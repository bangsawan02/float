/**
 * 好友提示 畫面中間一條訊息
 * 3秒後會自動消失 or 點擊任意處
 */
var FriendHintNode = cc.Node.extend({
    ctor: function () {
        this._super();

        this.setCascadeOpacityEnabled(true);

        // 提示背景
        var hintBgSprite = new ccui.Scale9Sprite("lobby_bg_hint.png");
        hintBgSprite.setPreferredSize(cc.size(JSVisibleSize.width, 60));
        hintBgSprite.setOpacity(242);
        this.addChild(hintBgSprite);

        // 提示文字
        var hintLabel = this._hintLabel = new cc.LabelTTF("", JSFontBoldName, 12, cc.size(0, 0), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        this.addChild(hintLabel);

        this.setOpacity(0);

        // 加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this._onTouchBegan.bind(this)
        }, this);
    },

    /**
     * show 提示
     */
    showHint: function (msg) {
        this._hintLabel.setString(msg);

        // show 3秒
        this.runAction(cc.sequence(
            cc.fadeIn(0.2),
            cc.delayTime(3),
            cc.fadeOut(0.2)
        ));
    },

    /**
     * 點擊任意處消失
     * @private
     */
    _onTouchBegan: function (touch, event) {
        if (this.getOpacity() === 0)
            return false;
        else {
            this.stopAllActions();
            this.runAction(cc.sequence(
                cc.fadeOut(0.2)
            ));
            return true;
        }
    }
});