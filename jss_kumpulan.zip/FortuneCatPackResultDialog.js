/**
 * 5.3.7 招財貓駕到 結果dialog
 */

var FortuneCatPackResultDialog = BaseDialogLayer.extend({
    ctor: function (param) {
        this._super();

        this.key = "FortuneCatPackResultDialog";

        this._param = param;

        // 要讀的圖檔
        this.loadFileArray = PurchasePackTool.getLoadFileArrayByPurchasePackSkin(PurchaseStructuresData.PackSkin.FORTUNE_CAT);
    },

    // 清掉不用的東西
    onExit: function () {
        this._loadFileDone && cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[0]);

        this._super();
    },

    // 素材讀完
    loadFileDone: function () {
        this._super();

        cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[0], this.loadFileArray[1]);

        var param = this._param;

        // 內容Node
        var contentNode = new cc.Node();
        contentNode.setCascadeOpacityEnabled(true);
        contentNode.setPosition(JSScreenMidPos);
        this._animationLayer.addChild(contentNode);

        // 背景
        var bg = new ccui.Scale9Sprite("pp_fortunecat_bg.png");
        bg.setPreferredSize(cc.size(300, 147));
        contentNode.addChild(bg);

        // 標題
        if (param.title) {
            // 標題背景
            var light = new cc.Sprite("#pp_fortunecat_pic_light.png");
            light.setPosition(0, 86);
            contentNode.addChild(light);

            // 標題
            var title = new cc.Sprite("#pp_fortunecat_word_success.png");
            title.setPosition(-1, 86);
            contentNode.addChild(title);
        }

        // 內文
        var contentLabel = new cc.LabelTTF(param.msg, JSFontName, 15);
        contentLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        contentNode.addChild(contentLabel, 1);

        // 按鈕
        var btn = ButtonUtility.createSimpleButton("pp_fortunecat_BT_01.png", cc.size(110, 42), param.btnText, JSColor.WHITE, 16);
        btn.addTouchUpInsideAction(this._closeDialogAnimation, this);
        btn.setPosition(0, -71);
        contentNode.addChild(btn);
    }
});