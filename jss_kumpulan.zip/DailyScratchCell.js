/**
 * 刮刮卡的cell
 * isVipCell    是不是vip的cell(有額外的顯示)
 */
var DailyScratchCell = cc.TableViewCell.extend({
    ctor: function (isVipCell = false) {
        this._super();
        this._index = 0;                // 第幾張刮刮卡
        this._quickPlayGame = 0;        // 馬上玩的類型
        this._isVipCell = isVipCell;    // 是不是vip刮刮卡

        var bgSize = cc.size(DailyScratchCell.WIDTH - 4, DailyScratchLayer.TABLE_VIEW_HEIGHT);
        var midPos = cc.p(DailyScratchCell.WIDTH / 2, bgSize.height / 2);

        // 背景圖
        var bgSprite = new ccui.Scale9Sprite((isVipCell) ? "lobby_btn_tournament_01.png" : "lobby_bg_list_02.png");
        bgSprite.setPreferredSize((isVipCell) ? cc.size(bgSize.width + 6, bgSize.height + 6) : bgSize);     // vip的背景要大一點
        bgSprite.setPosition(midPos);
        this.addChild(bgSprite);

        // 標籤
        var tabSprite = new cc.Sprite("#daily_scratch_banner.png");
        tabSprite.setPosition(midPos.x, midPos.y + 72);
        this.addChild(tabSprite, 2);

        // 數字
        var serialSprite = this._serialSprite = new cc.Sprite("#daily_scratch_num_0.png");
        serialSprite.setPosition(tabSprite.getPosition());
        this.addChild(serialSprite, 2);

        // 寶箱
        var chestSprite = this._chestSprite = new cc.Sprite("#daily_scratch_chest_13.png");
        chestSprite.setAnchorPoint(cc.p(0.5, 0));
        chestSprite.setPosition(midPos.x, midPos.y - 34);
        this.addChild(chestSprite, 2);

        // 按鈕(分為 領獎按鈕、時間按鈕、廣告按鈕)
        {
            var btnSize = cc.size(70, 20);

            // 領獎按鈕
            var images = (isVipCell) ? ["lobby_btn_10.png", "lobby_btn_10.png", "lobby_btn_04.png"] : ["lobby_btn_01.png", "lobby_btn_01.png", "lobby_btn_04.png"];
            var titles = [LocalizedString.FreeChip("領獎"), LocalizedString.FreeChip("領獎"), LocalizedString.FreeChip("已領獎")];
            var itemNodes = ButtonUtility.createArrayScale9Nodes(images, btnSize, titles, 10, JSColor.BLACK);
            itemNodes[2].setOpacity(255);   // 把透明度調回來
            var button = this._rewardButton = new GSControlButton(itemNodes[0], btnSize);
            button.setBackgroundSpriteForState(itemNodes[1], cc.CONTROL_STATE_HIGHLIGHTED);
            button.setBackgroundSpriteForState(itemNodes[2], cc.CONTROL_STATE_DISABLED);
            button.addTouchUpInsideAction(this._controlGetRewardClick, this);
            button.setPosition(midPos.x, midPos.y - 48);
            this.addChild(button, 2);

            // 時間按鈕
            {
                // 按鈕
                images = ["lobby_btn_01.png", "lobby_btn_01.png", "lobby_btn_01.png"];
                itemNodes = ButtonUtility.createArrayScale9Nodes(images, btnSize);
                button = this._timeButton = new GSControlButton(itemNodes[0], btnSize);
                button.setPosition(midPos.x, midPos.y - 48);
                button.addTouchUpInsideAction(this._controlGetRecentClick, this);
                button.setVisible(false);
                this.addChild(button, 2);

                // 時間按鈕裡面的東西(分為時間node、玩法label)
                {
                    // 時間node(用來做動畫、輪播)
                    var timeNode = this._timeNode = new cc.Node();
                    timeNode.setCascadeColorEnabled(true);
                    timeNode.setCascadeOpacityEnabled(true);
                    timeNode.setPosition(btnSize.width / 2, btnSize.height / 2);
                    itemNodes[0].addChild(timeNode);

                    // 時間icon(有兩種)
                    var timeIcon = this._timeIcon = new cc.Sprite("#daily_scratch_timeicon.png");
                    timeIcon.setPositionX(-20);
                    timeNode.addChild(timeIcon);

                    // 時間label用來做時間倒數
                    var timeLabel = this._timeLabel = new GSTimeLabel("", JSFontBoldName, 12);
                    timeLabel.setFormat("%mm:%ss");
                    timeLabel.setFontFillColor(JSColor.BLACK);
                    timeLabel.setPositionX(5);
                    timeNode.addChild(timeLabel);

                    // 玩法label(ex:馬上玩\nGaple)
                    var playLabel = this._playLabel = new cc.LabelTTF("", JSFontBoldName, 8);
                    playLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                    playLabel.setFontFillColor(JSColor.BLACK);
                    playLabel.setPosition(timeNode.getPosition());
                    playLabel.setVisible(false);
                    itemNodes[0].addChild(playLabel);
                }
            }

            // 廣告按鈕
            {
                // 按鈕
                btnSize = cc.size(52, 16);
                images = ["daily_scratch_btn_green.png", "daily_scratch_btn_green.png", "daily_scratch_btn_green.png"];
                itemNodes = ButtonUtility.createArrayScale9Nodes(images, btnSize);
                button = this._videoBtn = new GSControlButton(itemNodes[0], btnSize);
                button.setPosition(midPos.x, midPos.y - 68);
                button.addTouchUpInsideAction(this._controlGetVideoClick, this);
                this.addChild(button, 2);

                // 按鈕內的icon
                var iconSprite = new cc.Sprite("#daily_scratch_playicon.png");
                iconSprite.setPosition(btnSize.width / 2 - 16, btnSize.height / 2);
                itemNodes[0].addChild(iconSprite);

                // 按鈕內的文字(ex:-15秒)
                var btnLabel = this._videoLabel = new cc.LabelTTF("", JSFontBoldName, 8);
                btnLabel.setAnchorPoint(0, 0.5);
                btnLabel.setPosition(btnSize.width / 2 - 8, btnSize.height / 2);
                itemNodes[0].addChild(btnLabel);
            }
        }

        // 累積中的東西
        {
            // 累積中的node
            var accumulateNode = this._accumulateNode = new cc.Node();
            accumulateNode.setPosition(midPos.x, midPos.y + 47);
            accumulateNode.setVisible(false);
            this.addChild(accumulateNode, 2);

            // 背景
            bgSprite = new ccui.Scale9Sprite("daily_scratch_title_bg.png");
            bgSprite.setPreferredSize(cc.size(80, 24));
            accumulateNode.addChild(bgSprite);

            // 累積中的文字
            var accumulateLabel = new cc.LabelTTF(LocalizedString.FreeChip("累積中"), JSFontBoldName, 10);
            accumulateLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            accumulateLabel.enableStroke(cc.color(51, 0, 0), 1);
            accumulateNode.addChild(accumulateLabel);
        }

        // vip額外多的
        if (isVipCell) {
            // 擋touch(避免點到後面的cell)
            var dummy = new DummyTouchLayer(bgSize);
            this.addChild(dummy, -1);

            // 陰影
            var shadowSprite = new ccui.Scale9Sprite("bg_shadow_02.png");
            shadowSprite.setPreferredSize(cc.size(bgSize.width + 12, bgSize.height));
            shadowSprite.setPosition(midPos);
            this.addChild(shadowSprite, -1);

            // 外圍光圈
            var lightSprite = new ccui.Scale9Sprite("lobby_recommend.png");
            lightSprite.setPreferredSize(cc.size(bgSize.width + 6, bgSize.height + 6));
            lightSprite.setPosition(midPos);
            this.addChild(lightSprite);
        }
    },

    /**
     * 更新Cell
     * @param index     cell的index
     */
    refreshCell: function (index) {
        // 先暫停所有動畫
        this._timeNode.stopAllActions();
        this._playLabel.stopAllActions();
        this.stopAllActions();

        // 要延後一禎才做的事, 下面有解釋
        var delayAction = undefined;

        // 抓資料
        var scratchCardData = DataModal.scratchCardData;
        var cellCount = this._totalCellCount = scratchCardData.scratchCardCount;

        // 沒有這筆資料，隱藏這張刮刮卡
        if (index >= cellCount) {
            this.setVisible(false);
            return;
        }
        // 有vip刮刮卡，但是這張刮刮卡不是vip cell，隱藏他(為了讓畫面顯示，有vip刮刮卡時會多加一個cell讓最後一個cell可以正常顯示，不然會被vip cell給遮住)
        else if (scratchCardData.haveVipCard && index === cellCount - 1 && !this._isVipCell) {
            this.setVisible(false);
            return;
        } else
            this.setVisible(true);

        // 抓刮刮卡param
        var cardParam = scratchCardData.cardList[index];
        this._index = cardParam.index;
        this._type = cardParam.type;

        // 刷新數字 分為vip(顯示vip) 和 非vip(顯示數字index)
        this._serialSprite.setSpriteFrame((this._isVipCell) ? "daily_scratch_word_vip.png" : JSStringUtility.format("daily_scratch_num_%d.png", this._index + 1));

        // 刷新前可能在做動畫，把透明度調回來
        this._timeNode.setOpacity(255);
        this._playLabel.setOpacity(255);

        // 刷新寶箱
        var cardBtnStatus = ScratchCardData.BtnStatus;
        switch (cardParam.btnStatus) {
            case cardBtnStatus.CanReward:   // 可領獎:領獎按鈕顯示領獎
                // 刷新寶箱圖
                this._chestSprite.setSpriteFrame((this._isVipCell) ? "daily_scratch_chest_18.png" : "daily_scratch_chest_15.png");

                // 領獎按鈕設為可按
                this._rewardButton.setVisible(true);
                this._rewardButton.setEnabled(true);

                // 隱藏時間按鈕
                this._timeButton.setVisible(false);

                // 隱藏廣告按鈕
                this._videoBtn.setVisible(false);

                // 隱藏累積中
                this._accumulateNode.setVisible(false);

                break;
            case cardBtnStatus.DoneReward:  // 已領獎:領獎按鈕顯示已領獎
                // 刷新寶箱圖
                this._chestSprite.setSpriteFrame((this._isVipCell) ? "daily_scratch_chest_17.png" : "daily_scratch_chest_14.png");

                // 領獎按鈕設為不可按
                this._rewardButton.setVisible(true);
                this._rewardButton.setEnabled(false);

                // 隱藏時間按鈕
                this._timeButton.setVisible(false);

                // 隱藏廣告按鈕
                this._videoBtn.setVisible(false);

                // 隱藏累積中
                this._accumulateNode.setVisible(false);

                break;
            case cardBtnStatus.NoRewardButAccumulating: // 累積中:時間按鈕
                // 刷新寶箱圖
                this._chestSprite.setSpriteFrame((this._isVipCell) ? "daily_scratch_chest_16.png" : "daily_scratch_chest_13.png");

                // 顯示累積中
                this._accumulateNode.setVisible(true);

                // 隱藏領獎按鈕
                this._rewardButton.setVisible(false);

                // 顯示時間按鈕
                this._timeButton.setVisible(true);

                // 調整時間按鈕的icon
                this._timeNode.setVisible(true);
                this._timeIcon.setSpriteFrame("daily_scratch_timeicon.png");

                // 判斷是否在桌內
                if (PushScene.isGame) {
                    // 隱藏廣告按鈕
                    this._videoBtn.setVisible(false);

                    // 桌內時間按鈕不可點擊
                    this._timeButton.setEnabled(false);

                    // 不輪播因此不顯示玩法
                    this._playLabel.setVisible(false);

                    // 判斷時間要不要倒數
                    var socketTime = DataModal.scratchCardData.receiveSocketTime;
                    var remainTime = cardParam.remainTime;
                    if (socketTime > 0) { // 代表有收到倒數cmd (桌內)
                        var countdownTime = remainTime - (JSCodeUtility.getNowTime() - socketTime);
                        if (countdownTime > 0) {
                            delayAction = () => {
                                this._timeLabel.countdownSeconds(countdownTime, undefined, (seconds) => {
                                    cardParam.remainTime = seconds;
                                });
                            };
                        } else {
                            // 時間有問題重要資料
                            DataModal.scratchCardData.startGetInfo();
                        }
                    } else {
                        // 只設定時間
                        delayAction = () => {
                            this._timeLabel.countdownSeconds(remainTime);
                            this._timeLabel.pauseTimer();
                        };
                    }
                } else {
                    // 顯示廣告按鈕
                    this._videoBtn.setVisible(cardParam.haveAD && DataModal.videoADData.checkADAvailable(VideoADData.Type.ScratchMix));
                    this._videoLabel.setString(JSStringUtility.format(LocalizedString.FreeChip("-%d秒"), cardParam.adTime));

                    // 預設玩法 LuxyPoker要導入Texas(我們Texas編號是38) 這邊跟每日寶箱任務一樣要多轉一次
                    this._quickPlayGame = GS.isLuxyPoker ? GSEnum.Game.Texas : GSEnum.Game.Domino;

                    // server有傳玩法過來
                    if (cardParam.btnUrl) {
                        // server送19是導入Texas(我們Texas編號是38) 這邊跟每日寶箱任務一樣要多轉一次
                        // server Neil:server那邊會被合併版影響導致單一版這邊有可能會傳19以外的東西，所以這邊單一版如果玩法是38會不傳btnUrl，吃上面的預設
                        this._quickPlayGame = (cardParam.btnUrl === 19) ? GSEnum.Game.Texas : cardParam.btnUrl;
                        this._quickPlayGame = (cardParam.btnUrl === GSEnum.Game.GapleFriend) ? GSEnum.Game.Gaple : cardParam.btnUrl;
                    }

                    var gameName = JSStringUtility.format("%s\n(%s)", LocalizedString.Lobby("馬上玩"), GSEnum.GameName[this._quickPlayGame]);

                    // 大廳時間按鈕可以點擊
                    this._timeButton.setEnabled(true);

                    // 設定倒數(用來輪播)
                    delayAction = () => {
                        this._timeLabel.countdownSeconds(cardParam.remainTime);
                        this._timeLabel.pauseTimer();
                    };

                    // 設定玩法(用來輪播)
                    this._playLabel.setVisible(true);
                    this._playLabel.setString(gameName);

                    // 輪播動畫
                    var _this2 = this;
                    var delayTime = 2;
                    var fadeTime = 0.2;
                    this._playLabel.setOpacity(0);
                    this.runAction(cc.repeatForever(cc.sequence(
                        cc.delayTime(delayTime),
                        cc.callFunc(function () {
                            _this2._timeNode.runAction(cc.fadeOut(fadeTime));
                        }),
                        cc.delayTime(fadeTime),
                        cc.callFunc(function () {
                            _this2._playLabel.runAction(cc.fadeIn(fadeTime));
                        }),
                        cc.delayTime(delayTime + fadeTime),
                        cc.callFunc(function () {
                            _this2._playLabel.runAction(cc.fadeOut(fadeTime));
                        }),
                        cc.delayTime(fadeTime),
                        cc.callFunc(function () {
                            _this2._timeNode.runAction(cc.fadeIn(fadeTime));
                        }),
                        cc.delayTime(fadeTime)
                    )));
                }

                break;
            case cardBtnStatus.NoRewardAndMission:  // 不可領獎與解任務:時間按鈕
                // 刷新寶箱圖
                this._chestSprite.setSpriteFrame((this._isVipCell) ? "daily_scratch_chest_16.png" : "daily_scratch_chest_13.png");

                // 顯示時間按鈕但不可按
                this._timeButton.setVisible(true);
                this._timeButton.setEnabled(false);

                // 調整時間icon
                this._timeNode.setVisible(true);
                this._timeIcon.setSpriteFrame("daily_scratch_lockicon.png");

                delayAction = () => {
                    // 設定倒數
                    this._timeLabel.countdownSeconds(cardParam.remainTime);
                    this._timeLabel.pauseTimer();
                };

                // 隱藏玩法
                this._playLabel.setVisible(false);

                // 隱藏領獎按鈕
                this._rewardButton.setVisible(false);

                // 隱藏廣告按鈕
                this._videoBtn.setVisible(false);

                // 隱藏累積中
                this._accumulateNode.setVisible(false);

                break;
        }

        // 因為在timeLabel onEnter/Exit 設 destory的關係, tableView等等才會onEnter 這邊先讓他下一禎在做事了
        delayAction && this.runAction(cc.callFunc(delayAction, this));
    },

    /**
     * 按鈕
     */
    // 領獎按鈕
    _controlGetRewardClick: function (sender) {
        // 不是vip的話不能領vip
        if (this._isVipCell && DataModal.profileData.getVipLevel() < 2) {
            DialogManager.addDialog(new Dialog(DialogHelper(PushScene.isGame ? "NotVIPInGame" : "NotVIPInLobby")), false);
            return;
        }

        // 鎖住按鈕避免連續點
        sender.setEnabled(false);
        this.runAction(cc.sequence(
            cc.delayTime(1),
            cc.callFunc(() => sender.setEnabled(true))
        ));

        // 通知送領獎
        GS.dispatchCustomEvent("NotifyDailyScratchSendReward", {index: this._index, type: this._type});
    },

    // 時間按鈕
    _controlGetRecentClick: function () {
        // 關掉每日好禮dialog
        GS.dispatchCustomEvent("NotifyCloseActionListDialog");

        // 導馬上玩
        GS.dispatchCustomEvent("NotifyGoQuickPlay", {game: this._quickPlayGame});
    },

    // 廣告按鈕
    _controlGetVideoClick: function () {
        // 播放廣告
        DataModal.videoADData.showVideoAD({type: VideoADData.Type.ScratchMix});
    }
});

// 刮刮卡cell的寬度
DailyScratchCell.WIDTH = 80;