/**
 *  大廳好友邀請遊戲 Dialog
 *  @param type 好友邀請入桌/入桌失敗
 *  @param param 好友桌次資訊
 */
var FriendInvitationDialog = BaseDialogLayer.extend({
    ctor: function (type, param) {
        this._super();

        this.key = "FriendInvitationDialog";
        this._param = param;
        this._dialogType = type;                 // 好友邀請入桌/入桌失敗
        this._inviteType = param.inviteType;     // 邀請入桌(dialogType:1)才有的分類  1:好友邀請 2:Gaple好友桌邀請

        // 主要的畫面都加在這裡
        var aniNode = this._animationNode;

        // Menu
        var menu = this._menu = new cc.Menu();
        menu.setPosition(0, 0);
        aniNode.addChild(menu);

        // 好友邀請入桌
        if (this._dialogType === FriendInvitationDialog.TYPE.INVITED) {
            this._createInvitedContent();
        }
        // 入桌失敗
        else if (this._dialogType === FriendInvitationDialog.TYPE.JOIN_FAIL) {
            this._createJoinFailContent();
        }

        // 遊戲玩法
        if (param.playMsg) {
            var infoPos = cc.p(JSScreenMidPos.x, 113 + JSScreenBonusHalfHeight);

            // 玩法文字
            var titleLabel = new cc.LabelTTF(param.playMsg, JSFontName, 12);
            titleLabel.setPosition(infoPos);
            aniNode.addChild(titleLabel, 1);

            // 玩法背景
            var msgSize = titleLabel.getContentSize();
            var infoBgSprite = new ccui.Scale9Sprite("bg_white_02.png");
            infoBgSprite.setPreferredSize(cc.size(msgSize.width + 20, msgSize.height + 12));
            infoBgSprite.setColor(JSColor.BLACK);
            infoBgSprite.setPosition(infoPos);
            aniNode.addChild(infoBgSprite);
        }

        // 背景 (入桌失敗不會有玩法)
        var baseWidth = 322;
        var bgWidth = Math.max(msgSize ? msgSize.width + 30 : 0, baseWidth);
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(cc.size(bgWidth, 195));
        bgSprite.setPosition(JSScreenMidPos);
        aniNode.addChild(bgSprite, -1);

        // 右上關閉按鈕
        var exitNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_circle_04.png", null,
            "#lobby_btn_pic_window_x.png");
        var exitItem = new cc.MenuItemSprite(exitNodes[0], exitNodes[1], null, this._closeDialog, this);
        exitItem.setPosition(252 + bgWidth / 2 + JSScreenBonusHalfWidth, 238 + JSScreenBonusHalfHeight);
        menu.addChild(exitItem);
    },

    onExit: function () {
        if (this._dialogType === FriendInvitationDialog.TYPE.INVITED)
            cc.spriteFrameCache.removeSpriteFramesFromFile("friend/friend.plist");

        this._super();
    },

    /**
     * 建立好友邀請入桌訊息畫面
     * @private
     */
    _createInvitedContent: function () {
        // 主要的畫面都加在這裡
        var aniNode = this._animationNode;
        var friendString = LocalizedString.Friend;
        var param = this._param;
        var inviteType = this._inviteType;

        // 邀請玩家暱稱
        var inviterLabel = new EllipsisLabel(param.inviterNickname, JSFontBoldName, 12, 200);
        inviterLabel.setPosition(JSScreenMidPos.x, 174 + JSScreenBonusHalfHeight);
        aniNode.addChild(inviterLabel);

        // 邀請玩家大頭照
        var photoNode = new LobbyCircleProfileNode(param.inviterPhotoURL);
        photoNode.setScale(0.7);
        var posX = JSScreenMidPos.x - inviterLabel.getContentSize().width / 2 - 30;
        photoNode.setPosition(posX, 174 + JSScreenBonusHalfHeight);
        aniNode.addChild(photoNode);

        // 邀請文字
        var inviteText;
        switch (inviteType) {
            case 1:
                // 好友邀請
                inviteText = friendString("邀請您一起玩");
                break;
            case 2:
                // Gaple好友桌
                inviteText = friendString("邀你一起玩Gaple好友桌");
                break;
            default:
                // 預設文字
                inviteText = friendString("邀請您一起玩");
                break;
        }

        var inviteLabel = new cc.LabelTTF(inviteText, JSFontName, 14);
        inviteLabel.setFontFillColor(JSColor.YELLOW2);
        inviteLabel.setPosition(JSScreenMidPos.x, 144 + JSScreenBonusHalfHeight);
        aniNode.addChild(inviteLabel);

        // 加入按鈕
        var joinNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", cc.size(115, 28),
            friendString("加入"), 14, JSColor.BLACK);
        var joinItem = new cc.MenuItemSprite(joinNodes[0], joinNodes[1], null, this._joinBtnClicked, this);
        joinItem.setPosition(JSScreenMidPos.x, 74 + JSScreenBonusHalfHeight);
        this._menu.addChild(joinItem);

        // 加Resources的Function
        var resources = ["friend/friend.plist", "friend/friend.png"];
        var addResFunc = () => {
            // 讀取Plist
            cc.spriteFrameCache.addSpriteFrames(resources[0], resources[1]);

            // 標題
            var titleSprite = new cc.Sprite("#friend_word_invitation.png");
            titleSprite.setPosition(JSScreenMidPos.x, 212 + JSScreenBonusHalfHeight);
            aniNode.addChild(titleSprite);
        };

        if (cc.sys.isNative || cc.textureCache.getTextureForKey(resources[1])) {
            addResFunc();
        } else {
            // H5要先Loader
            cc.loader.load(resources, function () {
                addResFunc();
            });
        }

        // 如果是好友邀請入桌要額外監聽是否有收到join_friend_room的回應
        // 因為join_friend_room是跟其他功能共用，要分開處理
        if (inviteType === 1) {
            // 一般好友邀請 在視窗監聽結果
            GS.addListener("NotifyJoinFriendRoomDone", this.notifyJoinFriendRoomDone.bind(this), this);
        }
    },

    /**
     * 建立入桌失敗訊息畫面
     * @private
     */
    _createJoinFailContent: function () {
        // 主要的畫面都加在這裡
        var aniNode = this._animationNode;
        var friendString = LocalizedString.Friend;

        // 錯誤訊息
        var errorMsgLabel = new cc.LabelTTF(this._param.errorMsg, JSFontBoldName, 14);
        errorMsgLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        errorMsgLabel.setFontFillColor(JSColor.YELLOW2);
        errorMsgLabel.setPosition(JSScreenMidPos.x, 168 + JSScreenBonusHalfHeight);
        aniNode.addChild(errorMsgLabel);

        // 確定按鈕，導相同玩法牌局
        var joinOtherNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", cc.size(115, 28),
            friendString("確定"), 14, JSColor.BLACK);
        var joinOtherItem = new cc.MenuItemSprite(joinOtherNodes[0], joinOtherNodes[1], null,
            this._joinBtnClicked, this);
        joinOtherItem.setPosition(JSScreenMidPos.x, 76 + JSScreenBonusHalfHeight);
        this._menu.addChild(joinOtherItem);
    },

    // 關閉dialog按鈕
    _closeDialog: function () {
        // 如果是好友邀請入桌畫面要多送拒絕訊息給server
        if (this._dialogType === FriendInvitationDialog.TYPE.INVITED)
            DataProcess.sendString(JSStringUtility.format("invitation_reject %s", this._param.inviterID));

        this._closeDialogAnimation();
    },

    /**
     * 按鈕事件
     */
    // 加入好友/導相同玩法的牌局
    _joinBtnClicked: function () {
        var param = this._param;

        // 檢查錢
        var myMoney = DataModal.profileData.money;
        var needMoney = param.needMoney;
        var inviteType = this._inviteType;

        // 埋點
        if (inviteType === 2)
            DataProcess.sendString("track_gaple_friend_click 11");

        // 好友桌額外處理
        if (this._dialogType === FriendInvitationDialog.TYPE.INVITED && inviteType === 2) {
            if (myMoney >= needMoney) {
                // 送出跟隨好友入桌
                var obj = {
                    userid: param.inviterID,
                    room_id: param.roomID,
                    game: param.game
                };
                // 通知server
                DataModal.friendData.sendJoinCmd(FriendData.joinType.FriendTableInvitation, JSON.stringify(obj));

                // Gaple好友桌邀請 由大廳監聽結果 直接關掉視窗
                this._closeDialogAnimation();

                // 卡loading TODO: 要改成新loading
                GSLoading.addLoadingView();
            } else {
                // 一般沒錢的Dialog
                DialogManager.addDialog(new AvatarDialog(DialogHelper("RoomNoMoney", JSCodeUtility.getCurrencyString(needMoney - myMoney))));
            }

            // Gaple好友桌邀請 由大廳監聽結果 直接關掉視窗
            this._closeDialogAnimation();

            return;
        }

        // 夠錢玩
        if (myMoney >= needMoney) {
            // 一律送入桌指令給server
            if (this._dialogType === FriendInvitationDialog.TYPE.INVITED) {
                // 通知server
                var obj = {
                    userid: param.inviterID,
                    room_id: param.roomID,
                    game: param.game
                };
                DataModal.friendData.sendJoinCmd(FriendData.joinType.FriendInvitation, JSON.stringify(obj));
            }

            // 設定現在遊戲
            DataModal.setGameData(param.game);

            // 送馬上玩指令
            if (this._dialogType === FriendInvitationDialog.TYPE.JOIN_FAIL) {
                var json = {
                    game: param.game,
                    playType: param.playType,
                    fee: param.fee
                };
                DataProcess.sendString("mix_quickJoin " + JSON.stringify(json));
            }

            // 其他設定
            DataModal.lobbyInfo.toLobbyOpenPage = LobbyOpenPage.NONE;
            DataModal.lobbyInfo.lastGameMode = this._param.playType;

            // 卡loading TODO: 要改成新loading
            GSLoading.addLoadingView();
        } else {    // 不夠錢
            // 一般沒錢的Dialog
            DialogManager.addDialog(new AvatarDialog(DialogHelper("RoomNoMoney", JSCodeUtility.getCurrencyString(needMoney))));
            this._closeDialogAnimation();
        }
    },

    /**
     * 通知事件
     */
    notifyJoinFriendRoomDone: function (event) {
        if (!event || !event.getUserData())
            return;

        // 拿掉loading
        GSLoading.removeLoadingView();

        // 關掉好友邀請入桌的dialog
        this._closeDialogAnimation();

        var param = event.getUserData();

        if (param.code !== 0) {
            param.errorMsg = LocalizedString.Friend("此桌已無法入桌\n是否要與其他人玩?\n實際進入底台大小，可能與看到的不同");
            param.game = this._param.game;
            param.fee = this._param.fee;
            param.playMsg = this._param.playMsg;
            param.playType = "casual";
            DialogManager.addDialog(new FriendInvitationDialog(FriendInvitationDialog.TYPE.JOIN_FAIL, param), true);
        }
    }
});

FriendInvitationDialog.TYPE = {
    INVITED: 0,         // 好友邀請入桌
    JOIN_FAIL: 1        // 邀請入桌失敗
};