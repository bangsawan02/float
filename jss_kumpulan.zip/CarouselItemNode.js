/**
 * Created by terry on 2021/7/7.
 * 用來輪播顯示的item
 * warning: 請不要在外部使用setVisible,輪播時沒有效果。
 * warning: 這個node預設是顯示的。
 */

var CarouselItemNode = cc.Node.extend({
    ctor: function () {
        this._super();

        // 預設開啟
        this.setCascadeColorEnabled(true);
        this.setCascadeOpacityEnabled(true);

        this.isNeedToCarousel = true;
        this.setNeedToCarousel(true);
        this.setVisible(true);
    },

    /**
     * removeFromParent也要override掉 要告知現在看不到了
     */
    removeFromParent: function (cleanup) {
        // 先設自己不需要輪播
        this.setNeedToCarousel(false);

        // 最後在砍掉自己 因為Parent會不見
        this._super(cleanup);
    },

    removeFromParentAndCleanup: function (cleanup) {
        this.removeFromParent(cleanup);
    },

    setNeedToCarousel: function (value) {
        this.isNeedToCarousel = value;
        this.setVisible(value);

        // 通知外面 不走Event怕太多Container了
        for (var c = this.parent; c != null; c = c.parent) {
            if (c.refresh) {
                c.refresh();
                // break;
            }
        }
    },
});