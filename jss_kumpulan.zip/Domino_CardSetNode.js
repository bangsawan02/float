/**
 * 顯示牌的組合畫面 也用在個人的手牌上 numbers要帶string array
 */
var Domino_CardSetNode = cc.Node.extend({
    // 牌的座標
    CARD_SET_CARD_POS: [
        cc.p(-33, 0),
        cc.p(-11, 0),
        cc.p(11, 0),
        cc.p(33, 0)
    ],

    // 點擊牌的排序 3跟4代表幾張牌的時後 後面代表牌的順序
    CARD_SET_CARD_SORT: {
        3: [123, 132, 231],
        4: [1234, 1324, 1432, 2314, 2431, 3412]
    },

    // 牌型機率使用: 牌型點數的數量
    // 點數0: 1張牌(00) / 點數1: 1張牌(01) / 點數2: 2張牌(02, 11) / 點數3: 2張牌(03, 12) / 點數4 : 3張牌(04, 13, 22)
    // 點數5: 3張牌(05, 14, 23) / 點數6: 4張牌(06, 15, 24, 33) / 點數7: 3張牌(16, 25, 34) / 點數8: 3張牌(26, 35, 44) / 點數9 : 2張牌(36, 45)
    // 點數10: 2張牌(46, 55) / 點數11: 1張牌(56) / 點數12: 1張牌(66)

    // 牌型機率使用: 牌型QQ時第四張牌為9的個數
    // 第3張0 第4張是9 數量2 / 第3張1 第4張是8 數量3/ 第3張2 第4張是7 數量3/ 第3張3 第4張是6 數量4/ 第3張4 第4張是5 數量3
    // 第3張5 第4張是4 數量3 / 第3張6 第4張是3 數量2/ 第3張7 第4張是2 or 12 數量3/ 第3張8 第4張是1 or 11 數量2/ 第3張9 第4張是0 or 10 數量3
    // 第3張10 第4張是9 數量2 / 第3張11 第4張是8 數量3/ 第3張12 第4張是7 數量3
    CARD_NUMBER_99_COUNT: [
        2, 3, 3, 4, 3,
        3, 2, 3, 2, 3,
        2, 3, 3
    ],

    // 牌型機率使用: smallCards牌型 第四張牌拿到的張數
    // 手牌3張總和9 第四張總和0~0: 1個 / 手牌3張總和8 第四張總和0~1: 2個 / 手牌3張總和7 第四張總和0~2: 4個 / 手牌3張總和6 第四張總和0~3: 6個 / 手牌3張總和5 第四張總和0~4: 9個
    // 手牌3張總和4 第四張總和0~5: 12個 / 手牌3張總和3 第四張總和0~6: 16個
    CARD_NUMBER_0_TO_6_COUNT: [
        1, 2, 4, 6, 9,
        12, 16
    ],

    // 牌型機率使用: BigCards牌型 第四張牌拿到的張數
    // 手牌3張總和33 第四張總和6~12: 16個 / 手牌3張總和32 第四張總和7~12: 12個 / 手牌3張總和31 第四張總和8~12: 9個 / 手牌3張總和30 第四張總和9~12: 6個 / 手牌3張總和29 第四張總和10~12: 4個
    // 手牌3張總和28 第四張總和11~12: 2個 / 手牌3張總和27 第四張總和12~12: 1個
    CARD_NUMBER_6_TO_12_COUNT: [
        16, 12, 9, 6, 4,
        2, 1
    ],

    // 牌型機率使用: 整副牌28-3(自己的手牌)
    TOTAL_CARD_COUNT: 25,

    ctor: function (numbers) {
        this._super();

        this.setCascadeOpacityEnabled(true);
        this.setCascadeColorEnabled(true);

        this.cardArray = [];                        // 所有的牌
        this._scoreLabelArray = [];                 // 分數的Label
        this._changeCardNode = null;                // 用來做切換牌的Node 會放假按鈕跟 點擊牌切換順序的字
        this._isSelfCard = false;                   // 是否是自己手牌
        this._scoreLabelColor = [cc.color(255, 0, 136), cc.color(0, 255, 255)];     // 分數的嚴色 9的話用[0] 其他用[1]

        // 放牌的Node
        var cardNode = this._cardNode = new cc.Node();
        cardNode.setCascadeOpacityEnabled(true);
        cardNode.setCascadeColorEnabled(true);
        this.addChild(cardNode);

        // 上方分數的部份
        var scoreY = 31;
        var scoreNode = this._scoreNode = new cc.Node();
        scoreNode.setPosition(0, scoreY);
        scoreNode.setCascadeOpacityEnabled(true);
        scoreNode.setCascadeColorEnabled(true);
        scoreNode.setVisible(false);
        this.addChild(scoreNode, 1);

        var scoreBgSprite = new ccui.Scale9Sprite("lobby_pic_frame_black.png");
        scoreBgSprite.setPreferredSize(cc.size(50, 20));
        scoreBgSprite.setPosition(0, 0);
        scoreNode.addChild(scoreBgSprite);

        for (var i = 0; i < 2; i++) {
            var posX = i == 0 ? -13 : 13;
            // 分數的底
            var scoreBgSprite2 = new ccui.Scale9Sprite("lobby_pic_square_black.png");
            scoreBgSprite2.setPreferredSize(cc.size(14, 12));
            scoreBgSprite2.setPosition(posX, 0);
            scoreNode.addChild(scoreBgSprite2);

            // 分數
            var scoreLabel = this._scoreLabelArray[i] = new cc.LabelTTF("0", JSFontName, 12);
            scoreLabel.setPosition(posX, 0);
            scoreNode.addChild(scoreLabel, 1);
        }

        var scoreDot = new cc.LabelTTF(":", JSFontName, 12);
        scoreNode.addChild(scoreDot, 1);

        // 上方特殊牌型的圖片動畫
        var specialNode = this._specialNode = new cc.Node();
        specialNode.setCascadeOpacityEnabled(true);
        specialNode.setCascadeColorEnabled(true);
        specialNode.setPosition(0, scoreY);
        this.addChild(specialNode);

        // 把傳進來的牌組組出來
        if (numbers) {
            numbers.forEach(cardNum => {
                this.addCard(cardNum, false);
            });

            // 最後強制更新一次分數
            this._updateScore();
        }
    },

    /**
     * 清掉畫面
     */
    cleanData: function () {
        this._cardNode.removeAllChildren();
        this.cardArray = [];

        this._scoreNode.setVisible(false);
        this._changeCardNode && this._changeCardNode.setVisible(false);
        this._cardHintNode && this._cardHintNode.setVisible(false);

        // 拿掉特殊牌型
        this._specialNode.removeAllChildren();
        this._specialNode.setVisible(false);
    },

    /**
     * 設定是否為自己的手牌
     */
    setIsSelfCard: function (value) {
        this._isSelfCard = value;
    },

    /**
     * 新增牌
     * @param numberString 牌的號碼
     * @param animation 是否要翻牌
     * @param needUpdateScore 是否要更新分數
     */
    addCard: function (numberString, animation, needUpdateScore) {
        var len = arguments.length;
        if (len < 3)
            needUpdateScore = true;

        var nowLen = this.cardArray.length;
        if (nowLen >= 4)
            return;

        var newCard = new Domino_CardNode(numberString);
        newCard.setPosition(this.CARD_SET_CARD_POS[nowLen]);
        newCard.index = nowLen + 1;                 // 用來記下他原本是第幾張 +1 是為了不要有0 配合上面的設定的排序數字
        this._cardNode.addChild(newCard);

        this.cardArray.push(newCard);

        // 判斷是否要翻牌
        animation && newCard.turnRiver();

        // 假如超過三張 又是自己手牌 要加入可以換牌的
        if (this._isSelfCard && this.cardArray.length > 2)
            this.setChangeCardEnable(true);

        // 是否要更新分數
        needUpdateScore && this._updateScore();
    },

    /**
     * 抓取手牌數量
     */
    getCardCount: function () {
        return this.cardArray.length;
    },

    /**
     * 顯示牌型機率
     * @param isShow : 是否顯示
     */
    _showCardHint: function (isShow) {
        if (!isShow) {
            this._cardHintNode && this._cardHintNode.setVisible(false);
            return;
        }

        if (!this._cardHintNode) {
            var cardHintNode = this._cardHintNode = new cc.Node();
            this.addChild(cardHintNode);

            var bgSprite = new ccui.Scale9Sprite("lobby_bar_03.png");
            bgSprite.setPreferredSize(cc.size(70, 13));
            bgSprite.setPosition(-5, -40);
            cardHintNode.addChild(bgSprite);

            var hintLabel = this._cardHintLabel = new cc.LabelTTF(LocalizedString.Game(""), JSFontName, 8);
            hintLabel.setPosition(-5, -40);
            cardHintNode.addChild(hintLabel);
        }

        var getCardHint = (cardHintType, isNeedCheck) => {
            // 三張牌的總和
            var cardArray = this.cardArray;
            var cardTotalCount = cardArray.reduce((sum, cur) => sum + cur.getCardNumberSum(), 0);
            var card1 = cardArray[0];   // 第一張牌
            var card2 = cardArray[1];   // 第二張牌
            var card3 = cardArray[2];   // 第三張牌

            // 確認有哪些牌型需不需要判斷
            var checkOldHint = [1, 1, 1, 1, 1, 1];
            if (isNeedCheck) {
                // 哪幾個牌型已經判斷過 判斷過的牌型就不再判斷
                var checkHintArray = this._checkHintArray;
                for (var i = 0, len = checkHintArray.length; i < len; i++) {
                    for (var key in DOMINO_CARD_TYPE) {
                        if (checkHintArray[i] === DOMINO_CARD_TYPE[key]) {
                            checkOldHint[DOMINO_CARD_TYPE[key]] = 0;
                            break;
                        }
                    }
                }
            }

            // 判斷牌型
            if (checkOldHint[DOMINO_CARD_TYPE.SIX_DEVILS] && card1.getCardNumberSum() === 6 && card1.getCardNumberSum() === card2.getCardNumberSum() && card2.getCardNumberSum() === card3.getCardNumberSum())
                // Six Devils 4張牌都是點數6
                cardHintType = DOMINO_CARD_TYPE.SIX_DEVILS;
            else if (checkOldHint[DOMINO_CARD_TYPE.TWIN] && card1.isCoupleNumber() && card2.isCoupleNumber() && card3.isCoupleNumber())
                // Twin 4張牌都是對子
                cardHintType = DOMINO_CARD_TYPE.TWIN;
            else if (checkOldHint[DOMINO_CARD_TYPE.SMALL] && cardTotalCount >= 3 && cardTotalCount <= 9)
                // Small card
                cardHintType = DOMINO_CARD_TYPE.SMALL;
            else if (checkOldHint[DOMINO_CARD_TYPE.BIG] && cardTotalCount >= 27 && cardTotalCount <= 33)
                // Big card
                cardHintType = DOMINO_CARD_TYPE.BIG;
            else if (checkOldHint[DOMINO_CARD_TYPE.QQ] && (card1.getCardNumberSum() + card2.getCardNumberSum()) % 10 === 9)
                // QQ 左右兩組皆為9
                cardHintType = DOMINO_CARD_TYPE.QQ;
            else
                cardHintType = DOMINO_CARD_TYPE.NORMAL;

            var totalNum = 0;       // 計算第四張牌使用
            var fourNum = 0;        // 第四張牌
            var cardHint;           // 機率
            var cardTypeStr = "";   // 牌型名稱
            var denominator = this.TOTAL_CARD_COUNT; // 分母
            switch (cardHintType) {
                case DOMINO_CARD_TYPE.BIG:
                    // 手牌3張總和33 第四張牌 6~12 的機率
                    // 手牌3張總和32 第四張牌 7~12 的機率
                    // ...
                    // 手牌3張總和28 第四張牌 11~12 的機率
                    // 手牌3張總和27 第四張牌 12~12 的機率
                    totalNum = 33;  // 手牌3張總和
                    fourNum = 6;    // 第四張牌要大於的點數
                    fourNum = fourNum + (totalNum - cardTotalCount);    // 第四張牌的點數

                    // 手牌中 是第四張牌的點數有幾個
                    var handNumCount = 0;
                    for (var j = 0; j < 3; j++) {
                        if (cardArray[j].getCardNumberSum() >= fourNum && cardArray[j].getCardNumberSum() <= 12)
                            handNumCount++;
                    }

                    // 算機率
                    cardHint = (this.CARD_NUMBER_6_TO_12_COUNT[fourNum - 6] - handNumCount) / denominator;
                    cardTypeStr = "Big Cards ";
                    break;

                case DOMINO_CARD_TYPE.SMALL:
                    // 手牌3張總和9 第四張牌 0~0 的機率
                    // 手牌3張總和8 第四張牌 0~1 的機率
                    // ...
                    // 手牌3張總和4 第四張牌 0~5 的機率
                    // 手牌3張總和3 第四張牌 0~6 的機率
                    totalNum = 9;   // 手牌3張總和
                    fourNum = 0;    // 第四張牌要大於的點數
                    fourNum = fourNum + (totalNum - cardTotalCount);    // 第四張牌的點數
                    // 手牌中 是第四張牌的點數有幾個
                    var handNumCount = 0;
                    for (var j = 0; j < 3; j++) {
                        if (cardArray[j].getCardNumberSum() >= 0 && cardArray[j].getCardNumberSum() <= fourNum)
                            handNumCount++;
                    }
                    // 算機率
                    cardHint = (this.CARD_NUMBER_0_TO_6_COUNT[fourNum] - handNumCount) / denominator;
                    cardTypeStr = "Small Cards ";
                    break;

                case DOMINO_CARD_TYPE.TWIN:
                    // 只會有7張牌是對子(00,11,22,33,44,55,66) 7-3 = 11
                    cardHint = 4 / denominator;
                    cardTypeStr = "Twin Cards ";
                    break;

                case DOMINO_CARD_TYPE.SIX_DEVILS:
                    // 只會有4個6(06,15,24,33) 4-3 = 1
                    cardHint = 1 / denominator;
                    cardTypeStr = "Six Devils ";
                    break;

                case DOMINO_CARD_TYPE.QQ:
                    // 第3張牌+第4張牌總合要是9的機率
                    var threeNum = card3.getCardNumberSum();     // 第三張牌總和
                    var handNumCount = 0;
                    var num = 0;
                    if (threeNum <= 6) {
                        // 第三張是0~6
                        // 第3張0 第4張是9 / 第3張1 第4張是8 / 第3張2 第4張是7 / 第3張3 第4張是6
                        // 第3張4 第4張是5 / 第3張5 第4張是4 / 第3張6 第4張是3
                        num = 9 - threeNum;
                        // 手牌中 是第四張牌的點數有幾個
                        handNumCount = cardArray.filter(cur => cur.getCardNumberSum() === num).length;
                    } else if (threeNum >= 10) {
                        // 第三張是10~12
                        // 第3張10 第4張是9/ 第3張11 第4張是8/ 第3張12 第4張是7
                        num = 19 - threeNum;
                        // 手牌中 是第四張牌的點數有幾個
                        handNumCount = cardArray.filter(cur => cur.getCardNumberSum() === num).length;
                    } else {
                        // 第三張是7~9
                        // 第3張9 第4張是0 or 10/ 第3張8 第4張是1 or 11/ 第3張7 第4張是2 or 12
                        num = 9 - threeNum;
                        var num2 = 19 - threeNum;
                        // 手牌中 是第四張牌的點數有幾個
                        handNumCount = cardArray.filter(cur => cur.getCardNumberSum() === num || cur.getCardNumberSum() === num2).length;
                    }

                    // 算機率 第四張牌為9的機率
                    cardHint = (this.CARD_NUMBER_99_COUNT[threeNum] - handNumCount) / denominator;

                    cardTypeStr = "99 Cards ";
                    break;

                default:
                    cardHint = 0;
                    break;
            }

            cardHint = cardHint * 100;

            // 同組牌會有不同的牌型需要判斷 ex. 總和9的時候要判斷 smallcard ＆ 99 兩種牌型
            if (cardHintType === DOMINO_CARD_TYPE.NORMAL && cardHint === 0 || cardHintType !== DOMINO_CARD_TYPE.NORMAL && cardHint > 0)
                return {hint: cardHint, str: cardTypeStr};
            else {
                this._checkHintArray.push(cardHintType);
                return getCardHint(cardHintType, true);
            }
        };

        this._checkHintArray = [];
        var cardHint = getCardHint(DOMINO_CARD_TYPE.NORMAL);

        this._cardHintNode.setVisible(cardHint.hint > 0);
        this._cardHintLabel.setString(LocalizedString.Game(cardHint.str + Math.floor(cardHint.hint) + "%"));
    },

    /**
     * 是否打開切換牌的功能
     */
    setChangeCardEnable: function (isEnable) {
        if (isEnable) {
            // 要打開
            if (this._changeCardNode) {
                this._changeCardNode.setVisible(true);
                return;
            }

            var changeNode = this._changeCardNode = new cc.Node();
            changeNode.setCascadeOpacityEnabled(true);
            changeNode.setVisible(false);           // 預設是關的 等有分數才會出現
            this.addChild(changeNode, 5);

            // 創一個假按鈕
            var itemNodes = ButtonUtility.createEmptyNodes(cc.size(80, 38));
            var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._changeCardClicked, this);
            var menu = new cc.Menu(menuItem);
            menu.setPosition(0, 0);
            changeNode.addChild(menu, 1);

            // 加提示文字
            var bgSprite = new cc.Sprite("#lobby_pic_black.png");
            bgSprite.setScale(2.1);
            bgSprite.setPosition(0, -28);
            changeNode.addChild(bgSprite);

            var hintLabel = new cc.LabelTTF(LocalizedString.Game("點擊牌可以切換順序"), JSFontName, 7);
            hintLabel.setPosition(0, -28);
            changeNode.addChild(hintLabel, 1);
        } else {
            // 要關掉
            this._changeCardNode && this._changeCardNode.setVisible(false);
        }
    },

    /**
     * 抓取現在牌的順序 回傳JSON Array
     */
    getCardOrder: function () {
        var jsonArray = [];
        this.cardArray.forEach(function (cur) {
            jsonArray.push(cur.index);
        });

        return JSON.stringify(jsonArray);
    },

    /**
     * 設定結算的手牌 怕決定時間比Server慢
     * @param value ["12","33","36","00"] JSON Object
     */
    setFinishCard: function (value) {
        // 重新排序
        var self = this;
        var nextCardArray = [];
        value.forEach((cardNumber, index) => {
            // 要找到對應的牌
            for (var i = 0, len = self.cardArray.length; i < len; i++) {
                var card = self.cardArray[i];
                if (card.cardNumber == cardNumber) {
                    // 找到 換位置
                    self._runCardMoveAction(card, this.CARD_SET_CARD_POS[index]);

                    nextCardArray.push(card);
                    break;
                }
            }
        });

        // 最後把原本cardArray的順序做正確的排序
        this.cardArray = [].concat(nextCardArray);

        // 重新更新分數
        this._updateScore();

        // 把Touch拿掉 要在更新分數下面 因為更新分數會把Touch的文字打開
        this.setChangeCardEnable(false);
    },

    /**
     * 用來判斷上面的數字
     */
    _updateScore: function () {
        var nowCardLength = this.cardArray.length;
        if (nowCardLength < 2)
            return;

        var cardArray = this.cardArray;
        var cardCountArray = [];
        cardArray.forEach(cur => cardCountArray.push(cur.getCardCount()));

        // 前面兩張的分數
        var count1 = (cardCountArray[0] + cardCountArray[1]) % 10;
        this._scoreLabelArray[0].setString(count1.toString());
        this._scoreLabelArray[0].setFontFillColor(this._scoreLabelColor[count1 === 9 ? 0 : 1]);

        // 後面的分數
        if (nowCardLength < 4) {
            // 沒有分數可以算
            this._scoreLabelArray[1].setString("?");
            this._scoreLabelArray[1].setFontFillColor(this._scoreLabelColor[1]);
        } else {
            // 代表有分數可以算
            var count2 = (cardCountArray[2] + cardCountArray[3]) % 10;
            this._scoreLabelArray[1].setString(count2.toString());
            this._scoreLabelArray[1].setFontFillColor(this._scoreLabelColor[count2 === 9 ? 0 : 1]);
        }

        // 判斷分數要不要存在還是用美術圖
        var specialType = DOMINO_CARD_TYPE.NORMAL;
        var specialFrameName = null;
        while (nowCardLength === 4) {
            // 4張才需要算 先把分數全部抓出來 是要算各個點數的 不是算Count
            var totalCardSum = 0;
            cardArray.forEach(cur => totalCardSum += cur.getCardNumberSum());

            // QQ 左右兩組皆為9
            if (count1 === 9 && count2 === 9) {
                specialFrameName = "game_animate_qiuqiu.png";
                specialType = DOMINO_CARD_TYPE.QQ;
                break;
            }

            // BIG 4張牌總分超過39分 0對子卡可當作10分
            var bigSum = totalCardSum;
            for (var i = 0; i < 4; i++) {
                var card = cardArray[i];
                if (card.isCoupleNumber() && card.getCardNumberSum() === 0) {
                    // 0對的 把他+10分
                    bigSum += 10;
                }
            }
            if (bigSum >= 39) {
                specialFrameName = "game_animate_big.png";
                specialType = DOMINO_CARD_TYPE.BIG;
                break;
            }

            // SMALL 4張牌總分少於9
            if (totalCardSum <= 9) {
                specialFrameName = "game_animate_small.png";
                specialType = DOMINO_CARD_TYPE.SMALL;
                break;
            }

            // Twin 4張牌都是對子
            var allCouple = true;
            for (var i = 0; i < 4; i++) {
                var card = cardArray[i];
                if (!card.isCoupleNumber()) {
                    allCouple = false;
                    break;
                }
            }
            if (allCouple) {
                specialFrameName = "game_animate_twin.png";
                specialType = DOMINO_CARD_TYPE.TWIN;
                break;
            }

            // Six Devils 4張牌都是點數6
            if (cardCountArray.every(cur => cur === 6)) {
                specialFrameName = "game_animate_sixdevils.png";
                specialType = DOMINO_CARD_TYPE.SIX_DEVILS;
                break;
            }

            // 跑到最後 break掉
            break;
        }

        this._specialNode.removeAllChildren();
        this._specialNode.setVisible(specialFrameName !== null);
        if (specialFrameName) {
            // 創光芒
            var lightSprite = new cc.Sprite("#lobby_pic_simple_alert.png");
            lightSprite.setScale(2);
            lightSprite.runAction(cc.repeatForever(cc.rotateBy(2, 90)));
            this._specialNode.addChild(lightSprite);

            // 文字
            var specialSprite = new cc.Sprite("#" + specialFrameName);
            this._specialNode.addChild(specialSprite);
        }
        this._scoreNode.setVisible(specialFrameName === null);

        // 判斷要不要出現可以換手牌的提示
        this._changeCardNode && this._changeCardNode.setVisible(nowCardLength >= 3);

        // 第三張牌的時候顯示牌型提示 第四張牌時要關掉
        this._showCardHint(nowCardLength === 3);
    },

    /**
     * 切換排的順序
     */
    _changeCardClicked: function () {
        // 假如沒出現文字 不能讓他跑下來 主要是怕使用者按住按鈕 放開的時後又打開此功能
        if (this._changeCardNode && !this._changeCardNode.isVisible())
            return;

        // 3張才需要換牌
        var nowCardLength = this.cardArray.length;
        if (nowCardLength < 3)
            return;

        // 先組成現在的排序
        var nowSortNumber = 0;
        for (var i = 0; i < nowCardLength; i++) {
            nowSortNumber *= 10;
            nowSortNumber += this.cardArray[i].index;
        }

        // 抓出排序的Array
        var sortArray = this.CARD_SET_CARD_SORT[nowCardLength];
        var sortLen = sortArray.length;

        // 算出現在是在哪一個排序
        var sortIndex = 0;
        for (var i = 0; i < sortLen; i++) {
            if (sortArray[i] === nowSortNumber) {
                sortIndex = i;
                break;
            }
        }

        // 把排序往下一個走到可以左邊大於右邊的數字 4張排在檢查
        var originalIndex = sortIndex;
        sortIndex = (sortIndex + 1) % sortLen;
        if (nowCardLength === 4) {
            // 先創一個原本照1 2 3 4排序的牌組
            var tmpCardArray = [];
            for (var i = 0; i < 4; i++) {
                var thisCard = this.cardArray[i];
                tmpCardArray[thisCard.index - 1] = thisCard;
            }

            while (1) {
                if (sortIndex === originalIndex) {
                    // 找不到可以解的
                    return;
                }
                // 判斷此組合可不可以
                var thisSortNumber = sortArray[sortIndex].toString();
                var countArray = [0, 0];
                for (var i = 0; i < thisSortNumber.length; i++) {
                    countArray[i < 2 ? 0 : 1] += tmpCardArray[parseInt(thisSortNumber[i]) - 1].getCardCount();
                }
                if ((countArray[0] % 10) >= (countArray[1] % 10)) {
                    // 代表此個有解 跳掉
                    break;
                }

                // 這組不行解
                sortIndex = (sortIndex + 1) % sortLen;
            }
        }

        // 抓出該有的排序
        var nextSortNumber = sortArray[sortIndex];

        // 排序
        var nextSortNumberArray = ("" + nextSortNumber).split("");
        var nextSortNumberArrayLen = nextSortNumberArray.length;
        var nextCardArray = [];
        var self = this;
        this.cardArray.forEach(cur => {
            var toIndex;
            for (var i = 0; i < nextSortNumberArrayLen; i++) {
                if (cur.index.toString() === nextSortNumberArray[i]) {
                    toIndex = i;
                    break;
                }
            }

            // 移動到目的地
            self._runCardMoveAction(cur, this.CARD_SET_CARD_POS[toIndex]);

            // 把他放在新的Array裡
            nextCardArray[toIndex] = cur;
        });

        // 最後把原本cardArray的順序做正確的排序
        this.cardArray = [].concat(nextCardArray);

        // 最後更新一下分數
        this._updateScore();
    },

    /**
     * 移動牌的Action 統一這邊做
     */
    _runCardMoveAction: function (card, pos) {
        // 移動到目的地 要設tag 拿掉action不能直接stopAll 不然可能回連同翻牌的action一起取消掉
        var moveAction = cc.moveTo(0.2, pos);
        moveAction.setTag(5478);
        card.stopActionByTag(5478);
        card.runAction(moveAction);
    },

    /**
     * Server幫運算的最佳手牌 要強制幫他換掉
     */
    cmd_BestCard: function (value) {
        // BestCard {“leftScore”:“8”,”leftCards”:[“24”,”11”],”success”:1,”cardsOrder”:[1,2,3,4],”rightScore”:“0”,”rightCards”:[“55”,”46”]} 此時最好牌型
        var jsonValue = JSON.parse(value);
        var cardsOrder = jsonValue["cardsOrder"];
        if (!cardsOrder)
            return;

        // 把他移動到Server算的order
        var nowCardLength = this.cardArray.length;
        var nextCardArray = [];
        var self = this;
        cardsOrder.forEach((cur, index) => {
            var order = parseInt(cur);

            for (var i = 0; i < nowCardLength; i++) {
                var card = self.cardArray[i];
                if (card.index === order) {
                    // 移動到目的地
                    self._runCardMoveAction(card, this.CARD_SET_CARD_POS[index]);

                    // 把他加到新的Array
                    nextCardArray.push(card);
                    break;
                }
            }
        });

        // 最後把原本cardArray的順序做正確的排序
        if (nextCardArray.length === this.cardArray.length)
            this.cardArray = [].concat(nextCardArray);
        else {
            // 例外處理
            this.cardArray.forEach((cur, index) => {
                // 回原本位置
                self._runCardMoveAction(cur, this.CARD_SET_CARD_POS[index]);
            });
        }

        // 最後更新一下分數
        this._updateScore();
    },
});