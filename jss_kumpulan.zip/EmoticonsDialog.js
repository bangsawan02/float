var EmoticonsDialog = BaseDialogLayer.extend({
    ctor: function (openPos) {
        this._super();

        this.setCascadeOpacityEnabled(true);

        // 設定Dialog Key
        this.key = "EmoticonsDialog";

        this.dialogBgColor = cc.color(255, 255, 255, 0);

        openPos && this.setOpenWorldPosition(openPos);

        // 跳出的視窗
        var aniLayer = this._animationLayer;

        // 放東西的node(順便對位)
        var mainNode = this._mainNode = new cc.Node();
        mainNode.setPosition(JSScreenSafeWidth, 0);
        aniLayer.addChild(mainNode);

        // 背景底
        var bgSprite = this._bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(cc.size(219, 215));
        bgSprite.setAnchorPoint(0, 0);
        bgSprite.setPosition(-2, 26);
        mainNode.addChild(bgSprite, -1);

        // 黑底
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_list_04.png");
        bgSprite.setAnchorPoint(0, 0);
        bgSprite.setPreferredSize(cc.size(206, 163));
        bgSprite.setPosition(4, 43);
        mainNode.addChild(bgSprite);

        // 上方光暈
        var bgTopLightSprite = new cc.Sprite("#lobby_pic_light_gold.png");
        bgTopLightSprite.setScale(0.7, 0.4);
        bgTopLightSprite.setPosition(109, 208);
        mainNode.addChild(bgTopLightSprite);

        // 下方光暈
        var bgLightSprite = new cc.Sprite("#lobby_pic_light_gold.png");
        bgLightSprite.setAnchorPoint(0.5, 1);
        bgLightSprite.setScale(0.7, 0.4);
        bgLightSprite.setFlippedY(true);
        bgLightSprite.setPosition(109, 43);
        mainNode.addChild(bgLightSprite);

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
        closeBtn.setPosition(212, 238);
        mainNode.addChild(closeBtn);

        // Menu
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        mainNode.addChild(menu);

        var gameString = LocalizedString.Game;
        this._tabItems = [];
        var tabTitles = [gameString("互動道具"), gameString("表情")];
        var tabTitleLen = tabTitles.length;
        var btnImages = ["lobby_btn_tab_02.png", "lobby_btn_tab_02.png", "lobby_btn_tab_01.png"];
        var btnSize = cc.size(94, 24);
        var posX = 10;
        var posY = 217;
        var offsetX = btnSize.width + 2;
        for (var i = 0; i < tabTitleLen; i++) {
            var itemNode = ButtonUtility.createArrayScale9Nodes(btnImages, btnSize, tabTitles[i], 10, JSColor.WHITE);
            // 重新設定顏色
            itemNode[0].setOpacity(150);
            itemNode[2].setColor(JSColor.WHITE);
            itemNode[2].setOpacity(255);

            var menuItem = this._tabItems[i] = new cc.MenuItemSprite(itemNode[0], itemNode[1], itemNode[2], this._tabClicked, this);
            menuItem.setAnchorPoint(0, 0.5);
            menu.addChild(menuItem);

            // 先關起來
            if (GS.nowGame === GSEnum.Game.TebakQQ && i === 0) {
                menuItem.setVisible(false);
                menuItem.setEnabled(false);
            }
        }

        // 重新排位置
        for (var i = 0; i < 2; i++) {
            var menuItem = this._tabItems[i];
            if (menuItem.isVisible()) {
                menuItem.setPosition(posX, posY);

                posX += offsetX;
            }
        }

        // 跳出畫面 這個要在前面 因為之後才會統一加主畫面 要對位
        this._startDialogAnimation();

        // 主頁面
        this._pageArray = [];

        // 預設按鈕
        this._tabClicked(this._tabItems[1]);

        // 加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this.onTouchBegan.bind(this)
        }, this);

        // 註冊
        GS.addListener("NotifyCloseEmoticons", this.notifyCloseEmoticons.bind(this), this);
    },

    /**
     * 按鈕
     */
    // 按到Tab
    _tabClicked: function (sender) {
        var clickedPos = 0;

        this._tabItems.forEach((cur, index) => {
            if (sender === cur) {
                // 記下點到哪個按鈕
                clickedPos = index;

                cur.setEnabled(false);
            } else {
                cur.setEnabled(true);
            }
        });

        // 關掉其他頁面
        var pageArray = this._pageArray;
        pageArray.forEach(cur => cur.setVisible(false));

        var page = pageArray[clickedPos];
        if (!page) {
            switch (clickedPos) {
                case 0:     // 互動道具
                    page = pageArray[clickedPos] = new ActMoodsScrollLayer(ActMoodsType.NORMAL_GAME);
                    break;
                case 1:     // 表情
                    page = pageArray[clickedPos] = new EmoticonsScrollLayer();
                    break;
            }
            this._mainNode.addChild(page, 3);
        } else
            page.setVisible(true);
    },

    // 按到關閉
    _closeBtnClicked: function () {
        this._closeDialogAnimation();
        this._openAnimationDone = false;
    },

    /**
     * 通知
     */
    // 要關掉畫面
    notifyCloseEmoticons: function () {
        this._closeDialogAnimation();
    },

    /**
     * Touch
     */
    onTouchBegan: function (touch, event) {
        if (!this._openAnimationDone)
            // 畫面還沒打開完成不處理
            return;

        var target = event.getCurrentTarget();
        if (!target.isVisible())
            return false;
        for (var c = target.parent; c != null; c = c.parent) {
            if (!c.isVisible())
                return false;
        }

        var boundBox = this._bgSprite.getBoundingBox();
        var touchPos = this.convertToNodeSpace(touch.getLocation());

        if (!cc.rectContainsPoint(boundBox, touchPos)) {
            this._closeDialogAnimation();
            this._openAnimationDone = false;
            return false;
        }
        return true;
    }
});
