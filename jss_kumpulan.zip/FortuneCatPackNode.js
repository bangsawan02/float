/**
 * 5.3.7 衝動儲值_招財貓駕到 Node
 *
 * param                    禮包資訊
 * closeDialogCallBack      按下關閉或成功畫面的確定要執行的callBack
 */
var FortuneCatPackNode = PurchasePackBaseNode.extend({
    ctor: function (param, closeDialogCallBack) {
        // 先做繼承的東西
        this._super(param, closeDialogCallBack);

        // 內容Node
        var contentNode = this._contentNode = new cc.Node();
        contentNode.setPosition(JSScreenMidPos);
        this.addChild(contentNode, 1);

        var fortuneCat = LocalizedString.fortuneCat;

        // ----底圖區----
        {
            // 背景
            var bg = new ccui.Scale9Sprite("pp_fortunecat_bg.png");
            bg.setPosition(0, -17);
            bg.setPreferredSize(cc.size(291.5, 154));
            contentNode.addChild(bg);

            // 標題
            var title = new cc.Sprite("#pp_fortunecat_word_title.png");
            title.setPosition(0, 93);
            contentNode.addChild(title);

            // 副標題背景
            var light = new cc.Sprite("#pp_fortunecat_bg_yellowlight002.png");
            light.setPosition(-1, 56);
            light.setScale(25, 2.5);
            contentNode.addChild(light);

            // 副標題
            var subtitle = new cc.Sprite("#pp_fortunecat_word_subtitle_01.png");
            subtitle.setPosition(-1, 56);
            contentNode.addChild(subtitle);
        }

        //----content 內容區----
        {
            // 金幣堆
            var posX = [-161, 161];
            posX.forEach(cur => {
                var coin = new cc.Sprite("#pp_fortunecat_pic_money_01.png");
                coin.setPosition(cur, -74);
                contentNode.addChild(coin);
            });

            // 貓
            var cat = new cc.Sprite("#pp_fortunecat_pic_cat.png");
            cat.setPosition(-179, -36);
            contentNode.addChild(cat);

            // 硬幣袋
            var bag = new cc.Sprite("#pp_fortunecat_pic_chips-bag.png");
            bag.setPosition(-83, -2);
            contentNode.addChild(bag);

            // 標籤背景
            var labelSprite = new cc.Sprite("#pp_fortunecat_pic_label.png");
            labelSprite.setScale(0.9);
            labelSprite.setPosition(-105, -32);
            contentNode.addChild(labelSprite);

            // 標籤文字
            var percentLabel = new cc.LabelTTF(JSStringUtility.format(fortuneCat("%d%%\n優惠"), param.bonus), JSFontName, 11);
            percentLabel.setPosition(-105, -32);
            percentLabel.setFontFillColor(JSColor.BLACK);
            percentLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            contentNode.addChild(percentLabel);

            // 金幣掉落動畫
            this._runCoinAnim();

            // 右邊
            {
                // 使用的文字
                var hintLabel = new cc.LabelTTF(JSStringUtility.format(fortuneCat("使用%d%%加贈券獲得"), param.couponBonus), JSFontBoldName, 12);
                hintLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                hintLabel.setPosition(44, 3);
                contentNode.addChild(hintLabel);

                // 數字
                var moneyLabel = new GSAutoSizeLabel(JSStringUtility.format("%s %s", JSCodeUtility.getCurrencyString(param.money), LocalizedString.Common("德撲幣")), JSFontBoldName, 14, cc.size(180, 16));
                moneyLabel.setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
                moneyLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                moneyLabel.setFontFillColor(JSColor.YELLOW);
                moneyLabel.setPosition(44, -22);
                contentNode.addChild(moneyLabel);
            }

            // 倒數
            {
                // 倒數背景
                var marqueeBgNode = new ccui.Scale9Sprite("marquee_bg.png");
                marqueeBgNode.setPreferredSize(cc.size(90, 15));
                marqueeBgNode.setPosition(0, -58);
                contentNode.addChild(marqueeBgNode);

                var timeNode = new GSAutoLayoutNode();
                timeNode.setPosition(0, -58);
                timeNode.setSpace(5);
                contentNode.addChild(timeNode, 1);

                // 時鐘icon
                var clockSprite = new cc.Sprite("#lobby_pic_clock_02.png");
                clockSprite.setScale(0.5);
                timeNode.addChild(clockSprite);

                // 加贈券期限
                var timeLabel = new GSTimeLabel("", JSFontBoldName, 11);
                timeLabel.setMultiFormat("%hh:%mm:%ss", "%hh:%mm:%ss", "%hh:%mm:%ss");
                timeLabel.countdownSeconds(JSCodeUtility.getRemainTime(param.countDownTime, param.socketTime), () => this.closePurchasePackDialog());
                timeNode.addChild(timeLabel, 1);
            }

            // 右上叉叉按鈕
            var menu = new cc.Menu();
            menu.setPosition(0, 0);
            contentNode.addChild(menu);

            this._addCloseButton(cc.p(140, 56), menu);

            // 左上說明按鈕
            var explainButton = ButtonUtility.createSimpleImageButton("lobby_btn_circle_03.png", null, "#lobby_btn_pic_window_?.png");
            explainButton.setScale(0.8);
            explainButton.setPosition(-128, 43);
            explainButton.addTouchUpInsideAction(this._infoBtnClicked, this);
            contentNode.addChild(explainButton);

            // 購買按鈕
            // 創標籤
            var createPriceButtonSprite = function (originStr, discountStr) {
                // 背景
                var bgSp = new cc.Scale9Sprite("pp_fortunecat_BT_01.png");
                bgSp.setPreferredSize(cc.size(136, 53));

                // 原價標籤
                var originLabel = new cc.LabelTTF(JSStringUtility.format("IDR %s", originStr), JSFontName, 13);
                originLabel.setFontFillColor(JSColor.BLACK);
                originLabel.setPosition(68, 38);
                bgSp.addChild(originLabel);

                var lineWidth = originLabel.getContentSize().width;

                // 刪除線
                var line = new cc.LayerColor(JSColor.RED, lineWidth, 1);
                line.setCascadeColorEnabled(true);
                line.setPosition(68 - lineWidth / 2, 38);
                bgSp.addChild(line);

                // 折扣後金額
                var discountLabel = bgSp.discountLabel = new cc.LabelTTF(JSStringUtility.format("IDR %s", discountStr), JSFontName, 16);
                discountLabel.setPosition(68, 20);
                bgSp.addChild(discountLabel);

                return bgSp;
            };

            var normalSp = createPriceButtonSprite(JSCodeUtility.getCurrencyString(param.originPrice), JSCodeUtility.getCurrencyString(param.price));
            var button = new GSControlButton(normalSp);
            button.addTouchUpInsideAction(this._purchaseClicked, this);
            button.setPosition(0, -96);
            contentNode.addChild(button, 4);
        }
    },

    onExit: function () {

        // // 關掉小dialog
        // var littleDialog = DialogManager.getDialogByKey("FortuneCatPackCloseDialog") || DialogManager.getDialogByKey("FortuneCatPackResultDialog");
        // littleDialog && littleDialog.removeFromParent();

        this._super();
    },

    // 金幣掉落動畫
    _runCoinAnim: function () {
        var posX = [-220, -195, -177, -148, -140, 140, 148, 177, 195, 220];
        var coinImg = [2, 3, 2, 2, 3, 2, 3, 2, 2, 3];
        var delayTime = [0.2, 0.5, 0.2, 0, 0.1, 0, 0.2, 0.3, 0.2, 0.4];
        var rotation = [700, 400, 500, 400, 500, 600, 400, 700, 500, 400];
        var animTime = [0.8, 1, 0.6, 0.8, 0.6, 0.5, 0.7, 0.8, 0.6, 0.8];

        posX.forEach((cur, idx) => {
            var coin = new cc.Sprite(JSStringUtility.format("#pp_fortunecat_pic_money_%02d.png", coinImg[idx]));
            this._contentNode.addChild(coin, -1);

            coin.runAction(cc.repeatForever(cc.sequence(
                cc.moveTo(0, cur, JSVisibleSize.height / 2 + 20),
                cc.fadeIn(0),
                cc.delayTime(delayTime[idx]),
                cc.spawn(
                    cc.rotateBy(animTime[idx], rotation[idx]),
                    cc.moveTo(animTime[idx], cur, -80),
                    cc.fadeOut(animTime[idx]).easing(cc.easeIn(5))
                )
            )));
        });
    },

    /**
     * 儲值成功
     */
    purchaseSuccess: function () {
        this._super();

        // 把自己關掉
        this.closePurchasePackDialog();
    },

    /**
     * 按下儲值按鈕
     */
    _purchaseClicked: function () {
        this._super();

        // C->S track_fortune_cat {"type":"1","coupon_bonus":"10","button":"120"}
        // > type:1 點擊儲值按鈕
        // > coupon_bonus:info送的coupon_bonus
        // > button: 購買價格
        // // 埋點
        var param = {type: this._param.couponType, coupon_bonus: this._param.couponBonus, button: this._param.price};
        DataProcess.sendString("track_fortune_cat " + JSON.stringify(param));

        DataModal.purchaseData.goPurchase(this._param.productParam);
    },

    /**
     * 關閉按鈕事件
     * @override
     */
    _closeBtnClicked: function () {
        // 跳提醒dialog
        DialogManager.addDialog(new FortuneCatPackCloseDialog(index => {
            // 關閉
            if (index === 0) {
                this.closePurchasePackDialog();
            }
        }), false);
    },

    /**
     * 點擊說明按鈕
     */
    _infoBtnClicked: function () {
        var url = TexasUtility.getSimpleInfoURLByKey("fortune_cat");
        DialogManager.addDialog(new WebViewDialog(url, "", undefined, false, GSEnum.DialogSize.MIDDLE), false);
    }
});