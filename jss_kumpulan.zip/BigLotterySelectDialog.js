/**
 * 9T 幸運彩票選號dialog
 */
var BigLotterySelectDialog = BaseDialogLayer.extend({
    ctor: function () {
        this._super();

        this.key = "BigLotterySelectDialog";
        this._isWaitingCmd = false; // 等待server回覆(如果一直沒有收到server回覆，玩家還是可以點關閉按鈕關掉畫面，然後重要資料)
        this._selectArray = [];     // 選到的數字

        var animLayer = this._animationLayer;

        // 抓資料
        var bigLotteryData = DataModal.bigLotteryData;
        var myTicketParam = bigLotteryData.myTicketParam;
        var bigLotteryStr = LocalizedString.BigLottery;

        // 背景光
        var bgLightSprite = new cc.Sprite("#bigLottery_bg_titleLight.png");
        bgLightSprite.setScale(4, 3);
        bgLightSprite.setFlippedY(true);
        bgLightSprite.setAnchorPoint(0.5, 0);
        bgLightSprite.setPositionX(JSScreenMidPos.x);
        animLayer.addChild(bgLightSprite);

        // 背景
        var bgSprite = new ccui.Scale9Sprite("bigLottery_bg_ticket.png");
        bgSprite.setPreferredSize(cc.size(321, 280));
        bgSprite.setPosition(JSScreenMidPos);
        animLayer.addChild(bgSprite);

        // 期號
        var periodLabel = new cc.LabelTTF(bigLotteryData.period, JSFontName, 12);
        periodLabel.setFontFillColor(JSColor.BLACK);
        periodLabel.setPosition(151 + JSScreenBonusHalfWidth, 263 + JSScreenBonusHalfHeight);
        animLayer.addChild(periodLabel);

        // 標題
        {
            // 排版的node
            var titleNode = new GSAutoLayoutNode();
            titleNode.setPosition(JSScreenMidPos.x, 263 + JSScreenBonusHalfHeight);
            animLayer.addChild(titleNode);

            // Domino移植設定 第幾張彩券合為一張圖
            // 標題:第幾張彩券
            var titleSprite = new cc.Sprite("#bigLottery_word_num.png");
            titleNode.addChild(titleSprite);

            // 數量
            titleSprite = new GSSpriteNumberNode({
                number: myTicketParam.currentTicketCount,
                numStr: "#bigLottery_word_",
                spW: 10
            });
            titleNode.addChild(titleSprite);
        }

        // 文字: 請選5個號碼
        var selectLabel = new cc.LabelTTF(bigLotteryStr("請選5個號碼:"), JSFontName, 14);
        selectLabel.setPosition(JSScreenMidPos.x, 242 + JSScreenBonusHalfHeight);
        animLayer.addChild(selectLabel);

        // Domino移植設定 調寬背景
        // 白色背景
        var whiteBgSprite = new ccui.Scale9Sprite("bigLottery_bg_ticket_white.png");
        whiteBgSprite.setPreferredSize(cc.size(300, 180));
        whiteBgSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 4);
        animLayer.addChild(whiteBgSprite);

        // 按鈕
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        animLayer.addChild(menu);

        // Domino移植設定 調整位移/六個號碼一排
        // 選號按鈕
        this._selectBtn = [];
        var pos = cc.p(129 + JSScreenBonusHalfWidth, 211 + JSScreenBonusHalfHeight);
        for (var i = 0; i < 5; i++) {
            for (var j = 0; j < 6; j++) {
                var toggleItems = [];
                for (var k = 0; k < 2; k++) {
                    var btnSize = cc.size(40, 30);
                    var itemNode = [];
                    for (var l = 0; l < 3; l++) {
                        var node = itemNode[l] = new cc.Node();
                        node.setContentSize(btnSize);
                        node.setCascadeColorEnabled(true);

                        // 背景
                        var bgSprite = new ccui.Scale9Sprite((k === 1) ? "bigLottery_pic_ticketSelected.png" : "bigLottery_pic_ticketNormal.png");
                        bgSprite.setPreferredSize(btnSize);
                        bgSprite.setPosition(btnSize.width / 2, btnSize.height / 2);
                        node.addChild(bgSprite);

                        // 數字
                        var numNode = new GSSpriteNumberNode({
                            number: i * 6 + j + 1,
                            numStr: "#bigLottery_word_ticket_",
                            spW: 10
                        });
                        numNode.setPosition(bgSprite.getPosition());
                        node.addChild(numNode);
                    }
                    itemNode[1].setColor(JSColor.GRAY);
                    toggleItems[k] = new cc.MenuItemSprite(itemNode[0], itemNode[1], itemNode[2]);
                }
                var selectBtn = this._selectBtn[i * 6 + j] = new cc.MenuItemToggle(toggleItems[0], toggleItems[1], this._selectClicked, this);
                selectBtn.num = i * 6 + j + 1;
                selectBtn.setPosition(cc.pAdd(pos, cc.p(j * 51, i * -34)));
                menu.addChild(selectBtn);
            }
        }

        // Domino移植設定 調整位移
        // 清除按鈕
        var itemNode = ButtonUtility.createBtnLabelWithUnderLine(bigLotteryStr("清除已選數字"), 11, cc.color(50, 50, 50, 255));
        var cleanBtn = new cc.MenuItemSprite(itemNode[0], itemNode[1], itemNode[2], this._cleanBtnClicked, this);
        cleanBtn.setPosition(158 + JSScreenBonusHalfWidth, 30 + JSScreenBonusHalfHeight);
        menu.addChild(cleanBtn);

        // Domino移植設定 客製畫面
        // 確認選號按鈕
        var fontColors = [cc.color(0, 35, 90, 255), cc.color(0, 35, 90, 255), cc.color(45, 45, 45, 255)];
        itemNode = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", cc.size(90, 34), bigLotteryStr("確定選號"), 14);
        itemNode.forEach((cur, index) => cur.label.enableStroke(fontColors[index], 2));
        itemNode[2].setColor(JSColor.GRAY);
        itemNode[2].setOpacity(255);
        var confirmBtn = this._confirmBtn = new cc.MenuItemSprite(itemNode[0], itemNode[1], itemNode[2], this._confirmClicked, this);
        confirmBtn.setEnabled(false);
        confirmBtn.setPosition(JSScreenMidPos.x, 30 + JSScreenBonusHalfHeight);
        menu.addChild(confirmBtn);

        // Domino移植設定 調整位移
        // 關閉按鈕
        var closeBtnNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_circle_04.png", null, "#lobby_btn_pic_window_x.png");
        var closeBtn = new cc.MenuItemSprite(closeBtnNodes[0], closeBtnNodes[1], closeBtnNodes[2], this._closeButtonClicked, this);
        closeBtn.setPosition(392 + JSScreenBonusHalfWidth, 260 + JSScreenBonusHalfHeight);
        menu.addChild(closeBtn);

        // 倒數背景
        var countdownBgSprite = new ccui.Scale9Sprite("bigLottery_bg_redLine02.png");
        countdownBgSprite.setPreferredSize(cc.size(100, 32));
        countdownBgSprite.setPosition(353 + JSScreenBonusHalfWidth, 30 + JSScreenBonusHalfHeight);
        animLayer.addChild(countdownBgSprite);

        // Domino移植設定 調整描邊
        // 文字: 自行選號剩餘時間
        var hintLabel = new cc.LabelTTF(bigLotteryStr("選號剩餘時間: "), JSFontName, 10);
        hintLabel.setPosition(356 + JSScreenBonusHalfWidth, 28 + JSScreenBonusHalfHeight);
        hintLabel.enableStroke(cc.hexToColor("#B34025"), 2);
        animLayer.addChild(hintLabel);

        // 倒數時間
        var timeLabel = new GSTimeLabel("", JSFontBoldName, 8);
        timeLabel.setFontFillColor(JSColor.YELLOW);
        timeLabel.setMultiFormat("%ddD:%hhH:%mmM", "%hhH:%mmM:%ssS", "%mmM:%ssS");
        timeLabel.setPosition(368 + JSScreenBonusHalfWidth, 23 + JSScreenBonusHalfHeight);
        timeLabel.countdownSeconds(bigLotteryData.getSelectTime()); // callback移到BigLotteryLayer refreshView統一做掉
        animLayer.addChild(timeLabel, 1);

        // 通知
        GS.addListener("NotifyBigLotterySelectResult", this.notifyBigLotterySelectResult.bind(this), this);
        GS.addListener("NotifyBigLotterySelectDialogClose", this.notifyBigLotterySelectDialogClose.bind(this), this);
    },

    /**
     * Android Back Key
     * @override
     */
    keyBackPressed: function () {
        this._closeButtonClicked();
    },

    /**
     * 按鈕
     */
    // 關閉
    _closeButtonClicked: function () {
        MusicUtility.playEffect("Music/Effect/e_clickButton.mp3", false);

        var myTicketParam = DataModal.bigLotteryData.myTicketParam;
        var bigLotteryStr = LocalizedString.BigLottery;

        // 還有票還沒選號
        if (myTicketParam && myTicketParam.notSelectTicketNum && !this._isWaitingCmd) {
            // 跳dialog
            var param = {
                key: "BigLotteryCommonDialog",
                bgSize: cc.size(380, 170), // Domino移植設定 拉寬size
                btnImages: ["lobby_btn_01.png", "lobby_btn_06.png"],
                titleImg: "#bigLottery_word_dontMiss.png",
                content: bigLotteryStr("您尚未完成選號，\n離開後可再至『我的彩票』\n進行選號"),
                buttons: ["繼續選號", "先離開"].map(string => bigLotteryStr(string)),
                callback: (index) => {
                    if (index === 1) {
                        // 通知關掉選號dialog
                        GS.dispatchCustomEvent("NotifyBigLotterySelectDialogClose");

                        // 重要資料
                        DataProcess.sendString("big_lottery_my_ticket");
                    }
                }
            };
            DialogManager.addDialog(new BigLotteryCommonDialog(param), false);
        } else {
            // 重要資料
            DataProcess.sendString("big_lottery_my_ticket");

            // 關掉dialog
            this._closeDialogAnimation();
        }
    },

    // 清除按鈕
    _cleanBtnClicked: function () {
        MusicUtility.playEffect("Music/Effect/e_clickButton.mp3", false);

        var selectArray = this._selectArray;

        // 把按鈕都回原本狀態
        selectArray.forEach(cur => {
            cur.setSelectedIndex(0);
        });

        // 清掉已選的記錄
        this._selectArray = [];

        // 鎖住確認按鈕
        this._confirmBtn.setEnabled(false);
    },

    // 點擊選號按鈕
    _selectClicked: function (sender) {
        var selectArray = this._selectArray;

        // 數字是不是選過了
        var index = selectArray.findIndex(cur => cur === sender);
        var isSelectBefore = index !== -1;
        if (isSelectBefore) {
            selectArray.splice(index, 1);
        } else {
            // 已經選5個不能再選
            if (selectArray.length === 5) {
                // 把按鈕調回來
                sender.setSelectedIndex(0);

                // 跳dialog
                var param = {
                    key: "BigLotteryCommonDialog",
                    bgSize: cc.size(380, 170), // Domino移植設定 拉寬size
                    titleImg: "#bigLottery_word_outofRange.png",
                    content: LocalizedString.BigLottery("每張彩票只能選5個號碼，\n若想要換別的號碼，\n請先取消您已選的某一數字"),
                    buttons: ["OK"]
                };
                DialogManager.addDialog(new BigLotteryCommonDialog(param), false);

                return;
            }
            selectArray.push(sender);
        }

        // 選5個了，打開確認按鈕
        var confirmBtn = this._confirmBtn;
        if (selectArray.length === 5) {
            confirmBtn.setEnabled(true);
        } else if (confirmBtn.isEnabled()) {
            confirmBtn.setEnabled(false);
        }

        MusicUtility.playEffect("Music/Effect/Domino/bigLottery/bigLottery_selectClicked.mp3", false);
    },

    // 確認按鈕
    _confirmClicked: function () {
        MusicUtility.playEffect("Music/Effect/e_clickButton.mp3", false);

        var selectArray = this._selectArray;

        if (selectArray.length === 5) {
            // 把數字串起來
            var numList = selectArray.map(cur => cur.num);

            // 通知server
            DataProcess.sendString("big_lottery_choose " + JSON.stringify(numList));
        }

        var animLayer = this._animationLayer;

        // add loading
        var loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.start();
        loadingSprite.setPosition(JSScreenMidPos);
        animLayer.addChild(loadingSprite, 10);

        // 擋touch
        var dummyTouchLayer = new DummyTouchLayer(cc.size(JSVisibleSize.width, 254 + JSScreenBonusHalfHeight));
        animLayer.addChild(dummyTouchLayer, 10);

        // 設定flag
        this._isWaitingCmd = true;
    },

    /**
     * 通知
     */

    // 通知收到選號結果
    notifyBigLotterySelectResult: function (event) {
        if (event && event.getUserData()) {
            var isSuccess = event.getUserData().isSuccess;
            var myTicketParam = DataModal.bigLotteryData.myTicketParam;
            var bigLotteryStr = LocalizedString.BigLottery;

            // 拿掉loading
            if (this._loadingSprite) {
                this._loadingSprite.removeFromParent();
                this._loadingSprite = null;
            }

            // 關掉畫面
            this._closeDialogAnimation();

            if (isSuccess && myTicketParam) {
                // 全部都填完了
                if (myTicketParam.notSelectTicketNum === 0) {
                    // 跳選號成功dialog
                    var param = {
                        key: "BigLotteryCommonDialog",
                        bgSize: cc.size(420, 170),  // Domino移植設定 拉寬size
                        titleImg: "#bigLottery_word_chooseDone.png",
                        content: JSStringUtility.format(bigLotteryStr("您的第%d張彩票已選號成功\n祝您中獎！"), myTicketParam.currentTicketCount - 1),
                        buttons: ["OK"],
                        callback: () => {
                            // 重要資料
                            DataProcess.sendString("big_lottery_my_ticket");
                        }
                    };
                    DialogManager.addDialog(new BigLotteryCommonDialog(param), false);
                    MusicUtility.playEffect("Music/Effect/Domino/bigLottery/bigLottery_selectComplete.mp3", false);
                } else {
                    // 跳還有沒填的dialog
                    var param = {
                        key: "BigLotteryBeforeSelectDialog",
                        bgSize: cc.size(420, 170),  // Domino移植設定 拉寬size
                        titleImg: "#bigLottery_word_chooseDone.png",
                        content: JSStringUtility.format(bigLotteryStr("您的第%d張彩票已選號成功\n尚有%d張未選號的彩票\n是否要繼續選號？"),
                            myTicketParam.currentTicketCount - 1,
                            myTicketParam.notSelectTicketNum),
                        buttons: ["電腦選號", "繼續選號"].map(string => bigLotteryStr(string)),
                        closeButton: true,
                        callback: (index) => {
                            // 點關閉按鈕
                            if (index === -1) {
                                // 重要資料
                                DataProcess.sendString("big_lottery_my_ticket");
                            }
                            // 點電腦選號
                            else if (index === 0) {
                                // 跳電腦選號dialog
                                DialogManager.addDialog(new BigLotteryAutoSelectDialog(), false);

                                // 重要資料
                                DataProcess.sendString("big_lottery_my_ticket");
                            }
                            // 點繼續選號
                            else if (index === 1) {
                                // 跳選號dialog
                                DialogManager.addDialog(new BigLotterySelectDialog(), false);
                            }
                        }

                    };
                    DialogManager.addDialog(new BigLotteryCommonDialog(param), false);
                    MusicUtility.playEffect("Music/Effect/Domino/bigLottery/bigLottery_selectSuccess.mp3", false);
                }
            } else {//有錯誤
                var param = {
                    key: "BigLotteryCommonDialog",
                    bgSize: cc.size(290, 170),
                    content: bigLotteryStr("發生錯誤"),
                    buttons: ["OK"]
                };
                DialogManager.addDialog(new BigLotteryCommonDialog(param), false);
            }
        }
    },

    // 通知關掉選號dialog
    notifyBigLotterySelectDialogClose: function () {
        // 拿掉loading
        if (this._loadingSprite) {
            this._loadingSprite.removeFromParent();
            this._loadingSprite = null;
        }

        // 關掉畫面
        this._closeDialogAnimation();
    }
});
