/**
 * 牌王地圖
 */

var CardKingMapLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 所選的牌王等級
        this._selectedLevel = 1;

        // 當前的reject
        this._currReject = null;

        // 當前是不是跳過
        this._isSkip = false;

        // 動畫遮罩
        this._maskDialog = null;

        // 背景
        var bgSprite = new ccui.Scale9Sprite("cardKing_bg_purple.png");
        bgSprite.setAnchorPoint(0, 1);
        bgSprite.setPreferredSize(cc.size(JSVisibleSize.width, 100));
        bgSprite.setPosition(JSScreenBonusHalfWidth, JSVisibleSize.height - TITLE_BG_HEIGHT + 10);
        this.addChild(bgSprite);

        var contentNode = this._contentNode = new cc.Node();
        this.addChild(contentNode, 4);

        // 左方按鈕背景
        var tabBgSprite = new ccui.Scale9Sprite("cardKing_pic_frame_02.png");
        tabBgSprite.setPreferredSize(cc.size(120, JSVisibleSize.height + 20));
        tabBgSprite.setPosition(54 + JSScreenSafeWidth, JSScreenMidPos.y);
        contentNode.addChild(tabBgSprite);

        // 標題
        {
            // 標題-年
            var titleYearSprite = new cc.Sprite("#cardKing_word_title_01.png");
            titleYearSprite.setPosition(250 + JSScreenBonusHalfWidth, 240 + JSScreenBonusHalfHeight);
            contentNode.addChild(titleYearSprite, 1);

            // 哪一年
            var yearSprite = this._yearSprite = new GSSpriteNumberNode({
                number: 2021,
                numStr: "#num_20_",
                spW: 12,
            });
            yearSprite.setPosition(350 + JSScreenBonusHalfWidth, 242 + JSScreenBonusHalfHeight);
            contentNode.addChild(yearSprite, 1);

            // 標題-季
            var titleSeasonSprite = new cc.Sprite("#cardKing_word_title_02.png");
            titleSeasonSprite.setPosition(400 + JSScreenBonusHalfWidth, 240 + JSScreenBonusHalfHeight);
            contentNode.addChild(titleSeasonSprite, 1);

            // 哪一季
            var seasonSprite = this._seasonSprite = new GSSpriteNumberNode({
                number: 1,
                numStr: "#num_20_",
                spW: 12,
            });
            seasonSprite.setPosition(435 + JSScreenBonusHalfWidth, 242 + JSScreenBonusHalfHeight);
            contentNode.addChild(seasonSprite, 1);
        }

        // 地圖10分鐘更新一次
        var hintLabel = this._hintLabel = new cc.LabelTTF("", JSFontName, 8, cc.size(100, 0));
        hintLabel.enableStroke(JSColor.BLACK, 2);
        hintLabel.setFontFillColor(JSColor.YELLOW);
        hintLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        hintLabel.setPosition(52 + JSScreenSafeWidth, 244 + JSScreenBonusHalfHeight);
        contentNode.addChild(hintLabel);

        // 倒數node
        var countdownNode = this._countdownNode = new GSTimeLabel("", JSFontName, 8);
        countdownNode.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        countdownNode.enableStroke(JSColor.BLACK, 2);
        countdownNode.setPosition(52 + JSScreenSafeWidth, 222 + JSScreenBonusHalfHeight);
        contentNode.addChild(countdownNode);

        // 地圖
        var mapNode = this._mapNode = new CardKingMapNode();
        contentNode.addChild(mapNode);

        // 放按鈕
        this._tabButtons = [];

        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        contentNode.addChild(menu);

        // 按鈕看不看得見
        var buttonVisibleData = DataModal.cardKingData.mapVisible;

        var posY = 191 + JSScreenBonusHalfHeight;

        // 左邊按鈕
        for (var i = 4; i >= 0; --i) {
            if ((i + 1) in buttonVisibleData) {
                var itemNode = this._createTabBtn(i + 1);
                var btn = new cc.MenuItemSprite(itemNode[0], itemNode[1], itemNode[2], this._tabClicked, this);
                btn.level = i + 1;
                btn.setAnchorPoint(0, 0.5);
                btn.setPosition(4 + JSScreenSafeWidth, posY);

                var badge = btn.badge = new BadgeNode();
                badge.useDefaultStyle();
                badge.setPosition(100, 35);
                btn.addChild(badge);

                menu.addChild(btn);
                this._tabButtons.push(btn);

                posY -= 42;
            }
        }

        // 小紅點資料
        var redDotData = DataModal.cardKingData.mapRedDot;

        // 有沒有選過了
        var hasPreSelect = false;

        // 更新小紅點
        this._tabButtons.forEach(cur => {
            cur.badge.setVisible(!!redDotData[cur.level]);
            // 預選頁籤
            if (!hasPreSelect && !!redDotData[cur.level]) {
                hasPreSelect = true;
                this._tabClicked(cur);
            }
        });

        // 沒有小紅點給他預設
        if (this._tabButtons.length && !hasPreSelect)
            this._tabClicked(this._tabButtons[0]);

        this.refresh();

        GS.addListener("NotifyCardKingMapPlayerInfoDone", this.notifyCardKingMapPlayerInfoDone.bind(this), this);
        GS.addListener("NotifyCardKingInfoDone", this.notifyCardKingInfoDone.bind(this), this);
    },

    // 跑動畫
    runAnimationAsync: function (oldRound, newRound) {
        return new Promise(((resolve, reject) => {
            if (this._isSkip || this.__isDestroyed)
                return reject();
            var oldIndex = DataModal.cardKingData.getIndexBySearchCurrentDetail(this._selectedLevel, oldRound);
            var newIndex = DataModal.cardKingData.getIndexBySearchCurrentDetail(this._selectedLevel, newRound);

            // 移到要表演的cell, 有一些位移才不會一直靠最左邊
            this._mapNode.moveToIdx(oldIndex - 3);

            // 設定位置
            this._mapNode.setSelfNodePosByRound(oldRound, oldIndex);
            this._mapNode.checkPlayerNodeNeedToHide(newRound, oldIndex);

            // 所有要表演的cell
            var indexArray = [];
            for (var i = oldIndex; i <= newIndex; ++i) {
                indexArray.push(i);
            }

            // 先把泡泡藏起來
            var startPromise = new Promise((resolve) => {
                // 要是在同一個cell就不用縮小了
                if (oldIndex !== newIndex) {
                    // 先擺泡泡藏起來
                    this._mapNode.setSelfNodeBubbleOpen(false, () => resolve());
                } else {
                    return resolve();
                }
            });

            // 粗估用時
            var totalTime = (CardKingMapRouteCell.AnimationTime.CURVE + CardKingMapRouteCell.AnimationTime.LINEAR) * (indexArray.length - 1);
            // 讓數字轉上去
            this._mapNode.setSelfNodeRoundWithDuration(newRound, totalTime);

            var rejectFunc = () => {
                this._currReject = null;
                return reject();
            };

            indexArray.reduce((prePromise, currIdx) => {
                    return prePromise.then(() => new Promise((innerResolve, innerReject) => {
                        this._currReject = () => innerReject();

                        if (this._isSkip)
                            return innerReject();

                        this._mapNode.runningRouteAnimationAsync(currIdx, oldRound, newRound, innerResolve, innerReject);
                    }), rejectFunc);
                },
                startPromise)
                .catch(() => Promise.resolve())
                .then(() => {
                    if (!this._isSkip) {
                        // 打開泡泡匡
                        this._mapNode.setSelfNodeBubbleOpen(true);
                        this._mapNode.setSelfNodePosByRound(newRound, newIndex);
                        this._mapNode.checkPlayerNodeNeedToHide(newRound, newIndex);
                    }
                    return resolve();
                });
        }));
    },

    refresh: function () {
        var data = DataModal.cardKingData;
        var cardKingString = LocalizedString.CardKing;

        // 哪一季
        this._seasonSprite.setNumber(data.season);

        // 哪一年
        this._yearSprite.setNumber(data.year);

        var prefixStr = "";

        // 開放中
        if (data.status === CardKingData.Status.OPEN) {
            prefixStr = "重置倒數";
            this._hintLabel.setString(DataModal.cardKingData.mapRefreshHint || cardKingString("地圖每10分鐘更新一次"));
        }
        // 結算中
        else if (data.status === CardKingData.Status.CALCULATING) {
            prefixStr = "開放倒數";
            this._hintLabel.setString(cardKingString("牌王系統結算中"));
        }

        // 倒數時間
        var leftTime = JSCodeUtility.getRemainTime(data.remainTime, data.socketTime);
        if (leftTime > 0) {
            this._countdownNode.setMultiFormat(
                cardKingString(prefixStr) + "\n%dd" + cardKingString("天") + " %hh" + cardKingString("時"),
                cardKingString(prefixStr) + "\n%hh" + cardKingString("時") + " %mm" + cardKingString("分"),
                cardKingString(prefixStr) + "\n%mm" + cardKingString("分") + " %ss" + cardKingString("秒"),
                cardKingString(prefixStr) + "\n%mm" + cardKingString("分") + " %ss" + cardKingString("秒")
            );
            this._countdownNode.countdownSeconds(leftTime, undefined, undefined);
        }
    },

    // 生成按鈕
    _createTabBtn: function (level) {
        var itemNode = [];
        var enableBgSize = cc.size(104, 40);
        var disableBgSize = cc.size(110, 40);
        for (var i = 0; i < 3; i++) {
            var isDisable = i === 2;
            var bgSize = isDisable ? disableBgSize : enableBgSize;
            var btnImg = isDisable ? "lobby_btn_purchase_02.png" : "lobby_btn_tab_03.png";

            var node = itemNode[i] = new cc.Node();
            node.setContentSize(bgSize);
            node.setCascadeColorEnabled(true);
            node.setCascadeOpacityEnabled(true);

            var bgSprite = new ccui.Scale9Sprite(btnImg);
            bgSprite.setPreferredSize(!isDisable ? cc.size(bgSize.height, bgSize.width) : bgSize);   // 圖要翻轉
            !isDisable && bgSprite.setRotation(-90);
            bgSprite.setPosition(bgSize.width / 2, bgSize.height / 2);
            node.addChild(bgSprite);

            var iconSp = new cc.Sprite("#" + TexasUtility.getCardKingMedalName(level));
            iconSp.setScale(0.48);
            iconSp.setPosition(14, bgSize.height / 2);
            node.addChild(iconSp);

            var btnLabel = new cc.LabelTTF(JSStringUtility.format(LocalizedString.CardKing("牌王%d級"), level), JSFontName, 9);
            btnLabel.setAnchorPoint(0, 0.5);
            btnLabel.setPosition(29, bgSize.height / 2);
            node.addChild(btnLabel);
        }
        itemNode[1].setColor(JSColor.GRAY);

        return itemNode;
    },

    // 按到
    _tabClicked: function (sender) {
        this._tabButtons.forEach(cur => {
            cur.setEnabled(cur.level !== sender.level);
        });

        this._mapNode.changeLevel(sender.level);

        this._selectedLevel = sender.level;

        DataModal.cardKingData.mapRedDot[this._selectedLevel] = false;

        // 埋點
        DataProcess.sendString(JSStringUtility.format('track_crown_king {"type":"%d"}', (sender.level + 16)));

        // 小紅點
        if (sender.badge) {
            sender.badge.setVisible(false);
        }
    },

    // 跳過動畫
    _skipAnimation: function () {
        this._currReject && this._currReject();
        this._currReject = null;
        this._isSkip = true;
        this._mapNode.setTopPlayerShow(false);
        this._mapNode.refresh();
        DataModal.cardKingData.refreshOldSelfInfo(this._selectedLevel);

        if (this._maskDialog) {
            this._maskDialog.closeDialog();
            this._maskDialog = null;
        }
    },

    /**
     * 通知
     */
    // 自己玩家資料好了
    notifyCardKingMapPlayerInfoDone: function (event) {
        if (event && event.getUserData() !== undefined) {
            this._mapNode.notifyCardKingMapPlayerInfoDone(event);

            var level = event.getUserData();
            if (this._selectedLevel === Number(level)) {
                var oldInfo = DataModal.cardKingData.oldSelfInfo[level];
                var newInfo = DataModal.cardKingData.selfMapInfo[level];

                // 要跳動畫
                if (newInfo.round > oldInfo.round) {
                    this._isSkip = false;

                    // 如果有，先砍掉舊的
                    if (this._maskDialog) {
                        this._maskDialog.closeDialog();
                        this._maskDialog = null;
                    }

                    // 擋Touch dialog
                    var maskDialog = this._maskDialog = new CardKingMapUnlockMaskDialog(() => {
                        this._maskDialog = null;

                        this._skipAnimation();
                    });
                    DialogManager.addDialog(maskDialog, false);

                    // 要播恭喜的dialog
                    if (newInfo.needToPlayCongratsAnimaiton) {
                        var mapData = DataModal.cardKingData.getMapInfoByLevel(level);

                        this._mapNode.setTopPlayerShow(true);

                        this.runAnimationAsync(oldInfo.round, mapData.topPlayer.round)
                            .catch(() => Promise.resolve())
                            .then(() => new Promise((resolve) => {
                                // 跳過的話先更新一次
                                if (this._isSkip)
                                    this._mapNode.refresh();

                                // dialog完成callback
                                var doneCallback = () => {
                                    if (this.__isDestroyed)
                                        return resolve();

                                    this._mapNode.setSelfNodeIsTop(true);
                                    this._mapNode.setTopPlayerShow(false);
                                    return resolve();
                                };

                                // 跳恭喜他的dialog
                                var dialog = new CardKingMapCongratsDialog(this._selectedLevel);
                                dialog.setCloseCallback(doneCallback);
                                DialogManager.addDialog(dialog, false);
                            }))
                            .then(() => this.runAnimationAsync(mapData.topPlayer.round, newInfo.round))
                            .catch(() => Promise.resolve())
                            .then(() => {
                                if (!this.__isDestroyed)
                                    this._skipAnimation();
                            });
                    } else {
                        this.runAnimationAsync(oldInfo.round, newInfo.round)
                            .catch(() => Promise.resolve())
                            .then(() => {
                                if (!this.__isDestroyed)
                                    this._skipAnimation();
                            });
                    }
                }
            }
        }
    },

    // 資料更新
    notifyCardKingInfoDone: function () {
        this.refresh();
    }
});