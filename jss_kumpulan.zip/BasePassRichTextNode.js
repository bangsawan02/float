/**
 * 通行證 - Rich Text Node
 *
 * @param {object[][]} context 內文
 *
 * Notes:
 * - 文字可以不寫 object 而是直接傳 string
 *
 * @example
 * context: [
 *         [ // 第一行
 *             "Something is simple.",                                  // GSRichTextNode
 *             {
 *                 type: BasePassRichTextNode.Type.TEXT,                // GSRichTextNode
 *                 text: "",
 *                 fontColor: cc.color(255, 255, 255),
 *                 fontSize: 12,
 *             },
 *             {
 *                 type: BasePassRichTextNode.Type.NUMBER_SPRITE,       // GSSpriteNumberNode
 *                 offsetY: 0,                                          // 垂直偏移量
 *                 param: {},                                           // GSSpriteNumberNode 參數
 *             },
 *             {
 *                 type: BasePassRichTextNode.Type.SPRITE,              // cc.Sprite
 *                 fileName: "",
 *                 scale: 1,
 *             },
 *             {
 *                 type: BasePassRichTextNode.Type.DOWNLOAD_SPRITE,     // GSDownloadSprite
 *                 url: "",
 *                 savePath: "",
 *                 targetSize: cc.size(),
 *             }
 *           // ...
 *         ],
 *         [ // 第二行
 *             // ...
 *         ]
 *    //   ...
 * ]
 */
var BasePassRichTextNode = cc.Node.extend({
    ctor: function (context) {
        this._super();

        let columnAutoLayout = this._columnAutoLayout = new GSAutoLayoutNode();
        columnAutoLayout.setType(GSAutoLayout.TYPE.VERTICAL);
        columnAutoLayout.setAnchorPoint(0, 0);
        this.addChild(columnAutoLayout);

        context.forEach((row) => {
            // Create a new row
            let rowAutoLayout = new GSAutoLayoutNode();
            rowAutoLayout.setSpace(2);
            columnAutoLayout.addChild(rowAutoLayout);

            row.forEach((param) => {
                let elementNode;

                switch (JSCodeUtility.checkType(param)) {
                    case JSTYPE.STRING:
                        elementNode = this._createTextNode({
                            text: param,
                        });
                        break;
                    case JSTYPE.OBJECT:
                        elementNode = this._createElementByObject(param);
                        break;
                }

                elementNode && rowAutoLayout.addChild(elementNode);
            });
        });

        columnAutoLayout.refresh();
        this.setContentSize(columnAutoLayout.getContentSize());
        this.setAnchorPoint(0.5, 0.5);
    },

    /**
     * 建立文字 node
     * @param {object} param
     * @returns {*}
     * @private
     */
    _createTextNode: function (param) {
        let elementNode = new GSRichTextNode();
        elementNode.setDefaultTextColor(param.fontColor ? param.fontColor : JSColor.WHITE);
        elementNode.addComplexText(param.text, JSFontName, param.fontSize ? param.fontSize : 12);
        return elementNode;
    },

    /**
     * 依照設定建立 node.
     * @param {object} param
     * @returns {*}
     * @private
     */
    _createElementByObject: function (param) {
        let elementNode;
        switch (param.type) {
            case BasePassRichTextNode.Type.TEXT:
                elementNode = this._createTextNode(param);
                break;
            case BasePassRichTextNode.Type.NUMBER_SPRITE:
                let numberNode = new GSSpriteNumberNode(param.param);
                numberNode.setAnchorPoint(0, 0);
                numberNode.setPositionY(param.offsetY);

                elementNode = new cc.Node();
                elementNode.setContentSize(numberNode.getContentSize());
                elementNode.addChild(numberNode);
                break;
            case BasePassRichTextNode.Type.SPRITE:
                elementNode = new cc.Sprite(param.fileName);
                elementNode.setScale(param.scale ? param.scale : 1);
                break;
            case BasePassRichTextNode.Type.DOWNLOAD_SPRITE:
                elementNode = new GSDownloadSprite("", param.url, param.savePath);
                elementNode.setTargetSize(param.targetSize);
        }
        return elementNode;
    },

    /**
     * 設定 row 之間的間隙
     * @param {Number} space
     */
    setRowSpace: function (space) {
        this._columnAutoLayout.setSpace(space);
    },

    /**
     * 設定指定 index row 的 node 間隙
     * @param index
     * @param space
     */
    setNodeSpaceByRowIndex: function (index, space) {
        this._columnAutoLayout.getChildren()[index].setSpace(space);
    },
});
BasePassRichTextNode.Type = GSEnumHelper({
    TEXT: -1,
    NUMBER_SPRITE: -1,
    SPRITE: -1,
    DOWNLOAD_SPRITE: -1,
});