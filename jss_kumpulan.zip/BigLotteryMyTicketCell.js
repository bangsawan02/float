/**
 * 9T 幸運彩票 - 我的彩券Cell
 * isRealCell 是不是真的放在table view還是貼在畫面上的
 */

var BigLotteryMyTicketCell = cc.TableViewCell.extend({
    ctor: function (isRealCell = true, isEnvelope = false) {
        this._super();

        var cellWidth = BigLotteryMyTicketCell.WIDTH;
        var cellHeight = BigLotteryMyTicketCell.HEIGHT;
        var midPosX = cellWidth / 2;
        var midPosY = cellHeight / 2;

        var whiteSize = cc.size(180, 40);
        var bgSize = cc.size(285, 68);
        var numCount = 5;
        var offset = 0;
        var bgOffset = 0;
        var numItemOffset = 0;

        // Domino移植設定 統一顯示期數
        // 文字: 期數
        var periodLabel = this._periodLabel = new cc.LabelTTF("", JSFontName, 13);
        periodLabel.setFontFillColor(JSColor.BLACK);
        this.addChild(periodLabel);

        if (isEnvelope) {
            // 紅包圖
            var envelopeSprite = new cc.Sprite("#bigLottery_word_title_envelope.png");
            envelopeSprite.setPosition(midPosX - 150, midPosY + 6);
            this.addChild(envelopeSprite, 10);
            whiteSize = cc.size(200, 40);
            bgSize = cc.size(290, 68);
            numCount = 6;
            offset = 16;
            bgOffset = 3;
            numItemOffset = 2;

            periodLabel.setPosition(midPosX - 150, midPosY - 16);
        } else {
            // 大樂彩圖
            var titleSprite = new cc.Sprite("#bigLottery_word_title.png");
            titleSprite.setPosition(midPosX - 144, midPosY + 6);
            this.addChild(titleSprite);

            periodLabel.setPosition(midPosX - 144, midPosY - 16);
        }

        // 彩票背景
        var bgSprite = new ccui.Scale9Sprite("bigLottery_bg_ticket.png");
        bgSprite.setPreferredSize(bgSize);
        bgSprite.setPosition(midPosX - 50, midPosY);
        this.addChild(bgSprite, -1);

        // 彩票上白色背景
        var whiteBgSprite = new ccui.Scale9Sprite("bigLottery_bg_ticket_white.png");
        whiteBgSprite.setPreferredSize(whiteSize);
        whiteBgSprite.setPosition(midPosX - 12 - bgOffset, midPosY);
        this.addChild(whiteBgSprite, 0);

        // 彩票數字
        {
            var startPosX = midPosX - 81 - offset;
            var numNodeList = this._numNodeList = [];
            for (var i = 0; i < numCount; i++) {
                // 格子
                var squareSprite = new cc.Sprite("#bigLottery_pic_ticketNormal.png");
                squareSprite.setPosition(startPosX, midPosY);
                this.addChild(squareSprite);

                // 數字
                var numNode = numNodeList[i] = new GSSpriteNumberNode({
                    number: 0,
                    numStr: "#bigLottery_word_ticket_",
                    spW: 10
                });
                numNode.index = i;
                numNode.setPosition(squareSprite.getPosition());
                this.addChild(numNode);

                startPosX += (34 - numItemOffset);
            }
        }
        // 真的cell: 有右邊狀態
        if (isRealCell) {
            // 背景
            bgSprite = new ccui.Scale9Sprite("bigLottery_bg_redLine02.png");
            bgSprite.setPreferredSize(cc.size(100, 60));
            bgSprite.setPosition(midPosX + 142, midPosY);
            this.addChild(bgSprite);

            // 狀態文字圖
            var statusSprite = this._statusSprite = new cc.Sprite();
            statusSprite.setPosition(bgSprite.getPosition());
            this.addChild(statusSprite);
        }
    },

    /**
     * 根據彩券狀態取得狀態圖名稱
     */
    _getStatusImg: function (ticketStatus) {
        var img = "";

        var type = BigLotteryData.LotteryRewardType;
        switch (ticketStatus) {
            case type.UNSELECTED:   // 未選號
                img = "bigLottery_word_notChoose.png";
                break;

            case type.NO_WIN:       // 未中獎
                img = "bigLottery_word_notGotIt.png";
                break;

            case type.NO_DRAW:      // 未開獎
                img = "bigLottery_word_notOpen.png";
                break;

            case type.FIRST_PRICE:  // 頭獎
                img = "bigLottery_word_firstReward.png";
                break;

            case type.SECOND_PRICE: // 貳獎
                img = "bigLottery_word_secReward.png";
                break;

            case type.THIRD_PRICE:  // 參獎
                img = "bigLottery_word_thirdReward.png";
                break;

            case type.FOURTH_PRICE: // 肆獎
                img = "bigLottery_word_fourthReward.png";
                break;

            case type.FIFTH_PRICE:  // 伍獎
                img = "bigLottery_word_fifthReward.png";
                break;

            case type.NORMAL_PRICE: // 普獎
                img = "bigLottery_word_normalReward.png";
                break;
            case type.RED_ENVELOPE: // 大紅包
                img = "bigLottery_word_envelope.png";
                break;
            case type.LUCKY_NUMBER: // 幸運數字
                img = "bigLottery_word_luckyBingo.png";
                break;
        }

        return img;
    },

    // 更新cell
    refreshCell: function (param) {
        // 清除紅圈
        if (this._redCircleSps)
            this._redCircleSps.forEach(cur => cur.removeFromParent());
        this._redCircleSps = [];

        // 刷新期數
        this._periodLabel && this._periodLabel.setString(param.period);

        // 刷新彩票數字
        this._numNodeList.forEach((cur, index) => {
            cur.setNumber(param.numList[index] ? param.numList[index] : 0);
        });

        // 刷新狀態
        var statusSprite = this._statusSprite;
        statusSprite && statusSprite.setSpriteFrame(this._getStatusImg(param.rewardType));

        // 5.4.2新增幸運數字以外的紅圈顯示 by Jimmy.wen
        var historyParam = DataModal.bigLotteryData.historyParam;               // 取得歷史紀錄資料
        if (!historyParam)
            return;
        var numList = [];
        if (historyParam.historyList && historyParam.historyList[0])
            numList = historyParam.historyList[0].numList;                      // 取得中獎號碼
        var luckyNumber = undefined;
        if (historyParam.luckyHistoryList && historyParam.luckyHistoryList[0])
            luckyNumber = historyParam.luckyHistoryList[0].number;              // 取得幸運數字
        var redEnvelopeNumList = [];
        if (historyParam.envelopeHistoryList && historyParam.envelopeHistoryList[0])
            redEnvelopeNumList = historyParam.envelopeHistoryList[0].numList;   // 取得大紅包號碼
        var type = BigLotteryData.LotteryRewardType;                            // 票的類別

        // 真的票才需要圈
        if (param.rewardType) {
            if (param.rewardType !== type.NO_WIN && param.rewardType !== type.NO_DRAW && param.rewardType !== type.UNSELECTED) {
                // 先檢查有沒有中大紅包
                var winRedEnvelope = 0;
                if (redEnvelopeNumList.length > 0) {
                    param.numList.forEach((cur, index) => {
                        if (redEnvelopeNumList.indexOf(cur) > -1)
                            winRedEnvelope++;
                    });
                }

                // 依序檢查每個數字
                param.numList.forEach((cur, index) => {
                    let needRedCircle = false;
                    // 例行獎項
                    if (param.rewardType !== type.LUCKY_NUMBER && param.rewardType !== type.RED_ENVELOPE) {
                        // 數字相同 圈起來
                        if (numList.indexOf(cur) > -1)
                            needRedCircle = true;
                    }

                    // 額外判定幸運數字 & 大紅包(對中超過3個數字)
                    if (cur === luckyNumber || (winRedEnvelope >= 3 && redEnvelopeNumList.indexOf(cur) > -1))
                        needRedCircle = true;

                    // 需要紅圈就加上去
                    if (needRedCircle) {
                        var redCircleSprite = new cc.Sprite("#bigLottery_pic_redcircle.png");
                        redCircleSprite.setPosition(this._numNodeList[index].getPosition());
                        this.addChild(redCircleSprite);
                        this._redCircleSps.push(redCircleSprite);
                    }
                });
            }
        }
    },
});

// Cell寬
BigLotteryMyTicketCell.WIDTH = 418;

// Cell高
BigLotteryMyTicketCell.HEIGHT = 70;