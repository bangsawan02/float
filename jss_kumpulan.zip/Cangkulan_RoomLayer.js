/**
 *Cangkulan桌列表
 */
var Cangkulan_RoomLayer = cc.Layer.extend({
    ctor: function (mode) {
        this._super();

        // 先判斷是否可以進去三張牌的玩法
        this._regionArray = [];                                 // 底台列表
        this._totalCellCount = 0;                               // 底台列表數量
        this._gameMode = CANGKULAN_ROOM_TYPE.NORMAL;            // 遊戲玩法
        this._sortType = -1;                                    // 排序的類別
        this._isDecrement = true;                               // 是否遞減(排序用)

        var lobbyString = LocalizedString.Lobby;

        // 上方文字底
        var posY = JSVisibleSize.height - TITLE_BG_HEIGHT / 2;
        var titleNode = new TitleBackgroundNode();
        titleNode.setPosition(JSScreenMidPos.x, posY);
        this.addChild(titleNode, 10);

        // 上方右側的icon
        var containerNode = new RoomIconContainerNode(cc.p(0, posY + 3));
        this.addChild(containerNode, 20);

        // 每日任務
        var dailyMissionBtn = this._dailyMissionBtn = ButtonUtility.createSimpleImageButton("lobby_icon_lobbyMission.png");
        dailyMissionBtn.bonusWidth = 2;
        dailyMissionBtn.setVisible(!DataModal.profileData.isBlackAccount);
        dailyMissionBtn.addTouchUpInsideAction(this._dailyMissionBtnClicked, this);
        containerNode.addChild(dailyMissionBtn);

        // 錢
        var chipNode = new TitleChipsNode();
        chipNode.setPurchaseButtonVisible(true);
        containerNode.addChild(chipNode, 20);

        // 最後排一次位置
        containerNode.refresh();

        // 加入玩法說明
        var titleLabel = new cc.LabelTTF("Cangkulan (Pilih Meja)", JSFontBoldName, 12);
        titleLabel.setAnchorPoint(0, 0.5);
        titleLabel.setPosition(-JSScreenMidPos.x + 40 + JSScreenSafeWidth, 4);
        titleNode.addChild(titleLabel);

        // 下方的漸層
        var blackGradient = new cc.LayerGradient(cc.color(0, 0, 0, 255), cc.color(0, 0, 0, 0), cc.p(0, -1));
        blackGradient.setAnchorPoint(0.5, 1);
        blackGradient.ignoreAnchorPointForPosition(false);
        blackGradient.setContentSize(cc.size(JSVisibleSize.width, 50));
        blackGradient.setPosition(JSScreenMidPos.x, titleNode.getPositionY() - 10);
        this.addChild(blackGradient, -1);

        // 背景
        var bgSprite = new cc.Sprite(SelectGameManager.getNowGameFile("lobby_background.jpg"));
        bgSprite.setPosition(JSScreenMidPos);
        bgSprite.setOpacity(102);   //alpha 40%
        this.addChild(bgSprite, -1);

        // 背景的煙火
        var fPos = [cc.p(-9, 160), cc.p(419, 204)];
        for (var i = 0; i < 2; i++) {
            var fireworks = new cc.Sprite("#lobby_fireworks.png");
            fireworks.setScale(1.5);
            fireworks.setOpacity(76.5); //alpha 30%
            fireworks.setPosition(cc.pAdd(fPos[i], cc.p(JSScreenBonusHalfWidth, JSScreenBonusHalfHeight)));
            this.addChild(fireworks);
        }

        // 讀取畫面
        var loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 10);
        loadingSprite.setVisible(false);
        this.addChild(loadingSprite);

        // 選遊戲玩法 (先藏起來 等有新玩法在加上去)
        this._haveChangeMode = false;
        var changeModeNode = this._changeModeNode = new cc.Node();
        this.addChild(changeModeNode, 2);

        if (this._haveChangeMode) {
            var nowPosY = 236 + JSScreenBonusHeight;
            var listMenu = new cc.Menu();
            listMenu.setPosition(0, 0);
            changeModeNode.addChild(listMenu, 2);

            var btnSize = cc.size(120 + (JSScreenBonusWidth / 4), 18);
            var titles = [lobbyString("Normal"), lobbyString("All In")];
            var allMods = [CANGKULAN_ROOM_TYPE.NORMAL];
            var len = allMods.length;                                                           // 要出現幾個
            var basePosX = JSScreenMidPos.x - btnSize.width * (len - 1) / 2;
            this._listMenuItem = [];

            var listBg = new ccui.Scale9Sprite("lobby_bar_bg.png");
            listBg.setPreferredSize(cc.size(btnSize.width * len, 18));
            listBg.setPosition(JSScreenMidPos.x, nowPosY);
            changeModeNode.addChild(listBg);

            for (var i = 0; i < len; i++) {
                var labels = [];
                for (var x = 0; x < 3; x++) {
                    labels[x] = new cc.LabelTTF(titles[i], JSFontBoldName, 10, btnSize, cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
                }
                labels[1].setFontFillColor(JSColor.GRAY);
                labels[2].setFontFillColor(JSColor.BLACK);

                var listMenuItem = this._listMenuItem[i] = new cc.MenuItemSprite(labels[0], labels[1], labels[2], this._listItemClicked, this);
                listMenuItem.setPosition(basePosX + (i * btnSize.width), nowPosY);
                listMenuItem.gameMode = allMods[i];
                listMenu.addChild(listMenuItem);
            }

            //選擇的白底
            var selectIndex = allMods.indexOf(mode);
            var selectListMenuItem = this._listMenuItem[selectIndex > -1 ? selectIndex : 0];
            var selectSprite = this._selectSprite = new ccui.Scale9Sprite("lobby_bar_select.png");
            selectSprite.setPreferredSize(btnSize);
            selectSprite.setPosition(selectListMenuItem.getPosition());
            changeModeNode.addChild(selectSprite);
        }

        // 創一個主畫面的Node 動態改畫面
        var mainNode = this._mainNode = new cc.Node();
        this.addChild(mainNode);

        // 預設第幾個Tab
        if (this._haveChangeMode)
            this._listItemClicked(selectListMenuItem);
        else {
            // 沒上面的遊戲玩法 直接更新畫面
            this._refreshView();
        }

        // 去要桌列表每日任務的資料
        var dailyMissionData = DataModal.dailyMissionData;
        if (!dailyMissionData.getHaveDailyMissionDone())
            dailyMissionData.startGetInfo(DailyMissionEnum.whereType.Room, DailyMissionEnum.roomType.Cangkulan);
        else
            // 拿過資料判斷小紅點
            this.notifyUpdateDailyMission();

        //註冊通知
        GS.addListener("NotifySetTMoney", this.notifyRefreshRoomListSetTMoney.bind(this), this);            // 金錢有變動時 更新列表
        GS.addListener("NotifyRefreshRoomList", this.notifyRefreshRoomList.bind(this), this);               // 收到新資料時 更新列表
        GS.addListener("NotifyRefreshKoinLuxyStatusDone", this.notifyRefreshRoomList.bind(this), this);     // KL系統是否顯示 更新列表
        GS.addListener("NotifyUpdateDailyMission", this.notifyUpdateDailyMission.bind(this), this);         // 確認每日任務icon有沒有小紅點
    },

    /**
     * 功能
     */
    // 更新整個畫面
    _refreshView: function () {
        var regionsData = DataModal.regionsData;

        // 先砍掉畫面
        var mainNode = this._mainNode;
        mainNode.removeAllChildren();

        // 先判斷拿完Socket了沒
        var isGetSocket = regionsData.isGetRegionsData(GSEnum.Game.Cangkulan, this._gameMode);
        if (!isGetSocket) {
            // 沒拿到Socket 出現Loading
            this._loadingSprite.start();
            return;
        }

        // 有拿到Socket了
        this._loadingSprite.stop();
        this._regionArray = [];
        this._totalCellCount = 0;
        this._sortType = -1;                                        // 排序的類別

        // 先判斷是否要出現積分系統
        var gameRankObject = DataModal.regionsData.cangkulan.gameRankObject;
        var haveGameRank = !!gameRankObject;

        // 先判斷是否要出現koinLuxy系統
        var haveKoinLuxy = DataModal.regionsData.cangkulan.isShowKoinLuxy;

        // 頁籤
        var sortTitleNode = this._sortTitleNode = new cc.Node();
        mainNode.addChild(sortTitleNode, 1);

        var sortMenu = new cc.Menu();
        sortMenu.setPosition(0, 0);
        sortTitleNode.addChild(sortMenu, 2);

        // 排序背景
        var leftSpace = 35;
        var totalWidth = JSVisibleSize.width - (JSScreenSafeWidth + leftSpace) * 2;
        var btnPosX = leftSpace + JSScreenSafeWidth;
        var btnPosY = 205 + JSScreenBonusHeight + (this._haveChangeMode ? 0 : 20);
        var sortSprite = new ccui.Scale9Sprite("lobby_pic_banner_05.png");
        sortSprite.setPreferredSize(cc.size(JSVisibleSize.width - btnPosX * 2, 30));
        sortSprite.setPosition(JSScreenMidPos.x, btnPosY + 2);
        sortTitleNode.addChild(sortSprite);

        // 排序按鈕
        var lobbyString = LocalizedString.Lobby;
        var sortWords = ["房名", "底注"];

        // 有沒有積分
        if (haveGameRank)
            sortWords.push("積分");

        // 有沒有koin Luxy
        if (haveKoinLuxy)
            sortWords.push(ProfileData.getKoinLuxyRes("Koin Luxy", ""));

        var sortRatios = [];
        var sortTypes = [];
        var sortWordsLen = sortWords.length;

        if (sortWordsLen === 2) {
            sortRatios = [0.5, 0.5];
            sortTypes = [0, 1];
        } else if (sortWordsLen === 3) {
            sortRatios = [0.35, 0.35, 0.3];
            sortTypes = [0, 1, 2];
        } else if (sortWordsLen === 4) {
            sortRatios = [0.23, 0.27, 0.2, 0.3];
            sortTypes = [0, 1, 2, 3];
        }

        var sortWidths = sortRatios.map(cur => cur * totalWidth);
        this._sortMenuItem = [];
        this._sortNodes = [];
        sortWords.forEach((cur, i) => {
            var realWidth = Cangkulan_RoomLayer.TAB_WIDTH[i] = sortWidths[i];

            var sortNodes = this._sortNodes[i] = ButtonUtility.createSingleScale9Nodes("lobby_btn_empty.png", cc.size(realWidth, 24), lobbyString(sortWords[i]), 12, JSColor.WHITE);
            sortNodes.forEach(cur => cur.label.setPositionY(cur.label.getPositionY() + 2)); //文字較偏上

            var sortMenuItem = this._sortMenuItem[i] = new cc.MenuItemSprite(sortNodes[0], sortNodes[1], sortNodes[2], this._sortItemClicked, this);
            sortMenuItem.setPosition(btnPosX + realWidth / 2, btnPosY);
            sortMenuItem.sortType = sortTypes[i];
            sortMenu.addChild(sortMenuItem);

            btnPosX += realWidth + 2;
        });

        // 房名按鈕按下時不變色
        this._sortNodes[0].forEach((cur, idx) => idx === 1 && cur.setColor(JSColor.WHITE));

        // 顯示排序規則的箭頭
        var sortarrow = this._sortArrow = new cc.LabelTTF("▼", JSFontBoldName, 10);
        sortarrow.setPosition(cc.pAdd(this._sortMenuItem[0].getPosition(), cc.p(0, -8)));
        sortarrow.setFontFillColor(JSColor.YELLOW);
        sortTitleNode.addChild(sortarrow, 3);

        // 排序按鈕分隔線 (左右不用線)
        var linePosX = leftSpace - 2 + JSScreenSafeWidth;
        for (var i = 0, len = sortWords.length; i < len; i++) {
            if (i > 0) {
                var line = new ccui.Scale9Sprite("lobby_division_line.png");
                line.setPreferredSize(cc.size(28, 2));
                line.setRotation(90);
                line.setPosition(linePosX, btnPosY);
                sortTitleNode.addChild(line, 1);
            }

            linePosX += Cangkulan_RoomLayer.TAB_WIDTH[i] + 2.5;
        }
        // TableCell的總寬
        Cangkulan_RoomLayer.TABLE_CONTENT_WIDTH = Cangkulan_RoomLayer.TAB_WIDTH.reduce((prev, next) => prev + next);

        // 沒有Cell的文字
        var info = this._noCellInfoLabel = new cc.LabelTTF("Coming Soon", JSFontBoldName, 18);
        info.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 32);
        info.setVisible(false);
        mainNode.addChild(info, 3);

        // 列表背景
        var gameRankViewHeight = haveGameRank ? 44 : 0;
        var tableWidth = JSVisibleSize.width - (JSScreenSafeWidth * 2) - leftSpace * 2;
        var tableHeight = JSVisibleSize.height - TITLE_BG_HEIGHT - 60 - gameRankViewHeight + (this._haveChangeMode ? 0 : 20);
        var tablePosY = gameRankViewHeight;
        var tableBgSprite = this._tableBgSprite = new cc.Sprite("#lobby_bg_list_04.png");
        var tableBgSize = tableBgSprite.getContentSize();
        tableBgSprite.setScale(tableWidth / tableBgSize.width, (tableHeight + 6) / tableBgSize.height);
        tableBgSprite.setAnchorPoint(0.5, 0);
        tableBgSprite.setPosition(JSScreenMidPos.x, gameRankViewHeight);
        mainNode.addChild(tableBgSprite);

        // 列表
        this._mainLayer = new cc.Layer();
        var tableView = this._tableView = new cc.TableView(this, cc.size(tableWidth, tableHeight), this._mainLayer);
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setPosition(leftSpace + JSScreenSafeWidth, tablePosY);
        mainNode.addChild(tableView);

        // TableView上方要蓋一層檔Touch的 怕滑出去的按鈕點到
        var dummyTouch = new DummyTouchLayer(cc.size(JSVisibleSize.width, JSVisibleSize.height - (TITLE_BG_HEIGHT + tablePosY + tableHeight)));
        dummyTouch.setPosition(0, tablePosY + tableHeight);
        mainNode.addChild(dummyTouch);

        // 判斷是否要顯示下方的積分畫面
        this._gameRankNode = null;
        if (haveGameRank) {
            var resources = ["rank/gameRank.plist", "rank/gameRank.png"];

            // 加Icon的Function
            var addFunc = () => {
                // 讀取Plist
                cc.spriteFrameCache.addSpriteFrames(resources[0], resources[1]);

                var rankMidPosY = gameRankViewHeight / 2;

                var gameRankNode = this._gameRankNode = new cc.Node();
                mainNode.addChild(gameRankNode);

                // 先做一層檔Touch的
                var dummyTouch = new DummyTouchLayer(cc.size(JSVisibleSize.width, gameRankViewHeight));
                gameRankNode.addChild(dummyTouch);

                // 背景
                var bgSprite = new ccui.Scale9Sprite("lobby_bottom_bg.png");
                bgSprite.setPreferredSize(cc.size(JSVisibleSize.width, gameRankViewHeight));
                bgSprite.setAnchorPoint(0.5, 0);
                bgSprite.setPosition(JSScreenMidPos.x, 0);
                gameRankNode.addChild(bgSprite);

                // 階級Icon
                var rankIconNode = new GameRankIconNode(gameRankObject.class);
                rankIconNode.setScale(0.4);
                rankIconNode.setPosition(25 + JSScreenBonusHalfWidth, 24);
                gameRankNode.addChild(rankIconNode);

                // 階級文字
                var levelNameIcon = new cc.Sprite("#" + GameRankClass.getIconNameImage(gameRankObject.class));
                levelNameIcon.setScale(0.5);
                levelNameIcon.setPosition(25 + JSScreenBonusHalfWidth, 7);
                gameRankNode.addChild(levelNameIcon);

                // 排名
                if (!isNaN(gameRankObject.ranking)) {
                    var rankNumberNode = new GameRankNumberNode(gameRankObject.ranking);
                    rankNumberNode.setPosition(61 + JSScreenBonusHalfWidth, rankMidPosY - 2);
                    gameRankNode.addChild(rankNumberNode);
                }

                // 如果玩家的gameRank分數小於下一階的起始分數，才顯示進度條，否則玩家在Master等級時數值會超過100%
                var isShowGameRankBar = gameRankObject.score < gameRankObject.nextScore;

                // 進度條 背景
                if (gameRankObject.nextScore > 0 && isShowGameRankBar) {
                    var barPos = cc.p(147 + JSScreenBonusHalfWidth, rankMidPosY - 2);
                    var progressBgSprite = new ccui.Scale9Sprite("lobby_bar_bg_02.png");
                    progressBgSprite.setPreferredSize(cc.size(137, 16));
                    progressBgSprite.setPosition(barPos);
                    gameRankNode.addChild(progressBgSprite);

                    // 進度條
                    var percent = Math.floor(gameRankObject.score / gameRankObject.nextScore * 100);
                    var progressSprite = new cc.ProgressTimer(new cc.Sprite("#lobby_bar_04.png"));
                    progressSprite.setPosition(barPos);
                    progressSprite.setBarChangeRate(cc.p(1, 0));
                    progressSprite.setMidpoint(cc.p(0, 0));
                    progressSprite.setType(cc.ProgressTimer.TYPE_BAR);
                    progressSprite.setPercentage(percent);
                    gameRankNode.addChild(progressSprite);

                    // 進度條文字
                    var progressLabel = new cc.LabelTTF(percent.toString() + "%", JSFontBoldName, 9);
                    progressLabel.setPosition(barPos);
                    gameRankNode.addChild(progressLabel, 1);
                }

                // 右邊提示文字
                if (gameRankObject.showFirstWin) {
                    var hintString = JSStringUtility.format(LocalizedString.GameRank("每日首勝，額外+%d積分"), gameRankObject.showFirstWin);
                    var hintRichText = new GSRichTextNode(hintString, JSFontBoldName, 11);
                    hintRichText.setAnchorPoint(0, 0.5);
                    // 如果不顯示進度條，將文字的位置移到原本進度條的位置
                    hintRichText.setPosition((isShowGameRankBar ? 219 : 79) + JSScreenBonusHalfWidth, rankMidPosY - 2);
                    gameRankNode.addChild(hintRichText, 1);
                }
            };

            if (cc.sys.isNative || cc.textureCache.getTextureForKey(resources[1])) {
                addFunc();
            } else {
                // H5要先Loader
                cc.loader.load(resources, function () {
                    addFunc();
                });
            }
        }

        // 右下角的馬上玩按鈕
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        mainNode.addChild(menu, 2);

        var spriteArray = ButtonUtility.createBtnSpriteArray("#lobby_btn_play.png");
        var playButton = this._playButton = new cc.MenuItemSprite(spriteArray[0], spriteArray[1], spriteArray[2], this._playButtonClicked, this);
        playButton.setScale(haveGameRank ? 0.8 : 1);
        playButton.setPosition(JSVisibleSize.width - JSScreenSafeWidth - 29, haveGameRank ? 21 : 29);
        menu.addChild(playButton);

        // 預選排序
        this._sortItemClicked(this._sortMenuItem[1]);
    },

    //更新列表
    _refreshTableView: function () {
        this._regionArray = DataModal.regionsData.getCanglulanSortRegions(this._sortType, this._isDecrement, this._gameMode);
        this._totalCellCount = this._regionArray.length;

        //沒有Cell的文字
        var noCell = this._totalCellCount === 0;
        this._noCellInfoLabel.setVisible(noCell);
        this._sortTitleNode.setVisible(!noCell);
        this._tableBgSprite.setVisible(!noCell);
        this._playButton.setVisible(!noCell);
        this._gameRankNode && this._gameRankNode.setVisible(!noCell);

        //清除mainLayer上的所有東西 (這邊要傳false 因為cell裡面有動畫不能cleanup)
        this._mainLayer.removeAllChildren(false);

        //加線
        var tableWidth = JSVisibleSize.width - (JSScreenSafeWidth * 2) - 82;   //螢幕寬 - 兩邊安全區域的寬 - (左方留白24+右方留白53+線的留邊5=82)
        for (var i = 0; i < this._totalCellCount; i++) {
            var lineSprite = new ccui.Scale9Sprite("lobby_division_line.png");
            lineSprite.setPreferredSize(cc.size(tableWidth, 2));
            lineSprite.setPosition(cc.p(4 + tableWidth / 2, i * Cangkulan_RoomLayer.TABLE_CONTENT_HEIGHT));
            this._mainLayer.addChild(lineSprite, -1);
        }
        this._tableView.reloadData(true);
    },

    /**
     * 按鈕
     */
    // 桌列選單
    _listItemClicked: function (sender) {
        for (var i = 0, len = this._listMenuItem.length; i < len; i++) {
            if (this._listMenuItem[i] === sender) {
                this._selectSprite.stopAllActions();
                this._selectSprite.runAction(cc.moveTo(0.1, sender.getPosition()));
                this._gameMode = sender.gameMode;
                sender.setEnabled(false);
            } else {
                this._listMenuItem[i].setEnabled(true);
            }
        }

        // 更新畫面
        this._refreshView();
    },

    /**
     * 每日任務點擊
     */
    _dailyMissionBtnClicked: function () {
        DialogManager.addDialog(new ActionListDialog(0, DailyMissionEnum.whereType.Room, DailyMissionEnum.roomType.Cangkulan));

        // 埋點
        DataProcess.sendString("track_daily_mission 6");
    },

    //排序按鈕
    _sortItemClicked: function (sender) {
        //房名不排序
        if (sender === this._sortMenuItem[0]) {
            return;
        }

        var len = this._sortMenuItem.length;
        for (var i = 1; i < len; i++) {
            if (sender === this._sortMenuItem[i]) {
                //被選到的要顯示黃色
                this._sortNodes[i].forEach(cur => cur.label.setFontFillColor(JSColor.YELLOW));

                //如果sortType一樣要反排序
                if (this._sortType === sender.sortType)
                    this._isDecrement = !this._isDecrement;
                else
                    this._isDecrement = true;

                //更新sortType
                this._sortType = sender.sortType;

                //更新箭頭狀態
                this._sortArrow.setPositionX(sender.getPositionX());
                this._sortArrow.setScaleY(this._isDecrement ? 1 : -1);

            } else {
                //未選到的要設定回白色
                this._sortNodes[i].forEach(cur => cur.label.setFontFillColor(JSColor.WHITE));
            }
        }

        // 更新TableView
        this._refreshTableView();
    },

    // 馬上玩按鈕
    _playButtonClicked: function () {
        // Firebase 使用
        GSAnalyticsAdapter.record["isClickQuickPlayFromRoom"] = true;

        // 馬上玩
        GS.dispatchCustomEvent("NotifyGoQuickPlay", {
            game: GSEnum.Game.Cangkulan,
            playType: this._gameMode
        });
    },

    /**
     * TableView delegate
     */
    tableCellTouched: function (table, cell) {
        cell.setIsHighlight(false);
        var idx = cell.getIdx();
        var region = this._regionArray[idx];

        //不可入桌 要跳Dialog
        if (region.cannotSit && region.cannotSit.result !== 0) {
            var result = region.cannotSit.result;
            var dialog;
            switch (result) {
                case 1: // 金錢不夠
                    DialogManager.addDialog(new NoMoneyDialog(region.minBringIn));
                    break;
                case 3: //等級不足
                    var self = this;
                    var obj = DialogHelper("NoLevel_Cangkulan", region.cannotSit.resultValue.toString());
                    obj.callback = index => index === 0 && self._playButtonClicked();
                    dialog = new AvatarDialog(obj);
                    break;
                default:
                    break;
            }

            if (dialog)
                DialogManager.addDialog(dialog);
        } else {
            // 設定現在遊戲
            DataModal.setGameData(GSEnum.Game.Cangkulan);

            // 可入桌
            var json = {
                game: GSEnum.Game.Cangkulan,
                fee: region.ante,
                playType: "casual"
            };

            // 可入桌
            DataProcess.sendString("mix_quickJoin " + JSON.stringify(json));
            GSLoading.addLoadingView();

            // 先設定開哪一頁
            DataModal.lobbyInfo.toLobbyOpenPage = LobbyOpenPage.ROOM;
            DataModal.lobbyInfo.lastGameMode = this._gameMode;
        }
    },

    tableCellHighlight: function (table, cell) {
        if (cell)
            cell.setIsHighlight(true);
    },

    tableCellUnhighlight: function (table, cell) {
        if (cell)
            cell.setIsHighlight(false);
    },

    cellSizeForTable: function () {
        return cc.size(Cangkulan_RoomLayer.TABLE_CONTENT_WIDTH, Cangkulan_RoomLayer.TABLE_CONTENT_HEIGHT);
    },

    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        if (cell == null) {
            cell = new Cangkulan_RoomCell();
            cell.setAnchorPoint(cc.p(0, 0));
        }
        cell.refreshCell(idx, this._regionArray[idx]);

        return cell;
    },

    numberOfCellsInTableView: function (table) {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function (table, idx) {
        return this.cellSizeForTable(table);
    },

    /**
     * 無差別通知更新列表
     */
    notifyRefreshRoomList: function () {
        //通知更新列表
        this._refreshView();
    },

    /**
     * 金錢有變動才通知更新
     */
    notifyRefreshRoomListSetTMoney: function () {
        // 每日任務領獎等關閉Dialog後再一次重送
        if (DataModal.dailyMissionData.haveRewardDailyMission)
            return;

        if (DataModal.regionsData.checkRegionsMoney !== DataModal.profileData.money) {
            //通知更新列表
            this._refreshView();
            DataModal.dailyMissionData.haveRewardDailyMission = false;
        }
    },

    /**
     * 桌列表每日任務icon要不要小紅點
     */
    notifyUpdateDailyMission: function () {
        // 有沒有小紅點
        var isHaveBadge = DataModal.dailyMissionData.getActionListDialogHaveReward(DailyMissionEnum.whereType.Room, DailyMissionEnum.roomType.Cangkulan);

        var badge = this._badge;

        // 需要顯示但是還沒加過小紅點 先加小紅點
        if (isHaveBadge && !badge) {
            var pos = this._dailyMissionBtn.getPosition();

            badge = this._badge = new BadgeNode();
            badge.useDefaultStyle();
            badge.setPosition(pos.x + 9, pos.y + 9);
            badge.setScale(0.8);
            this.addChild(badge, 21);
        }

        badge && badge.setVisible(isHaveBadge);
    }
});

Cangkulan_RoomLayer.TABLE_CONTENT_WIDTH = 0;      //Table欄位的寬度
Cangkulan_RoomLayer.TABLE_CONTENT_HEIGHT = 41;    //Table欄位的高度
Cangkulan_RoomLayer.TAB_WIDTH = [];               //Tab的寬度