/**
 * 5.5.7大廳信件領獎整合 收件箱 Common Dialog
 * 移植自中文德撲 16.2大廳信件領獎整合
 *
 * created by daniel.lin
 */

var AwardAndMailCommonDialog = BaseDialogLayer.extend({
    ctor: function (title, content, callback, returnGiftAccount) {
        this._super();

        this.key = "AwardAndMailCommonDialog";

        var aniLayer = this._animationLayer;

        // 內文
        var contentLabel = new cc.LabelTTF(content, JSFontBoldName, 11.25);
        contentLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 5);
        contentLabel.setFontFillColor(GS.isLuxyPoker ? JSColor.WHITE : cc.color(102, 48, 20));
        contentLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        aniLayer.addChild(contentLabel, 2);

        // 背景圖
        var bgSprite = new cc.Scale9Sprite("awardAndMail_bg_window_01.png");
        bgSprite.setPreferredSize(cc.size(Math.max(216, contentLabel.getContentSize().width + 32), Math.max(130, contentLabel.getContentSize().height + 80)));
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite);

        // 標題
        var titleLabel = new cc.LabelTTF(title, JSFontBoldName, 17.5);
        titleLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + bgSprite.getContentSize().height / 2 - 22);
        titleLabel.setColor(GS.isLuxyPoker ? cc.color(225, 240, 0) : cc.color(179, 117, 54));
        aniLayer.addChild(titleLabel);

        // 設定closeCallBack
        callback && this.setCloseCallback(callback);

        // 確定按鈕
        let btnHeight = GS.isLuxyPoker ? 27 : 32.5;
        var receiveBtn = ButtonUtility.createSimpleButton(GS.isLuxyPoker ? "lobby_btn_01.png" : "lobby_btn_15.png", cc.size(returnGiftAccount ? 80 : 65.5, btnHeight), LocalizedString.AwardAndMail("確定"), GS.isLuxyPoker ? JSColor.BLACK : JSColor.WHITE, 12);
        receiveBtn.setPosition(JSScreenMidPos.x + (returnGiftAccount ? -55 : 0), JSScreenMidPos.y - bgSprite.getContentSize().height / 2 + 28);
        !GS.isLuxyPoker && receiveBtn.label.enableStroke(cc.color(24, 140, 0), 2);
        receiveBtn.addTouchUpInsideAction(() => {
            this._closeDialogAnimation();
        }, this);
        aniLayer.addChild(receiveBtn);

        // 需要回禮按鈕
        if (returnGiftAccount) {
            var returnGiftBtn = ButtonUtility.createSimpleButton("lobby_btn_01.png", cc.size(80, btnHeight), LocalizedString.AwardAndMail("回禮"), JSColor.BLACK, 12);
            returnGiftBtn.setPosition(JSScreenMidPos.x + 55, JSScreenMidPos.y - bgSprite.getContentSize().height / 2 + 28);
            returnGiftBtn.addTouchUpInsideAction(() => {
                // 回禮
                var param = {
                    "userid": returnGiftAccount
                };
                DataProcess.sendString("user_send_gift " + JSON.stringify(param));

                this._closeDialogAnimation();
            }, this);
            aniLayer.addChild(returnGiftBtn);
        }
    }
});