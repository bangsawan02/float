var Cangkulan_SpotLightLayer = cc.Layer.extend({

    ctor: function () {
        this._super();

        this._lightServerSitNum = 0;
        this._isStoped = false;

        var spot = this._spotLightSprite = new cc.Sprite("#game_pic_focus.png");
        spot.setScale(4);
        spot.setAnchorPoint(cc.p(1, 0.5));
        spot.setPosition(JSScreenMidPos);
        spot.setVisible(false);
        this.addChild(spot);

        //事件
        GS.addListener("NotifyGameTurnPositionFinish", this.notifyGameTurnPositionFinish.bind(this), this);
    },

    cleanData: function () {
        this.stop();
    },

    stop: function () {
        this._isStoped = true;
        this._spotLightSprite.setVisible(false);
        this._spotLightSprite.stopAllActions();
    },

    //sitNum是畫面上的位置
    play: function (serverSitNum) {
        this._isStoped = false;
        this._lightServerSitNum = serverSitNum;
        var scale = 0;
        var sitNum = DataModal.gameData.getDirectionByServerDirection(serverSitNum);
        var pos = Cangkulan_GameUtility.getPlayerPosition(sitNum);
        var dx = JSScreenMidPos.x - pos.x;
        var dy = JSScreenMidPos.y - pos.y;
        var rotation = Math.atan2(dx, dy) / Math.PI * 180 - 90;

        switch (sitNum) {
            case 0:
                scale = 0.8;
                break;
            case 1:
                scale = 0.8;
                break;
            case 2:
                scale = 0.4;
                break;
            case 3:
                scale = 0.8;
                break;
            default:
                scale = 0;
                break;
        }

        this._spotLightSprite.stopAllActions();
        this._spotLightSprite.runAction(cc.sequence(
                cc.show(),
                cc.spawn(
                    cc.fadeIn(0.2),
                    cc.rotateTo(0.2, rotation),
                    cc.scaleTo(0.2, scale * 4))
            )
        );
    },

    /**
     * 換位置時自已轉到畫面上0的位置結束時觸發,修改SpotLight的位置
     * @private
     */
    notifyGameTurnPositionFinish: function () {
        if (this._isStoped)
            return;
        this.play(this._lightServerSitNum);
    }
});