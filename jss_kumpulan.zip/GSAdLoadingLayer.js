var LoginLoadingStatus = {
    NONE: 0,                    // 開始的時後
    GO_GET_PROXY: 1,            // 去抓PROXY的位置
    SOCKET_CONNECT: 2,          // 開始去連Socket
    SOCKET_DONE: 3,             // Socket連上
    LOBBY26_DONE: 4,            // 收到LOBBY26
    CONNECT_INFO_DONE: 5,       // 收到connect_info
    LOGIN_DONE: 6,              // 登入成功
    SESSION_STATUS_DONE: 7,     // 收到session_status
    START_mRC: 8,               // 開始牌局重現
    END_TO_LOBBY: 9,            // 無牌局重現到大廳
    END_TO_GAME: 10             // 有牌局重現到遊戲
};

var LoadingTimeOutTime = 30;    // Timeout時間(LoginChangeURLLayer可以調整timeout時間 方便測試使用)

var GSAdLoadingLayer = cc.Layer.extend({
    BIG_LOADING_BAR_BEGIN_WIDTH: 6,     // loading bar的起始寬度
    BIG_LOADING_BAR_END_WIDTH: 198,     // loading bar的最長寬度
    CLOSE_LOADING_ACTION_TAG: 72912,    // loading 這個action的 tag

    ctor: function (type, isAnimation, position, fontColor, background) {
        this._super();

        this.setCascadeOpacityEnabled(true);

        // 大loading使用
        this._timeOutTime = LoadingTimeOutTime; // Timeout時間
        this._beginWidth = 0;                   // 起始寬度
        this._endWidth = 0;                     // 結束寬度
        this._beginTime = 0;                    // 起時時間
        this._nowTime = 0;                      // 現在時間
        this._endTime = 10000;                  // 結束時間

        this._isNotifyEnd = false;              // 通知結束
        this._isUseFadeAnimation = 0;           // 出來是否要淡入淡出

        this._isNeedTimeOut = false;            // 設定是否要timeOut
        this._isUseBigLoading = false;          // 設true 不會release SuperAnim
        this._loadingExpBar = null;             // loadingBar sprite
        this._textLabel = null;                 // 秀 loading 時的文字

        if (type === 2)             // logo+文字的讀取
            this._initWithLogo();
        else if (type == 1)         // 有人物的讀取
            this._initWithBigLoadingAndAvatarPosition(isAnimation, position, fontColor, background);
        else if (type == 0)         // 空白畫面
            this._initWithEmpty();
        else                        // 一般讀取畫面
            this._init();

        // 加一層UI檔Touch
        var dummyTouch = new DummyTouchLayer(JSVisibleSize);
        this.addChild(dummyTouch, 50000);
    },

    _initWithLogo: function () {
        // 背景主題
        var bgSprite = new cc.Sprite(SelectGameManager.getNowGameFile("lobby_background.jpg"));
        bgSprite.setPosition(JSScreenMidPos);
        this.addChild(bgSprite);

        // logo
        var logoSprite = new cc.Sprite(SelectGameManager.getNowGameFile("common_logo.png"));
        logoSprite.setPosition(JSScreenMidPos.x, JSOriginPoint.y + 179 + JSScreenBonusHalfHeight);
        this.addChild(logoSprite);

        // 小技巧提示文字
        var hintStringArray = [
            "Six Devil adalah kombinasi kartu tertinggi di permainan Domino QiuQiu",
            "Kembali setiap hari & raih hadiah",
            "Kotak Harta karun akan direset ulang setiap hari pkl. 06:00 pagi WIB"
        ];
        GS.isLuxyPoker && hintStringArray.shift();  // LuxyPoker不顯示第一個

        var word = new cc.LabelTTF(hintStringArray[JSCodeUtility.getRandomInt(0, hintStringArray.length - 1)], JSFontBoldName, 11);
        word.setPosition(cc.pAdd(logoSprite.getPosition(), cc.p(0, -55)));
        this.addChild(word);

        // Loading Bar
        var expBgSprite = new ccui.Scale9Sprite("loading_bar_bg.png");
        expBgSprite.setAnchorPoint(cc.p(0.5, 0.5));
        expBgSprite.setPreferredSize(cc.size(198, 10));
        expBgSprite.setPosition(cc.pAdd(logoSprite.getPosition(), cc.p(0, -79)));
        this.addChild(expBgSprite);

        this._loadingExpBar = new ccui.Scale9Sprite("loading_bar.png");
        this._loadingExpBar.setAnchorPoint(cc.p(0, 0.5));
        this._loadingExpBar.setPreferredSize(cc.size(20, 10));
        this._loadingExpBar.setPosition(cc.pAdd(expBgSprite.getPosition(), cc.p(-99, 0)));
        this.addChild(this._loadingExpBar);

        this._textLabel = new cc.LabelTTF(LocalizedString.Common("連接伺服器中.."), JSFontBoldName, 12);
        this._textLabel.setFontFillColor(JSColor.WHITE);
        this._textLabel.setPosition(cc.pAdd(expBgSprite.getPosition(), cc.p(0, -14)));
        this.addChild(this._textLabel);

        this._beginWidth = this._loadingExpBar.getContentSize().width;
        this._isUseBigLoading = true;

        this.setOpacity(0);

        // 小技巧
        word.enableStroke(JSColor.BLACK, 1.5);
        // 連結伺服器...
        this._textLabel.enableStroke(JSColor.BLACK, 1.5);

        // 持續更新 expBar
        this.schedule(this.scheduleUpdateLoadingExpBar);

        // 記下現在的時間
        this._startTime = new Date().getTime();
        this._isSuccess = false;

        // 開始登入埋點
        EventLogToBigQuery.logEventWithCampaignId(999, 1, 1, {action_log_value: 0});

        // 註冊進入背景 回來前景
        this._backgroundTime = 0;
        this._enterBackgroundListener = GS.addListener(cc.sys.isNative ? "NotifyGameEnterBackground" : cc.game.EVENT_HIDE, () => {
            this._leaveTime = new Date().getTime();
        }, -2);
        this._enterForegroundListener = GS.addListener(cc.sys.isNative ? "NotifyGameEnterForeground" : cc.game.EVENT_SHOW, () => {
            if (this._leaveTime) {
                this._backgroundTime += (new Date().getTime() - this._leaveTime);
                this._leaveTime = undefined;
            }
        }, -2);

        GS.addListener("NotifyUpdataLoading", this.notifyUpdateLoadingBar.bind(this), this);
        GS.addListener("NotifyLoginStatus", this.notifyLoginStatus.bind(this), this);

        // 直接先給他 LoginLoadingStatus.GO_GET_PROXY 因為直接登入會來不及接收到
        var event = new cc.EventCustom("NotifyLoginStatus");
        event.setUserData(LoginLoadingStatus.GO_GET_PROXY);
        this.notifyLoginStatus(event);
    },

    _initWithBigLoadingAndAvatarPosition: function (isAnimation, position, fontColor, background) {
        if (JSCodeUtility.checkType(isAnimation) == JSTYPE.UNDEFINED)
            isAnimation = true;
        position = position || cc.p(100, 100);
        fontColor = fontColor || cc.color(255, 255, 255);
        background = background || SelectGameManager.getNowGameFile("lobby_background.jpg");

        var bgSprite = new cc.Sprite(background);
        bgSprite.setPosition(JSScreenMidPos);
        this.addChild(bgSprite);

        // Avatar sprite
        var avatarSprite = new cc.Sprite(SelectGameManager.getNowGameFile("common_avatar.png"));
        avatarSprite.setPosition(position);
        this.addChild(avatarSprite);

        var gamesofaLogoSprite = new cc.Sprite("#gamesofa_logo.png");
        gamesofaLogoSprite.setPosition(66, JSVisibleSize.height - 14);
        this.addChild(gamesofaLogoSprite);

        // AD BANNER (原始AD大小為 800 * 500)
        var bannerOffset = 12;
        var scale = 0.26;
        var bannerWidth = 800 * scale + bannerOffset;
        var bannerHeight = 500 * scale + bannerOffset;
        var offsetX = 92;

        // AdBg

        var adBackgroundSprite;
        if (cc.loader.getRes("common/loading_ad_bg.png"))
            adBackgroundSprite = new ccui.Scale9Sprite("common/loading_ad_bg.png");     //9t
        else
            adBackgroundSprite = new ccui.Scale9Sprite("loading_ad_bg.png");          //4人

        adBackgroundSprite.setPreferredSize(cc.size(bannerWidth, bannerHeight));
        adBackgroundSprite.setPosition(JSScreenMidPos.x + offsetX, JSScreenMidPos.y + 52);
        this.addChild(adBackgroundSprite, 2);

        // 手機端才需要讀 loadingBannerSerial, 網頁端直接讀預設圖
        if (cc.sys.isNative) {
            var fileNameString = JSWriteablePath + "loadingbanner" + GS.localStorage.getItem("loadingBannerSerial") + ".png";
            var isHaveThisFile = cc.loader.getRes(fileNameString);

            if ((GS.localStorage.getItem("IsShowDefaultLoadingAD") == null || GS.localStorage.getItem("IsShowDefaultLoadingAD")) && isHaveThisFile) {
                var adSprite = new cc.Sprite(fileNameString);
            }
        }

        if (adSprite == null) {
            // 四人系列
            adSprite = new cc.Sprite("common/loading_default_ad.png");
        }

        this.addChild(adSprite, 1);
        adSprite.setScaleX((bannerWidth - bannerOffset) / adSprite.getContentSize().width);
        adSprite.setScaleY((bannerHeight - bannerOffset) / adSprite.getContentSize().height);
        adSprite.setPosition(cc.pAdd(adBackgroundSprite.getPosition(), cc.p(-2, 2)));

        // logo
        var logoSprite = new cc.Sprite(SelectGameManager.getNowGameFile("common_logo.png"));
        logoSprite.setPosition(JSVisibleSize.width / 2.0 + offsetX, JSOriginPoint.y + 98);
        this.addChild(logoSprite);

        // Loading Bar
        var expBgSprite = new ccui.Scale9Sprite("loading_bar_bg.png");
        expBgSprite.setAnchorPoint(cc.p(0.5, 0.5));
        expBgSprite.setPreferredSize(cc.size(200, 8));
        expBgSprite.setPosition(cc.pAdd(logoSprite.getPosition(), cc.p(0, -34)));
        this.addChild(expBgSprite);

        this._loadingExpBar = new ccui.Scale9Sprite("loading_bar.png");
        this._loadingExpBar.setAnchorPoint(cc.p(0, 0.5));
        this._loadingExpBar.setPreferredSize(cc.size(6, 6));
        this._loadingExpBar.setPosition(cc.pAdd(expBgSprite.getPosition(), cc.p(-99, 0)));
        this.addChild(this._loadingExpBar);

        this._textLabel = new cc.LabelTTF(LocalizedString.Common("連接伺服器中.."), JSFontBoldName, 12);
        this._textLabel.setFontFillColor(fontColor);
        this._textLabel.setPosition(cc.pAdd(expBgSprite.getPosition(), cc.p(0, -14)));
        this.addChild(this._textLabel);

        var companyLabel = new cc.LabelTTF(LocalizedString.Login("慧邦科技股份有限公司 Gamesofa Inc. All Rights Reserved."), JSFontBoldName, 9);
        companyLabel.setAnchorPoint(1, 0.5);
        companyLabel.setPosition(JSVisibleSize.width, 7);
        this.addChild(companyLabel);

        this._beginWidth = this._loadingExpBar.getContentSize().width;
        this._isUseBigLoading = true;

        this.setOpacity(0);

        // 持續更新 expBar
        this.schedule(this.scheduleUpdateLoadingExpBar);

        GS.addListener("NotifyUpdataLoading", this.notifyUpdateLoadingBar.bind(this), this);
        GS.addListener("NotifyLoginStatus", this.notifyLoginStatus.bind(this), this);

        // 直接先給他 LoginLoadingStatus.GO_GET_PROXY 因為直接登入會來不及接收到
        var event = new cc.EventCustom("NotifyLoginStatus");
        event.setUserData(LoginLoadingStatus.GO_GET_PROXY);
        this.notifyLoginStatus(event);
    },

    // 創空的 loadingLayer
    _initWithEmpty: function () {
        this._isUseBigLoading = true;
    },

    // 一般讀取畫面
    _init: function () {

        // 背景色
        var bgLayer = new cc.LayerColor(cc.color(0, 0, 0, 190), JSVisibleSize.width, JSVisibleSize.height);
        this.addChild(bgLayer, -10000);

        // GAF動畫
        var self = this;
        gaf.create("gaf/Loading.gaf", this, true, function (gafAsset) {
            if (!gafAsset)
                return;

            var gafObject = gafAsset.createObjectAndRun(true);
            gafObject.setPosition(JSScreenMidPos);
            self.addChild(gafObject);

            gafObject = null;
        });

        // TODO WebView的東西
    },

    onEnter: function () {
        this._super();

        PushScene.addBackKeyEnableLayer(this);
    },

    onExit: function () {
        PushScene.removeBackKeyEnableLayer(this);

        // 通知此畫面被拿掉了 登入Loading才需要
        if (this._isUseBigLoading) {
            // 埋點
            let endTime = new Date().getTime() - this._startTime - this._backgroundTime;
            if (this._isSuccess) {
                // 登入成功
                EventLogToBigQuery.logEventWithCampaignId(999, 1, 2, {action_log_value: endTime});
            } else {
                // 登入失敗
                EventLogToBigQuery.logEventWithCampaignId(999, 1, 3, {action_log_value: endTime});
            }

            // 砍掉Listener
            cc.eventManager.removeListener(this._enterBackgroundListener);
            cc.eventManager.removeListener(this._enterForegroundListener);

            GS.dispatchCustomEvent("NotifyLoadingIsRemoved");
        }

        this._super();
    },

    // AndroidBack
    keyBackPressed: function () {
        // 不做事
    },

    // 設定loading 文字
    setString: function (loadStr) {
        loadStr = loadStr || "";

        this.stopActionByTag(this.CLOSE_LOADING_ACTION_TAG);

        if (this._textLabel) {
            this._textLabel.setString(loadStr);
        } else {
            var textLabel = this._textLabel = new cc.LabelTTF(loadStr, JSFontBoldName, 16, cc.size(0, 0), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
            textLabel.setAnchorPoint(0.5, 1);
            textLabel.setPosition(JSScreenMidPos.x, 85 + JSScreenBonusHalfHeight);
            this.addChild(textLabel);
        }
    },

    // 要不要timeOut
    setNeedTimeOut: function (isNeedTimeOut) {
        if (!JSCodeUtility.checkIsdefined(isNeedTimeOut))
            isNeedTimeOut = true;
        this._isNeedTimeOut = isNeedTimeOut;
        this._refreshAction();
    },

    // 設定timeOut時間
    setTimeOutTime: function (time) {
        this._timeOutTime = time;
        this._refreshAction();
    },

    // 重新計算Timeout
    _refreshAction: function () {
        if (this._isNeedTimeOut) {
            this.stopActionByTag(78209);
            var action1 = cc.delayTime(this._timeOutTime);
            var action2 = cc.callFunc(this._timeout, this);
            var allAction = cc.sequence(action1, action2);
            allAction.setTag(78209);
            this.runAction(allAction);
        } else {
            this.stopActionByTag(78209);
        }
    },

    // 時間到要作的
    _timeout: function () {
        // 斷線
        DataProcess.disconnect(false, true);

        // 踢回登入畫面
        if (!PushScene.isLogin) {
            var reLoginObj = {
                title: LocalizedString.Common("連線錯誤"),
                content: LocalizedString.Common("連線中斷，請檢查網路是否連線再重新連線。")
            };
            if (PushScene.isSlot) {
                // slot走自己的回登入頁流程
                CommonUtility.goLoginScene(reLoginObj);
            } else {
                // 不是在登入頁面
                cc.director.runScene(new LoginScene(reLoginObj));
            }
        } else {
            // 是在登入頁面
        }

        // Post一個訊息出去
        this.dismiss();
        GS.dispatchCustomEvent("NotifyLoadingTimeout");
    },

    // 更新進度條
    scheduleUpdateLoadingExpBar: function (dt) {
        if (this._nowTime < this._endTime) {
            this._nowTime += dt;
            var nextWidth = 0;
            if (this._nowTime >= this._endTime) {
                nextWidth = this._endWidth;
            } else {
                nextWidth = (this._nowTime / this._endTime) * (this._endWidth - this._beginWidth) + this._beginWidth;
            }

            this._loadingExpBar.setPreferredSize(cc.size(nextWidth, this._loadingExpBar.getContentSize().height));
        }
    },

    // loading完成
    delayNotifyLoadingDone: function () {
        GS.dispatchCustomEvent("NotifyLoadingDone");
    },

    // 更新loading 時的畫面
    _updateLoadingBar: function (loadingData) {
        /*
         loadingData = {loadingString: "開始連線..", loadingPercent: 1.0, aniTime: 0.5, isEnd: false}
         loadingString:     Loading文字
         loadingPercent:    這次要跑多少百分比,如果是 0.3 就跑完30%就結束
         aniTime：          總共多少時間
         isEnd:             跑完loadingPercent後要不要跑 End callback
         */

        if (loadingData == null || this._loadingExpBar == null)
            return;

        loadingData.loadingString = LocalizedString.Common(loadingData.loadingString || "");
        loadingData.loadingPercent = loadingData.loadingPercent || 1;
        loadingData.aniTime = loadingData.aniTime || 0.5;
        loadingData.isEnd = loadingData.isEnd || false;

        // 表示到了下一個讀取條,把沒跑完的bar 跑完
        // this._loadingExpBar.setPreferredSize(cc.size(this._endWidth, this._loadingExpBar.getContentSize().height));

        this._beginWidth = this._loadingExpBar.getContentSize().width;
        this._endWidth = this.BIG_LOADING_BAR_BEGIN_WIDTH + (this.BIG_LOADING_BAR_END_WIDTH - this.BIG_LOADING_BAR_BEGIN_WIDTH) * loadingData.loadingPercent;
        this._nowTime = 0;
        this._endTime = loadingData.aniTime;
        this._textLabel.setString(loadingData.loadingString);

        this._refreshAction();   //重新更新時間

        // 判斷是否要換Scene
        if (loadingData.isEnd) {
            // 關掉timeout
            this.stopActionByTag(78209);

            var action1 = cc.delayTime(loadingData.aniTime + 0.1);
            var action2 = cc.callFunc(function () {
                this.delayNotifyLoadingDone();
            }, this);
            this.runAction(cc.sequence(action1, action2));
        }

        // 登入失敗ErrorLog
        var logString = "Loading" + loadingData.loadingString;
        GS.dispatchCustomEvent("NotifyLoginErrorLog", logString);
    },

    /**
     * 登入成功 要進入大廳或遊戲
     */
    _loginSuccess: function () {
        this._isSuccess = true;
    },


    // 開
    show: function () {
        this.stopActionByTag(this.CLOSE_LOADING_ACTION_TAG);
        if (this._isUseFadeAnimation) {
            this.setOpacity(0);
            this.runAction(cc.fadeIn(0.4));
        } else {
            this.setOpacity(255);
        }
    },

    // 關
    dismiss: function () {
        // 先把Android Back key拿掉
        PushScene.removeBackKeyEnableLayer(this, false);

        if (this._isUseBigLoading) {
            this.removeFromParent();
        } else {
            var action1 = cc.fadeOut(0.4);
            var action2 = cc.removeSelf(true);
            var allAction = cc.sequence(action1, action2);
            allAction.setTag(this.CLOSE_LOADING_ACTION_TAG);
            this.runAction(allAction);
        }
    },

    /**
     * 通知
     */
    // 通知連線的進度
    notifyLoginStatus: function (event) {
        var status = event.getUserData();
        switch (status) {
            case LoginLoadingStatus.NONE:
                this._updateLoadingBar({
                    loadingString: LocalizedString.Common("開始連線.."),
                    loadingPercent: 0,
                    aniTime: 0
                });
                break;
            case LoginLoadingStatus.GO_GET_PROXY:
                this._updateLoadingBar({
                    loadingString: LocalizedString.Common("開始連線.."),
                    loadingPercent: 0.3,
                    aniTime: 4.0
                });
                break;
            case LoginLoadingStatus.SOCKET_CONNECT:
                this._updateLoadingBar({
                    loadingString: LocalizedString.Common("載入設定.."),
                    loadingPercent: 0.4,
                    aniTime: 1.0
                });
                break;
            case LoginLoadingStatus.SOCKET_DONE:
                this._updateLoadingBar({
                    loadingString: LocalizedString.Common("伺服器連線.."),
                    loadingPercent: 0.6
                });
                break;
            case LoginLoadingStatus.LOBBY26_DONE:
                this._updateLoadingBar({
                    loadingString: LocalizedString.Common("連線到大廳(1/2).."),
                    loadingPercent: 0.7
                });
                break;
            case LoginLoadingStatus.CONNECT_INFO_DONE:
                this._updateLoadingBar({
                    loadingString: LocalizedString.Common("連線到大廳(2/2).."),
                    loadingPercent: 0.8
                });
                break;
            case LoginLoadingStatus.LOGIN_DONE:
                this._updateLoadingBar({
                    loadingString: LocalizedString.Common("讀取個人資料.."),
                    loadingPercent: 0.9
                });
                break;
            case LoginLoadingStatus.SESSION_STATUS_DONE:
                this._updateLoadingBar({
                    loadingString: LocalizedString.Common("成功進入大廳.."),
                    loadingPercent: 1,
                    aniTime: 0.35,
                    isEnd: true
                });
                break;
            case LoginLoadingStatus.START_mRC:
                this._updateLoadingBar({
                    loadingString: LocalizedString.Common("讀取個人資料.."),
                    loadingPercent: 0.95
                });
                // 登入成功
                this._loginSuccess();
                break;
            case LoginLoadingStatus.END_TO_LOBBY:
                this._updateLoadingBar({
                    loadingString: LocalizedString.Common("成功進入大廳.."),
                    loadingPercent: 1,
                    aniTime: 0.15,
                    isEnd: true
                });
                // 登入成功
                this._loginSuccess();
                break;
            case LoginLoadingStatus.END_TO_GAME:
                this._updateLoadingBar({
                    loadingString: LocalizedString.Common("準備導回遊戲中.."),
                    loadingPercent: 0.99,
                    aniTime: 0.35
                });
                // 登入成功
                this._loginSuccess();
                break;
        }
    },

    /**
     * 通知
     */
    // 大 Loading
    notifyUpdateLoadingBar: function (event) {
        if (event) {
            var result = event.getUserData();
            this._updateLoadingBar(result);
        }
    }
});
