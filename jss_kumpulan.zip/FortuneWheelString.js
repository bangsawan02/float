var LocalizedString = LocalizedString || {};

(function () {
    var keyValue = {
        "儲值成功!": "Pembelian berhasil!",
        "別浪費你的好運氣!\n小幫手自動幫您旋轉喔!": "Jangan habiskan kerberuntungan Anda!\nAkan secara otomatis bantu Anda spin!",
        "就是要離開": "Keluar",
        "珍惜好運氣": "Coba putar",
        "OK": "OK",
        "恭喜您獲得": "Selamat Anda mendapatkan"
    };

    LocalizedString.FortuneWheel = function (str) {
        return USE_i18n ? (keyValue[str] || str) : str;
    };
})();