/**
 * 無Avatar的Dialog
 obj = {
        loadFileArray: ["xxx.plist", "xxx.png"],    // 需要讀取的素材
        key: ""                         //Dialog Key
        bgSize: ""                      //背景尺寸
        title: "",                      //標題
        content: "",                    //內文
        buttons: ["title"],             //按鈕的文字
        btnFontColors: [cc.color],      //按鈕的文字顏色
        buttonHints: [""],              //有的話 按鈕的文字要往上一點
        btnImages: [],                  //按鈕背景圖片
        btnSize: "",                    //按鈕大小
        btnIcons: [],                   //按鈕文字旁的icon
        btnIconScales: [],              //按鈕文字旁的icon縮放大小
        callback: cb,                   //Callback
        contentLeft : "0",              //內文置左 (給條列式訊息使用,預設置中)
        tip: "",                        //最下方的小提示
        closeButton: 1,                 //是否要右上角X按鈕
    }

 按鈕顯示由左至右
 *
 */

var Dialog = BaseDialogLayer.extend({
    ctor: function (obj) {
        this._super();

        this.obj = obj;

        // 需要讀取的素材
        this.loadFileArray = obj.loadFileArray || [];
    },

    onExit: function () {
        if (this._loadFileDone && this.loadFileArray.length) {
            for (let i = 0, len = this.loadFileArray.length; i < len; i += 2) {
                cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[i]);
            }
        }

        this._super();
    },

    /**
     * 讀取素材完畢
     * @override
     */
    loadFileDone: function () {
        this._super();

        if (this.loadFileArray.length) {
            for (var i = 0; i < this.loadFileArray.length; i += 2) {
                cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[i], this.loadFileArray[i + 1]);
            }
        }

        // 預設值
        var obj = this.obj;
        this.key = obj.key || "";
        obj.bgSize = obj.bgSize || GSEnum.DialogSize.MIDDLE;
        obj.contentLeft = obj.contentLeft ? 1 : 0;
        obj.buttons = obj.buttons ? obj.buttons : [LocalizedString.Common("確定")];
        obj.btnFontColors = obj.btnFontColors || [];
        obj.buttonHints = obj.buttonHints || [];
        obj.btnImages = obj.btnImages || [];
        obj.btnIcons = obj.btnIcons || [];
        obj.btnIconScales = obj.btnIconScales || [];
        obj.closeButton = obj.closeButton === undefined ? 1 : obj.closeButton;
        obj.closeLight = obj.closeLight === undefined ? 1 : obj.closeLight;
        obj.titleFontSize = obj.titleFontSize || 19;

        var aniLayer = this._animationLayer;

        // 背景底
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(obj.bgSize);
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite, -1);

        if (obj.closeLight) {
            var lightSprite = new cc.Sprite("#lobby_pic_pink_light.png");
            lightSprite.setScale(100, 50);
            lightSprite.setPosition(JSScreenMidPos);
            aniLayer.addChild(lightSprite, -1);
        }

        var titleMidPosX = JSScreenMidPos.x;

        // 標題 圖或文
        var title = obj.title;
        if (title && title.length > 0) {
            var titleMessage;
            var titlePosY = JSScreenMidPos.y + obj.bgSize.height / 2 - 24;
            if (JSStringUtility.containString(title, ".png")) {
                // title 是圖
                titleMessage = new cc.Sprite(title);
            } else {
                //文字
                titleMessage = new GSRichTextNode(title, JSFontBoldName, obj.titleFontSize, cc.size(obj.bgSize.width - 70, 0));
                titleMessage.setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                titleMessage.setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
            }
            titleMessage.setPosition(titleMidPosX, titlePosY);
            aniLayer.addChild(titleMessage);

            // 分隔線
            var lineSprite = new cc.Sprite("#lobby_division_line.png");
            lineSprite.setScaleX(JSIsPortrait ? 20 : 30);
            lineSprite.setPosition(titleMidPosX, titlePosY - titleMessage.getContentSize().height / 2 - 5);
            aniLayer.addChild(lineSprite);
        }

        // 內文
        var messageLabel = new GSRichTextNode(obj.content, JSFontBoldName, 13, cc.size(obj.bgSize.width - 10, 0));
        messageLabel.setTextHorizontalAlignment(obj.contentLeft ? cc.TEXT_ALIGNMENT_LEFT : cc.TEXT_ALIGNMENT_CENTER);
        messageLabel.setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        messageLabel.setPosition(titleMidPosX, JSScreenMidPos.y + 1);
        aniLayer.addChild(messageLabel);

        // 按鈕
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        aniLayer.addChild(menu);

        var btnLen = obj.buttons.length;
        var btnSize = obj.btnSize || cc.size(btnLen === 3 ? 100 : 125, 30);
        var basePos = cc.p(titleMidPosX, JSScreenMidPos.y - obj.bgSize.height / 2 + btnSize.height / 2 + 12);
        var tx = basePos.x;
        var ty = basePos.y;
        var paddingX = 11;

        // 一個按鈕置中 其它要往左邊對齊
        if (btnLen === 2) {
            tx -= (btnSize.width + paddingX) / 2;
        } else if (btnLen === 3) {
            tx -= (btnSize.width + paddingX);
        }

        this._buttons = [];
        obj.buttons.forEach((cur, index) => {
            var btnImage = obj.btnImages[index] || "lobby_btn_01.png";
            var btnFontColor = obj.btnFontColors[index] || JSColor.BLACK;
            var btnIcon = obj.btnIcons[index];
            var btnIconScale = obj.btnIconScales[index];
            var btnItem = ButtonUtility.createSingleScale9NodesWithIcon(btnImage, btnSize, btnIcon, btnIconScale, cur, 12, btnFontColor, 2);
            btnItem[1].label.setOpacity(150);
            var btn = new cc.MenuItemSprite(btnItem[0], btnItem[1], this._buttonClicked, this);
            btn.setPosition(tx, ty);
            menu.addChild(btn);
            this._buttons.push(btn);

            // 判斷是否有提示文字
            var hint = obj.buttonHints[index];
            if (hint) {
                // 文字要往上一些
                btnItem.forEach((btn) => {
                    var label = btn.label;
                    label.setPositionY(label.getPositionY() + 6);

                    // 加提示文字
                    var hintLabel = new cc.LabelTTF(hint, JSFontBoldName, 10);
                    hintLabel.setFontFillColor(JSColor.BLACK);
                    hintLabel.setPosition(cc.pAdd(label.getPosition(), cc.p(0, -12)));
                    btn.addChild(hintLabel);
                });
            }

            tx += btn.getContentSize().width + paddingX;
        });

        if (obj.tip) {
            // 有最下方的小提示
            var tip = new GSRichTextNode(obj.tip, JSFontBoldName, 10);
            tip.setPosition(titleMidPosX, 43 + JSScreenBonusHalfHeight);
            aniLayer.addChild(tip);
        }

        this._callback = obj.callback;

        // 離開按鈕
        if (obj.closeButton) {
            var closeBtn = ButtonUtility.createSimpleImageButton("lobby_btn_circle_04.png", null, "#lobby_btn_pic_window_x.png");
            closeBtn.setPosition(JSScreenMidPos.x + obj.bgSize.width / 2 - 5, JSScreenMidPos.y + obj.bgSize.height / 2 - 5);
            closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
            aniLayer.addChild(closeBtn);
        }
    },

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        if (this.isLockBackKey) {
            return;
        }

        if (this._callback)
            this._callback(-1);

        this._closeDialogAnimation();
    },

    /**
     * 按鈕
     */
    // 關掉畫面
    _closeBtnClicked: function () {
        if (this._callback)
            this._callback(-1);

        this._closeDialogAnimation();
    },

    _buttonClicked: function (sender) {
        var index = 0;
        for (var i = 0; i < this._buttons.length; i++) {
            if (this._buttons[i] === sender) {
                index = i;
                break;
            }
        }

        if (this._callback)
            this._callback(index);

        this._closeDialogAnimation();
    }
});

var CommonDialog = Dialog;