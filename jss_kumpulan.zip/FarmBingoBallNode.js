/**
 * v5.6.0 齋戒副系統 賓果球 node
 * @param number {int} 球號
 */
var FarmBingoBallNode = cc.Node.extend({
    ctor: function (number) {
        this._super();

        // 背景
        var bgSprite = new cc.Sprite("#farm_bingo_pic_waterer.png");
        this.addChild(bgSprite);

        // 球號
        var numLabel = new GSSpriteNumberNode({
            number: number,
            numStr: "#farm_bingo_num_p_",
            spW: 12,
            spH: 18
        });
        numLabel.setScale(1.2);
        numLabel.setPosition(8, -3);
        this.addChild(numLabel);

        this.setCascadeOpacityEnabled(true);
    }
});