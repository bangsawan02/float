/**
 * 牌王地圖每個節點上的泡泡匡
 */

var CardKingMapPlayerBubbleNode = cc.Node.extend({
    ctor: function (level, round) {
        this._super();

        // 局數等級
        this._level = level;
        this._round = round;

        this._data = null;

        this.setContentSize(cc.size(130, 100));

        this._viewRect = cc.rect(-65, -50, 130, 100);

        // 中間tableView
        var tableView = this._tableView = new cc.TableView(this, cc.size(130, 75), new cc.Layer());
        tableView.setDataSource(this);
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setPosition(-65, -40);
        tableView.setTouchEnabled(false);
        this.addChild(tableView);

        // 共多少人
        var totalPeople = this._totalPeople = new cc.LabelTTF("", JSFontName, 12);
        totalPeople.setFontFillColor(JSColor.RED);
        totalPeople.setPosition(0, 47);
        this.addChild(totalPeople);

        // 加一條線
        var lineSprite = new cc.Sprite("#users_line.png");
        lineSprite.setScaleX(3.75);
        lineSprite.setPosition(0, 38);
        this.addChild(lineSprite);

        var label = new cc.LabelTTF("...", JSFontName, 14);
        label.setFontFillColor(JSColor.BLACK);
        label.setPosition(0, -43);
        this.addChild(label);

        var loadingSp = this._loadingSp = new GSLoadingSprite();
        loadingSp.setColor(JSColor.GRAY);
        loadingSp.setScale(0.7);
        this.addChild(loadingSp);

        // 先去檢查資料裡面有沒有, 沒有再要
        if (DataModal.cardKingData.getNodeDetail(this._level, this._round)) {
            this.refresh();
        } else {
            DataModal.cardKingData.startGetNodeInfo(this._level, this._round);
            loadingSp.start();
        }

        // 加觸碰, 碰到其他地方關掉這個東西
        var listener = cc.EventListener.create({
            event: cc.EventListener.TOUCH_ONE_BY_ONE
        });
        listener.onTouchBegan = this.onTouchBegan.bind(this);
        listener.setSwallowTouches(true);
        cc.eventManager.addListener(listener, this);

        GS.addListener("NotifyCardKingMapNodeDetailDone", this.notifyCardKingMapNodeDetailDone.bind(this), this);
    },

    refresh: function () {
        var data = this._data = DataModal.cardKingData.getNodeDetail(this._level, this._round);

        if (data) {
            this._loadingSp.stop();

            this._totalPeople.setString(JSStringUtility.format(LocalizedString.CardKing("共%s人"), TexasUtility.getSimpleMoneyString(data.totalCount)));

            this._tableView.reloadData(true);
        }
    },

    /**
     * TableView delegate
     */
    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();
        if (this._data) {
            if (!cell)
                cell = new CardKingMapPlayerBubbleCell();

            cell.refresh(this._data.playerList[idx], idx === (this._data.playerList.length - 1));
        }
        return cell;
    },

    numberOfCellsInTableView: function (table) {
        if (this._data)
            return this._data.playerList.length;

        return 0;
    },

    tableCellSizeForIndex: function (table, idx) {
        return cc.size(CardKingMapPlayerBubbleCell.WIDTH, CardKingMapPlayerBubbleCell.HEIGHT);
    },

    notifyCardKingMapNodeDetailDone: function () {
        this.refresh();
    },

    // touch
    onTouchBegan: function (touch) {
        for (var c = this; c != null; c = c.parent) {
            if (!c.isVisible() || this._direction == cc.SCROLLVIEW_DIRECTION_NONE)
                return false;
        }

        var pos = this.convertTouchToNodeSpace(touch);

        if (cc.rectContainsPoint(this._viewRect, pos))
            return true;

        // 按到框框外,就關掉
        GS.dispatchCustomEvent("NotifyCardKingMapCloseBubble");

        return false;
    }
});