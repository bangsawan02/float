/**
 * 9T 幸運彩票 - 我的彩券 Top Cell
 */

var BigLotteryMyTicketTopCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        var cellSize = cc.size(BigLotteryMyTicketTopCell.WIDTH, BigLotteryMyTicketTopCell.HEIGHT);
        var midPosX = cellSize.width / 2;
        var midPosY = cellSize.height / 2;

        var noTicketCellSize = cc.size(BigLotteryMyTicketTopCell.WIDTH, BigLotteryMyTicketTopCell.NO_TICKET_HEIGHT);
        var noTicketMidPosY = noTicketCellSize.height / 2;

        // 沒有票
        {
            // 沒有票的node
            var noTicketNode = this._noTicketNode = new cc.Node();
            noTicketNode.setVisible(false);
            noTicketNode.setPosition(midPosX, noTicketMidPosY);
            this.addChild(noTicketNode);

            // 背景
            var bgSprite = new ccui.Scale9Sprite("bigLottery_bg_redLine02.png");
            bgSprite.setPreferredSize(cc.size(400, 120));
            bgSprite.setPositionY(-44);
            noTicketNode.addChild(bgSprite);

            // Domino移植設定 調整位移
            // 文字: 您目前彩券...尚未選號別錯過頭獎
            var hintLabel = new cc.Sprite("#bigLottery_word_notChooseHint.png");
            hintLabel.setPositionY(-44);
            noTicketNode.addChild(hintLabel);
        }

        // 頭獎
        {
            // 頭獎的node
            var winnerNode = this._winnerNode = new cc.Node();
            winnerNode.setPosition(midPosX, midPosY);
            winnerNode.setVisible(false);
            this.addChild(winnerNode);

            // 本期結果
            var wordSprite = new cc.Sprite("#bigLottery_word_currentResult.png");
            wordSprite.setPosition(144, 22);
            winnerNode.addChild(wordSprite);

            // 期號
            var periodLabel = this._periodLabel = new cc.LabelTTF("", JSFontName, 12);
            periodLabel.setFontFillColor(JSColor.YELLOW);
            periodLabel.setPosition(144, 4);
            winnerNode.addChild(periodLabel);

            // 格子
            var startPosX = -135;
            this._winnerNumNodeList = [];
            for (var i = 0; i < 5; i++) {
                // 背景
                var numBgSprite = new cc.Sprite("#bigLottery_pic_ball.png");
                numBgSprite.setPosition(startPosX + 1, 10);
                winnerNode.addChild(numBgSprite);

                // 數字
                var numNode = this._winnerNumNodeList[i] = new GSSpriteNumberNode({
                    number: 0,
                    numStr: "#bigLottery_word_ticket_",
                    spW: 10
                });
                numNode.setPosition(startPosX, 11);
                winnerNode.addChild(numNode);

                startPosX += 45;
            }
        }

        // 主要的東西
        {
            var mainNode = this._mainNode = new cc.Node();
            this.addChild(mainNode);

            // Domino移植設定 使用AutoLayoutNode排版
            // 裝文字的node
            var labelNode = this._labelNode = new GSAutoLayoutNode();
            labelNode.setPosition(midPosX - 52, midPosY + 11);
            mainNode.addChild(labelNode);

            // 按鈕
            var menu = new cc.Menu();
            menu.setPosition(0, 0);
            mainNode.addChild(menu);

            // 選號按鈕
            var images = ["lobby_btn_03.png", "lobby_btn_06.png", "lobby_btn_06.png"];
            var itemNode = ButtonUtility.createArrayScale9Nodes(images, cc.size(85, 35), LocalizedString.BigLottery("選號"), 14, [JSColor.WHITE, JSColor.WHITE, JSColor.GRAY]);
            itemNode.forEach((cur, index) => {
                var strokeColor = (index === 2) ? JSColor.BLACK : cc.color(0, 35, 90, 255);
                cur.label.enableStroke(strokeColor, 2);
            });
            itemNode[2].setOpacity(255);
            var selectBtn = this._selectBtn = new cc.MenuItemSprite(itemNode[0], itemNode[1], itemNode[2], this._selectClicked, this);
            selectBtn.setPosition(midPosX + 148, midPosY + 11);
            menu.addChild(selectBtn);

            // 中間線
            var lineSprite = new ccui.Scale9Sprite("bigLottery_pic_line.png");
            lineSprite.setPreferredSize(cc.size(400, 4));
            lineSprite.setPosition(midPosX, midPosY - 45);
            mainNode.addChild(lineSprite);
        }
    },

    /**
     * 刷新畫面
     * @param isOnlyTopCell     只有一個top cell 用來排版用
     */
    refreshCell: function (isOnlyTopCell) {
        var bigLotteryData = DataModal.bigLotteryData;
        var myTicketParam = bigLotteryData.myTicketParam;
        var bigLotteryStr = LocalizedString.BigLottery;

        if (myTicketParam) {
            if (isOnlyTopCell) {
                var offSetPosY = BigLotteryMyTicketTopCell.NO_TICKET_HEIGHT - BigLotteryMyTicketTopCell.HEIGHT;
                this._mainNode.setPositionY(offSetPosY);

                this._noTicketNode.setVisible(true);
            } else {
                this._mainNode.setPositionY(0);

                this._noTicketNode.setVisible(false);
            }

            this._selectBtn.setEnabled(false);
            this._selectBtn.setVisible(true);

            var labelNode = this._labelNode;
            labelNode.removeAllChildren();
            labelNode.setType(GSAutoLayout.TYPE.HORIZONTAL);

            this._winnerNode.setVisible(false);

            // 選票狀態字串處理
            var status = bigLotteryData.status;
            if (status === BigLotteryData.Status.NORMAL || status === BigLotteryData.Status.CANNOT_BUY) {
                // 全部選完了
                if (myTicketParam.notSelectTicketNum === 0) {
                    var label = new cc.LabelTTF(JSStringUtility.format(bigLotteryStr("您目前共有%d張彩卷，祝您中頭獎!"), myTicketParam.totalTicketNum), JSFontName, 14, cc.size(300, 35));
                    label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                    label.enableStroke(cc.color(190, 30, 0, 255), 2);
                    labelNode.addChild(label);

                } else {
                    // 打開選號按鈕
                    this._selectBtn.setEnabled(true);

                    var label = new cc.LabelTTF(JSStringUtility.format(bigLotteryStr("您目前有%d張彩票，有%d張尚未選號"), myTicketParam.totalTicketNum, myTicketParam.notSelectTicketNum), JSFontName, 14, cc.size(300, 35));
                    label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                    label.enableStroke(cc.color(190, 30, 0, 255), 2);
                    labelNode.addChild(label);
                }
            } else if (status === BigLotteryData.Status.CANNOT_SELECT || status === BigLotteryData.Status.AUTO_SELECT_FINISH) {
                // 開獎前15分鐘 有不能選號>電腦選號狀態
                if (myTicketParam.autoSelectTicketNum) {
                    // 有電腦選號的彩券
                    var label = new cc.LabelTTF(JSStringUtility.format(bigLotteryStr("您%d張彩票未在開獎前15分鐘完成選號，電腦已幫您自動選號完成"), myTicketParam.autoSelectTicketNum), JSFontName, 14, cc.size(300, 35));
                    label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                    label.enableStroke(cc.color(190, 30, 0, 255), 2);
                    labelNode.addChild(label);
                } else {
                    var label = new cc.LabelTTF(JSStringUtility.format(bigLotteryStr("您目前共有%d張彩卷，祝您中頭獎!"), myTicketParam.totalTicketNum), JSFontName, 14, cc.size(300, 35));
                    label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                    label.enableStroke(cc.color(190, 30, 0, 255), 2);
                    labelNode.addChild(label);
                }
            } else {
                // 12:00後(重置中或sever開獎完狀態)
                if (myTicketParam.drawNumList.length) {

                    // 有開獎要出現頭獎獎號
                    this._selectBtn.setVisible(false);
                    this._winnerNode.setVisible(true);

                    // 數字
                    myTicketParam.drawNumList.forEach((cur, index) => {
                        this._winnerNumNodeList[index].setNumber(cur);
                    });

                    // 期數
                    this._periodLabel.setString(JSStringUtility.format("(%s)", bigLotteryData.period));
                } else {
                    // Domino移植設定 server還沒開獎 顯示稍等開獎文案
                    var label = new cc.LabelTTF(JSStringUtility.format(bigLotteryStr("開獎中，稍後顯示中獎號碼"), myTicketParam.totalTicketNum), JSFontName, 14, cc.size(300, 35));
                    label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                    label.enableStroke(cc.color(190, 30, 0, 255), 2);
                    labelNode.addChild(label);
                }
            }

            // 跑馬燈
            {
                // 如果有創過先拿掉
                if (this._marqueeNode) {
                    this._marqueeNode.stopAllActions();
                    this._marqueeNode.removeFromParent();
                }
                var marqueeList = myTicketParam.marqueeList;

                // 跑馬燈
                if (marqueeList.length > 0) {

                    var marqueeWidth = BigLotteryMyTicketTopCell.WIDTH - 20;
                    var marqueeHeight = 20;

                    var marqueeNode = this._marqueeNode = new cc.Node();
                    marqueeNode.setPosition(BigLotteryMyTicketTopCell.WIDTH / 2, BigLotteryMyTicketTopCell.HEIGHT / 2 - 30);
                    this._mainNode.addChild(marqueeNode);

                    var bgColorLayer = new ccui.Scale9Sprite("lobby_pic_black.png");
                    bgColorLayer.setPreferredSize(cc.size(marqueeWidth, marqueeHeight));
                    marqueeNode.addChild(bgColorLayer);

                    // Domino移植設定 跑馬燈輪播
                    var marquee = this._marquee = new MarqueeNode({
                        width: marqueeWidth,
                        height: marqueeHeight,
                        fontSize: 12,
                        isLoop: true,
                        sec: 7,
                        disableBG: true
                    });
                    marqueeNode.addChild(marquee);

                    // 輪播
                    var currentIndex = 0;
                    marqueeNode.runAction(cc.sequence(
                        cc.callFunc(() => {
                            marquee.push({
                                color: JSColor.WHITE,
                                message: marqueeList[currentIndex]
                            });
                            currentIndex = (currentIndex + 1) % marqueeList.length;
                        }),
                        cc.delayTime(7)
                    ).repeatForever());
                }
            }
        }
    },

    /**
     * 按鈕
     */

    // 點擊馬上選號按鈕
    _selectClicked: function () {
        MusicUtility.playEffect("Music/Effect/e_clickButton.mp3", false);

        // 抓資料
        var myTicketParam = DataModal.bigLotteryData.myTicketParam;
        var bigLotteryStr = LocalizedString.BigLottery;

        // 跳dialog
        var param = {
            key: "BigLotteryBeforeSelectDialog",
            bgSize: cc.size(400, 153),
            content: JSStringUtility.format(bigLotteryStr("您有#!FF0000!#%d張#!FFFFFF!#未選號的彩券\n請選擇選號方式"), myTicketParam.notSelectTicketNum),
            buttons: ["電腦選號", "自己選號"].map(string => bigLotteryStr(string)),
            closeButton: true,
            callback: (index) => {
                // 點擊電腦選號
                if (index === 0) {
                    // 跳電腦選號dialog
                    DialogManager.addDialog(new BigLotteryAutoSelectDialog(), false);
                }
                // 點自己選號
                else if (index === 1) {
                    // 跳自己選號dialog
                    DialogManager.addDialog(new BigLotterySelectDialog(), false);
                }
            }
        };
        DialogManager.addDialog(new BigLotteryCommonDialog(param), false);
    }
});

// Cell寬
BigLotteryMyTicketTopCell.WIDTH = 418;

// Cell高
BigLotteryMyTicketTopCell.HEIGHT = 94;

// 沒有票的Cell高
BigLotteryMyTicketTopCell.NO_TICKET_HEIGHT = 228;
