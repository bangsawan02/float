/**
 * Poker13 特效集中區
 */

var CapsaSusun_ScoreLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this.clean();

        // 創要做分數的動畫
        this._scoreNodeArray = [];
        for (var i = 0; i < DataModal.gameData.playerNumber; i++) {
            // 在玩家身上的動畫都會放在這裡
            var pos = CapsaSusun_GameUtility.getCardStacksMidPos(i);
            var animNode = this._scoreNodeArray[i] = new CapsaSusun_ScoreAnimNode(i);
            animNode.setPosition(pos);
            this.addChild(animNode);
        }
    },

    // 清掉分數動畫
    clean: function () {
        this._scoreNodeArray && this._scoreNodeArray.forEach(cur => {
            cur.clean();
        });
    },

    // 更新總分
    updateAllPlayersScore: function (posArray, totalScore) {
        if (!posArray.length)
            return;

        posArray.forEach(cur => {
            var direction = DataModal.gameData.getDirectionByServerDirection(cur);
            var score = totalScore[cur];
            this._scoreNodeArray[direction].updateTotalScore(score);
        });
    },

    // 一般比牌
    showNormalFightAllScore: function (posArray, scoreArray, mySpScore, isMeSpecial, isSkipAnim) {
        if (!posArray.length)
            return;

        var myPos = DataModal.gameData.myPos;
        var myDirection = DataModal.gameData.getDirectionByServerDirection(myPos);
        if (isSkipAnim) {
            posArray.forEach(pos => {
                var direction = DataModal.gameData.getDirectionByServerDirection(pos);
                // 更新分數
                scoreArray[0] && this._scoreNodeArray[direction].addStackScore(0, scoreArray[0][pos], mySpScore[0]);
                scoreArray[1] && this._scoreNodeArray[direction].addStackScore(1, scoreArray[1][pos], mySpScore[1]);
                scoreArray[2] && this._scoreNodeArray[direction].addStackScore(2, scoreArray[2][pos], mySpScore[2]);
                if (pos !== myPos && scoreArray[3])
                    this._scoreNodeArray[direction].updateTotalScore(scoreArray[3][pos]);
            });

            // 假如自己是特殊牌也是要更新分數
            if (isMeSpecial) {
                this._scoreNodeArray[myDirection].addStackScore(0, 0, 0);
                this._scoreNodeArray[myDirection].addStackScore(1, 0, 0);
                this._scoreNodeArray[myDirection].addStackScore(2, 0, 0);
            }
        } else {
            // 照順序開始翻開
            this.runAction(
                cc.sequence(
                    cc.delayTime(0.45),
                    cc.callFunc(() => {
                        posArray.forEach(pos => {
                            var direction = DataModal.gameData.getDirectionByServerDirection(pos);
                            // 更新分數
                            scoreArray[0] && this._scoreNodeArray[direction].addStackScore(0, scoreArray[0][pos], mySpScore[0]);
                        });

                        // 假如自己是特殊牌也是要更新分數
                        if (isMeSpecial)
                            this._scoreNodeArray[myDirection].addStackScore(0, 0, 0);
                    }),
                    cc.delayTime(0.75),
                    cc.callFunc(() => {
                        posArray.forEach(pos => {
                            var direction = DataModal.gameData.getDirectionByServerDirection(pos);
                            // 更新分數
                            scoreArray[1] && this._scoreNodeArray[direction].addStackScore(1, scoreArray[1][pos], mySpScore[1]);
                        });

                        // 假如自己是特殊牌也是要更新分數
                        if (isMeSpecial)
                            this._scoreNodeArray[myDirection].addStackScore(1, 0, 0);
                    }),
                    cc.delayTime(0.75),
                    cc.callFunc(() => {
                        posArray.forEach(pos => {
                            var direction = DataModal.gameData.getDirectionByServerDirection(pos);
                            // 更新分數
                            scoreArray[2] && this._scoreNodeArray[direction].addStackScore(2, scoreArray[2][pos], mySpScore[2]);
                        });

                        // 假如自己是特殊牌也是要更新分數
                        if (isMeSpecial)
                            this._scoreNodeArray[myDirection].addStackScore(2, 0, 0);

                    }),
                    cc.delayTime(0.3),
                    cc.callFunc(() => {
                        posArray.forEach(pos => {
                            var direction = DataModal.gameData.getDirectionByServerDirection(pos);
                            // 更新分數
                            if (pos !== myPos)
                                scoreArray[3] && this._scoreNodeArray[direction].updateTotalScore(scoreArray[3][pos]);
                        });
                    })
                )
            );
        }
    },

    // 特殊比牌
    showSpecialScore: function (posArray, scoreArray) {
        posArray.forEach(pos => {
            var direction = DataModal.gameData.getDirectionByServerDirection(pos);

            // 更新分數
            this._scoreNodeArray[direction].updateTotalScore(scoreArray[pos]);
        });
    },

    // 更新某個位置的總分
    updateTotalScoreByDirection: function (direction, score, isAnim) {
        this._scoreNodeArray[direction].updateTotalScore(score, isAnim);
    },

    // 更新全壘打的分數
    updateHomeRunScore: function (homeRunInfo) {
        // 更新總分顯示
        var totalScore = homeRunInfo.totalScoreArray;
        var winServerDir = homeRunInfo.winServerDir;
        var winnerScore = totalScore[winServerDir];
        var loseDirArray = homeRunInfo.loseServerDirArray;
        for (var n = 0; n < loseDirArray.length; n++) {
            var loseServerDir = loseDirArray[n];
            var winDir = DataModal.gameData.getDirectionByServerDirection(winServerDir);
            var loseDir = DataModal.gameData.getDirectionByServerDirection(loseServerDir);
            this._scoreNodeArray[winDir].updateTotalScore(winnerScore);
            this._scoreNodeArray[loseDir].updateTotalScore(totalScore[loseServerDir]);
        }
    }
});

