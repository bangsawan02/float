/**
 * v5.5.1 夾娃娃機挑戰-獎勵顯示Dialog
 * created by Jim.Chen
 */

var ClawMachineChallengeSystemMessageDialog = BaseDialogLayer.extend({
    ctor: function (messageArray) {
        this._super();

        this.key = "ClawMachineChallengeSystemMessageDialog";
        this.isLockBackKey = true;

        // 訊息array
        this._messageArray = messageArray || [];

        var animLayer = this._animationLayer;

        // 背景
        var bg = new ccui.Scale9Sprite("clawMachineChallenge_pic_frame_01.png", cc.rect(30, 30, 20, 20));
        bg.setPreferredSize(cc.size(315, 195));
        bg.setPosition(JSScreenMidPos);
        animLayer.addChild(bg);

        // 內文背景
        var contentBg = new ccui.Scale9Sprite("clawMachineChallenge_pic_frame_02.png", cc.rect(8, 8, 12, 12));
        contentBg.setPreferredSize(cc.size(230, 85));
        contentBg.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 4);
        animLayer.addChild(contentBg);

        // 加ScrollView
        var scrollViewSize = this._scrollViewSize = cc.size(215, 75);
        var mainLayer = this._mainLayer = new cc.Layer();
        var scrollView = this._scrollView = new cc.ScrollView(scrollViewSize, mainLayer);
        scrollView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        scrollView.setPosition(JSScreenMidPos.x - 105, JSScreenMidPos.y - 33);
        animLayer.addChild(scrollView);
        // 先設成看不見避免殘影
        scrollView.setVisible(false);

        // 恭喜獲得標題
        var titleLabel = new cc.LabelTTF(LocalizedString.Purchase("恭喜獲得"), JSFontName, 14);
        titleLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 60);
        animLayer.addChild(titleLabel);

        // 確定按鈕
        var button = this._confirmBtn = ButtonUtility.createSimpleButton("lobby_btn_01.png", cc.size(100, 30), LocalizedString.Common("確認"), JSColor.BLACK);
        button.addTouchUpInsideAction(this._confirmBtnClicked, this);
        button.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 60);
        button.setVisible(false);
        animLayer.addChild(button);
    },

    _dialogOpenAnimationDone: function () {
        // 開啟dialog後馬上跑
        this._super();
        this.startLoadMessageAndRun();
    },

    // 開始跑動畫
    startLoadMessageAndRun: function () {
        // 先清掉所有東西
        var mainLayer = this._mainLayer;
        mainLayer.removeAllChildren();

        // 文字排版的node
        var layoutNode = new GSAutoLayoutNode();
        layoutNode.setType(GSAutoLayout.TYPE.VERTICAL);
        layoutNode.setAnchorPoint(0, 0);
        mainLayer.addChild(layoutNode);

        // 創文字
        var totalHeight = 0;
        var delayTime = 0.05;
        var messageArray = this._messageArray;
        messageArray.forEach(cur => {
            // 內文
            var messageLabel = new GSRichTextNode("#!FFFF00!#" + cur, JSFontName, 12, cc.size(215, 0));
            layoutNode.addChild(messageLabel);

            // 算高度
            totalHeight += messageLabel.getContentSize().height;
        });

        // 設置scrollView大小
        this._scrollView.setContentSize(this._scrollViewSize.width, totalHeight);

        // 顯示scrollView
        this._scrollView.setVisible(true);

        // 先不讓他滑動
        this._scrollView.setTouchEnabled(false);

        // 先跑到最上面
        this._scrollView.setContentOffset(this._scrollView.minContainerOffset());

        // 動畫時間
        var animTime = 0.1;

        // 需要滾動
        if (this._scrollViewSize.height < totalHeight) {
            // 每個訊息出現時間
            animTime = messageArray.length * delayTime;

            layoutNode.getChildren().forEach((child, index) => {
                // 先隱藏
                child.setVisible(false);

                // 再出現
                child.runAction(cc.sequence(
                    cc.delayTime(index * (delayTime - 0.01)),
                    cc.show()
                ));
            });

            // 再跑到最下面
            this._scrollView.setContentOffsetInDuration(this._scrollView.maxContainerOffset(), animTime);
        }

        // 跑動畫
        this.runAction(cc.sequence(
            cc.delayTime(animTime),
            cc.callFunc(() => {
                this.afterAnimationDone();
            }))
        );
    },

    /**
     * 動畫結束
     */
    afterAnimationDone: function () {
        this._confirmBtn.setVisible(true);
        this._scrollView.setTouchEnabled(true);
    },

    /**
     * 確認
     */
    _confirmBtnClicked: function () {
        this._closeDialogAnimation();
    }
});