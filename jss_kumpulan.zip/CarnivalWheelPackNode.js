/**
 * v5.6.6 轉輪大狂歡 - 主畫面
 * created by tony.cheng
 */

var CarnivalWheelPackNode = PurchasePackBaseNode.extend({
    ctor: function (param, closeDialogCallBack) {
        // 先做繼承的東西
        this._super(param, closeDialogCallBack);

        this._wheels = [];
        this._isInAnimation = false;
        this._isPurchasing = false;

        // 加上測試選單
        TestMenu.delegate(this);

        let wheelParam = this._wheelParam = DataModal.purchaseStructuresData.packMap[PurchaseStructuresData.PackSkin.CARNIVAL_WHEEL];

        // -----底圖區-----
        {
            let pinkBgSp = new ccui.Scale9Sprite("carnivalWheel_bg_01.png");
            pinkBgSp.setPreferredSize(JSVisibleSize);
            pinkBgSp.setPosition(JSScreenMidPos);
            this.addChild(pinkBgSp);

            for (let i = 0; i < 2; i++) {
                let lightSp = new cc.Sprite("#carnivalWheel_pic_light_01.png");
                lightSp.setAnchorPoint(i, 1);
                lightSp.setOpacity(50);
                lightSp.setPosition(JSScreenMidPos.x, JSVisibleSize.height);
                this.addChild(lightSp);

                // 紫色聚光燈
                for (let pN = 0; pN < 2; pN++) {
                    let purpleSpotlightSp = new cc.Sprite("#carnivalWheel_pic_spot_purple.png");
                    purpleSpotlightSp.setAnchorPoint(0.5, 0);
                    purpleSpotlightSp.setScale(i ? -1 : 1, -1);
                    purpleSpotlightSp.setPosition(JSScreenMidPos.x + (i ? 1 : -1) * (75 + pN * 115), JSVisibleSize.height + 10);
                    purpleSpotlightSp.setOpacity(200 / (pN + 1));
                    this.addChild(purpleSpotlightSp);
                }

                // 藍色聚光燈
                let blueSpotlightSp = new cc.Sprite("#carnivalWheel_pic_spot_blue.png");
                blueSpotlightSp.setAnchorPoint(0.5, 0);
                blueSpotlightSp.setOpacity(150);
                blueSpotlightSp.setScale(i ? -1 : 1, -1);
                blueSpotlightSp.setPosition(JSScreenMidPos.x + (i ? 134 : -134), JSVisibleSize.height + 10);
                this.addChild(blueSpotlightSp);

                // 背景的紙花
                let paperFlowerSp = new cc.Sprite("#carnivalWheel_pic_papperflower_01.png");
                paperFlowerSp.setRotation(90);
                paperFlowerSp.setPosition(JSScreenMidPos.x + (i ? 177 : -170), JSVisibleSize.height - 58 - 3 * i);
                this.addChild(paperFlowerSp);

                // 前景的捲捲黃色彩帶
                let ribbonDecorateSp = new cc.Sprite("#carnivalWheel_pic_paperflower.png");
                ribbonDecorateSp.setPosition(JSScreenMidPos.x + (i ? 248 : -250), JSScreenMidPos.y + 3 - 73 * i);
                ribbonDecorateSp.setFlippedX(!i);
                this.addChild(ribbonDecorateSp, 0);
            }

            // 標題
            {
                let titleBasePosition = cc.p(JSScreenMidPos.x, JSVisibleSize.height - 32);
                // 標題背景
                let titleBgImage = "#carnivalWheel_bg_title_purple.png";
                if (!GS.isLuxyPoker)
                    titleBgImage = "#carnivalWheel_pic_title_bg.png";
                let titleBg = new cc.Sprite(titleBgImage);
                titleBg.setPosition(titleBasePosition);
                this.addChild(titleBg);

                // 標題文圖檔
                let titleSpImage = "#carnivalWheel_word_title.png";
                if (!GS.isLuxyPoker)
                    titleSpImage = "#carnivalWheel_w_title.png";
                let titleSp = new cc.Sprite(titleSpImage);
                titleSp.setPosition(titleBasePosition);
                this.addChild(titleSp);
            }

            // 倒數計時
            {
                let countDownBasePosition = cc.p(JSScreenBonusHalfWidth + 460, JSScreenBonusHalfHeight + 20);
                // 倒數背景
                let countDownBg = new ccui.Scale9Sprite("marquee_bg.png");
                countDownBg.setPreferredSize(cc.size(104, 15));
                countDownBg.setPosition(countDownBasePosition);
                this.addChild(countDownBg);

                // 時鐘
                let clockSp = new cc.Sprite("#lobby_pic_clock_02.png");
                clockSp.setScale(0.5);
                clockSp.setPosition(countDownBasePosition.x - 36, countDownBasePosition.y);
                this.addChild(clockSp);

                // 倒數
                let timeLabel = this._timeLabel = new GSTimeLabel("", JSFontName, 11);
                timeLabel.setMultiFormat("%ddD:%hhH:%mmM", "%hhH:%mmM:%ssS", undefined, undefined);
                timeLabel.setPosition(countDownBasePosition.x + 8, countDownBasePosition.y);
                this.addChild(timeLabel);
            }

            // 黃色彩帶
            [cc.p(-240, -100), cc.p(-235, 35), cc.p(-90, 70), cc.p(50, 50), cc.p(240, 65)].forEach((cur, idx) => {
                // 彩帶
                let ribbonSprite = new cc.Sprite("#pic_ribbon_03.png");
                ribbonSprite.setPosition(cc.pAdd(cur, JSScreenMidPos));
                ribbonSprite.setFlippedX(idx % 2 === 1);
                if (idx === 2)
                    ribbonSprite.setOpacity(100);
                this.addChild(ribbonSprite);
            });

            let infoPosition = cc.p(JSScreenMidPos.x, JSVisibleSize.height - 59);

            // 上面說明背景
            let infoBg = new ccui.Scale9Sprite("lobby_bg_list_04.png");
            infoBg.setPreferredSize(cc.size(100, 20));
            infoBg.setOpacity(150);
            infoBg.setScaleX(2.5);
            infoBg.setPosition(infoPosition);
            this.addChild(infoBg);

            // 上面說明
            let infoLabel = new cc.LabelTTF(LocalizedString.PurchaseCoupon("不猶豫！馬上轉出財富自由！"), JSFontName, 11);
            infoLabel.setPosition(infoPosition);
            this.addChild(infoLabel);

            // 地板
            let downLightSp = new cc.Sprite("#carnivalWheel_bg_floor.png");
            downLightSp.setAnchorPoint(.5, 0);
            downLightSp.setScale(3);
            downLightSp.setPosition(294 + JSScreenBonusHalfWidth, 5 + JSScreenBonusHalfHeight);
            this.addChild(downLightSp);

            // 旋轉舞台
            let circularView = this._circularView = new CircularView(150, 10, this, 270, cc.size(0, 0));
            circularView.setDelegate(this);
            circularView.setTouchEnabled(false);
            circularView.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 20);
            this.addChild(circularView);

            let bgMenu = new cc.Menu();
            bgMenu.setPosition(0, 0);
            this.addChild(bgMenu);

            // 右上叉叉按鈕
            this._addCloseButton(cc.p(JSVisibleSize.width - JSScreenSafeWidth - 30  , JSVisibleSize.height - 30), bgMenu, undefined);

            // 說明按鈕
            let infoBtn = ButtonUtility.createSimpleImageButton("lobby_btn_circle_03.png", null, "#lobby_btn_pic_window_?.png");
            infoBtn.addTouchUpInsideAction(this._infoBtnClicked, this);
            infoBtn.setScale(0.8);
            infoBtn.setPosition(30 + JSScreenSafeWidth, JSVisibleSize.height - 30);
            this.addChild(infoBtn);
        }

        // 檔Touch用
        let loadingLayer = this._loadingLayer = new DummyTouchLayer(JSVisibleSize);
        this.addChild(loadingLayer, 4);

        // loading轉圈圈
        let loadingSp = this._loadingSp = new GSLoadingSprite();
        loadingSp.start();
        loadingSp.setPosition(JSScreenMidPos);
        loadingLayer.addChild(loadingSp);

        // 刷新一遍
        this._refreshView(true);

        // 註冊通知
        GS.addListener("NotifyCarnivalWheelInfoDone", this.notifyCarnivalWheelInfoDone.bind(this), this);
        GS.addListener("NotifyCarnivalWheelLoadingLayer", this.notifyCarnivalWheelLoadingLayer.bind(this), this);
        GS.addListener("NotifyCarnivalWheelAutoSpin", this.notifyCarnivalWheelAutoSpin.bind(this), this);
        GS.addListener("NotifyCarnivalWheelSetSpinFinished", this.notifyCarnivalWheelSetSpinFinished.bind(this), this);
        GS.addListener("NotifyCarnivalWheelShowDialog", this.notifyCarnivalWheelShowDialog.bind(this), this);

        // 判斷有無資料再決定要不要送埋點，不清楚為什麼可以從新聞牆過來。CrashEye Ref: t.ly/IJQ93
        if (wheelParam) {
            // 埋點：4544 進入儲值整合轉輪大狂歡頁：進入介面人數
            let group = wheelParam.group;
            TexasUtility.sendUserAnalyticsTrack(4544, group);
        }
    },

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        if (!this._canPressedKeyBack)
            return;

        // 等同按下關閉按鈕
        this._closeBtnClicked();
    },

    /**
     * 設定loading
     */
    _setLoadingVisible: function (isVisible) {
        this._loadingLayer.setVisible(isVisible);
        if (isVisible) {
            this._canPressedKeyBack = false;
            this._loadingSp.start();
        } else {
            this._canPressedKeyBack = true;
            this._loadingSp.stop();
        }
    },

    /**
     * 刷新畫面
     */
    _refreshView: function (isFirst) {
        // 動畫中或儲值中不做事
        if (this._isInAnimation || this._isPurchasing)
            return;

        // 拿掉loading
        this._setLoadingVisible(false);

        // 判斷活動有無開啟
        let data = DataModal.purchaseStructuresData.packMap[PurchaseStructuresData.PackSkin.CARNIVAL_WHEEL];
        if (!data || !data.isOpen) {
            // 跳活動結束dialog
            this.showEventEndDialog();
            return;
        }

        this._wheelParam = DataModal.purchaseStructuresData.packMap[PurchaseStructuresData.PackSkin.CARNIVAL_WHEEL];

        // 設定倒數計時
        this._timeLabel.countdownSeconds(JSCodeUtility.getRemainTime(data.remainTime, data.socketTime), () => {
            // 跳活動結束dialog
            this.showEventEndDialog();
        }, undefined);

        // 重創輪子，先刪除
        let wheels = this._wheels;
        wheels.forEach(cur => cur.removeFromParent());
        wheels.length = 0;

        // 實際轉輪順序是[0,2,1]
        let realIndex = [0, 2, 1];
        let step = data.step;

        // 創三個輪子
        let circularView = this._circularView;
        circularView.reloadData(true);
        let angle = circularView.getAngleAtIndex(realIndex[step - 1]);
        circularView.setCurrentRotationAngle(angle);

        // 假如是第一次更新，代表不是server強制吐資料更新
        if (isFirst) {
            // 解an返回
            this._canPressedKeyBack = true;

            // 判斷除了免費轉以外
            if (data.step !== 1) {
                // 設定第一階段輪盤已領取
                wheels[CarnivalWheelPackWheelNode.Level.FIRST].setSpinFinishedStatus(false);

                // 是否轉過第二階段輪盤
                wheels[CarnivalWheelPackWheelNode.Level.SECOND].setSpinFinishedStatus(data.step === 2);
            }
        } else {
            // 鎖an返回
            this._canPressedKeyBack = false;

            // 判斷除了免費轉以外，第二階段更新就要馬上送通知，要開始創一個大轉盤來做動畫
            if (data.step === 2 || step === 3)
                GS.dispatchCustomEvent("NotifyCarnivalWheelAutoSpin", {wheelStep: data.step});
        }
    },

    /**
     * 轉轉盤
     */
    _spinWheel: function (param) {
        // 記下正在演動畫
        this._isInAnimation = true;

        // 拿掉loading
        this._setLoadingVisible(false);

        // ===================演轉輪動畫=========================
        // 確認目前是否有已經轉過的輪子結果
        let data = this._wheelParam;
        let nowStep = data.step;
        let target = (nowStep > param.wheelStep) ? data.targetRecord[param.wheelStep - 1] : data.wheelTarget;

        let aniLayer = new cc.Layer();
        aniLayer.setCascadeOpacityEnabled(true);
        aniLayer.setOpacity(0);
        this.addChild(aniLayer);

        let bgLayer = new cc.LayerColor(cc.color(0, 0, 0, 200), JSVisibleSize.width, JSVisibleSize.height);
        aniLayer.addChild(bgLayer);

        // 擋住後面的按鈕們
        let dummyTouchLayer = new DummyTouchLayer(JSVisibleSize);
        aniLayer.addChild(dummyTouchLayer);

        // 大轉盤
        aniLayer.runAction(cc.sequence(
            cc.fadeIn(0.15),    // 背景出來後 轉輪才出現
            cc.callFunc(() => {
                let wheelParam = {
                    wheelStep: param.wheelStep,      // 第幾階段的轉輪
                    nowStep: nowStep,                   // 當前進行階段
                    wheelTarget: target,                // 要轉到哪裡
                    wheelList: data.wheelList[param.wheelStep - 1],     // 轉輪內容
                    payMoney: data.payMoney,            // 儲值金額
                    needSpinAnim: true,
                };
                // 輪盤
                let wheelCarnival = new CarnivalWheelPackWheelNode(wheelParam);
                wheelCarnival.setPosition(JSScreenMidPos);
                wheelCarnival.setStartSpinStatus();
                wheelCarnival.spin();       // 開始轉
                aniLayer.addChild(wheelCarnival);

                // 跳過按鈕
                let skipButton = new cc.Node(); // 後面的 code 會用到，先放個空的
                skipButton = ButtonUtility.createTextUnderLineButton(LocalizedString.PurchaseCoupon("點我跳過動畫"));
                skipButton.setAnchorPoint(1, 0);
                skipButton.addTouchUpInsideAction(wheelCarnival.spinEnd, wheelCarnival);
                skipButton.setPosition(JSVisibleSize.width - JSScreenSafeWidth - 8, JSScreenBonusHalfHeight + 16);
                aniLayer.addChild(skipButton);

                // 設定自動轉的輪子轉完要做的事情
                wheelCarnival.setSpinFinishCallback(() => {
                    skipButton.setVisible(false);
                    aniLayer.runAction(cc.sequence(cc.delayTime(3),
                        cc.callFunc(() => {
                            // 轉完領獎時，顯示結果的dialog
                            let wheelData = data.wheelList[param.wheelStep - 1];
                            let reward = wheelData.rewardList.length > target ? wheelData.rewardList[target] : 0;
                            this._showDialog(new CarnivalWheelRewardDialog({
                                type: param.wheelStep > 1 ? CarnivalWheelRewardDialog.Type.PURCHASE : CarnivalWheelRewardDialog.Type.GET_REWARD,
                                getReward: reward,
                                wheelStep: param.wheelStep,
                                payMoney: data.payMoney,
                                isMaxReward: target === 0, // 是 0 就是最大獎勵
                            }));
                        }),
                        cc.removeSelf()));
                });
            })
        ));

        // 要開始轉，設定成不能返回鍵
        this._canPressedKeyBack = false;

        // 埋點
        // 4546 第1階段旋轉
        // 4547 第2階段旋轉
        // 4549 第3階段旋轉
        let step = param.wheelStep;
        let track = step === 1 ? 4546 : step === 2 ? 4547 : 4549;
        let group = DataModal.purchaseStructuresData.packMap[PurchaseStructuresData.PackSkin.CARNIVAL_WHEEL].group;
        TexasUtility.sendUserAnalyticsTrack(track, group);
    },

    /**
     * 轉完轉盤
     */
    _spinWheelDone: function (param) {
        let realIndex = [0, 2, 1];

        let wheels = this._wheels;                          // 所有轉輪
        let wheelStep = param.wheelStep;                    // 目前第幾階段
        let wheelNum = wheelStep - 1;                       // 轉輪index
        let nextWheelNum = realIndex[wheelNum + 1];         // 實際上的下一個轉盤
        let canPurchase = wheelStep === 1 ? false : !param.isPurchase;        // 是否還可以購買

        // 是不是儲值完
        if (!param.isPurchase) {
            // 拿掉loading
            this._setLoadingVisible(false);
        } else {
            // 解掉儲值flag
            this._isPurchasing = false;
        }

        // 免費領獎完先鎖著按an返回
        this._canPressedKeyBack = wheelStep > 1;

        // 設定轉盤狀態 已購買的話 壓上"已領取"
        wheels[wheelNum].setSpinFinishedStatus(canPurchase, true);

        // 免費領獎完 跟 儲值完
        if (wheelStep === 1 || param.isPurchase) {
            // 記下在演動畫、鎖 an 返回
            this._isInAnimation = true;
            this._canPressedKeyBack = false;

            this.runAction(cc.sequence(
                cc.delayTime(1.5),
                cc.callFunc(() => {
                    // 轉到下一階段的轉盤
                    this._circularView.rotateToAngleWithDuration(1, this._circularView.getAngleAtIndex(nextWheelNum));
                    // 原本轉盤往後變小變黑 下一個轉盤變大變亮
                    wheels[wheelNum].runAction(cc.spawn(cc.scaleTo(1, 0.6), cc.tintTo(1, 150, 150, 150)));
                    wheels[wheelNum + 1].runAction(cc.spawn(cc.scaleTo(1, 0.8), cc.tintTo(1, 255, 255, 255)));
                }),
                cc.delayTime(1),
                // 鎖掉下來
                cc.callFunc(() => wheels[wheelNum + 1].lockFall()),
                cc.delayTime(1.5),
                cc.callFunc(() => {
                    // 記下動畫結束
                    this._isInAnimation = false;

                    if (this._isEventEnd) {
                        this.showEventEndDialog();
                    } else {
                        // 卡loading
                        this._setLoadingVisible(true);

                        // 重要資料
                        DataProcess.sendString("wheel_carnival_info");
                    }
                })
            ));
        } else {
            // 記下動畫結束
            this._isInAnimation = false;
        }
    },

    /**
     * 儲值成功
     */
    purchaseSuccess: function () {
        // 卡loading等收到 wheel_carnival_recharge 跟 wheel_carnival_info
        this._setLoadingVisible(true);

        // 記下正在儲值
        this._isPurchasing = true;
    },

    /**
     * 跳Dialog
     */
    _showDialog: function (dialog, zOrder = 9999) {
        // 如果有說明dialog先把它關掉
        if (this._infoDialog) {
            this._infoDialog.closeDialogAnimation();
            this._infoDialog = undefined;
        }

        // 跳dialog
        dialog.startDialogAnimation();
        this.addChild(dialog, zOrder);
    },

    /**
     * 跳活動結束dialog
     */
    showEventEndDialog: function () {
        // 記下現在活動結束了
        this._isEventEnd = true;

        // 動作中 或 已經跳活動結束 或 在不能跳活動結束的dialog 或 在儲值中 就不做事
        if (this._isShowEventEndDialog || this._isInAnimation || this._isPurchasing)
            return;

        // 記下已經跳了活動結束dialog
        this._isShowEventEndDialog = true;

        // 如果說明頁有開幫他關掉
        if (this._infoDialog) {
            this._infoDialog.closeDialogAnimation();
            this._infoDialog = undefined;
        }

        // 如果提示dialog有開幫他關掉
        if (this._hintDialog) {
            this._hintDialog.closeDialogAnimation();
            this._hintDialog = undefined;
        }

        // 活動結束
        let dialog = new Dialog({
            title: LocalizedString.Common("提醒"),
            content: LocalizedString.Purchase("活動已結束"),
            closeButton: false,
            callback: () => {
                this.closePurchasePackDialog();
            }
        });
        this._showDialog(dialog);
    },

    /**
     * 按鈕相關
     */

    /**
     * 按下關閉按鈕
     */
    _closeBtnClicked: function () {
        if (!this._canPressedKeyBack)
            return;

        // 要開始轉就創一個大轉盤來做動畫
        let data = DataModal.purchaseStructuresData.packMap[PurchaseStructuresData.PackSkin.CARNIVAL_WHEEL];

        if (data.step !== 1) {
            // 免費轉已經轉過就可以直接關閉
            this.closePurchasePackDialog();
        } else {
            // 不給按an返回
            this._canPressedKeyBack = false;

            // 跳提示Dialog
            var hintDialog = this._hintDialog = new CarnivalWheelRewardDialog({
                type: CarnivalWheelRewardDialog.Type.MESSAGE,
                message: LocalizedString.PurchaseCoupon("別讓好運流失") + "\n" + LocalizedString.PurchaseCoupon("小幫手自動幫您旋轉喔！"),
                callback: () => {
                    // 去要資料
                    DataProcess.sendString("wheel_carnival_reward");

                    // 卡loading
                    GS.dispatchCustomEvent("NotifyCarnivalWheelLoadingLayer", {startLoading: true});
                }
            });
            hintDialog.setCloseCallback(() => {
                // 清掉紀錄
                this._hintDialog = undefined;
            });
            this._showDialog(hintDialog);
        }
    },

    /**
     * 點擊說明按鈕
     */
    _infoBtnClicked: function () {
        let url = TexasUtility.getSimpleInfoURLByKey("wheel_carnival");
        let dialog = this._infoDialog = new WebViewDialog(url, "", undefined, false, GSEnum.DialogSize.MIDDLE);
        dialog.setCloseCallback(() => {
            this._infoDialog = undefined;
        });
        dialog.startDialogAnimation();
        this.addChild(dialog, 9999);

        // 埋點
        // 4552 點擊說明頁
        let group = DataModal.purchaseStructuresData.packMap[PurchaseStructuresData.PackSkin.CARNIVAL_WHEEL].group;
        TexasUtility.sendUserAnalyticsTrack(4552, group);
    },

    /**
     * 實作 `CircularViewDataSource`
     */
    numberItemInCircularView: function () {
        let param = this._wheelParam;
        if (param)
            return param.wheelList.length;
        return 0;
    },

    itemNodeAtIndex: function (circularView, index) {
        // 裡面資料順序有調換 第2階段和第3階段資料交換 circularView的index不變
        // circularView內實際index內容
        // 0 => 第一階段 ,1 => 第三階段 ,2 => 第二階段
        let wheelNode = new CarnivalWheelPackWheelItemNode(this._wheelParam, index);

        // 讓this._wheel內的index 依照『階段』排序
        switch (index) {
            case CarnivalWheelPackWheelNode.Level.SECOND:
                index = 2;
                break;
            case CarnivalWheelPackWheelNode.Level.THIRD:
                index = 1;
                break;
            default:
                break;
        }

        this._wheels[index] = wheelNode.getWheel();
        return wheelNode;
    },

    circularViewDidRotate: function (circularView, angle) {
        // 越高表示他要越小
        circularView.getContainer().getChildren().forEach(child => {
            // 防呆
            if (child.__isDestroyed)
                return;

            // 以20舉例:範圍是-10 ~ 10, 為了計算方便, 上移y軸, 變成越低的YFactor會越高(y:-10 => 20, y: 10 = 0)
            let yFactor = 10 - child.getPosition().y;

            // 要設定層級 較高的要跑到後面
            if (yFactor < 10) {
                child.setLocalZOrder(0);
            } else {
                child.setLocalZOrder(1);
            }
        });
    },

    /**
     * 通知相關
     */

    /**
     * 通知已收到新的資料，如果現在活動是開著就更新，已經拿完全部的獎勵會收到server傳來要關掉的消息
     */
    notifyCarnivalWheelInfoDone: function () {
        this._refreshView();
    },

    /**
     * 通知要卡loading
     */
    notifyCarnivalWheelLoadingLayer: function (event) {
        if (event && event.getUserData()) {
            var param = event.getUserData();
            this._setLoadingVisible(param.startLoading);
        }
    },

    /**
     * 通知開始轉
     */
    notifyCarnivalWheelAutoSpin: function (event) {
        if (event && event.getUserData()) {
            var param = event.getUserData();
            this._spinWheel(param);
        }
    },

    /**
     * 通知已經轉完了
     */
    notifyCarnivalWheelSetSpinFinished: function (event) {
        if (event && event.getUserData()) {
            var param = event.getUserData();
            this._spinWheelDone(param);
        }
    },

    /**
     * 通知要跳dialog
     */
    notifyCarnivalWheelShowDialog: function (event) {
        if (event && event.getUserData()) {
            let param = event.getUserData();
            if (param.dialog) {
                this._showDialog(param.dialog);
            }
        }
    },

    /**
     * 移除所有讀取
     */
    removeLoadingLayer: function () {
        // 解an返回
        this._canPressedKeyBack = true;

        if (this._loadingLayer) {
            this._loadingLayer.setVisible(false);
        }
    },

    createDebugTestObject: function () {
        return new TestMenuDebugObject("轉輪大狂歡", {
            "step 1": () => DataProcess.sendCustomStringToSelf('wheel_carnival_info ' + JSON.stringify({
                "error": "0",
                "group": "2",
                "img_url": "https://g.mwsrv.com/19_60/store/iapp/download/payment/ID/",
                "plan": "30,000",
                "pop": "0",
                "prev_step_target": [],
                "product_list": {
                    "pic": [
                        "Google_01.png",
                        "Telkomsel_01.png",
                        "Codapay_SMS01.png"
                    ],
                    "productID": [
                        "texas9id_android_tmoney_1_60t_bigspincarnival3",
                        "texas9id_telkomsel_tmoney_1_63T_bigspincarnival3",
                        "texas9id_codapay_tmoney_1_60t_bigspincarnival3"
                    ],
                    "topMsg": "Top-up Rp. 30,000 bisa dapat 2.7mlr Chips(Google Play, Indosat,XL,3,Telkomsel)"
                },
                "step": "1",
                "time_left": "10000",
                "wheel_list": {
                    "1": [
                        "1000000",
                        "800000",
                        "780000",
                        "500000",
                        "350000",
                        "300000"
                    ],
                    "2": [
                        "700000000",
                        "675000000",
                        "650000000",
                        "600000000",
                        "550000000",
                        "500000000"
                    ],
                    "3": [
                        "2770000000",
                        "2620000000",
                        "2550000000",
                        "2320000000",
                        "2250000000",
                        "2170000000"
                    ]
                },
                "wheel_target": "0"
            })),
            "step 2": () => DataProcess.sendCustomStringToSelf('wheel_carnival_info ' + JSON.stringify({
                "wheel_list": {
                    "2": ["20250000000", "18750000000", "15000000000", "13870000000", "13500000000", "12000000000"],
                    "1": ["1000000", "800000", "780000", "600000", "550000", "350000"],
                    "3": ["48340000000", "44550000000", "37950000000", "33000000000", "31350000000", "26400000000"]
                },
                "prev_step_target": ["2"],
                "img_url": "https://g.mwsrv.com/19_60/store/iapp/download/payment/ID/",
                "step": "2",
                "plan": "150,000",
                "time_left": "2246963",
                "error": "0",
                "group": "4",
                "pop": "0",
                "product_list": {
                    "topMsg": "Top-up Rp. 150,000 bisa dapat 20.2mlr Chips(Google Play, Indosat,XL,3)\nTop-up Rp. 100,000 bisa dapat 13.2mlr Chips(Telkomsel)",
                    "productID": ["texas9id_android_tmoney_1_303t_bigspincarnival2"],
                    "pic": ["Google_01.png"]
                },
                "wheel_target": "0"
            })),
            "step 3": () => DataProcess.sendCustomStringToSelf('wheel_carnival_info ' + JSON.stringify({
                "step": "3",
                "plan": "330,000",
                "img_url": "https://g.mwsrv.com/19_60/store/iapp/download/payment/ID/",
                "prev_step_target": ["2", "3"],
                "wheel_target": "1",
                "time_left": "2246846",
                "error": "0",
                "wheel_list": {
                    "3": ["48340000000", "44550000000", "37950000000", "33000000000", "31350000000", "26400000000"],
                    "1": ["1000000", "800000", "780000", "600000", "550000", "350000"],
                    "2": ["20250000000", "18750000000", "15000000000", "13870000000", "13500000000", "12000000000"]
                },
                "pop": "0",
                "group": "4",
                "product_list": {
                    "productID": ["texas9id_android_tmoney_1_666t_bigspincarnival3"],
                    "topMsg": "Top-up Rp. 330,000 bisa dapat 44.5mlr Chips(Google Play, Indosat,XL,3)\nTop-up Rp. 250,000 bisa dapat 33.1mlr Chips(Telkomsel)",
                    "pic": ["Google_01.png"]
                }
            })),
            "免費轉": () => DataProcess.sendCustomStringToSelf('wheel_carnival_reward ' + JSON.stringify({
                "error": "0",
                "reward": "780000",
                "wheel_target": '1',
            })),
            "儲值": () => DataProcess.sendCustomStringToSelf('wheel_carnival_recharge ' + JSON.stringify({
                "wheel_target": "1", "reward": "44550000000", "error": "0", "btn_url": "1"
            })),
            "Message Dialog": () => {
                this._showDialog(new CarnivalWheelRewardDialog({
                    type: CarnivalWheelRewardDialog.Type.MESSAGE,
                    message: LocalizedString.PurchaseCoupon("別讓好運流失") + "\n" + LocalizedString.PurchaseCoupon("小幫手自動幫您旋轉喔！"),
                }));
            },
            "GetReward Dialog": () => {
                this._showDialog(new CarnivalWheelRewardDialog({
                    type: CarnivalWheelRewardDialog.Type.GET_REWARD,
                    getReward: 780000,
                }));
            },
            "Purchase Dialog": () => {
                this._showDialog(new CarnivalWheelRewardDialog({
                    type: CarnivalWheelRewardDialog.Type.PURCHASE,
                    getReward: 780000,
                    payMoney: 100000,
                }));
            },
        });
    },
});