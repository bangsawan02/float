/**
 * 通行證 - 領獎按鈕
 * ```
 * Sample config: {
 *     claimAllBtnStyle: Texas_Button.Style.COMMON_BLUE,   // 全部領獎按鈕樣式
 *     claimAllBtnText: "",                                // 全部領獎按鈕文字
 *     isUseOldBtnStyle: true,                             // 是否使用新的按鈕樣式（依照遊戲改變 Style）
 * }
 * ```
 */
var BasePassClaimButton = Texas_Button.extend({
    ctor: function (config = {}) {
        let btnStyle = config.claimAllBtnStyle !== undefined ? config.claimAllBtnStyle : (config.isUseOldBtnStyle ? Texas_Button.Style.COMMON_BLUE : Texas_Button.Style.BLUE);
        let btnSize = cc.size(110, 38);
        let btnMessage = config.claimAllBtnText || LocalizedString.BasePass("全部領取");
        this._super(btnStyle, btnSize, btnMessage);

        this.setChangeColorWhenDisabled(false);
        this.setChangeOpacityWhenDisabled(false);

        // 特效光
        GSSpine.create("spine/luxyPass/luxyPass_button_light", 0.25, (spine) => {
            this._bgLightSpine = spine;
            spine.setPosition(btnSize.width / 2, btnSize.height / 2);
            spine.setAnimation(0, "animation", true);
            this.addChild(spine, -1);
        });
    },

    /**
     * 播放特效（僅 LuxyPass 使用）
     * @deprecated 特效光已調整為常駐發光，非 LuxyPass 請勿使用
     */
    playLightSpineEffect: function () {
        let spine = this._bgLightSpine;
        if (spine) {
            spine.setVisible(true);
            spine.stopAllActions();
            spine.setOpacity(0);
            spine.runAction(cc.sequence(
                cc.fadeIn(0.2),
                cc.delayTime(0.5),
                cc.fadeOut(0.2),
                cc.callFunc(() => spine.setVisible(false))
            ));
        }
    },
});