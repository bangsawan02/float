/**
 * Cangkulan的一些動畫都放在這邊顯示
 */

var Cangkulan_AnimationLayer = cc.Layer.extend({
    ctor: function () {
        this._super();
    },

    clean: function () {
        this.stopAllActions();
        this.removeAllChildren();
        this._gafObject = undefined;
    },

    /**
     * 創金錢的圖片Node
     */
    _createChipNumberNode: function (value) {
        var autoLayout = new GSAutoLayoutNode();
        autoLayout.setSpace(-7);
        autoLayout.setScale(0.8);

        // 先加個加號
        var plusSprite = new cc.Sprite("#game_number_+.png");
        autoLayout.addChild(plusSprite);

        // 處理數字
        var numberString = TexasUtility.getSimpleMoneyString(value);
        for (var i = 0, len = numberString.length; i < len; i++) {
            var numberChar = numberString[i];
            if (isNaN(numberChar)) {
                // 不是數字 要判斷是不是小數點
                if (numberChar === ".") {
                    var dotSprite = new cc.Sprite("#game_number_point.png");
                    autoLayout.addChild(dotSprite);
                } else {
                    // 代表是最後的文字
                    var wordString = numberString.substr(i, len - i);
                    var wordSprite = new cc.Sprite(JSStringUtility.format("#game_number_%s.png", wordString));
                    autoLayout.addChild(wordSprite);
                    break;
                }
            } else {
                // 數字 直接創
                var numberSprite = new cc.Sprite(JSStringUtility.format("#game_number_%s.png", numberChar));
                autoLayout.addChild(numberSprite);
            }
        }

        return autoLayout;
    },

    /**
     * 顯示飛金錢的動畫
     * @param baseDirs    從哪一個位置0~3 Array or Int
     * @param serverToDir 到哪一個位置
     * @param money       飛過去要顯示多少錢
     * @param isFinal     是否為結算
     */
    showCoinAsync: function (baseDirs, serverToDir, money, isFinal) {
        return new Promise(resolve => {
            if (!Array.isArray(baseDirs))
                baseDirs = [baseDirs];

            // 先轉成正確位置
            var toDir = DataModal.gameData.getDirectionByServerDirection(serverToDir);
            var toPos = Cangkulan_GameUtility.getPlayerPosition(toDir);

            baseDirs.forEach((baseDir, dirIndex) => {
                baseDir = DataModal.gameData.getDirectionByServerDirection(baseDir);

                var startPos = Cangkulan_GameUtility.getPlayerPosition(baseDir);

                // 算出目標離開始是在哪一個地方
                var offsetX = toPos.x - startPos.x;
                var midPos = cc.p((startPos.x + toPos.x) / 2, (startPos.y + toPos.y) / 2);
                var offsetRatio = 20;

                var bezierConfig = [startPos, cc.pAdd(midPos, cc.p(offsetX < 0 ? offsetRatio : -offsetRatio, offsetRatio)), toPos];
                var coinCount = 10;
                var moveTime = 0.7;
                var moveAction = (index) => {
                    var coinSprite = new cc.Sprite("#game_pic_chip_01.png");
                    coinSprite.setRotation(JSCodeUtility.getRandomInt(0, 360));
                    coinSprite.setOpacity(0);
                    coinSprite.setScale(0.3);
                    coinSprite.setPosition(startPos);
                    coinSprite.setVisible(false);
                    this.addChild(coinSprite);

                    // 先做旋轉的動畫
                    var rotateAction = cc.repeatForever(cc.rotateBy(0.1, 45));
                    coinSprite.runAction(rotateAction);

                    // 移動的動畫
                    coinSprite.runAction(cc.sequence(
                        cc.delayTime(index * 0.1),
                        cc.show(),
                        cc.spawn(
                            cc.fadeIn(moveTime * 0.5),
                            cc.scaleTo(moveTime, 0.6),
                            cc.bezierTo(moveTime, bezierConfig).easing(cc.easeIn(1.4))
                        ),
                        cc.callFunc(function () {
                            // 把他換圖 閃一下
                            coinSprite.setSpriteFrame("cangkulan_pic_light_01.png");
                            coinSprite.setScale(1.3);
                            coinSprite.setRotation(0);
                            coinSprite.stopAction(rotateAction);

                            if (index === 0 && money && dirIndex === 0) {
                                // 有錢 需要跳顯示
                                var moneyNode = this._createChipNumberNode(money);
                                moneyNode.setPosition(toPos.x, toPos.y - 5);
                                this.addChild(moneyNode, 1);

                                if (isFinal) {
                                    // 是結算 錢不要Remove
                                    moneyNode.runAction(cc.sequence(
                                        cc.moveBy(0.9, cc.p(0, 10)),
                                        cc.callFunc(function () {
                                            // Player上面出現Winner
                                            GS.dispatchCustomEvent("NotifyPlayerShowWinAnimation", serverToDir);
                                        }, this),
                                        cc.delayTime(0.5),
                                        cc.removeSelf()
                                    ));
                                } else {
                                    // 一般的顯示
                                    moneyNode.runAction(cc.sequence(
                                        cc.moveBy(0.9, cc.p(0, 15)),
                                        cc.removeSelf()
                                    ))
                                }

                                // 通知要更新金錢
                                GS.dispatchCustomEvent("NotifyUpdatePlayerMoney");
                            }

                            if (index === coinCount - 1) {
                                // 完成了
                                resolve();
                            }
                        }, this),
                        cc.delayTime(0.04),
                        cc.removeSelf()
                    ));
                };
                for (var i = 0; i < coinCount; i++) {
                    moveAction(i);
                }
            });

            // 給錢音效
            MusicUtility.playEffect("Music/Effect/pass_money.mp3");
        });
    },

    // 結算的動畫 loseDirs:輸家Array , winDir:贏家 , multiple:倍數 , winChips:贏多少錢
    showFinalAsync: function (loseDirs, winDir, winChips) {
        return new Promise(resolve => {
            if (winDir !== DataModal.gameData.myPos) {
                // 不是自己贏錢 沒有煙火 只跑金幣動畫
                if (loseDirs.length === 0) {
                    // Winner動畫
                    GS.dispatchCustomEvent("NotifyPlayerShowWinAnimation", winDir);
                    // 通知要更新金錢
                    GS.dispatchCustomEvent("NotifyUpdatePlayerMoney");
                    // 平局更新完狀態就結束
                    resolve();
                } else {
                    // 付錢完才能走
                    this.showCoinAsync(loseDirs, winDir, winChips, true)
                        .then(() => {
                            resolve();
                        });
                }
            } else {
                // 自己贏錢 放煙火 + 跑金幣動畫
                // 停止動畫並移除
                this.clean();

                gaf.create("gaf/game/remi_win_fireworks.gaf", this, true, (gafAsset) => {
                    var gafObject = this._gafObject = gafAsset.createObjectAndRun(true);
                    gafObject.setPosition(JSScreenMidPos);
                    this.addChild(gafObject, 1);

                    if (loseDirs.length === 0) {
                        // 平局 放煙火
                        this.runAction(cc.sequence(
                            cc.delayTime(2),
                            cc.callFunc(function () {
                                if (this._gafObject) {
                                    this._gafObject.removeFromParent();
                                    this._gafObject = undefined;
                                }

                                // Winner動畫
                                GS.dispatchCustomEvent("NotifyPlayerShowWinAnimation", winDir);
                                // 通知要更新金錢
                                GS.dispatchCustomEvent("NotifyUpdatePlayerMoney");
                                // 平局更新完狀態就結束
                                resolve();
                            }, this)
                        ));
                    } else {
                        // 放完煙火 + 付錢完才能走
                        this.runAction(cc.sequence(
                            cc.delayTime(2),
                            cc.callFunc(function () {
                                this.showCoinAsync(loseDirs, winDir, winChips, true)
                                    .then(() => {
                                        if (this.__isDestroyed)
                                            return;

                                        if (this._gafObject) {
                                            this._gafObject.removeFromParent();
                                            this._gafObject = undefined;
                                        }

                                        resolve();
                                    })
                            }, this)
                        ));
                    }
                });
            }
        });
    },
});