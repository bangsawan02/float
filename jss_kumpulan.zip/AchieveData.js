/**
 * 成就
 */
var AchieveData = cc.Class.extend({
    ctor: function () {
        // 初始化
        this.clean();

        // 創目錄
        if (cc.sys.isNative) {
            jsb.fileUtils.createDirectory(JSWriteablePath + "AchieveIcon");
        }

        // 用來存放"每日"、"活動"、"偉大"、"一般"的成就，其中每日已經沒有在使用，但server還是有吐
        this.achieveArray = [[], [], [], []];

        // 用來記錄每個頁籤是否可以領獎
        this.achieveNumArray = [];

        // 可領獎的總數量
        this.achieveNum = 0;

        // 註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            "fetch_achievement_info": this.cmd_fetch_achievement_info,
            "patch_achievement_reward": this.cmd_patch_achievement_reward,
            "fetch_achievement_tab_info": this.cmd_fetch_achievement_tab_info
        });
    },

    /**
     * 砍掉Data
     */
    destroyData: function () {
        DataProcess.removeSocketKeyDispatch(this);
    },

    /**
     * 清除資料
     */
    clean: function () {
        this.achieveArray = [[], [], [], []];
    },

    /**
     * 成就的提示
     */
    startGetInfo: function () {
        DataProcess.sendString("fetch_achievement_tab_info");
    },

    /**
     * ===============
     * Socket Callback
     * ===============
     */

    /**
     * 取得成就資訊
     */
    cmd_fetch_achievement_info: function (key, value) {
        var jsonValue = JSON.parse(value || "{}");
        var len = jsonValue.length;
        if (len > 1) {
            // 開始處理資料
            for (var i = 1; i < len; i++) {

                var data = jsonValue[i];

                var param = {};

                // 成就圖片
                param.icon = JSCodeUtility.getStringValue(data["icon"]);

                // SID
                param.sid = JSCodeUtility.getIntValue(data["sid"]);

                // 類型 0:每日 1:一般 2:偉大 3:活動
                param.type = JSCodeUtility.getIntValue(data["stype"]);

                // 獎金
                param.bonus1 = JSCodeUtility.getStringValue(data["bonus1"]);

                // 勳章
                param.bonus2 = JSCodeUtility.getStringValue(data["bonus2"] && data["bonus2"].name);

                // 稱號
                param.bonus3 = JSCodeUtility.getStringValue(data["bonus3"] && data["bonus3"].name);

                // 物品
                param.bonus4 = JSCodeUtility.getStringValue(data["bonus4"] && data["bonus4"].name);

                // 表情
                param.bonus5 = JSCodeUtility.getStringValue(data["bonus5"] && data["bonus5"].name);

                // 成就名稱
                param.title = JSCodeUtility.getStringValue(data["suc_title"]);

                // 成就說明
                param.info = JSCodeUtility.getStringValue(data["suc_info"]);

                // 達成幾次
                param.rateTimes = JSCodeUtility.getIntValue(data["times"]);

                // 完成需要幾次
                param.rateNumber = JSCodeUtility.getIntValue(data["target_num"]);

                // 是否已領獎
                param.hasGetBonus = JSCodeUtility.getIntValue(data["get_bonus"]);

                // 是否已完成
                param.complete = JSCodeUtility.getIntValue(data["complete"]);

                // 是否過期
                param.isTimeout = JSCodeUtility.getIntValue(data["time_out"]);

                if (param.type < 4)
                    this.achieveArray[param.type].push(param);
            }

            GS.dispatchCustomEvent("NotifyFetchAchievementInfo");
        }
    },

    /**
     * 取得獎勵
     */
    cmd_patch_achievement_reward: function (key, value) {
        // 關掉Loading
        GSLoading.removeLoadingView();

        var param = null;
        var jsonValue = JSON.parse(value || "{}");
        var result = JSCodeUtility.getIntValue(jsonValue["result"]);
        if (result) {
            // 物品的ID
            var id = JSCodeUtility.getIntValue(jsonValue["id"]);

            // 物品的種類
            var type = JSCodeUtility.getIntValue(jsonValue["type"]);

            // 目前只會有4個標籤的物品
            var achieveString = LocalizedString.Achieve;
            if (type < 4) {
                param = [];
                for (var i = 0, len = this.achieveArray[type].length; i < len; i++) {
                    var item = this.achieveArray[type][i];
                    if (item.sid === id) {
                        item.hasGetBonus = true;
                        item.bonus1 && item.bonus1 !== "0" && param.push("#!000000!#" + achieveString("德撲幣") + " #!DC0050!#" + JSCodeUtility.getCurrencyString(item.bonus1));
                        item.bonus2 && param.push("#!000000!#" + achieveString("勳章") + " #!DC0050!#" + item.bonus2);
                        item.bonus3 && param.push("#!000000!#" + achieveString("稱號") + " #!DC0050!#" + item.bonus3);
                        item.bonus4 && param.push("#!000000!#" + achieveString("物品") + " #!DC0050!#" + item.bonus4);
                        item.bonus5 && param.push("#!000000!#" + achieveString("表情") + " #!DC0050!#" + item.bonus5);
                        break;
                    }
                }

                // 有得到獎勵才需要更新/通知UI
                if (param.length) {
                    // 更新資訊
                    DataProcess.sendString("session_status [1]");

                    // 更新頁籤數量
                    DataProcess.sendString("fetch_achievement_tab_info");
                }
            }
        }

        // 取得成就獎勵失敗
        GS.dispatchCustomEvent("NotifyPatchAchievementRewardDone", param);
    },

    /**
     * 頁籤可領取獎勵的數量
     * fetch_achievement_tab_info [每日, 一般, 偉大, 活動] 是各頁籤可領取獎勵的數量
     * ps."每日"頁籤目前不會顯示
     */
    cmd_fetch_achievement_tab_info: function (key, value) {
        var jsonValue = JSON.parse(value || "[]");
        if (jsonValue.length >= 4) {
            // 用來記錄總數，顯示於更多Dialog > 成就icon右上
            this.achieveNum = 0;

            // 用於記錄每個標籤上的成就數量，會顯示每個頁籤的右上角
            this.achieveNumArray = jsonValue.map((num, index) => {
                var ret = JSCodeUtility.getIntValue(num);

                // "每日"頁籤目前不會顯示，所以不記算於總數內
                if (index > 0)
                    this.achieveNum += ret;

                return ret;
            });

            // 更新UI
            GS.dispatchCustomEvent("NotifyFetchAchievementTabInfoDone");
        }
    },
});