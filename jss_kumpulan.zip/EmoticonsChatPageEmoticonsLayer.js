/**
 * v5.5.4 Gaple 系列牌桌優化 - 互動道具頁面
 * create by lichiehchou on 2023/7/25
 */
var EmoticonsChatPageEmoticonsLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 互動道具頁面
        this._pageArray = [];

        // 用於依照遊戲不同儲存不同的圖檔資源
        var resourceObj = {
            // linePic              分頁選單下方線條圖
            // btnImages            分頁選單按鈕背景圖
            // labelBorderColor     分頁選單文字邊框的顏色     optional
        };
        switch (GS.nowGame) {
            case GSEnum.Game.Gaple:
            case GSEnum.Game.GaplePlus:
            case GSEnum.Game.GapleVideo:
                resourceObj.linePic = "gaple_pic_line_white.png";
                resourceObj.btnImages = ["gaple_btn_03_2.png", "gaple_btn_03_2.png", "gaple_btn_03_1.png"];
                resourceObj.labelBorderColor = cc.color(38, 98, 128);
                break;
            case GSEnum.Game.Texas:
            case GSEnum.Game.Texas19:
                resourceObj.linePic = "game_pic_line_white.png";
                resourceObj.btnImages = ["lobby_btn_tab_02.png", "lobby_btn_tab_02.png", "lobby_btn_tab_01.png"];
                break;
            default:
                return;
        }
        var lineSprite = new ccui.Scale9Sprite(resourceObj.linePic);
        lineSprite.setRotation(90);
        lineSprite.setOpacity(153);
        lineSprite.setPreferredSize(cc.size(1, 153));
        lineSprite.setPosition(121, 190);
        this.addChild(lineSprite);

        // Menu
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        this.addChild(menu);

        var gameString = LocalizedString.Game;
        this._tabItems = [];
        var tabTitles = [gameString("互動道具"), gameString("表情")];
        var tabTitleLen = tabTitles.length;
        var btnSize = cc.size(68, 21);
        var posX = 52;
        var posY = 201;
        var offsetX = btnSize.width + 3;
        for (var i = 0; i < tabTitleLen; i++) {
            var itemNode = ButtonUtility.createArrayScale9Nodes(resourceObj.btnImages, btnSize, tabTitles[i], 10, JSColor.WHITE);
            // 重新設定顏色
            if (resourceObj.labelBorderColor) {
                itemNode[0].label.enableStroke(resourceObj.labelBorderColor, 1);
                itemNode[1].label.enableStroke(resourceObj.labelBorderColor, 1);
                itemNode[2].label.enableStroke(resourceObj.labelBorderColor, 1);
            }
            itemNode[1].setOpacity(150);
            itemNode[2].setOpacity(255);

            var menuItem = this._tabItems[i] = new cc.MenuItemSprite(itemNode[0], itemNode[1], itemNode[2], this._tabClicked, this);
            menuItem.setAnchorPoint(0, 0.5);
            menu.addChild(menuItem);
        }

        // 重新排位置
        for (var i = 0; i < 2; i++) {
            var menuItem = this._tabItems[i];
            if (menuItem.isVisible()) {
                menuItem.setPosition(posX, posY);

                posX += offsetX;
            }
        }

        this._tabClicked(this._tabItems[1]);
    },

    /**
     * 按鈕
     */
    // 按到Tab
    _tabClicked: function (sender) {
        var clickedPos = 0;

        this._tabItems.forEach((cur, index) => {
            if (sender === cur) {
                // 記下點到哪個按鈕
                clickedPos = index;

                cur.setEnabled(false);
            } else {
                cur.setEnabled(true);
            }
        });

        // 關掉其他頁面
        var pageArray = this._pageArray;
        pageArray.forEach(cur => cur.setVisible(false));

        var page = pageArray[clickedPos];
        if (!page) {
            switch (clickedPos) {
                case 0:     // 互動道具
                    page = pageArray[clickedPos] = new ActMoodsScrollLayer(true);
                    break;
                case 1:     // 表情
                    page = pageArray[clickedPos] = new EmoticonsScrollLayer(true);
                    break;
            }
            this.addChild(page, 3);
        } else
            page.setVisible(true);
    },
});
 