/**
 * v5.5.2 大小超過會左右彈的label
 * 移植自中文德撲 v15.8 大小超過會左右彈的label
 * created by Lichieh.
 */

var BouncingNicknameLabel = BaseDetectSizeChangeLabelNode.extend({
    ctor: function (title, fontName, fontSize, size, speedFactor = 1) {
        // 中間位置
        this._midPos = cc.p(0, 0);

        // 一個字跑幾秒
        this._speedFactor = speedFactor;

        // 記起來
        this._fontSize = fontSize;

        // 有title的話 會override onSizeChange
        // onSizeChange有用到midPos,fontSize，這邊沒傳title，但保險起見先下移
        this._super(title, fontName, fontSize, size);
        this.setCascadeOpacityEnabled(true);
        this.setCascadeColorEnabled(true);
    },

    onSizeChange: function () {
        this._super();

        var labelSize = this._label.getContentSize();
        var diff = labelSize.width - this._size.width;
        var moveSpeed = diff / this._fontSize * this._speedFactor;

        this._label.stopActionByTag(this.ANIMATION_TAG);

        // label比較大
        if (diff > 0) {
            this._label.setPosition(this._midPos.x + (diff / 2), this._midPos.y);
            var act = cc.sequence(
                cc.moveTo(moveSpeed, this._midPos.x - (diff / 2), this._midPos.y).easing(cc.easeSineInOut()),
                cc.delayTime(0.5),
                cc.moveTo(moveSpeed, this._midPos.x + (diff / 2), this._midPos.y).easing(cc.easeSineInOut()),
                cc.delayTime(0.5)
            ).repeatForever();
            act.setTag(this.ANIMATION_TAG);
            this._label.runAction(act);
        } else {
            // 這邊diff是負的
            diff = Math.abs(diff);
            switch (this._horizontalAlignment) {
                case cc.TEXT_ALIGNMENT_CENTER:
                    this._label.setPosition(this._midPos);
                    break;
                case cc.TEXT_ALIGNMENT_LEFT:
                    this._label.setPosition(this._midPos.x - (diff / 2), this._midPos.y);
                    break;
                case cc.TEXT_ALIGNMENT_RIGHT:
                    this._label.setPosition(this._midPos.x + (diff / 2), this._midPos.y);
                    break;
            }
        }
    },

    /**
     * 設定文字對齊的功能
     * @param horizontalAlignment
     */
    setHorizontalAlignment: function (horizontalAlignment) {
        if (horizontalAlignment !== this._horizontalAlignment) {
            this._horizontalAlignment = horizontalAlignment;
            this.onSizeChange();
        }
    }
});