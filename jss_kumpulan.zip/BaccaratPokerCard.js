/**
 * 百家樂的牌
 */
var BaccaratPokerCard = PokerCardNode.extend({
    ctor: function () {
        this._super();
        this._cardNumber = 0;
    },

    /**
     * 抓取牌的數字
     */
    getCardNumber: function () {
        return this._cardNumber;
    },

    /**
     * 翻轉牌
     */
    turnCard: function (number, callback) {
        var scaleTime = 0.25;

        var self = this;
        this.runAction(cc.sequence(
            cc.scaleTo(scaleTime, 0, 0.9),
            cc.callFunc(function () {
                // 開始出現牌
                self.setCardNumber(number);

                self.runAction(cc.sequence(
                    cc.scaleTo(scaleTime, 0.8),
                    cc.callFunc(function () {
                        callback && callback();
                    })
                ));
            })
        ));

        // 設定現在這牌的數字
        var numberString = number[1];
        switch (numberString) {
            case "T":
            case "J":
            case "Q":
            case "K":
                this._cardNumber = 10;
                break;
            default:
                this._cardNumber = parseInt(numberString) || 0;
                break;
        }

        // 撥放音樂
        Vegas_MusicUtility.playEffect("Music/Effect/turn_river.mp3");
    },

    /**
     * 把牌轉回來背面
     */
    turnCardToBackAsync: function () {
        return new Promise(resolve => {
            var scaleTime = 0.25;

            this.runAction(cc.sequence(
                cc.scaleTo(scaleTime, 0, 0.8),
                cc.callFunc(function () {
                    // 把他轉到背面
                    this.setCardIsInBack(true);
                }, this),
                cc.scaleTo(scaleTime, 0.8),
                cc.callFunc(resolve)
            ));
        });
    },

});