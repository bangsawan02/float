var DOMINO_UILAYER_BUTTON_Y = 14;
var DOMINO_UILAYER_BUTTON_HEIGHT = 27;
var DOMINO_UILAYER_STATUS = {
    HAS_RAISE: 0,           //等待中有人加注 (若玩家預設選「棄牌/過牌」，「棄牌/過牌」暗掉，幫玩家勾「棄牌」)
    NO_RAISE: 1,            //等待中無人加注
    MY_NO_RAISE: 2,         //輪到自己 沒人加注（大於大盲）
    MY_RAISE: 3,            //輪到自己 有人加注（大於大盲）
    ALL_IN_NO_RAISE: 4,     //輪到自己 沒人加注（小於大盲 Allin）
    ALL_IN_RAISE: 5,        //輪到自己 有人加注（小於大盲 Allin）
    ALL_IN_RAISE2: 6,       //輪到自己 有人加注 (最小加注金額大於攜入，只能跟注或Allin)

    EMPTY: 7,               //顯示空白條
    WAIT_NEXT_GAME: 8,      //請等待下一輪
    WAIT_NEXT_GAME2: 9,     //請稍候
    PLEASE_SIT: 10,         //請選位坐下
    SCORE: 11,              //顯示戰績
};

// 一般決策按鈕狀態
var DOMINO_UILAYER_BUTTON_TYPE = {
    FOLD: 0,        // 棄牌
    PASS: 1,        // 過牌
    CALL: 2,        // 跟注
    RAISE: 3,       // 加注
    FOLD_PASS: 4,   // 棄牌/過牌
    ENABLED: 5,     // 灰階
};

// 用來上方0~6狀態的按鈕的設定
var DOMINO_UILAYER_BUTTON_SETTING = {
    0: [
        {name: "棄牌", checkBox: true, type: DOMINO_UILAYER_BUTTON_TYPE.FOLD},
        {name: "跟注", checkBox: true, type: DOMINO_UILAYER_BUTTON_TYPE.PASS},
        {name: "跟任何注", checkBox: true, type: DOMINO_UILAYER_BUTTON_TYPE.CALL}
    ],
    1: [
        {name: "棄牌/過牌", checkBox: true, type: DOMINO_UILAYER_BUTTON_TYPE.FOLD_PASS},
        {name: "過牌", checkBox: true, type: DOMINO_UILAYER_BUTTON_TYPE.PASS},
        {name: "跟任何注", checkBox: true, type: DOMINO_UILAYER_BUTTON_TYPE.CALL}
    ],
    2: [
        {name: "棄牌", checkBox: false, type: DOMINO_UILAYER_BUTTON_TYPE.FOLD},
        {name: "過牌", checkBox: false, type: DOMINO_UILAYER_BUTTON_TYPE.PASS},
        {name: "加注", checkBox: false, type: DOMINO_UILAYER_BUTTON_TYPE.RAISE}
    ],
    3: [
        {name: "棄牌", checkBox: false, type: DOMINO_UILAYER_BUTTON_TYPE.FOLD},
        {name: "跟注", checkBox: false, type: DOMINO_UILAYER_BUTTON_TYPE.CALL},
        {name: "加注", checkBox: false, type: DOMINO_UILAYER_BUTTON_TYPE.RAISE}
    ],
    4: [
        {name: "棄牌", checkBox: false, type: DOMINO_UILAYER_BUTTON_TYPE.FOLD},
        {name: "過牌", checkBox: false, type: DOMINO_UILAYER_BUTTON_TYPE.PASS},
        {name: "All in", checkBox: false, type: DOMINO_UILAYER_BUTTON_TYPE.RAISE}
    ],
    5: [
        {name: "棄牌", checkBox: false, type: DOMINO_UILAYER_BUTTON_TYPE.FOLD},
        {name: "All in", checkBox: false, type: DOMINO_UILAYER_BUTTON_TYPE.RAISE},
        {name: "跟注", checkBox: false, type: DOMINO_UILAYER_BUTTON_TYPE.CALL}

    ],
    6: [
        {name: "棄牌", checkBox: false, type: DOMINO_UILAYER_BUTTON_TYPE.FOLD},
        {name: "All in", checkBox: false, type: DOMINO_UILAYER_BUTTON_TYPE.RAISE},
        {name: "加注", checkBox: false, type: DOMINO_UILAYER_BUTTON_TYPE.ENABLED}
    ],
};