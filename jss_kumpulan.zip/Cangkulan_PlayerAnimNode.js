/**
 * Cangkulan_LeaveGameStatus 用來撥放Player上面出現的動畫
 */

var Cangkulan_PlayerAnimNode = cc.Node.extend({

    ctor: function () {
        this._super();
        this.setCascadeOpacityEnabled(true);

        // 用來慢慢顯示Label的Queue
        this._queue = [];
    },

    clean: function () {
        this.removeAllChildren();
    },

    /**
     * 把東西放到Queue裡
     */
    _addLabelToQueue: function (label) {
        label.setVisible(false);
        this._queue.push(label);

        // 假如只有一個 馬上跑動畫
        if (this._queue.length === 1)
            this._playQueneAnimation();
    },

    /**
     * 把東西從Queue拿掉
     */
    _removeLabelFromQueue: function (label) {
        var index = this._queue.indexOf(label);
        if (index > -1)
            this._queue.splice(index, 1);

        // 跑動畫
        this._playQueneAnimation();
    },

    /**
     * 跑Queue的動畫
     */
    _playQueneAnimation: function () {
        if (this._queue.length === 0)
            return;

        var label = this._queue[0];
        label.setVisible(true);
        label.runAction(cc.moveBy(1, cc.p(0, 10)));
        label.runAction(cc.sequence(
            cc.fadeIn(0.2),
            cc.delayTime(0.6),
            cc.callFunc(function () {
                this._removeLabelFromQueue(label);
            }, this),
            cc.fadeOut(0.2),
            cc.removeSelf()
        ));
    },

    stopAllAnim: function () {
        this.removeAllChildren();

        this._queue = [];
    },

    //指示目前自已的位置(一個白色圈圈)
    playSitAnim: function () {
        var pointSprite = new cc.Sprite("#game_pic_player_point.png");
        pointSprite.setOpacity(0);
        pointSprite.setScale(0);
        this.addChild(pointSprite);

        // 一直讓他旋轉
        pointSprite.runAction(cc.repeatForever(cc.rotateBy(3.5, 360)));

        // 讓他出來的動畫
        pointSprite.runAction(cc.sequence(
            cc.delayTime(0.5),
            cc.spawn(cc.fadeTo(0.3, 255), cc.scaleTo(0.3, 1.5)),
            cc.delayTime(3),
            cc.spawn(cc.fadeTo(0.3, 0), cc.scaleTo(0.3, 0)),
            cc.removeSelf()
        ));

        MusicUtility.playVoice("welcome.mp3");
    },

    // 播贏家動畫
    playWinAnim: function () {
        var self = this;
        // 頭像上的 周圍繞著的圈圈動畫
        gaf.create("gaf/game/remi_winner.gaf", this, true, function (gafAsset) {
            var gafObject = gafAsset.createObjectAndRun(true);
            self.addChild(gafObject);

            gafObject.runAction(cc.sequence(
                cc.delayTime(2),
                cc.callFunc(() => {
                    GS.dispatchCustomEvent("NotifyEnableProcessMessage");
                }),
                cc.removeSelf()
            ));
        });

        // 頭像上的 Winner文字
        var winnerSprite = new cc.Sprite("#game_word_winner.png");
        winnerSprite.setPosition(0, 5);
        this.addChild(winnerSprite, 1);
        winnerSprite.runAction(cc.spawn(
            cc.moveBy(0.5, cc.p(0, 15)),
            cc.sequence(
                cc.delayTime(2),
                cc.removeSelf())
        ));
    },

    // 撥放拿多少錢的動畫
    playGetChips: function (value) {
        var chipsTag = 555;

        var chipsNode = new cc.Node();
        chipsNode.setCascadeOpacityEnabled(true);
        chipsNode.setPosition(0, -10);
        chipsNode.setOpacity(0);
        this.addChild(chipsNode, 0, chipsTag);

        // 背景
        var bgSprite = new cc.Sprite("#lobby_pic_black.png");
        bgSprite.setScale(2.6, 4);
        chipsNode.addChild(bgSprite);

        var posY = 1;                   // 因為小數點有點太下面 我們把他拉上來
        var chipSprite = new cc.Sprite("#game_pic_chips_big_02.png");
        chipSprite.setPosition(5, posY);
        chipsNode.addChild(chipSprite);

        // 加數字
        var numberString = TexasUtility.getSimpleMoneyString(value);
        var numberArray = [chipSprite];
        var totalWidth = 18;            // 先把籌碼的寬度算下去 之後一起移動
        for (var i = 0, len = numberString.length; i < len; i++) {
            var numberChar = numberString[i];
            if (isNaN(numberChar)) {
                // 不是數字 要判斷是不是小數點
                if (numberChar === ".") {
                    var dotSprite = new cc.Sprite("#game_number_point.png");
                    dotSprite.setPosition(totalWidth - 3, posY);
                    chipsNode.addChild(dotSprite);

                    totalWidth += 4;

                    numberArray.push(dotSprite);
                } else {
                    // 代表是最後的文字
                    var wordString = numberString.substr(i, len - i);
                    var wordSprite = new cc.Sprite(JSStringUtility.format("#game_number_%s.png", wordString));
                    wordSprite.setAnchorPoint(0, 0.5);
                    wordSprite.setPosition(totalWidth - 7, posY);
                    chipsNode.addChild(wordSprite);

                    // 要扣掉之前加的數字寬
                    totalWidth += wordSprite.getContentSize().width - 16;

                    numberArray.push(wordSprite);
                    break;
                }
            } else {
                // 數字 直接創
                var numberSprite = new cc.Sprite(JSStringUtility.format("#game_number_%s.png", numberChar));
                numberSprite.setPosition(totalWidth, posY);
                chipsNode.addChild(numberSprite);

                totalWidth += 10;

                numberArray.push(numberSprite);
            }
        }

        // 重新排序
        var offsetX = totalWidth / 2;
        numberArray.forEach(function (cur) {
            cur.setPositionX(cur.getPositionX() - offsetX);
        });

        // 動畫 先判斷有沒有舊的 有的話delay一下在撥
        var moveFunc = function () {
            chipsNode.runAction(cc.moveBy(1, cc.p(0, 20)));
            chipsNode.runAction(cc.sequence(
                cc.fadeIn(0.2),
                cc.delayTime(0.8),
                cc.fadeOut(0.2),
                cc.removeSelf()
            ));
        };

        var children = this.getChildren();
        var oldCount = 0;
        children.forEach(function (cur) {
            if (cur.getTag() === chipsTag)
                oldCount++;
        });
        if (oldCount > 1) {
            chipsNode.runAction(cc.sequence(
                cc.delayTime(0.6 * (oldCount - 1)),
                cc.callFunc(moveFunc)
            ));
        } else {
            // 直接撥
            moveFunc();
        }
    },

    // 經驗值動畫
    playExp: function (value) {
        value = value || 0;

        if (value === 0)
            return;

        var expLabel = new cc.LabelTTF("Exp + " + value, JSFontBoldName, 12);
        expLabel.setOpacity(0);
        expLabel.enableStroke(JSColor.GRAY, 3);
        this.addChild(expLabel, 1);

        // 把他放進去Queue裡
        this._addLabelToQueue(expLabel);
    },

    // Level UP動畫
    playLevelUp: function (value) {
        value = value || 0;

        if (value === 0)
            return;

        var levelLabel = new cc.LabelTTF("Level Up", JSFontBoldName, 12);
        levelLabel.setPosition(0, -10);
        levelLabel.setOpacity(0);
        levelLabel.setFontFillColor(JSColor.YELLOW);
        levelLabel.enableStroke(JSColor.GRAY, 3);
        this.addChild(levelLabel, 1);

        // 把他放進去Queue裡
        this._addLabelToQueue(levelLabel);
    },

    // 遊戲積分的變化
    playGameRankScoreChange: function (value) {
        value = value || 0;

        if (value === 0)
            return;

        var operString = value >= 0 ? "+ " : "- ";
        var scoreLabel = new cc.LabelTTF("Poin " + operString + Math.abs(value).toString(), JSFontBoldName, 12);
        scoreLabel.setOpacity(0);
        scoreLabel.enableStroke(JSColor.GRAY, 3);
        this.addChild(scoreLabel, 1);

        // 把他放進去Queue裡
        this._addLabelToQueue(scoreLabel);
    },

    playShowCard: function (cardValue, sit) {
        if (sit === 0)
            // 自己不表演
            return;

        var cardList = JSCodeUtility.getStringValue(cardValue).match(REGEXP_TWO_NUMBERS);

        // 牌的間距
        var cardOffsetX = 12;
        // 牌的大小
        var cardScale = 0.67;
        // 結算時玩家亮手牌的位置
        var cardPos = [
            cc.p(59, -2),       // 自己的位置
            cc.p(48, -15),      // 左方 其他人
            cc.p(-43, -45),     // 上方 其他人
            cc.p(-50, -15)      // 右方 其他人

        ];

        // 牌組的Node
        var cardNode = new cc.Node();
        this.addChild(cardNode, 5);

        // 右邊玩家手牌從大頭照旁邊開始放
        if (sit === 3) {
            var len = cardList.length;
            if (len <= 12)
                cardPos[3] = cc.pAdd(cardPos[3], cc.p(len * -11, 0));
        }

        cardList.forEach((cur, idx) => {

            var pos = (idx >= 12) ? cc.pAdd(cardPos[sit], cc.p(0, -20)) : cardPos[sit];

            // 創出手牌
            var card = new PokerCardNode(cur);
            card.setPosition(pos);
            card.setScale(cardScale);
            cardNode.addChild(card, idx);

            card.runAction(cc.moveTo(0.35, cc.p(pos.x + cardOffsetX * (idx % 12), pos.y)));
        });

    },

    playScoreAnim: function (scoreObj, pos) {
        // 結算時玩家亮手牌的位置
        var scorePos = [
            cc.p(150, 55),      // 自己的位置
            cc.p(55, 25),       // 左方 其他人
            cc.p(-50, 0),       // 上方 其他人
            cc.p(-55, 25),      // 右方 其他人
        ];

        var scoreNode = new cc.Node();
        this.addChild(scoreNode, 10);

        var isWin = scoreObj.win;

        // 背景
        var spName = (isWin) ? "#game_pic_score_02.png" : "#game_pic_score_01.png";
        var scoreBg = new cc.Sprite(spName);
        scoreBg.setPosition(scorePos[pos]);
        scoreBg.setScale(0.45);
        scoreNode.addChild(scoreBg);

        // 數字
        var score = scoreObj.score;
        var symbolName = (score >= 0) ? "#cangkulan_num_score_+.png" : "#cangkulan_num_score_-.png";
        var numberObj = {
            number: Math.abs(score),
            numStr: "#cangkulan_num_score_",
            spW: 8,
            symbolName: symbolName,
            symbolLoc: GSSpriteNumberNode.SymbolLoc.FRONT,
        };
        var scoreNumNode = new GSSpriteNumberNode(numberObj);
        scoreNumNode.setPosition(scorePos[pos]);
        scoreNumNode.setSymbolSpriteWidth(7);
        scoreNode.addChild(scoreNumNode);

        // 背景放大縮小
        var winBig = (isWin) ? 0.5 : 0.45;
        scoreBg.runAction(cc.sequence(
            cc.scaleTo(0.2, 0.6),
            cc.scaleTo(0.2, winBig)
        ));
    },

    /**
     * 表演鈴鐺動畫
     * @param pos
     */
    playBellAnim: function (pos) {

        // 播放響鈴音效
        MusicUtility.playEffect("Music/Effect/cangkulan_ringBell.mp3");

        // 鈴鐺的位置
        var bellPos = [
            cc.p(50, 0),      // 自己的位置
            cc.p(80, -25),    // 左方 其他人
            cc.p(0, -55),     // 上方 其他人
            cc.p(-80, -25),   // 右方 其他人
        ];

        gaf.create("gaf/game/cangkulan_bells.gaf", this, true, (gafAsset) => {
            // GAF播放設定
            var bellGafObject = gafAsset.createObjectAndRun(false);
            bellGafObject.setPosition(bellPos[pos]);
            this.addChild(bellGafObject);

            // 設定播完動畫後的事
            bellGafObject.runAction(cc.sequence(
                cc.delayTime(2),
                cc.removeSelf()
            ));
        });
    }
});

Cangkulan_PlayerAnimNode.Type = {
    SIT: 1,                     // 坐下的動畫
    GET_CHIPS: 2,               // 拿多少錢的動畫
    ALL_IN: 3,                  // All in的動畫
    EXP: 4,                     // 得到多少經驗值的動畫
    LEVEL_UP: 5,                // 升級的動畫
    GAME_RANK_SCORE_CHANGE: 6,  // 積分分數的更動
    WIN: 7,                     // 贏家動畫
    SHOW_CARD: 8,               // 顯示手牌
    SCORE: 9,                   // 分數動畫
    BELL: 10                    // 鈴鐺動畫
};