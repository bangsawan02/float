/**
 * 風雲會 - 共用 data（移植中文撲克）
 *
 * 目前使用中的：
 * 1. 百人骰寶風雲會
 */

var CloudClubData = cc.Class.extend({
    ctor: function () {
        this._dataMap = new Map();

        this.clean();

        // 註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            "cloud_club_icon": this.cmd_cloud_club_icon.bind(this),
            "cloud_club_lobby": this.cmd_cloud_club_lobby.bind(this),
            "cloud_club_rank": this.cmd_cloud_club_rank.bind(this),
            "cloud_club_honor": this.cmd_cloud_club_honor.bind(this),
            "cloud_club_reward": this.cmd_cloud_club_reward.bind(this),
            "cloud_club_join_room_msg": this.cmd_cloud_club_join_room_msg.bind(this),
            "cloud_club_upgrade_msg": this.cmd_cloud_club_upgrade_msg.bind(this)
        });
    },

    /**
     * 取得 Icon 資料
     * @param {CloudClubData.slotType} which 
     */
    startGetIconInfo: function (which) {
        DataProcess.sendString("cloud_club_icon " + JSON.stringify({ which: which.toString() }));
    },

    /**
     * 取得 Lobby 資料
     * @param {CloudClubData.slotType} which 
     */
    startGetLobbyInfo: function (which) {
        DataProcess.sendString("cloud_club_lobby " + JSON.stringify({ which: which.toString() }));
    },

    /**
     * 送領獎
     * @param {CloudClubData.slotType} which 
     * @param {CloudClubData.RankType} rankType 
     */
    sendRewardData: function (which, rankType) {
        DataProcess.sendString("cloud_club_reward " + JSON.stringify({
            which: which.toString(),
            rank_type: rankType.toString()
        }));
    },

    /**
     * 告知 server 可以送唱名
     * @param which
     */
    sendJoinRoomMsg: function (which) {
        DataProcess.sendString("cloud_club_join_room_msg " + JSON.stringify({ which: which.toString() }));
    },

    /**
     * 砍掉 Data
     */
    destroyData: function () {
        this.clean();

        DataProcess.removeSocketKeyDispatch(this);
    },

    clean: function () {
        this._dataMap.clear();
    },

    /**
     * 取得指定機台的俱樂部資料
     * @param {CloudClubData.slotType} slotType
     * @returns {*}
     */
    getDataBySlotType: function (slotType) {
        if (this._dataMap.has(slotType)) {
            return this._dataMap.get(slotType);
        } else {
            let dataObj = { which: slotType, error: -1 };
            this._dataMap.set(slotType, dataObj);
            return dataObj;
        }
    },

    /**
     * 處理玩家資料
     * @param {object} jsonValue
     * @returns {{score: (number|number|*), picURL: (*|string), rankType: (number|number|*), nickName: string, rankNumber: (*|string), account: (*|string)}}
     * @private
     */
    _processPlayerData: function (jsonValue) {
        jsonValue = jsonValue || {};
        return {
            nickName: JSCodeUtility.getDecodeStringValue(jsonValue["nickname"]),
            score: JSCodeUtility.getIntValue(jsonValue["score"]),
            picURL: JSCodeUtility.getStringValue(jsonValue["pic"]),
            rankType: JSCodeUtility.getIntValue(jsonValue["rank_type"]),
            rankNumber: JSCodeUtility.getStringValue(jsonValue["rank"]),
            account: JSCodeUtility.getStringValue(jsonValue["account"])
        };
    },

    getClassName: function (which, level) {
        let locString;

        switch (which) {
            case CloudClubData.slotType.MULTI_DICEBO:
                locString = LocalizedString.MultiDiceBoClub;
                break;
        }

        switch (level) {
            case CloudClubData.RankType.NONE:
                return locString("無階級");
            case CloudClubData.RankType.INTERN_1:
                return locString("見習") + " I";
            case CloudClubData.RankType.INTERN_2:
                return locString("見習") + " II";
            case CloudClubData.RankType.INTERN_3:
                return locString("見習") + " III";
            case CloudClubData.RankType.STUDENT_1:
                return locString("骰子學徒") + " I";
            case CloudClubData.RankType.STUDENT_2:
                return locString("骰子學徒") + " II";
            case CloudClubData.RankType.STUDENT_3:
                return locString("骰子學徒") + " III";
            case CloudClubData.RankType.EXPERT_1:
                return locString("擲骰專家") + " I";
            case CloudClubData.RankType.EXPERT_2:
                return locString("擲骰專家") + " II";
            case CloudClubData.RankType.EXPERT_3:
                return locString("擲骰專家") + " III";
            case CloudClubData.RankType.MASTER_1:
                return locString("骰寶大師") + " I";
            case CloudClubData.RankType.MASTER_2:
                return locString("骰寶大師") + " II";
            case CloudClubData.RankType.MASTER_3:
                return locString("骰寶大師") + " III";
            case CloudClubData.RankType.KING:
                return locString("骰寶傳奇");
        }
    },

    /**
     * 取得該階級的樓層
     * @param level 階級
     */
    getFloorByLevel: function (level) {
        switch (level) {
            case CloudClubData.RankType.NONE:
                return 1;
            case CloudClubData.RankType.INTERN_1:
            case CloudClubData.RankType.INTERN_2:
            case CloudClubData.RankType.INTERN_3:
                return 2;
            case CloudClubData.RankType.STUDENT_1:
            case CloudClubData.RankType.STUDENT_2:
            case CloudClubData.RankType.STUDENT_3:
                return 3;
            case CloudClubData.RankType.EXPERT_1:
            case CloudClubData.RankType.EXPERT_2:
            case CloudClubData.RankType.EXPERT_3:
                return 4;
            case CloudClubData.RankType.MASTER_1:
            case CloudClubData.RankType.MASTER_2:
            case CloudClubData.RankType.MASTER_3:
                return 5;
            case CloudClubData.RankType.KING:
                return 6;
        }
    },

    /**
     * 取得該樓層的所有階級
     * @param floor 樓層
     */
    getLevelListByFloor: function (floor) {
        switch (floor) {
            case 1:
                return [CloudClubData.RankType.NONE];
            case 2:
                return [CloudClubData.RankType.INTERN_1, CloudClubData.RankType.INTERN_2, CloudClubData.RankType.INTERN_3];
            case 3:
                return [CloudClubData.RankType.STUDENT_1, CloudClubData.RankType.STUDENT_2, CloudClubData.RankType.STUDENT_3];
            case 4:
                return [CloudClubData.RankType.EXPERT_1, CloudClubData.RankType.EXPERT_2, CloudClubData.RankType.EXPERT_3];
            case 5:
                return [CloudClubData.RankType.MASTER_1, CloudClubData.RankType.MASTER_2, CloudClubData.RankType.MASTER_3];
            case 6:
                return [CloudClubData.RankType.KING];
        }
        return [];
    },

    /**
     * 取得某頁的全球榜玩家資料
     * @param {CloudClubData.slotType} which
     * @param {number} page
     */
    getGlobalRankingPage: function (which, page) {
        let param = {
            type: 2,
            which: which,
            page: page
        };
        DataProcess.sendString("cloud_club_rank " + JSON.stringify(param));
    },

    /**
     * 取得階級排行資料
     * @param {CloudClubData.slotType} which
     */
    getClassRankingPage: function (which) {
        let param = {
            which: which,
            type: 1
        };
        DataProcess.sendString("cloud_club_rank " + JSON.stringify(param));
    },

    /**
     * 取得榮譽牆資料
     * @param {CloudClubData.slotType} which
     * @param {string} week 格式為 dd/mm/yyyy。**移植時請特別注意日期格式，送出的格式必須是 yyyy/mm/dd**
     */
    getHonorWallData: function (which, week = "0") {
        let param = {
            which: which,
            week: week === "0" ? week : this.getDataBySlotType(which).honorWallData.weekKeyHash[week],
        };
        DataProcess.sendString("cloud_club_honor " + JSON.stringify(param));
    },

    /**
     * 風雲會 Icon
     * C -> S cloud_club_icon {"which":"31"}
     * S -> C cloud_club_icon
     */
    cmd_cloud_club_icon: function (key, value) {
        let jsonValue = JSON.parse(value || "{}");
        let errorCode = JSCodeUtility.getIntValue(jsonValue["error"]);

        // 機台編號 參照 CloudClubData.slotType
        let which = JSCodeUtility.getIntValue(jsonValue["which"]);
        let dataObj = this.getDataBySlotType(which);
        dataObj.error = errorCode;

        // 有沒有成功
        if (errorCode === 0) {
            // 可否領獎
            dataObj.canReward = dataObj.redPoint = JSCodeUtility.getBooleanValue(jsonValue["can_reward"]);

            // 週期
            dataObj.period = JSCodeUtility.getStringValue(jsonValue["period"]);

            // 等級, 參照 MultiDiceBo_ClubData.RankType
            dataObj.rankType = dataObj.selfRankType = JSCodeUtility.getIntValue(jsonValue["rank_type"], CloudClubData.RankType.NONE);

            // 玩家目前樓層
            dataObj.selfFloor = this.getFloorByLevel(dataObj.rankType);

            // 玩家目前分數
            dataObj.score = JSCodeUtility.getIntValue(jsonValue["score"]);

            // 升級所需分數
            dataObj.endScore = JSCodeUtility.getIntValue(jsonValue["score_limit"]);

            // 是不是在結算
            dataObj.isSettling = dataObj.isInSettling = JSCodeUtility.getIntValue(jsonValue["is_settling"]);

            // 要不要跳出風雲會
            dataObj.isPop = JSCodeUtility.getBooleanValue(jsonValue["isPop"]);

            // 距離本期結算剩餘秒數
            dataObj.socketTime = JSCodeUtility.getNowTime();
            dataObj.settleLeftTime = JSCodeUtility.getIntValue(jsonValue["settle_left_time"]);
            dataObj.iconRemainTime = dataObj.settleLeftTime > 0 ? dataObj.settleLeftTime : JSCodeUtility.getIntValue(jsonValue["next_period_left_time"]);

            // 是否可以送「當日有玩百人骰寶、有風雲會點數紀錄，且有進入風雲會頁人數」
            dataObj.canTrack = JSCodeUtility.getBooleanValue(jsonValue["can_track"]);

            if (PushScene.isLobby) {
                // 如果在 Lobby 就更新 FreeChips
                DataModal.freeChipsData.refreshAvailableList();
            }

            GS.dispatchCustomEvent("NotifyCloudClubIconDone", dataObj);
        }
    },

    /**
     * 風雲會大廳資料
     * C -> S cloud_club_lobby {"which":"31"}
     * S -> C cloud_club_lobby
     */
    cmd_cloud_club_lobby: function (key, value) {
        let jsonValue = JSON.parse(value || "{}");

        // 有沒有成功
        if (!JSCodeUtility.getIntValue(jsonValue["error"])) {
            // 機台編號 參照 CloudClubData.slotType
            let which = JSCodeUtility.getIntValue(jsonValue["which"]);
            let dataObj = this.getDataBySlotType(which);

            // 是不是在結算中
            dataObj.isInSettling = JSCodeUtility.getIntValue(jsonValue["is_settling"]);

            // 結算訊息
            if (dataObj.isInSettling) {
                dataObj.settleMsg = JSCodeUtility.getStringValue(jsonValue["settle_msg"]);
            }

            // 本身的分數
            dataObj.selfScore = JSCodeUtility.getIntValue(jsonValue["score"]);

            // 載圖的網址
            dataObj.rewardIMGBaseURL = JSCodeUtility.getStringValue(jsonValue["img_url"]);

            // 玩家本身是什麼等級的
            dataObj.selfRankType = JSCodeUtility.getIntValue(jsonValue["rank_type"], CloudClubData.RankType.NONE);

            // 玩家目前樓層
            dataObj.selfFloor = this.getFloorByLevel(dataObj.selfRankType);

            // 馬上玩要導哪一區
            dataObj.quickPlayRoomType = JSCodeUtility.getIntValue(jsonValue["redirect_type"], 1);

            // 各樓層的資料
            dataObj.allLevelInfo = (jsonValue["floor_info"] || []).map(cur => {
                let param = {};

                // 這階級最高的分數
                param.scoreLimit = JSCodeUtility.getIntValue(cur["score_limit"]);

                // 獎勵
                let rewardValue = (cur["rewards"] || {});
                // 本週獎勵
                param.settleRewards = (rewardValue["settle"] || []).map(rewardItem => {
                    let item = {};
                    // 圖片名稱
                    item.imgName = JSCodeUtility.getStringValue(rewardItem["pic"]);

                    // 品名描述
                    item.detail = JSCodeUtility.getStringValue(rewardItem["name"]);

                    return item;
                });

                // 升級獎勵
                param.upgradeRewards = (rewardValue["upgrade"] || []).map(rewardItem => {
                    let item = {};
                    // 圖片名稱
                    item.imgName = JSCodeUtility.getStringValue(rewardItem["pic"]);

                    // 品名描述
                    item.detail = JSCodeUtility.getStringValue(rewardItem["name"]);

                    return item;
                });

                // 領獎狀態 0:未達成 1:可領獎 2: 已領獎
                param.rewardStatus = JSCodeUtility.getIntValue(rewardValue["reward_status"]);

                return param;
            });

            // 額外進頁面要表演的資訊
            let additionalInfo = dataObj.additionalInfo = {};

            if (jsonValue["upgrade_info"]) {
                let upgradeValue = jsonValue["upgrade_info"];

                // 有要跳出升級資訊
                if (JSCodeUtility.getIntValue(upgradeValue["is_pop"])) {
                    additionalInfo.upgradeInfo = {
                        oldRankType: JSCodeUtility.getIntValue(upgradeValue["from_rank_type"], CloudClubData.RankType.NONE)
                    };
                }
            }

            // 非結算時間，才可以跳結算資訊
            if (!dataObj.isInSettling && jsonValue["settle_info"]) {
                let settleValue = jsonValue["settle_info"];

                // 有要跳出結算資訊
                if (JSCodeUtility.getIntValue(settleValue["is_pop"])) {
                    additionalInfo.settleInfo = {
                        // 結算訊息
                        message: JSCodeUtility.getStringValue(settleValue["pop_msg"])
                    };
                }
            }

            GS.dispatchCustomEvent("NotifyCloudClubLobbyInfoDone");
        }
    },

    /**
     * 風雲會排行榜資料 ,type: 1 是階級, 2 是全球
     * C -> S cloud_club_rank {"which":"31","type":"1"}
     * S -> C cloud_club_rank
     */
    cmd_cloud_club_rank: function (key, value) {
        let jsonValue = JSON.parse(value || "{}");

        // 有沒有成功
        if (JSCodeUtility.getIntValue(jsonValue["error"]))
            return;

        // 機台編號 參照 CloudClubData.slotType
        let which = JSCodeUtility.getIntValue(jsonValue["which"]);

        let dataObj = this.getDataBySlotType(which);

        let type = JSCodeUtility.getIntValue(jsonValue["type"]);

        let rankingList = (jsonValue["rank_list"] || []).map((cur, i) => {
            // 如果沒有帶階級就是照array的順序
            cur["rank"] = cur["rank"] !== undefined ? cur["rank"] : i + 1;
            return this._processPlayerData(cur);
        });

        // 階級
        if (type === CloudClubData.RankingDataType.CLASS) {
            // 前三名的資料
            dataObj.classTopThreeDatas = rankingList.splice(0, 3);

            // 自己的資料，有資料才更新。沒資料用舊的
            dataObj.classRankingSelfData = jsonValue["info"] ? this._processPlayerData(jsonValue["info"]) : dataObj.classRankingSelfData;

            // 拿掉自己
            rankingList = rankingList.filter(cur => cur.account !== dataObj.classRankingSelfData.account);

            // 哪個階級的排行
            dataObj.classRankingType = JSCodeUtility.getIntValue(jsonValue["rank_type"], CloudClubData.RankType.NONE);

            dataObj.classRankingArray = rankingList;

            // 通知ui
            GS.dispatchCustomEvent("NotifyCloudClubClassRankingDone");
        }
        // 全球資料
        else if (type === CloudClubData.RankingDataType.GLOBAL) {
            // 哪一份資料
            let pageIndex = JSCodeUtility.getIntValue(jsonValue["page"]);

            // 自己的資料，有資料才更新。沒資料用舊的
            dataObj.globalRankingSelfData = jsonValue["info"] ? this._processPlayerData(jsonValue["info"]) : dataObj.globalRankingSelfData;

            // 前三名的資料
            if (pageIndex === 1) {
                dataObj.globalTopThreeDatas = rankingList.splice(0, 3);
            }

            // 拿掉自己
            rankingList = rankingList.filter(cur => cur.account !== dataObj.globalRankingSelfData.account);

            // 第一次拿資料
            if (!dataObj.globalRankingArray) {
                dataObj.globalRankingArray = rankingList;
                let info = {};
                info.pageIndex = pageIndex;
                info.itemLength = rankingList.length;
                dataObj.globalRankingPageInfo = [info];
            }
            // 東西要接在後面
            else if (pageIndex > dataObj.globalRankingPageInfo[dataObj.globalRankingPageInfo.length - 1].pageIndex) {
                // PM說避免crash 超過220筆資料就會砍一些的資料
                // 接在後面的要先砍前面, 一個位移的概念
                if (dataObj.globalRankingArray.length > 220) {
                    let first = dataObj.globalRankingPageInfo.shift();
                    dataObj.globalRankingArray.splice(0, first.itemLength);
                }

                // 更新表單尾端的資料
                dataObj.globalRankingArray = dataObj.globalRankingArray.concat(rankingList);
                dataObj.globalRankingPageInfo.push({
                    pageIndex: pageIndex,
                    itemLength: rankingList.length
                });
            }
            // 東西要接在前面的
            else if (pageIndex < dataObj.globalRankingPageInfo[0].pageIndex) {
                // PM說避免crash 超過220筆資料就會砍一些的資料
                // 接在前面的要先砍後面, 一個位移的概念
                if (dataObj.globalRankingArray.length > 220) {
                    let last = dataObj.globalRankingPageInfo.pop();
                    // 有可能是空的就會是0, 這時候不用刪array的內容
                    if (last.itemLength) {
                        dataObj.globalRankingArray.splice(-last.itemLength);
                    }
                }

                // 更新表單前端的資料
                dataObj.globalRankingArray = rankingList.concat(dataObj.globalRankingArray);
                dataObj.globalRankingPageInfo.splice(0, 0, {
                    pageIndex: pageIndex,
                    itemLength: rankingList.length
                });
            }

            // 通知ui
            GS.dispatchCustomEvent("NotifyCloudClubGlobalRankingDone");
        }
    },

    /**
     * 榮譽牆
     * C -> S cloud_club_honor {"which":"31","week":"2018/12/31"}
     * S -> C cloud_club_honor
     */
    cmd_cloud_club_honor: function (key, value) {
        let jsonValue = JSON.parse(value);
        let errorCode = JSCodeUtility.getIntValue(jsonValue["error"]);
        let which = JSCodeUtility.getIntValue(jsonValue["which"]);

        // 有沒有成功
        if (errorCode)
            return;

        let data = this.getDataBySlotType(which);
        let honorWallData = data.honorWallData = data.honorWallData || {};

        // 沒資料顯示的文字
        honorWallData.noDataMsg = JSCodeUtility.getStringValue(jsonValue["no_data_msg"]);

        // 有哪些週
        honorWallData.weekList = (jsonValue["week_list"] || []).map(cur => JSCodeUtility.getStringValue(cur));

        // 週對應送給 server 的 key hash map
        honorWallData.weekKeyHash = {};
        Object.keys(jsonValue["week_list_to_server"] || {}).forEach(cur => {
            let key = JSCodeUtility.getStringValue(cur);
            honorWallData.weekKeyHash[key] = JSCodeUtility.getStringValue(jsonValue["week_list_to_server"][cur]);
        });

        // 哪週的資料
        let week = JSCodeUtility.getStringValue(jsonValue["week"]);

        // 該週的資料
        honorWallData.weekRankHash = honorWallData.weekRankHash || {};
        honorWallData.weekRankHash[week] = (jsonValue["rank_list"] || []).map(cur => this._processPlayerData(cur));

        GS.dispatchCustomEvent("NotifyCloudClubHonorWallDone", week);
    },

    /**
     * 領獎
     * C -> S cloud_club_reward {"which":"31","rank_type":"1"}
     * S -> C cloud_club_reward
     */
    cmd_cloud_club_reward: function (key, value) {
        let jsonValue = JSON.parse(value || "{}");
        let errorCode = JSCodeUtility.getIntValue(jsonValue["error"], 1);
        let which = JSCodeUtility.getIntValue(jsonValue["which"]);
        let dataObj = this.getDataBySlotType(which);

        // 有成功：更新獎勵狀態
        if (!errorCode) {
            let level = JSCodeUtility.getIntValue(jsonValue["rank_type"], CloudClubData.RankType.INTERN_1);
            dataObj.allLevelInfo[level].rewardStatus = CloudClubData.RewardStatus.RECEIVED;
            dataObj.canReward = dataObj.redPoint = dataObj.allLevelInfo.some(cur => cur.rewardStatus === CloudClubData.RewardStatus.CAN_RECEIVE);
        }

        // 通知UI
        GS.dispatchCustomEvent("NotifyCloudClubGetRewardDone", {
            error: errorCode,
            which: which,
            rewardMsg: (jsonValue["reward_msg"] || []).map(e => "#!000000!#" + JSCodeUtility.getStringValue(e))
        });
    },

    /**
     * 入桌唱名。
     * 自己入座後主動送給 server 代表可以唱名了。
     * 其他人的唱名從這裡接收。
     *
     * C->S cloud_club_join_room_msg
     * S->C cloud_club_join_room_msg
     */
    cmd_cloud_club_join_room_msg: function (key, value) {
        let jsonValue = JSON.parse(value || "{}");

        // 有成功
        if (!JSCodeUtility.getIntValue(jsonValue["error"])) {
            GS.dispatchCustomEvent("NotifyCloudClubShowMessage", {
                which: JSCodeUtility.getIntValue(jsonValue["which"]),
                rankType: JSCodeUtility.getIntValue(jsonValue["rank_type"]),
                userName: JSCodeUtility.getStringValue(jsonValue["user_name"]),
                // 1 入桌唱名
                type: JSCodeUtility.getIntValue(jsonValue["type"], 1),
            });
        }
    },

    /**
     * 桌內升階，僅會在自己升階時送來
     * S -> C cloud_club_upgrade_msg
     */
    cmd_cloud_club_upgrade_msg: function (key, value) {
        let jsonValue = JSON.parse(value || "{}");

        if (!JSCodeUtility.getIntValue(jsonValue["error"])) {
            let which = JSCodeUtility.getIntValue(jsonValue["which"]);
            let dataObj = this.getDataBySlotType(which);
            dataObj.rankType = JSCodeUtility.getIntValue(jsonValue["rank_type"]);

            // 有升階才會給 true，server 不會判斷是否可以領獎
            dataObj.canReward = dataObj.redPoint = dataObj.canReward || JSCodeUtility.getBooleanValue(jsonValue["can_reward"]);

            // 玩家目前樓層
            dataObj.selfFloor = this.getFloorByLevel(dataObj.rankType);

            // 玩家目前分數
            dataObj.score = JSCodeUtility.getIntValue(jsonValue["score"]);

            // 升級所需分數
            dataObj.endScore = JSCodeUtility.getIntValue(jsonValue["score_limit"]);

            // 通知更新 icon
            GS.dispatchCustomEvent("NotifyCloudClubIconDone");
        }
    }
});

// 等級
CloudClubData.RankType = {
    NONE: 0,         // 無階級
    INTERN_1: 1,     // 見習I
    INTERN_2: 2,     // 見習II
    INTERN_3: 3,     // 見習III
    STUDENT_1: 4,    // 骰子學徒I
    STUDENT_2: 5,    // 骰子學徒II
    STUDENT_3: 6,    // 骰子學徒III
    EXPERT_1: 7,     // 擲骰專家I
    EXPERT_2: 8,     // 擲骰專家II
    EXPERT_3: 9,     // 擲骰專家III
    MASTER_1: 10,    // 骰寶大師I
    MASTER_2: 11,    // 骰寶大師II
    MASTER_3: 12,    // 骰寶大師III
    KING: 13         // 骰寶傳奇
};

// 等級的type
CloudClubData.RankingDataType = {
    CLASS: 1,       // 階級
    GLOBAL: 2       // 全球
};

CloudClubData.RewardStatus = {
    UNFINISHED: 0,      // 未達成
    CAN_RECEIVE: 1,     // 可領獎
    RECEIVED: 2         // 已領獎
};
// 最大獎勵數量
CloudClubData.MAX_REWARD = 4;

/**
 * 風雲會機台的類型，對應 server 的編號
 */
CloudClubData.slotType = {
    MULTI_DICEBO: 31,    // 百人骰寶
};