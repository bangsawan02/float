/**
 * Bonus 撲克牌頁面
 */
var BonusPokersLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this._handCards = [];
        this._bonusRates = [30, 25, 20, 15, 10, 5, 3];          // 玩家Bonus贏的倍率

        this._publicCards = this._createPokerCards(5);
        this._dealerCards = this._createPokerCards(2);
        this._playerCards = this._createPokerCards(2);
    },

    /**
     * 清空資料
     */
    clean: function () {
        this._handCards = [];
    },

    /**
     * 建立撲克牌
     * @param {Number} number 張數
     * @return {[BonusPokerCardNode]}
     */
    _createPokerCards: function (number) {
        var pokerCards = [];
        for (var i = 0; i < number; i++) {
            var pokerCard = pokerCards[i] = new BonusPokerCardNode();
            this._resetCard(pokerCard);
            this.addChild(pokerCard);
        }
        return pokerCards;
    },

    /**
     * 重設牌的數值
     * @param {PokerCardNode} pokerCard 牌
     */
    _resetCard: function (pokerCard) {
        pokerCard.setColor(JSColor.WHITE);
        pokerCard.setScale(BonusPokersLayer.CARD_END_SCALE);
        pokerCard.setPosition(473 + JSScreenBonusHalfWidth, 223 + JSScreenBonusHalfHeight);
        pokerCard.setRotation(115);
        pokerCard.setVisible(false);
    },

    /**
     * 發牌不轉牌動畫
     * @param {BonusPokerCardNode}  pokerCard       牌
     * @param {cc.Point}            endPosition     移動到哪個位置
     * @param {Number}              delayTimes      delay時間
     */
    _dealAnimation: function (pokerCard, endPosition, delayTimes = 0) {
        // 設定
        var aniTime = BonusPokersLayer.CARD_MOVE_TIME;
        var delayTime = 0.25;
        var endScaleSize = BonusPokersLayer.CARD_SCALE;

        // 移動
        pokerCard.runAction(cc.sequence(
            cc.delayTime(delayTime * delayTimes),
            cc.show(),
            cc.spawn(
                cc.moveTo(aniTime, endPosition).easing(cc.easeExponentialOut()),
                // 旋轉回來
                cc.rotateBy(aniTime, -115).easing(cc.easeExponentialOut()),
                // 變大小
                cc.scaleTo(aniTime, endScaleSize).easing(cc.easeExponentialOut()),
                // 播放音效
                cc.callFunc(function () {
                    Vegas_MusicUtility.playEffect("Music/Effect/flop.mp3");
                })
            )
        ));
    },

    /**
     * 翻牌
     * @param {PokerCardNode}   pokerCard       牌
     * @param {String}          number          牌的數值
     * @param {Boolean}         isPlayEffect    是否播放音效
     * @param {Number}          delayTime       要延遲幾倍的時間
     * @param {Function}        callback        發完的callback
     */
    _flipAnimation: function (pokerCard, number = "", isPlayEffect = true, delayTime = 0, callback = undefined) {
        var endScaleSize = BonusPokersLayer.CARD_SCALE;

        pokerCard.stopAllActions();
        pokerCard.runAction(cc.sequence(
            cc.delayTime(delayTime * 0.15),
            cc.scaleTo(0.15, 0, endScaleSize),
            cc.callFunc(() => {
                // 開始出現牌
                pokerCard.setCardNumber(number);
                // 如果翻到背面額外設定回白色
                if (!number)
                    pokerCard.setColor(JSColor.WHITE);

                // 播放音效
                isPlayEffect && Vegas_MusicUtility.playEffect("Music/Effect/turn_river.mp3");
            }),
            cc.scaleTo(0.15, endScaleSize),
            cc.callFunc(() => {
                callback && callback();
            })
        ));
    },

    /**
     * 將牌移到棄牌區
     * @param {PokerCardNode} pokerCard 牌
     */
    _moveCardToDiscard: function (pokerCard) {
        var aniTime = BonusPokersLayer.CARD_MOVE_TIME;
        var endScaleSize = BonusPokersLayer.CARD_END_SCALE;
        var endPosition = cc.p(25 + JSScreenBonusHalfWidth, JSVisibleSize.height - 57 - JSScreenBonusHalfHeight);

        pokerCard.runAction(cc.sequence(
            cc.spawn(
                cc.moveTo(aniTime, endPosition).easing(cc.easeExponentialOut()),
                // 旋轉回來
                cc.rotateBy(aniTime, 371).easing(cc.easeExponentialOut()),
                // 變大小
                cc.scaleTo(aniTime, endScaleSize).easing(cc.easeExponentialOut())
            ),
            cc.hide(),
            cc.callFunc(() => this._resetCard(pokerCard))
        ));
    },

    /**
     * 檢查牌的bonus狀態
     * @return {{winRate: number, winType: number}}
     * @private
     */
    _checkBonus: function () {
        // 先檢查Bonus
        var winRate = 0, winType = 0;

        var card1 = this._handCards[0];
        var card2 = this._handCards[1];
        // Type是1~K Flower是花色, 1 = Spade, 2 = Heart, 3 = Diamond, 4 = MultiDiceBo_Club
        var flower1 = card1.charAt(0), type1 = card1.charAt(1);
        var flower2 = card2.charAt(0), type2 = card2.charAt(1);

        if (type1 === "1" && type2 === "1") {
            // AA
            winType = 0;
            winRate = this._bonusRates[0];
        } else if (flower1 === flower2 &&
            ((type1 === "1" && type2 === "K") || (type1 === "K" && type2 === "1"))) {
            // AK同花
            winType = 1;
            winRate = this._bonusRates[1];
        } else if (flower1 === flower2 &&
            ((type1 === "1" && (type2 === "Q" || type2 === "J")) ||
                (type2 === "1" && (type2 === "Q" || type1 === "J")))) {
            // AQ or AJ同花
            winType = 2;
            winRate = this._bonusRates[2];
        } else if (flower1 !== flower2 && ((type1 === "1" && type2 === "K") || (type1 === "K" && type2 === "1"))) {
            // AK非同花
            winType = 3;
            winRate = this._bonusRates[3];
        } else if ((type1 === "K" && type2 === "K") || (type1 === "Q" && type2 === "Q") || (type1 === "J" && type2 === "J")) {
            //KK、QQ、JJ一對
            winType = 4;
            winRate = this._bonusRates[4];
        } else if (flower1 !== flower2 && ((type1 === "1" && (type2 === "Q" || type2 === "J")) ||
            (type2 === "1" && (type1 === "Q" || type1 === "J")))) {
            //AQ or AJ非同花
            winType = 5;
            winRate = this._bonusRates[5];
        } else if (type1 === type2) {
            // 2-2至 10-10一對, 只需要判斷牌是否是一對就好, 因為其他的對子都已經被handle
            winType = 6;
            winRate = this._bonusRates[6];
        }

        return {winType: winType, winRate: winRate, cardList: this._handCards};
    },

    /**
     * 檢查是否為贏牌的牌型
     * @param {BonusPokerCardNode}  card            牌
     * @param {[String]}            cardArray       贏牌的牌數值陣列
     * @param {Boolean}             isPlayerCard    是否為玩家的牌
     */
    _checkIsCardWin: function (card, cardArray, isPlayerCard = false) {
        if (this._isCardInArray(card, cardArray)) {
            card.pushCard(isPlayerCard);
            card.displayWinAni();
        } else
            card.displayLoseColor();
    },

    /**
     * 檢查是否牌型一樣
     * @param {BonusPokerCardNode}  card        牌
     * @param {[String]}            cardArray   贏牌的牌數值陣列
     * @return {Boolean}    是否牌型一樣
     */
    _isCardInArray: function (card, cardArray) {
        return cardArray.some(cur => cur === card.cardNumber);
    },

    /**
     * 發手牌及莊家牌
     * @param {[String]}    cardList    玩家手牌
     * @param {Function}    callback    發完牌的callback
     */
    dealHandCard: function (cardList, callback) {
        this._handCards = cardList;
        // 發牌給玩家跟莊家, 並翻開玩家手牌
        this.runAction(cc.sequence(
            cc.callFunc(() => this.dealPlayerCard()),
            cc.delayTime(0.5),
            cc.callFunc(() => this.dealDealerCard()),
            cc.delayTime(BonusPokersLayer.CARD_MOVE_TIME + 0.3),
            cc.callFunc(() => {
                this.flipPlayerCard(cardList);
                callback && callback();
            })
        ));
    },

    /**
     * 發三張牌到Flop
     * @param {[String]}    cardList    牌
     * @param {Function}    callback    發完牌的callback
     */
    cmd_bonus_flop_cards: function (cardList, callback) {
        // 發三張牌到Flop, 並翻開
        this.runAction(cc.sequence(
            cc.callFunc(() => this.dealFlopCard()),
            cc.delayTime(BonusPokersLayer.CARD_MOVE_TIME + 0.7),
            cc.callFunc(() => {
                this._publicCards.slice(0, 3).forEach((cur, idx) => {
                    var isLast = (idx === 2);
                    this._flipAnimation(cur, JSCodeUtility.getStringValue(cardList[idx]), isLast, idx, isLast ? callback : undefined);
                });
                Vegas_MusicUtility.playVoice("flop.mp3");
            })
        ));
    },

    /**
     * 發一張牌到Turn
     * @param {[String]}    cardList    牌
     * @param {Function}    callback    發完牌的callback
     */
    cmd_bonus_turn_cards: function (cardList, callback) {
        // 發一張牌到Turn, 並翻開
        this.runAction(cc.sequence(
            cc.callFunc(() => this.dealTurnCard()),
            cc.delayTime(BonusPokersLayer.CARD_MOVE_TIME + 0.2),
            cc.callFunc(() => {
                this._flipAnimation(this._publicCards[3], JSCodeUtility.getStringValue(cardList[3]), true, 0, callback);
                Vegas_MusicUtility.playVoice("turn.mp3");
            })
        ));
    },

    /**
     * 發一張牌到River
     * @param {[String]}    cardList    牌
     * @param {Function}    callback    發完牌的callback
     */
    cmd_bonus_river_cards: function (cardList, callback) {
        // 發一張牌到River, 並翻開
        this.runAction(cc.sequence(
            cc.callFunc(() => this.dealRiverCard()),
            cc.delayTime(BonusPokersLayer.CARD_MOVE_TIME + 0.2),
            cc.callFunc(() => {
                this._flipAnimation(this._publicCards[4], JSCodeUtility.getStringValue(cardList[4]), true, 0, callback);
                Vegas_MusicUtility.playVoice("river.mp3");
            })
        ));
    },

    /**
     * 結算
     * @param {Object}      jsonValue
     * @param {Object}      passStatus  玩家過牌的狀態
     * @param {Function}    callback    發完牌的callback
     */
    cmd_bonus_showdown: function (jsonValue, passStatus, callback) {
        // 先檢查Bonus
        var bonusParam;
        // 先檢查Bonus, 玩家沒有棄牌的情況下才比對
        if (!passStatus["bonus_flop"]) {
            bonusParam = this._checkBonus();
        }

        // 抓出莊家的牌組
        var cardList = (jsonValue["bankercards"] || []);
        if (cardList.length === 2) {
            var retCallback = undefined;
            if (callback) {
                retCallback = () => callback(bonusParam);
            }

            this._dealerCards.forEach((cur, idx) => {
                this._flipAnimation(cur, cardList[idx], true, idx, idx === 1 ? retCallback : undefined);
            });
        }
    },

    /**
     * 發莊家的牌
     */
    dealDealerCard: function () {
        this._dealerCards.forEach((cur, idx) => {
            var pos = cc.p(240 + JSScreenBonusHalfWidth + idx * 46, 260 + JSScreenBonusHalfHeight);
            this._dealAnimation(cur, pos, idx);
        });
    },

    /**
     * 轉莊家的牌
     * @param {[String]}    cardList    牌
     * @param {Function}    callback    發完牌的callback
     */
    flipDealerCard: function (cardList, callback) {
        if (cardList.length === 2)
            this._dealerCards.forEach((cur, idx) => {
                this._flipAnimation(cur, cardList[idx], true, idx, idx === 1 ? callback : undefined);
            });
    },

    /**
     * 發玩家的牌
     */
    dealPlayerCard: function () {
        this._playerCards.forEach((cur, idx) => {
            var pos = cc.p(302 + JSScreenBonusHalfWidth + idx * 20, 80 + JSScreenBonusHalfHeight);
            this._dealAnimation(cur, pos, idx);
        });
    },

    /**
     * 轉玩家的牌
     * @param {Array} cardList
     */
    flipPlayerCard: function (cardList) {
        if (cardList.length === 2) {
            this._playerCards.forEach((cur, idx) => {
                this._flipAnimation(cur, cardList[idx], true);
            });
        }
    },

    /**
     * 發FLOP的牌
     */
    dealFlopCard: function () {
        this._publicCards.slice(0, 3).forEach((cur, idx) => {
            var pos = cc.p(174 + JSScreenBonusHalfWidth + idx * 40, JSVisibleSize.height - 77 - JSScreenBonusHalfHeight);
            this._dealAnimation(cur, pos, idx);
        });
    },

    /**
     * 發TURN的牌
     */
    dealTurnCard: function () {
        var pos = cc.p(304 + JSScreenBonusHalfWidth, JSVisibleSize.height - 77 - JSScreenBonusHalfHeight);
        this._dealAnimation(this._publicCards[3], pos);
    },

    /**
     * 發RIVER的牌
     */
    dealRiverCard: function () {
        var pos = cc.p(346 + JSScreenBonusHalfWidth, JSVisibleSize.height - 77 - JSScreenBonusHalfHeight);
        this._dealAnimation(this._publicCards[4], pos);
    },

    /**
     * 轉RIVER的牌
     * @param {Array} cardList
     */
    flipRiverCard: function (cardList) {
        if (cardList.length === 1)
            this._flipAnimation(this._publicCards[4], cardList[0], true);
    },

    /**
     * 將所有牌轉到背面
     */
    flipAllCardToBack: function (callback) {
        var aniTime = BonusPokersLayer.CARD_MOVE_TIME;
        this.runAction(cc.sequence(
            cc.callFunc(() => {
                // 翻牌
                this._playerCards.forEach(cur => this._flipAnimation(cur, "", false));
                this._dealerCards.forEach(cur => this._flipAnimation(cur, "", false));
                this._publicCards.forEach(cur => this._flipAnimation(cur, "", false));
                // 這邊統一播放音效，避免_flipAnimation時一起播爆音
                Vegas_MusicUtility.playEffect("Music/Effect/turn_river.mp3");
            }),
            cc.delayTime(0.3),
            cc.callFunc(() => {
                // 把各自的牌集中一堆
                this._playerCards.forEach(cur => cur.runAction(cc.moveTo(aniTime, cc.p(JSScreenMidPos.x, 80 + JSScreenBonusHalfHeight)).easing(cc.easeExponentialOut())));
                this._dealerCards.forEach(cur => cur.runAction(cc.moveTo(aniTime, cc.p(JSScreenMidPos.x, 260 + JSScreenBonusHalfHeight)).easing(cc.easeExponentialOut())));
                this._publicCards.forEach(cur => cur.runAction(cc.moveTo(aniTime, cc.p(JSScreenMidPos.x, JSVisibleSize.height - 77 - JSScreenBonusHalfHeight)).easing(cc.easeExponentialOut())));
                // 播放音效
                Vegas_MusicUtility.playEffect("Music/Effect/flop.mp3");
            }),
            cc.delayTime(aniTime),
            cc.callFunc(() => {
                // 把所有牌收到中間
                var centerPos = cc.p(JSScreenMidPos.x, 160 + JSScreenBonusHalfHeight);
                this._playerCards.forEach(cur => cur.runAction(cc.moveTo(aniTime, centerPos).easing(cc.easeExponentialOut())));
                this._dealerCards.forEach(cur => cur.runAction(cc.moveTo(aniTime, centerPos).easing(cc.easeExponentialOut())));
                this._publicCards.forEach(cur => cur.runAction(cc.moveTo(aniTime, centerPos).easing(cc.easeExponentialOut())));
            }),
            cc.delayTime(aniTime),
            cc.callFunc(() => {
                this._playerCards.forEach(cur => this._moveCardToDiscard(cur));
                this._dealerCards.forEach(cur => this._moveCardToDiscard(cur));
                this._publicCards.forEach(cur => this._moveCardToDiscard(cur));
                // 播放音效
                Vegas_MusicUtility.playEffect("Music/Effect/flop.mp3");

                callback && callback();
            })
        ));
    },

    /**
     * 顯示贏牌
     * @param cards     贏牌的牌數值陣列
     * @param callback  callback
     */
    displayWinningCard: function (cards, callback) {
        this._playerCards.forEach(cur => this._checkIsCardWin(cur, cards, true));
        this._dealerCards.forEach(cur => this._checkIsCardWin(cur, cards));
        this._publicCards.forEach(cur => this._checkIsCardWin(cur, cards));
        this.runAction(cc.sequence(cc.delayTime(0.5), cc.callFunc(callback)));
    }
});

BonusPokersLayer.CARD_MOVE_TIME = 0.75;
BonusPokersLayer.CARD_SCALE = 0.72;
BonusPokersLayer.CARD_END_SCALE = 0.6;