var DialogPriority = {};

(function () {
    // 優先權的設定 越下面優先權越高
    // LimitIAPCouponDialog: -1,               // 限定IAP Coupon卷Banner 5.4.2詢問pm已改不彈跳
    var priorityObject = GSEnumHelper({
        // 娛樂城
        VegasRacingDialog: -1,                  // 機台任務-極速競標

        /**
         * 單一版(LuxyPoker)
         */
        PurchaseD0PayDialog: -1,                // D0儲值優惠(LuxyPoker)
        BankruptCouponDialog: -1,               // 破產儲值

        /**
         * 以下合併版(Domino)
         */
        VipFirstRechargeRemindDialog: -1,       // 首儲VIP權益提示訊息
        VipExpireDialog: -1,                    // VIP到期提醒
        RatingDislikeDialog: -1,                // 評價系統
        RatingLikeDialog: -1,                   // 評價系統
        RatingDialog: -1,                       // 評價系統(google 評分)
        KoinLuxyBannerDialog: -1,               // KL提示Banner
        ActionListDialog: -1,                   // 每日任務
        VegasSlotMachinePromoteDialog: -1,      // 機台引導
        VegasVipPromoteDialog: -1,              // Vip娛樂城導引
        VegasSlotGuideDialog: -1,               // 引導玩機台
        NewbieLevelGiftDialog: -1,              // 新玩家等級禮包

        // 以下邀請類
        CardKingInviteDialog: -1,               // 牌王戰帖
        FriendInvitationDialog: -1,             // 桌內邀請

        VipSlotGuideDialog: -1,                 // vipSlot引導
        ThirdPurchaseDialog: -1,                // 第三方儲值banner
        SettingUserProvinceDialog: -1,          // 設定居住地視窗
        RP_ResetNotifyDialog: -1,               // RP清空提醒
        FortuneWheelLobbyDialog: -1,            // 加碼轉輪領獎介面/儲值後簽到dialog
        KoinLuxyDailyPackDialog: -1,            // 領取RP商城兌換的每日禮包
        NewsWallDialog: -1,                     // 新聞牆

        // 副系統
        VegasMapMissionMainDialog: -1,          // 娛樂城副系統 - 地圖式機台任務
        GoldMedalTaskDialog: -1,                // 金牌任務
        VegasCompeteRewardDialog: -1,          // 機台爭霸賽結算
        GamblerRoadChestRewardDialog: -1,       // 牌王之路_資格賽領獎
        GamblerRoadDialog: -1,                  // 牌王之路_資格賽
        VegasDragonVsLeopardDialog: -1,         // 龍豹對決
        VegasCompeteDialog: -1,                 // 機台爭霸賽
        FierceBattleDialog: -1,                 // 激戰任務
        VegasNewbieMissionBannerDialog: -1,     // 娛樂城機台新手任務通知banner
        VegasNewbieMissionDialog: -1,           // 娛樂城機台新手任務
        TokenSubsystemMainDialog: -1,           // 代幣副系統
        LuxyPassDialog: -1,                     // LuxyPass
        RamadanSignInDialog: -1,                // 齋戒大挑戰 - 簽到
        FarmBingoDialog: -1,                    // 農場賓果
        PuzzleHomeRunDialog: -1,                // 拼圖紅不讓
        TreasureQuestDialog: -1,                // 奪寶冒險

        // 以下儲值類
        VipPurchaseDialog: -1,                  // VIP限定優惠儲值
        CouponAdvanceDialog: -1,                // 首儲卡 (晶鑽卡A B)
        TurnAroundPackDialog: -1,               // 翻倍禮包(翻身禮包)
        PayAgainCouponDialog: -1,               // 再儲值
        Coupon110Dialog: -1,                    // 再儲值小額送10%
        WelcomeDiscountDialog: -1,              // D0首儲(限時歡迎禮包)
        PurchasePackDialog_FortuneWheel: -1,    // 加碼轉輪
        PurchasePackDialog_MegaWheel: -1,       // 幸運轉輪
        PurchasePackDialog_FortuneCat: -1,      // 招財貓駕到
        PurchasePackDialog_GreatDeal: -1,       // 超值好禮
        RewardCardPurchaseDialog: -1,           // 儲值集點卡(儲值方案)
        PurchaseTriggerIntegrationDialog: -1,   // 儲值觸發整合
        TreasureBowlDialog: -1,                 // 聚寶盆(幸運雞)
        SlotAgainDialog: -1,                    // 再儲拉霸
        PurchaseBonusDialog: -1,                // 轉金樂
        PurchasePackDialog_LuckyCard: -1,       // 幸運女神禮
        TreasureBowlLimitCouponDialog: -1,      // 聚寶盆(幸運雞)限時優惠
        ThirdPayThinkTwiceDialog: -1,           // 第三方儲值優惠卷
        LifetimeCouponDialog: -1,               // 人生儲值優惠券
        RebateWalletMainDialog: -1,             // 超值返利錢包
        PurchasePackDialog_CarnivalWheel: -1,   // 轉輪大狂歡
        FreeChipLoginRewardDialog: -1,          // 特定時段登入獎勵
        GoldenEggsDialog: -1,                   // 金雞抓抓樂
        GoldRushDialog: -1,                     // 尋寶抽抽樂
        BecomeSultanDialog: -1,                 // 成為蘇丹
        BecomeSultanStyleDialog: -1,            // 成為蘇丹的額外訊息dialog
        PurchasePackDialog_SpecialGift: -1,     // 特別禮物
        PurchasePackDialog_LuckyScratch: -1,    // 好運刮刮卡
        CloneModelMainDialog: -1,               // 分身模組主視窗
        RamadanPurchasePackDialog: -1,          // 齋戒大挑戰 - 禮包
        ReceiveLimitedCouponDialog: -1,         // 給優惠券

        GapleFriendRoomNoMoneyDialog: -1,       // Gaple好友桌金額不足
        RamadanDialog: -1,                      // 齋戒副系統
        DailyLuckyWheelFullDialog: -1,          // 大廳保留輪盤lucky wheel
        FreeChipDialog: -1,                     // 免費幣
        SignInDialog: -1,                       // 每日簽到獎勵
        PurchasePackDialog_ReturnWelfare: -1,   // 回流儲值觸發
        ReturnWelfareSignInDialog: -1,          // 回流簽到
        ReturnWelfarePackDialog: -1,            // 回流禮包
        VipUpDialog: -1,                        // 儲值後跳VIP身份變化Dialog
        PrestigeReturnCarnivalDialog: -1,       // 大戶尊榮回歸 - 嘉年華
        ReturnWelfareUIHelperDialog: -1,        // 回流流程Dialog
        VipLimitDialog: -1,                     // 送玩家 VIP

        /**
         * 其它
         */
        LobbyNewbieDialog: -1,                  // 新帳號進大廳引導
        LobbyNotifyDialog: -1,                  // sever的notify指令視窗

        /**
         * 登入頁
         */
        LoginAnnounceDialog: -1,                // 登入頁的公告
        LoginServerDownDialog: -1,              // 登入失敗 Server掛掉的公告

        /**
         * 需要下載的東西放最下面
         */
        VegasDownloadDialog: -1,                // 下載娛樂城遊戲的Dialog
        Fish_DownloadDialog: -1,                // 下載捕魚遊戲的Dialog
    });

    /**
     * 抓此Dialog的priority
     */
    DialogPriority.getPriority = function (dialog) {
        var retValue = -1;
        if (dialog) {
            var value = priorityObject[dialog.key];
            if (value !== undefined) {
                retValue = value;
            }
        }

        // 統一加1 這樣比較好算 最低就是0
        return retValue + 1;
    };

    // 這邊設定把getPriority記下來 假如今天哪天外部去override 還有機會透過此抓回來
    DialogPriority.backupGetPriority = DialogPriority.getPriority;
})();
