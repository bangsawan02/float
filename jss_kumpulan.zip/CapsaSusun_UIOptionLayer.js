/**
 * CapsaSusun 遊戲內左上角的選單
 */

var CapsaSusun_UIOptionLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this._isOpen = false;

        // 選單本身
        var container = this._container = new cc.Layer();
        container.setVisible(false);
        container.setScale(0);
        container.setAnchorPoint(cc.p(0, 1));
        container.setPosition(JSScreenSafeWidth, 0);
        this.addChild(container, 10);

        // 選單本身背景
        var containerBgSprite = this._bgSprite = new ccui.Scale9Sprite("lobby_bg_list_04.png");
        containerBgSprite.setAnchorPoint(0.5, 1);
        containerBgSprite.setPreferredSize(cc.size(52, 150));
        containerBgSprite.setScaleX(3);
        containerBgSprite.setPosition(75, JSVisibleSize.height);
        container.addChild(containerBgSprite);

        // 加入選單按鈕
        var types = [
            CapsaSusun_UIOptionButton.Type.CLOSE,
            CapsaSusun_UIOptionButton.Type.TO_LOBBY,
            CapsaSusun_UIOptionButton.Type.CHANGE_TABLE,
            CapsaSusun_UIOptionButton.Type.INFO,
        ];

        var typeLen = types.length;
        this._buttons = [];
        for (var i = 0; i < typeLen; i++) {
            var button = this._buttons[i] = new CapsaSusun_UIOptionButton(types[i]);
            button.setPosition(75, JSVisibleSize.height - 18 - 36 * i);
            button.addTargetWithActionForControlEvents(this, this._menuClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
            container.addChild(button, 1);
        }

        // 打開選單按鈕
        var openMenu = new cc.Menu();
        openMenu.setPosition(0, 0);
        this.addChild(openMenu);

        var opneNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_07.png", null, "#game_btn_back.png");
        var openItem = this.openItem = new cc.MenuItemSprite(opneNodes[0], opneNodes[1], opneNodes[2], this._menuOpen, this);
        openItem.setPosition(18 + JSScreenSafeWidth, JSVisibleSize.height - 18);
        openMenu.addChild(openItem);

        // 每日任務
        var itemNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_07.png", cc.size(28, 28), "#lobby_icon_lobbyMission.png");
        var menuItem = this._missionMenuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._missionClicked, this);
        menuItem.setVisible(!DataModal.profileData.isBlackAccount);
        menuItem.setPosition(openItem.getPositionX() + 36, JSVisibleSize.height - 18);
        openMenu.addChild(menuItem);

        // 每日任務要加紅點
        var badge = new BadgeNode();
        badge.useDefaultStyle();
        badge.setPosition(26, 26);
        badge.setScale(0.9);
        menuItem.addChild(badge);

        // 每日任務可領獎的文字
        var freeSprite = new cc.Sprite("#lobby_word_reward.png");
        freeSprite.setScale(0.8);
        freeSprite.setPosition(14, -2);
        freeSprite.setOpacity(100);
        freeSprite.runAction(cc.sequence(
            cc.fadeTo(0.6, 255),
            cc.fadeTo(0.6, 100)
        ).repeatForever());
        menuItem.addChild(freeSprite);

        // 刮刮的倒數時間
        var scratchTimeLabel = new cc.LabelTTF("--:--", JSFontBoldName, 9);
        scratchTimeLabel.setPosition(cc.pAdd(menuItem.getPosition(), cc.p(0, -20)));
        scratchTimeLabel.enableStroke(JSColor.BLACK, 1);
        this.addChild(scratchTimeLabel);

        var checkMissionFunc = function () {
            var haveReward = DataModal.dailyMissionData.getActionListDialogHaveReward(DailyMissionEnum.whereType.Game);  // 每日任務有無獎勵
            var haveScratchCard = DataModal.scratchCardData.cardList.length > 0;        // 有無刮刮卡
            badge.setVisible(haveReward);
            freeSprite.setVisible(haveReward);
            scratchTimeLabel.setVisible(!haveReward && haveScratchCard);                // 有獎勵 或 沒有刮刮卡 都不顯示
        };

        var updateScratch = function () {
            // 先跑一次每日任務的 判斷是否要顯示紅點
            checkMissionFunc();

            scratchTimeLabel.stopAllActions();

            // 判斷是否要倒數
            var scratchData = DataModal.scratchCardData;
            if (scratchData.countdownSec > 0) {
                scratchTimeLabel.runAction(cc.repeatForever(cc.sequence(
                    cc.callFunc(function () {
                        if (!DataModal.gameData.haveMe) {
                            // 假如沒有自己
                            scratchTimeLabel.setString("--:--");
                            scratchTimeLabel.stopAllActions();
                            return;
                        }

                        // 先算剩餘時間
                        var nowTime = Math.floor(new Date().getTime() / 1000);
                        var nextTime = scratchData.countdownSec - (nowTime - scratchData.receiveSocketTime);
                        if (nextTime <= 0) {
                            // 等待scratch_ready cmd
                            nextTime = 0;

                            scratchTimeLabel.setString("--:--");
                            scratchTimeLabel.stopAllActions();
                            return;
                        }

                        var min = (nextTime / 60) % 60;
                        var sec = nextTime % 60;
                        scratchTimeLabel.setString(JSStringUtility.format("%02d:%02d", min, sec));
                    }, scratchTimeLabel),
                    cc.delayTime(0.5)
                )));
            } else {
                // 重置時間
                scratchTimeLabel.setString("--:--");
            }
        };
        updateScratch();

        // 自動排版
        var autoLayoutNode = new GSAutoLayoutNode();
        autoLayoutNode.setType(GSAutoLayout.TYPE.HORIZONTAL);
        autoLayoutNode.setAnchorPoint(0, 0.5);
        autoLayoutNode.setPosition(menuItem.getPositionX() + 22, JSVisibleSize.height - 17);

        // 副系統任務icon
        var missionButton = new Texas_GameMissionButton(true);
        autoLayoutNode.addChild(missionButton);

        autoLayoutNode.addEmptyNode(cc.size(20, 0));

        // 牌王之路(有排行榜, 所以zOrder要高些)
        var gamblerRoadNode = new GamblerRoadIconNode(GamblerRoadIconNode.Type.GAME);
        autoLayoutNode.addChild(gamblerRoadNode, 1);

        this.addChild(autoLayoutNode);

        // 每日任務監聽事件
        GS.addListener("NotifyUpdateDailyMission", checkMissionFunc, badge);
        GS.addListener("NotifyUpdateDailyScratch", updateScratch, badge);

        //加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this._onTouchBegan.bind(this)
        }, this);

        //通知
        GS.addListener("NotifyGameUIStandUpClicked", this.notifyGameUIStandUpClicked.bind(this), this);
        GS.addListener("NotifyGameUICancelReplaceRoom", this.notifyGameUICancelReplaceRoom.bind(this), this);
        GS.addListener("NotifyGameUICancelStandUp", this.notifyGameUICancelStandUp.bind(this), this);
        GS.addListener("NotifyShowUIOptionOpenMenu", this.notifyShowUIOptionOpenMenu.bind(this), this);
        GS.addListener("NotifyGameTableFunctionHint", this.notifyGameTableFunctionHint.bind(this), this);
    },

    clean: function () {
        this._close();
    },

    /**
     * 設定站起觀戰按鈕的enabled
     * @param value
     */
    setStandUpButtonEnabled: function (value) {
        this._items[1].setEnabled(value);
    },

    /**
     * @private
     */
    _menuOpen: function (sender) {
        this._open();
    },

    /**
     * 按到每日任務
     */
    _missionClicked: function () {
        DialogManager.addDialog(new ActionListDialog(0, DailyMissionEnum.whereType.Game, GSEnum.Game.CapsaSusun), true, true);

        // 撥放音效
        MusicUtility.playEffect("Music/Effect/button_click.mp3");

        // 關掉泡泡框
        if (this._msgNode) {
            this._msgNode.close();
            this._msgNode = undefined;
        }

        // 埋點
        DataProcess.sendString("track_daily_mission 7");
    },

    /**
     * 按下按鈕們
     * @private
     */
    _menuClicked: function (sender) {
        // 如果有Loading就不給點擊
        if (GSLoading.isLoading())
            return;

        switch (sender.buttonType) {
            case CapsaSusun_UIOptionButton.Type.CLOSE:
                // 關閉選單
                this._close();
                break;

            case CapsaSusun_UIOptionButton.Type.TO_LOBBY:
                // 返回大廳
                var nowStatus = DataModal.gameData.leaveGameStatus;
                var nextStatus;
                if (nowStatus === CapsaSusun_LeaveGameStatus.CAN_LEAVE) {
                    // 直接離桌
                    GS.dispatchCustomEvent("NotifyGameUIBackToLobbyClicked");

                    // 關掉畫面
                    this._close();
                } else {
                    // 出現訊息
                    if (nowStatus === CapsaSusun_LeaveGameStatus.BOOKING_LEAVE) {
                        // 要取消
                        nextStatus = CapsaSusun_LeaveGameStatus.NO_LEAVE;
                    } else {
                        // 要去預約離開
                        nextStatus = CapsaSusun_LeaveGameStatus.BOOKING_LEAVE;
                    }

                    // 先把換桌的取消
                    if (nowStatus === CapsaSusun_LeaveGameStatus.BOOKING_CHANGE_TABLE)
                        DataProcess.sendString("order_quickJoin 0");

                    // 跟Server通知現在狀態
                    DataProcess.sendString("order_toLobby " + (nextStatus === CapsaSusun_LeaveGameStatus.BOOKING_LEAVE ? "1" : "0"));

                    // 設定回去現在的狀態
                    DataModal.gameData.leaveGameStatus = nextStatus;

                    // 顯示訊息
                    var hintString = nextStatus === CapsaSusun_LeaveGameStatus.NO_LEAVE ? "已取消預約離桌" : "本局結束將回遊戲大廳";
                    GS.dispatchCustomEvent("NotifyShowTopMessage", LocalizedString.Game(hintString));

                    // 更新按鈕
                    this._buttons.forEach(button => button.updateButton());
                }

                break;
            case CapsaSusun_UIOptionButton.Type.CHANGE_TABLE:
                // 更換牌桌
                var nowStatus = DataModal.gameData.leaveGameStatus;
                var nextStatus;
                if (nowStatus === CapsaSusun_LeaveGameStatus.CAN_LEAVE) {
                    // 直接換桌
                    GS.dispatchCustomEvent("NotifyGameUIChangePlaceClicked", {isReplaceRoomByClickedUIButton: true});

                    // 關掉畫面
                    this._close();
                } else {
                    // 出現訊息
                    if (nowStatus === CapsaSusun_LeaveGameStatus.BOOKING_CHANGE_TABLE) {
                        // 要取消
                        nextStatus = CapsaSusun_LeaveGameStatus.NO_LEAVE;
                    } else {
                        // 要去預約離開
                        nextStatus = CapsaSusun_LeaveGameStatus.BOOKING_CHANGE_TABLE;
                    }

                    // 先把離開的取消
                    if (nowStatus === CapsaSusun_LeaveGameStatus.BOOKING_LEAVE)
                        DataProcess.sendString("order_toLobby 0");

                    // 跟Server通知現在狀態
                    DataProcess.sendString("order_quickJoin " + (nextStatus === CapsaSusun_LeaveGameStatus.BOOKING_CHANGE_TABLE ? "1" : "0"));

                    // 設定回去現在的狀態
                    DataModal.gameData.leaveGameStatus = nextStatus;

                    var hintString = nextStatus === CapsaSusun_LeaveGameStatus.NO_LEAVE ? "已取消預約換桌" : "本局結束將幫您換新一桌";
                    GS.dispatchCustomEvent("NotifyShowTopMessage", LocalizedString.Game(hintString));

                    // 更新按鈕
                    this._buttons.forEach(button => button.updateButton());
                }

                break;
            case CapsaSusun_UIOptionButton.Type.INFO:
                // 算分規則
                DialogManager.addDialog(new WebViewDialog(TexasUtility.getSimpleInfoURLByKey("capsaSusunRule", "page=rule")));

                // 關掉畫面
                this._close();
                break;
        }
    },

    /**
     * 打開選單
     * @private
     */
    _open: function () {
        if (this._isOpen) {
            return;
        }
        this._isOpen = true;

        this.openItem.setEnabled(false);
        this.openItem.stopAllActions();
        this.openItem.runAction(cc.sequence(cc.scaleTo(0.15, 0).easing(cc.easeBackIn()), cc.hide()));
        this._container.stopAllActions();
        this._container.runAction(cc.sequence(cc.delayTime(0.15), cc.show(), cc.scaleTo(0.25, 1).easing(cc.easeBackOut())));

        // 更新一次按鈕
        this._buttons.forEach(button => button.updateButton());
    },

    /**
     * 關開選單
     * @private
     */
    _close: function () {
        if (!this._isOpen) {
            return;
        }
        this._isOpen = false;

        this._container.stopAllActions();
        this._container.runAction(cc.sequence(cc.scaleTo(0.25, 0).easing(cc.easeBackIn()), cc.hide()));
        this.openItem.setEnabled(true);
        this.openItem.stopAllActions();
        this.openItem.runAction(cc.sequence(cc.delayTime(0.25), cc.show(), cc.scaleTo(0.15, 1).easing(cc.easeBackOut())));
    },

    /**
     * 每日任務提示泡泡框
     */
    _showDailyMissionHintMsg: function (msg, time = 2) {
        if (msg && msg.length) {
            if (this._msgNode) {
                this._msgNode = undefined;
            }

            // 泡泡框
            var msgLabel = new GSRichTextNode("#!000000!#" + msg, JSFontName, 12);
            var msgLabelHalfWidth = msgLabel.getContentSize().width / 2;
            var param = {
                mainNode: msgLabel,
                style: BaseMessageNode.Style.WHITE,
                direct: BaseMessageNode.Direct.UP,
                arrowType: BaseMessageNode.ArrowType.STRAIGHT,
                arrowPadding: (msgLabelHalfWidth < 20) ? 0 : msgLabelHalfWidth - 20,
                closeCallback: () => {
                    // 拿掉泡泡框
                    if (this._msgNode) {
                        this._msgNode = undefined;
                    }
                }
            };

            var targetPos = this._missionMenuItem.getPosition();
            var msgNode = this._msgNode = new BaseMessageNode(param);
            msgNode.setPosition(targetPos.x, targetPos.y - 16);
            msgNode.show(time);
            this.addChild(msgNode, 2);
        }
    },

    /**
     * 按"站起觀戰"按鈕
     * @private
     */
    notifyGameUIStandUpClicked: function () {
        DataProcess.sendString("stand");
    },

    /**
     * 取消換房 / 站起
     */
    notifyGameUICancelReplaceRoom: function () {
        this.stopAllActions();
        this._items[2].setEnabled(true);
    },

    notifyGameUICancelStandUp: function () {
        this.stopAllActions();
        this._items[1].setEnabled(true);
    },

    /**
     * 打開選單
     */
    notifyShowUIOptionOpenMenu: function () {
        this._open();
    },

    /**
     * 牌桌內功能提示
     */
    notifyGameTableFunctionHint: function (event) {
        var hintType = event.getUserData();
        if (hintType === NewbieData.GameTableFunctionHintType.DAILY_MISSION && this._missionMenuItem.isVisible()) {
            // 泡泡框
            this._showDailyMissionHintMsg(LocalizedString.Game("完成任務拿獎勵!"), 3);

            // 紀錄已經跳過
            DataModal.newbieData.saveGameTableFunctionShowed(hintType);
        }
    },

    /**
     * Touch相關
     * @private
     */
    _onTouchBegan: function (touch, event) {
        var touchPos = this.convertToNodeSpace(touch.getLocation());
        if (!cc.rectContainsPoint(this._bgSprite.getBoundingBox(), touchPos)) {
            this._close();
            return false;
        }

        return this._isOpen;
    }
});