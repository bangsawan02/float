/**
 * v5.5.1 首儲禮包頁面
 * created by andrew.chang
 */
var FirstPayPageLayer = PurchaseTriggerIntegrationPageLayer.extend({
    ctor: function (dialog) {
        this._super(dialog);

        this.key = "FirstPayPageLayer";
        this.type = PurchaseTriggerIntegrationData.purchaseType.FIRST_PAYMENT;

        // 要讀的素材
        this.loadFileArray = [
            "purchaseTriggerIntegration/firstPay.plist", "purchaseTriggerIntegration/firstPay.png",
            "common/number/num_gold1.plist", "common/number/num_gold1.png"
        ];
    },

    onEnter: function () {
        this._super();

        // 更新小紅點
        DataModal.purchaseTriggerIntegrationData.setBadgeRecordByType(PurchaseTriggerIntegrationData.purchaseType.FIRST_PAYMENT);

        // TODO:
        DataProcess.sendCustomStringToSelf("clientLog: FirstPayPageLayer onEnter");
    },

    onExit: function () {
        // TODO:
        DataProcess.sendCustomStringToSelf("clientLog: FirstPayPageLayer onExit");

        this._super();
    },

    // Override
    setVisible: function (value) {
        if (value === this.isVisible())
            return;

        this._super(value);

        // 畫面被隱藏(自己切換頁籤or活動時間到被整合視窗隱藏)，要清掉跟儲值有關的東西
        if (!value) {
            // 清掉儲值類型
            DataModal.purchaseTriggerIntegrationData.nowPurchaseType = -1;
        }
    },

    /**
     * @override
     */
    loadFileDone: function () {
        this._super();

        // 放內容的node
        var contentNode = this._contentNode = new cc.Node();
        contentNode.setPosition(JSScreenMidPos.x + 48, JSScreenMidPos.y);
        this.addChild(contentNode);

        // 刷新畫面
        this._refreshView();

        // 監聽
        GS.addListener("NotifyPurchaseSuccess", this.notifyPurchaseSuccess.bind(this), this);
    },

    _refreshView: function () {
        // 拿掉loading
        this.setLoadingSprite(false, false);

        var param = this._param = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.FIRST_PAYMENT);
        if (!param || !param.isOpen) {
            return;
        }

        var localStr = LocalizedString.Purchase;

        // 清掉所有東西
        var contentNode = this._contentNode;
        contentNode.removeAllChildren();

        // 是不是禮包A
        var isPackA = param.type === PurchaseTriggerIntegrationData.firstPaymentType.PACK_A;
        if (isPackA) {
            // ----底圖區----
            {
                // 背景
                [0.88, -0.88].forEach((cur, index) => {
                    var bgSprite = new cc.Sprite("#firstPay_bgA.png");
                    bgSprite.setAnchorPoint(0, 0.5);
                    bgSprite.setPosition(!index ? -0.5 : 0.5, -8);
                    bgSprite.setScaleX(cur);
                    contentNode.addChild(bgSprite);
                });

                [
                    {rotation: 25, pos: cc.p(-169, 101)},
                    {rotation: -30, pos: cc.p(188, -54)}
                ].forEach((cur, index) => {
                    // 紙片
                    var chipSprite = new cc.Sprite("#firstPay_pic_paperflower.png");
                    chipSprite.setRotation(cur.rotation);
                    !!index && chipSprite.setFlippedX(true);
                    chipSprite.setPosition(cur.pos);
                    contentNode.addChild(chipSprite);
                });

                // 標題背景
                for (let i = 0; i < 2; i++) {
                    var titleBgSprite = new cc.Sprite("#firstPay_pic_ribbon.png");
                    titleBgSprite.setPosition(0, 102);
                    titleBgSprite.setAnchorPoint(cc.p(i, .5));
                    !i && titleBgSprite.setFlippedX(true);
                    contentNode.addChild(titleBgSprite);
                }

                // 標題星星
                for (let i = 0; i < 2; i++) {
                    var starSprite = new cc.Sprite("#firstPay_p_star02.png");
                    starSprite.setPosition(!i ? -95 : 95, 110);
                    !!i && starSprite.setFlippedX(true);
                    contentNode.addChild(starSprite);
                }

                // 標題
                var titleSprite = new cc.Sprite("#firstPay_word_maxStored.png");
                titleSprite.setPosition(0, 108);
                contentNode.addChild(titleSprite);

                // 副標題
                var subTitleAutoLayoutNode = new GSAutoLayoutNode();
                subTitleAutoLayoutNode.setType(GSAutoLayout.TYPE.HORIZONTAL_TOP);
                subTitleAutoLayoutNode.setPosition(75, 47);
                contentNode.addChild(subTitleAutoLayoutNode);

                subTitleAutoLayoutNode.addChild(new cc.Sprite("#firstPay_word_title_01.png"));

                var pointNode = new GSSpriteNumberNode({
                    number: param.multiple,
                    numStr: "#num_gold1_",
                    spW: 33,
                    spH: 14
                });
                pointNode.setScale(0.6);
                subTitleAutoLayoutNode.addChild(pointNode);

                subTitleAutoLayoutNode.addChild(new cc.Sprite("#firstPay_pic_word.png"));

                // 右上對話框
                var popNode = new cc.Node();
                popNode.setPosition(170, 89);
                contentNode.addChild(popNode, 1);

                // 背景
                var popBgSprite = new cc.Sprite("#firstPay_pic_bubble.png");
                popBgSprite.setScale(0.73);
                popNode.addChild(popBgSprite);

                // 文字
                var label = new cc.LabelTTF(JSStringUtility.format(localStr("已有\n%d人購買"), param.sales), JSFontName, 8);
                label.setPosition(0, 3);
                label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                label.setFontFillColor(cc.color(29, 0, 174));
                popNode.addChild(label);

                // 右上對話框動畫
                popNode.runAction(cc.sequence(
                    cc.moveTo(1, 170, 93),
                    cc.moveTo(1, 170, 89)
                ).repeatForever());
            }

            //----content 內容區----
            {
                // 左邊獎勵
                var rewardNode = new cc.Node();
                rewardNode.setPosition(-110, -10);
                contentNode.addChild(rewardNode);

                // 背景
                var bg = new ccui.Scale9Sprite("firstPay_bg_black_00.png");
                bg.setPreferredSize(cc.size(102, 125));
                rewardNode.addChild(bg);

                // 背景光
                var light = new cc.Sprite("#bg_radiateLight.png");
                light.setRotation(-15);
                rewardNode.addChild(light);

                // 德撲幣禮包
                var giftSprite = new cc.Sprite("#firstPay_pic_gift.png");
                giftSprite.setPosition(0, 6);
                rewardNode.addChild(giftSprite);

                // 獎勵文字背景
                for (var i = 0; i < 2; i++) {
                    var isRight = (i === 1);
                    var pinkBgSprite = new ccui.Scale9Sprite("firstPay_pic_name.png");
                    pinkBgSprite.setAnchorPoint(isRight ? 0 : 1, 0.5);
                    isRight && pinkBgSprite.setFlippedX(true);
                    pinkBgSprite.setPosition(0, -46);
                    rewardNode.addChild(pinkBgSprite);
                }

                // 獎勵文字
                var rewardLabel = new cc.LabelTTF(JSStringUtility.format("%s chips", TexasUtility.getSimpleNumber(param.money, 2)), JSFontName, 10);
                rewardLabel.setFontFillColor(JSColor.YELLOW);
                rewardLabel.setPosition(0, -46);
                rewardNode.addChild(rewardLabel);

                // 胸花
                var corsageSprite = new cc.Sprite("#firstPay_pic_corsage.png");
                corsageSprite.setPosition(46, 56);
                rewardNode.addChild(corsageSprite);

                // 文字
                var coinLabel = new cc.LabelTTF(JSStringUtility.format(localStr("優惠\n%d%%"), param.bonus), JSFontBoldName, 8);
                coinLabel.setPosition(46, 61);
                coinLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                coinLabel.setFontFillColor(cc.color(46, 19, 86));
                rewardNode.addChild(coinLabel);

                // 加號
                var plusSprite = new cc.Sprite("#firstPay_pic_plus.png");
                plusSprite.setPosition(-41, -13);
                plusSprite.setScale(1.3);
                contentNode.addChild(plusSprite);

                // 右邊獎勵
                var rewardParams = param.rewards || [];
                for (let i = 0; i < Math.min(rewardParams.length, 3); i++) {
                    var node = new cc.Node();
                    node.setPosition(7 + i * 68, -20);
                    contentNode.addChild(node);

                    // 背景
                    var itemBgSprite = new ccui.Scale9Sprite("firstPay_bg_white.png");
                    itemBgSprite.setPreferredSize(cc.size(69, 112));
                    itemBgSprite.setCapInsets(cc.rect(21, 21, 77, 109));
                    node.addChild(itemBgSprite);

                    // 獎勵文字背景
                    for (var j = 0; j < 2; j++) {
                        var isRight = (j === 1);
                        var labelBgSp = new cc.Sprite("#firstPay_pic_name.png");
                        labelBgSp.setScale(0.6, 1.3);
                        labelBgSp.setAnchorPoint(isRight ? 0 : 1, 0.5);
                        isRight && labelBgSp.setFlippedX(true);
                        labelBgSp.setPosition(isRight ? -0.1 : 0.1, -19);
                        node.addChild(labelBgSp);
                    }

                    // 獎勵
                    var saveFileName = JSStringUtility.format("%sshop/%d.png", JSWriteablePath, rewardParams[i].serial);
                    var reward = new GSDownloadSprite("", TexasUtility.getItemImageUrl(rewardParams[i].serial), saveFileName);
                    reward.setTargetSize(cc.size(60, 60));
                    reward.setPosition(0, 20);
                    node.addChild(reward);

                    // 獎勵文字
                    var rewardLabel = new cc.LabelTTF(rewardParams[i].name, JSFontName, 7);
                    rewardLabel.setDimensions(cc.size(50, 0));
                    rewardLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                    rewardLabel.setPosition(0, -19);
                    rewardLabel.setFontFillColor(cc.color(255, 240, 54));
                    node.addChild(rewardLabel);

                    // 獎勵文字 數量
                    var numLabel = new cc.LabelTTF(JSStringUtility.format("x%s", rewardParams[i].count), JSFontName, 10);
                    numLabel.setPosition(0, -40);
                    numLabel.setFontFillColor(JSColor.BLACK);
                    node.addChild(numLabel);
                }
            }
        } else {
            // 背景
            {
                // 粉色邊邊背景
                for (let i = 0; i < 2; i++) {
                    var purpleBgSprite = new cc.Sprite("#firstPay_bg_purple_02.png");
                    purpleBgSprite.setPositionX(!i ? -171 : 171);
                    !!i && purpleBgSprite.setFlippedX(true);
                    contentNode.addChild(purpleBgSprite);
                }

                // 粉色背景
                var purpleBgSprite = new ccui.Scale9Sprite("firstPay_bg_purple_03.png");
                purpleBgSprite.setPreferredSize(cc.size(297, 173));
                contentNode.addChild(purpleBgSprite);

                // 裝飾燈泡
                for (let i = 0; i < 2; i++) {
                    var lightSprite = new cc.Sprite("#firstPay_pic_light_01.png");
                    lightSprite.setPosition(!i ? 100 : -100, 44);
                    !!i && lightSprite.setFlippedX(true);
                    contentNode.addChild(lightSprite);
                }
            }

            // 標題
            {
                // 標題旁星星
                for (let i = 0; i < 2; i++) {
                    var titleStarSprite = new cc.Sprite("#firstPay_pic_star.png");
                    titleStarSprite.setPosition(!i ? -118 : 118, 91);
                    !!i && titleStarSprite.setFlippedX(true);
                    contentNode.addChild(titleStarSprite);
                }

                // 標題
                var titleSprite = new cc.Sprite("#firstPay_word_starStored.png");
                titleSprite.setPosition(0, 97);
                contentNode.addChild(titleSprite);
            }

            // 獎勵
            {
                // 左邊獎勵
                var rewardNode = new cc.Node();
                rewardNode.setPosition(-90, -1);
                contentNode.addChild(rewardNode);

                // 黑底背景
                var blackBgSprite = new ccui.Scale9Sprite("firstPay_bg_black_00.png");
                blackBgSprite.setPreferredSize(cc.size(104, 117));
                rewardNode.addChild(blackBgSprite);

                // 物品背後光
                var lightSprite = new cc.Sprite("#bg_radiateLight.png");
                lightSprite.setPosition(0, 5);
                rewardNode.addChild(lightSprite);

                // 德撲幣禮包
                var giftSprite = new cc.Sprite("#firstPay_pic_gift.png");
                giftSprite.setPosition(0, 5);
                rewardNode.addChild(giftSprite);

                // 文字粉色背景
                for (var i = 0; i < 2; i++) {
                    var isRight = (i === 1);
                    var pinkBgSprite = new ccui.Scale9Sprite("firstPay_pic_name.png");
                    pinkBgSprite.setAnchorPoint(isRight ? 0 : 1, 0.5);
                    isRight && pinkBgSprite.setFlippedX(true);
                    pinkBgSprite.setPosition(0, -42);
                    rewardNode.addChild(pinkBgSprite);
                }

                // 文字
                var coinLabel = new cc.LabelTTF(JSStringUtility.format("%s chips", TexasUtility.getSimpleNumber(param.money, 2)), JSFontBoldName, 10);
                coinLabel.setPosition(0, -42);
                coinLabel.setFontFillColor(JSColor.YELLOW);
                rewardNode.addChild(coinLabel);

                // 胸花
                var corsageSprite = new cc.Sprite("#firstPay_pic_corsage.png");
                corsageSprite.setPosition(55, 41);
                rewardNode.addChild(corsageSprite);

                // 文字
                var coinLabel = new cc.LabelTTF(JSStringUtility.format(localStr("優惠\n%d%%"), param.bonus), JSFontBoldName, 8);
                coinLabel.setPosition(55, 46);
                coinLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                coinLabel.setFontFillColor(cc.color(46, 19, 86));
                rewardNode.addChild(coinLabel);

                // 加號
                var plusSprite = new cc.Sprite("#firstPay_pic_plus.png");
                plusSprite.setPosition(-16, -4);
                plusSprite.setScale(1.2);
                contentNode.addChild(plusSprite);

                // 右邊獎勵
                var rewardParams = param.rewards || [];
                for (var i = 0; i < Math.min(rewardParams.length, 2); i++) {
                    var node = new cc.Node();
                    node.setPosition(37 + i * 70, -4);
                    contentNode.addChild(node);

                    // 物品白背景
                    var itemBgSprite = new ccui.Scale9Sprite("firstPay_bg_white.png");
                    itemBgSprite.setCapInsets(cc.rect(21, 21, 77, 109));
                    itemBgSprite.setPreferredSize(cc.size(69, 114));
                    node.addChild(itemBgSprite);

                    // 文字粉色背景
                    for (var j = 0; j < 2; j++) {
                        var isRight = (j === 1);
                        var labelBgSp = new cc.Sprite("#firstPay_pic_name.png");
                        labelBgSp.setScale(0.6, 1.3);
                        labelBgSp.setAnchorPoint(isRight ? 0 : 1, 0.5);
                        isRight && labelBgSp.setFlippedX(true);
                        labelBgSp.setPosition(isRight ? -0.1 : 0.1, -19);
                        node.addChild(labelBgSp);
                    }

                    // 獎勵
                    var saveFileName = JSStringUtility.format("%sshop/%d.png", JSWriteablePath, rewardParams[i].serial);
                    var reward = new GSDownloadSprite("", TexasUtility.getItemImageUrl(rewardParams[i].serial), saveFileName);
                    reward.setTargetSize(cc.size(60, 60));
                    reward.setPositionY(21);
                    node.addChild(reward);

                    var rewardLabel = new cc.LabelTTF(rewardParams[i].name, JSFontBoldName, 7);
                    rewardLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                    rewardLabel.setDimensions(cc.size(50, 0));
                    rewardLabel.setPositionY(-18);
                    rewardLabel.setFontFillColor(cc.color(255, 240, 54));
                    node.addChild(rewardLabel);

                    var rewardCountLabel = new cc.LabelTTF(JSStringUtility.format("x%s", rewardParams[i].count), JSFontBoldName, 10);
                    rewardCountLabel.setPositionY(-41);
                    rewardCountLabel.setFontFillColor(JSColor.BLACK);
                    node.addChild(rewardCountLabel);
                }
            }

            // 硬幣堆
            [-130, 139].forEach(cur => {
                var coinSprite = new cc.Sprite("#firstPay_pic_coins005.png");
                coinSprite.setScale(0.65);
                coinSprite.setFlippedX(true);
                coinSprite.setPosition(cur, -86);
                contentNode.addChild(coinSprite);
            });
        }

        // 倒數時間icon
        var clockSp = new cc.Sprite("#lobby_pic_clock_02.png");
        clockSp.setScale(0.6);
        clockSp.setPosition(isPackA ? cc.p(107, -92) : cc.p(-30, -68));
        contentNode.addChild(clockSp);

        // 倒數時間
        var timeLabel = new GSTimeLabel("", JSFontBoldName, 12);
        timeLabel.setPosition(isPackA ? cc.p(140, -92) : cc.p(5, -68));
        timeLabel.setFormat("%hh:%mm:%ss");
        contentNode.addChild(timeLabel);

        // 倒數完不做事，由主視窗自己判斷關閉
        timeLabel.countdownSeconds(JSCodeUtility.getRemainTime(param.countDownTime, param.socketTime), undefined, undefined);

        // 問號按鈕
        var infoBtn = new Texas_ExplainButton(this._explainBtnStyle);
        infoBtn.addTouchUpInsideAction(this._infoBtnClicked, this);
        infoBtn.setPosition(-169, isPackA ? 78 : 63);
        contentNode.addChild(infoBtn);

        // 按鈕
        var btn = ButtonUtility.createSimpleButton("firstPay_button_green_02.png", cc.size(108, 40),
            JSStringUtility.format(localStr("Rp %s 搶購"), JSCodeUtility.getCurrencyString(param.button)), JSColor.WHITE, 12);
        btn.label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        btn.addTouchUpInsideAction(this._purchaseClicked, this);
        btn.runAction(Texas_AnimationUtility.buttonScaleAni().repeatForever());
        btn.setPositionY(isPackA ? -108 : -96);
        contentNode.addChild(btn);

        // 埋點
        // C->S track_first_payment {"type":"4","value":"1","button":"120"}
        // > type:4 進入畫面
        // > value:1 #禮包樣式info的type
        // > button:120 #info的button
        var trackParam = {type: 4, value: param.type, button: param.button};
        DataProcess.sendString("track_first_payment " + JSON.stringify(trackParam));
    },

    /**
     * 按下儲值按鈕
     */
    _purchaseClicked: function () {
        if (!this._param)
            return;

        // 埋點
        // C->S track_first_payment {"type":"1","value":"1","button":"120"}
        // > type:1 點擊儲值按鈕
        // > value:1 #禮包樣式info的type
        // > button:120 #info的button
        var param = {type: 1, value: this._param.type, button: this._param.button};
        DataProcess.sendString("track_first_payment " + JSON.stringify(param));

        // 去儲值
        var productParam = this._param.productParam;
        if (!productParam || !productParam.productIDList.length)
            return;

        // 判斷有沒有第三方
        if (productParam.productIDList.length > 1) {
            productParam.callBackFunc = () => {
                // 按下方案後，設定儲值類型
                DataModal.purchaseTriggerIntegrationData.nowPurchaseType = this.type;
            };

            // 通知跳出儲值管道選擇視窗
            DialogManager.addDialog(new ProviderChooseDialog(productParam), false);
        } else {
            // 記下儲值類型
            DataModal.purchaseTriggerIntegrationData.nowPurchaseType = this.type;
            DataModal.purchaseData.sendPurchase(productParam.productIDList[0]);
        }
    },

    /**
     * 建立說明頁 dialog
     */
    _createInfoDialog: function () {
        return new WebViewDialog(TexasUtility.getSimpleInfoURLByKey("first_payment", "&page=" + this._param.type));

    },

    /**
     * 點擊說明按鈕
     */
    _infoBtnClicked: function () {
        this.showInfoDialog();
    },

    /**
     * 儲值成功
     */
    notifyPurchaseSuccess: function () {
        // 沒有顯示的時候不處理 & 非該儲值類型
        if (!this.isVisibleRecursive() || DataModal.purchaseTriggerIntegrationData.nowPurchaseType !== this.type)
            return;

        // 清掉儲值類型
        DataModal.purchaseTriggerIntegrationData.nowPurchaseType = -1;

        // 記下儲值成功
        DataModal.purchaseTriggerIntegrationData.firstPaymentData.purchaseSuccess = true;

        var param = this._param;

        // 德撲幣
        var content = JSStringUtility.format("chip x %s", TexasUtility.getSimpleNumber(param.money, 2));

        // 其他獎勵
        var paramStringList = param.rewards.map((cur) => JSStringUtility.format("%s x %s", cur.name, cur.count));
        if (paramStringList.length > 0) {
            content += "\n" + paramStringList.join('\n');
        }

        // 跳提示Dialog
        this.showDialog(new FirstPayCommonDialog({
            title: LocalizedString.Purchase("儲值成功!恭喜您獲得"),
            content: content,
            callback: () => {
                // 清掉資料
                DataModal.purchaseTriggerIntegrationData.firstPaymentData = undefined;
                DataModal.purchaseTriggerIntegrationData.updateOpenPurchaseActivityCount();

                // 關閉Dialog
                this.closeDialogAnimation();
            }
        }));

        // 儲值成功 server主動傳 S->C first_payment_info
    }
});