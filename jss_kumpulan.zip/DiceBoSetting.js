var DiceBoMoneyType = {
    Small_MAX: 200000000,           // 投注總上限 (小注)
    Small_UP: 200000000,            // 任意豹子、數字區上限 (小注)
    Small_DOWN: 200000000,          // 大小單雙三骰上限 (小注)
    Big_MAX: 6000000000,            // 投注總上限 (大注)
    Big_UP: 1500000000,             // 任意豹子、數字區上限 (大注)
    Big_DOWN: 1500000000            // 大小單雙三骰上限 (大注)
};

// 下注區域Enum
var DiceBoZoneType = {
    BIG: 1,
    SMALL: 2,
    TRIPLE_1: 3,
    TRIPLE_2: 4,
    TRIPLE_3: 5,
    TRIPLE_4: 6,
    TRIPLE_5: 7,
    TRIPLE_6: 8,
    TRIPLE_ANY: 9,
    NUMBER_4: 10,
    NUMBER_5: 11,
    NUMBER_6: 12,
    NUMBER_7: 13,
    NUMBER_8: 14,
    NUMBER_9: 15,
    NUMBER_10: 16,
    NUMBER_11: 17,
    NUMBER_12: 18,
    NUMBER_13: 19,
    NUMBER_14: 20,
    NUMBER_15: 21,
    NUMBER_16: 22,
    NUMBER_17: 23,
    DICE_NUM1: 24,
    DICE_NUM2: 25,
    DICE_NUM3: 26,
    DICE_NUM4: 27,
    DICE_NUM5: 28,
    DICE_NUM6: 29,
};

// 下注的賠率 對應到ZoneType
var DiceBoWinRatio = [0, 1.02, 1.02, 210, 210, 210, 210, 210, 210, 34, 69, 34, 20, 13, 9, 7.45, 6.8, 6.8, 7.45, 9, 13, 20, 34, 69, 1, 2.3, 12];