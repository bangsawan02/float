/**
 * CapsaSusun 遊戲左上角選單的按鈕
 */

var CapsaSusun_UIOptionButton = cc.ControlButton.extend({
    ctor: function (type) {
        this._super();

        this.buttonType = type;

        var localString = LocalizedString.Game;

        // 先把此按鈕的圖片做好
        var btnSize = cc.size(135, 27);
        var midPos = cc.p(btnSize.width / 2, btnSize.height / 2);

        var node = this._mainNode = new ccui.Scale9Sprite();
        node.setCascadeColorEnabled(true);
        node.setCascadeOpacityEnabled(true);
        node.setContentSize(btnSize);

        if (type !== CapsaSusun_UIOptionButton.Type.CLOSE) {
            // 背景
            var bgSprite = new ccui.Scale9Sprite("lobby_btn_07.png");
            bgSprite.setPreferredSize(btnSize);
            bgSprite.setPosition(midPos);
            node.addChild(bgSprite);
        }

        var iconName, wordName;
        switch (type) {
            case CapsaSusun_UIOptionButton.Type.CLOSE:
                iconName = "#game_btn_back.png";
                wordName = "關閉選單";
                break;
            case CapsaSusun_UIOptionButton.Type.TO_LOBBY:
                iconName = "#game_btn_leave.png";
                wordName = "離桌";
                break;
            case CapsaSusun_UIOptionButton.Type.CHANGE_TABLE:
                iconName = "#game_btn_random.png";
                wordName = "換桌";
                break;
            case CapsaSusun_UIOptionButton.Type.INFO:
                iconName = "#game_btn_teach.png";
                wordName = "算分規則";
                break;
        }

        // Icon
        var iconSprite = new cc.Sprite(iconName);
        iconSprite.setPosition(midPos.x - 48, midPos.y);
        node.addChild(iconSprite);

        // 文字
        var nameLabel = this._nameLabel = new cc.LabelTTF(localString(wordName), JSFontBoldName, 9);
        nameLabel.setPosition(midPos.x + 12, midPos.y);
        node.addChild(nameLabel);

        // 更新一次按鈕畫面
        this.updateButton();

        // 自己的設定
        this.setPreferredSize(btnSize);         // 一定要加這行 Native才會是對的
        this.setBackgroundSpriteForState(node, cc.CONTROL_STATE_NORMAL);
        this.addTargetWithActionForControlEvents(this, this._buttonClicked,
            cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
            cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
            cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
        this.setAdjustBackgroundImage(false);
        this.setZoomOnTouchDown(false);
        this.setSwallowTouches(true);
        this.setTouchDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
    },

    /**
     * 更新按鈕畫面
     */
    updateButton: function () {
        var leaveStatus = DataModal.gameData.leaveGameStatus;
        var nameLabel = this._nameLabel;
        switch (this.buttonType) {
            case CapsaSusun_UIOptionButton.Type.TO_LOBBY:
                var isBooking = leaveStatus === CapsaSusun_LeaveGameStatus.BOOKING_LEAVE;
                nameLabel.setString(LocalizedString.Game(isBooking ? "取消離桌" : "離桌"));
                nameLabel.setFontFillColor(isBooking ? JSColor.YELLOW : JSColor.WHITE);
                break;
            case CapsaSusun_UIOptionButton.Type.CHANGE_TABLE:
                var isBooking = leaveStatus === CapsaSusun_LeaveGameStatus.BOOKING_CHANGE_TABLE;
                nameLabel.setString(LocalizedString.Game(isBooking ? "取消換桌" : "換桌"));
                nameLabel.setFontFillColor(isBooking ? JSColor.YELLOW : JSColor.WHITE);
                break;
        }
    },

    /**
     * 按到的時後 要改變顏色
     */
    _buttonClicked: function (sender, type) {
        var isTouched = (type === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || type === cc.CONTROL_EVENT_TOUCH_DOWN);
        this._mainNode.setColor(isTouched ? JSColor.GRAY : JSColor.WHITE);
    },
});

CapsaSusun_UIOptionButton.Type = {
    CLOSE: 0,
    TO_LOBBY: 1,
    CHANGE_TABLE: 2,
    INFO: 3,
};