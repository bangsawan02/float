/**
 * v5.4.8 成為蘇丹 儲值Dialog
 * 首次主動跳的時候要顯示椅子動畫
 *
 * create by Wen
 */

var BecomeSultanDialog = BaseDialogLayer.extend({
    ctor: function (param) {
        this._super();

        this.key = "BecomeSultanDialog";
        this._param = param;
        this._isPurchased = false;   // 已儲值
        this._isEventEnd = false;    // 是不是活動結束了

        // 需要讀取的素材
        this.loadFileArray = ["lobby/becomeSultan.plist", "lobby/becomeSultan.png"];
    },

    onExit: function () {
        if (this._loadFileDone)
            cc.spriteFrameCache.removeSpriteFramesFromFile("lobby/becomeSultan.plist");

        this._super();
    },

    /**
     * 讀取素材完畢
     * @override
     */
    loadFileDone: function () {
        this._super();

        // 先讀圖片Plist
        cc.spriteFrameCache.addSpriteFrames("lobby/becomeSultan.plist", "lobby/becomeSultan.png");

        // 判斷是不是第一次
        var param = this._param;
        var isFirstTime = param && param.isNewPeriod;
        this._refreshView(isFirstTime);

        // 註冊
        GS.addListener("NotifyBecomeSultanInfoDone", this.notifyBecomeSultanInfoDone.bind(this), this);
        GS.addListener("NotifyBecomeSultanRechargeDone", this.notifyBecomeSultanRechargeDone.bind(this), this);

        // 送server埋點
        var trackParam = {
            click_type: "1",
            group: DataModal.purchaseCouponData.becomeSultanInfo.group
        };
        DataProcess.sendString("track_sultan_king " + JSON.stringify(trackParam));
    },

    // 刷新畫面
    _refreshView: function (isNewPeriod) {
        if (isNewPeriod)
            this._createChairAnimation();
        else
            this._createMainPurchaseBanner();
    },

    // 創立椅子動畫，只有server第一次噴的時候要顯示
    _createChairAnimation: function () {
        var aniLayer = this._animationLayer;
        aniLayer.removeAllChildren();

        // 背景 左右對稱
        for (var i = 0; i < 2; i++) {
            // 椅子背景
            var chairBg = new cc.Sprite("#becomeSultan_bg_chair.png");
            chairBg.setPosition(JSScreenMidPos.x - 0.15 + i * 0.3, JSScreenMidPos.y + 10);
            chairBg.setAnchorPoint(i, 0.5);
            chairBg.setFlippedX(!i);
            aniLayer.addChild(chairBg);

            // 聚光燈
            var spotlightSp = new cc.Sprite("#becomeSultan_bg_spotlight.png");
            spotlightSp.setPosition(JSScreenMidPos.x - 0.14 + i * 0.28, JSScreenMidPos.y + 35);
            spotlightSp.setAnchorPoint(i, 0.5);
            spotlightSp.setFlippedX(!i);
            aniLayer.addChild(spotlightSp);

            // 文字圖檔
            var titleSp = new cc.Sprite(JSStringUtility.format("#becomeSultan_word_%02d.png", i + 1));
            titleSp.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 20 - 35 * i);
            aniLayer.addChild(titleSp, 1);
        }

        // 註冊只點一次
        var dummyTouchLayer = new DummyTouchLayer(JSVisibleSize);
        dummyTouchLayer.setOnTouchCallback(() => this._chairBtnClicked());
        aniLayer.addChild(dummyTouchLayer, 1);

        // 椅子購買按鈕
        var chairButton = ButtonUtility.createSimpleButton("lobby_btn_03.png", cc.size(90, 28), LocalizedString.PurchaseCoupon("查看"), JSColor.WHITE, 16);
        chairButton.addTouchUpInsideAction(this._chairBtnClicked, this);
        chairButton.setPosition(JSScreenMidPos.x, 35 + JSScreenBonusHalfHeight);
        chairButton.label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        aniLayer.addChild(chairButton, 1);
        chairButton.runAction(cc.repeatForever(
            cc.sequence(
                cc.scaleTo(0.5, 1.1),
                cc.scaleTo(0.5, 1)
            ))
        );
    },

    // 創立主要的儲值頁面
    _createMainPurchaseBanner: function () {
        var aniLayer = this._animationLayer;
        aniLayer.removeAllChildren();

        var param = this._param;

        // 背景
        for (var i = 0; i < 2; i++) {
            var bgSp = new cc.Sprite("#becomeSultan_bg_window_01.png");
            bgSp.setPosition(JSScreenMidPos.x - 0.15 + i * 0.3, JSScreenMidPos.y);
            bgSp.setAnchorPoint(i, 0.5);
            bgSp.setScale(1.4);
            bgSp.setFlippedX(!i);
            aniLayer.addChild(bgSp);

            // 文字圖檔
            var titleSp = new cc.Sprite(JSStringUtility.format("#becomeSultan_word_%02d.png", i + 3));
            titleSp.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 102 - 30 * i);
            aniLayer.addChild(titleSp, 1);
        }

        // 藍色光
        var spotlightSp = new cc.Sprite("#lobby_pic_bluelight.png");
        spotlightSp.setScale(24, 6);
        spotlightSp.setOpacity(140);
        spotlightSp.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 98);
        aniLayer.addChild(spotlightSp);

        for (var i = 0; i < 2; i++) {
            // 左邊的椅子
            var chairBg = new cc.Sprite("#becomeSultan_bg_chair.png");
            chairBg.setPosition(JSScreenMidPos.x - 123 + i * 0.3, JSScreenMidPos.y - 9);
            chairBg.setAnchorPoint(i, 0.5);
            chairBg.setScale(0.6);
            chairBg.setFlippedX(!i);
            aniLayer.addChild(chairBg);

            // 兩個閃光
            var shiningSp = new cc.Sprite("#shining_04.png");
            shiningSp.setPosition(JSScreenMidPos.x - 223 + i * 385, JSScreenMidPos.y + 45 + i * 48);
            shiningSp.setScale(1.3 + i * 0.4);
            aniLayer.addChild(shiningSp);
        }

        // 額外閃光
        var shiningSp = new cc.Sprite("#shining_04.png");
        shiningSp.setPosition(JSScreenMidPos.x + 225, JSScreenMidPos.y - 67);
        shiningSp.setScale(1.2);
        aniLayer.addChild(shiningSp);

        // 左邊的蘇丹王
        var kingSpName = JSStringUtility.format("#becomeSultan_pic_sultan_%02d.png", this._isPurchased ? 1 : 2);
        var sultanKingSp = new cc.Sprite(kingSpName);
        sultanKingSp.setPosition(JSScreenMidPos.x - 126, JSScreenMidPos.y + 15);
        aniLayer.addChild(sultanKingSp);

        // 加號
        var plusSp = new cc.Sprite("#becomeSultan_word_+.png");
        plusSp.setPosition(JSScreenMidPos.x - 5, JSScreenMidPos.y - 8);
        plusSp.setScale(1.5);
        aniLayer.addChild(plusSp);

        // 右邊的獎勵
        var rewardSp = new cc.Sprite("#becomeSultan_pic_sultan_03.png");
        rewardSp.setPosition(JSScreenMidPos.x + 113, JSScreenMidPos.y + 3);
        aniLayer.addChild(rewardSp);

        // 獎勵訊息
        var rewardTxt = new GSRichLabelNode(param.awardMsg, JSFontName, 10);
        rewardTxt.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        rewardTxt.setPosition(JSScreenMidPos.x + 113, JSScreenMidPos.y - 60);
        aniLayer.addChild(rewardTxt);

        // 購買按鈕
        var btnSp = this._isPurchased ? "lobby_btn_04.png" : "lobby_btn_10.png";
        var btnTxt = this._isPurchased ? LocalizedString.PurchaseCoupon("挑戰成功") : param.btnMsg;
        var btnTxtColor = this._isPurchased ? JSColor.BLACK : JSColor.WHITE;
        var buyBtn = ButtonUtility.createSimpleButton(btnSp, cc.size(100, 33), btnTxt, btnTxtColor, 10);
        buyBtn.addTouchUpInsideAction(this._buyBtnClicked, this);
        buyBtn.setPosition(JSScreenMidPos.x + 4, JSScreenMidPos.y - 87);
        buyBtn.label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        aniLayer.addChild(buyBtn);

        if (this._isPurchased) {
            // 已購買的話，就禁止再按
            buyBtn.setEnabled(false);
        } else {
            // 還沒買的時候，有放大縮小的動畫
            buyBtn.runAction(cc.repeatForever(
                cc.sequence(
                    cc.scaleTo(0.5, 1.1),
                    cc.scaleTo(0.5, 1)
                ))
            );

            // 時鐘icon
            var clockSprite = new cc.Sprite("#pic_icon_time.png");
            clockSprite.setPosition(JSScreenMidPos.x + 155, JSScreenMidPos.y - 94);
            clockSprite.setScale(0.75);
            aniLayer.addChild(clockSprite);

            // 倒數時間
            var timeLabel = new GSTimeLabel("", JSFontName, 11);
            timeLabel.setPosition(JSScreenMidPos.x + 188, JSScreenMidPos.y - 94);
            timeLabel.setMultiFormat("%hh:%mm:%ss");
            aniLayer.addChild(timeLabel);

            // 計時
            var remainTime = JSCodeUtility.getRemainTime(param.leftTime, param.socketTime);
            // 時間到的callback
            if (remainTime > 0) {
                timeLabel.countdownSeconds(remainTime, () => {
                    this._showErrorDialogAndCloseDialog();
                });
            } else
                this._showErrorDialogAndCloseDialog();
        }

        // 說明按鈕
        var explainBtn = ButtonUtility.createSimpleImageButton("lobby_btn_circle_03.png", null, "#btn_explain.png");
        explainBtn.setPosition(JSScreenMidPos.x - 206, JSScreenMidPos.y + 68);
        explainBtn.setScale(0.8);
        explainBtn.addTouchUpInsideAction(this._explainBtnClicked, this);
        aniLayer.addChild(explainBtn);

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
        closeBtn.setPosition(JSScreenMidPos.x + 205, JSScreenMidPos.y + 66);
        aniLayer.addChild(closeBtn);
    },

    /**
     * 按鈕
     */
    // 關閉按鈕
    _closeBtnClicked: function () {
        this._closeDialogAnimation();
    },

    // 說明按鈕
    _explainBtnClicked: function () {
        var dialog = this._infoDialog = new WebViewDialog(TexasUtility.getSimpleInfoURLByKey("sultan_king"));
        dialog.setCloseCallback(() => {
            if (this._infoDialog) {
                this._infoDialog = null;
            }
        });
        dialog.startDialogAnimation();
        this._animationLayer.addChild(dialog, 1000);
    },

    // 按下椅子動畫的按鈕
    _chairBtnClicked: function () {
        this._refreshView();
    },

    // 儲值按鈕
    _buyBtnClicked: function () {
        // 抓出資訊
        var productParam = this._param.productParam;

        // 去儲值
        DataModal.purchaseData.goPurchase(productParam);

        // 送server埋點
        var trackParam = {
            click_type: "3",
            group: DataModal.purchaseCouponData.becomeSultanInfo.group
        };
        DataProcess.sendString("track_sultan_king " + JSON.stringify(trackParam));
    },

    // 跳出錯誤Dialog
    _showErrorDialogAndCloseDialog: function () {
        if (this._isEventEnd)
            return;

        // 記下活動結束
        this._isEventEnd = true;

        if (this._infoDialog) {
            this._infoDialog.closeDialogAnimation();
            this._infoDialog = null;
        }

        // 跳出通知Dialog
        var dialog = new Dialog({
            content: LocalizedString.PurchaseCoupon("活動已結束"),
            bgSize: cc.size(280, 150),
            buttons: ["OK"],
            callback: () => {
                this.closeDialogAnimation();
            }
        });
        dialog.startDialogAnimation();
        this._animationLayer.addChild(dialog, 1000);
    },

    // 收到通知更新資訊
    notifyBecomeSultanInfoDone: function (event) {
        var param = event && event.getUserData();
        if (param) {
            // 有資料
            this._param = param;
            var isNewPeriod = param.isNewPeriod;
            this._refreshView(isNewPeriod);
        } else {
            // 沒資料
            this._showErrorDialogAndCloseDialog();
        }
    },

    // 收到儲值成功資訊
    notifyBecomeSultanRechargeDone: function () {
        // 更新成已經購買了
        this._isPurchased = true;

        // 刷新
        this._refreshView();
    }
});