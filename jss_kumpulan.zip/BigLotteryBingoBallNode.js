/**
 * 大樂彩 Bingo 球
 * 5.4.2 移植自中文德撲 by Jimmy.Wen
 * Created by yuki.huang on 2022/3/3.
 */
var BigLotteryBingoBallNode = cc.Node.extend({
    /**
     * @param {Number}  number      球的數字
     */
    ctor: function (number) {
        this._super();
        this.setCascadeOpacityEnabled(true);

        // 取得球對應的文字
        var ballChar = BigLotteryBingoBallNode.getBallCharByNum(number);

        // 球體
        var ballBgSp;
        ballBgSp = new cc.Sprite(JSStringUtility.format("#bigLottery_pic_ball_%s.png", ballChar));
        this.addChild(ballBgSp, -1);

        // 數字
        var ballNumSp = new GSSpriteNumberNode({
            number: number,
            numStr: "#bigLottery_word_ticket_",
            spW: 10
        });
        ballNumSp.setPosition(0, -2);
        this.addChild(ballNumSp);
    }
});

/**
 * 將賓果球的數字轉成bingo字
 * @param   {Number}    number  賓果球數字
 * @return  {String}    轉換後的bingo字
 */
BigLotteryBingoBallNode.getBallCharByNum = function (number) {
    if (number >= 0 && number <= 5)
        return "01";
    else if (number >= 6 && number <= 10)
        return "02";
    else if (number >= 11 && number <= 15)
        return "03";
    else if (number >= 16 && number <= 20)
        return "04";
    else
        return "05";
};