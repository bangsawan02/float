/**
 * 9T 衝動儲值_加碼輪盤 做輪盤的地方 Node
 */

var FortuneWheelPackWheelNode = cc.Node.extend({
    ctor: function (param) {
        this._super();

        // 轉盤相關初始化
        this._rewardDay = param.day;            // 中獎天數
        this._bonusArray = param.bonusArray;    // 輪盤呈現獎項
        this.setCascadeColorEnabled(true);

        // 閃光
        var sunLight = this._sunLight = new cc.Sprite("#fortune_wheel_title_light_01.png");
        sunLight.setScale(2);
        sunLight.setPosition(0, 141);
        this.addChild(sunLight);

        // 旋轉光
        sunLight.runAction(cc.rotateBy(2, 180).repeatForever());

        // 標題
        var title = new cc.Sprite("#fortune_wheel_word_title.png");
        title.setPosition(0, 145);
        this.addChild(title);

        // 副標題
        var subTitle = new cc.Sprite("#fortune_wheel_word_youwin.png");
        subTitle.setPosition(-1, 104);
        this.addChild(subTitle);

        // 轉盤container, 要轉的東西放這裡
        var wheelContainer = this._wheelContainer = new cc.Node();
        this.addChild(wheelContainer, 2);

        this._initWheel();
    },

    /**
     * 設定開始轉的callback
     * @param callback
     */
    setSpinCallback: function (callback) {
        this._spinCallback = callback;
    },

    /**
     * 設定轉完的callback
     * @param callback
     */
    setSpinFinishCallback: function (callback) {
        this._spinFinishCallback = callback;
    },

    spinWheel: function () {
        this._spinBtnClicked(this._spinBtn);
    },

    /**
     * 生成轉盤
     * @private
     */
    _initWheel: function () {
        var wheelContainer = this._wheelContainer;

        // 轉盤外框
        var wheelSprite = new cc.Sprite("#fortune_wheel_01.png");
        this.addChild(wheelSprite);

        // 轉盤內容物相關參數
        var rewardBgNum = ["2", "5", "4", "5", "3", "5", "1", "5"];             // 圖檔的名稱
        var rewardDayArray = this._rewardDayArray = this._bonusArray;  // 中獎的天數

        this._rewardNodeArray = rewardBgNum.map((num, index) => {
            var rewardNode = new cc.Node();
            rewardNode.setRotation(index * 45);
            rewardNode.setCascadeColorEnabled(true);
            rewardNode.setColor(JSColor.GRAY);
            wheelContainer.addChild(rewardNode);

            // 獎項背景
            var rewardBg = new cc.Sprite(JSStringUtility.format("#fortune_wheel_wheel_0%s.png", num));
            rewardBg.setAnchorPoint(0.5, 0);
            rewardNode.addChild(rewardBg);

            // 獎項文字
            var rewardString = JSStringUtility.format("#fortune_wheel_word_%s.png", rewardDayArray[index] > 0
                ? "plus" + rewardDayArray[index]
                : "again");
            var rewardWord = new cc.Sprite(rewardString);
            rewardWord.setPosition(0, 60);
            rewardNode.addChild(rewardWord);

            return rewardNode;
        });

        // 內圈
        var wheelInsideSprite = new cc.Sprite("#fortune_wheel_02.png");
        this.addChild(wheelInsideSprite, 3);

        // 燈泡動畫
        var lightFrames1 = this._lightFrame1 = [
            cc.spriteFrameCache.getSpriteFrame("fortune_wheel_light_01.png"),
            cc.spriteFrameCache.getSpriteFrame("fortune_wheel_light_02.png")
        ];

        // 燈泡動畫2
        var lightFrames2 = this._lightFrame2 = lightFrames1.slice().reverse();

        var len = 98;
        var lightArray = this._lightArray = [];
        // 放燈泡
        for (var i = 0; i < 16; i++) {
            var radian = 22.5 * i * Math.PI / 180;
            var posX = len * Math.cos(radian);
            var posY = len * Math.sin(radian);

            var light = new cc.Sprite();
            light.setScale(0.8);
            light.setPosition(posX, posY);
            this.addChild(light);

            lightArray.push(light);

            light.runAction(cc.animate(new cc.Animation(i % 2 ? lightFrames1 : lightFrames2, 0.5)).repeatForever());
        }

        // 紅色指針
        var pointerSprite = new cc.Sprite("#fortune_wheel_pointer.png");
        pointerSprite.setPosition(0, 107);
        this.addChild(pointerSprite, 3);

        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        this.addChild(menu, 3);

        // 馬上轉按鈕
        var spinSprite = ButtonUtility.createSingleScale9SpriteNodes("fortune_wheel_wheelbutton.png", null, "#fortune_wheel_word_rightnow.png");
        var spinBtn = this._spinBtn = new cc.MenuItemSprite(spinSprite[0], spinSprite[1], this._spinBtnClicked, this);
        menu.addChild(spinBtn);

        // 指引手指
        var navigateSprite = this._navigateSprite = new cc.Sprite("#lobby_pic_finger3.png");
        navigateSprite.setPosition(2, -34);
        this.addChild(navigateSprite, 3); // 要在按鈕上方

        // 觸碰動畫
        var touchAnimation = cc.sequence(
            cc.spawn(cc.skewTo(0.2, -5, 5), cc.scaleTo(0.2, 1, 0.9)),
            cc.spawn(cc.skewTo(0.2, 0, 0), cc.scaleTo(0.2, 1))
        );

        // 手指動起來
        navigateSprite.runAction(
            cc.sequence(
                cc.delayTime(1.5),
                touchAnimation,
                touchAnimation.clone()
            ).repeatForever()
        );
    },

    /**
     * 按下馬上轉
     * @private
     */
    _spinBtnClicked: function (sender) {
        this._spinCallback && this._spinCallback();

        sender && sender.setEnabled(false);

        if (this._sunLight) {
            this._sunLight.removeFromParent();          // 移除光
            this._sunLight = null;
        }
        if (this._navigateSprite) {
            this._navigateSprite.removeFromParent();    // 移除手指
            this._navigateSprite = null;
        }

        // 尋找加碼天數在第幾格
        var rewardIndex = this._rewardIndex = this._rewardDayArray.findIndex(cur => cur === this._rewardDay);

        // 計算轉盤最終位置
        this._targetRotation = 360 * 3 + rewardIndex * -45 + JSCodeUtility.getRandomInt(-10, 10);

        // 轉盤起始速度
        this._wheelSpeed = 1;

        this._rewardNodeArray.forEach(node => node.setColor(JSColor.WHITE));

        // 外框閃爍(換一種閃爍方式
        this._lightArray.forEach((light, index) => {
            var frame = index % 2 === 0 ? this._lightFrame1 : this._lightFrame2;

            light.stopAllActions();
            light.runAction(cc.animate(new cc.Animation(frame, 0.2)).repeatForever());
        });

        // 開始轉
        this.scheduleUpdate();
    },

    /**
     * update
     * @param delta 每幀run的秒數
     */
    update: function (delta) {
        var tmpSpeed = 0;
        var targetRotation = this._targetRotation;

        // 最後一圈開始減速
        if (this._wheelContainer.getRotation() > (targetRotation - 360)) {
            // 最近的rotation
            var curRotation = this._wheelContainer.getRotation();

            // 利用rotation來控制速度
            tmpSpeed = (targetRotation - curRotation) * delta;

            // 防止最後轉的時候太慢
            if (tmpSpeed < 0.07) {
                tmpSpeed = 0.07;
            }

            var nowRotation = curRotation + tmpSpeed;

            // 防呆 避免轉盤轉不停
            if (nowRotation >= targetRotation)
                nowRotation = targetRotation;

            // 設置rotation
            this._wheelContainer.setRotation(nowRotation);

            // 到達目標角度
            if (Math.abs(nowRotation - targetRotation) < 0.1) {
                this._spinEnd();
            }
        } else {
            // 一開始的加速度
            tmpSpeed = (this._wheelSpeed *= 1.02);

            // 設置速度上限
            if (tmpSpeed >= 10)
                tmpSpeed = 10;

            var rotation = Math.floor(this._wheelContainer.getRotation()) + Math.floor(tmpSpeed);
            this._wheelContainer.setRotation(rotation);
        }
    },

    /**
     * 轉完了要關動畫
     * @private
     */
    _spinEnd: function () {
        this.unscheduleUpdate();

        // 把沒中獎的壓黑
        this._rewardNodeArray.forEach((node, index) => index !== this._rewardIndex && node.setColor(JSColor.GRAY));

        // 外框閃爍(換一種閃爍方式
        this._lightArray.forEach(light => {
            light.stopAllActions();
            light.runAction(cc.animate(new cc.Animation(this._lightFrame1, 0.5)).repeat(3));
        });

        // 三秒以後關閉畫面
        this.runAction(cc.sequence(
            cc.delayTime(3),
            cc.callFunc(() => {
                // 呼叫轉盤動畫完成callback
                this._spinFinishCallback && this._spinFinishCallback();
                this._rewardNodeArray.forEach(node => node.setColor(JSColor.GRAY));

            }, this)
        ));
    },
});