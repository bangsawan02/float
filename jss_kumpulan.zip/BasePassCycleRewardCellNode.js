/**
 * 通行證 - 循環獎勵 Cell Node
 *
 * Sample config: {
 *     tableViewCycleCellSize: cc.size(0, 0),               // 循環獎勵 cell size
 *     tableViewCycleCellClass: BasePassCycleRewardNode,    // 循環獎勵 cell class
 * }
 */
var BasePassCycleRewardCellNode = cc.Node.extend({
    ctor: function (config) {
        this._super();

        this._config = config;
        let cellSize = this._cellSize = config.tableViewCycleCellSize || BasePassRewardCell.CycleRewardCellSize;
        let midPos = this._midPos = cc.p(cellSize.width / 2, cellSize.height / 2);
        let cellClass = config.tableViewCycleCellClass || BasePassCycleRewardNode;

        this.setContentSize(cellSize);

        let cycleRewardNode = this._rewardNode = new cellClass(config);
        cycleRewardNode.setPosition(midPos.x, midPos.y - 6);
        this.addChild(cycleRewardNode);
    },

    /**
     * 取得獎勵 Node
     * @returns {*}
     */
    getRewardNode: function () {
        return this._rewardNode;
    },

    /**
     * 是否跳過動畫
     * @param {boolean} isSkipped
     */
    setSkipped: function (isSkipped) {
        this._rewardNode.setSkipped(isSkipped);
    },

    /**
     * 更新畫面
     * @param {boolean} isInCycleReward         進度是否已到循環獎勵
     * @param {int}     currentCycleTokenCount  目前循環代幣數量
     * @param {int}     goalTokenCount          目標代幣數量
     */
    refreshView: function (isInCycleReward, currentCycleTokenCount, goalTokenCount) {
        this._rewardNode.refreshView(isInCycleReward, currentCycleTokenCount, goalTokenCount);
    },

    /**
     * 表演星星進度條
     * @param {int}         addTokenCount   增加的代幣數量
     * @param {int}         goalTokenCount  目標的代幣數量
     * @return {Promise<void>}
     */
    playProgressAnimationAsync: function (addTokenCount, goalTokenCount) {
        return new Promise((resolve, reject) => {
            if (this.__isDestroyed) {
                return;
            }
            this._rewardNode.playProgressAnimationAsync(addTokenCount, goalTokenCount)
                .then(() => resolve())
                .catch(() => reject());
        });
    },
});