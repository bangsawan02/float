/**
 * 足球機台的教學畫面 丟進來的東西是外面產生好的
 */

var FootballTeachLayer = cc.Layer.extend({
    ctor: function (directionNode, betBtnArray, startButton) {
        this._super();

        // 先記下來
        this._directionNode = directionNode;
        this._betBtnArray = betBtnArray;
        this._startButton = startButton;

        // 黑底
        var bgColor = new cc.LayerColor(cc.color(0, 0, 0, 200), JSVisibleSize.width, JSVisibleSize.height);
        this.addChild(bgColor);

        // 右下角的文字
        var hintLabel = this._hintLabel = new cc.LabelTTF(LocalizedString.Football("點擊螢幕繼續>>"), JSFontBoldName, 12);
        hintLabel.setAnchorPoint(1, 0);
        hintLabel.setPosition(JSVisibleSize.width - 10 - JSScreenSafeWidth, 3);
        this.addChild(hintLabel);

        // 放訊息的地方
        var messageContainer = this._messageContainer = new cc.Node();
        this.addChild(messageContainer, 1);

        // 最上面加一個檔Touch的東西
        var dummyTouch = new DummyTouchLayer(JSVisibleSize);
        dummyTouch.setOnTouchCallback(() => this._processNextStep());
        this.addChild(dummyTouch, 10);

        // 一開始就處理
        this._nowStep = 0;
        this._showTeachNodeArray = [];
        this._canProcessNext = true;
        this._processNextStep();
    },

    onEnter: function () {
        this._super();

        // 加Android back key
        PushScene.addBackKeyEnableLayer(this);
    },

    onExit: function () {
        PushScene.removeBackKeyEnableLayer(this);

        this._super();
    },

    /**
     * 教學的步驟
     */
    _processNextStep: function () {
        if (!this._canProcessNext)
            return;

        this._canProcessNext = false;
        this._nowStep++;

        // 先判斷假如有之前把Node移過來這邊加的 要把他還原回去
        this._showTeachNodeArray.forEach(param => {
            var showNode = param.node;
            cc.sys.isNative && showNode.retain();
            showNode.removeFromParent(false);
            param.parent.addChild(showNode, param.zorder);
            cc.sys.isNative && showNode.release();
        });
        this._showTeachNodeArray.length = 0;

        // 假如沒了 砍掉自己
        if (this._nowStep === 4) {
            // 記下來
            GS.localStorage.setItem("FirstEnterFootball", "0");
            this.removeFromParent();
            return;
        }

        // 清掉上一次的訊昔
        this._messageContainer.removeAllChildren();

        // 先關掉提示文字
        this._hintLabel.setVisible(false);

        // 依照哪一個步驟來產生畫面
        var message, messagePos;
        var footballString = LocalizedString.Football;
        switch (this._nowStep) {
            case 1:
                this._betBtnArray.forEach(btn => {
                    this._showTeachNodeArray.push({
                        node: btn,
                        parent: btn.getParent(),
                        zorder: btn.getLocalZOrder()
                    });
                });

                message = footballString("選擇注額");
                messagePos = cc.pAdd(this._betBtnArray[1].getPosition(), cc.p(0, 20));
                break;
            case 2:
                this._showTeachNodeArray.push({
                    node: this._directionNode,
                    parent: this._directionNode.getParent(),
                    zorder: this._directionNode.getLocalZOrder()
                });
                message = footballString("選擇射門方向與倍數");
                messagePos = cc.p(JSScreenMidPos.x, JSScreenMidPos.y + 20);
                break;
            case 3:
                this._showTeachNodeArray.push({
                    node: this._startButton,
                    parent: this._startButton.getParent(),
                    zorder: this._startButton.getLocalZOrder()
                });
                var btnPos = this._startButton.getPosition();
                message = footballString("射門下注");
                messagePos = cc.pAdd(btnPos, cc.p(0, 20));

                // 這個特別一點 要加個圖加強一下
                var lightSprite = new ccui.Scale9Sprite("football_pic_light_1.png");
                lightSprite.setPreferredSize(cc.size(94, 50));
                lightSprite.setPosition(cc.pAdd(btnPos, cc.p(0, 3)));
                this._messageContainer.addChild(lightSprite);
                break;
        }

        // 把要出現教學的畫面加在此畫面
        this._showTeachNodeArray.forEach(param => {
            var showNode = param.node;
            cc.sys.isNative && showNode.retain();
            showNode.removeFromParent(false);
            this.addChild(showNode);
            cc.sys.isNative && showNode.release();
        });

        // 跳訊息
        var messageLabel = new cc.LabelTTF(message, JSFontBoldName, 12);
        messageLabel.setFontFillColor(JSColor.BLACK);
        var param = {
            mainNode: messageLabel,
            style: BaseMessageNode.Style.WHITE,
            direct: BaseMessageNode.Direct.DOWN,
            arrowType: BaseMessageNode.ArrowType.STRAIGHT,
            arrowPadding: 0,
        };

        var msgNode = new BaseMessageNode(param);
        msgNode.setPosition(messagePos);
        msgNode.show();
        this._messageContainer.addChild(msgNode);

        // 過一段時間後才能讓他按
        this.runAction(cc.sequence(
            cc.delayTime(0.5),
            cc.callFunc(() => {
                this._canProcessNext = true;

                // 顯示文字
                this._hintLabel.setVisible(true);
            })
        ));
    },
});