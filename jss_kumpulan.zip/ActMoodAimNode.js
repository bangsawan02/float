/**
 * 互動道具選擇人物的框框
 */

var ActMoodAimNode = cc.Node.extend({
    ctor: function (index, callback, target) {
        this._super();

        this.index = index;
        this._callback = callback;
        this._target = target;

        var clipImgString = "";
        var buttonScale = 1;
        var imageSize;
        switch (GS.nowGame) {
            case GSEnum.Game.Texas:
                // Domino 荷官是方的 玩家是圓的
                if (index === -1) {
                    clipImgString = "game_pic_aim_bg.png";
                    imageSize = cc.size(50, 76);
                } else {
                    clipImgString = "lobby_photo_clip.png";
                    buttonScale = 0.7;
                }
                break;
            case GSEnum.Game.Domino:
                // Domino 荷官是方的 玩家是圓的
                if (index === -1) {
                    clipImgString = "game_pic_aim_bg.png";
                    imageSize = cc.size(50, 76);
                } else {
                    clipImgString = "lobby_photo_clip.png";
                    buttonScale = 0.6;
                }
                break;
            case GSEnum.Game.Remi:
            case GSEnum.Game.Gaple:
            case GSEnum.Game.GapleChat:
            case GSEnum.Game.GaplePlus:
            case GSEnum.Game.GapleFriend:
            case GSEnum.Game.GapleVideo:
            case GSEnum.Game.Cangkulan:
            case GSEnum.Game.CapsaSusun:
                // Gaple 圓的
                clipImgString = "lobby_photo_clip.png";
                buttonScale = 0.7;
                break;
        }

        // 按鈕
        // 一般玩家
        var imageSprite1 = new ccui.Scale9Sprite(clipImgString);
        var imageSprite2 = new ccui.Scale9Sprite(clipImgString);
        imageSprite1.setColor(JSColor.RED);
        imageSprite1.setOpacity(150);
        imageSprite2.setColor(cc.color(200, 0, 0));
        imageSprite2.setOpacity(150);

        if (imageSize) {
            imageSprite1.setPreferredSize(imageSize);
            imageSprite2.setPreferredSize(imageSize);
        }

        var button = new cc.ControlButton(imageSprite1);
        button.setBackgroundSpriteForState(imageSprite2, cc.CONTROL_STATE_HIGHLIGHTED);
        button.addTargetWithActionForControlEvents(this, this._aimNodeClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        button.setAdjustBackgroundImage(false);
        button.setZoomOnTouchDown(false);
        button.setScale(buttonScale);
        this.addChild(button);

        // 手指頭
        var finger = this._finger = new cc.Sprite("#game_pic_finger.png");
        finger.setAnchorPoint(0, 1);
        finger.setScale(0.8);
        this.addChild(finger);
    },

    /**
     * 開始動畫
     */
    show: function () {
        this.setVisible(true);

        var finger = this._finger;
        finger.stopAllActions();
        finger.setPosition(0, 0);
        finger.runAction(cc.repeatForever(cc.sequence(
            cc.moveBy(0.5, cc.p(3, -3)),
            cc.moveBy(0.5, cc.p(-3, 3))
        )));
    },

    /**
     * 關掉
     */
    close: function () {
        this.setVisible(false);
        this._finger.stopAllActions();
    },

    /**
     * 按到按鈕
     */
    _aimNodeClicked: function () {
        this._callback && this._callback.call(this._target, this);
    },
});