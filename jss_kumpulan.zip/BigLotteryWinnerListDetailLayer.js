/**
 * 幸運彩票點寶箱跳出來的獎勵泡泡框畫面
 */

var BigLotteryWinnerListDetailLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 加一層UI檔Touch
        this._dummyTouch = new DummyTouchLayer(JSVisibleSize);
        this._dummyTouch.setOnTouchEventName("NotifyBigLotteryHistoryWinnerDetailClose");
        this.addChild(this._dummyTouch);

        // 監聽
        GS.addListener("NotifyBigLotteryHistoryWinnerDetailClose", this.notifyBigLotteryHistoryWinnerDetailClose.bind(this), this);
    },

    /**
     * 顯示獎勵內容
     * rewardIndex      獎勵的index 用來查內容
     * chestWorldPos    被點到的寶箱的世界座標
     */
    showRewardDetail: function (rewardIndex, chestWorldPos) {
        var rewardList = DataModal.bigLotteryData.historyParam.rewardList;
        var rewardJson = rewardList[rewardIndex - 1];   // server傳 1~6, 但是array index是0~5

        // 找不到reward資料 直接關掉
        if (!rewardJson) {
            this.close();
            return;
        }

        // 放獎勵的node
        var rewardNode = new GSAutoLayoutNode();
        rewardNode.setType(GSAutoLayout.TYPE.VERTICAL_LEFT);

        // 加入獎勵項目
        rewardJson.forEach(cur => {
            var itemNode = new GSAutoLayoutNode();
            itemNode.setType(GSAutoLayout.TYPE.HORIZONTAL);

            // 獎勵的圖
            var imageUrl = JSStringUtility.format("https://g.mwsrv.com/19_60/store/iapp/download/multi/HD/%s.png", cur.wid);
            var savePath = JSWriteablePath + "shop/" + cur.wid + ".png";
            var iconSp = new GSDownloadSprite("", imageUrl, savePath);
            iconSp.setTargetSize(cc.size(25, 25));
            itemNode.addChild(iconSp);

            // 獎勵的數量
            var text = new cc.LabelTTF(cur.name, JSFontBoldName, 10);
            text.setFontFillColor(JSColor.BLACK);
            itemNode.addChild(text);

            rewardNode.addChild(itemNode);
        });

        // Domino移植設定 調整泡泡框設定
        // 抓獎勵文字的最大寬度來決定泡泡框位移
        var rewardNodeWidth = rewardNode.getContentSize().width;
        var arrowPadding = rewardNodeWidth > 200 ? 200 - rewardNodeWidth : 0;

        // 設定泡泡框
        var param = {
            mainNode: rewardNode,
            style: BaseMessageNode.Style.CUSTOM,
            direct: BaseMessageNode.Direct.DOWN,
            arrowType: BaseMessageNode.ArrowType.STRAIGHT,
            bgName: "lobby_pic_tip_bg.png",
            arrowName: "lobby_pic_tip_arrow.png",
            arrowToBgPadding: 0.2,
            arrowPadding: arrowPadding,
            bgBonusSize: cc.size(6, 4),
            isFlip: false
        };
        var infoNode = this._infoNode = new BaseMessageNode(param);
        infoNode.setPosition(cc.pAdd(this.convertToNodeSpace(chestWorldPos), cc.p(0, 14)));
        infoNode.show();
        this.addChild(infoNode, 2);
    },

    /**
     * 關掉
     */
    close: function () {
        this._infoNode && this._infoNode.close();
        this._infoNode = null;

        this.runAction(cc.sequence(cc.delayTime(DIALOG_ANIMATION_TIME), cc.removeSelf()));
    },

    /**
     * 通知
     */
    // 關掉獎勵畫面
    notifyBigLotteryHistoryWinnerDetailClose: function () {
        this.close();
    }
});