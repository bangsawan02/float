/**
 * 百加樂的桌面
 */

var BaccaratTableLayer = cc.Node.extend({
    ctor: function (betCallback) {
        this._super();

        this.setCascadeOpacityEnabled(true);

        this._isBigTable = false;
        this._nowTotalBetMoney = 0;                     // 現在總下注金額
        this._betChipsIndex = 0;                        // 現在下注的按鈕Index
        this._betCallback = betCallback;
        this._usedFreeTicketCount = 0;                  // 現在用掉幾張免費券

        // 下注區的下注金額跟上限金額
        this._zoneMaxMoney = {};
        this._zoneBetMoney = {};
        this._zoneBetChipCountArray = {};
        this._zoneBetChipSprite = {};
        for (var key in BaccaratZoneType) {
            var zoneType = BaccaratZoneType[key];
            this._zoneMaxMoney[zoneType] = 0;
            this._zoneBetMoney[zoneType] = 0;
            this._zoneBetChipCountArray[zoneType] = [];
            this._zoneBetChipSprite[zoneType] = [];
        }

        // 感應區塊
        var zoneButtonObjects = this._zoneButtonObjects = {};

        // 以下要創建按鈕區塊 跟 圖片 跟 文字, 統一區塊在zOrder:0 圖片系列都在1 Label都在2 為了節省Drawcall
        var zones = [BaccaratZoneType.PLAYER, BaccaratZoneType.PLAYER_PAIR, BaccaratZoneType.SERI, BaccaratZoneType.BANKER_PAIR, BaccaratZoneType.BANKER];
        var posY = JSScreenMidPos.y - 30;
        var imageWord1s = ["#bcr_word_player.png", "#bcr_word_player_pair.png", "#bcr_word_seri.png", "#bcr_word_banker_pair.png", "#bcr_word_banker.png"];
        var buttonSizeWidth = [99, 60, 60, 60, 99];
        var posXArray = [
            JSScreenMidPos.x - buttonSizeWidth[1] * 2 - (buttonSizeWidth[0] - buttonSizeWidth[1]) / 2 - 6,
            JSScreenMidPos.x - buttonSizeWidth[1] - 3,
            JSScreenMidPos.x,
            JSScreenMidPos.x + buttonSizeWidth[1] + 3,
            JSScreenMidPos.x + buttonSizeWidth[1] * 2 + (buttonSizeWidth[0] - buttonSizeWidth[1]) / 2 + 6,
        ];
        for (var i = 0; i < 5; i++) {
            var posX = posXArray[i];
            var tableButton = zoneButtonObjects[zones[i]] = new BaccaratTableButton(cc.size(buttonSizeWidth[i], 74), zones[i], this._tableZoneClicked, this);
            tableButton.setPosition(posX, posY);
            this.addChild(tableButton);

            var tableWordSprite = new cc.Sprite(imageWord1s[i]);
            tableWordSprite.setPosition(posX, posY + 20);
            this.addChild(tableWordSprite, 1);

            var tableText = new cc.LabelTTF(JSStringUtility.format("1:%s", BaccaratWinRatio[i + 1].toString()), JSFontBoldName, 12);
            tableText.setPosition(posX, posY - 28);
            tableText.setFontFillColor(JSColor.YELLOW);
            tableText.enableShadow(JSColor.BLACK, cc.size(-1, 1), 1);
            this.addChild(tableText, 2);
        }

        // 放中獎文字的Node
        var winWordNode = this._winWordNode = new cc.Node();
        winWordNode.setCascadeOpacityEnabled(true);
        this.addChild(winWordNode, 10);

        // 放籌碼的Node
        var chipsNode = this._chipsNode = new cc.Node();
        chipsNode.setCascadeOpacityEnabled(true);
        this.addChild(chipsNode, 10);

        // 燈光的圖 0左 1右
        var lights = this._lights = [];
        for (var i = 0; i < 2; i++) {
            var lightSprite = this._lights[i] = new cc.Sprite("#bcr_focus.png");
            lightSprite.setFlippedX(i === 0);
            lightSprite.setRotation(i === 0 ? 45 : -45);
            lightSprite.setPosition(i === 0 ? -10 : JSVisibleSize.width + 10, JSVisibleSize.height - 54);
            this.addChild(lightSprite, 5);
        }

        // 先重置一次 讓每個區的最大金額算出來
        this.clean();
    },

    /**
     * 清除畫面
     */
    clean: function () {
        // 把所有東西都重置
        var isBigTable = this._isBigTable;

        for (var key in BaccaratZoneType) {
            var zoneType = BaccaratZoneType[key];

            // 重置下注區金額 & 上限
            var maxBetMoney = (isBigTable ? BaccaratMoneyType.Big_MAX : BaccaratMoneyType.Small_MAX);

            this._zoneMaxMoney[zoneType] = maxBetMoney;
            this._zoneBetMoney[zoneType] = 0;
            this._zoneBetChipCountArray[zoneType] = [];
            this._zoneBetChipSprite[zoneType] = [];

            // 清掉按鈕顯示
            var zoneButton = this._zoneButtonObjects[zoneType];
            zoneButton.clean();
        }

        // 總金額清掉
        this._nowTotalBetMoney = 0;

        // 把中獎文字砍掉
        this._winWordNode.removeAllChildren();

        // 把下注的籌碼砍光
        this._chipsNode.removeAllChildren();

        // 把光拿掉
        this._lights.forEach(light => light.setVisible(false));
    },

    /**
     * 出現第一次閃光
     */
    showFirstHint: function () {
        // 是否第一次進來
        if (!GS.localStorage.getItem("FirstBaccarat")) {
            GS.localStorage.setItem("FirstBaccarat", "1");

            // 要出現亮的動畫
            this._tableAllLight();
        }
    },

    /**
     * 用來判斷是否可以搖骰 跟 重新下注
     */
    // 回傳是否可以搖骰
    getCanStart: function () {
        return this._nowTotalBetMoney > 0;
    },

    // 回傳是否可以重新下注
    getCanReBetChips: function () {
        return this._oldTotalBetMoney > 0;
    },

    /**
     * 抓現在下注的金額
     */
    getNowTotalBetMoney: function () {
        return this._nowTotalBetMoney;
    },

    /**
     * 抓現在用掉多少免費券
     */
    getUsedFreeTicketCount: function () {
        if (this._isBigTable)
            return 0;

        // 回傳下注金額除以最小金額
        return this._usedFreeTicketCount;
    },

    /**
     * 清掉用掉的免費券
     */
    clearUsedFreeTicketCount: function () {
        this._usedFreeTicketCount = 0;
    },

    /**
     * 設定現在的總金額
     */
    _setNowTotalBetTotalMoney: function (totalMoney) {
        this._nowTotalBetMoney = totalMoney;

        // 當作判斷用掉幾張免費券
        if (!this._isBigTable)
            this._usedFreeTicketCount = totalMoney / BaccaratMoneyType.Small_L;

        // 更新LED
        GS.dispatchCustomEvent("NotifyBaccaratUpdateLED", totalMoney);
    },

    /**
     * 設定大小桌
     */
    setIsBigTable: function (isBigTable) {
        if (this._isBigTable != isBigTable) {
            this._isBigTable = isBigTable;

            // 有換大小 要把上一次的記錄清掉
            this._oldZoneBetChipCountArray = null;
            this._oldTotalBetMoney = null;
            this._usedFreeTicketCount = 0;

            // 更新每一區下注金額上限
            this.clean();
        }
    },

    /**
     * 設定現在下注是按鈕是哪一個 小注到大注左到右是 0, 1, 2, 3, 4, 5
     */
    setBetChipsIndex: function (index) {
        this._betChipsIndex = index;
    },

    /**
     * 重新下注上一次的籌碼
     */
    reBetChips: function () {
        // 先清掉桌面上的東西
        this.clean();

        // 先判斷上次下注金額有沒有超過身上的錢
        var myMoney = DataModal.profileData.money;
        var isBigTable = this._isBigTable;

        // 假如有免費券 要把自己手上的錢往上加 因為那是免費給的
        var freeTicketCount = DataModal.vegasData.freeTicket.Baccarat;
        if (!isBigTable && freeTicketCount)
            myMoney += (freeTicketCount * BaccaratMoneyType.Small_L);

        if (this._oldTotalBetMoney > myMoney) {
            // 超過 要跳Dialog
            DialogManager.addDialog(new NoMoneyDialog(this._oldTotalBetMoney - myMoney));

            // 清空下注金額
            this._setNowTotalBetTotalMoney(0);
            return;
        }

        var bonusChipIndex = isBigTable ? 3 : 0;
        var self = this;
        for (var zoneType in this._oldZoneBetChipCountArray) {
            // 先把那區下注金額歸0
            this._zoneBetMoney[zoneType] = 0;

            // 抓出那一區下注的次數
            var countArray = this._oldZoneBetChipCountArray[zoneType];
            var haveBetChips = false;
            countArray.forEach(function (cur, index) {
                if (cur) {
                    for (var i = 0; i < cur; i++) {
                        self._addChip(zoneType, index + bonusChipIndex);
                    }
                    haveBetChips = true;
                }
            });

            // 看是否需要把按鈕的區域打開
            var zoneButton = this._zoneButtonObjects[zoneType];
            zoneButton.setChooseLightVisible(haveBetChips);
        }

        // 更新下注金額
        this._setNowTotalBetTotalMoney(this._oldTotalBetMoney);

        // 撥放音樂
        Vegas_MusicUtility.playEffect("Music/Effect/blackjack_btn2.mp3");
    },

    /**
     * 送出搖骰的Socket CMD
     */
    sendStartCMD: function () {
        // 先把上一次下注的東西記下來
        this._oldZoneBetChipCountArray = _.clone(this._zoneBetChipCountArray);
        this._oldTotalBetMoney = this._nowTotalBetMoney;

        // 轉成Server吃的規格
        var zoneArray = [];

        for (var key in BaccaratZoneType) {
            var zoneType = BaccaratZoneType[key];
            zoneArray.push(this._zoneBetMoney[zoneType]);

            // 清掉所有選到的區域亮光
            this._zoneButtonObjects[zoneType].setChooseLightVisible(false);
        }

        // 送出
        DataProcess.sendString("slot13_send " + JSON.stringify(zoneArray));
    },

    /**
     * 按到下注的區塊
     */
    _tableZoneClicked: function (sender) {
        var zoneType = sender.zoneType;
        if (zoneType > 0) {
            var myMoney = DataModal.profileData.money;
            var chipIndex = this._betChipsIndex;
            // 抓出要放多少錢
            var chipMoney = BaccaratBetChips[chipIndex].money;

            // 判斷還能不能繼續放
            if (this._checkZoneMaxMoney(zoneType, chipMoney))
                return;

            // 總金額更新
            this._setNowTotalBetTotalMoney(this._nowTotalBetMoney + chipMoney);

            // 把按鈕的區域打開
            var zoneButton = this._zoneButtonObjects[zoneType];
            zoneButton.setChooseLightVisible(true);

            // 加上籌碼
            this._addChip(zoneType, chipIndex);

            // 自己按的要出現籌碼的文字
            var moneyLabel = new cc.LabelTTF("+" + TexasUtility.getSimpleMoneyString(chipMoney), JSFontName, 10);
            moneyLabel.enableStroke(JSColor.BLACK, 2);
            this.addChild(moneyLabel, 15);

            // 要判斷文字放左邊還右邊 裡面的位置是用432當做底的 然後整個Layer Scale 所以要用432算
            var basePosition = zoneButton.getPosition();
            var isLeft = basePosition.x > (432 - 70);
            moneyLabel.setPosition(basePosition.x + (isLeft ? -15 : 15), basePosition.y);
            moneyLabel.setAnchorPoint(isLeft ? 1 : 0, 0.5);
            moneyLabel.setOpacity(0);
            moneyLabel.runAction(cc.fadeIn(0.1));
            moneyLabel.runAction(cc.sequence(
                cc.moveBy(1, cc.p(0, 20)),
                cc.fadeOut(0.1),
                cc.removeSelf()
            ));

            // 撥放音樂
            Vegas_MusicUtility.playEffect("Music/Effect/blackjack_btn2.mp3");

            // callback回去
            this._betCallback && this._betCallback(zoneType);
        }
    },

    /**
     * 加籌碼 傳下注的籌碼Index
     */
    _addChip: function (zoneType, betChipIndex) {
        var zoneButton = this._zoneButtonObjects[zoneType];
        var reallyIndex = betChipIndex % 3;

        // 先抓現在同顏色有多少籌碼
        var chipIndexCount = this._zoneBetChipCountArray[zoneType][reallyIndex] || 0;

        // 抓出要放在哪個位置
        var basePosition = cc.pAdd(zoneButton.getPosition(), BaccaratBetChipsOffset[reallyIndex]);

        // 開始加籌碼
        var newChipSprite = new cc.Sprite(BaccaratBetChips[betChipIndex].image);
        newChipSprite.setScale(0.8);
        newChipSprite.setPosition(cc.pAdd(basePosition, cc.p(0, 2 * chipIndexCount - zoneButton.zoneSize.height / 6)));
        this._chipsNode.addChild(newChipSprite, parseInt(zoneType) + 3 - reallyIndex);

        // 把這個Sprite記下來
        this._zoneBetChipSprite[zoneType].push(newChipSprite);

        // 同顏色籌碼+1
        this._zoneBetChipCountArray[zoneType][reallyIndex] = chipIndexCount + 1;

        // 金額往上加
        this._zoneBetMoney[zoneType] += BaccaratBetChips[betChipIndex].money;
    },

    /**
     * 判斷該區的壓注金額上線
     */
    _checkZoneMaxMoney: function (zoneType, betMoney) {
        var myMoney = DataModal.profileData.money;
        var isBigTable = this._isBigTable;
        var tableMaxMoney = isBigTable ? BaccaratMoneyType.Big_MAX : BaccaratMoneyType.Small_MAX;
        var newTotalBetMoney = this._nowTotalBetMoney + betMoney;

        // 假如有免費券 要把自己手上的錢往上加 因為那是免費給的
        var freeTicketCount = DataModal.vegasData.freeTicket.Baccarat;
        if (!isBigTable && freeTicketCount)
            myMoney += (freeTicketCount * BaccaratMoneyType.Small_L);

        var needFillUp = false;
        if (myMoney < newTotalBetMoney) {
            // 手上的錢比下注的金額少 要跳Dialog
            var lessMoney = newTotalBetMoney - myMoney;

            DialogManager.addDialog(new NoMoneyDialog(lessMoney));

            return true;
        } else if (newTotalBetMoney > tableMaxMoney) {
            // 下注金額超過最大上限 要跳Dialog
            needFillUp = true;

            var baccaratString = LocalizedString.Baccarat;
            var maxString = JSCodeUtility.getCurrencyString(tableMaxMoney);
            var dialog = new AvatarDialog({
                title: baccaratString("超過上限"),
                content: baccaratString("總下注金額上限為") + "\n#!E6AA00!#" + maxString + "#!FFFFFF!#"
            });
            DialogManager.addDialog(dialog);
        } else if (this._zoneBetMoney[zoneType] + betMoney > this._zoneMaxMoney[zoneType]) {
            // 下注區金額超過上限 要跳Dialog
            needFillUp = true;

            var baccaratString = LocalizedString.Baccarat;
            var maxString = JSCodeUtility.getCurrencyString(this._zoneMaxMoney[zoneType]);
            var dialog = new AvatarDialog({
                title: baccaratString("超過上限"),
                content: baccaratString("本區下注金額上限為") + "\n#!E6AA00!#" + maxString + "#!FFFFFF!#"
            });
            DialogManager.addDialog(dialog);
        }

        // 下注金額有問題時
        // 1.總下注金額已超過上限,幫他下滿到總下注金額上限即可
        // 2.區下注金額已超過上限,幫他下滿到區下注金額上限即可
        // 3.以上兩點發生,但如果玩家手上的錢不足以下滿,則不幫他下注
        if (needFillUp) {
            // 幫使用者重新下注
            var tableMoneyLess = tableMaxMoney - this._nowTotalBetMoney;                            // 距離桌上限還差多少
            var zoneMoneyLess = this._zoneMaxMoney[zoneType] - this._zoneBetMoney[zoneType];        // 區上限還差多少
            var needFillUpMoney = (tableMoneyLess < zoneMoneyLess ? tableMoneyLess : zoneMoneyLess);
            if (myMoney >= needFillUpMoney) {
                // 要幫他補到滿 從中間的籌碼開始補
                var chipIndex = this._isBigTable ? 4 : 1;
                var fillUpMoney = needFillUpMoney;
                for (var i = 0; i < 2; i++) {
                    // 抓出要放多少錢
                    var chipMoney = BaccaratBetChips[chipIndex - i].money;

                    // 抓出要補幾次
                    var totalTimes = Math.floor(fillUpMoney / chipMoney);
                    for (var x = 0; x < totalTimes; x++) {
                        this._addChip(zoneType, chipIndex - i);
                    }
                    fillUpMoney = fillUpMoney % chipMoney;
                }

                if (needFillUpMoney !== fillUpMoney) {
                    // 代表有幫他補 要把那區域亮起來
                    var zoneButton = this._zoneButtonObjects[zoneType];
                    zoneButton.setChooseLightVisible(true);

                    // 更新現在下注的金額
                    this._setNowTotalBetTotalMoney(this._nowTotalBetMoney + needFillUpMoney - fillUpMoney);

                    // callback回去 更新按鈕
                    this._betCallback && this._betCallback(zoneType);
                }
            }

            return true;
        }

        // 沒事 回傳false
        return false;
    },

    /**
     * 全部的Table動畫 讓他亮一陣子
     */
    _tableAllLight: function () {
        // 先檔Touch
        var dummyTouch = new DummyTouchLayer(JSVisibleSize);
        this.addChild(dummyTouch, 1000);

        // 讓他一閃一閃的
        this.runAction(cc.sequence(
            cc.repeat(cc.sequence(
                cc.callFunc(function () {
                    // 把所有東西都亮起
                    for (var key in this._zoneButtonObjects) {
                        var zoneButton = this._zoneButtonObjects[key];
                        zoneButton.setZoneLightVisible(true);
                    }
                }, this),
                cc.delayTime(0.5),
                cc.callFunc(function () {
                    // 把所有東西都關掉
                    for (var key in this._zoneButtonObjects) {
                        var zoneButton = this._zoneButtonObjects[key];
                        zoneButton.setZoneLightVisible(false);
                    }
                }, this),
                cc.delayTime(0.5)
            ), 3),
            cc.callFunc(function () {
                // 拿掉檔Touch
                dummyTouch.removeFromParent();
            }, this)
        ));
    },

    /**
     * 顯示中獎的區域
     */
    _showZoneLight: function (zoneType) {
        var haveReward = this._zoneBetMoney[zoneType] > 0;
        var zoneButton = this._zoneButtonObjects[zoneType];
        zoneButton.setZoneLightVisible(true);

        // 中獎文字的出現
        if (haveReward) {
            var winSprite = new cc.Sprite("#brc_word_win2.png");
            winSprite.setScale(0.8);
            winSprite.setPosition(cc.pAdd(zoneButton.getPosition(), cc.p(0, zoneButton.zoneSize.height / 2)));
            this._winWordNode.addChild(winSprite);
        }
    },

    /**
     * 出現贏牌的字
     */
    _showWinWord: function (type) {
        var posXOffset, imageString, needShowLight;
        switch (type) {
            case BaccaratWinType.PLAYER:
                imageString = "#bcr_word_player_win.png";
                posXOffset = -92;
                needShowLight = true;
                break;
            case BaccaratWinType.BANKER:
                imageString = "#bcr_word_banker_win.png";
                posXOffset = 92;
                needShowLight = true;
                break;
            case BaccaratWinType.PLAYER_PAIR:
                imageString = "#bcr_word_player_pair2.png";
                posXOffset = -54;
                break;
            case BaccaratWinType.BANKER_PAIR:
                imageString = "#bcr_word_banker_pair2.png";
                posXOffset = 54;
                break;
            case BaccaratWinType.SERI:
                imageString = "#bcr_word_seri2.png";
                posXOffset = 0;
                break;
            default:
                return;
        }

        var winSprite = new cc.Sprite(imageString);
        winSprite.setPosition(JSScreenMidPos.x + posXOffset, JSScreenMidPos.y + 45);
        winSprite.setOpacity(0);
        winSprite.setScale(0.5);
        this.addChild(winSprite);

        winSprite.runAction(cc.sequence(
            cc.spawn(
                cc.fadeIn(0.5),
                cc.scaleTo(0.5, 1)
            ),
            cc.delayTime(1.6),
            cc.removeSelf()
        ));

        // 判斷是否要出現光線
        if (needShowLight) {
            var lightSprite = this._lights[type === BaccaratWinType.PLAYER ? 0 : 1];
            lightSprite.setOpacity(0);
            lightSprite.setVisible(true);
            lightSprite.runAction(cc.sequence(
                cc.fadeIn(0.5),
                cc.delayTime(1.6),
                cc.fadeOut(0.2),
                cc.hide()
            ));
        }
    },

    /**
     * 顯示大路的東西
     */
    showBigRoadAsync: function (param) {
        return new Promise(resolve => {
            var winPair = (parseInt(param.bigRoad[0]) || 0) % 4;
            var delayTime;
            if (winPair > 0 && winPair < 4) {
                delayTime = 3;

                switch (winPair) {
                    case 1:
                        // 閒一對
                        this._showZoneLight(BaccaratZoneType.PLAYER_PAIR);
                        this._showWinWord(BaccaratWinType.PLAYER_PAIR);
                        break;
                    case 2:
                        // 莊一對
                        this._showZoneLight(BaccaratZoneType.BANKER_PAIR);
                        this._showWinWord(BaccaratWinType.BANKER_PAIR);
                        break;
                    case 3:
                        // 閒莊各一對
                        this._showZoneLight(BaccaratZoneType.PLAYER_PAIR);
                        this._showZoneLight(BaccaratZoneType.BANKER_PAIR);
                        this._showWinWord(BaccaratWinType.PLAYER_PAIR);
                        this._showWinWord(BaccaratWinType.BANKER_PAIR);
                        break;
                }
            } else {
                // 不用顯示
                delayTime = 1.4;
            }

            this.runAction(cc.sequence(
                cc.delayTime(delayTime),
                cc.callFunc(resolve)
            ));
        })
    },

    /**
     * 播贏或平手的文字動畫
     */
    showWinReslutAsync: function (param) {
        return new Promise(resolve => {
            // 先出現誰贏
            var whoWin = parseInt(param.beadRoad[0]);
            switch (whoWin) {
                case 0:
                    // 閒贏
                    this._showZoneLight(BaccaratZoneType.PLAYER);
                    this._showWinWord(BaccaratWinType.PLAYER);
                    break;
                case 1:
                    // 莊贏
                    this._showZoneLight(BaccaratZoneType.BANKER);
                    this._showWinWord(BaccaratWinType.BANKER);
                    break;
                case 2:
                    // 平手
                    this._showZoneLight(BaccaratZoneType.SERI);
                    this._showWinWord(BaccaratWinType.SERI);
                    break;
            }

            // 贏錢的結果
            var result = param.result;

            // 把沒中的籌碼移掉
            var haveMoveOutChips = false;
            var winZoneBetChipSprite = {};
            for (var zoneType in this._zoneBetChipSprite) {
                if (result[BaccaratZoneTypeToResultPos[zoneType]] === 0) {
                    // 沒中獎的
                    this._zoneBetChipSprite[zoneType].forEach(function (cur) {
                        haveMoveOutChips = true;
                        cur.runAction(cc.moveTo(1, cc.p(JSScreenMidPos.x, JSVisibleSize.height + 30)));
                    })
                } else {
                    // 代表有中獎的
                    winZoneBetChipSprite[zoneType] = this._zoneBetChipSprite[zoneType];
                }
            }

            // 撥放收掉的音樂
            if (haveMoveOutChips)
                Vegas_MusicUtility.playEffect("Music/Effect/chippool.mp3");

            // 中獎的籌碼分發 先算出總共有幾個籌碼
            var bigTableIndex = this._isBigTable ? 3 : 0;
            var chipsMoney = [BaccaratBetChips[bigTableIndex].money, BaccaratBetChips[bigTableIndex + 1].money, BaccaratBetChips[bigTableIndex + 2].money];
            var chipsSpriteName = [BaccaratBetChips[bigTableIndex].image, BaccaratBetChips[bigTableIndex + 1].image, BaccaratBetChips[bigTableIndex + 2].image];
            for (var zoneType in winZoneBetChipSprite) {
                // 先判斷是否單純的退錢而已
                if (this._zoneBetMoney[zoneType] === param.result[zoneType - 1]) {
                    // 是單純退錢
                    var moveFunc = (zoneType) => {
                        var basePosition = this._zoneButtonObjects[zoneType].getPosition();
                        this.runAction(cc.sequence(
                            cc.delayTime(1),
                            cc.callFunc(function () {
                                // 把壓注區原本的籌碼也收回來
                                var moveByPos = cc.pSub(cc.p(JSScreenMidPos.x, 40), basePosition);
                                winZoneBetChipSprite[zoneType].forEach(function (cur) {
                                    cur.runAction(cc.moveBy(1, moveByPos));
                                });
                            })
                        ));
                    };
                    moveFunc(zoneType);
                    continue;
                }

                // 抓出賠率
                var winRatio = BaccaratWinRatio[zoneType];

                // 算出要賠的數量
                var winChipsCount = [0, 0, 0];
                var zoneWinChips = 0;
                this._zoneBetChipCountArray[zoneType].forEach(function (cur, index) {
                    zoneWinChips += (cur * winRatio);

                    // 算出小 中 大的籌碼數
                    winChipsCount[index] = cur * winRatio;
                });

                // 如果數量超過 把小籌碼換成較大的籌碼給他
                if (zoneWinChips > 300) {
                    if (zoneWinChips < 600) {
                        // 小轉中就好
                        var changeRatio = Math.floor(chipsMoney[1] / chipsMoney[0]);
                        winChipsCount[1] += Math.floor(winChipsCount[0] / changeRatio);
                        winChipsCount[0] %= changeRatio;
                    } else {
                        // 小轉中 中轉大
                        var changeRatio = Math.floor(chipsMoney[1] / chipsMoney[0]);
                        winChipsCount[1] += Math.floor(winChipsCount[0] / changeRatio);
                        winChipsCount[0] %= changeRatio;

                        changeRatio = Math.floor(chipsMoney[2] / chipsMoney[1]);
                        winChipsCount[2] += Math.floor(winChipsCount[1] / changeRatio);
                        winChipsCount[1] %= changeRatio;
                    }
                }

                // 創籌碼 先算好總數量 然後倒著放回來
                var stackPerChips = 20;         // 一疊最多幾個籌碼
                var stackCount = 0;             // 有幾疊籌碼
                winChipsCount.forEach(function (count) {
                    stackCount += Math.floor(count / stackPerChips);
                    // 要多加一疊
                    if (count % stackPerChips !== 0)
                        stackCount++;
                });

                // 開始擺放
                var chipOneRowMaxStack = 3;                                     // 一列最多幾疊
                if (stackCount > 20)
                    chipOneRowMaxStack = 9;
                else if (stackCount > 10)
                    chipOneRowMaxStack = 6;
                var chipStackOffset = cc.p(14, 14);                             // 每疊位移多少
                var lastRowStack = (stackCount % chipOneRowMaxStack);           // 最前面那一行有幾疊
                var otherRowBaseX = chipStackOffset.x * (chipOneRowMaxStack - 1) / 2;       // 後面行數 最右邊的X
                var firstRowBaseX = chipStackOffset.x * (lastRowStack - 1) / 2;             // 第一行 最右邊的X
                var winChipsAllPos = [];
                for (var i = 0; i < stackCount; i++) {
                    var pos;
                    if (i < lastRowStack) {
                        // 排前面的位置
                        pos = cc.p(firstRowBaseX - chipStackOffset.x * i, 0);
                    } else {
                        // 排後面的位置
                        var nowIndex = i - lastRowStack;
                        pos = cc.p(otherRowBaseX - chipStackOffset.x * (nowIndex % chipOneRowMaxStack), chipStackOffset.y * (Math.floor(nowIndex / chipOneRowMaxStack) + 1));
                    }
                    winChipsAllPos.push(pos);
                }

                var winChipsNode = new cc.Node();   // 用來放贏家籌碼
                winChipsNode.setCascadeOpacityEnabled(true);
                winChipsNode.setPosition(JSScreenMidPos.x, JSVisibleSize.height + 10);
                this._chipsNode.addChild(winChipsNode, zoneType);

                winChipsCount.forEach(function (count, index) {
                    for (var i = 0; i < count; i++) {
                        if (i % stackPerChips === 0 && i !== 0) {
                            stackCount--;
                        }

                        var newChipSprite = new cc.Sprite(chipsSpriteName[index]);
                        newChipSprite.setColor(cc.color(255, 200, 200));
                        newChipSprite.setScale(0.8);
                        newChipSprite.setPosition(cc.pAdd(winChipsAllPos[stackCount - 1], cc.p(0, 2 * (i % stackPerChips))));
                        winChipsNode.addChild(newChipSprite);
                    }

                    // 換下一個顏色籌碼
                    if (count > 0)
                        stackCount--;
                });

                // 只透過winChipsNode來做動作 為了怕zoneType被改掉 用一層包起來
                var moveFunc = (zoneType) => {
                    var basePosition = this._zoneButtonObjects[zoneType].getPosition();
                    winChipsNode.runAction(cc.sequence(
                        cc.moveTo(1, basePosition),
                        cc.delayTime(1),
                        cc.callFunc(function () {
                            // 把壓注區原本的籌碼也收回來
                            var moveByPos = cc.pSub(cc.p(JSScreenMidPos.x, 40), basePosition);
                            winZoneBetChipSprite[zoneType].forEach(function (cur) {
                                cur.runAction(cc.moveBy(1, moveByPos));
                            });
                        }),
                        cc.moveTo(1, cc.p(JSScreenMidPos.x, 40))
                    ));
                };
                moveFunc(zoneType);
            }

            if (param.winMoney) {
                this.runAction(cc.sequence(
                    cc.delayTime(2),
                    cc.callFunc(function () {
                        // 撥放收回來的音效
                        Vegas_MusicUtility.playEffect("Music/Effect/blackjack_btn3.mp3");
                    }),
                    cc.delayTime(1),
                    cc.callFunc(function () {
                        // 把所有籌碼清掉
                        this._chipsNode.removeAllChildren();
                    }, this)
                ));
            }

            this.runAction(cc.sequence(
                cc.delayTime(param.winMoney > 0 ? 3.6 : 2.5),
                cc.callFunc(function () {
                    resolve(this._nowTotalBetMoney);
                }, this)
            ));
        })
    },


});