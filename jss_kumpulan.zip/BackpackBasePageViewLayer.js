/**
 * v5.4.5 背包 - 背包的pageView (可直接繼承使用)
 *
 * 需要帶入的參數
 * type: ShopType
 * playerData : 個人資訊Dialog刷新資料使用(可不傳)
 * pageItemCount : 一頁有幾個物品(預設 8)
 * pageViewSize
 * pageViewPos
 *
 * 每個頁面的數量不一樣(override使用)
 * _scheduleUpdatePageView: 預設一頁8個物品
 *
 * 有需要再塞就可以
 * this._account: 買給誰(桌內有送禮) 會預設給自己
 * this._chipShopDialogType: 確認ShopProductDetailDialog打開後的按鈕數量(對應chipShopDialogType)
 *
 * created by lichieh on 2022/10/25
 */
var BackpackBasePageViewLayer = cc.Layer.extend({
    ctor: function (shopType, playerData, pageItemCount, pageViewSize, pageViewPos) {
        this._super();

        this._account = DataModal.profileData.account;    // 買給誰(桌內有送禮)
        this._chipShopDialogType = undefined;             // 確認ShopProductDetailDialog打開後的按鈕數量

        this._totalItemCount = pageItemCount || 8;
        this._playerData = playerData;
        this._shopType = shopType;              // 哪個頁籤
        this._pageDoneArray = [];               // 有哪些頁已經加完
        this._isChangeItem = false;             // 是不是更換裝備(更換裝備時不刷新頁面)

        var pageSize = this._pageSize = pageViewSize || cc.size(320, 205);
        var pos = pageViewPos || cc.p(JSScreenMidPos.x - pageSize.width / 2, 25 + JSScreenBonusHalfHeight);
        var pageView = this._pageView = new ccui.PageView();
        pageView.setPosition(pos);
        pageView.setDirection(ccui.ScrollView.DIR_HORIZONTAL);
        pageView.setContentSize(pageSize);
        pageView.setBounceEnabled(true);
        pageView.setIndicatorEnabled(true);
        pageView.setIndicatorSpaceBetweenIndexNodes(10);
        pageView.setIndicatorIndexNodesTexture("lobby_page_point_0.png", ccui.Widget.PLIST_TEXTURE);
        pageView.setIndicatorSelectedIndexColor(cc.color(255, 255, 255));
        pageView.setIndicatorPosition(cc.p(pageSize.width / 2, 0));
        this.addChild(pageView);

        // 當PageView滑動的行為, 看不到的物件先隱藏，避免draw call過高
        var pageViewScrollFunc = (sender, eventType) => {
            var currentIndex = pageView.getCurrentPageIndex();
            // 滑動結束
            switch (eventType) {
                case ccui.ScrollView.EVENT_AUTOSCROLL_ENDED:
                    pageView.getItems().forEach((cur, index) => {
                        cur.setVisible(index === currentIndex);
                    });

                    // 去看現在畫面更新到哪些頁面
                    this._scheduleUpdatePageView();
                    break;
                case ccui.ScrollView.EVENT_SCROLLING:
                    pageView.getItems().forEach((cur) => {
                        cur.setVisible(true);
                    });

                    // 去看現在畫面更新到哪些頁面
                    this._scheduleUpdatePageView();
                    break;
                default:
            }
        };
        pageView.addCustomEventListener(pageViewScrollFunc);

        // 加Loading
        var loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(pos.x + pageSize.width / 2, pos.y + pageSize.height / 2);
        loadingSprite.start();
        this.addChild(loadingSprite);

        // 註冊
        GS.addListener("NotifyShopDataDone", this.notifyShopDataDone.bind(this), this);
        GS.addListener("NotifyUpdateSelfAccessory", this.notifyUpdateSelfAccessory.bind(this), this);
    },

    // 送Socket CMD
    sendSocketCommand: function () {
        // 砍掉其他頁面的資料，等server傳
        if (this._shopType === ShopType.OTHER) {
            DataModal.shopData.deleteShopItemArrayByType(this._shopType);
        } else if (DataModal.shopData.getShopItemArrayByType(this._shopType).length) {
            this._refreshAllPage();
        }

        switch (this._shopType) {
            case ShopType.PRODUCT:
                if (DataModal.shopData.getShopItemDone)
                    this._refreshAllPage();
                else
                    DataModal.shopData.startGetInfo();
                break;

            case ShopType.BACKPACK:
                // 背包
                DataProcess.sendString("backpack a,b,g");
                break;

            case ShopType.EXTEND:
                // 延長物品
                DataProcess.sendString("extend_livetime_backpack");
                break;

            case ShopType.MEDAL:
                // 勳章
                DataProcess.sendString("backpack h");
                break;

            case ShopType.OTHER:
                // 其他
                DataProcess.sendString("backpack l");
                break;

            case ShopType.FRAME:
                // 頭像框
                DataProcess.sendString("backpack m");
                break;
        }
    },

    _updatePage: function () {
        // 判斷是否有Item
        var pageView = this._pageView;
        this._pageArray = [];
        this._shopItemNodeArray = [];
        this._pageDoneArray = [];
        var shopString = LocalizedString.Shop;
        if (this._shopItemArray.length === 0) {
            // 要出現文字
            var message;
            switch (this._shopType) {
                case ShopType.PRODUCT:
                    message = shopString("目前商城沒此類商品");
                    break;
                case ShopType.EXTEND:
                    message = shopString("您沒有可延長時效的物品喔!");
                    break;
                case ShopType.BACKPACK:
                    message = shopString("您沒有任何物品,請至商城購買");
                    break;
                case ShopType.MEDAL:
                    message = shopString("您沒有任何勳章,請透過活動取得");
                    break;
                default:
                    message = shopString("目前沒有任何物品");
                    break;
            }

            var layout = new ccui.Layout();
            layout.setContentSize(this._pageSize);
            pageView.addPage(layout);

            var messageLabel = new cc.LabelTTF(message, JSFontBoldName, 14);
            messageLabel.setPosition(this._pageSize.width / 2, this._pageSize.height - 80);
            messageLabel.setFontFillColor(JSColor.WHITE);
            layout.addChild(messageLabel);

        } else {
            var totalItemLen = this._shopItemArray.length;
            var totalPage = Math.floor((totalItemLen - 1) / this._totalItemCount) + 1;

            for (var i = 0; i < totalPage; i++) {
                // 這邊先加空白的 等有移動到在加
                var layout = this._pageArray[i] = new ccui.Layout();
                layout.setContentSize(this._pageSize);
                pageView.addPage(layout);

                // 記錄哪些頁還沒創
                this._pageDoneArray[i] = 0;
            }

            // 先處理一次1, 2頁
            this._scheduleUpdatePageView();
        }
    },

    // 更新畫面
    _refreshAllPage: function () {
        // 把Loading拿掉
        this._loadingSprite.stop();

        // 以下Page的主畫面
        var pageView = this._pageView;
        pageView.removeAllPages();

        // 抓有哪些Item
        this._shopItemArray = DataModal.shopData.getShopItemArrayByType(this._shopType) || [];

        this._updatePage();
    },

    _showBuyDialog: function (shopObj) {
        if (!shopObj || !JSCodeUtility.isObject(shopObj))
            return;

        // 延效物品只有購買按鈕
        shopObj.shopType = this._shopType;

        // 買給誰(桌內有送禮)
        shopObj.sendID = this._account;
        // 延效物品只有購買按鈕
        shopObj.chipShopDialogType = (shopObj.type === ShopType.EXTEND) ? ChipShopDialog.Type.SINGLE : this._chipShopDialogType;

        var dialog = new ShopProductDetailDialog(shopObj);
        dialog.startDialogAnimation();
        this.addChild(dialog, 100);
    },

    /**
     * 去檢查PageView有沒有換頁 有的話判斷是否要處理下一頁的東西
     * @override
     */
    _scheduleUpdatePageView: function () {
        var pageView = this._pageView;
        var pageIndex = pageView.getCurrentPageIndex();
        var pageDoneArray = this._pageDoneArray;

        if (pageDoneArray[pageIndex] === 0 || pageDoneArray[pageIndex + 1] === 0) {
            // 要創
            var totalItemLen = this._shopItemArray.length;
            var startPage = (pageIndex === 0 ? 0 : pageIndex + 1);  // 哪頁開始
            var toPage = pageIndex + 1;                             // 做到哪一頁

            var basePosY = this._shopType === ShopType.PRODUCT ? 136 : 156;
            for (var i = startPage; i <= toPage; i++) {
                var layout = this._pageArray[i];
                if (!layout)
                    break;

                var baseCount = i * this._totalItemCount;
                var thisPageCount = (totalItemLen - baseCount) >= this._totalItemCount ? this._totalItemCount : (totalItemLen - baseCount);
                for (var x = 0; x < thisPageCount; x++) {
                    var itemPos = x + baseCount;
                    var shopObj = this._shopItemArray[itemPos];
                    var shopItemNode = this._shopItemNodeArray[itemPos] = new BackpackItemNode(shopObj, this._shopItemClicked, this);
                    shopItemNode.setPosition(40 + (x % 4) * 76, basePosY - Math.floor(x / 4) * 90);
                    layout.addChild(shopItemNode);
                }

                // 記錄這頁好了
                this._pageDoneArray[i] = 1;
            }
        }
    },

    /**
     * 點到道具
     */
    _shopItemClicked: function (shopObj) {
        if (this._shopType === ShopType.BACKPACK || this._shopType === ShopType.MEDAL || this._shopType === ShopType.FRAME) {
            // 背包或勳章
            var profileData = DataModal.profileData;
            var playerData = this._playerData;

            var nowItem;
            switch (this._shopType) {
                case ShopType.BACKPACK:
                    nowItem = profileData.accessory.code;
                    break;

                case ShopType.MEDAL:
                    nowItem = profileData.medal.code;
                    break;

                case ShopType.FRAME:
                    nowItem = profileData.vip.code;
                    break;
            }

            var resetItem = (nowItem === shopObj.serial);
            switch (this._shopType) {
                case ShopType.BACKPACK:
                    // 同一件要取消裝備
                    if (resetItem)
                        DataProcess.sendString("reset_item_socket accessory");
                    else {
                        DataProcess.sendString("use_item_socket " + shopObj.wid);

                        // 清掉其他裝備
                        DataProcess.sendString("reset_item_socket medal");
                        profileData.medal.name = "";
                        profileData.medal.code = "";
                    }

                    profileData.accessory.name = resetItem ? "" : shopObj.name;
                    profileData.accessory.code = resetItem ? "" : shopObj.serial;

                    if (playerData) {
                        playerData.accessory.name = resetItem ? "" : shopObj.name;
                        playerData.accessory.code = resetItem ? "" : shopObj.serial;
                    }
                    break;

                case ShopType.MEDAL:
                    if (resetItem)
                        DataProcess.sendString("reset_item_socket medal");
                    else {
                        DataProcess.sendString("use_item_socket " + shopObj.wid);

                        // 清掉其他裝備
                        DataProcess.sendString("reset_item_socket accessory");
                        profileData.accessory.name = "";
                        profileData.accessory.code = "";
                    }

                    profileData.medal.name = resetItem ? "" : shopObj.name;
                    profileData.medal.code = resetItem ? "" : shopObj.serial;

                    if (playerData) {
                        playerData.medal.name = resetItem ? "" : shopObj.name;
                        playerData.medal.code = resetItem ? "" : shopObj.serial;
                    }
                    break;

                case ShopType.FRAME:
                    if (resetItem)
                        DataProcess.sendString("reset_item_socket identity");
                    else
                        DataProcess.sendString("use_item_socket " + shopObj.wid);

                    profileData.vip.item = resetItem ? "" : shopObj.name;
                    profileData.vip.code = resetItem ? "" : shopObj.serial;
                    // ProfileDialog裡的資料也更新
                    if (playerData) {
                        playerData.identity = resetItem ? "" : shopObj.serial;
                    }
                    break;
            }

            // 重整選到的邊框
            this._shopItemNodeArray.forEach((cur) => cur.checkItemNeededFrame());

            // 要把個人資訊的東西清掉 之後重新要
            DataModal.playerProfileData.cleanData();

            // 更換裝備不刷新頁面
            this._isChangeItem = true;

            // 更新資料
            GS.dispatchCustomEvent("NotifyUpdateSelfAccessory");
        } else if (this._shopType === ShopType.EXTEND || this._shopType === ShopType.PRODUCT) {
            // 要跳Dialog
            this._showBuyDialog(shopObj);
        }

        // 查看是否有東西
        if (shopObj.info && this._shopType === ShopType.OTHER) {
            // 物品說明dialog
            var dialog = new BackpackItemDialog(shopObj);
            DialogManager.addDialog(dialog, false);
        }

        // 桌內加入提示訊息
        if (PushScene.isGame) {
            // 加入提示訊息(物品、頭像框)
            if (this._shopType === ShopType.BACKPACK || this._shopType === ShopType.FRAME) {
                if (!this._hintNode) {
                    var node = this._hintNode = new cc.Node();
                    node.setOpacity(0);
                    node.setCascadeOpacityEnabled(true);
                    node.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 30);
                    this.addChild(node, 1000);

                    var hintMsg = (this._shopType === ShopType.BACKPACK) ? "牌局中更換物品，下一局才會更新" : "會於下一回合幫你更換你選擇的頭像框";
                    var noticeLabel = new cc.LabelTTF(LocalizedString.Shop(hintMsg), JSFontBoldName, 10);
                    noticeLabel.setVisible(true);
                    noticeLabel.setFontFillColor(cc.color(244, 192, 0));
                    node.addChild(noticeLabel, 1);

                    // 陰影
                    var shadowSprite = new ccui.Scale9Sprite("bg_shadow_02.png");
                    shadowSprite.setPreferredSize(cc.size(noticeLabel.getContentSize().width + 12, noticeLabel.getContentSize().height + 8));
                    node.addChild(shadowSprite);
                }
                this._hintNode.stopAllActions();
                this._hintNode.runAction(cc.sequence(cc.fadeIn(0.5), cc.delayTime(1), cc.fadeOut(0.5), cc.callFunc(() => {
                    this._hintNode.removeFromParent();
                    this._hintNode = undefined;
                })));
            }
        }
    },

    // 給外面重整該頁面物品使用狀態
    refreshItemCheckStatus: function () {
        // 重整選到的邊框
        this._shopItemArray && this._shopItemNodeArray.forEach((cur) => cur.checkItemNeededFrame());
    },

    /**
     * 通知
     */
    // Socket東西回來了
    notifyShopDataDone: function (event) {
        var type = event.getUserData();
        if (this._shopType === type || !type) {
            // 是這類型 更新畫面
            this._refreshAllPage();
        }
    },

    notifyUpdateSelfAccessory: function () {
        // 更換裝備時不刷新整個頁面
        if (this._isChangeItem) {
            this._isChangeItem = false;
            return;
        }

        this._refreshAllPage();
    }
});