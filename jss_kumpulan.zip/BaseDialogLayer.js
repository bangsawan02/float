/**
 * Dialog的基底
 */

var BaseDialogLayer = cc.Layer.extend({
    initProperties: function () {
        // 預設的Dialog Key
        this.key = "";

        // 用來判斷此Dialog是否跳出來需要動畫
        this.openNeedAnimation = true;

        // 用來判斷此Dialog在onExit的時後 是否要執行DialogManager.removeDialog
        this.removeWhenOnExit = true;

        // 是否已經做完過跳出動畫 之後重新跳出就不要再做了
        this._openAnimationDone = false;

        // 是否是暫時拿掉Dialog 不走到onExit會爛掉
        this.tempHide = false;

        // 被設隱藏時紀錄當下的可視設定
        this.hidingVisible = false;

        // android back key 是否鎖定backKey關閉dialog
        this.isLockBackKey = false;

        // 可以設定的背景色
        this.dialogBgColor = cc.color(0, 0, 0, DIALOG_BG_OPACITY);

        // 需要讀取的素材
        this.loadFileArray = [];

        // 素材是否讀取完畢
        this._loadFileDone = false;

        // 我是webView
        this._webView = undefined;

        // 即將要關閉之前要做的事
        this.__willCloseCallback = undefined;

        // 關閉之後要做的事
        this.__closeCallback = undefined;

        // 隱藏之後要做的事
        this.__hideCallback = undefined;

        // 從哪邊出來跟結束
        this.__openWorldPos = undefined;
    },

    ctor: function () {
        this._super();
        this.initProperties();
        this.setCascadeOpacityEnabled(true);

        // 加一層UI檔Touch
        var dummyTouch = this._dummyTouch = new DummyTouchLayer(cc.size(JSVisibleSize.width + 2, JSVisibleSize.height + 2));
        dummyTouch.setPosition(-1, -1);
        this.addChild(dummyTouch, -10000);

        // 背景色
        this._addBackgroundLayer();

        // 跳出的視窗 改用cc.Layer 這樣就不用重新對位
        // @deprecated this._animationNode, please use this._animationLayer instead.
        var aniLayer = this._animationNode = this._animationLayer = new cc.Layer();
        aniLayer.setCascadeColorEnabled(true);
        aniLayer.setCascadeOpacityEnabled(true);
        aniLayer.setScale(0);
        aniLayer.setContentSize(JSVisibleSize);          // 要加這行 因為他預設是WinSize 這樣在做動畫看起來會有點位移
        this.addChild(aniLayer);
    },

    onEnter: function () {
        this._super();

        // Native不需要讀取
        if (cc.sys.isNative || this.loadFileArray.length === 0) {
            this.loadFileDone();
        } else {        // H5要先讀取
            // 加讀取
            this.addLoadingLayer();

            // 去讀取檔案
            cc.loader.load(this.loadFileArray, () => {
                this.loadFileDone();
            });
        }

        // 加Android back key
        PushScene.addBackKeyEnableLayer(this);
    },

    onExit: function () {
        PushScene.removeBackKeyEnableLayer(this);

        // 拿掉自己
        this.removeWhenOnExit && DialogManager.removeDialog(this);

        this._super();
    },

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        if (this.isLockBackKey) {
            return;
        }

        this._closeDialogAnimation();
    },

    /**
     * 加讀取
     * 可自行override做不同呈現
     */
    addLoadingLayer: function () {
        // 加之前先檢查有沒有加過，有的話要拿掉
        this.removeLoadingLayer();

        // 加讀取
        var loadingLayer = this._loadingLayer = new cc.LayerColor(JSColor.BLACK, JSVisibleSize.width + 2, JSVisibleSize.height + 2);
        loadingLayer.setOpacity(0);
        loadingLayer.setCascadeOpacityEnabled(true);
        loadingLayer.setPosition(-1, -1);
        this.addChild(loadingLayer, JSCodeUtility.INT_MAX);

        // 讀取sprite
        var loadingSprite = this._dialogLoadingSprite = new GSLoadingSprite();
        loadingSprite.setOpacity(0);
        loadingSprite.setPosition(JSScreenMidPos);
        loadingSprite.start();
        this.addChild(loadingSprite, JSCodeUtility.INT_MAX - 1);

        loadingLayer.runAction(cc.fadeTo(DIALOG_ANIMATION_TIME, 0.3));
        loadingSprite.runAction(cc.fadeIn(DIALOG_ANIMATION_TIME));
    },

    /**
     * 移除讀取
     * 可自行override做不同呈現
     */
    removeLoadingLayer: function () {
        if (this._loadingLayer) {
            this._loadingLayer.removeFromParent();
            this._loadingLayer = undefined;
        }
        if (this._dialogLoadingSprite) {
            this._dialogLoadingSprite.removeFromParent();
            this._dialogLoadingSprite = undefined;
        }
    },

    /**
     * 用來執行讀取檔案完之後要做的事
     * 自行override
     */
    loadFileDone: function () {
        // 素材讀取完畢
        this._loadFileDone = true;

        this.removeLoadingLayer();
    },

    /**
     * 移除DummyTouchLayer
     */
    removeDummyTouchLayer: function () {
        if (this._dummyTouch) {
            this._dummyTouch.removeFromParent();
            this._dummyTouch = undefined;
        }
    },

    /**
     * Override掉 假如有WebView一起關掉，同時控制BackKey
     */
    setVisible: function (isVisible) {
        this._super(isVisible);

        this._webView && this._webView.setVisible(isVisible);

        if (isVisible)
            PushScene.addBackKeyEnableLayer(this);
        else
            PushScene.removeBackKeyEnableLayer(this);
    },

    /**
     * 設定是否暫時先藏起來
     * @param value
     */
    setTempHide: function (value) {
        if (this.tempHide === value)
            return;

        this.tempHide = value;

        if (this.tempHide) {
            this.hidingVisible = this.isVisible();
            this.setVisible(false);
            // 強制取消跳出動畫
            if (!this._openAnimationDone) {
                this._stopDialogAnimation();
            }
        } else {
            this.setVisible(this.hidingVisible);
            // 強制之前被取消跳出動畫，這裡要補跳
            if (this.hidingVisible && !this._openAnimationDone) {
                this._startDialogAnimation();
            }
        }

        // 如果被隱藏才執行
        value && this.__hideCallback && this.__hideCallback();
    },

    /**
     * 設定即將要關閉之前要做的事
     * @param callback
     */
    setWillCloseCallback: function (callback) {
        this.__willCloseCallback = callback;
    },

    /**
     * 設定關閉之後要做的事
     * @param callback
     */
    setCloseCallback: function (callback) {
        this.__closeCallback = callback;
    },

    /**
     * 設定隱藏之後要做的事
     * @param callback
     */
    setHideCallback: function (callback) {
        this.__hideCallback = callback;
    },

    /**
     * 設定跳出來的東西從哪開始 從哪結束
     */
    setOpenWorldPosition: function (pos) {
        this.__openWorldPos = pos;
    },

    /**
     * 讓 dialog 演跳出動畫
     * 這是專門給外部呼叫用的，繼承的時候須保持原有功能
     * (_startDialogAnimation 已遍地都是，所以就包一層減少修改量)
     */
    startDialogAnimation: function () {
        this._startDialogAnimation();
    },

    /**
     * 讓 dialog 演關閉動畫
     * 這是專門給外部呼叫用的，繼承的時候須保持原有功能
     * (_closeDialogAnimation 已遍地都是，所以就包一層減少修改量)
     */
    closeDialogAnimation: function () {
        this._closeDialogAnimation();
    },

    /**
     * 加入淡入淡出的背景底圖 (不會跟著animationLayer做彈跳動畫)
     * 可自行override
     */
    _addBackgroundLayer: function () {
        this._bgColorLayer = new cc.LayerColor(cc.color(0, 0, 0, 0), JSVisibleSize.width + 2, JSVisibleSize.height + 2);
        this._bgColorLayer.setPosition(-1, -1);
        this.addChild(this._bgColorLayer, -10000);
    },

    /**
     * 當彈跳做完動畫
     */
    // 打開畫面結束
    _dialogOpenAnimationDone: function () {
        // 給需要的人override
        this._openAnimationDone = true;
    },

    // 關掉畫面結束
    _dialogCloseAnimationDone: function () {
        // 給需要的人override
    },

    /**
     * 動畫
     */
    // 做彈跳動畫
    _startDialogAnimation: function () {
        var aniLayer = this._animationLayer;
        var bgColorLayer = this._bgColorLayer;

        if (this.openNeedAnimation && !this._openAnimationDone) {
            // 做彈跳動畫
            aniLayer.stopAllActions();

            // 判斷是否要從指定的位置開始跳
            if (this.__openWorldPos) {
                // 有指定位置
                var toPos = cc.pSub(this.convertToNodeSpace(this.__openWorldPos), JSScreenMidPos);
                aniLayer.setPosition(toPos);
                aniLayer.runAction(cc.sequence(
                    cc.spawn(
                        cc.moveTo(DIALOG_ANIMATION_TIME, cc.p(0, 0)),
                        cc.scaleTo(DIALOG_ANIMATION_TIME, 1)
                    ),
                    cc.callFunc(function () {
                        BaseDialogLayer.__baseDialogOpenAnimationDone && BaseDialogLayer.__baseDialogOpenAnimationDone(this);
                        this._dialogOpenAnimationDone();
                    }, this)
                ));
            } else {
                // 沒指定位置
                aniLayer.setPosition(0, 0);
                aniLayer.runAction(cc.sequence(
                    cc.scaleTo(DIALOG_ANIMATION_TIME, 1).easing(cc.easeBackOut()),
                    cc.callFunc(function () {
                        BaseDialogLayer.__baseDialogOpenAnimationDone && BaseDialogLayer.__baseDialogOpenAnimationDone(this);
                        this._dialogOpenAnimationDone();
                    }, this)
                ));
            }

            if (bgColorLayer) {
                bgColorLayer.stopAllActions();

                var toColor = this.dialogBgColor;
                bgColorLayer.runAction(cc.spawn(
                    cc.tintTo(DIALOG_ANIMATION_TIME, toColor.r, toColor.g, toColor.b),
                    cc.fadeTo(DIALOG_ANIMATION_TIME, toColor.a))
                );
            }
        } else {
            // 不做動畫
            aniLayer.stopAllActions();
            aniLayer.setScale(1);

            if (bgColorLayer) {
                bgColorLayer.stopAllActions();
                bgColorLayer.setColor(this.dialogBgColor);
                bgColorLayer.setOpacity(this.dialogBgColor.a);
            }

            if (!this._openAnimationDone) {
                BaseDialogLayer.__baseDialogOpenAnimationDone && BaseDialogLayer.__baseDialogOpenAnimationDone(this);
                this._dialogOpenAnimationDone();
            }
        }
    },

    // 中止動畫 只給DialogManager用
    _stopDialogAnimation: function () {
        this._animationLayer.stopAllActions();
        this._bgColorLayer && this._bgColorLayer.stopAllActions();
    },

    // 關掉Dialog
    _closeDialogAnimation: function () {
        // 動畫中 || 已被砍掉就不跑關掉的動畫
        if (this._closeAnimation || this.__isDestroyed)
            return;
        var aniLayer = this._animationLayer;
        var bgColorLayer = this._bgColorLayer;

        // 加一層UI檔Touch
        var dummyTouch = new DummyTouchLayer(cc.size(JSVisibleSize.width + 2, JSVisibleSize.height + 2));
        dummyTouch.setPosition(-1, -1);
        this.addChild(dummyTouch, 99999);

        // 動畫
        aniLayer.stopAllActions();

        // 判斷是否要往指定的位置縮過去
        if (this.__openWorldPos) {
            var toPos = cc.pSub(this.convertToNodeSpace(this.__openWorldPos), JSScreenMidPos);
            aniLayer.runAction(cc.spawn(
                cc.moveTo(DIALOG_ANIMATION_TIME, toPos),
                cc.scaleTo(DIALOG_ANIMATION_TIME, 0)
            ));
        } else {
            aniLayer.runAction(cc.scaleTo(DIALOG_ANIMATION_TIME, 0).easing(cc.easeBackIn()));
        }

        if (bgColorLayer) {
            bgColorLayer.stopAllActions();
            bgColorLayer.runAction(cc.fadeTo(DIALOG_ANIMATION_TIME, 0));
        }

        // 即將要關閉之前要做的事
        this.__willCloseCallback && this.__willCloseCallback();

        this.stopAllActions();
        this.runAction(cc.sequence(
            cc.delayTime(DIALOG_ANIMATION_TIME),
            cc.callFunc(() => {
                this._dialogCloseAnimationDone();

                // 關閉之後要做的事
                this.__closeCallback && this.__closeCallback();

                this._webView && this._webView.removeFromParent();
            }),
            cc.removeSelf()
        ));

        this._closeAnimation = true;
    }
});

// 設定所有dialog跳出時都會共同呼叫的callback
BaseDialogLayer.setBaseDialogOpenAnimationDoneCallback = function (callbackFunc) {
    BaseDialogLayer.__baseDialogOpenAnimationDone = callbackFunc;
};