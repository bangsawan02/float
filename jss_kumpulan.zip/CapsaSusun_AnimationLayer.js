/**
 * Poker13 特效集中區
 */

var CapsaSusun_AnimationLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this.clean();
    },

    clean: function () {
        this._hasShowMeSpecialAnim = false;
        this.removeAllChildren();
        this._strikeAnimNode = undefined;
        this._gunGaf1 = undefined;
        this._gunGaf2 = undefined;
        this._shootFootballAnimNode = undefined;
    },

    // 取2座標夾角
    // 以posA為原點 向量posB的tan(Θ) 回傳角度
    _getTwoPointAngle: function (posA, posB) {
        var x = posB.x - posA.x;
        var y = posB.y - posA.y;

        var z = Math.sqrt(x * x + y * y);
        return Math.round((Math.asin(y / z) / Math.PI) * 180); //最終角度
    },

    // 顯示開始比牌文字動畫
    showStartFight: function () {
        var startBg = new ccui.Scale9Sprite("capsaSusun_pic_frame_01.png");
        startBg.setPreferredSize(cc.size(380, 70));
        startBg.setPosition(JSScreenMidPos);
        this.addChild(startBg);
        startBg.runAction(
            cc.sequence(
                cc.fadeIn(0.1),
                cc.delayTime(1.5),
                cc.fadeOut(0.4),
                cc.removeSelf()
            )
        );

        // 初始位置
        var originalPos = [
            cc.p(JSScreenMidPos.x + 80, JSScreenMidPos.y + 35),
            cc.p(JSScreenMidPos.x - 80, JSScreenMidPos.y - 35)
        ];

        // 上下的金線
        for (var i = 0; i < 2; i++) {
            var goldSp = new cc.Sprite("#lobby_pic_gold.png");
            goldSp.setPosition(originalPos[i]);
            goldSp.setScaleY(0.6);
            goldSp.setOpacity(0);
            this.addChild(goldSp);

            var endPos = cc.p(originalPos[1 - i].x, originalPos[i].y);
            // 做動畫, 結束後刪掉自己
            goldSp.runAction(
                cc.sequence(
                    cc.fadeIn(0.1),
                    cc.delayTime(0.75),
                    cc.spawn(cc.scaleTo(0.4, 1), cc.moveTo(0.4, endPos.x, endPos.y), cc.fadeOut(0.4)),
                    cc.removeSelf()
                )
            );
        }

        var startFightSp = new cc.Sprite("#capsaSusun_word_card_start.png");
        startFightSp.setPosition(JSScreenMidPos.x, JSScreenMidPos.y);
        startFightSp.setOpacity(0);
        startFightSp.setScale(8);
        this.addChild(startFightSp);
        // 做動畫, 結束後刪掉自己
        startFightSp.runAction(
            cc.sequence(
                cc.spawn(cc.fadeIn(0.4), cc.scaleTo(0.4, 0.9)),
                cc.scaleTo(0.1, 1.1),
                cc.scaleTo(0.1, 1),
                cc.delayTime(1),
                cc.fadeOut(0.4),
                cc.removeSelf()
            )
        );

        // 撥音效
        MusicUtility.playEffect("Music/Effect/Domino/capsaSusun_startFight.mp3");
    },

    // 一般比牌
    showNormalFighting: function (posArray, cardTypeArray, scoreArray) {
        // 照順序開始翻開
        this.runAction(
            cc.sequence(
                cc.delayTime(0.45),
                cc.callFunc(() => {
                    posArray.forEach(pos => {
                        var type = cardTypeArray[pos] && cardTypeArray[pos][0];
                        if (type) {
                            var isWin = scoreArray[0] && scoreArray[0][pos] >= 0;
                            var direction = DataModal.gameData.getDirectionByServerDirection(pos);
                            var position = CapsaSusun_GameUtility.getCardStacksMidPos(direction);
                            var cardType = new CapsaSusun_CardTypeAnimNode(false, type, isWin);
                            cardType.setPosition(position.x, position.y + 10);
                            this.addChild(cardType);
                        }
                    });
                }),
                cc.delayTime(0.75),
                cc.callFunc(() => {
                    posArray.forEach(pos => {
                        var type = cardTypeArray[pos] && cardTypeArray[pos][1];
                        if (type) {
                            var isWin = scoreArray[1] && scoreArray[1][pos] >= 0;
                            var direction = DataModal.gameData.getDirectionByServerDirection(pos);
                            var position = CapsaSusun_GameUtility.getCardStacksMidPos(direction);
                            var cardType = new CapsaSusun_CardTypeAnimNode(false, type, isWin);
                            cardType.setPosition(position.x, position.y - 15);
                            this.addChild(cardType);
                        }
                    });
                }),
                cc.delayTime(0.75),
                cc.callFunc(() => {
                    posArray.forEach(pos => {
                        var type = cardTypeArray[pos] && cardTypeArray[pos][2];
                        if (type) {
                            var isWin = scoreArray[2] && scoreArray[2][pos] >= 0;
                            var direction = DataModal.gameData.getDirectionByServerDirection(pos);
                            var position = CapsaSusun_GameUtility.getCardStacksMidPos(direction);
                            var cardType = new CapsaSusun_CardTypeAnimNode(false, type, isWin);
                            cardType.setPosition(position.x, position.y - 40);
                            this.addChild(cardType);
                        }
                    });
                })
            )
        );
    },

    // 特殊比牌
    showSpecialFighting: function (posArray, cardTypeArray) {
        posArray.forEach(pos => {
            var direction = DataModal.gameData.getDirectionByServerDirection(pos);

            var type = cardTypeArray[pos][0];
            if (pos === DataModal.gameData.myPos) {
                if (!this._hasShowMeSpecialAnim) {
                    this.showMySelfSpecialAnime(type);
                }
            } else {
                var position = CapsaSusun_GameUtility.getCardStacksMidPos(direction);
                var cardType = new CapsaSusun_CardTypeAnimNode(true, type);
                cardType.setPosition(position.x, position.y - 40);
                this.addChild(cardType);
            }
        });
    },

    // 特殊牌型的動畫(自己)
    showMySelfSpecialAnime: function (cardType) {
        var position = CapsaSusun_GameUtility.getCardStacksMidPos(0);
        var cardType = new CapsaSusun_CardTypeAnimNode(true, cardType, false, false);
        cardType.setPosition(position.x, position.y - 40);
        this.addChild(cardType);
        this._hasShowMeSpecialAnim = true;
    },

    // 打槍動畫
    // winDir 贏家方位 loseDir 輸家方位
    showStrikeAnim: function (winDir, loseDir) {
        if (this._strikeAnimNode) {
            // 把上一個打槍動畫停止並移除
            this._strikeAnimNode.stopAllActions();
            this._strikeAnimNode.removeFromParent();
            this._strikeAnimNode = undefined;
            this._gunGaf1 = undefined;
            this._gunGaf2 = undefined;
        }

        // 創個node包起來
        var animNode = this._strikeAnimNode = new cc.Node();
        this.addChild(animNode);

        // 取打槍的發射跟目標座標
        var shotPos = CapsaSusun_GameUtility.getCardStacksMidPos(winDir);
        var targetPos = CapsaSusun_GameUtility.getCardStacksMidPos(loseDir);

        // 計算座標夾角 校正角度
        var rotation;
        var scaleX = 1;
        switch (winDir) {
            case GSEnum.GameDirection.RIGHT:
                rotation = this._getTwoPointAngle(shotPos, targetPos);
                break;

            case GSEnum.GameDirection.LEFT:
                rotation = -this._getTwoPointAngle(shotPos, targetPos);
                scaleX = -1;
                break;

            case GSEnum.GameDirection.BOTTOM:
            case GSEnum.GameDirection.TOP:
                rotation = this._getTwoPointAngle(shotPos, targetPos);
                // 角度修正
                if (loseDir === GSEnum.GameDirection.RIGHT) {
                    scaleX = -1;
                    rotation = -rotation;
                }
                break;
        }

        // 開始表演打槍動畫
        var runStrikeAnim = () => {
            // 載完打槍用的兩個gaf才開始跑動畫
            if (!this._gunGaf1 || !this._gunGaf2)
                return;

            this._gunGaf1.start();
            this._gunGaf2.start();

            this._strikeAnimNode.runAction(cc.sequence(
                cc.delayTime(0.5),
                cc.callFunc(() => MusicUtility.playEffect("Music/Effect/Domino/capsaSusun_shotgun.mp3")),
                cc.delayTime(3.5),
                cc.callFunc(() => {
                    this._strikeAnimNode && this._strikeAnimNode.removeFromParent();
                    this._strikeAnimNode = undefined;
                    this._gunGaf1 = undefined;
                    this._gunGaf2 = undefined;
                }, this)
            ));
        };

        var self = this;

        // 槍
        gaf.create("gaf/game/capsaSusun_gun_01.gaf", this, false, function (gafAsset) {
            var gafObject = self._gunGaf1 = gafAsset.createObjectAndRun(false);
            gafObject.stop();
            gafObject.setPosition(shotPos);
            gafObject.setScaleX(scaleX);
            gafObject.setRotation(rotation);
            self._strikeAnimNode.addChild(gafObject);

            runStrikeAnim();
        });

        // 彈孔
        gaf.create("gaf/game/capsaSusun_gun_02.gaf", this, false, function (gafAsset) {
            var gafObject = self._gunGaf2 = gafAsset.createObjectAndRun(false);
            gafObject.stop();
            gafObject.setPosition(targetPos);
            self._strikeAnimNode.addChild(gafObject);

            runStrikeAnim();
        });
    },

    // tripleKill 踢球動畫
    // winDir 贏家方位 loseDir 輸家方位
    _showShootFootballAnim: function (winDir, loseDir) {
        // 創個node包起來
        var animNode = this._shootFootballAnimNode = new cc.Node();
        this.addChild(animNode);

        // 取踢球的位置跟目標座標
        var shotPos = CapsaSusun_GameUtility.getCardStacksMidPos(winDir);
        var targetPos = CapsaSusun_GameUtility.getCardStacksMidPos(loseDir);

        // 足球gaf
        gaf.create("gaf/game/capsaSusun_football.gaf", this, false, function (gafAsset) {
            gafAsset.setRootTimelineWithName("act02");
            var gafObject = gafAsset.createObjectAndRun(false);
            gafObject.setPosition(shotPos);
            animNode.addChild(gafObject);

            gafObject.runAction(cc.spawn(
                cc.moveTo(0.5, targetPos),
                cc.rotateTo(0.5, 0)
            ));
        });

        // 撥音效
        MusicUtility.playEffect("Music/Effect/Domino/capsaSusun_explode.mp3");

        // 等動畫結束, 執行callBack
        this.runAction(cc.sequence(
            cc.delayTime(4),
            cc.callFunc(() => {
                if (this._shootFootballAnimNode) {
                    this._shootFootballAnimNode.removeFromParent();
                    this._shootFootballAnimNode = undefined;
                }
            }, this)
        ));
    },

    // tripleKill 全屏動畫
    _showHomeRunFullScreenAnim: function () {
        var animNode = new cc.Node();
        this.addChild(animNode);

        // 背景Node 負責做動畫的
        var bgAnimNode = new cc.Node();
        bgAnimNode.setPosition(JSVisibleSize.width - 240, JSScreenMidPos.y);
        animNode.addChild(bgAnimNode);

        // 背景
        var bgSp = new cc.Sprite("#capsaSusun_pic_red_01.png");
        bgSp.setScale(4.3, 19);
        bgAnimNode.addChild(bgSp);

        // 上下的金線
        for (var i = 0; i < 2; i++) {
            var goldSp = new cc.Sprite("#lobby_pic_gold.png");
            goldSp.setPosition(0, 36 - (72 * i));
            goldSp.setScale(1.5);
            bgAnimNode.addChild(goldSp);
        }

        // 紅色的斜條
        var posArray = [cc.p(150, 15), cc.p(20, -20), cc.p(-120, 0), cc.p(-150, 10)];
        var scale = [0.65, 0.5, 0.5, 0.7];
        posArray.forEach((cur, idx) => {
            var redSp = new cc.Sprite("#capsaSusun_pic_red_02.png");
            redSp.setPosition(cur);
            redSp.setScale(scale[idx]);
            bgAnimNode.addChild(redSp);
        });

        // 動畫
        bgAnimNode.runAction(cc.sequence(
            cc.moveTo(0.5, JSScreenMidPos.x, JSScreenMidPos.y),
            cc.delayTime(2),
            cc.fadeOut(0.2),
            cc.removeSelf()
        ));

        // triple kill 文字圖
        var wordSp = new cc.Sprite("#capsaSusun_word_homerun.png");
        wordSp.setPosition(JSVisibleSize.width + 240, JSScreenMidPos.y);
        animNode.addChild(wordSp);
        wordSp.runAction(cc.sequence(
            cc.delayTime(0.5),
            cc.moveTo(0.5, JSScreenMidPos.x, JSScreenMidPos.y),
            cc.delayTime(1.5),
            cc.fadeOut(0.2),
            cc.removeSelf()
        ));

        // 足球
        gaf.create("gaf/game/capsaSusun_football.gaf", this, true, function (gafAsset) {
            gafAsset.setRootTimelineWithName("act01");
            var gafObject = gafAsset.createObjectAndRun(true);
            animNode.addChild(gafObject);
            gafObject.setPosition(-50, JSScreenMidPos.y);
            gafObject.runAction(cc.sequence(
                cc.delayTime(1.2),
                cc.moveTo(1, JSVisibleSize.width + 50, JSScreenMidPos.y),
                cc.removeSelf()
            ));
        });

        // 撥音效
        MusicUtility.playEffect("Music/Effect/Domino/capsaSusun_tripleKill.mp3");
    },

    // tripleKill 全壘打動畫
    // homeRunInfo:{"winServerDir":"勝者", "loseServerDirArray":["被打的"],"total":["全部人的被打後的分數"]};
    // skipFullAnim:跳過全屏動畫
    showHomeRunAnimation: function (homeRunInfo, skipFullAnim) {
        var self = this;
        var shootBallFunc = function (info) {
            // 迴圈顯示
            var winServerDir = info.winServerDir;
            var loseDirArray = info.loseServerDirArray;
            for (var n = 0; n < loseDirArray.length; n++) {
                var loseServerDir = loseDirArray[n];

                var winDir = DataModal.gameData.getDirectionByServerDirection(winServerDir);
                var loseDir = DataModal.gameData.getDirectionByServerDirection(loseServerDir);
                // 動畫
                self._showShootFootballAnim(winDir, loseDir);
            }
        };
        // 是否要跳過全屏動畫
        if (skipFullAnim) {
            shootBallFunc(homeRunInfo);
        } else {
            this._showHomeRunFullScreenAnim();
            this.runAction(cc.sequence(
                cc.delayTime(2.5),
                cc.callFunc(() => shootBallFunc(homeRunInfo))
            ));
        }
    },

    /**
     * 創金錢的圖片Node
     */
    _createChipNumberNode: function (value) {
        var autoLayout = new GSAutoLayoutNode();
        autoLayout.setSpace(-7);
        autoLayout.setScale(0.8);

        // 先加個加號
        var plusSprite = new cc.Sprite("#game_number_+.png");
        autoLayout.addChild(plusSprite);

        // 處理數字
        var numberString = TexasUtility.getSimpleMoneyString(value);
        for (var i = 0, len = numberString.length; i < len; i++) {
            var numberChar = numberString[i];
            if (isNaN(numberChar)) {
                // 不是數字 要判斷是不是小數點
                if (numberChar === ".") {
                    var dotSprite = new cc.Sprite("#game_number_point.png");
                    autoLayout.addChild(dotSprite);
                } else {
                    // 代表是最後的文字
                    var wordString = numberString.substr(i, len - i);
                    var wordSprite = new cc.Sprite(JSStringUtility.format("#game_number_%s.png", wordString));
                    autoLayout.addChild(wordSprite);
                    break;
                }
            } else {
                // 數字 直接創
                var numberSprite = new cc.Sprite(JSStringUtility.format("#game_number_%s.png", numberChar));
                autoLayout.addChild(numberSprite);
            }
        }

        return autoLayout;
    },

    /**
     * 顯示飛金錢的動畫
     * loseDirs:輸家Array , winDirs:贏家 , winChips:贏多少錢
     */
    showCoinAsync: function (loseArray, winArray, moneyArray) {
        return new Promise(resolve => {
            if (!loseArray.length || !winArray.length)
                resolve();

            var winLen = winArray.length;

            // 先轉成正確位置
            winArray.forEach((curWin, idx) => {
                var winMoney = moneyArray[curWin];
                var toDir = DataModal.gameData.getDirectionByServerDirection(curWin);
                var toPos = CapsaSusun_GameUtility.getPlayerPosition(toDir);

                loseArray.forEach((baseDir, dirIndex) => {

                    var playerSit = DataModal.gameData.getDirectionByServerDirection(baseDir);

                    var startPos = CapsaSusun_GameUtility.getPlayerPosition(playerSit);

                    // 算出目標離開始是在哪一個地方
                    var offsetX = toPos.x - startPos.x;
                    var midPos = cc.p((startPos.x + toPos.x) / 2, (startPos.y + toPos.y) / 2);
                    var offsetRatio = 20;

                    var bezierConfig = [startPos, cc.pAdd(midPos, cc.p(offsetX < 0 ? offsetRatio : -offsetRatio, offsetRatio)), toPos];
                    var coinCount = 10;
                    var moveTime = 0.7;
                    var moveAction = (index) => {
                        var coinSprite = new cc.Sprite("#game_pic_chip_01.png");
                        coinSprite.setRotation(JSCodeUtility.getRandomInt(0, 360));
                        coinSprite.setOpacity(0);
                        coinSprite.setScale(0.3);
                        coinSprite.setPosition(startPos);
                        coinSprite.setVisible(false);
                        this.addChild(coinSprite);

                        // 先做旋轉的動畫
                        var rotateAction = cc.repeatForever(cc.rotateBy(0.1, 45));
                        coinSprite.runAction(rotateAction);

                        // 移動的動畫
                        coinSprite.runAction(cc.sequence(
                            cc.delayTime(index * 0.1),
                            cc.show(),
                            cc.spawn(
                                cc.fadeIn(moveTime * 0.5),
                                cc.scaleTo(moveTime, 0.6),
                                cc.bezierTo(moveTime, bezierConfig).easing(cc.easeIn(1.4))
                            ),
                            cc.callFunc(function () {
                                // 把他換圖 閃一下
                                coinSprite.setSpriteFrame("game_pic_chip_01.png");
                                coinSprite.setScale(1.3);
                                coinSprite.setRotation(0);
                                coinSprite.stopAction(rotateAction);

                                var isFinal = idx === winLen - 1;

                                if (index === 0 && winMoney) {
                                    if (isFinal) {
                                        // 輸錢 需要跳顯示
                                        var money = TexasUtility.getSimpleMoneyString(moneyArray[baseDir]);
                                        var moneyLabel = new cc.LabelTTF(money, JSFontBoldName, 12);
                                        moneyLabel.setOpacity(0);
                                        moneyLabel.enableStroke(JSColor.GRAY, 3);
                                        moneyLabel.setPosition(startPos.x, startPos.y - 5);
                                        this.addChild(moneyLabel, 1);
                                        moneyLabel.runAction(cc.moveBy(1, cc.p(0, 10)));
                                        moneyLabel.runAction(cc.sequence(
                                            cc.fadeIn(0.2),
                                            cc.delayTime(0.6),
                                            cc.fadeOut(0.2),
                                            cc.removeSelf()
                                        ));
                                    }

                                    if (dirIndex === 0) {
                                        // 有錢 需要跳顯示
                                        var winMoneyNode = this._createChipNumberNode(winMoney);
                                        winMoneyNode.setPosition(toPos.x, toPos.y - 5);
                                        this.addChild(winMoneyNode, 1);

                                        if (isFinal) {
                                            // 是結算 要有winner動畫
                                            winMoneyNode.runAction(cc.sequence(
                                                cc.moveBy(0.9, cc.p(0, 10)),
                                                cc.callFunc(function () {
                                                    // Player上面出現Winner
                                                    GS.dispatchCustomEvent("NotifyPlayerShowWinAnimation", winArray);
                                                }, this),
                                                cc.delayTime(0.5),
                                                cc.removeSelf()
                                            ));
                                        } else {
                                            // 一般的顯示
                                            winMoneyNode.runAction(cc.sequence(
                                                cc.moveBy(0.9, cc.p(0, 15)),
                                                cc.removeSelf()
                                            ));
                                        }

                                        // 通知要更新金錢
                                        GS.dispatchCustomEvent("NotifyUpdatePlayerMoney");
                                    }
                                }

                                if (index === coinCount - 1) {
                                    // 完成了
                                    resolve();
                                }
                            }, this),
                            cc.delayTime(0.04),
                            cc.removeSelf()
                        ));
                    };
                    for (var i = 0; i < coinCount; i++) {
                        moveAction(i);
                    }
                });

                // 給錢音效
                MusicUtility.playEffect("Music/Effect/pass_money.mp3");
            });
        });
    },
});

