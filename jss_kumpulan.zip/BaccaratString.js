var LocalizedString = LocalizedString || {};

(function () {
    var keyValue = {
        "本區下注金額上限為": "Bet Tertinggi ",
        "總下注金額上限為": "Total Bet Tertinggi ",
        "重複下注的金額不足": "Chip tidak cukup",
        "超過上限": "Melebih batas",
    };

    LocalizedString.Baccarat = function (str) {
        return USE_i18n ? (keyValue[str] || str) : str;
    };
})();
