/**
 * Bonus機台 下注選項頁面
 */
var BonusRaiseLayer = cc.Layer.extend({
    initProperties: function (betMenuItem) {
        this._betMenuItem = betMenuItem;
        this._nowMoney = 0;                 // 目前所選到的金額
        this._minBet = 0;                   // 最低加注
        this._maxBet = 0;                   // 最高加注
        this._raisePlusArray = [0, 0, 0];   // 左邊三個按鈕加注金額
        this._ignoreValueChanged = false;   // 是否忽略計算
    },

    ctor: function () {
        this._super();
        this.initProperties();

        // 左方按鈕
        var bgPos = cc.p(344, 95);
        var raiseBtnBg = this._raiseBtnBg = new ccui.Scale9Sprite("bg_slim.png");
        raiseBtnBg.setPreferredSize(cc.size(65, 116));
        raiseBtnBg.setPosition(bgPos);
        this.addChild(raiseBtnBg);

        // Menu
        var menu = this._mainMenu = new cc.Menu();
        menu.setPosition(0, 0);
        this.addChild(menu);

        // 左方按鈕背景光
        var raiseBtnLightSp = new cc.Sprite("#bg_light.png");
        raiseBtnLightSp.setScale(2, 2.6);
        raiseBtnLightSp.setPosition(bgPos);
        raiseBtnLightSp.setOpacity(200);
        this.addChild(raiseBtnLightSp);

        // 左方按鈕背景線
        for (var i = 0; i < 3; i++) {
            var btnLineSp = new cc.Sprite("#btn_function_line.png");
            btnLineSp.setRotation(90);
            btnLineSp.setScaleY(1.5);
            btnLineSp.setPosition(bgPos.x, bgPos.y + ((i - 1) * 29));
            this.addChild(btnLineSp);
        }

        // 左方四個加注按鈕
        this._raiseBtns = [
            LocalizedString.Bonus("最大"),
            "",
            "",
            ""
        ].map((cur, idx) => {
            var itemNode = [];

            for (var i = 0; i < 3; i++) {
                var node = itemNode[i] = new ccui.Scale9Sprite();
                node.setCascadeColorEnabled(true);
                node.setCascadeOpacityEnabled(true);

                // 文字
                var titleLabel = node.label = new cc.LabelTTF(cur, JSFontBoldName, 10);
                var contentSize = cc.size(40, 25);
                var midPos = cc.p(contentSize.width / 2, contentSize.height / 2);
                titleLabel.setPosition(midPos);
                node.addChild(titleLabel);

                node.setPreferredSize(contentSize);
                node.setContentSize(contentSize);

                if (i === 1)
                    node.setColor(JSColor.GRAY);
            }

            var btn = new cc.MenuItemSprite(itemNode[0], itemNode[1], itemNode[2], this._raiseBtnClicked, this);
            btn.setTag(idx);
            btn.setPosition(bgPos.x - 6, bgPos.y + 43.5 - (idx * 29));
            menu.addChild(btn);

            return btn;
        });

        // 加注Bar背景
        var barBgPos = cc.p(402, 140);
        var raiseBarBg = this._raiseBarBg = new ccui.Scale9Sprite("bg_slim.png");
        raiseBarBg.setPreferredSize(cc.size(88, 240));
        raiseBarBg.setPosition(barBgPos);
        this.addChild(raiseBarBg);

        // 加注Bar背景光
        raiseBtnLightSp = new cc.Sprite("#bg_light.png");
        raiseBtnLightSp.setScale(2.6, 6);
        raiseBtnLightSp.setPosition(barBgPos);
        raiseBtnLightSp.setOpacity(200);
        this.addChild(raiseBtnLightSp);

        // 加注Bar背景線
        var btnLineSp = new cc.Sprite("#btn_function_line.png");
        btnLineSp.setRotation(90);
        btnLineSp.setScaleY(2.2);
        btnLineSp.setPosition(barBgPos.x, barBgPos.y + 90);
        this.addChild(btnLineSp);

        // 加注金額
        var nowMoney = this._nowMoneyLabel = new cc.LabelTTF("1,000", JSFontBoldName, 14);
        nowMoney.setFontFillColor(JSColor.YELLOW);
        nowMoney.setPosition(barBgPos.x, barBgPos.y + 104);
        this.addChild(nowMoney);

        // 金錢Slider
        var moneySlider = this._moneySlider = new cc.ControlSlider("#bonus_up_bar_bg_02.png", "#bonus_up_bar.png", "#bonus_sliderimage.png");
        moneySlider.addTargetWithActionForControlEvents(this, this._raiseSliderValueChanged, cc.CONTROL_EVENT_VALUECHANGED);
        moneySlider.setMinimumValue(-0.1);
        moneySlider.setMinimumAllowedValue(0);
        moneySlider.setMaximumValue(1.1);
        moneySlider.setMaximumAllowedValue(1);
        moneySlider.setPosition(barBgPos.x, barBgPos.y - 10);
        moneySlider.setRotation(-90);
        this.addChild(moneySlider);

        // 加Touch監聽是否有點到
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: false,
            onTouchBegan: this._onTouchBegan.bind(this),
            onTouchEnded: this._onTouchEnded.bind(this),
            onTouchCancelled: this._onTouchEnded.bind(this)
        }, this);
    },

    /**
     * 轉換加注金額文字
     * @param   {Number}  value 加注金額數值
     * @return  {String} 金錢轉換後的文字
     */
    _convertMoneyStr: function (value) {
        return TexasUtility.getSimpleMoneyString(value, 1);
    },

    /**
     * 加注時金錢文字強調動畫
     */
    _moneyLabelScaleAnimation: function () {
        this._nowMoneyLabel.stopAllActions();
        this._nowMoneyLabel.runAction(cc.sequence(cc.scaleTo(0, 1.4), cc.scaleTo(0.15, 1)));
    },

    /**
     * 更新Slider數值
     * @param   {Number} betValue 加注金額
     */
    _updateSliderValue: function (betValue) {
        this._nowMoney += betValue;

        // 同步MixMJ Texas_GameRaiseNode
        // 更新Slider前要先設定不在slider change value時算金錢 上面算好了
        this._ignoreValueChanged = true;

        if (this._nowMoney > this._maxBet) {
            this._nowMoney = this._maxBet;
            this._moneySlider.setValue(1);
        } else {
            var value = (this._nowMoney - this._minBet) / (this._maxBet - this._minBet);
            this._moneySlider.setValue(value);
            this._moneyLabelScaleAnimation();
        }

        this._ignoreValueChanged = false;
    },

    /**
     * 點擊左方加注按鈕
     */
    _raiseBtnClicked: function (sender) {
        if (sender) {
            switch (sender.getTag()) {
                // All in按鈕
                case 0:
                    var oldMoney = this._nowMoney;
                    this._moneySlider.setValue(1);
                    if (this._nowMoney > oldMoney)
                        this._moneyLabelScaleAnimation();
                    break;
                // 第一個加注按鈕
                case 1:
                    this._updateSliderValue(this._raisePlusArray[0]);
                    break;
                // 第二個加注按鈕
                case 2:
                    this._updateSliderValue(this._raisePlusArray[1]);
                    break;
                // 第三個加注按鈕
                case 3:
                    this._updateSliderValue(this._raisePlusArray[2]);
                    break;
                default:
                    break;
            }
        }
    },

    /**
     * Slider滑動時金額處理
     */
    _raiseSliderValueChanged: function () {
        var value = this._moneySlider.getValue();

        // 假如沒有乎略 在進去算
        if (!this._ignoreValueChanged) {
            if (value === 0)
                this._nowMoney = this._minBet;
            else if (value === 1)
                this._nowMoney = this._maxBet;
            else {
                // 同步MixMJ Texas_GameRaiseNode
                // 這邊要把數字用好看一點 所以要處理一下
                var bigBlind = this._minBet;    // 這邊沒有大盲改抓最小注額
                var tempMoney = this._minBet + (this._maxBet - this._minBet) * value;
                var rateNum = Math.round(tempMoney / bigBlind);
                this._nowMoney = bigBlind * rateNum;
                if (this._nowMoney > this._maxBet)
                    this._nowMoney = this._maxBet;
            }
        }

        // 轉成最小注的倍數
        this._nowMoney = Math.ceil(this._nowMoney);
        this._refreshMoneyLabel();
    },

    /**
     * 更新目前加注金額文字
     */
    _refreshMoneyLabel: function () {
        var str = this._convertMoneyStr(this._nowMoney);
        this._nowMoneyLabel.setString(str);
    },

    /**
     * 回傳目前所選金額
     * @return {Number} 目前所選金額
     */
    getBetMoney: function () {
        return this._nowMoney;
    },

    /**
     * 設定下注的上限及下限
     * @param {Number}  maxBet  上限
     * @param {Number}  minBet  下限
     */
    setPnNumber: function (maxBet = 0, minBet = 0) {
        this._maxBet = maxBet;
        this._minBet = this._nowMoney = minBet;
        this._refreshMoneyLabel();

        this._raisePlusArray = [minBet * 10, minBet * 5, minBet];
        this._raiseBtns.slice(1, 4).forEach((btn, idx) => {
            var value = this._raisePlusArray[idx];
            var string = "+".concat(this._convertMoneyStr(value));

            btn.getChildren().forEach(cur => cur.label && cur.label.setString(string));
        });
    },

    /**
     * 重設下注金額
     */
    resetRaiseLayer: function () {
        this._moneySlider.setValue(0);
    },

    /**
     * 顯示RaiseLayer
     */
    show: function () {
        this.resetRaiseLayer();
        this.setPnNumber(this._maxBet, this._minBet);
        this.setVisible(true);
    },

    /**
     * 隱藏RaiseLayer
     */
    hide: function () {
        this.setVisible(false);
    },

    /**
     * 觸碰事件
     */

    _onTouchBegan: function (touch, event) {
        var target = event.getCurrentTarget();
        for (var c = target.parent; c != null; c = c.parent) {
            if (!c.isVisible())
                return false;
        }
        return this.isVisible();
    },

    _onTouchEnded: function (touch, event) {
        if (!this._betMenuItem)
            return;

        var touchPos = this.convertToNodeSpace(touch.getLocation());
        var raiseBarBoundBox = this._raiseBarBg.getBoundingBox();
        var raiseBtnBoundBox = this._raiseBtnBg.getBoundingBox();

        // 額外加上下注按鈕區域
        var betMenuItemRect = this._betMenuItem.getBoundingBox();
        var origin = this._betMenuItem.convertToWorldSpace(cc.p(0, 0));
        betMenuItemRect.x = origin.x;
        betMenuItemRect.y = origin.y;

        // 如果沒點擊到UI區域，就關閉RaiseLayer
        if (!cc.rectContainsPoint(raiseBarBoundBox, touchPos) && !cc.rectContainsPoint(raiseBtnBoundBox, touchPos) && !cc.rectContainsPoint(betMenuItemRect, touchPos)) {
            this.hide();
            GS.dispatchCustomEvent("NotifyBonusRaiseLayerHide");
        }
    }
});
