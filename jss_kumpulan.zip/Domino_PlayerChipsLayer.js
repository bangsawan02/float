/**
 * 用來丟籌碼 & 贏牌後堆疊發籌碼的地方
 */
var Domino_PlayerChipsLayer = cc.Layer.extend({
    // 設定有哪些金額的籌碼 從大到小
    PLAYER_CHIPS_POT_SETTING: [10000000, 1000000, 100000, 10000, 1000, 100],

    ctor: function () {
        this._super();

        // 池裡所有的籌碼 把他跟對應到的金額都放一次Array
        this._potChipsArray = {};
        for (var i = 0, len = this.PLAYER_CHIPS_POT_SETTING.length; i < len; i++) {
            this._potChipsArray[this.PLAYER_CHIPS_POT_SETTING[i]] = [];
        }

        // 池裡的總金額
        this._totalPot = 0;

        // 所有的籌碼Node
        var allChipNode = this._allChipNode = new cc.Node();
        allChipNode.setCascadeOpacityEnabled(true);
        this.addChild(allChipNode);

        // 彩池的籌碼數字
        var potNumberNode = this._potNumberNode = new Domino_PlayerChipsPotNumberNode();
        potNumberNode.setPosition(JSScreenMidPos.x, 184 + JSScreenBonusHalfHeight);
        this.addChild(potNumberNode);
    },

    cleanData: function () {
        for (var key in this._potChipsArray) {
            // 把Array清掉
            this._potChipsArray[key].length = 0;
        }
        this._totalPot = 0;

        this._allChipNode.removeAllChildren();
        this._potNumberNode.cleanData();
    },

    /**
     * 送籌碼到彩池
     */
    sendChipsToPot: function (serverPos, money, noAnimation) {
        noAnimation = !!noAnimation;

        var playerPos = DataModal.gameData.getDirectionByServerDirection(serverPos);

        // 先把Pot加上金額
        this._potNumberNode.addMoney(money);

        // 算出起始點
        var startPos = Domino_GameUtility.getPlayerPosition(playerPos);
        var lastMoney = money;

        // 開始算要丟哪些籌碼
        for (var i = 0, len = this.PLAYER_CHIPS_POT_SETTING.length; i < len; i++) {
            var thisChipMoney = this.PLAYER_CHIPS_POT_SETTING[i];
            var count = lastMoney / thisChipMoney;

            // 創籌碼 x要從1開始 因為JS除完會有小數點 0.xxx 要不算
            for (var x = 1; x <= count; x++) {
                var toPos = cc.p(JSScreenMidPos.x + JSCodeUtility.getRandomInt(-60, 60), 152 + JSCodeUtility.getRandomInt(-20, 20) + JSScreenBonusHalfHeight);

                // 創出籌碼
                var chipNode = new Domino_PlayerChipNode(thisChipMoney);
                chipNode.setRotation(JSCodeUtility.getRandomInt(-20, 20));
                chipNode.setPosition(startPos);
                this._allChipNode.addChild(chipNode);

                // 把他放到正確的Array裡
                this._potChipsArray[thisChipMoney].push(chipNode);

                if (noAnimation) {
                    // 直接到定位
                    chipNode.setPosition(toPos);
                } else {
                    // 貝茲曲線
                    var moveTime = 0.6;
                    var bezierConfig = [startPos, cc.pAdd(startPos, cc.p(20, 20)), toPos];
                    chipNode.runAction(cc.bezierTo(moveTime, bezierConfig).easing(cc.easeOut(1.5)));
                }
            }

            // 最後更新剩下的籌碼
            lastMoney %= thisChipMoney;
        }

        // 撥放音效
        MusicUtility.playEffect("Music/Effect/chipone.mp3");
    },

    /**
     * 結算要把金錢送到玩家手上
     * @param isLast 代表是否把剩下最後的籌碼都給他 因為分池算法有抽趴 不一定會完整剛好的拿走籌碼
     */
    sendPotChipsToPlayer: function (serverPos, money, isLast, callback) {
        var playerPos = DataModal.gameData.getDirectionByServerDirection(serverPos);
        var endPos = Domino_GameUtility.getPlayerPosition(playerPos);

        var moveTime = 0.6;
        var sendFunc = function (chipNode) {
            // 移動
            chipNode.runAction(cc.moveTo(moveTime, endPos).easing(cc.easeOut(1.5)));

            // 淡出
            chipNode.runAction(cc.sequence(
                cc.delayTime(moveTime - 0.1),
                cc.fadeOut(0.15),
                cc.removeSelf()
            ));
        };

        if (isLast) {
            // 最後了 直接把所有籌碼丟過去
            for (var key in this._potChipsArray) {
                // 把Array剩下的都給他
                this._potChipsArray[key].forEach(cur => sendFunc(cur));

                // 清掉
                this._potChipsArray[key].length = 0;
            }

            // 把Pot的金額清光
            this._potNumberNode.setNowMoney(0);
        } else {
            // 開始算要丟哪些籌碼
            var lastMoney = money;
            for (var i = 0, len = this.PLAYER_CHIPS_POT_SETTING.length; i < len; i++) {
                var thisChipMoney = this.PLAYER_CHIPS_POT_SETTING[i];
                var count = lastMoney / thisChipMoney;

                // 最後更新剩下的籌碼
                lastMoney %= thisChipMoney;

                // 找出裡面的籌碼 x要從1開始 因為JS除完會有小數點 0.xxx 要不算
                for (var x = 1; x <= count; x++) {
                    // 找出籌碼
                    var chipsArray = this._potChipsArray[thisChipMoney];
                    if (chipsArray.length) {
                        // 確定有圖片在送
                        var chipNode = this._potChipsArray[thisChipMoney].pop();
                        sendFunc(chipNode);
                    } else {
                        // 沒圖片 代表大籌碼被拿光了 要把現在的金額加上去 讓他拿低籌碼的
                        lastMoney += thisChipMoney;
                    }
                }
            }
        }

        // 用來callback用
        this.runAction(cc.sequence(
            cc.delayTime(moveTime),
            cc.callFunc(callback)
        ));

        // 撥放音效
        MusicUtility.playEffect("Music/Effect/chipone.mp3");
    },

    /**
     *  pot x x x x x x x 各彩池的金額 (共7個)
     */
    setPot: function (value) {
        var total = 0;
        var valueArray = value.split(" ");
        for (var i = 0, len = valueArray.length; i < len; i++) {

            var potChip = JSCodeUtility.getIntValue(valueArray[i]);
            total += potChip;
        }

        this._totalPot = total;

        // 判斷現在的錢是不是跟this._potNumberNode 一樣 不一樣的話 代表是要偷補籌碼在池裡
        if (this._potNumberNode.totalMoney != this._totalPot) {
            // 算出差多少錢
            var different = this._totalPot - this._potNumberNode.totalMoney;
            if (different > 0) {
                // 只做>0的就好 負的先不理
                this.sendChipsToPot(0, different, true);
            }

            // 強制更新一次Pot的金額 防呆用
            this._potNumberNode.setNowMoney(total);
        }
    },

    /**
     * 送底注
     */
    cmd_ante: function (value) {
        // ante pos 底注金額
        var valueArray = value.split(" ");
        this.sendChipsToPot(parseInt(valueArray[0]), parseInt(valueArray[1]));
    },

    /**
     * 送小費玩家丟錢給荷官，錢的動畫
     * sendTips SeverSitNum 金額 荷官的話
     */
    cmd_sendTips: function (jsonValue) {
        var array = jsonValue.split(" ");
        var sitNum = DataModal.gameData.getDirectionByServerDirection(JSCodeUtility.getIntValue(array[0]));
        var money = JSCodeUtility.getIntValue(array[1]);
        var from = Domino_GameUtility.getPlayerPosition(sitNum);

        var chip = new Domino_PlayerChipNode(money);
        chip.setPosition(from);
        this.addChild(chip);

        //錢幣飛到荷官 (pot指令)
        var toPos = cc.p(JSScreenMidPos.x, 234 + JSScreenBonusHalfHeight);
        chip.runAction(cc.sequence(
            cc.moveTo(0.5, toPos).easing(cc.easeOut(0.5)),
            cc.fadeOut(0.3),
            cc.removeSelf()
        ));
    },

    /**
     * 遊戲結束
     */
    cmd_stopGame: function () {
        this.cleanData();
    },
});