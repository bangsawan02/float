/**
 * 9T 每日任務左下角的VIP資訊
 */

var DailyMissionVIPBonusNode = cc.Node.extend({
    ctor: function () {
        this._super();

        // 先更新一次畫面
        this._refreshView();

        // 註冊
        GS.addListener("NotifyVipInfoDone", this.notifyVipInfoDone.bind(this), this);
    },

    /**
     * 點擊說明按鈕
     */
    _explainBtnClicked: function () {
        // 要跳Dialog
        DialogManager.addDialog(new DailyMissionVIPBonusDialog(), false);
    },

    /**
     * 更新畫面
     */
    _refreshView: function () {
        // 先把畫面全砍光
        this.removeAllChildren();

        // 判斷是否有東西
        var vipInfo = DataModal.vipData.vipInfo;
        if (vipInfo)
            var param = vipInfo["vip_dailyMission_discount_info"];

        if (!param || (param.nowVip === -1 || param.nowBonus === -1)) {
            this.setVisible(false);
            return;
        }
        this.setVisible(true);

        // parse掉多餘的東西
        var vipLevel = param.nowVip;
        var vipBonusArray = [
            param.preVip === 0 ? undefined : {level: param.preVip, bonus: param.preBonus},
            {level: param.nowVip, bonus: param.nowBonus},
            param.nextVip === 0 ? undefined : {level: param.nextVip, bonus: param.nextBonus}
        ].filter(obj => !!obj);

        // 創畫面 先算出位置
        var paddingX = 38;
        var bonusNodes = vipBonusArray.map(cur => {
            var isCurrentLevel = cur.level === vipLevel;
            var bonusNode = new cc.Node();
            bonusNode.setCascadeColorEnabled(true);

            // 背景 假如是nowVip背景色要不一樣
            var bgSprite = new cc.Sprite(isCurrentLevel
                ? "#vip_process_bg_2.png"
                : cur.level < vipLevel ? "#vip_process_bg_1.png" : "#vip_process_bg_3.png");
            bonusNode.addChild(bgSprite);

            if (isCurrentLevel) {
                bgSprite = new cc.Sprite("#vip_process_bg_4.png");
                bonusNode.addChild(bgSprite);
            }

            // 文字
            var bonusLabel = new cc.LabelTTF(JSStringUtility.format("VIP %s\n+%s%%", cur.level, cur.bonus), JSFontBoldName, 8, cc.size(0, 0), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
            bonusLabel.setFontFillColor(JSColor.BLACK);
            bonusNode.addChild(bonusLabel);

            // 回傳此Node
            return bonusNode;
        });

        // Bonus畫面
        var nowPosX = 0;
        bonusNodes.forEach(bonusNode => {
            bonusNode.setPosition(nowPosX, 13);
            this.addChild(bonusNode);

            nowPosX += paddingX;
        });

        // 問號按鈕
        var explainBtn = new Texas_ExplainButton();
        explainBtn.setPosition(nowPosX - paddingX / 2 + 2, 24);
        explainBtn.addTouchUpInsideAction(this._explainBtnClicked, this);
        this.addChild(explainBtn, 1);

        this.setContentSize(cc.size(nowPosX, 26));
    },

    /**
     * 通知
     */
    // VIP資訊完成
    notifyVipInfoDone: function () {
        this._refreshView();
    },
});