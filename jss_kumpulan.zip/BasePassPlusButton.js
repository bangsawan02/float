/**
 * 通行證 - 增加代幣按鈕
 * config: {
 *     plusBtnBgFileName: "",       // 背景圖
 *     plusBtnWordFileName: "",     // 字圖
 * }
 */
var BasePassPlusButton = GSControlButton.extend({
    ctor: function (config) {
        let contentNode = new cc.Node();
        let bgFileName = config.plusBtnBgFileName || "luxyPass_btn_02_1.png";
        let plusIconFileName = config.plusBtnWordFileName || "luxyPass_bt_+.png";

        let bgSprite = new ccui.Scale9Sprite(bgFileName);
        contentNode.addChild(bgSprite);

        let wordSprite = new cc.Sprite("#" + plusIconFileName);
        contentNode.addChild(wordSprite);

        this._super(contentNode, bgSprite.getContentSize());
    },
});