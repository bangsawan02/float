/**
 * 5.4.3 每日任務優化 - 大廳Icon
 *
 * created by Jim.Chen
 */

var DailyMissionLobbyIconNode = LobbyIconScrollItemButton.extend({
    /**
     * @param whereType 在哪個地方(可參照DailyMissionLobbyIconNode.WhereType)
     */
    ctor: function (whereType) {
        this._isInSlot = whereType === DailyMissionLobbyIconNode.WhereType.Slot;

        this._super(!this._isInSlot ? cc.size(28, 28) : cc.size(50, 50));

        this.key = "DailyMissionLobbyIconNode";

        this._isInSlot && this._button.setChangeColorWhenDisabled(false);

        // 註冊
        GS.addListener("NotifyUpdateDailyMission", this.notifyUpdateDailyMission.bind(this), this);
        // 機台內監聽
        if (this._isInSlot) {
            GS.addListener("NotifyOnClickSpin", this.notifyOnClickSpin.bind(this), this);
            GS.addListener("NotifySlotOnSpinEnd", this.notifySlotOnSpinEnd.bind(this), this);
        }
    },

    onEnter: function () {
        this._super();

        // 去要資料
        DataModal.dailyMissionData.startGetInfo();
    },

    /**
     * 更新畫面
     */
    _refreshView: function () {
        // 先清掉所有東西
        var mainNode = this._mainNode;
        mainNode.removeAllChildren();
        this._badgeNode = undefined;

        var dailyMissionData = DataModal.dailyMissionData;

        this.setVisible(true);

        // 在機台側邊欄
        if (this._isInSlot) {
            // 按鈕icon
            var iconSp = new cc.Sprite("#lobby_icon_daily_mission.png");
            this._button.enableTouchCancel(cc.SCROLLVIEW_DIRECTION_VERTICAL);
            mainNode.addChild(iconSp);

            // 紅點
            if (dailyMissionData.getHaveReward()) {
                var badgeNode = this._badgeNode = new BadgeNode();
                badgeNode.useDefaultStyle();
                badgeNode.setName("badge");
                badgeNode.setPosition(cc.p(16, 15));
                mainNode.addChild(badgeNode);

                // 通知側邊欄顯示小紅點
                GS.dispatchCustomEvent("NotifyShowVegasSideBadge", {
                    type: SideOptionShowType.MAIN,
                    isShowBadge: false
                });
            }
        } else {
            // 在娛樂城大廳
            // 按鈕icon
            var iconSp = new cc.Sprite("#lobby_icon_daily_mission.png");
            mainNode.addChild(iconSp);

            // 紅點
            if (dailyMissionData.getHaveReward()) {
                var badgeNode = this._badgeNode = new BadgeNode();
                badgeNode.useDefaultStyle();
                badgeNode.setVisible(true);
                badgeNode.setPosition(cc.p(15, 15));
                mainNode.addChild(badgeNode);
            }
        }
    },

    /**
     * 按鈕
     */
    _iconClicked: function (sender) {
        // 跳每日任務視窗
        if (this._isInSlot) {
            if (JSIsPortrait) {
                // 直式直接顯示提示前往大廳查看
                GS.dispatchCustomEvent("NotifyShowVegasSideOptionRemind", {
                    type: VegasSideOptionMessageType.DAILY_MISSION,
                    msg: "#!000000!#" + LocalizedString.Vegas("可至大廳右下方free chips 查看")
                });
            } else
                DialogManager.addDialog(new ActionListDialog(0, DailyMissionEnum.whereType.Slot));

            // 埋點
            sender && DataProcess.sendString("track_daily_mission 5");
        } else {
            // 埋點 5089：>=5.6.8 點擊副系統區塊任一ICON
            TexasUtility.sendUserAnalyticsTrack(5089);

            // 埋點 5091：>=5.6.8 點擊每日任務
            TexasUtility.sendUserAnalyticsTrack(5091);

            // 小紅點點過就消失
            this._badgeNode && this._badgeNode.setVisible(false);

            DialogManager.addDialog(new ActionListDialog(0, DailyMissionEnum.whereType.Vip_Lobby));

            // 埋點
            sender && DataProcess.sendString("track_daily_mission 4");
        }
    },

    /**
     * 通知
     */
    // 通知收到info
    notifyUpdateDailyMission: function (event) {
        this._refreshView();
    },

    // 開始轉就不給按
    notifyOnClickSpin: function () {
        this._button && this._button.setEnabled(false);
    },

    // 停下來就可以按
    notifySlotOnSpinEnd: function () {
        this._button && this._button.setEnabled(true);
    }
});

DailyMissionLobbyIconNode.WhereType = {
    VegasLobby: 0,     // 娛樂城大廳
    Slot: 1            // 機台內
};