/**
 * 牌王說明頁
 */

var CardKingInfoLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // WebView
        var webView = this._webView = new GSWebView();
        webView.setContentSize(JSVisibleSize.width, JSVisibleSize.height - TITLE_BG_HEIGHT);
        webView.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - TITLE_BG_HEIGHT / 2);
        !cc.sys.isNative && webView.setTransparent(true);
        this.addChild(webView);

        // 載入網頁
        var url = TexasUtility.getSimpleInfoURLByKey("crown_king");
        webView.loadURL(url);
        cc.log("CardKingInfoLayer 連到: " + url);
    },

    /**
     * 因為有網頁 setVisible要override掉
     */
    setVisible: function (value) {
        this._webView && this._webView.setVisible(value);

        this._super(value);
    },

    /**
     * 畫面進出
     */
    viewWillDisappear: function () {
        this._webView.setVisible(false);
    },

    viewWillAppear: function () {
        this._webView.setVisible(true);
    },
});