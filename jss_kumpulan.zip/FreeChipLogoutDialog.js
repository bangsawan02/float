/**
 * v5.4.3 離開前顯示獎勵提示
 */

var FreeChipLogoutDialog = BaseDialogLayer.extend({
    ctor: function () {
        this._super();

        this.key = "FreeChipLogoutDialog";

        // 黑色底圖
        this.dialogBgColor = cc.color(0, 0, 0, 200);

        var aniLayer = this._animationLayer;

        // 背景底
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(cc.size(314, 110));
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite);

        // 金幣底圖
        var moneySp = new cc.Sprite("#lobby_pic_money.png");
        moneySp.setAnchorPoint(0.5, 0);
        moneySp.setOpacity(102);
        moneySp.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 50);
        aniLayer.addChild(moneySp);

        // 標題
        var titleSp = new cc.Sprite("#lobby_word_title_logout.png");
        titleSp.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 70);
        aniLayer.addChild(titleSp);

        var label = new cc.LabelTTF(LocalizedString.Common("確定要離開遊戲嗎?"), JSFontName, 14);
        label.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 65);
        aniLayer.addChild(label);

        // 更新內容
        this._refreshView();

        var btnSize = cc.size(78, 25);

        // 離開遊戲按鈕
        var leaveBtn = new ButtonUtility.createSimpleButton("lobby_btn_02.png", btnSize, LocalizedString.Game("離開遊戲"));
        leaveBtn.addTouchUpInsideAction(this._leaveBtnClicked, this);
        leaveBtn.setPosition(JSScreenMidPos.x - 45, JSScreenMidPos.y - 90);
        aniLayer.addChild(leaveBtn, 10);

        // 取消登出按鈕
        var cancelBtn = new ButtonUtility.createSimpleButton("lobby_btn_01.png", btnSize, LocalizedString.Common("不離開"), JSColor.BLACK);
        cancelBtn.addTouchUpInsideAction(this._cancelBtnClicked, this);
        cancelBtn.setPosition(JSScreenMidPos.x + 45, JSScreenMidPos.y - 90);
        aniLayer.addChild(cancelBtn, 10);

        // 埋點 顯示就送
        DataProcess.sendString("track_logout_notice_click 2");

        // 5.6.0埋點 跳出提示畫面
        TexasUtility.sendUserAnalyticsTrack(3070);
    },

    // 點擊離開按鈕
    _leaveBtnClicked: function () {
        // 埋點
        DataProcess.sendString("track_logout_notice_click 3");

        // 5.6.0埋點 點擊離開按鈕
        TexasUtility.sendUserAnalyticsTrack(3072);

        // 回登入頁
        DataModal.loginData.logout();
    },

    // 點擊取消按鈕
    _cancelBtnClicked: function () {
        // 埋點
        DataProcess.sendString("track_logout_notice_click 4");

        // 關掉畫面
        this._closeDialogAnimation();

        // 5.6.0埋點 點擊不離開按鈕
        TexasUtility.sendUserAnalyticsTrack(3073);
    },

    // 更新內容
    _refreshView: function () {
        var aniLayer = this._animationLayer;

        var data = DataModal.freeChipsData.getRefreshLogoutOrderList();
        var maxLength = DataModal.freeChipsData.logOutMaxShow;

        var totalLength = data.length > maxLength ? maxLength : data.length;

        // 超過3個就放進ScrollView
        if (totalLength > 3) {
            var scrollSize = cc.size(300, 110);
            var scrollViewPos = cc.p(JSScreenMidPos.x - 150, JSScreenMidPos.y - 55);
            var mainLayer = new cc.Layer();
            var scrollView = new cc.ScrollView(scrollSize, mainLayer);
            scrollView.setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
            scrollView.setPosition(scrollViewPos);
            aniLayer.addChild(scrollView);

            for (var i = 0; i < totalLength; i++) {
                var btn = new FreeChipLogoutNode(data[i]);
                btn.setPosition(42 + i * 85, 55);
                mainLayer.addChild(btn);
            }

            var width = totalLength * 85;
            scrollView.setContentSize(width, 110);
        } else {
            // 排版用的node
            var autoLayoutNode = new GSAutoLayoutNode();
            autoLayoutNode.setSpace(totalLength === 2 ? 46 : 16);
            autoLayoutNode.setPosition(JSScreenMidPos);
            aniLayer.addChild(autoLayoutNode);

            // 創畫面
            data.forEach(cur => {
                autoLayoutNode.addChild(new FreeChipLogoutNode(cur));
            });
        }
    }
});