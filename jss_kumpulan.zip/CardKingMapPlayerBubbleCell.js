/**
 * 牌王地圖每個節點上的泡泡匡的cell
 */

var CardKingMapPlayerBubbleCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        // 頭貼
        var headPhoto = this._headPhoto = new PhotoSprite("", 18, 18);
        headPhoto.setPosition(12, CardKingMapPlayerBubbleCell.HEIGHT / 2);
        this.addChild(headPhoto);

        // 名字
        var nameLabel = this._nickNameLabel = new cc.LabelTTF("", JSFontName, 10, cc.size(100, 14));
        nameLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        nameLabel.setFontFillColor(JSColor.BLACK);
        nameLabel.setPosition(78, CardKingMapPlayerBubbleCell.HEIGHT / 2);
        this.addChild(nameLabel);

        // 加一條線
        var lineSprite = this._lineSp = new cc.Sprite("#users_line.png");
        lineSprite.setScaleX(3.75);
        lineSprite.setPosition(CardKingMapPlayerBubbleCell.WIDTH / 2, 0);
        this.addChild(lineSprite);
    },

    refresh: function (data, isLast) {
        if (data) {
            this._headPhoto.setPhotoUrlString(data.playerImgUrl);

            this._nickNameLabel.setString(data.nickName);

            this._lineSp.setVisible(!isLast);
        }
    }

});

// 這個cell大小
CardKingMapPlayerBubbleCell.WIDTH = 130;
CardKingMapPlayerBubbleCell.HEIGHT = 25;