/**
 * 用來撥放Player上面出現的動畫
 */

var Domino_PlayerAnimNode = cc.Node.extend({

    ctor: function () {
        this._super();
        this.setCascadeOpacityEnabled(true);

        // 用來慢慢顯示Label的Queue
        this._queue = [];
    },

    /**
     * 把東西放到Queue裡
     */
    _addLabelToQueue: function (label) {
        label.setVisible(false);
        this._queue.push(label);

        // 假如只有一個 馬上跑動畫
        if (this._queue.length === 1)
            this._playQueneAnimation();
    },

    /**
     * 把東西從Queue拿掉
     */
    _removeLabelFromQueue: function (label) {
        var index = this._queue.indexOf(label);
        if (index > -1)
            this._queue.splice(index, 1);

        // 跑動畫
        this._playQueneAnimation();
    },

    /**
     * 跑Queue的動畫
     */
    _playQueneAnimation: function () {
        if (this._queue.length === 0)
            return;

        var label = this._queue[0];
        label.setVisible(true);
        label.runAction(cc.moveBy(1, cc.p(0, 10)));
        label.runAction(cc.sequence(
            cc.fadeIn(0.2),
            cc.delayTime(0.6),
            cc.callFunc(function () {
                this._removeLabelFromQueue(label);
            }, this),
            cc.fadeOut(0.2),
            cc.removeSelf()
        ));
    },

    stopAllAnim: function () {
        this.removeAllChildren();

        this._queue = [];
    },

    //指示目前自已的位置(一個白色圈圈)
    playSitAnim: function () {
        var pointSprite = new cc.Sprite("#game_pic_player_point.png");
        pointSprite.setOpacity(0);
        pointSprite.setScale(0);
        this.addChild(pointSprite);

        // 一直讓他旋轉
        pointSprite.runAction(cc.repeatForever(cc.rotateBy(3.5, 360)));

        // 讓他出來的動畫
        pointSprite.runAction(cc.sequence(
            cc.delayTime(0.5),
            cc.spawn(cc.fadeTo(0.3, 255), cc.scaleTo(0.3, 1.5)),
            cc.delayTime(3),
            cc.spawn(cc.fadeTo(0.3, 0), cc.scaleTo(0.3, 0)),
            cc.removeSelf()
        ));

        MusicUtility.playVoice("welcome.mp3");
    },

    // 播贏家動畫
    playWinAnim: function (value) {
    },

    // 撥放拿多少錢的動畫
    playGetChips: function (value) {
        var chipsTag = 555;

        var chipsNode = new cc.Node();
        chipsNode.setCascadeOpacityEnabled(true);
        chipsNode.setPosition(0, -10);
        chipsNode.setOpacity(0);
        this.addChild(chipsNode, 0, chipsTag);

        // 背景
        var bgSprite = new cc.Sprite("#lobby_pic_black.png");
        bgSprite.setScale(2.6, 4);
        chipsNode.addChild(bgSprite);

        var posY = 1;                   // 因為小數點有點太下面 我們把他拉上來
        var chipSprite = new cc.Sprite("#game_pic_chips_big_02.png");
        chipSprite.setPosition(5, posY);
        chipsNode.addChild(chipSprite);

        // 加數字
        var numberString = TexasUtility.getSimpleMoneyString(value);
        var numberArray = [chipSprite];
        var totalWidth = 18;            // 先把籌碼的寬度算下去 之後一起移動
        for (var i = 0, len = numberString.length; i < len; i++) {
            var numberChar = numberString[i];
            if (isNaN(numberChar)) {
                // 不是數字 要判斷是不是小數點
                if (numberChar === ".") {
                    var dotSprite = new cc.Sprite("#game_number_point.png");
                    dotSprite.setPosition(totalWidth - 3, posY);
                    chipsNode.addChild(dotSprite);

                    totalWidth += 4;

                    numberArray.push(dotSprite);
                } else {
                    // 代表是最後的文字
                    var wordString = numberString.substr(i, len - i);
                    var wordSprite = new cc.Sprite(JSStringUtility.format("#game_number_%s.png", wordString));
                    wordSprite.setAnchorPoint(0, 0.5);
                    wordSprite.setPosition(totalWidth - 7, posY);
                    chipsNode.addChild(wordSprite);

                    // 要扣掉之前加的數字寬
                    totalWidth += wordSprite.getContentSize().width - 16;

                    numberArray.push(wordSprite);
                    break;
                }
            } else {
                // 數字 直接創
                var numberSprite = new cc.Sprite(JSStringUtility.format("#game_number_%s.png", numberChar));
                numberSprite.setPosition(totalWidth, posY);
                chipsNode.addChild(numberSprite);

                totalWidth += 10;

                numberArray.push(numberSprite);
            }
        }

        // 重新排序
        var offsetX = totalWidth / 2;
        numberArray.forEach(function (cur) {
            cur.setPositionX(cur.getPositionX() - offsetX);
        });

        // 動畫 先判斷有沒有舊的 有的話delay一下在撥
        var moveFunc = function () {
            chipsNode.runAction(cc.moveBy(1, cc.p(0, 20)));
            chipsNode.runAction(cc.sequence(
                cc.fadeIn(0.2),
                cc.delayTime(0.8),
                cc.fadeOut(0.2),
                cc.removeSelf()
            ));
        };

        var children = this.getChildren();
        var oldCount = 0;
        children.forEach(function (cur) {
            if (cur.getTag() === chipsTag)
                oldCount++;
        });
        if (oldCount > 1) {
            chipsNode.runAction(cc.sequence(
                cc.delayTime(0.6 * (oldCount - 1)),
                cc.callFunc(moveFunc)
            ));
        } else {
            // 直接撥
            moveFunc();
        }
    },

    // 表演All In動畫
    playAllIn: function () {
        var allInSprite = new cc.Sprite("#domino_pic_allin.png");
        allInSprite.setPosition(0, -10);
        allInSprite.setOpacity(0);
        allInSprite.setScale(5);
        this.addChild(allInSprite);

        allInSprite.runAction(cc.sequence(
            cc.spawn(cc.fadeIn(0.25), cc.scaleTo(0.25, 1)),
            cc.delayTime(1.5),
            cc.scaleTo(0.25, 1, 0),
            cc.fadeOut(0.05),
            cc.removeSelf()
        ));
    },

    // 經驗值動畫
    playExp: function (value) {
        value = value || 0;

        if (value === 0)
            return;

        var expLabel = new cc.LabelTTF("Exp + " + value, JSFontBoldName, 12);
        expLabel.setOpacity(0);
        expLabel.enableStroke(JSColor.GRAY, 3);
        this.addChild(expLabel, 1);

        // 把他放進去Queue裡
        this._addLabelToQueue(expLabel);
    },

    // Level UP動畫
    playLevelUp: function (value) {
        value = value || 0;

        if (value === 0)
            return;

        var levelLabel = new cc.LabelTTF("Level Up", JSFontBoldName, 12);
        levelLabel.setPosition(0, -10);
        levelLabel.setOpacity(0);
        levelLabel.setFontFillColor(JSColor.YELLOW);
        levelLabel.enableStroke(JSColor.GRAY, 3);
        this.addChild(levelLabel, 1);

        // 把他放進去Queue裡
        this._addLabelToQueue(levelLabel);
    },

    // 遊戲積分的變化
    playGameRankScoreChange: function (value) {
        value = value || 0;

        if (value === 0)
            return;

        var operString = value >= 0 ? "+ " : "- ";
        var scoreLabel = new cc.LabelTTF("Poin " + operString + Math.abs(value).toString(), JSFontBoldName, 12);
        scoreLabel.setOpacity(0);
        scoreLabel.enableStroke(JSColor.GRAY, 3);
        this.addChild(scoreLabel, 1);

        // 把他放進去Queue裡
        this._addLabelToQueue(scoreLabel);
    },
});

Domino_PlayerAnimNode.Type = {
    SIT: 1,                     // 坐下的動畫
    GET_CHIPS: 2,               // 拿多少錢的動畫
    ALL_IN: 3,                  // All in的動畫
    EXP: 4,                     // 得到多少經驗值的動畫
    LEVEL_UP: 5,                // 升級的動畫
    GAME_RANK_SCORE_CHANGE: 6,  // 積分分數的更動
};