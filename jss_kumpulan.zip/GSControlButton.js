/**
 * 用來創按鈕的功能
 * contentNode  預設的畫面 可傳可不傳
 * btnSize      這個按鈕的大小 沒傳的話會抓contentNode的size
 *
 * Warning
 * 使用GSControlButton不要自己使用setBackgroundSpriteForState(X, cc.CONTROL_STATE_NORMAL)
 * 不然_mainNode會被release
 */
var GSControlButton = cc.ControlButton.extend({
    ctor: function (contentNode, btnSize, debug) {
        this._super();

        // 預設開啟
        this.setCascadeColorEnabled(true);
        this.setCascadeOpacityEnabled(true);

        // 設定不能按的話是不是要改變顏色
        this._changeColorWhenDisabled = true;
        this._changeOpacityWhenDisabled = false;

        // 判斷是否有預設畫面 沒有的話創一個空的
        if (!contentNode) {
            contentNode = new cc.Node();
        }

        // 預設顏色跟透明度設定會穿透下去
        contentNode.setCascadeColorEnabled(true);
        contentNode.setCascadeOpacityEnabled(true);

        btnSize = btnSize || contentNode.getContentSize();

        // 抓出大小
        var midPos = cc.p(btnSize.width / 2, btnSize.height / 2);

        var node = this._mainNode = new ccui.Scale9Sprite();
        node.setCascadeColorEnabled(true);
        node.setCascadeOpacityEnabled(true);
        node.setContentSize(btnSize);

        if (debug) {
            // 要加Debug畫面
            var colorLayer = new cc.LayerColor(cc.color(255, 0, 0, 100), btnSize.width, btnSize.height);
            this.addChild(colorLayer);
        }

        // 把畫面加上去
        contentNode.setPosition(midPos);
        node.addChild(contentNode);

        // 把ContentNode記下來
        this._contentNode = contentNode;

        // 自己的設定
        this.setPreferredSize(btnSize);         // 一定要加這行 Native才會是對的
        this.setBackgroundSpriteForState(node, cc.CONTROL_STATE_NORMAL);
        this.addTargetWithActionForControlEvents(this, this._buttonClicked,
            cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
            cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
            cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
        this.setAdjustBackgroundImage(false);
        this.setZoomOnTouchDown(false);
    },

    /**
     * 按到的時候 要改變顏色
     */
    _buttonClicked: function (sender, type) {
        var isTouched = (type === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || type === cc.CONTROL_EVENT_TOUCH_DOWN);
        this._mainNode.setColor(isTouched ? JSColor.GRAY : JSColor.WHITE);
    },

    /**
     * 不能按的時候 要改變顏色
     */
    setEnabled: function (enable) {
        // 用來防止GSControlButton內有gaf或download object產生error
        // 另外為了防止按鈕加在tableView上，導致H5上面onExit就會有this.__isDestroyed，而不能設定setEnabled，所以只在native上觸發
        if (cc.sys.isNative && this.__isDestroyed) {
            return;
        }

        this._super(enable);

        // 這邊要判斷是否有打開關掉改變顏色
        if (this._changeColorWhenDisabled)
            this._mainNode.setColor(enable ? JSColor.WHITE : (this._disabledColor || JSColor.GRAY));

        // 是否有打開關掉改變透名度
        this._changeOpacityWhenDisabled && this._mainNode.setOpacity(enable ? 255 : (this._disabledOpacity || 150));
    },

    /**
     * 設定不能按的話是不是要改變顏色
     */
    setChangeColorWhenDisabled: function (value) {
        if (this._changeColorWhenDisabled !== value) {
            this._changeColorWhenDisabled = value;

            // 更新一次
            this.setEnabled(this.isEnabled());
        }
    },

    /**
     * 設定不能按的話要改變成什麼顏色
     */
    setDisabledColor: function (color) {
        this._disabledColor = color || JSColor.GRAY;
    },

    /**
     * 設定不能按的話是不是要改變透明度
     */
    setChangeOpacityWhenDisabled: function (value) {
        if (this._changeOpacityWhenDisabled !== value) {
            this._changeOpacityWhenDisabled = value;

            // 更新一次
            this.setEnabled(this.isEnabled());
        }
    },

    /**
     * 設定不能按的話要改變成什麼透明度
     */
    setDisabledOpacity: function (value) {
        this._disabledOpacity = value || 150;
    },

    /**
     * 加入按鈕按下去的Callback
     * @param {function}    func    傳Function
     * @param {context}     target  傳Context
     * 用法 button.addTouchUpInsideAction(this._testClicked, this);
     */
    addTouchUpInsideAction: function (func, target) {
        this.addTargetWithActionForControlEvents(target, func, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
    },

    /**
     * 開啟Touch會取消的機制 用在按鈕放在ScrollView上面
     * @param direction     傳cc.SCROLLVIEW_DIRECTION_ 系列的東西 傳 cc.SCROLLVIEW_DIRECTION_NONE 代表不開啟
     */
    enableTouchCancel: function (direction) {
        this.setSwallowTouches(direction === cc.SCROLLVIEW_DIRECTION_NONE);
        this.setTouchDirection(direction);
    },

    /**
     * 額外加入畫面 對位cc.p(0, 0) 是在此按鈕的中心點
     */
    addChildToContentNode: function (child, localZOrder = 0) {
        this._contentNode.addChild(child, localZOrder);
    },

    /**
     * 取得ContentNode
     */
    getContentNode: function () {
        return this._contentNode;
    },

    /**
     * 如果外面有修改prefersize, contentSize
     * 請務必在後面接著呼叫這個function把該排的東西排一排
     * 不然出來的按鈕有可會怪怪的
     */
    refreshContentNodesPosAndSize: function () {
        var contentSize = this.getContentSize();
        this._mainNode.setContentSize(contentSize);
        this._contentNode.setPosition(contentSize.width / 2, contentSize.height / 2);
    },
});