var LocalizedString = LocalizedString || {};

LocalizedString.BlastPinballString = function (str) {
    let keyValue = {
        "來抽免費獎勵！": "Ambil hadiah gratis!",
        "每球必有獎！": "Pasti dapat hadiah!",
        "剩餘時間": "Countdown:",
        "剩餘彈珠": "Sisa:",
        "獲得彈珠": "Beli Kelereng",
        "長壓！": "Tekan!",
        "恭喜您獲得": "Selamat dapat",
        "儲值玩彈珠獲得更多獎勵！": "Beli kelereng untuk main lagi!",
        "繼續玩": "Lanjut",
        "(你還有%s顆彈珠)": "(Sisa %s butir kelereng)",
        "購買成功！": "Pembelian berhasil!",
        "恭喜獲得#!fff433!#%s#!ffffff!#次遊玩機會\n#!faffad$!10!$!#次數請務必於倒數時間結束前用完": "Selamat bisa main #!fff433!#%s#!ffffff!# kali!\n#!faffad$!10!$!#harus digunakan sebelum event selesai",
        "提醒您": "Perhatian",
        "獲得更多彈珠子，\n有機會中GRAND獎！": "Lanjut main & coba dapat GRAND!",
        "先不要": "Tolak",
        "確定": "OK",
        "因連線不穩定，獎勵已發送囉": "Koneksi terputus, hadiah sudah dikirm",
        "還有#!fff433!#%d#!ffffff!#顆未使用的彈珠，\n來玩一手吧！": "Masih ada #!fff433!#%d#!ffffff!# butir kelereng,\nlanjut main yuk!",
    };

    return USE_i18n ? (keyValue[str] || str) : str;
};