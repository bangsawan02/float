// 送每日任務cmd用到
var DailyMissionEnum = {
    // 在哪個layer中 (自己判斷使用)
    whereType: {
        Lobby: 0,    // 大廳
        Room: 1,     // 桌列表
        Game: 2,     // 桌內
        Vip_Lobby: 3,// vip slot大廳
        Slot: 4      // slot機台內
    },

    // 在哪個桌列表中 (對應server 送cmd的編號)
    roomType: {
        Gaple: 1,
        QiuQiu: 2,
        Texas: 3,
        Remi: 4,
        Cangkulan: 5,
        CapsaSusun: 6,
        GapleFriend: 92
    },

    // 領獎種類(送cmd給server用)
    rewardType: {
        DAILY_CHEST: 0,             // 日寶箱
        WEEKLY_CHEST: 1,            // 週寶箱
        DAILY_MISSION: 2,           // 每日任務
        ALL: 3                      // 全部領取
    },

    // 任務領獎狀態
    missionRewardStatus: {
        NOT_COMPLETE: 0,         // 未完成
        CAN_GET_REWARD: 1,       // 可領獎
        GET_REWARD_DONE: 2       // 已經領獎
    },

    // 寶箱領獎狀態
    chestRewardStatus: {
        NOT_COMPLETE: 0,         // 未完成
        CAN_GET_REWARD: 1,       // 可領獎
        GET_REWARD_DONE: 2       // 已經領獎
    }
};
var DailyMissionData = cc.Class.extend({
    ctor: function () {
        //初始化
        this.resetAllValue();
        this.resetTimeLimitValue();

        //註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            "dailyMission_info": this.cmd_dailyMission_info,                        // 每日任務整包
            "dailyMission_update": this.cmd_dailyMission_update,                    // 每日任務更新
            "dailyMission_reward": this.cmd_dailyMission_reward,                    // 每日任務領獎
            "timelimit_task_info": this.cmd_timelimit_task_info,                    // 限時任務資訊
            "timelimit_task_reward": this.cmd_timelimit_task_reward                 // 限時任務領獎
        });
    },

    //清空資料
    resetAllValue: function () {
        this.lobbyMissionList = [];             // 每日任務列表
        this.haveLobbyMissionDone = false;      // 是否已抓過大廳的每日任務

        this.activityParam = {};                // 活躍值資訊

        this.missionNotifyParam = {};           // 每日任務的推播
        this.resetSurplusTime = 0;              // 重置剩餘時間
        this.resetSocketTime = 0;               // 重置Socket拿到的當下時間
        this.haveRewardDailyMission = false;    // 是不是有領獎的flag(桌列表的每日任務使用)

        this.activityConvertParam = undefined;  // 活躍值轉換資訊

        this.resetTimeLimitValue();             // 限時任務
    },

    resetTimeLimitValue: function () {
        this.timeLimitInfo = {};
    },

    /**
     * 抓取進大廳所需要的每日任務資訊
     */
    startGetInfo: function (whereType, missionType) {
        // 跟server拿每日任務
        this.sendDailyMissionData();

        // 也要去抓刮刮卡的任務(大廳拿過刮刮卡資料 桌列表的地方就不用在拿一次)
        if (whereType === DailyMissionEnum.whereType.Lobby || whereType === DailyMissionEnum.whereType.Game)
            DataModal.scratchCardData.startGetInfo();
    },

    /**
     * 去要每日任務的資料
     */
    sendDailyMissionData: function () {
        DataProcess.sendString("dailyMission_info");
    },

    /**
     * 確認每日任務是否有資料
     */
    getHaveDailyMissionDone: function () {
        return this.haveLobbyMissionDone;
    },

    /**
     * 取得每日任務的清單
     */
    getDailyMissionList: function () {
        return this.lobbyMissionList || [];
    },

    /**
     * 抓取獨立的每日任務
     */
    _getDailyMissionParamBySerialID: function (missionList, serialID) {
        var retParam = {};
        var len = missionList.length;
        for (var i = 0; i < len; i++) {
            if (missionList[i].serialID === serialID) {
                retParam = missionList[i];
                break;
            }
        }
        return retParam;
    },

    /**
     * 處理日/週活躍資料
     */
    _processActivityParam: function (jValue) {
        if (!jValue)
            return {};

        // 算進度條數值
        var finishStage = 0;            // 已完成第幾個寶箱
        var finishStageGoal = 0;        // 已完成寶箱的目標值
        var lastGoal = 0;               // 前一個寶箱的目標值
        var stageGapGoalList = [];      // 各階段間差值陣列

        var chestList = [];             // 各個寶箱資料
        (jValue["list"] || []).forEach((cur, idx, arr) => {
            var stage = JSCodeUtility.getIntValue(cur["stage"]);             // 第幾個寶箱
            var status = JSCodeUtility.getIntValue(cur["status"]);           // 領獎狀態 0:不可領,1:可領,2:已領
            var goal = JSCodeUtility.getIntValue(cur["goal"]);               // 需求活躍值

            // 更新已經達成的階段
            if (status !== DailyMissionEnum.chestRewardStatus.NOT_COMPLETE) {
                finishStage = stage;
                finishStageGoal = goal;
            }

            // 計算各階段差值
            stageGapGoalList.push(goal - lastGoal);
            lastGoal = goal;

            chestList.push({
                stage: stage,
                status: status,
                goal: goal,
                reward: JSCodeUtility.getStringValue(cur["reward"])     // 獎勵顯示
            });
        });

        // 計算進度條%數用的資料
        var activity = JSCodeUtility.getIntValue(jValue["activity"]);       // 玩家活躍值
        // 完成階段後多出的活躍值比例
        var extraGoal = activity - finishStageGoal;
        // 多出活躍值的間隔比例，最後一階段不用算直接給0
        var gapRatio = (finishStage < stageGapGoalList.length) ? extraGoal / stageGapGoalList[finishStage] : 0;

        return {
            activity: activity,
            remainTime: JSCodeUtility.getIntValue(jValue["left_time"]),       // 剩餘時間
            socketTime: JSCodeUtility.getNowTime(),                           // 拿到cmd時間
            chestList: chestList,                                             // 寶箱資料
            finishStage: finishStage,                                         // 完成第幾階段寶箱
            gapRatio: gapRatio                                                // 多出的活躍值間隔比例
        };
    },

    /**
     * 重新排序每日任務 把可領獎的放在上面
     */
    _sortDailyMissionList: function (missionList) {
        // 已完成 > 優先權高的放上面(數字越小 優先權越大)
        missionList.sort((a, b) => {
            return a.sortPriority - b.sortPriority;
        });
        // 已領獎放最下方, 可領獎放最上方, 其他擺中間
        missionList.sort((a, b) => {
            if (a.status === DailyMissionEnum.missionRewardStatus.GET_REWARD_DONE && b.status !== DailyMissionEnum.missionRewardStatus.GET_REWARD_DONE)
                return 1;
            else if (b.status === DailyMissionEnum.missionRewardStatus.GET_REWARD_DONE && a.status !== DailyMissionEnum.missionRewardStatus.GET_REWARD_DONE)
                return -1;
            else
                return b.status - a.status;
        });
    },

    /**
     * 判斷活躍值寶箱能否領獎
     */
    _haveChestCanGetReward: function (chestList) {
        return chestList.some((cur) => cur.status === DailyMissionEnum.chestRewardStatus.CAN_GET_REWARD);
    },

    /**
     * 設定每日任務推播
     */
    setDailyMissionNotify: function () {
        var notifyParam = this.missionNotifyParam;
        var isOpenDMNotify = GS.localStorage.getItem("isOpenDailyMissionNotify");
        if (isOpenDMNotify === "1" && _.size(notifyParam) > 0 && notifyParam.message.length > 0) {
            //先抓出玩家目前時間
            var hr = new Date().getHours();
            var min = new Date().getMinutes();
            var sec = new Date().getSeconds();
            var curTime = hr * 3600 + min * 60 + sec;

            //推播時間 PM設定隔日中午12點(重置時間:早上六點 60*60*6=21600 重置時間前設定，是今天中午12點，反之則是隔日的中午12點)
            var notifyInfo = {
                "msg": notifyParam.message,
                "id": JSNotify.key.DailyMission,
                "bg": notifyParam.bgUrl,
                "big": "",
                "sound": notifyParam.sound,
                "icon": "",
                "date": (curTime < 21600) ? "0" : "1",
                "hour": "12",
                "minute": "0",
                "interval": notifyParam.time
            };
            JSNotify.scheduleFixNotify(notifyInfo);
        } else {
            //取消推播
            JSNotify.removeNotify("9100");
        }
    },

    /**
     * 抓取是否有可以領獎
     */
    getHaveReward: function (whereType, missionType) {
        var missionList = this.getDailyMissionList();

        // 先算任務有沒有可領獎
        var retValue = missionList.some((cur) => cur.status === 1);

        // 判斷日/週活躍值能否領獎
        var activityParam = this.activityParam;
        if (activityParam.daily && activityParam.daily.chestList.length > 0) {
            retValue |= this._haveChestCanGetReward(activityParam.daily.chestList);
        }

        if (activityParam.weekly && activityParam.weekly.chestList.length > 0) {
            retValue |= this._haveChestCanGetReward(activityParam.weekly.chestList);
        }

        return retValue;
    },

    /**
     * 抓取整個ActionList(每日任務)視窗是否有可以領獎
     */
    getActionListDialogHaveReward: function (whereType, missionType) {
        var retValue = this.getHaveReward(whereType, missionType);

        // 其他也包在裡面的任務 Gaple好友桌不用判斷這裡
        if (missionType !== DailyMissionEnum.roomType.GapleFriend && !retValue && !PushScene.isGame) {
            // 特殊任務 (Action_list)
            retValue |= DataModal.lobbyActionData.getHaveReward();
        }

        // 刮刮卡
        if (!retValue) {
            retValue |= DataModal.scratchCardData.getHaveReward();
        }

        return retValue;
    },

    /**
     * Socket Call Back
     */

    /**
     * 每日任務整包
     *
     * C→S dailyMission_info
     * S→C dailyMission_info
     {
       "show":"0",              // 主動跳視窗
       "count_down":"49165",    // 刷新倒數
       "img_host":"http://d.mwsrv.com/19_60/store/dailymision/",
       "reward_host":"http://d.mwsrv.com/19_60/store/iapp/goods/",

       // 舊版到新版的活躍值轉換
       "convert":{
            "old": 120,
            "new": 60
        },

        // 每日任務列表
        "list":[
        {
            "mid":"12",
            "name":"Main 1 kali (Gaple Plus)",
            "status":"0",  //狀態 # 0不可領,1可領,2已領
            "activity":"12",  //活躍值
            "reward":[
                {"wid" : 123, "reward_txt" : "100rb"},
                {"wid" : 123, "reward_txt" : "100rb"},
            ],
            "progress":[  //進度
                "0",
                "1"
            ],
            "btn_url":"95",
            "btn_type":"3"
            "priority":"73",

        },
        {...}
        ],

        // 寶箱資訊(日/週活躍值)
        "chest":{
            "weekly":{ // 每週
                "list":[    // 每個寶箱資訊
                    {
                        "stage" :"1", //哪個寶箱
                        "status":"0", //狀態 # 0不可領,1可領,2已領
                        "goal":"12",  //需要活躍值
                        "reward":"10 RP(Koin Luxy)" //獎勵顯示（待補）
                    },
                    {...}
                ],
                "left_time":"481056", //剩餘時間
                "activity":"0" //玩家活躍值
            },
            "daily":{ // 每日(架構和週活躍相同)
                    ...
            }
        }
     }
     *
     */
    cmd_dailyMission_info: function (key, value) {
        // 擋黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        // 先移除loadingView
        GS.dispatchCustomEvent("NotifyDailyMissionLoading", false);

        var jsonValue = JSON.parse(value || "{}");

        // 已經拿到大廳任務資料
        this.haveLobbyMissionDone = true;

        // 圖片下載的網址
        DailyMissionData.IMAGE_BASE_HOST = JSCodeUtility.getStringValue(jsonValue["img_host"]);

        // 獎勵圖片下載網址
        DailyMissionData.REWARD_BASE_HOST = JSCodeUtility.getStringValue(jsonValue["reward_host"]);

        // 重置倒數時間
        this.resetSurplusTime = JSCodeUtility.getIntValue(jsonValue["count_down"]);
        this.resetSocketTime = JSCodeUtility.getNowTime();

        //每日任務清單
        this.lobbyMissionList = (jsonValue["list"] || []).map((missionValue) => {

            return {
                // 任務名稱
                name: JSCodeUtility.getStringValue(missionValue["name"]),
                // 任務序號
                serialID: JSCodeUtility.getStringValue(missionValue["mid"]),
                // 領獎狀態 0不可領,1可領,2已領
                status: JSCodeUtility.getIntValue(missionValue["status"]),
                // 活躍值數值
                activity: JSCodeUtility.getIntValue(missionValue["activity"]),
                // 底台
                limitFee: JSCodeUtility.getIntValue(missionValue["limitFee"]),
                // 排序優先權
                sortPriority: JSCodeUtility.getIntValue(missionValue["priority"]),
                // 按下後要導去哪
                bannerType: JSCodeUtility.getIntValue(missionValue["btn_type"]),
                bannerUrl: JSCodeUtility.getStringValue(missionValue["btn_url"]),

                // 進度陣列[目前任務數值,目標值]
                progressList: (missionValue["progress"] || []).map((cur) => JSCodeUtility.getStringValue(cur)),

                // 獎勵陣列
                rewardList: (missionValue["reward"] || []).map((cur) => {
                    return {
                        wid: JSCodeUtility.getStringValue(cur["wid"]),
                        rewardTxt: JSCodeUtility.getStringValue(cur["reward_txt"])
                    };
                })
            };
        });

        // 排序列表
        this._sortDailyMissionList(this.lobbyMissionList);

        // 日/週活躍值
        var activityJv = jsonValue["chest"];
        if (activityJv) {
            this.activityParam.weekly = this._processActivityParam(activityJv["weekly"]);
            this.activityParam.daily = this._processActivityParam(activityJv["daily"]);
        }

        // 新舊版本的活躍值轉換
        var convertJv = jsonValue["convert"];
        if (convertJv) {
            this.activityConvertParam = {
                oldValue: JSCodeUtility.getIntValue(convertJv["old"]),
                newValue: JSCodeUtility.getIntValue(convertJv["new"])
            };
        }

        // 每日任務的推播
        var notifyValue = jsonValue["notify"];
        if (_.size(notifyValue) > 0 && JSCodeUtility.isObject(notifyValue)) {
            this.missionNotifyParam = {
                time: JSCodeUtility.getIntValue(notifyValue["time"]),               //時間
                message: JSCodeUtility.getStringValue(notifyValue["message"]),      //訊息
                bgUrl: JSCodeUtility.getStringValue(notifyValue["background_img"]), //Android 推播背景圖
                sound: JSCodeUtility.getStringValue(notifyValue["sound"])           //聲音
            };

            // 設定每日任務推播
            this.setDailyMissionNotify();
        }

        // 是否主動跳
        var isAutoShow = (JSCodeUtility.getIntValue(jsonValue["show"]) === 1);

        // 送通知
        if (isAutoShow)
            GS.dispatchCustomEvent("NotifyDailyMissionInfoDone");   //每日任務data done 要主動跳再送
        GS.dispatchCustomEvent("NotifyUpdateDailyMission", 1);      //更新遊戲中UI 強制更新畫面
    },

    /**
     * 每日任務更新
     *
     * C→S dailyMission_update 1 1 # 任務種類 累積數量
     * S→C dailyMission_update
     {
       "mid" => 13,
       "progress" => [12, 20], // [目前任務進度,任務目標]
       "status" => 1,          // 領獎狀態 # 0不可領,1可領,2已領
     }
     */
    cmd_dailyMission_update: function (key, value) {
        var jsonValue = JSON.parse(value || "{}");

        // 序號
        var serialID = JSCodeUtility.getStringValue(jsonValue["mid"]);

        // 更新每日任務
        var dailyMissionParam = this._getDailyMissionParamBySerialID(this.lobbyMissionList, serialID);
        if (dailyMissionParam) {
            // 狀態
            dailyMissionParam.status = JSCodeUtility.getIntValue(jsonValue["status"]);
            // 進度
            var jValue = jsonValue["progress"] || [];
            if (jValue.length > 1) {
                dailyMissionParam.progressList = [];
                for (var i = 0; i < 2; i++)
                    dailyMissionParam.progressList[i] = JSCodeUtility.getIntValue(jValue[i]);
            }

            // 排序列表
            this._sortDailyMissionList(this.lobbyMissionList);
        }

        // 送通知
        GS.dispatchCustomEvent("NotifyUpdateDailyMission");
    },

    /**
     * 每日任務領獎
     * C→S dailyMission_reward X_Y
     * X: 領獎種類-> 0:每日寶箱 1:每週寶箱 2:每日任務 3:全部(3_0)
     * Y: mid (全部領獎時給0)
     * S→C dailyMission_reward

     {
        "success":"1",
        "id":"1_1", // 同傳來的
        "reward":[
            {"wid": XXX, "reward_txt" : XXX},
            {"wid": XXX, "reward_txt" : XXX},
        ],
        "chest":[ // 文件給的，但實際上沒用到
            {
                "stage"   : 1,
                "type"    : daily,
                "activit" : 14,
                "status"  : 1,
            },
            {
              ...
            }
        ]
     }
     *
     */
    cmd_dailyMission_reward: function (key, value) {
        // 先移除loadingView
        GSLoading.removeLoadingView();

        var jsonValue = JSON.parse(value);

        //領取成功的
        var isSuccess = JSCodeUtility.getBooleanValue(jsonValue["success"]);
        if (isSuccess) {
            // 領取成功
            var baseParam = {};
            // 領獎種類序號 0:每日寶箱 1:每週寶箱 2:每日任務 3:全部
            baseParam.serialId = JSCodeUtility.getStringValue(jsonValue["id"]);

            // 獎勵列表
            baseParam.rewardList = (jsonValue["reward"] || []).map((cur) => {
                return {
                    wid: JSCodeUtility.getStringValue(cur["wid"]),
                    rewardTxt: JSCodeUtility.getStringValue(cur["reward_txt"])
                };
            });

            // 更新物品背包
            DataProcess.sendString("get_camp_mood_list");   //抓special表情
            DataProcess.sendString("act_moods_backpack");   //抓互動道具
            DataProcess.sendString("store_mood_backpack");  //抓商城表情

            // 刷新session_status
            DataProcess.sendString("session_status [1]");

            // 送通知
            GS.dispatchCustomEvent("NotifyGotDailyMissionReward", baseParam);   //跳領獎畫面

            GS.dispatchCustomEvent("NotifyUpdateDailyMission", 1);              //更新畫面
        } else {
            // 失敗
            var errMsg = jsonValue["msg"];
            GS.dispatchCustomEvent("NotifyGotDailyMissionRewardFail", errMsg);
        }

        // 加loading 更新任務資料
        GS.dispatchCustomEvent("NotifyDailyMissionLoading", true);
        this.sendDailyMissionData();
    },

    /**
     * 限時任務資訊
     * timelimit_task_info {
     *  "mission":[["1","Blinds kecil 1jt keatas main 4 kali","2000000","4","0","0","33"]], // 只會傳有開放的，要顯示3個任務在畫面
     *  "open":"1","canPlay":"1","pop":"0","timer":"75908",
     *  "complete":[["5004.png","3.5jt"],["6053.png","x 3"],["19004.png","x 1"]]            // 完成獎勵
     *  }
     */
    cmd_timelimit_task_info: function (key, value) {
        var jsonValue = JSON.parse(value || "{}");
        var timeLimitInfo = this.timeLimitInfo = {};

        var isOpen = (JSCodeUtility.getIntValue(jsonValue["open"]) === 1);
        if (isOpen) {
            // 是否開放
            timeLimitInfo.isOpen = isOpen;
            // 倒數計時
            timeLimitInfo.countdownTime = JSCodeUtility.getIntValue(jsonValue["timer"]) + JSCodeUtility.getNowTime();
            // 是否可玩
            timeLimitInfo.canPlay = (JSCodeUtility.getIntValue(jsonValue["canPlay"]) === 1);
            //每日限時任務的圖片跟數量
            timeLimitInfo.rewardList = (jsonValue["complete"] || []).map(cur => {
                if (cur.length === 2) {
                    return {
                        pic: JSCodeUtility.getStringValue(cur[0]),
                        num: JSCodeUtility.getStringValue(cur[1])
                    };
                }
            }).filter(reward => !!reward);

            // 任務內容
            timeLimitInfo.missionList = [];
            var missionValueList = jsonValue["mission"] || [];
            timeLimitInfo.currentMission = missionValueList.length;
            // 最多三個任務
            for (var i = 0; i < 3; i++) {
                var missionValue = missionValueList[i];

                if (missionValue) {
                    var pickUpState = JSCodeUtility.getIntValue(missionValue[5]);
                    //如果最後一個傳過來的任務是可領獎
                    if (i === timeLimitInfo.currentMission - 1 && pickUpState === 1)
                        timeLimitInfo.canPickUp = true;

                    timeLimitInfo.missionList.push({
                        starNum: i + 1,
                        type: JSCodeUtility.getIntValue(missionValue[0]),
                        content: JSCodeUtility.getStringValue(missionValue[1]),
                        reward: JSCodeUtility.getIntValue(missionValue[2]),
                        goalNum: JSCodeUtility.getIntValue(missionValue[3]),
                        nowNum: JSCodeUtility.getIntValue(missionValue[4]),
                        isPickUp: pickUpState === 2,
                        destination: this.transferServerIDToBanner(JSCodeUtility.getIntValue(missionValue[6]))
                    });
                }
            }

        }

        GS.dispatchCustomEvent("NotifyTimeLimitTaskInfoDone");
    },

    /**
     * 限時任務獎勵
     * timelimit_task_reward {
     * "txt":["chips _2jt"],
     * "error":"0"
     * }
     */
    cmd_timelimit_task_reward: function (key, value) {
        var jsonValue = JSON.parse(value);

        var error = JSCodeUtility.getIntValue(jsonValue["error"], 1) === 1;
        if (error)
            return;

        // 跳獎勵
        var rewardArray = (jsonValue["txt"] || []).map(cur => "#!000000!#" + JSCodeUtility.getStringValue(cur).replace("_", "#!DC0050!#"));
        // 獎勵畫面
        DialogManager.addDialog(new RewardDialog({content: rewardArray}), false); //不列入DialogManager控管

        //更新任務
        DataProcess.sendString("callback_mission_info");

        //更新錢
        DataProcess.sendString("get_tmoney");

        //更新免費券
        DataProcess.sendString("slot16_info");             // 拉霸大廳資訊
        DataProcess.sendString("slot12_info");             // 骰寶大廳資訊
        DataProcess.sendString("slot10_info");             // 21點大廳資訊
    },

    /**
     * 將server那邊拿到的 PushLayer 轉成 LobbyBannerMode
     * 只會傳機台過來
     * @param ID
     * @returns {number}
     */
    transferServerIDToBanner: function (ID) {
        switch (ID) {
            case 25:
                // 生肖拉霸
                return LobbyBannerMode.SlotB;
            case 27:
                // 21點
                return LobbyBannerMode.Blackjack;
            case 28:
                // 骰寶
                return LobbyBannerMode.DiceBo;
            case 29:
                // 魚蝦蟹
                return LobbyBannerMode.HooHeyHow;
            case 31:
                // 恭喜發財
                return LobbyBannerMode.GoldSlot;
            case 30:
                // 水果拉霸
                return LobbyBannerMode.SlotFruit;
            case 32:
                // 5PK
                return LobbyBannerMode.PK5;
            case 34:
                // 百家樂
                return LobbyBannerMode.Bakarat;
            case 35:
                // 足球
                return LobbyBannerMode.Football;
            default:
                return LobbyBannerMode.None;
        }
    }
});

DailyMissionData.IMAGE_BASE_HOST = "";                                  // 圖片下載的網址
DailyMissionData.SAVE_BASE_PATH = JSWriteablePath + "dailyMission/";    // 圖片儲存的路徑
DailyMissionData.REWARD_BASE_HOST = "";                                 // 獎勵圖片下載的網址
DailyMissionData.SAVE_REWARD_BASE_PATH = JSWriteablePath + "shop/";     // 獎圖儲存的路徑，統一放在shop