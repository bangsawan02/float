/**
 * 5.4.0 副系統 - 激戰任務活動視窗
 * created by Jim.Chen
 */

var FierceBattleDialog = BaseDialogLayer.extend({
    ctor: function () {
        this._super();

        // 先設定此Dialog的Key 之後容易砍
        this.key = "FierceBattleDialog";

        this._pressedBtn = undefined;               // 紀錄被按下的scrollBtn 用來關閉顯示的 wallPageLayer
        this._canChangeBroadcastEnabled = true;     // 紀錄推播開關30秒才能按一次
        this._isBroadcastEnabled = true;            // 推播功能是否開啟

        // 需要讀取的素材
        this.loadFileArray = ["lobby/lobby_fierceBattle.plist", "lobby/lobby_fierceBattle.png"];
    },

    onEnter: function () {
        this._super();

        // 埋點
        DataProcess.sendString("track_fierce_battle 1");
    },

    onExit: function () {
        this._loadFileDone && cc.spriteFrameCache.removeSpriteFramesFromFile("lobby/lobby_fierceBattle.plist");

        this._super();
    },

    loadFileDone: function () {
        this._super();

        cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[0], this.loadFileArray[1]);

        var aniLayer = this._animationLayer;

        // 兩旁樹葉
        [72, 496].forEach((curX, idx) => {
            var leafSp = new cc.Sprite("#fierceBattle_pic_leaf.png");
            leafSp.setPosition(curX + JSScreenBonusHalfWidth, 33 + JSScreenBonusHalfHeight);
            leafSp.setFlippedX(!!idx);
            aniLayer.addChild(leafSp);
        });

        // 左側玩法顯示區旗子
        var flagSp = new cc.Scale9Sprite("fierceBattle_pic_banner_list.png");
        flagSp.setPreferredSize(cc.size(72, 170));
        flagSp.setPosition(39 + JSScreenBonusHalfWidth, 142 + JSScreenBonusHalfHeight);
        aniLayer.addChild(flagSp);

        // 背景底版
        var bgSp = new cc.Scale9Sprite("fierceBattle_bg_01.png");
        bgSp.setPreferredSize(cc.size(410, 200));
        bgSp.setPosition(282 + JSScreenBonusHalfWidth, 120 + JSScreenBonusHalfHeight);
        aniLayer.addChild(bgSp);

        // 背景底版2
        bgSp = new cc.Scale9Sprite("fierceBattle_bg_02.png");
        bgSp.setPreferredSize(cc.size(305, 210));
        bgSp.setPosition(329 + JSScreenBonusHalfWidth, 120 + JSScreenBonusHalfHeight);
        aniLayer.addChild(bgSp);

        // 上木板背景
        var upBgSp = new cc.Scale9Sprite("fierceBattle_pic_board.png");
        upBgSp.setCapInsets(cc.rect(45, 16, 48, 13));
        upBgSp.setPreferredSize(cc.size(435, 43));
        upBgSp.setPosition(282 + JSScreenBonusHalfWidth, 229 + JSScreenBonusHalfHeight);
        aniLayer.addChild(upBgSp);

        // 下木板背景
        var bottomBgSp = new cc.Scale9Sprite("fierceBattle_pic_shelf_01.png");
        bottomBgSp.setPreferredSize(cc.size(445, 28));
        bottomBgSp.setPosition(282 + JSScreenBonusHalfWidth, 18 + JSScreenBonusHalfHeight);
        aniLayer.addChild(bottomBgSp);

        // 標題背景
        var titleBgSp = new cc.Sprite("#fierceBattle_pic_title_bg.png");
        titleBgSp.setPosition(284 + JSScreenBonusHalfWidth, 257 + JSScreenBonusHalfHeight);
        aniLayer.addChild(titleBgSp);

        // 標題文字
        var titleSp = new cc.Sprite("#fierceBattle_word_title.png");
        titleSp.setPosition(284 + JSScreenBonusHalfWidth, 260 + JSScreenBonusHalfHeight);
        aniLayer.addChild(titleSp);

        // 最左邊玩法選單
        {
            var chooseGameScrollViewSize = cc.size(60, 115);
            var chooseGameScrollView = this._chooseGameScrollView = new cc.ScrollView(chooseGameScrollViewSize);
            chooseGameScrollView.setPosition(9 + JSScreenBonusHalfWidth, 92 + JSScreenBonusHalfHeight);
            chooseGameScrollView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
            aniLayer.addChild(chooseGameScrollView);

            // 擋touch
            var topDummyTouchLayer = new DummyTouchLayer(cc.size(chooseGameScrollViewSize.width, JSVisibleSize.height - 115 - JSScreenBonusHalfHeight), false);
            topDummyTouchLayer.setPosition(9 + JSScreenBonusHalfWidth, 208 + JSScreenBonusHalfHeight);
            aniLayer.addChild(topDummyTouchLayer);

            var bottomDummyTouchLayer = new DummyTouchLayer(cc.size(chooseGameScrollViewSize.width, 92 + JSScreenBonusHalfHeight), false);
            bottomDummyTouchLayer.setPosition(9 + JSScreenBonusHalfWidth, 0);
            aniLayer.addChild(bottomDummyTouchLayer);
        }

        // 倒數時間icon
        var clockSp = this._clockSp = new cc.Sprite("#lobby_pic_clock_02.png");
        clockSp.setScale(0.5);
        clockSp.setColor(JSColor.BLACK);
        clockSp.setPosition(255 + JSScreenBonusHalfWidth, 243 + JSScreenBonusHalfHeight);
        clockSp.setVisible(false);
        aniLayer.addChild(clockSp);

        // 顯示活動倒數時間
        var seasonTimeLabel = this._seasonTimeLabel = new GSTimeLabel("", JSFontBoldName, 11);
        seasonTimeLabel.setFontFillColor(JSColor.BLACK);
        seasonTimeLabel.setPosition(291 + JSScreenBonusHalfWidth, 243 + JSScreenBonusHalfHeight);
        seasonTimeLabel.setMultiFormat("%hh:%mm:%ss", "%hh:%mm:%ss", "%hh:%mm:%ss");
        aniLayer.addChild(seasonTimeLabel);

        // 時段刷新倒數(不顯示)
        var refreshTimeLabel = this._refreshTimeLabel = new GSTimeLabel("", JSFontBoldName, 11);
        refreshTimeLabel.setAnchorPoint(0, 0);
        refreshTimeLabel.setPosition(JSScreenBonusHalfWidth, JSScreenBonusHalfHeight);
        refreshTimeLabel.setVisible(false);
        aniLayer.addChild(refreshTimeLabel);

        // 大廳每分鐘刷新倒數(不顯示)
        var selfCountdownLabel = this._selfCountdownLabel = new GSTimeLabel("", JSFontBoldName, 11);
        selfCountdownLabel.setVisible(false);
        aniLayer.addChild(selfCountdownLabel);

        // 關閉按鈕
        var closeBtn = ButtonUtility.createSimpleImageButton("lobby_btn_circle_04.png", null, "#lobby_btn_pic_window_x.png");
        closeBtn.setPosition(495 + JSScreenBonusHalfWidth, 245 + JSScreenBonusHalfHeight);
        closeBtn.addTouchUpInsideAction(this._closeDialogAnimation, this);
        aniLayer.addChild(closeBtn, 1);

        // 說明按鈕
        var explainBtn = new Texas_ExplainButton();
        explainBtn.setPosition(73 + JSScreenBonusHalfWidth, 245 + JSScreenBonusHalfHeight);
        explainBtn.addTouchUpInsideAction(this._explainBtnClicked.bind(this), this);
        aniLayer.addChild(explainBtn, 1);

        // 推播開關
        {
            var contentNode = new cc.Node();

            // 加入背景圖
            var btnBgSp = new cc.Sprite("#btn_round_red.png");
            contentNode.addChild(btnBgSp);

            // icon
            var iconSp = new cc.Sprite("#fierceBattle_btn_bell_on.png");
            contentNode.addChild(iconSp);

            var btnSize = cc.size(30, 30);
            var broadcastBtn = this._broadcastBtn = new GSControlButton(contentNode, btnSize);
            broadcastBtn.bgSp = btnBgSp;
            broadcastBtn.iconSp = iconSp;
            broadcastBtn.setScale(0.8);
            broadcastBtn.setPosition(126 + JSScreenBonusHalfWidth, 224 + JSScreenBonusHalfHeight);
            broadcastBtn.setVisible(false);
            broadcastBtn.addTouchUpInsideAction(this._broadcastBtnClicked, this);
            aniLayer.addChild(broadcastBtn, 1);
        }

        // 放頁面的node
        var pageNode = this._pageNode = new cc.Node();
        aniLayer.addChild(pageNode, 1);

        // 每次開Dialog更新排行榜資料
        this.addLoadingLayer();
        DataModal.fierceBattleData.startGetInfo(null, true);

        GS.addListener("NotifyFierceBattleInfoDone", this.notifyFierceBattleInfoDone.bind(this), this);
    },

    /**
     * 加讀取
     * @override
     */
    addLoadingLayer: function () {
        var aniLayer = this._animationLayer;

        // 加之前先檢查有沒有加過，有的話要拿掉
        this.removeLoadingLayer();

        var touchSize = cc.size(500, 210);

        // 檔Touch用
        var loadingLayer = this._loadingLayer = new DummyTouchLayer(touchSize, false);
        loadingLayer.setPosition(JSScreenBonusHalfWidth, JSScreenBonusHalfHeight);
        aniLayer.addChild(loadingLayer, JSCodeUtility.INT_MAX);

        // 讀取sprite
        var loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(touchSize.width / 2 + 76, touchSize.height / 2 + 15);
        loadingSprite.start();
        loadingLayer.addChild(loadingSprite, 999999);
    },

    // 更新畫面
    _refreshView: function () {
        var fierceData = DataModal.fierceBattleData;
        var infoParam = fierceData.infoParam;
        // 有開啟活動的玩法列表
        var gameList = fierceData.getObjKeyList(infoParam.gameInfoParams);
        var gameListLen = gameList.length;

        // 沒資料 跳活動結束
        if (gameListLen === 0) {
            this._showEventOverDialog();
            return;
        }

        // 顯示賽季時間 賽季結束後24hr不顯示
        if (infoParam.eventStatus !== FierceBattleData.EventStatusType.SEASON_END) {
            this._clockSp.setVisible(true);
            this._seasonTimeLabel.countdownSeconds(JSCodeUtility.getRemainTime(infoParam.seasonRemainTime, infoParam.socketTime), () => {
                // 更新資料
                this.addLoadingLayer();
                DataModal.fierceBattleData.startGetInfo(null, true);
            });
        } else {
            this._clockSp.setVisible(false);
            this._seasonTimeLabel.clearTimer();
        }

        // 大廳且活動進行中 每分鐘更新一次排行榜
        if (PushScene.isLobby && infoParam.eventStatus !== FierceBattleData.EventStatusType.SEASON_END) {
            this._selfCountdownLabel.countdownSeconds(60, () => {
                // 非活動結束後24hr 更新資料
                this.addLoadingLayer();
                DataModal.fierceBattleData.startGetInfo(null, true);
            });
        }

        // 先清掉原本的資料
        var chooseGameScrollView = this._chooseGameScrollView;
        var chooseGameScrollViewContainer = chooseGameScrollView.getContainer();
        chooseGameScrollViewContainer.removeAllChildren();
        this._pageNode.removeAllChildren();
        this._pressedBtn = undefined;

        // 更新玩法選擇區
        {
            chooseGameScrollView.setTouchEnabled(gameListLen > 3);

            // 加換頁按鈕
            var gapHeight = 1;                      // 按鈕間隙
            var totalContentSizeHeight = gapHeight; // 按鈕總高
            var btnSize = cc.size(60, 30);          // 按鈕尺寸

            // 逐一建立scrollView按鈕
            var buttonArray = [];
            this._chooseGameButtons = [];
            gameList.forEach((curGameType, idx) => {
                // 玩法選擇按鈕
                var chooseGameButtons = this._chooseGameButtons[idx] = new FierceBattleChooseGameButton(btnSize, infoParam.gameInfoParams[curGameType]);
                chooseGameButtons.addTouchUpInsideAction(this._chooseGameBtnClicked, this);
                chooseGameButtons.setAnchorPoint(0, 0);
                chooseGameScrollViewContainer.addChild(chooseGameButtons);
                buttonArray.push(chooseGameButtons);
                totalContentSizeHeight += (btnSize.height + gapHeight);
            });

            // 設定ScrollView的大小
            chooseGameScrollView.setContentSize(cc.size(85, totalContentSizeHeight));
            //設定offset到最高點
            chooseGameScrollView.setContentOffset(cc.p(0, chooseGameScrollView.getViewSize().height - chooseGameScrollView.getContentSize().height));

            // 重新對位
            buttonArray.forEach(cur => {
                totalContentSizeHeight -= (btnSize.height + gapHeight);
                cur.setPositionY(totalContentSizeHeight);
            });

            // 預設點哪一個活動 預設為第一個
            this._tapIndex = 0;
            this._chooseGameBtnClicked(this._chooseGameButtons[this._tapIndex]);
        }

        // 更新推播按鈕狀態
        var isBroadcastEnabled = this._isBroadcastEnabled = fierceData.isCanBroadcast;
        this._broadcastBtn.bgSp.setSpriteFrame((isBroadcastEnabled) ? "btn_round_red.png" : "btn_ban_off.png");
        this._broadcastBtn.iconSp.setSpriteFrame((isBroadcastEnabled) ? "fierceBattle_btn_bell_on.png" : "fierceBattle_btn_bell_off.png");
        this._broadcastBtn.setVisible(true);
    },

    /**
     * 按鈕
     * 分頁 sender 為 FierceBattleChooseGameButton
     * 用sender.page 存個別的pageLayer
     */
    _chooseGameBtnClicked: function (sender) {
        // 把與目前按鈕對應的pageLayer關掉 確保切換頁籤時也能清乾淨
        if (this._pressedBtn && this._pressedBtn.page) {
            this._pressedBtn.page.setVisible(false);
        }
        this._pressedBtn = sender;

        // 逐一更新按鈕狀態
        var btnLen = this._chooseGameButtons.length;
        for (var i = 0; i < btnLen; i++) {
            var btn = this._chooseGameButtons[i];
            var findIt = sender === btn;

            // 選到的按鈕設成不能按
            btn.setEnabled(!findIt);
            // 把Page關掉
            btn.page && btn.page.setVisible(findIt);
        }

        // 顯示畫面
        if (!sender.page) {
            var page = sender.page = new FierceBattlePageLayer(sender.pageParam);
            this._pageNode.addChild(page);
        }
    },

    // 點擊推播開關
    _broadcastBtnClicked: function () {
        var fierceString = LocalizedString.FierceBattle;

        // 三十秒後才能再點一次
        if (!this._canChangeBroadcastEnabled) {
            // 還不能刷新
            DialogManager.addDialog(new Dialog({
                title: LocalizedString.Common("提醒"),
                content: fierceString("您剛剛已經刷新過了喔\n稍等再試試看吧"),
                buttons: ["OK"],
                closeButton: 0
            }), false);

        } else {
            // 30秒內 不可再次刷新
            this._canChangeBroadcastEnabled = false;

            // 改變推播狀態 同時會送or清除推播
            var isBroadcastEnabled = this._isBroadcastEnabled = !this._isBroadcastEnabled;
            DataModal.fierceBattleData.setBroadcastEnabled(isBroadcastEnabled);
            this._showBannerHintNode(fierceString((isBroadcastEnabled) ? "已開啟鈴鐺，下一場比賽開賽10分鐘前提醒我" : "取消提醒功能"));

            // 調整按鈕樣式
            this._broadcastBtn.bgSp.setSpriteFrame((isBroadcastEnabled) ? "btn_round_red.png" : "btn_ban_off.png");
            this._broadcastBtn.iconSp.setSpriteFrame((isBroadcastEnabled) ? "fierceBattle_btn_bell_on.png" : "fierceBattle_btn_bell_off.png");

            // 埋點
            DataProcess.sendString(JSStringUtility.format("track_fierce_battle %d", (isBroadcastEnabled) ? 6 : 7));

            // 30秒後才可以點
            this.runAction(cc.sequence(
                cc.delayTime(30),
                cc.callFunc(() => {
                    // 恢復可調整狀態
                    this._canChangeBroadcastEnabled = true;
                })
            ));
        }
    },

    // 按說明按鈕
    _explainBtnClicked: function () {
        DialogManager.addDialog(new WebViewDialog(TexasUtility.getSimpleInfoURLByKey("fierce_battle")), false);

        // 埋點
        DataProcess.sendString("track_fierce_battle 5");
    },

    /**
     *  顯示提示
     */
    // 跳活動結束視窗
    _showEventOverDialog: function () {
        DialogManager.addDialog(new Dialog({
            title: LocalizedString.Common("提醒您"),
            content: LocalizedString.FierceBattle("活動已結束"),
            buttons: ["OK"],
            closeButton: 0,
            callback: () => {
                // 更新熱門看板資料
                DataModal.hotBoardData.startGetInfo();

                this._closeDialogAnimation();
            }
        }), false);
    },

    // 顯示橫幅文字提示
    _showBannerHintNode: function (text) {
        var bannerHintNode = new cc.Node();
        bannerHintNode.setPosition(JSScreenMidPos);
        bannerHintNode.setOpacity(0);
        bannerHintNode.setCascadeOpacityEnabled(true);
        this._animationLayer.addChild(bannerHintNode, 10);

        // 提示文字
        var hintLabel = new cc.LabelTTF(text, JSFontBoldName, 14, cc.size(400, 0), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        bannerHintNode.addChild(hintLabel, 1);

        // 文字背景
        var blackBgSp = new ccui.Scale9Sprite("lobby_bg_list_04.png");
        blackBgSp.setPreferredSize(cc.size(JSVisibleSize.width, hintLabel.getContentSize().height + 15));
        bannerHintNode.addChild(blackBgSp);

        bannerHintNode.stopAllActions();
        bannerHintNode.runAction(cc.sequence(
            cc.fadeIn(0.25).easing(cc.easeInOut(0.25)),
            cc.delayTime(1),
            cc.fadeOut(0.25).easing(cc.easeIn(0.25)),
            cc.removeSelf()
        ));
    },

    /**
     * 通知icon資料完成
     */
    notifyFierceBattleInfoDone: function () {
        // 拿掉loading
        this.removeLoadingLayer();

        // 更新畫面
        this._refreshView();
    }
});
