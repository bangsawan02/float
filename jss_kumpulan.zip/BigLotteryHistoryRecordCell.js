/**
 * 9T 幸運彩票 - 歷史紀錄 Cell
 * Domino移植設定 調整文字描邊顏色
 */

var BigLotteryHistoryRecordCell = cc.TableViewCell.extend({
    ctor: function (isRedEnvelope = false) {
        this._super();

        this._isRedEnvelope = isRedEnvelope;

        var cellWidth = BigLotteryHistoryRecordCell.WIDTH;
        var cellHeight = BigLotteryHistoryRecordCell.HEIGHT;
        var midPosX = cellWidth / 2;
        var midPosY = cellHeight / 2;

        // 期數
        var periodLabel = this._periodLabel = new cc.LabelTTF("", JSFontName, 14);
        periodLabel.enableStroke(cc.color(190, 30, 0, 255), 2);
        periodLabel.setPosition(midPosX - 120, midPosY);
        this.addChild(periodLabel);

        // 開獎號碼
        var numLabel = this._numLabel = new cc.LabelTTF("", JSFontName, 14);
        numLabel.enableStroke(cc.color(190, 30, 0, 255), 2);
        numLabel.setPosition(midPosX, midPosY);
        this.addChild(numLabel);

        // 有沒有贏家
        var winnerLabel = this._winnerLabel = new cc.LabelTTF("", JSFontName, 14);
        winnerLabel.enableStroke(cc.color(190, 30, 0, 255), 2);
        winnerLabel.setPosition(midPosX + 120, midPosY);
        this.addChild(winnerLabel);

        // 線條
        var lineSprite = this._lineSprite = new ccui.Scale9Sprite("bigLottery_pic_line.png");
        lineSprite.setPreferredSize(cc.size(cellWidth * 0.9, 4));
        lineSprite.setPosition(midPosX, midPosY - 14);
        this.addChild(lineSprite);
    },

    /**
     * 刷新cell
     * @param param         cell資料
     * @param isLastCell    是不是最後一個cell(用來判斷線條要不要出現)
     */
    refreshCell: function (param, isLastCell) {
        if (param) {
            // 刷新期數
            this._periodLabel.setString(param.period);

            var str = "";
            var color = JSColor.WHITE;
            if (!this._isRedEnvelope) {
                str = LocalizedString.BigLottery(param.hasWinner ? "是" : "否");
                color = (param.hasWinner ? JSColor.YELLOW : JSColor.WHITE);
            } else {
                // 是紅包要秀人數
                str = param.winnerCount.toString();
            }

            // 刷新贏家文字
            this._winnerLabel.setString(str);
            this._winnerLabel.setFontFillColor(color);

            // 刷新開獎數字
            var numString = Array.isArray(param.numList) ? param.numList.join(", ") : param.number;
            this._numLabel.setString(numString);

            // 刷新線條
            this._lineSprite.setVisible(!isLastCell);
        }
    }
});

// Cell寬
BigLotteryHistoryRecordCell.WIDTH = 380;

// Cell高
BigLotteryHistoryRecordCell.HEIGHT = 30;
