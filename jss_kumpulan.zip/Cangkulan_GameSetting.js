// 一開始發牌的張數
var Cangkulan_DealCount = 7;
// 手牌的間隔
var Cangkulan_HandCardOffsetX = 30;
// 手牌放的長度
var Cangkulan_HandCardWidth = 300;
// 手牌大於16張要把可出的牌間距變大
var Cangkulan_MaxHandCard = 16;
// 手牌超過10張後要調整手牌間隔大小
var Cangkulan_HandCardMaxOffsetCount = 10;

// 剩幾張手牌要顯示鈴鐺
var Cangkulan_SHOW_BELL_COUNT = 2;

// 手牌的Y
var Cangkulan_HandCardPosY = 36;
var Cangkulan_HandCardPosX = 3 * Cangkulan_HandCardOffsetX;

// 抽牌區要疊幾張牌
var Cangkulan_DeawDrawStackCount = 12;

// 偏移量
var Cangkulan_Offset = {
    DRAW: cc.p(-33, 10),           // 抽牌區
    FOLD: cc.p(31, 11),            // 棄牌區
    WASH: cc.p(0, -15)             // 洗牌的地方
};

// 牌的花色 1~4: server送來的編號  20~80: cardNode設定的編號
var Cangkulan_CardSuit = {
    "1": 80,    // 黑桃
    "2": 60,    // 紅心
    "3": 20,    // 紅磚
    "4": 40     // 梅花
};

// 馬上玩類型
var CANGKULAN_ROOM_TYPE = {
    NORMAL: 0,              //一般桌
};

var Cangkulan_CardType = {
    DRAW: 1,    // 抽牌區
    FOLD: 2     // 棄牌區
};

// Cangkulan 現在預約離桌 換桌 的類型
var Cangkulan_LeaveGameStatus = {
    CAN_LEAVE: 0,               // 可以直接離桌
    NO_LEAVE: 1,                // 現在是不能離桌狀態
    BOOKING_LEAVE: 2,           // 預約離桌
    BOOKING_CHANGE_TABLE: 3,    // 預約換桌
};