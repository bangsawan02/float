/**
 * 骰寶
 */

var DiceBoLayer = VegasGameBaseLayer.extend({
    ctor: function () {
        this._super();

        this.setCascadeOpacityEnabled(true);

        cc.spriteFrameCache.addSpriteFrames("vegas/dicebo/dicebo.plist", "vegas/dicebo/dicebo.png");

        // 初始化參數
        this._reBetChipsDone = false;           // 是否已經重新下注過了
        this._betButtonArray = [];              // 存放下注籌碼按鈕

        var diceBoString = LocalizedString.DiceBo;

        // 設定機台是哪一個 一定要設
        this._vegasType = VegasGameType.DICEBO;

        // 清掉指令
        DataModal.vegasData.cleanMessageQueue(this._vegasType);

        // 先算出現在預設是要大注還是小注
        var freeTicketCount = DataModal.vegasData.freeTicket.DiceBo;
        var slot12Data = DataModal.vegasData.diceBoBetInfo;
        this._isBigTable = freeTicketCount === 0 && slot12Data.defaultTable === "b";

        // 背景
        var bgSprite = this._bgSprite = new cc.Sprite(this._isBigTable ? "#db_bg_big.png" : "#db_bg_small.png");
        bgSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y);
        bgSprite.setScale(JSVisibleSize.width / bgSprite.getContentSize().width);
        this.addChild(bgSprite, -2);

        // 下方背景條
        var upBgSprite = new ccui.Scale9Sprite("db_bt_menu_bg.png");
        upBgSprite.setPreferredSize(cc.size(JSVisibleSize.width, 40));
        upBgSprite.setPosition(JSScreenMidPos.x, JSVisibleSize.height - 20);
        upBgSprite.setScaleY(-1);
        this.addChild(upBgSprite, -1);

        // 標題
        var titleSprite = new cc.Sprite("#db_logo.png");
        titleSprite.setPosition(JSScreenMidPos.x, JSVisibleSize.height - 14);
        this.addChild(titleSprite);

        // 新增返回按鈕
        this._backMenuItem = this._addBackButton(this._backBtnClicked, this, 7);

        // 右上方賠率按鈕
        var btnSize = cc.size(44, 36);
        var itemNodes = [];
        for (var i = 0; i < 2; i++) {
            var node = itemNodes[i] = new cc.Node();
            node.setCascadeOpacityEnabled(true);
            node.setCascadeColorEnabled(true);
            node.setContentSize(btnSize);

            var bgSprite = new ccui.Scale9Sprite("vegas_bt_record.png");
            bgSprite.setPreferredSize(btnSize);
            bgSprite.setPosition(btnSize.width / 2, btnSize.height / 2);
            node.addChild(bgSprite);

            var wordSprite = new cc.Sprite("#vegas_record_explain.png");
            wordSprite.setPosition(btnSize.width / 2, btnSize.height / 2 + 4);
            node.addChild(wordSprite);

            // 文字
            var wordLabel = new cc.LabelTTF(diceBoString("Info"), JSFontBoldName, 8);
            wordLabel.setPosition(btnSize.width / 2, btnSize.height / 2 - 8);
            node.addChild(wordLabel);
        }
        itemNodes[1].setColor(JSColor.GRAY);
        var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._openRateInfoClicked, this);
        var menu = new cc.Menu(menuItem);
        menu.setPosition(JSVisibleSize.width - 23 - JSScreenSafeWidth, JSVisibleSize.height - 18);
        this.addChild(menu, 7);

        // 右上方記錄畫面按鈕
        for (var i = 0; i < 3; i++) {
            var node = itemNodes[i] = new cc.Node();
            node.setCascadeOpacityEnabled(true);
            node.setCascadeColorEnabled(true);
            node.setContentSize(btnSize);

            var bgSprite = new ccui.Scale9Sprite("vegas_bt_record.png");
            bgSprite.setPreferredSize(btnSize);
            bgSprite.setPosition(btnSize.width / 2, btnSize.height / 2);
            node.addChild(bgSprite);

            var wordSprite = new cc.Sprite("#vegas_record_word.png");
            wordSprite.setPosition(btnSize.width / 2, btnSize.height / 2 + 4);
            node.addChild(wordSprite);

            // 文字
            var wordLabel = new cc.LabelTTF(diceBoString("Record"), JSFontBoldName, 8);
            wordLabel.setPosition(btnSize.width / 2, btnSize.height / 2 - 8);
            node.addChild(wordLabel);
        }
        itemNodes[1].setColor(JSColor.GRAY);
        itemNodes[2].setOpacity(150);
        var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._recordListClicked, this);
        var menu = new cc.Menu(menuItem);
        menu.setPosition(JSVisibleSize.width - 70 - JSScreenSafeWidth, JSVisibleSize.height - 18);
        this.addChild(menu, 5);

        // 下注的桌面
        var miniScaleX = 1.2;                                                       // 最小的ScaleX
        var tableScaleX = Math.min(JSVisibleSize.width / 432, miniScaleX);          // 設定ScaleX不要超過多少
        var tableLayer = this._tableLayer = new DiceBoTableLayer(this._tableBetClicked.bind(this));
        tableLayer.setScale(tableScaleX, JSVisibleSize.height / 288);
        tableLayer.setPosition((JSVisibleSize.width - (432 * tableScaleX)) / 2, 0);
        this.addChild(tableLayer, 1);

        // 下方背景條
        var downBgSprite = new ccui.Scale9Sprite("db_bt_menu_bg.png");
        downBgSprite.setPreferredSize(cc.size(JSVisibleSize.width, 40));
        downBgSprite.setPosition(JSScreenMidPos.x, 46);
        this.addChild(downBgSprite, 1);

        // 免費券Node
        var freeTicketNode = this._freeTicketNode = new VegasFreeTicketNode(VegasGameType.DICEBO);
        freeTicketNode.setPosition(JSScreenMidPos.x - 23, 45);
        freeTicketNode.setEnableAutoRefresh(true);
        freeTicketNode.setScale(1.2);
        this.addChild(freeTicketNode, 8);

        // 下注金額Led
        var ledNode = this._ledNode = new DiceBoLedNode();
        ledNode.setPosition(64, 41);
        this.addChild(ledNode, 1);

        // 下注金額文字
        var tableWordSprite = new cc.Sprite("#db_word_bet.png");
        tableWordSprite.setPosition(64, 58);
        this.addChild(tableWordSprite, 1);

        // 下注bet的node
        var chipsNode = this._chipsNode = new cc.Node();
        this.addChild(chipsNode, 1);

        // 重覆下注按鈕
        var mainMenu = new cc.Menu();
        mainMenu.setPosition(0, 0);
        this.addChild(mainMenu, 2);

        var reBetMenuItem = this._reBetMenuItem = this._createBetMenuItem("#db_bt_reroll_up.png",
            "#db_bt_reroll_down.png", "#vegase_bt_word_reroll.png", [4, 0, 0], this._reBetClicked, this);
        reBetMenuItem.setPosition(365 + JSScreenBonusWidth, 48);
        mainMenu.addChild(reBetMenuItem);

        // 清除按鈕
        var cleanMenuItem = this._cleanMenuItem = this._createBetMenuItem("#db_bt_cancelroll_up.png",
            "#db_bt_cancelroll_down.png", "#vegase_bt_word_clear.png", [4, 0, 0], this._cleanClicked, this);
        cleanMenuItem.setPosition(411 + JSScreenBonusWidth, 48);
        mainMenu.addChild(cleanMenuItem);

        // 開使搖骰按鈕
        var startMenuItem = this._startMenuItem = this._createBetMenuItem("#db_bt_roll_up.png",
            "#db_bt_roll_down.png", "#db_bt_roll_word.png", [8, 2, 2], this._startRollClicked, this);
        startMenuItem.setPosition(470 + JSScreenBonusWidth, 48);
        mainMenu.addChild(startMenuItem);

        // 搖骰的記錄
        var recordLayer = this._recordLayer = new DiceBoRecordLayer();
        this.addChild(recordLayer, 11);

        // 動畫相關的Layer
        var effectLayer = this._effectLayer = new DiceBoEffectLayer();
        this.addChild(effectLayer, 12);

        // 新增下方儲值選單
        this._addPurchaseMenu(this._purchaseClicked, this, 10);

        // 新增場編
        this._addSerialNumber(10);
        this.serialNumber.setPosition(JSVisibleSize.width - 95 - JSScreenSafeWidth, JSVisibleSize.height - 7);

        // 最後創一個檔Touch用的東西 用來防止動畫的時後去按到
        var dummyTouch = this._dummyTouchLayer = new DummyTouchLayer(JSVisibleSize);
        dummyTouch.setVisible(false);
        this.addChild(dummyTouch, 50);

        // 註冊
        GS.addListener("NotifyDiceBoStart", this.notifyDiceBoStart.bind(this), this);
        GS.addListener("NotifyDiceBoResultDone", this.notifyDiceBoResultDone.bind(this), this);
        GS.addListener("NotifyRefreshFreeTicket", this.notifyRefreshFreeTicket.bind(this), this);
        GS.addListener("NotifySlotFailCMD", this.notifySlotFailCMD.bind(this), this);
        GS.addListener("NotifySlot12InfoDone", this.notifySlot12InfoDone.bind(this), this);
    },

    onEnter: function () {
        this._super();

        // 加Android
        PushScene.addBackKeyEnableLayer(this);
    },

    onExit: function () {
        PushScene.removeBackKeyEnableLayer(this);

        cc.spriteFrameCache.removeSpriteFramesFromFile("vegas/dicebo/dicebo.plist");

        this._super();
    },

    /**
     * 進遊戲
     * @override
     */
    _enterVegasGame: function () {
        // 加Loading(等slot12_info回來)
        GSLoading.addLoadingView();

        // 加UI(確認近GameServer才能要資料)
        {
            // 側邊欄
            this._addSideOptionLayer(50);

            // 新增聚寶盆icon
            var treasureBowlIcon = new TreasureBowlGameIconNode();
            treasureBowlIcon.setGameTypeAddProgressBar(VegasGameType.DICEBO);
            treasureBowlIcon.setScale(0.6);
            treasureBowlIcon.setPosition(JSVisibleSize.width - JSScreenSafeWidth - 85, 15);
            this.addChild(treasureBowlIcon, 11);

            // 牌王之路icon
            // 牌桌內的娛樂城返回按鈕比較大顆
            var offsetX = (PushScene.isGame) ? 14 : 0;
            this._addGamblerRoadIconNode(7, offsetX);
        }

        // 重要資料
        DataProcess.sendString("slot12_info");
    },

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        // 先判斷返回是否能按
        if (this._dummyTouchLayer.isVisible())
            return;

        this._super();
    },

    /**
     * 重置所有東西 用在結算過後
     */
    _clean: function () {
        // 先把檔Touch關掉
        this._dummyTouchLayer.setVisible(false);

        // 清掉桌面
        this._tableLayer.clean();

        // LED歸0
        this._ledNode.setMoney(0, false);

        // 設定沒有重新下注
        this._reBetChipsDone = false;

        // 更新按鈕
        this._updateBetMenuItems();
    },

    /**
     * 更新免費券的使用量
     */
    _refreshFreeTicket: function (isClean) {
        var freeTicketCount = DataModal.vegasData.freeTicket.DiceBo;
        if (freeTicketCount) {
            var usedFreeTicketCount = this._tableLayer.getUsedFreeTicketCount();

            if (isClean) {
                // 按到清除案件
                this._betButtonArray[0] && this._chipBetClicked(this._betButtonArray[0]);
                this._scrollView && this._scrollView.setContentOffsetInDuration(cc.p(0, 0), 0);
            } else {
                // 不是按到清除按鈕的需要扣券數量
                freeTicketCount -= usedFreeTicketCount;
                if (freeTicketCount > 0)
                    this._betButtonArray[0] && this._chipBetClicked(this._betButtonArray[0]);
            }

            // 要更新畫面
            this._freeTicketNode && this._freeTicketNode.setFreeTicketCount(freeTicketCount < 0 ? 0 : freeTicketCount);
        }
        this._isUseFreeTicket = freeTicketCount >= 1;
        this._freeTicketNode && this._freeTicketNode.setVisible(this._isUseFreeTicket);

        // 有使用免費券 隱藏籌碼
        this._chipsNode && this._chipsNode.setVisible(!this._isUseFreeTicket);
    },

    /**
     * 創按鈕類的東西
     */
    // 創下注金額按鈕
    _createBetChipMenuItem: function (chipName, chipString, callback, target) {
        var itemNodes = [];

        for (var i = 0; i < 3; i++) {
            var node = itemNodes[i] = new cc.Node();
            node.setCascadeColorEnabled(true);
            node.setCascadeOpacityEnabled(true);

            var bgSprite = new cc.Sprite(chipName);
            var size = bgSprite.getContentSize();
            bgSprite.setPosition(size.width / 2, size.height / 2);
            node.addChild(bgSprite);

            // 上面的數字(number, prefixName, numberSize, dotSize, unitSize, dotLength = 2, maxWidth = 0, numberFormat)
            var numberNode = new NumberSimpleNode(chipString, "vegas_chip_num", cc.size(10, 12), cc.size(5, 10), [cc.size(5, 10), cc.size(10, 10), cc.size(25, 10)], 2, size.width, "%d");
            numberNode.setPosition(size.width / 2, size.height / 2);
            node.addChild(numberNode);

            node.setContentSize(size);
        }
        itemNodes[0].setColor(cc.color(100, 100, 100));
        itemNodes[1].setColor(cc.color(200, 200, 200));

        return new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], callback, target);
    },

    // 創下注系列的按鈕
    _createBetMenuItem: function (bgName, pressBgName, wordName, offsetY, callback, target) {
        var itemNodes = [];

        for (var i = 0; i < 3; i++) {
            var node = itemNodes[i] = new cc.Node();
            node.setCascadeColorEnabled(true);
            node.setCascadeOpacityEnabled(true);

            var bgSprite = new cc.Sprite(i === 0 ? bgName : pressBgName);
            var wordSprite = new cc.Sprite(wordName);
            node.addChild(bgSprite);
            node.addChild(wordSprite);

            var size = bgSprite.getContentSize();
            bgSprite.setPosition(size.width / 2, size.height / 2);
            wordSprite.setPosition(size.width / 2, offsetY[i] + size.height / 2);

            node.setContentSize(size);
        }

        return new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], callback, target);
    },

    /**
     * 按鈕
     */
    // 按到儲值
    _purchaseClicked: function () {
        // 決勝排行榜埋點
        if (this._getIsVegasRankOpen())
            DataProcess.sendString("slot12_click_bill");

        // 要去儲值頁
        PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
    },

    // 按到說明
    _openRateInfoClicked: function () {
        DialogManager.addDialog(new VegasIntroDialog(VegasGameType.DICEBO));
    },

    // 左右滑動箭頭
    _arrowChipClicked: function (sender) {
        var pos = this._scrollView.getContentOffset();
        var posX = Math.ceil(pos.x);

        var moveX;
        if (sender === this._chipArrowButtons[1]) {
            // 右邊箭頭
            if (posX < this._maxOffsetWidth)
                return;

            // 移動一個籌碼的位置
            var offsetX = (Math.ceil(posX / 50) - 1) * 50;
            moveX = offsetX <= this._maxOffsetWidth ? this._maxOffsetWidth : offsetX;

            this._scrollView.setContentOffsetInDuration(cc.p(moveX, 0), 0.3);
        } else {
            // 左邊箭頭
            if (posX > 0)
                return;

            // 移動一個籌碼的位置
            var offsetX = (Math.floor(posX / 50) + 1) * 50;
            moveX = offsetX >= 0 ? 0 : offsetX;
        }

        // 移動一個籌碼的位置
        this._scrollView.setContentOffsetInDuration(cc.p(moveX, 0), 0.3);

        // 關閉點擊事件
        this._chipArrowButtons[0].setEnabled(false);
        this._chipArrowButtons[1].setEnabled(false);
        this._scrollView.setTouchEnabled(false);

        // 滑動完畢開啟點擊
        this.runAction(cc.sequence(
            cc.delayTime(0.4),
            cc.callFunc(() => {
                // 滑動後確認最後的箭頭可否點擊
                var pos = this._scrollView.getContentOffset();
                var posX = Math.floor(pos.x);

                this._chipArrowButtons[0].setEnabled(posX < -1);
                this._chipArrowButtons[1].setEnabled(posX > this._maxOffsetWidth + 1);
                this._scrollView.setTouchEnabled(true);
            })
        ));
    },

    // 按到出現記錄
    _recordListClicked: function (sender) {
        sender.setEnabled(false);
        this._recordLayer.show(true, function () {
            // 等關掉後把按鈕打開
            sender.setEnabled(true);
        });
    },

    // 下注籌碼
    _chipBetClicked: function (sender) {
        var clickedIndex = 0;
        this._betButtonArray.forEach(function (cur, index) {
            cur.setPositionY(15);
            cur.setEnabled(true);
            if (cur === sender)
                clickedIndex = index;
        });
        sender.setPositionY(25);
        sender.setEnabled(false);

        // 告知Table現在的下注籌碼
        this._tableLayer.setBetChipsIndex(clickedIndex);
    },

    // 重新下注
    _reBetClicked: function () {
        this._tableLayer.reBetChips();

        // 已重新下注打開
        this._reBetChipsDone = true;

        // 重置按鈕
        this._updateBetMenuItems();

        // 更新用掉多少免費券
        this._refreshFreeTicket();
    },

    // 清除
    _cleanClicked: function () {
        // 清掉免費券
        this._tableLayer.clearUsedFreeTicketCount();

        // 清掉Table上的東西
        this._tableLayer.clean();

        // 已重新下注關掉
        this._reBetChipsDone = false;

        // 清掉LED
        this._ledNode.setMoney(0, false);

        // 更新按鈕
        this._updateBetMenuItems();

        // 更新用掉多少免費券
        this._refreshFreeTicket(true);
    },

    // 開始搖骰
    _startRollClicked: function () {
        this._tableLayer.sendStartCMD();

        // 存下遊戲紀錄
        this._savePlayerRecord();

        // 先把檔Touch打開
        this._dummyTouchLayer.setVisible(true);

        // AppsFlyer埋點
        GSAppsFlyerWrapper.logEvent("casino");
    },

    // 按到桌子的感應區
    _tableBetClicked: function (zoneType) {
        // 用來更新按鈕
        this._updateBetMenuItems();

        // 更新用掉多少免費券
        this._refreshFreeTicket();
    },

    /**
     * 處理 重新下注 清除 搖骰 按鈕的開關
     */
    _updateBetMenuItems: function () {
        var canStart = this._tableLayer.getCanStart();
        this._cleanMenuItem.setEnabled(canStart);
        this._startMenuItem.setEnabled(canStart);

        // 可否重新下注判斷
        var canReBet = this._tableLayer.getCanReBetChips();
        this._reBetMenuItem.setEnabled(canReBet && !this._reBetChipsDone);
    },

    // 滑動結束
    scrollViewDidEndScroll: function () {
        var posX = this._scrollView.getContentOffset().x;

        this._chipArrowButtons[0].setEnabled(posX < -1);
        this._chipArrowButtons[1].setEnabled(posX > this._maxOffsetWidth + 1);
    },

    /**
     * 通知
     */
    // 開始搖骰
    notifyDiceBoStart: function (event) {
        var diceParam = event.getUserData();

        var self = this;

        // 搖完骰後做的事
        var diceAnimationDoneFunc = function () {
            self._tableLayer.showFinishResult(diceParam, getRewardDoneFunc);
        };

        // 派發完籌碼後要做的事
        var getRewardDoneFunc = function (totalBetMoney, isTriple) {
            // 要出現 贏 or 輸 的動畫
            self._effectLayer.showFinishResult(diceParam, totalBetMoney, isTriple);
        };

        // 搖骰動畫
        this._effectLayer.showDiceAnimation(diceParam, diceAnimationDoneFunc);

        // 計算免費券的使用
        var betMoney = this._tableLayer.getNowTotalBetMoney();
        var freeTicketCount = DataModal.vegasData.freeTicket.DiceBo;
        var info = DataModal.vegasData.diceBoBetInfo;
        var freeBetMoney = (info) ? info.betArray[0] : 1000000;

        // 更新聚寶盆 透過網址
        DataModal.treasureBowlData.treasureBowlParam && DataModal.treasureBowlData.updateDataBy(betMoney);

        // 扣掉身上的錢 要把免費券的扣掉
        if (!this._isBigTable && freeTicketCount) {
            var usedFreeTicketCount = this._tableLayer.getUsedFreeTicketCount();
            if (usedFreeTicketCount > freeTicketCount)
                usedFreeTicketCount = freeTicketCount;
            betMoney -= usedFreeTicketCount * freeBetMoney;
        }
        DataModal.profileData.money -= betMoney;

        // 清掉Table裡面記下來用掉的免費券
        this._tableLayer.clearUsedFreeTicketCount();

        // 更新免費券
        DataProcess.sendString("slot12_free");

        // 通知UI更新金錢
        GS.dispatchCustomEvent("NotifySetTMoney");
    },

    // 結算畫面結束
    notifyDiceBoResultDone: function () {
        // 通知外面動畫結束，檢查有沒有事情要做
        this.notifyVegasGameFinished();

        this._clean();
    },

    // 更新免費券
    notifyRefreshFreeTicket: function () {
        this._refreshFreeTicket();
    },

    // 下注失敗
    notifySlotFailCMD: function (event) {
        if (event && event.getUserData()) {
            // 把按鈕打開
            this._clean();
        }

        // 更新免費券
        DataProcess.sendString("slot12_free");
    },

    // 更新下注資訊
    notifySlot12InfoDone: function () {
        // 拿掉Loading(對應DiceBoLayer裡enterVegasGame)
        GSLoading.removeLoadingView();

        var chipsNode = this._chipsNode;
        chipsNode.removeAllChildren();

        // 先算出現在預設是要大注還是小注
        var slot12BetData = DataModal.vegasData.diceBoBetInfo;
        var freeTicketCount = DataModal.vegasData.freeTicket.DiceBo;
        this._isBigTable = freeTicketCount === 0 && (slot12BetData.defaultTable === "b");
        var defaultIndex = (freeTicketCount === 0) ? slot12BetData.defaultIndex : 1;

        // scrollView
        var scrollLayer = new cc.Layer();
        var scrollSize = cc.size(150, 50);
        var scrollView = this._scrollView = new cc.ScrollView(scrollSize, scrollLayer);
        scrollView.setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
        scrollView.setDelegate(this);
        scrollView.setBounceable(false);
        scrollView.setPosition(170 + JSScreenBonusHalfWidth, 27);
        chipsNode.addChild(scrollView);

        var chipsString = slot12BetData.betArray;
        var chipsLen = chipsString.length;

        var maxWidth = 50 * chipsLen;
        this._maxOffsetWidth = scrollSize.width - maxWidth;
        scrollView.setContentSize(cc.size(maxWidth, 50));

        var defaultBetChip;
        var curBetChip;
        var defaultPos;
        var tableBetChips = [];
        this._betButtonArray = [];
        chipsString.forEach((curChip, index) => {

            var chipsNode = [];
            for (var i = 0; i < 2; i++) {
                var chipNode = chipsNode[i] = new ccui.Scale9Sprite();
                chipNode.setCascadeColorEnabled(true);
                chipNode.setCascadeOpacityEnabled(true);
                chipNode.setPreferredSize(cc.size(50, 50));

                var chipRes;
                var tableChipRes;
                if (curChip <= 1000000) {
                    // 紅籌碼
                    chipRes = "#vegas_cycle_chip_red.png";
                    tableChipRes = "#vegas_chip_red.png";
                } else if (curChip > 1000000 && curChip <= 10000000) {
                    // 藍色
                    chipRes = "#vegas_cycle_chip_blue.png";
                    tableChipRes = "#vegas_chip_blue.png";
                } else if (curChip > 10000000 && curChip <= 100000000) {
                    // 綠色
                    chipRes = "#vegas_cycle_chip_green.png";
                    tableChipRes = "#vegas_chip_green.png";
                } else if (curChip > 100000000 && curChip <= 250000000) {
                    // 橘色
                    chipRes = "#vegas_cycle_chip_orange.png";
                    tableChipRes = "#vegas_chip_orange.png";
                } else if (curChip > 250000000 && curChip <= 500000000) {
                    // 紅黑色
                    chipRes = "#vegas_cycle_chip_red_gray.png";
                    tableChipRes = "#vegas_chip_red_gray.png";
                } else if (curChip > 500000000) {
                    // 粉色
                    chipRes = "#vegas_cycle_chip_pink.png";
                    tableChipRes = "#vegas_chip_purple.png";
                }

                if (!chipRes)
                    return;

                // 籌碼圖
                var chipSprite = new cc.Sprite(chipRes);
                chipSprite.setPosition(25, 25);
                chipNode.addChild(chipSprite);

                // 上面的數字(number, prefixName, numberSize, dotSize, unitSize, dotLength = 2, maxWidth = 0, numberFormat)
                var numberNode = new NumberSimpleNode(curChip, "vegas_chip_num", cc.size(10, 12), cc.size(7, 10), [cc.size(9, 10), cc.size(9, 10), cc.size(25, 10)], 2, 50, "%d");
                numberNode.setScale(0.8);
                numberNode.setPosition(25, 25);
                chipNode.addChild(numberNode);

                // 籌碼亮燈
                if (i === 1) {
                    var lightSprite = new cc.Sprite("#vegas_chip_light.png");
                    lightSprite.setPosition(25, 25);
                    chipNode.addChild(lightSprite);
                }
            }

            var chipButton = new GSControlButton(chipsNode[0]);
            chipButton.setPosition(25 + 50 * index, (index === defaultIndex) ? 25 : 15);
            chipButton.addTouchUpInsideAction(this._chipBetClicked, this);
            chipButton.setBackgroundSpriteForState(chipsNode[1], cc.CONTROL_STATE_DISABLED);
            chipButton.enableTouchCancel(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
            scrollLayer.addChild(chipButton);

            if (index === defaultIndex) {
                defaultPos = 50 * index;
                curBetChip = chipButton;
                defaultBetChip = chipButton;
            }

            tableBetChips.push(tableChipRes);
            this._betButtonArray.push(chipButton);
        });

        // 設定桌面上籌碼的顏色
        this._tableLayer.seTableBetChips(tableBetChips);

        // 左右按鈕
        this._chipArrowButtons = [];
        for (var i = 0; i < 2; i++) {
            // 擋touch
            var dummyTouch = new DummyTouchLayer(cc.size(182 + JSScreenBonusHalfWidth, 50));
            dummyTouch.setPosition(-12 + (332 + JSScreenBonusHalfWidth) * i, 25);
            chipsNode.addChild(dummyTouch);

            var chipNode = new ccui.Scale9Sprite();
            chipNode.setCascadeColorEnabled(true);
            chipNode.setCascadeOpacityEnabled(true);
            chipNode.setPreferredSize(cc.size(18, 26));

            var arraowSprite = new cc.Sprite("#vegas_arrow_01.png");
            arraowSprite.setFlippedX(i);
            arraowSprite.setPosition(9, 13);
            chipNode.addChild(arraowSprite);

            var chipNodeGray = new ccui.Scale9Sprite();
            chipNodeGray.setCascadeColorEnabled(true);
            chipNodeGray.setCascadeOpacityEnabled(true);
            chipNodeGray.setPreferredSize(cc.size(18, 26));

            var arraowGraySprite = new cc.Sprite("#vegas_arrow_02.png");
            arraowGraySprite.setFlippedX(i);
            arraowGraySprite.setPosition(9, 13);
            chipNodeGray.addChild(arraowGraySprite);

            var arrowButton = new GSControlButton(chipNode);
            arrowButton.setPosition(158 + (172 * i) + JSScreenBonusHalfWidth, 44);
            arrowButton.setBackgroundSpriteForState(chipNodeGray, cc.CONTROL_STATE_DISABLED);
            arrowButton.addTouchUpInsideAction(this._arrowChipClicked, this);
            chipsNode.addChild(arrowButton);

            this._chipArrowButtons.push(arrowButton);
        }

        // 預設點擊的籌碼
        defaultBetChip && this._chipBetClicked(defaultBetChip);

        // 清掉Table上的東西 要在免費券上面
        this._tableLayer.clean();

        // 先判斷是否使用免費券
        this._refreshFreeTicket();

        // 滑動到預設的地方(第一個籌碼不用滑動)
        var scrollOffset = (this._isUseFreeTicket) ? 0 : -defaultPos;
        this._scrollView.setContentOffsetInDuration(cc.p(scrollOffset, 0), 0);

        // 下注按鈕
        chipsNode.setVisible(!this._isUseFreeTicket);

        // 下注按鈕預設第二個 假如有免費券 小注要變第一個
        if (this._isUseFreeTicket)
            this._chipBetClicked(this._betButtonArray[0]);
        else
            curBetChip && this._chipBetClicked(curBetChip);

        // 清掉LED
        this._ledNode.setMoney(0, false);

        // 按鈕重置
        this._reBetChipsDone = false;
        this._updateBetMenuItems();

        // 顯示下注的教學
        var haveShowHint = parseInt(GS.localStorage.getItem("ShowDiceBoTeach", "0")) === 1;
        if (!haveShowHint && !this._isUseFreeTicket) {
            var touchFunc = () => {
                // 停止scroll的滑動
                var posX = this._scrollView.getContentOffset().x;
                this._scrollView.setContentOffsetInDuration(cc.p(posX, 0), 0);

                // 已完成教學
                GS.localStorage.setItem("ShowDiceBoTeach", "1");
            };

            // 顯示教學提示
            this._effectLayer.showTeachBetHint(touchFunc);
            this._scrollView.setContentOffsetInDuration(cc.p(this._maxOffsetWidth, 0), 2);
        }
    }
});