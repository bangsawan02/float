/**
 * 用來撥放Player上面出現的動畫
 */

var Domino_PlayerAnimLayer = cc.Layer.extend({
    ctor: function () {
        this._super();
        this.setCascadeOpacityEnabled(true);

        this._animNodeArray = [];
        for (var i = 0; i < DataModal.gameData.playerNumber; i++) {
            // 在玩家身上的動畫都會放在這裡(贏框動畫、All In動畫、把錢丟到桌上的動畫)
            var animNode = this._animNodeArray[i] = new Domino_PlayerAnimNode();
            animNode.setPosition(Domino_GameUtility.getPlayerPosition(i));
            this.addChild(animNode);
        }
    },

    /**
     * 撥放玩家上面的動畫
     * @param serverPos 位置
     * @param type 哪一種動畫 Domino_PlayerAnimNode.Type
     * @param value 這動畫有帶參數的話需要
     */
    playAnimation: function (serverPos, type, value) {
        var playerPos = DataModal.gameData.getDirectionByServerDirection(serverPos);
        var aniNode = this._animNodeArray[playerPos];
        switch (type) {
            case Domino_PlayerAnimNode.Type.SIT:
                aniNode.playSitAnim();
                break;
            case Domino_PlayerAnimNode.Type.GET_CHIPS:
                aniNode.playGetChips(value);
                break;
            case Domino_PlayerAnimNode.Type.EXP:
                aniNode.playExp(value);
                break;
            case Domino_PlayerAnimNode.Type.LEVEL_UP:
                aniNode.playLevelUp(value);
                break;
            case Domino_PlayerAnimNode.Type.GAME_RANK_SCORE_CHANGE:
                aniNode.playGameRankScoreChange(value);
                break;
        }
    },
});