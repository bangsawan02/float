/**
 * 牌王戰帖
 */

var CardKingInviteDialog = BaseDialogLayer.extend({
    ctor: function (data) {
        this._super();

        // 設定參數
        this.key = "CardKingInviteDialog";
        this._data = data;

        this.dialogBgColor = cc.color(0, 0, 0, 180);

        this.loadFileArray = ["cardKing/cardKing.plist", "cardKing/cardKing.png"];
    },

    onExit: function () {
        this._loadFileDone && cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[0]);

        this._super();
    },

    loadFileDone: function () {
        this._super();

        cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[0], this.loadFileArray[1]);

        var aniLayer = this._animationLayer;
        var cardKingString = LocalizedString.CardKing;

        // 太陽光
        var sunSprite = new cc.Sprite("#cardKing_pic_light_01.png");
        sunSprite.setScaleX(1.4);
        sunSprite.setPosition(JSScreenMidPos.x, 230 + JSScreenBonusHalfHeight);
        aniLayer.addChild(sunSprite);

        // 橘光
        [cc.p(133, 137), cc.p(375, 147)].forEach(pos => {
            var orangeLightSprite = new cc.Sprite("#cardKing_pic_light_03.png");
            orangeLightSprite.setScale(24);
            orangeLightSprite.setPosition(pos.x + JSScreenBonusHalfWidth, pos.y + JSScreenBonusHalfHeight);
            aniLayer.addChild(orangeLightSprite);
        });

        // 背景
        var bgSprite = new ccui.Scale9Sprite("cardKing_pic_frame_02.png");
        bgSprite.setPreferredSize(cc.size(328, 192));
        bgSprite.setPosition(JSScreenMidPos.x, 136 + JSScreenBonusHalfHeight);
        aniLayer.addChild(bgSprite);

        // 光暈
        var lightSprite = new cc.Sprite("#lobby_bg_pink01.png");
        lightSprite.setAnchorPoint(0.5, 1);
        lightSprite.setScale(2, 2.6);
        lightSprite.setPosition(JSScreenMidPos.x, 224 + JSScreenBonusHalfHeight);
        aniLayer.addChild(lightSprite);

        // 標題
        var titleSprite = new cc.Sprite("#cardKing_word_invite.png");
        titleSprite.setPosition(JSScreenMidPos.x, 214 + JSScreenBonusHalfHeight);
        aniLayer.addChild(titleSprite);

        // 星星
        var starSprite = new cc.Sprite("#cardKing_pic_star.png");
        starSprite.setPosition(JSScreenMidPos.x, 220 + JSScreenBonusHalfHeight);
        aniLayer.addChild(starSprite);

        // 內文
        var contentStr = JSStringUtility.format(cardKingString("#!FFEE00!#[%s]\n#!FFFFFF!#正在%s/%s牌桌等您\n是否入桌挑戰他，勇奪牌王地位?"),
            this._data.userNickName,
            TexasUtility.getSimpleMoneyString(this._data.smallBlind),
            TexasUtility.getSimpleMoneyString(this._data.bigBlind)
        );
        var contentLabel = new GSRichTextNode(contentStr, JSFontName, 12);
        contentLabel.setHAlignmentToCenter(true);
        contentLabel.setPosition(JSScreenMidPos.x, 145 + JSScreenBonusHalfHeight);
        aniLayer.addChild(contentLabel);

        // 拒絕按鈕
        var cancelBtn = ButtonUtility.createSimpleButton("lobby_btn_08.png", cc.size(100, 30), cardKingString("委婉拒絕"), JSColor.WHITE, 14);
        cancelBtn.setPosition(193 + JSScreenBonusHalfWidth, 79 + JSScreenBonusHalfHeight);
        cancelBtn.addTouchUpInsideAction(this.cancelClicked, this);
        aniLayer.addChild(cancelBtn);

        // 馬上前往按鈕
        var confirmBtn = ButtonUtility.createSimpleButton("lobby_btn_01.png", cc.size(100, 30), cardKingString("馬上前往"), JSColor.BLACK, 14);
        confirmBtn.setPosition(318 + JSScreenBonusHalfWidth, 79 + JSScreenBonusHalfHeight);
        confirmBtn.addTouchUpInsideAction(this.confirmClicked, this);
        aniLayer.addChild(confirmBtn);
    },

    // 立即前往
    confirmClicked: function () {
        // 埋點
        DataProcess.sendString('track_crown_king {"type":"14"}');

        var notEnoughMoney = this._data.needMoney - DataModal.profileData.money;
        // 夠錢
        if (notEnoughMoney <= 0) {
            // 先設成德撲
            GS.nowGame = GSEnum.Game.Texas19;
            DataModal.setGameData(GSEnum.Game.Texas19);

            // 送入桌cmd
            DataProcess.sendString(JSStringUtility.format("joinRoomP %s", this._data.roomID));

            GSLoading.addLoadingView();
        } else {
            // 跳金額不足
            DialogManager.addDialog(new AvatarDialog(DialogHelper("RoomNoMoney", JSCodeUtility.getCurrencyString(notEnoughMoney))));
        }

        this._closeDialogAnimation();
    },

    // 委婉拒絕
    cancelClicked: function () {
        // 埋點
        DataProcess.sendString('track_crown_king {"type":"15"}');

        this._closeDialogAnimation();
    }
});