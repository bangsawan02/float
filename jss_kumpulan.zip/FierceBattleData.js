/**
 * 5.4.0 副系統 - 激戰任務資料
 * https://hackmd.io/3xnUB0vPR8-rhZm1fPFBOg
 * created by Jim.Chen
 */

var FierceBattleData = cc.Class.extend({
    ctor: function () {

        // 初始化
        this.clean();

        //註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            "fierce_battle_icon_status": this.cmd_fierce_battle_icon_status,
            "fierce_battle_info": this.cmd_fierce_battle_info,
            "fierce_battle_update_rank": this.cmd_fierce_battle_update_rank,
            "fierce_battle_add_score": this.cmd_fierce_battle_add_score
        });
    },

    // 初始資料
    clean: function () {
        this.isCanBroadcast = true;                        // 是否開啟推播

        // icon整包資料
        this.iconParam = {
            gameIconParams: {}                             // 放各玩法icon資料
        };

        // 整包info資料
        this.infoParam = {
            gameInfoParams: {}                            // 放各玩法活動資料
        };
    },

    // 抓有哪些玩法物件，並回傳物件的keyArray 有問題回傳空陣列
    getObjKeyList: function (obj) {
        if (JSCodeUtility.isObject(obj)) {
            return Object.keys(obj);
        }
        return [];
    },

    /**
     * 取得組好的 local storage key
     * @param defaultKey 傳 UserDefaultKey
     */
    getStorageKey: function (defaultKey) {
        return JSStringUtility.format("%s%s", defaultKey, DataModal.profileData.account);
    },

    /**
     * 判斷玩法是否顯示結算後小紅點
     * @param gameType 遊戲編號
     */
    getPeriodEndRedPointStatus: function (gameType) {
        // 抓玩法結算資料
        var lastEndPeriodKey = this.getStorageKey(UserDefaultKey.FierceBattleLastEndPeriodData);
        var lastEndPeriodData = JSON.parse(GS.localStorage.getItem(lastEndPeriodKey, "{}"));
        var gameLastEndPeriodObj = (lastEndPeriodData[gameType]) ? lastEndPeriodData[gameType] : {};

        return !!gameLastEndPeriodObj.showRedPoint;
    },

    /**
     * 確認活動是否開啟
     */
    getEventIsOpen: function () {
        var iconParam = this.iconParam;
        return DataModal.profileData.level >= 3
            && iconParam && iconParam.eventStatus !== undefined
            && iconParam.eventStatus !== FierceBattleData.EventStatusType.CLOSE;
    },

    /**
     * 調整玩法結算小紅點狀態
     * @param gameType
     * @param status
     */
    setPeriodEndRedPointStatus: function (gameType, status) {
        // 抓玩法結算資料
        var lastEndPeriodKey = this.getStorageKey(UserDefaultKey.FierceBattleLastEndPeriodData);
        var lastEndPeriodData = JSON.parse(GS.localStorage.getItem(lastEndPeriodKey, "{}"));
        var gameLastEndPeriodObj = (lastEndPeriodData[gameType]) ? lastEndPeriodData[gameType] : {};
        gameLastEndPeriodObj.showRedPoint = status;

        // 本機存新資料
        lastEndPeriodData[gameType] = gameLastEndPeriodObj;
        GS.localStorage.setItem(lastEndPeriodKey, JSON.stringify(lastEndPeriodData));
    },

    // 開關推播功能
    setBroadcastEnabled: function (enabled) {
        // 改變狀態
        GS.localStorage.setItem(this.getStorageKey(UserDefaultKey.FierceBattleBroadcastFlag), (enabled) ? "1" : "0");
        this.isCanBroadcast = enabled;

        if (enabled) {
            // 送推播
            this._sendBroadcast();
        } else {
            // 清除推播
            this._cleanBroadcast();
        }
    },

    /**
     * 去要icon資料
     * @param gameType 傳玩法編號
     * @param isGetAllData 是否拿全玩法資料
     */
    startGetIconInfo: function (gameType = "19", isGetAllData = false) {
        // 要全玩法
        if (isGetAllData) {
            FierceBattleData.AllGameTypeList.forEach((gameType) => {
                DataProcess.sendString("fierce_battle_icon_status " + JSON.stringify({game_type: gameType.toString()}));
            });
        } else {
            // 單一玩法
            DataProcess.sendString("fierce_battle_icon_status " + JSON.stringify({game_type: gameType.toString()}));
        }
    },

    /**
     * 去要排行資料
     * @param gameType 傳玩法編號
     * @param isGetAllData 是否拿全玩法資料
     */
    startGetInfo: function (gameType = "19", isGetAllData = false) {
        // 要全玩法
        if (isGetAllData) {
            FierceBattleData.AllGameTypeList.forEach((gameType) => {
                DataProcess.sendString("fierce_battle_info " + JSON.stringify({game_type: gameType.toString()}));
            });
        } else {
            // 單一玩法
            DataProcess.sendString("fierce_battle_info " + JSON.stringify({game_type: gameType.toString()}));
        }
    },

    // 送推播資料
    _sendBroadcast: function () {
        // 清掉之前的推播
        this._cleanBroadcast();

        var storageKey = this.getStorageKey(UserDefaultKey.FierceBattleBroadcastData);
        var broadcastData = JSON.parse(GS.localStorage.getItem(storageKey, "{}"));
        var gameBroadcastObjs = broadcastData.gameBroadcastObjs;                            // 所有玩法推播資料
        var broadcastNum = 0;                                                               // 總推播數量 用來生成推播ID

        // 送各玩法的推播
        for (var gameTypeKey in gameBroadcastObjs) {
            if (gameBroadcastObjs.hasOwnProperty(gameTypeKey)) {
                var gameBroadcastObj = gameBroadcastObjs[gameTypeKey];
                var broadcastTimeList = gameBroadcastObj.broadcastTimeList;
                for (var i = 0; i < broadcastTimeList.length; i++) {

                    // 與socket時間算出真實推播秒數
                    var triggerTime = JSCodeUtility.getRemainTime(broadcastTimeList[i], gameBroadcastObj.socketTime);
                    if (triggerTime > 0) {
                        // 根據時間差 送推播
                        JSNotify.scheduleNotify({
                            msg: LocalizedString.FierceBattle("激戰任務即將開始，趕快回來參加唷"),
                            bg: "https://d.mwsrv.com/19_60/store/announce/4country/5.4.0/battlemission.jpg",
                            id: JSStringUtility.format("50013%04d", ++broadcastNum),
                            trigger: triggerTime
                        });
                    }
                }
            }
        }

        // 儲存個數
        broadcastData.broadcastNum = broadcastNum;
        GS.localStorage.setItem(storageKey, JSON.stringify(broadcastData));
    },

    // 清掉推播資料
    _cleanBroadcast: function () {
        // 抓現在目前幾筆推播
        var storageKey = this.getStorageKey(UserDefaultKey.FierceBattleBroadcastData);
        var broadcastData = JSON.parse(GS.localStorage.getItem(storageKey, "{}"));

        var broadcastNum = (broadcastData.broadcastNum) ? broadcastData.broadcastNum : 0;

        // 清掉
        for (var i = 1; i <= broadcastNum; i++) {
            JSNotify.removeNotify(JSStringUtility.format("50013%04d", i));
        }

        broadcastData.broadcastNum = 0;
        GS.localStorage.setItem(storageKey, JSON.stringify(broadcastData));
    },

    /**
     * 收到icon資料
     * C -> S fierce_battle_icon_status {"game_type":"19"}
     * S -> C fierce_battle_icon_status
     * {
     * # 0:可累積時段 1:活動完全結束 2:結算中 3:活動結束後24小時內可看排行榜 4:活動時間內，但非結算也非累積時段
     * "error":"2",
     * "game_type":"19",                     # 玩法

       "time_left":"0",                      # 對應需要倒數時間才有會值
       "ranking":"100+",                     # 可累積時段才會有ranking
       "last_settle_end_time" : "1651736820" # 2; 當天前次結算完畢時間 沒有會傳"0"
        }
     */
    cmd_fierce_battle_icon_status: function (key, value) {
        var jsonValue = JSON.parse(value);

        // 0:可累積時段 1:活動完全結束 2:結算 3:活動結束後24小時內可看排行榜 4:活動時間內，但非結算也非累積時段
        var eventStatus = JSCodeUtility.getIntValue(jsonValue["error"]);
        var isShowIcon = eventStatus !== FierceBattleData.EventStatusType.CLOSE;

        if (isShowIcon) {
            // 存該玩法的icon資料
            var gameIconParam = {};

            // 活動狀態
            var eventStatus = gameIconParam.eventStatus = eventStatus;
            gameIconParam.isShowIcon = isShowIcon;

            // 玩法編號
            var gameType = gameIconParam.gameType = JSCodeUtility.getIntValue(jsonValue["game_type"]);

            // 倒數時間
            gameIconParam.socketTime = JSCodeUtility.getNowTime();
            // 顯示用倒數
            var remainTime = gameIconParam.remainTime = JSCodeUtility.getIntValue(jsonValue["time_left"]);

            // 當前的名次 可累積時段才會有
            gameIconParam.myRank = JSCodeUtility.getStringValue(jsonValue["ranking"]);

            // (活動是非結算也非累積時段 & 倒數 > 0) -> 稍後還有比賽進行
            gameIconParam.hasNextContest = eventStatus === FierceBattleData.EventStatusType.NORMAL && remainTime > 0;

            // 整個活動狀態
            this.iconParam.eventStatus = eventStatus;
            // 存下玩法Icon資料
            this.iconParam.gameIconParams[gameType] = gameIconParam;

            // 最新一期結算完的時段(結算後小紅點用) 當天第一次會是0
            var lastEndPeriodTxt = gameIconParam.lastEndPeriodTxt = JSCodeUtility.getStringValue(jsonValue["last_settle_end_time"]);

            // 抓各玩法最後一次結算資料
            var todayStr = JSCodeUtility.getNowDateString();
            var lastEndPeriodKey = this.getStorageKey(UserDefaultKey.FierceBattleLastEndPeriodData);
            var lastEndPeriodData = JSON.parse(GS.localStorage.getItem(lastEndPeriodKey, "{}"));

            // 空資料或非今天的資料(換天)->清空資料
            if (!(lastEndPeriodData.dateStr && lastEndPeriodData.dateStr === todayStr)) {
                // 清玩法結算資料
                lastEndPeriodData = {
                    dateStr: todayStr        // 存今日日期
                };
            }

            // 抓該玩法最新一期結算資料
            var gameLastEndPeriodObj = (lastEndPeriodData[gameType]) ? lastEndPeriodData[gameType] : {};
            // 最新一期結算字串已經變更&更新小紅點
            if (gameLastEndPeriodObj.lastEndPeriodTxt !== lastEndPeriodTxt) {
                // 更新最後結算時段
                gameLastEndPeriodObj.lastEndPeriodTxt = lastEndPeriodTxt;

                // 收到0代表今天還沒結算過 -> 不用顯示小紅點
                if (lastEndPeriodTxt !== "0") {
                    gameLastEndPeriodObj.showRedPoint = true;
                }
            }

            // 更新本玩法結算資料 -> 存本機
            lastEndPeriodData[gameType] = gameLastEndPeriodObj;
            GS.localStorage.setItem(lastEndPeriodKey, JSON.stringify(lastEndPeriodData));
        } else {
            this.clean();
        }

        GS.dispatchCustomEvent("NotifyFierceBattleIconDone");
    },

    /**
     * 各玩法 時段活動資料/排名等
     * C -> S fierce_battle_info {"game_type":"19"}
     * S -> C fierce_battle_info
     *
     * {
     * # 0:可累積時段 1:活動完全結束 2:結算中 3:活動結束後24小時內可看排行榜 4:活動時間內，但非結算也非累積時段
       "error":"4",

       "game_type":"19",                    # 玩法
       "wtime":"1651736820",                # 此次活動走期首日
       "time_left":"1895344",               # 活動倒數時間
       "refresh_time":"52803",              # 下次要重整時間(可開始累積/開始結算/隔天0600)
       "pop":"1",                           # 是否主動彈跳

       "img_url":"https://g.mwsrv.com/19_60/store/iapp/goods/",   # 獎圖base_url
       "period_data":[                      # 今日所有時段資料
           {
               "list":[                     # 該時段的排行榜
               ],
               "status":"2",                # 1:現在正在累積 2:時間已過 3:時間未到
               "marquee":[                  # 各時段跑馬燈
                   "Kompetisi telah berakhir untuk Periode ini~"
               ],
               "start_time":"1652853600",
               "end_time":"1652857200",
               "user_score":"0",            # 該時段玩家獎牌數
               "period":"14:00~15:00",      # 該時段時間文字
               "user_rank":"-"              # 該時段玩家名次
           },
           {...}
       ]
      }
     */
    cmd_fierce_battle_info: function (key, value) {
        var jsonValue = JSON.parse(value);

        // 是否開啟推播
        this.isCanBroadcast = JSCodeUtility.getIntValue(GS.localStorage.getItem(this.getStorageKey(UserDefaultKey.FierceBattleBroadcastFlag), "1")) === 1;

        // 0:可累積時段 1:活動完全結束 2:結算 3:活動結束後24小時內可看排行榜 4:活動時間內，但非結算也非累積時段
        var eventStatus = JSCodeUtility.getIntValue(jsonValue["error"]);

        // 活動開啟
        if (eventStatus !== FierceBattleData.EventStatusType.CLOSE) {

            // 更新該玩法資料
            var gameInfoParam = {};

            // 存本玩法需要推播的時間
            var tempBroadTimeList = [];

            // 玩法編號
            var gameType = gameInfoParam.gameType = JSCodeUtility.getIntValue(jsonValue["game_type"]);
            // 玩法名稱
            gameInfoParam.gameName = GSEnum.GameName[gameType] || "";

            // 活動狀態
            gameInfoParam.eventStatus = eventStatus;

            // 活動時間相關
            var socketTime = gameInfoParam.socketTime = JSCodeUtility.getNowTime();
            // 該玩法下次刷新時間(可開始累積/開始結算/隔天0600)
            gameInfoParam.refreshTime = JSCodeUtility.getIntValue(jsonValue["refresh_time"]);

            // 防呆 避免server送的不是array
            var periodJsonValueArray = JSCodeUtility.isArray(jsonValue["period_data"]) ? jsonValue["period_data"] : [];
            gameInfoParam.eventList = periodJsonValueArray.map((periodData, idx) => {
                // status是3(時間未到)，才會有下次開始倒數時間(推播使用)
                var broadcastTime = JSCodeUtility.getIntValue(periodData["next_time_left"]);
                // 記下需要推播的時間
                if (broadcastTime > 0)
                    tempBroadTimeList.push(broadcastTime);

                // 該時段狀態 1:現在正在累積 2:時間已過 3:時間未到
                var status = JSCodeUtility.getIntValue(periodData["status"]);

                // 找出預設顯示的時段
                var isDefaultPeriod = JSCodeUtility.getBooleanValue(periodData["default_period"]);
                if (isDefaultPeriod)
                    gameInfoParam.defaultOpenPeriodIndex = idx;

                return {
                    periodTxt: JSCodeUtility.getStringValue(periodData["period"]),                             // 本時段時間文字(18:00-19:00)
                    isDefaultPeriod: isDefaultPeriod,                                                          // 目前預設打開時段
                    status: status,                                                                            // 1:現在正在累積 2:時間已過 3:時間未到
                    startTime: JSCodeUtility.getIntValue(periodData["start_time"]),                            // 開始時間
                    endTime: JSCodeUtility.getIntValue(periodData["end_time"]),                                // 結束時間
                    broadcastTime: broadcastTime,                                                              // status 是3才會有下次開始倒數時間(推播使用)
                    myScore: JSCodeUtility.getIntValue(periodData["user_score"]),                              // 自己獎牌數
                    myRank: JSCodeUtility.getStringValue(periodData["user_rank"]),                             // 自己排名
                    marqueeList: (periodData["marquee"] || []).map(str => JSCodeUtility.getStringValue(str)),  // 跑馬燈

                    // 排名列表
                    rankList: (periodData["list"] || []).map((playerData) => {
                        return {
                            nickname: JSCodeUtility.getDecodeStringValue(playerData["nickname"]),               // 暱稱
                            account: JSCodeUtility.getStringValue(playerData["userid"]),                        // 帳號
                            photoUrl: JSCodeUtility.getStringValue(playerData["pic"]),                          // 大頭貼圖
                            rank: JSCodeUtility.getIntValue(playerData["rank"]),                                // 排名
                            score: JSCodeUtility.getIntValue(playerData["score"]),                              // 獎牌數
                            rewards: (playerData["rewards"] || []).map((rewardData) => {
                                return {
                                    pic: JSCodeUtility.getStringValue(rewardData["pic"]),                       // 獎勵圖
                                    rewardTxt: JSCodeUtility.getStringValue(rewardData["reward"])               // 獎勵文字
                                };
                            })
                        };
                    })
                };
            });

            // 更新活動通用資料
            this.infoParam.eventStatus = eventStatus;               // 整個活動狀態
            this.infoParam.seasonRemainTime = JSCodeUtility.getIntValue(jsonValue["time_left"]);     // 整個活動時間
            this.infoParam.socketTime = socketTime;                 // 最新socketTime

            // 存下該玩法活動資料
            this.infoParam.gameInfoParams[gameType] = gameInfoParam;

            // 抓今日推播資料
            var todayStr = JSCodeUtility.getNowDateString();
            var broadcastKey = this.getStorageKey(UserDefaultKey.FierceBattleBroadcastData);
            var broadcastData = JSON.parse(GS.localStorage.getItem(broadcastKey, "{}"));

            // 空資料或非今天的資料(換天)->清空資料
            if (!(broadcastData.dateStr && broadcastData.dateStr === todayStr)) {
                // 清推播
                broadcastData.dateStr = todayStr;
                broadcastData.broadcastNum = 0;
                broadcastData.gameBroadcastObjs = {};
            }

            // 更新玩法推播資料
            broadcastData.gameBroadcastObjs[gameType] = {
                socketTime: socketTime,                        // 收到該socket時間
                broadcastTimeList: tempBroadTimeList           // 該玩法所有推播倒數時間
            };

            // 推播資料存本機
            GS.localStorage.setItem(broadcastKey, JSON.stringify(broadcastData));

            // 送推播
            if (this.isCanBroadcast) {
                this._sendBroadcast();
            }

            // 是否主動跳dialog
            if (JSCodeUtility.getBooleanValue(jsonValue["pop"]) && PushScene.isLobby) {
                DialogManager.addLobbyDialog(new FierceBattleDialog(), true);
            }

            FierceBattleData.REWARD_BASE_HOST = JSCodeUtility.getStringValue(jsonValue["img_url"]);                     // 獎圖網址
        } else {
            // 活動關閉 通知icon關閉
            this.clean();
            GS.dispatchCustomEvent("NotifyFierceBattleIconDone");
        }

        GS.dispatchCustomEvent("NotifyFierceBattleInfoDone");
    },

    /**
     * 桌內通知獲得獎牌
     * S->C fierce_battle_add_score x
     */
    cmd_fierce_battle_add_score: function (key, value) {
        var medalNum = JSCodeUtility.getIntValue(value);
        if (medalNum > 0) {
            // 通知桌內獲得獎牌
            GS.dispatchCustomEvent("NotifyFierceBattleGetScore", medalNum);
        }
    },

    /**
     * 桌內通知名次更新
     * S->C fierce_battle_update_rank (無排名:"-" , 50名外:"50+" , 50名內:50)
     */
    cmd_fierce_battle_update_rank: function (key, value) {
        // 通知桌內名次更新
        if (value)
            GS.dispatchCustomEvent("NotifyFierceBattleUpdateRank", value);
    }
});

// 該玩法的狀態進行 0:可累積時段 1:活動完全結束 2:結算 3:活動結束後24小時內可看排行榜 4:活動時間內，但非結算也非累積時段
FierceBattleData.EventStatusType = {
    ACCUMULATING: 0,       // 可累積時段
    CLOSE: 1,              // 活動完全結束
    RANKING: 2,            // 結算中
    SEASON_END: 3,         // 活動結束後24小時內可看排行榜
    NORMAL: 4              // 活動中非結算也非累積時段
};

// 玩法中各時段自己的狀態 1:現在正在累積 2:時間已過 3:時間未到
FierceBattleData.PeriodStatusType = {
    NOW: 1,                       // 現在正在累積
    END: 2,                       // 時間已過
    COMING_SOON: 3                // 時間未到
};

// 目前激戰任務支援的玩法編號 用來一次要全玩法資料
FierceBattleData.AllGameTypeList = [
    "19"            // Poker
];

FierceBattleData.REWARD_BASE_HOST = "";                                 // 獎勵圖片下載的網址