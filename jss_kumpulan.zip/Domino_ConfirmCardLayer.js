/**
 * 用來確認手牌的牌型 確定完跟Server說
 */

var Domino_ConfirmCardLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this._nowTime = 0;

        var titlePosY = 156 + JSScreenBonusHalfHeight;  // 顯示的Y
        var numberWidth = 26;                           // 數字的寬度

        // 背景
        var bgSprite = new cc.Sprite("#lobby_pic_black.png");
        bgSprite.setScale(6);
        bgSprite.setPosition(JSScreenMidPos.x, titlePosY);
        this.addChild(bgSprite);

        // 文字
        var wordSprite = new cc.Sprite("#domino_word_01.png");
        wordSprite.setPosition(JSScreenMidPos.x - numberWidth / 2, titlePosY);
        this.addChild(wordSprite);

        // 數字
        var numberPosX = wordSprite.getPositionX() + (wordSprite.getContentSize().width / 2) - 10;
        this._timeSprites = [];
        for (var i = 0; i < 2; i++) {
            var timeSprite = this._timeSprites[i] = new cc.Sprite();
            timeSprite.setPosition(numberPosX, titlePosY);
            timeSprite.setAnchorPoint(0, 0.5);
            this.addChild(timeSprite);

            numberPosX += numberWidth / 2;
        }

        // 下方的確定按鈕
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        this.addChild(menu, 1);

        var buttonSize = cc.size(145, DOMINO_UILAYER_BUTTON_HEIGHT);
        var itemNodes = ButtonUtility.createArrayScale9Nodes(["lobby_btn_01.png", "lobby_btn_01.png", "lobby_btn_01.png"], buttonSize, LocalizedString.Game("確定"), 16, JSColor.BLACK);
        var okItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._menuOKClicked, this);
        okItem.setPosition(JSScreenMidPos.x, DOMINO_UILAYER_BUTTON_Y);
        menu.addChild(okItem);
    },

    cleanData: function () {
        this.stopAllActions();
        this.setVisible(false);
    },

    /**
     * 開始倒數
     */
    startConfirm: function (time) {
        this._nowTime = time;

        // 讓自己顯示
        this.setVisible(true);

        this.stopAllActions();

        // 跑schedule
        this.runAction(cc.repeatForever(cc.sequence(
            cc.delayTime(1),
            cc.callFunc(function () {
                this._nowTime--;
                if (this._nowTime <= 0) {
                    // 時間到
                    this.stopAllActions();
                }
                this._updateTimeSprite();
            }, this)
        )));

        // 先更新一次數字
        this._updateTimeSprite();
    },

    /**
     * 更新時間
     */
    _updateTimeSprite: function () {
        // timeSprites[0] 是十位數 [1]是個位數
        var timeString = this._nowTime.toString();
        var timeSpriteLen = this._timeSprites.length;
        // 從後面開始塞 後面才是個位數
        var startTimeLen = timeString.length - 1;
        for (var i = timeSpriteLen - 1; i >= 0; i--) {
            var timeSprite = this._timeSprites[i];
            if (startTimeLen >= 0) {
                timeSprite.setVisible(true);
                timeSprite.setSpriteFrame(JSStringUtility.format("game_number_elec_%s.png", timeString[startTimeLen]));
            } else
                timeSprite.setVisible(false);

            startTimeLen--;
        }
    },

    /**
     * 按鈕
     */
    // 按下確定
    _menuOKClicked: function () {
        // 送一個通知出去 把最終手牌跟Server講
        GS.dispatchCustomEvent("NotifyConfirmCardDone");

        // 把自己關掉
        this.setVisible(false);
        this.stopAllActions();
    },
});