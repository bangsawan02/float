/**
 * 活動Dialog
 * created by andrew.chang
 */

var BaseEventDialog = BaseDialogLayer.extend({
    ctor: function () {
        this._super();

        // 參數
        this._isInitDone = false;               // 是不是初始化完
        this._isInAnimation = false;            // 是不是在動畫中
        this._isEventEnd = false;               // 是不是活動結束了
        this._isInDialog = false;               // 是不是在其他dialog
        this._isShowEventEndDialog = false;     // 是不是已經跳了活動結束dialog
        this._isPurchasing = false;             // 是否正在儲值

        // 相關畫面
        this._infoDialog = undefined;           // 說明畫面

        // 測試資料
        TestMenu.delegate(this);

        EventEndDelegate.delegate(this);

        // 監聽通知
        GS.addListener("NotifyPurchaseFail", this.notifyPurchaseFail.bind(this), this);
    },

    onExit: function () {
        // 砍素材
        if (this._loadFileDone) {
            for (let i = 0; i < this.loadFileArray.length; i += 2)
                cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[i]);
        }

        this._super();
    },

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        if (this.isLockBackKey)
            return;

        this._closeBtnClicked();
    },

    /**
     * 讀完素材
     */
    loadFileDone: function () {
        this._super();

        // 加素材
        for (let i = 0; i < this.loadFileArray.length; i += 2)
            cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[i], this.loadFileArray[i + 1]);

        // 檔Touch用
        let dummyTouchLayer = this._dummyTouchLayer = new DummyTouchLayer(JSVisibleSize, JSDebugMode);
        this._animationLayer.addChild(dummyTouchLayer, 10);

        // 加一個Loading
        let loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(JSScreenMidPos);
        loadingSprite.start();
        dummyTouchLayer.addChild(loadingSprite);
    },

    /**
     * Override掉 假如有WebView一起關掉
     */
    setVisible: function (isVisible) {
        // 有說明頁也要隱藏
        if (this._infoDialog) {
            this._infoDialog.setVisible(isVisible);
        }

        this._super(isVisible);
    },

    /**
     * 設定 Loading Sprite
     * @param {boolean} isLoadingVisible 是否顯示 Loading
     * @param {boolean} isLockTouch 是否鎖定 Touch
     */
    setLoadingSprite: function (isLoadingVisible, isLockTouch) {
        this._loadingSprite && (isLoadingVisible ? this._loadingSprite.start() : this._loadingSprite.stop());
        this._dummyTouchLayer && this._dummyTouchLayer.setVisible(isLoadingVisible || isLockTouch);
    },

    /**
     * 創測試資料
     * 給外部override用
     */
    createDebugTestObject: function () {
        // TODO
    },

    /**
     * UI相關
     */

    /**
     * 創說明dialog
     * 給外部override用
     */
    _createEventInfoDialog: function () {
        cc.error(this.key + "忘了override _createEventInfoDialog");

        return new WebViewDialog();
    },

    /**
     * 創活動結束dialog
     * 給外部override用
     */
    _createEventEndDialog: function () {
        return new Dialog({
            content: LocalizedString.Common("活動已結束"),
            callback: () => {
                this.closeDialogAnimation();
            }
        });
    },

    /**
     * 顯示dialog
     * @param dialog    要顯示的dialog
     * @param isHighest 是不是要壓在最上面
     */
    showDialog: function (dialog, isHighest = false) {
        // 加到畫面上
        this._animationLayer.addChild(dialog, isHighest ? 10000 : 9999);

        // dialog彈跳
        dialog.startDialogAnimation();
    },

    /**
     * 跳活動結束dialog
     */
    showEventEndDialog: function () {
        // 記下現在活動結束了
        this._isEventEnd = true;

        // 動作中 或 已經跳活動結束 或 在不能跳活動結束的dialog 或 在儲值中 就不做事
        if (this._isShowEventEndDialog || this._isInAnimation || this._isInDialog || this._isPurchasing)
            return;

        // 記下已經跳了活動結束dialog
        this._isShowEventEndDialog = true;

        // 如果說明頁有開幫他關掉說明頁
        if (this._infoDialog) {
            this._infoDialog.closeDialogAnimation();
            this._infoDialog = undefined;
        }

        // 活動結束
        var dialog = this._createEventEndDialog();
        this._animationLayer.addChild(dialog, 10001);
        dialog.startDialogAnimation();
    },

    /**
     * 檢查是否有要做啥事(通常可能是動畫完或領獎完 目前只有檢查是不是活動結束了)
     */
    _isNeedToDoSomething: function () {
        // 活動結束了
        if (this._isEventEnd) {
            this.showEventEndDialog();
            return true;
        }

        return false;
    },

    /**
     * 點擊說明按鈕
     */
    _infoBtnClicked: function () {
        var dialog = this._infoDialog = this._createEventInfoDialog();
        dialog.setCloseCallback(() => {
            // 清掉dialog
            this._infoDialog = undefined;
        });
        this.showDialog(dialog, false);
    },

    /**
     * 點擊關閉按鈕
     */
    _closeBtnClicked: function () {
        // 動畫中 儲值等待過帳中 不做事
        if (!this.canCloseDialog())
            return;

        this.closeDialogAnimation();
    },

    /**
     * 判斷是否可以關閉 dialog
     * @return {boolean}
     */
    canCloseDialog: function () {
        return !this._isInAnimation && !this._isPurchasing;
    },

    /**
     * 關掉Dialog
     * @override
     */
    _closeDialogAnimation: function () {
        // 如果有說明頁也要關閉說明頁
        if (this._infoDialog) {
            this._infoDialog.closeDialogAnimation();
            this._infoDialog = undefined;
        }

        this._super();
    },

    /**
     * 通知儲值失敗
     */
    notifyPurchaseFail: function () {
        this._isPurchasing = false;

        // 檢查有沒有做的事
        this._isNeedToDoSomething();
    },
});
