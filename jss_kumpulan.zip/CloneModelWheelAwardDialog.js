/**
 * v5.6.1 分身模組 - 轉盤獎勵主畫面 移植中撲 16.7
 */

var CloneModelWheelAwardDialog = BaseDialogLayer.extend({
    ctor: function (whereType) {
        this._super();

        this.key = "CloneModelWheelAwardDialog";
        this._whereType = whereType;

        this.loadFileArray = [
            "cloneModel/cloneModel.plist", "cloneModel/cloneModel.png",
            SelectGameManager.getNowGameFile("cloneModel.plist", "cloneModel/"), SelectGameManager.getNowGameFile("cloneModel.png", "cloneModel/")
        ];

        // 註冊通知
        GS.addListener("NotifyCloseCloneMainDialog", this.notifyCloseCloneMainDialog.bind(this), this);
    },

    onExit: function () {
        // 砍素材
        if (this._loadFileDone) {
            for (let i = 0; i < this.loadFileArray.length; i += 2)
                cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[i]);
        }

        this._super();
    },

    loadFileDone: function () {
        this._super();

        // 讀素材
        for (let i = 0; i < this.loadFileArray.length; i += 2) {
            cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[i], this.loadFileArray[i + 1]);
        }

        let infoParam = this._infoParam = DataModal.cloneModelData.infoParam;
        let iconParam = this._iconParam = DataModal.cloneModelData.iconParam;
        let rechargeParam = this._rechargeParam = DataModal.cloneModelData.rechargeParam;

        let aniLayer = this._animationLayer;

        // 是不是儲值成功打開的
        let isFromPurchaseSuccess = rechargeParam !== undefined && rechargeParam.isSuccess;

        // 轉盤中獎的index
        this._hit = isFromPurchaseSuccess ? rechargeParam.hit : -1;

        // 幸運草數量
        let coinCount = this._coinCount = isFromPurchaseSuccess ? rechargeParam.nextCoinProgress - 1 : infoParam ? infoParam.nowCoinProgress : iconParam.coinsCount;

        // 刷新動畫callback
        isFromPurchaseSuccess && this.setCloseCallback(() => {
            GS.dispatchCustomEvent("NotifyPlanReplacementPlayAddCoinAnimate");
        });

        // 中間視窗內物件的中心點
        let windowCenterPosX = this._windowCenterPosX = JSScreenMidPos.x + 127.5;

        // 背景
        var bgSprite = new ccui.Scale9Sprite("cloneModel_bg_blue.png");
        bgSprite.setPreferredSize(JSVisibleSize);
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite);

        // 背景上的花紋
        let patternBgSprite = new cc.Sprite("#cloneModel_pic_pattern_02.png");
        patternBgSprite.setPosition(0, JSScreenMidPos.y + 5);
        aniLayer.addChild(patternBgSprite);

        // 頂跟底的藍光
        for (let i = 0; i < 2; i++) {
            let bgLightSprite = new cc.Sprite("#cloneModel_bg_light_01.png");
            bgLightSprite.setAnchorPoint(0.5, 1);
            bgLightSprite.setScaleX(5);
            bgLightSprite.setScaleY(i ? -5 : 5);
            bgLightSprite.setPosition(JSScreenMidPos.x, i ? -50 : JSVisibleSize.height + 60);
            aniLayer.addChild(bgLightSprite);
        }

        // 藍光點
        let bgLightPointSprite = new cc.Sprite("#cloneModel_bg_light_02.png");
        bgLightPointSprite.setScale(2);
        bgLightPointSprite.setPosition(JSScreenMidPos.x - 127.5, JSScreenMidPos.y + 100);
        aniLayer.addChild(bgLightPointSprite);

        // 底部往上飄的發光點
        GSSpine.create("spine/cloneModel/ani_light", 0.25, (spine) => {
            spine.setPosition(JSScreenMidPos.x + 120, 80);
            spine.setAnimation(0, 'animation', true);
            aniLayer.addChild(spine);
        });

        // 中間的視窗
        let windowSprite = new ccui.Scale9Sprite("cloneModel_bg_windows.png");
        windowSprite.setPreferredSize(cc.size(300, 222));
        windowSprite.setPosition(JSScreenMidPos.x + 76, JSScreenMidPos.y);
        aniLayer.addChild(windowSprite);

        // 背景上的花紋
        let windowPatternSprite = new cc.Sprite("#cloneModel_pic_pattern_01.png");
        windowPatternSprite.setPosition(JSScreenMidPos.x + 66, JSScreenMidPos.y - 66);
        aniLayer.addChild(windowPatternSprite);

        // 有關時間
        {
            // 時鐘背景
            let timeBgSprite = new ccui.Scale9Sprite("cloneModel_bg_frame_02.png");
            timeBgSprite.setPreferredSize(cc.size(102, 24));
            timeBgSprite.setPosition(windowCenterPosX, JSScreenMidPos.y + 99);
            aniLayer.addChild(timeBgSprite);

            // 時間的node
            let timeNode = new GSAutoLayoutNode();
            timeNode.setSpace(3);
            timeNode.setPosition(timeBgSprite.getPosition());

            // 時鐘
            timeNode.addChild(new cc.Sprite("#lobby_pic_clock_04.png"));

            // 關閉倒數的時間
            let countdownLabel = this._countdownLabel = new GSTimeLabel("", JSFontBoldName, 11);
            countdownLabel.setMultiFormat("%ddD%hhH", "%hhH%mmM", "%mmM%ssS");
            countdownLabel.countdownSeconds(DataModal.cloneModelData.getRemainTime(), () => {
                this._showEventOverDialog();
            });
            timeNode.addChild(countdownLabel);
            aniLayer.addChild(timeNode, 1);
        }

        // coin 數量的node
        {
            let cloverNode = this._cloverNode = new cc.Node();

            // 底圖
            var bgSprite = new ccui.Scale9Sprite("cloneModel_bg_frame_01.png");
            bgSprite.setPreferredSize(cc.size(147, 33));
            bgSprite.setOpacity(204);
            cloverNode.addChild(bgSprite);

            // 幸運草們
            let cloverPos = this._cloverPos = cc.p(-50, 0);
            let cloverGap = this._cloverGap = 32;
            for (let i = 0; i < 3; i++) {
                // 虛位以待
                let blackCloverSprite = new cc.Sprite("#cloneModel_bg_window_4.png");
                blackCloverSprite.setPosition(cloverPos.x + cloverGap * i, cloverPos.y);
                blackCloverSprite.setScale(0.45);
                blackCloverSprite.setOpacity(204);
                cloverNode.addChild(blackCloverSprite);
                if (i < coinCount) {
                    // 有 coin
                    let cloverSprite = new cc.Sprite("#lobby_icon_cloneModel_02.png");
                    cloverSprite.setPosition(cloverPos.x + cloverGap * i, cloverPos.y);
                    cloverSprite.setScale(0.6);
                    cloverNode.addChild(cloverSprite);
                }
            }

            // 小轉盤
            let wheelSprite = new cc.Sprite("#cloneModel_pic_icon_wheel.png");
            wheelSprite.setPosition(55, 0);
            cloverNode.addChild(wheelSprite);

            cloverNode.setPosition(windowCenterPosX, JSScreenMidPos.y - 38);
            aniLayer.addChild(cloverNode);
        }

        // 大轉盤Node
        let wheelNode = this._wheelNode = new CloneModelWheelNode();
        let wheelNodePos = this._wheelNodePos = cc.p(JSScreenMidPos.x - 100, JSScreenMidPos.y - 7);
        wheelNode.setPosition(wheelNodePos);
        wheelNode.setSpinFinishCallback(this._wheelSpinFinishCallback.bind(this));
        aniLayer.addChild(wheelNode, 2);

        // 按鈕
        {
            // 馬上轉 or 馬上儲值 按鈕
            let turnButton = this._turnButton = new Texas_Button(
                Texas_Button.Style.GREEN, cc.size(77.5, 39),
                LocalizedString.Purchase(coinCount === 3 ? "馬上轉" : "馬上儲值")
            );
            turnButton.setPosition(windowCenterPosX, JSScreenMidPos.y - 76);
            turnButton.addTouchUpInsideAction(this._turnButtonClicked, this);
            turnButton.runAction(cc.sequence(
                cc.scaleTo(0.75, 1.05).easing(cc.easeSineInOut()),
                cc.scaleTo(0.75, 1).easing(cc.easeSineInOut())
            ).repeatForever());
            aniLayer.addChild(turnButton);

            // 關閉按鈕 (v5.7.0 拔掉關閉按鈕，預設 visible = false)
            // 關閉按鈕在儲值中心不拔掉
            // 關閉按鈕在可領獎的時候不拔掉
            let closeBtn = this._closeBtn = new Texas_CloseButton();
            closeBtn.setPosition(490 + JSScreenBonusHalfWidth, 266 + JSScreenBonusHalfHeight);
            closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
            closeBtn.setVisible(false);
            aniLayer.addChild(closeBtn, 11);

            // 說明按鈕
            let explainButton = new Texas_ExplainButton(Texas_ExplainButton.Style.BLACK_BIG);
            explainButton.setPosition(20 + JSScreenBonusHalfWidth, 266 + JSScreenBonusHalfHeight);
            explainButton.addTouchUpInsideAction(this._explainBtnClicked, this);
            aniLayer.addChild(explainButton, 1);
        }

        // 畫面 initialize 完成，根據不同數量的金幣有不同的標題與按鈕文字
        this._refreshView(coinCount);

        // 如果是購買成功來的要做動畫
        if (isFromPurchaseSuccess) {
            this._purchaseSuccessAnimation(rechargeParam.nextCoinProgress);
        }

        // 只要是進畫面是三個幸運草一定要發獎勵
        if (coinCount === 3)
            DataModal.awardAndMailData.startGetIcon();
    },

    onEnter: function () {
        this._super();

        // 埋點：3419 進入轉盤頁
        TexasUtility.sendUserAnalyticsTrack(3419, DataModal.cloneModelData.infoParam.cluster);

        // 埋點：5251 >=5.7.0獲得分身模組且登入轉盤介面
        TexasUtility.sendUserAnalyticsTrack(5251, DataModal.cloneModelData.infoParam.cluster);
    },

    /**
     * 跳活動結束視窗
     */
    _showEventOverDialog: function () {
        if (this._webInfoDialog) {
            this._webInfoDialog.closeDialogAnimation();
            this._webInfoDialog = null;
        }

        // 活動結束
        let dialog = new Dialog({
            content: LocalizedString.Purchase("活動已結束"),
            closeButton: false,
            callback: () => {
                // 關閉分身模組 dialog
                GS.dispatchCustomEvent("NotifyCloseCloneMainDialog", {isAnimeEnabled: true});
            }
        });
        dialog.startDialogAnimation();
        this._animationLayer.addChild(dialog, 1000);
    },

    /**
     * 更新畫面
     * @param {number} coinCount
     * @private
     */
    _refreshView: function (coinCount) {
        let isInPurchase = PushScene.checkNowLayer(PurchaseLayer);
        this._refreshTitle(coinCount);
        this._refreshButton(coinCount);
        // 關閉按鈕在儲值中心不拔掉
        // 關閉按鈕在可領獎的時候不拔掉
        // 在儲值中心不鎖返回鍵
        this._closeBtn.setVisible(coinCount === 3 || isInPurchase);
        this._closeBtn.setEnabled(coinCount === 3 || isInPurchase);
        this.isLockBackKey = !(coinCount === 3 || isInPurchase);
    },

    /**
     * 更新標題
     * @param {number} coinCount
     * @private
     */
    _refreshTitle: function (coinCount) {
        let animationLayer = this._animationLayer;

        if (!this._titleLayer) {
            this._titleLayer = new cc.Node();
            animationLayer.addChild(this._titleLayer);
        } else {
            this._titleLayer.removeAllChildren();
        }

        let titleLayer = this._titleLayer;
        let fontColor = cc.color(255, 235, 120);

        let columnNode = new GSAutoLayoutNode();
        columnNode.setType(GSAutoLayout.TYPE.VERTICAL);
        columnNode.setPosition(this._windowCenterPosX, JSScreenMidPos.y + 32);
        titleLayer.addChild(columnNode);

        let msg, rowNode, cloverSprite;
        switch (coinCount) {
            case 0:
                // First line
                msg = new cc.LabelTTF(LocalizedString.Purchase("儲值指定金額"), JSFontBoldName, 12);
                msg.setColor(fontColor);
                columnNode.addChild(msg);

                // Second line
                rowNode = new GSAutoLayoutNode();
                rowNode.setSpace(3);
                columnNode.addChild(rowNode);

                // The message at second line
                msg = new cc.LabelTTF(LocalizedString.Purchase("拿（_金色代幣_）"), JSFontBoldName, 12);
                msg.setColor(fontColor);
                rowNode.addChild(msg);

                // The coin sprite at second line
                cloverSprite = new cc.Sprite("#lobby_icon_cloneModel_02.png");
                cloverSprite.setScale(0.38);
                rowNode.addChild(cloverSprite);

                // The third line.
                msg = new cc.LabelTTF(LocalizedString.Purchase("並升級轉盤獎勵"), JSFontBoldName, 12);
                msg.setColor(fontColor);
                columnNode.addChild(msg);

                // The spacer.
                columnNode.addEmptyNode(cc.size(0, 3));

                // The fourth line.
                rowNode = new GSAutoLayoutNode();
                rowNode.setSpace(3);
                columnNode.addChild(rowNode);

                // The message at fourth line.
                msg = new cc.LabelTTF(LocalizedString.Purchase("收集3枚"), JSFontBoldName, 12);
                msg.setColor(fontColor);
                rowNode.addChild(msg);

                // The coinSprite at fourth line.
                cloverSprite = new cc.Sprite("#lobby_icon_cloneModel_02.png");
                cloverSprite.setScale(0.38);
                rowNode.addChild(cloverSprite);

                // The fifth line.
                msg = new cc.LabelTTF(LocalizedString.Purchase("即可旋轉"), JSFontBoldName, 12);
                msg.setColor(fontColor);
                columnNode.addChild(msg);
                break;
            case 1:
            case 2:
                rowNode = new GSAutoLayoutNode();
                rowNode.setSpace(3);
                columnNode.addChild(rowNode);

                msg = new cc.LabelTTF(JSStringUtility.format(LocalizedString.Purchase("只差%d枚"), 3 - coinCount), JSFontName, 12);
                msg.setColor(fontColor);
                rowNode.addChild(msg);

                cloverSprite = new cc.Sprite("#lobby_icon_cloneModel_02.png");
                cloverSprite.setScale(0.38);
                rowNode.addChild(cloverSprite);

                msg = new cc.LabelTTF(LocalizedString.Purchase("即可"), JSFontBoldName, 12);
                msg.setColor(fontColor);
                rowNode.addChild(msg);

                msg = new cc.LabelTTF(LocalizedString.Purchase("拿大獎"), JSFontBoldName, 12);
                msg.setColor(fontColor);
                columnNode.addChild(msg);
                break;
            case 3:
                msg = new cc.LabelTTF(LocalizedString.Purchase("恭喜集滿拉\n快來領獎吧!"), JSFontBoldName, 12);
                msg.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                msg.setColor(fontColor);
                columnNode.addChild(msg);
                break;
            default:
                break;
        }
    },

    /**
     * 更新按鈕文字
     * @param {number} coinCount
     * @private
     */
    _refreshButton: function (coinCount) {
        this._turnButton.setBtnString(LocalizedString.Purchase(coinCount === 3 ? "馬上轉" : "馬上儲值"));
    },

    _purchaseSuccessAnimation: function (coinCount) {
        // 如果有馬上轉要先鎖起來
        this._turnButton.setEnabled(false);
        // 鎖an返回
        this.isLockBackKey = true;
        this._closeBtn.setEnabled(false);

        // 動畫流程：先增加幸運草 -> 光束跑到轉輪 -> 更新獎勵 -> 打開馬上轉
        this.increaseCloverAsync(coinCount)
            .then(() => this.upgradeRewardAsync())
            .then(() => this._wheelNode.refreshRewardAsync())
            .then(() => {
                if (this.__isDestroyed)
                    return;

                this._turnButton.setEnabled(true);

                if (coinCount !== 3) {
                    // 更新資料，可轉等到轉完再清資料
                    DataModal.cloneModelData.updateDataFromRechargeParam();
                }

                this._refreshView(coinCount);

                // 更新金色籌碼數量
                this._coinCount = coinCount;
            });
    },

    // 增加幸運草
    increaseCloverAsync: function (coinCount) {
        return new Promise((resolve) => {
            if (this.__isDestroyed)
                return;

            let cloverPos = this._cloverPos;
            let cloverGap = this._cloverGap;
            let cloverNode = this._cloverNode;

            let animationCloverSprite = new cc.Sprite("#lobby_icon_cloneModel_02.png");
            animationCloverSprite.setScale(0.6);
            let animationCloverShaderSprite = this._animationCloverShaderSprite = GSShaderSpriteTools.changeNodeToGSShaderSprite(animationCloverSprite);
            animationCloverShaderSprite.setPosition(cloverPos.x + cloverGap * (coinCount - 1), cloverPos.y);
            animationCloverShaderSprite.setScale(1.5);
            animationCloverShaderSprite.setVisible(false);
            cloverNode.addChild(animationCloverShaderSprite);

            // 閃亮特效
            let brightParam = new BrightenShaderParam();
            brightParam.cycleTime = 1;
            brightParam.updateTime = 0;

            // 幸運草飛下來 -> 亮一下
            animationCloverShaderSprite.runAction(cc.sequence(
                cc.delayTime(0.5),
                cc.show(),
                cc.scaleTo(0.3, 1, 1).easing(cc.easeBackOut()),
                cc.delayTime(0.2),
                cc.callFunc(() => {
                    animationCloverShaderSprite.setShader(new GSBrightenShader(brightParam));
                }),
                cc.delayTime(0.2),
                cc.callFunc(() => {
                    resolve();
                }),
                cc.delayTime(0.6),
                cc.callFunc(() => {
                    animationCloverShaderSprite.restoreNormalShader();
                })
            ));
        });
    },

    // 光束跑道轉輪中心
    upgradeRewardAsync: function () {
        return new Promise((resolve) => {
            if (this.__isDestroyed)
                return;

            let particlePos = this.convertToNodeSpace(this._animationCloverShaderSprite.convertToWorldSpace());
            let path = "spine/cloneModel/ani_wheel_ray.plist";
            let particle = this._particle = new cc.ParticleSystem(path);
            particle.setPosition(particlePos.x, particlePos.y + 15);
            particle.setScale(0.4);
            particle.pause();
            this.addChild(particle, 100);

            particle.runAction(cc.sequence(
                cc.callFunc(() => {
                    particle.setTotalParticles(300);
                    particle.resume();
                }),
                cc.moveTo(0.7, this._wheelNodePos.x + 5, this._wheelNodePos.y),
                cc.scaleTo(0.8, 0, 0),
                cc.callFunc(() => {
                    resolve();
                })
            ));
        });
    },

    keyBackPressed: function () {
        if (this.isLockBackKey) {
            return;
        }

        this._closeBtnClicked();
    },

    _closeBtnClicked: function () {
        if (this._coinCount === 3) {
            let dialog = new CloneModelWheelAwardSystemHelpDialog();
            dialog.setCloseCallback(this._turnButtonClicked.bind(this));
            this.addChild(dialog, 1000);
            dialog.startDialogAnimation();
            this._turnButton.setEnabled(false);

            // 埋點 幸運草數=3且點擊Ｘ的人數
            TexasUtility.sendUserAnalyticsTrack(3421, DataModal.cloneModelData.infoParam.cluster);
        } else {
            // 埋點 幸運草數=0~2且點擊Ｘ的人數
            TexasUtility.sendUserAnalyticsTrack(3420, DataModal.cloneModelData.infoParam.cluster);
            this._closeDialogAnimation();
        }
    },

    /**
     * 馬上轉 or 馬上儲值 按鈕被點擊
     */
    _turnButtonClicked: function (sender) {
        // 埋點 點擊馬上轉
        sender && TexasUtility.sendUserAnalyticsTrack(3422, DataModal.cloneModelData.infoParam.cluster);
        this._closeBtn.setVisible(false);

        // 可以轉
        if (this._coinCount === 3) {
            if (this._hit !== -1) {
                this.isLockBackKey = true;
                this._wheelNode.spineClicked(sender);
            } else {
                // 避免 server 送來錯誤的資料，直接跳獎勵
                this._wheelSpinFinishCallback();
            }
            return;
        }

        // 不能轉 導儲值中心 (已經在儲值中心的話不要再導)
        // 埋點：5252 分身模組_轉盤 點擊馬上儲值按鈕
        TexasUtility.sendUserAnalyticsTrack(5252, DataModal.cloneModelData.infoParam.cluster);

        if (!PushScene.checkNowLayer(PurchaseLayer)) {
            PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
        }
        GS.dispatchCustomEvent("NotifyCloseCloneMainDialog");
    },

    _explainBtnClicked: function () {
        if (!this._infoParam)
            return;

        let infoParam = this._infoParam;
        let url = TexasUtility.getSimpleInfoURLByKey("plan_replacement_wheel", ["cluster=" + infoParam.cluster, "skin=" + infoParam.skinType, "group=" + infoParam.group]);
        let webInfoDialog = this._webInfoDialog = new WebViewDialog(url);
        webInfoDialog.setCloseCallback(() => {
            this._webInfoDialog = undefined;
        });
        webInfoDialog.startDialogAnimation();
        this._animationLayer.addChild(webInfoDialog, 1000);
    },

    // 轉盤轉完 callback
    _wheelSpinFinishCallback: function () {
        // 解開鎖按鈕
        this.isLockBackKey = false;
        this._closeBtn.setEnabled(false);

        // 轉完獲獎的dialog
        if (this._rechargeParam && this._rechargeParam.progressReward) {
            let dialog = new CloneModelWheelAwardRewardDialog(this._rechargeParam.progressReward);
            dialog.setCloseCallback(() => {
                // 清除儲值資料
                DataModal.cloneModelData.rechargeParam = undefined;

                // 重新要 info
                DataModal.cloneModelData.startGetInfo();

                // 開啟分身模組視窗
                if (this._whereType === CloneModelIconNode.WhereType.LOBBY) {
                    if (!DialogManager.isExist("CloneModelMainDialog")) {
                        DialogManager.addLobbyDialog(new CloneModelMainDialog(this._whereType));
                    }
                } else {
                    DialogManager.addDialog(new CloneModelMainDialog(this._whereType));
                }

                this.closeDialogAnimation();
            });
            this.addChild(dialog, 1000);
            dialog.startDialogAnimation();
        } else {
            DataModal.cloneModelData.startGetInfo();
            this.closeDialogAnimation();
        }
    },

    /**
     * 通知關閉
     */
    notifyCloseCloneMainDialog: function (event) {
        const param = event?.getUserData();
        const isAnimeEnabled = param?.isAnimeEnabled ?? true;

        if (isAnimeEnabled) {
            this._closeDialogAnimation();
        } else {
            this.removeFromParent();
        }
    }
});