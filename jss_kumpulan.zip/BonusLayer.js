/**
 * Bonus機台 主頁面
 * 目前只有德撲有
 * Voice是用到Vegas_MusicUtility
 */
var BonusLayer = VegasGameBaseLayer.extend({
    initProperties: function () {
        this._gameState = BonusStateType.BET_ANTE;      // 目前遊戲的程序
        this._lowestBet = 0;                            // 最低下注限制
        this._highestBet = 0;                           // 最高下注限制
        this._bringInRetry = 0;                         // 攜入錯誤的重試, 超過三次的話就離開遊戲
        this._passStatus = {};                          // 玩家決策狀態

        this._enableProcessMessage = true;              // 是否可以執行cmd
    },

    ctor: function () {
        this._super();
        this.initProperties();

        cc.spriteFrameCache.addSpriteFrames("vegas/bonus/bonus.plist", "vegas/bonus/bonus.png");

        // 設定機台是哪一個 一定要設
        this._vegasType = VegasGameType.BONUS;
        this._smId = DataModal.vegasData.getVegasSMIDMapByVegasGameType(this._vegasType);

        // 清掉指令
        DataModal.vegasData.cleanMessageQueue(this._vegasType);

        // 新增返回按鈕
        this._backMenuItem = this._addBackButton(this._backBtnClicked, this, 10);

        // 右上方說明按鈕
        this._infoMenuItem = this._addInfoButton(this._infoBtnClicked, this, 10);

        // 新增天線
        this._addAntenna(10);
        this._vegasAntennaLayer.setPosition(68, 26);

        // 牌桌背景
        var tableLayer = this._bonusTableLayer = new BonusTableLayer();
        this.addChild(tableLayer);

        // 新增聚寶盆icon
        var treasureBowlIcon = new TreasureBowlGameIconNode();
        treasureBowlIcon.setGameTypeAddProgressBar(VegasGameType.BONUS);
        treasureBowlIcon.setScale(0.75);
        treasureBowlIcon.setPosition(JSVisibleSize.width - JSScreenSafeWidth - 40, 45);
        this.addChild(treasureBowlIcon);

        // 下注按鈕
        var bonusUINode = this._bonusUINode = new BonusUINode();
        this.addChild(bonusUINode, 1);

        // 玩家
        var bonusPlayersLayer = this._bonusPlayersLayer = new BonusPlayersLayer();
        this.addChild(bonusPlayersLayer);

        // 籌碼
        var bonusChipsLayer = this._bonusChipsLayer = new BonusChipsLayer();
        this.addChild(bonusChipsLayer);

        // 牌
        var bonusPokersLayer = this._bonusPokersLayer = new BonusPokersLayer();
        this.addChild(bonusPokersLayer);

        // 預設注額範圍 TODO:目前是client寫死，待日後改吃server
        this._setBetRange(1000000, 10000000000);

        // 註冊通知
        GS.addListener("NotifyBonusCanPlay", this.notifyBonusCanPlay.bind(this), this);
        GS.addListener("NotifyBonusBusyDone", this._startProcess.bind(this), this);
        GS.addListener("NotifyStopCountdown", this._stopCountdown.bind(this), this);
        GS.addListener(DataModal.vegasData.getCmdNotifyName(VegasGameType.BONUS), this.notifyReceiveCommand.bind(this), this);
    },

    onEnter: function () {
        this._super();

        // 加Android back key
        PushScene.addBackKeyEnableLayer(this);
    },

    onExit: function () {
        PushScene.removeBackKeyEnableLayer(this);

        cc.spriteFrameCache.removeSpriteFramesFromFile("Texas_lobby/bonus/bonus.plist");

        this._super();
    },

    /**
     * 準備進遊戲(用來通知server玩家入桌和一般機台不同走自己的方法)
     * @override
     */
    _prepareToStartGame: function () {
        // 初始化機台,joinBonusP single要有回傳bonus_canplay, 才可以開始play
        GSLoading.addLoadingView();

        // 通知server
        DataProcess.sendString("joinBonusP single");
    },

    // An 返回鍵
    keyBackPressed: function () {
        this._backBtnClicked();
    },

    /**
     * 回大廳
     * @override
     */
    _toLobby: function () {
        // 加Loading
        GSLoading.addLoadingView();

        // 送離開指令
        DataProcess.sendString("bonus_exit");

        // Domino移植設定
        // Bonus要額外通知娛樂城大廳要刷新畫面
        GS.dispatchCustomEvent("NotifyRefreshVegasGames");
    },

    /**
     * 設定下注區間
     * @param {Number} lowestBet 下限
     * @param {Number} highestBet 上限
     */
    _setBetRange: function (lowestBet, highestBet) {
        this._lowestBet = lowestBet;
        this._highestBet = highestBet;
        // 設定上方下注金額區間文字
        this._bonusUINode.setBetText(lowestBet, highestBet);
    },

    /**
     * 計算Ante的上限
     */
    _checkAnteBetLimit: function () {
        var player = this._bonusPlayersLayer.getUserPlayer();
        if (player) {
            var limit = parseInt(player.playerData.money / 5);
            if (limit > this._highestBet)
                limit = this._highestBet;

            this._bonusUINode.setPnNumber(limit, this._lowestBet);
            this._bonusUINode.resetRaiseLayer();
        }
    },

    /**
     * 讓玩家可以開始選擇
     */
    _notifyCanBet: function () {
        this._bonusTableLayer.notifyCanBet(this._gameState);
        this._bonusUINode.notifyCanBet(this._gameState);
    },

    /**
     * 把遊戲桌清空
     */
    _resetGame: function () {
        this._gameState = BonusStateType.BET_ANTE;
        this._passStatus = {};

        this._bonusTableLayer.clean();
        this._bonusUINode.clean();
        this._bonusPlayersLayer.clean();
        this._bonusChipsLayer.clean();
        this._bonusPokersLayer.clean();

        this.runAction(cc.sequence(
            cc.delayTime(2.5),
            cc.callFunc(() => this._startProcess())
        ));
    },

    /**
     * 開始倒數計時
     * @param   {Number}    time    倒數時間
     * @param   {Date}      nowTime 現在時間
     */
    _startCountdown: function (time, nowTime) {
        // 牌桌上的倒數畫面
        this._bonusUINode.startClockCountdown(time, nowTime);
        // 玩家倒數
        var player = this._bonusPlayersLayer.getUserPlayer();
        player && player.startClock(time, nowTime);
    },

    /**
     * 關閉倒數計時
     */
    _stopCountdown: function () {
        this._bonusUINode.stopClockCountdown();
        var player = this._bonusPlayersLayer.getUserPlayer();
        player && player.stopClock();

        // 把按鈕都關起來
        this._bonusUINode.enableBet(false);
    },

    /**
     * 清除桌面顯示
     */
    _removeTableVisual: function () {
        this._bonusTableLayer.removeBetPlacementState();
        this._bonusTableLayer.dismissNotifyText();
        this._bonusUINode.enableBet(false);
    },

    /**
     * 按到返回按鈕
     * @override
     */
    _backBtnClicked: function () {
        var bonusStr = LocalizedString.Bonus;
        var param = {
            title: bonusStr("離開遊戲"),
            content: bonusStr("牌局進行中，若中途離開\n已下注的金額不會歸還\n \n確定要離開嗎？"),
            buttons: [bonusStr("離開"), bonusStr("繼續遊戲")],
            callback: (index) => {
                if (index === 0) {
                    this._toLobby();
                }
            }
        };
        DialogManager.addDialog(new AvatarDialog(param));
    },

    /**
     * 跳Bonus教學
     */
    _infoBtnClicked: function () {
        DialogManager.addDialog(new VegasIntroDialog(VegasGameType.BONUS));
    },

    /**
     * 通知事件
     */

    /**
     * 通知Bonus可以開始玩
     */
    notifyBonusCanPlay: function () {
        GSLoading.removeLoadingView();

        DataProcess.sendString("get_camp_mood_list");          // 抓現在可使用哪些表情
        DataProcess.sendString("get_broke_payment_json");      // 抓遊戲中儲值payment
        DataProcess.sendString("store_mood_backpack");

        // 直接帶入全部金錢
        DataProcess.sendString(JSStringUtility.format("bonus_bring_in %d", DataModal.profileData.money));

        // 側邊欄
        this._addSideOptionLayer(7);

        // 牌王之路icon
        this._addGamblerRoadIconNode(7, -2, -2);
    },

    /**
     * 開始抓socket
     */
    notifyReceiveCommand: function () {
        this._processAllMessage();
    },

    /******** 處理cmd ********/
    _processMessage: function () {
        var cmd = DataModal.vegasData.popQueuedMessage(VegasGameType.BONUS);
        if (cmd) {
            switch (cmd.key) {
                /**
                 * 更新座位，目前會只有一個玩家 (自己)
                 */
                case "bonus_updateSeat":
                    var jsonValue = JSON.parse(cmd.value || []);
                    if (jsonValue && Array.isArray(jsonValue)) {
                        jsonValue.forEach((cur, idx) => {
                                if (cur) {
                                    // 玩家帳號
                                    var playerID = JSCodeUtility.getStringValue(cur["userid"]);
                                    if (playerID.length) {
                                        var param = {};
                                        param.account = playerID;
                                        // 玩家大頭貼
                                        param.photoURL = JSCodeUtility.getStringValue(cur["pic"]);
                                        // 玩家暱稱
                                        param.nickname = decodeURIComponent(JSCodeUtility.getStringValue(cur["nick"]));
                                        // 玩家攜入的金額
                                        param.tableChips = JSCodeUtility.getIntValue(cur["chips"]);
                                        // 玩家身上的金額
                                        param.money = JSCodeUtility.getIntValue(cur["tmoney"]);
                                        // 玩家框框類型
                                        param.identity = JSCodeUtility.getStringValue(cur["identity"]);

                                        // 玩家裝備物品編號
                                        var accessory = JSCodeUtility.getStringValue(cur["accessory"]);
                                        var accessoryName = decodeURIComponent(JSCodeUtility.getStringValue(jsonValue["name_accessory"]));
                                        if (accessory === "1101") {
                                            accessoryName = "";
                                            accessory = "";
                                        }
                                        param.accessory = {};
                                        param.accessory.name = accessoryName;
                                        param.accessory.code = accessory;

                                        // 玩家裝備徽章編號
                                        var medal = JSCodeUtility.getStringValue(cur["medal"]);
                                        var medalName = decodeURIComponent(JSCodeUtility.getStringValue(cur["name_medal"]));
                                        if (medal === "8101") {
                                            medalName = "";
                                            medal = "";
                                        }
                                        param.medal = {};
                                        param.medal.name = medalName;
                                        param.medal.code = medal;

                                        // 是自己
                                        if (DataModal.profileData.account === param.account) {
                                            // 從profileData中抓自己的相關資料
                                            var profileData = DataModal.profileData;
                                            param.exp = profileData.exp;
                                            param.level = profileData.level;
                                            param.titleName = profileData.titleName;
                                            param.isMe = true;

                                            // 如果場上還沒有人直接加入玩家
                                            if (this._bonusPlayersLayer.getPlayerCount() === 0) {
                                                this._bonusPlayersLayer.addPlayer(param);
                                                var player = this._bonusPlayersLayer.getUserPlayer();
                                                player && player.showJoinTableAni();
                                            }
                                            // 如果有人就將第0個位置取代成自己
                                            else {
                                                var player = this._bonusPlayersLayer.getUserPlayer();
                                                if (player)
                                                    player.setPlayerData(param);
                                            }
                                        }
                                        // 不是自己
                                        else {
                                            param.isMe = false;
                                            param.isMale = JSCodeUtility.getStringValue(jsonValue["gender"]) === "m";

                                            // 如果場上玩家人數還沒滿就新增
                                            if (this._bonusPlayersLayer.getPlayerCount() < 5) {
                                                this._bonusPlayersLayer.addPlayer(param);
                                            }
                                            // 場上玩家人數滿了就抓一個取代掉
                                            else {
                                                this._bonusPlayersLayer.getPlayerByIndex(idx).setPlayerData(param);
                                            }
                                        }
                                    }
                                }
                            }
                        );
                    }
                    break;

                case "bonus_bring_in":
                    if (this._bonusPlayersLayer.getPlayerCount() > 0) {
                        var player = this._bonusPlayersLayer.getUserPlayer();
                        player && player.setPlayerMoney(JSCodeUtility.getIntValue(cmd.value));
                    }
                    break;

                case "bonus_tmoney":
                    var stringArray = cmd.value.split(" ") || [];
                    var money = JSCodeUtility.getIntValue(stringArray[0]);
                    if (this._bonusPlayersLayer.getPlayerCount() > 0)
                        this._bonusPlayersLayer.getPlayerByAccount(stringArray[1]).setPlayerMoney(money);
                    break;

                case "bonus_can_ante":
                    // 先檢查Ante的上限, 然後通知玩家可以下注了
                    this._checkAnteBetLimit();
                    this._notifyCanBet();
                    // Ante的時候不能Pass
                    this._bonusUINode.enablePassBtn(false);
                    break;

                case "bonus_ante":
                    this._enableProcessMessage = false;

                    // 玩家下注金額
                    var stringArray = cmd.value.split(" ") || [];
                    var bet = JSCodeUtility.getIntValue(stringArray[0]);

                    this._bonusTableLayer.dismissNotifyText();
                    this._bonusUINode.setAnteBet(bet);
                    this._removeTableVisual();

                    // 玩家下注成功, 移動籌碼
                    this._bonusChipsLayer.placePlayerChip(this._gameState, bet, () => {
                        this._startProcess();
                    });

                    // 更新聚寶盆 透過網址
                    DataModal.treasureBowlData.treasureBowlParam && DataModal.treasureBowlData.updateDataBy(bet);

                    // 存下遊戲紀錄
                    this._savePlayerRecord();

                    break;

                case "bonus_timeout":
                    this._startCountdown(JSCodeUtility.getIntValue(cmd.value), new Date().getTime());
                    // 按鈕開放使用
                    this._notifyCanBet();
                    break;

                case "bonus_max_bonus":
                    // 設定玩家最大Bonus的下注
                    var stringArray = cmd.value.split(" ") || [];
                    // 顯示玩家的錢
                    var canBonusMoney = JSCodeUtility.getIntValue(stringArray[0]);
                    if (canBonusMoney > 0) {
                        this._bonusUINode.setPnNumber(canBonusMoney, this._lowestBet);
                    }
                    break;

                case "bonus_can_bonus":
                    this._gameState = BonusStateType.BET_BONUS;
                    break;

                case "bonus_bonus":
                    // 只有有下注的時候會移動籌碼
                    var stringArray = cmd.value.split(" ") || [];
                    var money = JSCodeUtility.getIntValue(stringArray[0]);

                    this._enableProcessMessage = false;

                    this._removeTableVisual();

                    this._bonusChipsLayer.placePlayerChip(this._gameState, money, () => {
                        this._startProcess();
                    });

                    // 更新聚寶盆 透過網址
                    DataModal.treasureBowlData.treasureBowlParam && DataModal.treasureBowlData.updateDataBy(money);
                    break;

                case "bonus_two_card":
                    // 把兩張玩家牌加入進行設定
                    var jsonValue = JSON.parse(cmd.value || []);
                    if (jsonValue.length === 2) {
                        var player = this._bonusPlayersLayer.getUserPlayer();
                        if (player) {
                            this._enableProcessMessage = false;

                            // 發玩家跟莊家的牌
                            var card1 = JSCodeUtility.getStringValue(jsonValue[0]);
                            var card2 = JSCodeUtility.getStringValue(jsonValue[1]);

                            this._bonusPokersLayer.dealHandCard([card1, card2], () => {
                                this._startProcess();
                            });

                            // bonus已經bet完, 所以先關掉通知,跟讓玩家不能下注
                            this._bonusTableLayer.dismissNotifyText();
                            this._bonusTableLayer.updateBetPlacementLightPos(this._gameState);
                        }
                    }

                    break;

                case "bonus_can_flop":
                    // 通知玩家可以下注了
                    this._gameState = BonusStateType.FLOP_START;
                    break;

                case "bonus_can_turn":
                    // 通知玩家可以下注了
                    this._gameState = BonusStateType.TURN_START;
                    break;

                case "bonus_can_river":
                    // 通知玩家可以下注了
                    this._gameState = BonusStateType.RIVER_START;
                    break;

                case "bonus_flop":
                case "bonus_turn":
                case "bonus_river":
                    // bonus_flop/bonus_turn/bonus_river 2000000 8496310 ivan001@an

                    this._enableProcessMessage = false;

                    var stringArray = cmd.value.split(" ") || [];
                    var money = JSCodeUtility.getIntValue(stringArray[0]);

                    this._removeTableVisual();
                    this._bonusChipsLayer.placePlayerChip(this._gameState, money, () => {
                        this._stopCountdown();
                        this._startProcess();
                    });

                    if (money === 0) {
                        // 記下哪些步驟被Pass
                        this._passStatus[cmd.key] = true;
                    }

                    // 更新聚寶盆 透過網址
                    DataModal.treasureBowlData.treasureBowlParam && DataModal.treasureBowlData.updateDataBy(money);
                    break;

                case "bonus_flop_cards":
                    if (this._passStatus["bonus_flop"]) {
                        //單人版要擋
                        return;
                    }

                    // 把三張Flop牌加入並發牌
                    var jsonValue = JSON.parse(cmd.value || []);
                    if (jsonValue.length === 3) {
                        this._enableProcessMessage = false;

                        // 發完牌才解開this._enableProcessMessage
                        // 發三張Flop牌
                        this._bonusPokersLayer.cmd_bonus_flop_cards(jsonValue, () => {
                            this._startProcess();
                        });
                    }

                    break;

                case "bonus_turn_cards":
                    if (this._passStatus["bonus_flop"]) {
                        // 單人版要擋
                        return;
                    }

                    // 把第四張Turn牌加入並發牌
                    var jsonValue = JSON.parse(cmd.value || []);
                    if (jsonValue.length === 4) {
                        this._enableProcessMessage = false;

                        // 發Turn牌
                        this._bonusPokersLayer.cmd_bonus_turn_cards(jsonValue, () => {
                            this._startProcess();
                        });
                    }

                    break;

                case "bonus_river_cards":
                    if (this._passStatus["bonus_flop"]) {
                        // 單人版要擋
                        return;
                    }

                    // 把第五張River牌加入並發牌
                    var jsonValue = JSON.parse(cmd.value || []);
                    if (jsonValue.length === 5) {
                        this._enableProcessMessage = false;

                        // 發River牌
                        this._bonusPokersLayer.cmd_bonus_river_cards(jsonValue, () => {
                            this._startProcess();
                        });
                    }

                    break;

                case "bonus_showdown":
                    this._enableProcessMessage = false;

                    var jsonValue = JSON.parse(cmd.value || {});

                    if (JSCodeUtility.getIntValue(jsonValue["fold"]) === 1) {
                        // 如果玩家棄牌的話, 直接將ante跟牌回收
                        this._bonusChipsLayer.playerFold();
                        this._bonusPokersLayer.flipAllCardToBack(() => {
                            // 通知外面動畫結束，檢查有沒有事情要做
                            this.notifyVegasGameFinished();
                            this._resetGame();
                        });
                        // 棄牌語音
                        Vegas_MusicUtility.playVoice("fold.mp3");
                        break;
                    }

                    // 沒有棄牌
                    this._bonusTableLayer.removeBetPlacementState();
                    this._bonusTableLayer.dismissNotifyText();
                    this._bonusUINode.displayNotifyNode(LocalizedString.Bonus("Good Luck To You"));

                    // 抓出玩家
                    var players = (jsonValue["players"] || []);
                    var player = (players[0] || {});

                    // 0: 平手 1: 玩家贏 -1: 莊家贏
                    var playerWinStatus = JSCodeUtility.getIntValue(player["win"]);

                    // 抓獎金
                    var reward = (player["reward"] || {});

                    var winMoney = JSCodeUtility.getIntValue(reward["reward"]);
                    var bonusWin = JSCodeUtility.getIntValue(reward["bonus"]);    // 玩家Bonus贏的錢

                    // 發莊家的牌
                    this._bonusPokersLayer.cmd_bonus_showdown(jsonValue, this._passStatus, (bonusParam) => {
                        var playerNode = this._bonusPlayersLayer.getUserPlayer();
                        var isBonusWin = playerNode && bonusParam.winRate > 0 && bonusWin > 0;
                        if (isBonusWin) {
                            // 中Bonus的話 顯示動畫
                            playerNode.showBonusWinAni(bonusParam.winRate, bonusParam.winType, bonusParam.cardList);
                            playerNode.setPlayerMoney(playerNode.playerData.money + bonusWin);
                        }

                        // 平手時不顯示
                        var isPlayerWin = (playerWinStatus === 1);
                        var isAnteWin = false;              // 玩家是否贏了Ante
                        if (playerWinStatus !== 0) {
                            var resultCards, resultType;
                            // 顯示玩家贏牌
                            if (isPlayerWin) {
                                // 抓出玩家的牌組
                                resultCards = player["pcomb"] || [];
                                resultType = JSCodeUtility.getIntValue(player["pdt"]);

                                if (isBonusWin)
                                    this.runAction(cc.sequence(
                                        cc.delayTime(2),
                                        cc.callFunc(() => this._bonusPlayersLayer.showPlayerWinAnimeByIdx(0))
                                    ));
                                else
                                    this._bonusPlayersLayer.showPlayerWinAnimeByIdx(0);

                                isAnteWin = resultType > 3; // 順子以上才算贏
                            }
                            // 顯示莊家贏牌
                            else {
                                // 抓出莊家的牌組
                                resultCards = jsonValue["bcomb"] || [];
                                resultType = JSCodeUtility.getIntValue(jsonValue["bdt"]);
                            }

                            // 顯示贏的卡
                            this._bonusPokersLayer.displayWinningCard(resultCards, () => {
                                // 變換下方狀態列文字
                                this._bonusUINode.displayWinInfoWithNotifyNode(playerWinStatus, resultType, resultCards);
                            });
                        } else {
                            // 平手
                            this._bonusUINode.displayWinInfoWithNotifyNode(playerWinStatus);
                        }

                        // 發籌碼
                        this._bonusChipsLayer.checkBonusBet(JSCodeUtility.getIntValue(reward["bonus"]), bonusParam.winRate);
                        this._bonusChipsLayer.cmd_bonus_showdown(playerWinStatus, this._passStatus, isAnteWin);

                        this.runAction(cc.sequence(
                            cc.delayTime(2.5),
                            cc.callFunc(() => {
                                var playerNode = this._bonusPlayersLayer.getUserPlayer();
                                if (playerNode && winMoney > 0)
                                    playerNode.setPlayerMoney(playerNode.playerData.money + winMoney);
                            }),
                            cc.delayTime(0.5),
                            cc.callFunc(() => this._bonusPokersLayer.flipAllCardToBack()),
                            cc.delayTime(2),
                            cc.callFunc(() => {
                                this._resetGame();
                                // 通知bonus結束動畫完成
                                this.notifyVegasGameFinished();
                            })
                        ));
                    });

                    break;

                case "bonus_exit":
                    // 要離開機台了 先關掉所有Dialog
                    DialogManager.cleanAllDialog();

                    var stringArray = cmd.value.split(" ") || [];
                    if (stringArray.length) {
                        var reason = JSCodeUtility.getIntValue(stringArray[1]);
                        switch (reason) {
                            case 1:
                                // 當錢不夠再繼續下一場遊戲
                                var dialogObj = new AvatarDialog(DialogHelper("RoomNoMoney", ""));
                                // TODO: 目前沒有DialogManager addDialogToQueueByCounter
                                // dialogObj.addToQueue = true;
                                DialogManager.addDialog(dialogObj);

                                break;
                            case 2:
                                // 太久沒動作 返回Lobby
                                var param = {
                                    title: LocalizedString.Bonus("返回大廳"),
                                    content: LocalizedString.Bonus("太久沒動作 返回大廳"),
                                    buttons: [LocalizedString.Bonus("確認")]
                                };
                                DialogManager.addDialog(new AvatarDialog(param));

                                break;
                        }
                    }

                    // 回大廳
                    this._toLobby();

                    break;

                case "bonus_error":
                    // 錯誤處理
                    switch (JSCodeUtility.getIntValue(cmd.value)) {
                        case 0:
                            if (this._bringInRetry < 3) {
                                DataProcess.sendString(JSStringUtility.format("bonus_bring_in %d", DataModal.profileData.money));
                                this._bringInRetry++;
                                break;
                            } else {
                                // 沒辦法Bring in, 離開遊戲
                                this._toLobby();
                            }

                            break;
                        case 1:
                            //1 # 攜入的錢不夠繼續玩
                            //當錢不夠再繼續下一場遊戲, 回到Lobby
                            this._toLobby();
                            break;
                        case 2:
                            //2 # 緊急停機不給玩,跳出訊息回到大廳
                            var dialogObj = DialogHelper("VegasBonusShutdown");
                            dialogObj.closeButton = false;
                            DialogManager.addDialog(new AvatarDialog(dialogObj));
                            break;
                        case 3:
                            //3 # 下注金額超出或低於需求
                            break;
                        case 4:
                            //4 # client送了server看不懂的command
                            //command是寫死的 所以發生機率不大, 發生的話可能照遊戲階段重送command?
                            break;
                        case 5:
                            //5 # 沒有下ante注就下了bonus注
                            break;
                        case 6:
                            //6 # 還沒看到兩張手牌就傳了flop、turn或是river的command
                            //遊戲因為是收到手牌後才會進行flop的動作, 所以發生機率不大, 發生的話回到BetBonus?
                            break;
                        case 7:
                            //7 # 在不對的時間吐了command給server
                            //遊戲是收到一個指令後才會進行下一步, 所以發生機率不大, 不然就是得檢查遊戲階段了
                            break;
                        default:
                            break;
                    }

                    break;

                // 單人版先不處理
                case "bonus_pending":
                case "bonus_condition":
                default:
                    this._enableProcessMessage = true;
                    break;
            }
        }

        return !!cmd;
    },

    /**
     * 重新開始處理指令
     */
    _startProcess: function () {
        this._enableProcessMessage = true;
        this._processAllMessage();
    },

    // 一直處理指令 直到沒有或有動畫停止
    _processAllMessage: function () {
        //一直抓cmd直到沒有
        while (this._enableProcessMessage && this._processMessage()) {
        }
    }
});