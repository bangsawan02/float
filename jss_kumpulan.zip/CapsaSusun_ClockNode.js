/**
 * 倒數時間 (移植 MP 時鐘的Node)
 * callback 倒數完的callback
 */

var CapsaSusun_ClockNode = cc.Node.extend({
    ctor: function (callback) {
        this._super();

        this.setCascadeOpacityEnabled(true);

        this._callback = callback;              // 倒數完的callback

        this.maxTime = 0;                       // 最大時間
        this.notifySecond = 5;                  // 剩下幾秒的時候開始播放提醒音效/動畫
        this.needPlayEffect = true;             // 是否需要播放音效
        this.needPlayAnimation = true;          // 是否需要播放動畫
        this.needShock = true;                  // 是否已經完成決策

        this._playEffectTime = 0;

        var clockNode = this._clockNode = new cc.Node();
        this.addChild(clockNode);

        // 時鐘的圓形
        var clockCircle = this._clockCircle = new cc.Sprite("#capsaSusun_pic_clock.png");
        clockNode.addChild(clockCircle);

        this._numberSprite = [];
        for (var i = 0; i < 2; i++) {
            this._numberSprite[i] = new cc.Sprite("#number_07_0.png");
            this._numberSprite[i].setScale(0.65);
            clockNode.addChild(this._numberSprite[i], 2);
        }

        // 註冊
        GS.addListener("NotifyReconnectDone", this.notifyReconnectDone.bind(this), this);
    },

    /**
     * 設定倒數完的callback
     */
    setTimeoutCallback: function (callback) {
        this._callback = callback;
    },

    /**
     * 更新時間圖片
     */
    _updateTimeSprite: function (time) {
        var nowTime = time;

        var numberSprite = this._numberSprite;

        if (nowTime < 1) {
            // 倒數完了
            this._timeout();

            numberSprite[0].setVisible(false);
            numberSprite[1].setPosition(0, 0);

            numberSprite[1].setSpriteFrame("number_07_0.png");
        } else {
            if (nowTime > 100)
                nowTime %= 100;

            if (nowTime >= 10) {
                // numberSprite[0].setScale(0.9);
                numberSprite[0].setPosition(-5.5, 0);
                // numberSprite[1].setScale(0.9);
                numberSprite[1].setPosition(5.5, 0);

                numberSprite[0].setSpriteFrame(JSStringUtility.format("number_07_%d.png", nowTime / 10));
                numberSprite[0].setVisible(true);
                numberSprite[1].setSpriteFrame(JSStringUtility.format("number_07_%d.png", nowTime % 10));
                numberSprite[1].setVisible(true);
            } else {
                numberSprite[0].setVisible(false);
                numberSprite[1].setPosition(0, 0);
                // numberSprite[1].setScale(1);

                numberSprite[1].setSpriteFrame(JSStringUtility.format("number_07_%d.png", nowTime % 10));
            }

            if ((nowTime < this.notifySecond) && this.needPlayEffect && this._playEffectTime !== nowTime) {
                this._playEffectTime = nowTime;
            }

            // 假如是自己 且剩餘時間進入提示秒數範圍
            if (nowTime < this.notifySecond && this.needPlayAnimation) {
                MusicUtility.playEffect("Music/Effect/clockhurry.mp3");

                // 判斷是否要震動
                if (DataModal.settingData.capsaSusun.vibrateBefore3Sec && cc.sys.isNative && this.needShock) {
                    cc.Device.vibrate(0.2);
                }

                this._clockNode.runAction(cc.sequence(
                    cc.scaleTo(0.2, 1.3),
                    cc.scaleTo(0.2, 1)
                ));
            }
        }
    },

    /**
     * 更新時間
     */
    //更新時間
    _refreshTime: function () {
        //避免玩家縮下去暫停遊戲時間不準確
        var elapsedTime = ((new Date()).getTime() - this._startSystemTime) / 1000;
        if (elapsedTime - this._reduceTime > 1) {
            this._reduceTime = elapsedTime;
        }

        var nowTime = this.maxTime - this._reduceTime;
        if (nowTime >= 0) {
            this._updateTimeSprite(nowTime);
            this._reduceTime++;
        }
    },

    /**
     * 倒數完了
     */
    _timeout: function () {
        this.stop();
        if (this._callback)
            this._callback();
    },

    /**
     * 開始倒數
     */
    start: function (time) {
        this.stopAllActions();
        this.setVisible(true);

        this.needShock = true;

        // 設定時間
        this.maxTime = time || this.maxTime;
        this._startSystemTime = (new Date()).getTime();
        this._reduceTime = 0;
        this._playEffectTime = 0;

        // 假如是自己 要把自己的背景停止轉動
        if (this._clockCircleAnimation) {
            this._clockCircle.stopAllActions();
            this._clockCircle.setRotation(0);
            this._clockCircleAnimation = false;
        }

        // 淡入
        this.runAction(cc.fadeTo(0.2, 255));

        // 不是牌局重現, 開始計數
        if (!DataModal.gameData.isReappearing) {
            this._startCounting();
        }
    },

    /**
     * 開始計數
     */
    _startCounting: function () {
        // 先跑一次畫面
        this._refreshTime();

        // 每一秒更新一次
        var action = cc.repeatForever(cc.sequence(
            cc.delayTime(1),
            cc.callFunc(this._refreshTime, this)
        ));
        this.runAction(action);
    },

    /**
     * 停止搖晃
     */
    setShock: function (isShock) {
        this.needShock = isShock;
    },

    /**
     * 停止
     */
    stop: function () {
        this.stopAllActions();

        if (this.isVisible()) {
            this.runAction(cc.sequence(cc.fadeTo(0.2, 0), cc.hide()));
        }

        // 假如是自己 要把自己的背景停止轉動
        if (this._clockCircleAnimation) {
            this._clockCircle.stopAllActions();
            this._clockCircle.setRotation(0);
            this._clockCircleAnimation = false;
        }
    },

    /**
     * 通知
     */
    // 斷線重連回來
    notifyReconnectDone: function () {
        if (this.isVisible()) {
            // 開始原本的倒數
            this._startCounting();
        }
    }
});