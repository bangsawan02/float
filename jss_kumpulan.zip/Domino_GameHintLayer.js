/**
 * 遊戲上方的提示畫面
 */

var Domino_GameHintLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // Queue Array
        this._queueArray = [];

        // 是否在顯示動畫中
        this._isShowing = false;

        // 上方的提示訊息
        this._oldMessageNode = null;

        // 提示要換桌的東西
        var changeTableNode = this._changeTableNode = new cc.Node();
        changeTableNode.setVisible(false);
        this.addChild(changeTableNode);

        var changeTableBg = new cc.Sprite("#lobby_pic_black.png");
        changeTableBg.setScale(6, 5.5);
        changeTableBg.setPosition(JSScreenMidPos.x, DOMINO_UILAYER_BUTTON_Y);
        changeTableNode.addChild(changeTableBg);

        var changeTableLabel = new cc.LabelTTF(LocalizedString.Game("牌桌人數已滿"), JSFontBoldName, 14);
        changeTableLabel.setPosition(changeTableBg.getPosition());
        changeTableNode.addChild(changeTableLabel);

        // 按鈕
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        changeTableNode.addChild(menu);

        var faceButtonWidth = 82;           // 左邊擺放表情的按鈕寬
        var totalWidth = JSVisibleSize.width - JSScreenSafeWidth * 2 - faceButtonWidth;
        var buttonSize = cc.size((totalWidth - 4 * 5) / 5, DOMINO_UILAYER_BUTTON_HEIGHT);
        var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", buttonSize, "Ganti Meja", 12, JSColor.BLACK);
        var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._changeTableClicked, this);
        menuItem.setAnchorPoint(1, 0.5);
        menuItem.setPosition(JSVisibleSize.width - JSScreenSafeWidth - 3, DOMINO_UILAYER_BUTTON_Y);
        menu.addChild(menuItem);

        // 監聽
        GS.addListener("NotifyShowTopMessage", this._notifyShowTopMessage.bind(this), this);
    },

    /**
     * 開始出現
     */
    _show: function () {
        if (this._queueArray.length === 0 || this._isShowing || this._oldMessageNode)
            return;

        // 讓他出現
        this._isShowing = true;

        var showNode = this._queueArray.shift();
        var height = showNode.getContentSize().height;
        showNode.setAnchorPoint(0.5, 0.5);
        showNode.setVisible(true);
        showNode.setPosition(JSScreenMidPos.x, JSVisibleSize.height + height / 2);
        showNode.runAction(cc.sequence(
            cc.moveBy(0.5, cc.p(0, -height)).easing(cc.easeIn(2)),
            cc.delayTime(2),
            cc.moveBy(0.5, cc.p(0, height)).easing(cc.easeOut(2)),
            cc.callFunc(function () {
                // 設定沒顯示了
                this._isShowing = false;

                // 再跑一次 看有沒有新的
                this._show();
            }, this),
            cc.removeSelf()
        ));
    },


    /**
     * 出現自訂義的畫面
     */
    showWithNode: function (node) {
        this._queueArray.push(node);

        // 把node先加進來 當做retain用
        this.addChild(node);
        node.setVisible(false);

        // 統一給show那邊判斷
        this._show();
    },

    /**
     * 設定提示換桌是否看到
     */
    setChangeTableHintVisible: function (isVisible) {
        this._changeTableNode.setVisible(isVisible);
    },

    /**
     * 自動攜入的提示
     * @param value 文字
     */
    cmd_auto_bring_in_msg: function (value) {
        // 剛為您攜入XXX,XXX,XXX,XXX遊戲幣
        var totalText = "Memberikan Anda #!FFFF50!#" + value + "#!FFFFFF!# Chips";

        var showNode = new cc.Node();

        // 文字
        var textNode = new GSRichTextNode(totalText, JSFontBoldName, 14);
        showNode.addChild(textNode, 1);

        // 算大小
        var textSize = textNode.getContentSize();
        var totalSize = cc.size(textSize.width + 30, textSize.height + 10);
        var midPos = cc.p(totalSize.width / 2, totalSize.height / 2);

        // 背景
        var bgNode = new ccui.Scale9Sprite("lobby_pic_black.png");
        bgNode.setPreferredSize(totalSize);
        showNode.addChild(bgNode);

        // 設定位置
        textNode.setPosition(midPos);
        bgNode.setPosition(midPos);

        // 設定大小
        showNode.setContentSize(totalSize);

        // 顯示
        this.showWithNode(showNode);
    },

    // 用來跳桌內上方的保護令提示
    cmd_gameRank_protect_info: function (value) {
        // gameRank_protect_info x   (x為保護令手數)
        var number = parseInt(value);
        var totalText = JSStringUtility.format(LocalizedString.GameRank("獲得俱樂部保護令防護%d手，\n祝牌運亨通！"), number);

        var showNode = new cc.Node();

        // 文字
        var textNode = new GSRichTextNode(totalText, JSFontBoldName, 14);
        textNode.setHAlignmentToCenter(true);
        showNode.addChild(textNode, 1);

        // 算大小
        var textSize = textNode.getContentSize();
        var totalSize = cc.size(textSize.width + 30, textSize.height + 10);
        var midPos = cc.p(totalSize.width / 2, totalSize.height / 2);

        // 背景
        var bgNode = new ccui.Scale9Sprite("lobby_pic_black.png");
        bgNode.setPreferredSize(totalSize);
        showNode.addChild(bgNode);

        // 設定位置
        textNode.setPosition(midPos);
        bgNode.setPosition(midPos);

        // 設定大小
        showNode.setContentSize(totalSize);

        // 顯示
        this.showWithNode(showNode);
    },

    /**
     * 通知
     */
    // 上方顯示的訊息
    _notifyShowTopMessage: function (event) {
        if (event && event.getUserData()) {
            var labelString = event.getUserData();

            // 這部份特別處理 因為他可以連點 要即時顯示
            this._oldMessageNode && this._oldMessageNode.removeFromParent();

            // 創新的畫面
            var showHeight = 32;
            var showMidHeight = showHeight / 2;
            var showNode = this._oldMessageNode = new cc.Node();
            showNode.setContentSize(cc.size(0, showHeight));
            this.addChild(showNode);

            // 背景
            var bgSprite = new ccui.Scale9Sprite("lobby_bg_list_04.png");
            bgSprite.setPreferredSize(cc.size(72, showHeight));
            bgSprite.setScaleX(5);
            bgSprite.setPosition(0, showMidHeight);
            showNode.addChild(bgSprite);

            // 文字
            var label = new cc.LabelTTF(labelString, JSFontBoldName, 10);
            label.setPosition(0, showMidHeight);
            showNode.addChild(label);

            // 顯示
            showNode.setPosition(JSScreenMidPos.x, JSVisibleSize.height + showHeight / 2);
            showNode.setAnchorPoint(0.5, 0.5);
            showNode.runAction(cc.sequence(
                cc.moveBy(0.5, cc.p(0, -showHeight)).easing(cc.easeIn(2)),
                cc.delayTime(2),
                cc.moveBy(0.5, cc.p(0, showHeight)).easing(cc.easeOut(2)),
                cc.callFunc(function () {
                    // 設定沒了
                    this._oldMessageNode = null;

                    // 再跑一次 看有沒有新的
                    this._show();
                }, this),
                cc.removeSelf()
            ));
        }
    },

    /**
     * 按鈕
     */
    // 按到換桌
    _changeTableClicked: function () {
        GS.dispatchCustomEvent("NotifyGameUIChangePlaceClicked", {isReplaceRoomByClickedUIButton: true});
    },
});