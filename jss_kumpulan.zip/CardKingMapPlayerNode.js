/**
 * 牌王地圖節點上的玩家框框
 */

var CardKingMapPlayerNode = cc.Node.extend({
    ctor: function (type = CardKingMapPlayerNode.Type.OTHER) {
        this._super();

        // 這是哪一種類型的
        this._type = type;

        // 等級
        this._level = 0;

        // 局數
        this._round = 0;

        // 泡泡匡的箭頭方向
        this._direction = undefined;

        // 現在是不是打開的
        this._open = true;

        // 這個節點上有沒有玩家, 沒有就隱藏
        this._hasPlayer = false;

        // 是不是玩家自己
        var isSelf = this._type === CardKingMapPlayerNode.Type.SELF;

        // 箭頭
        var arrowSp = this._arrowSp = new cc.Sprite();
        arrowSp.setAnchorPoint(0.5, 0);
        this.addChild(arrowSp, 0);

        // 背景node
        var bgNode = this._bgNode = new cc.Node();
        this.addChild(bgNode, 1);

        // 背景
        var bg = this._bg = new cc.Sprite();
        bgNode.addChild(bg, 1);

        // 自己字樣, 只有自己有
        if (isSelf) {
            var selfTitleSp = new cc.Sprite("#cardKing_word_self.png");
            selfTitleSp.setPosition(0, -18);
            bgNode.addChild(selfTitleSp, 3);
        }

        // 最強字樣
        var bestTitleSp = this._bestTitleSp = new cc.Sprite("#cardKing_word_best.png");
        bestTitleSp.setPosition(0, -18);
        bgNode.addChild(bestTitleSp, 3);
        bestTitleSp.setVisible(false);

        // 最強局數
        var bestRoundLabel = this._bestRoundLabel = new cc.LabelTTF("", JSFontName, 10);
        bestRoundLabel.setFontFillColor(JSColor.YELLOW);
        bestRoundLabel.enableStroke(cc.color(80, 10, 10, 255), 2);
        bestRoundLabel.setVisible(false);
        bestRoundLabel.setPosition(0, -28);
        bgNode.addChild(bestRoundLabel, 3);

        // 按鈕
        var btn = this._btn = new GSControlButton(undefined, cc.size(24, 24));
        btn.setChangeColorWhenDisabled(false);
        btn.setChangeOpacityWhenDisabled(false);
        btn.addTouchUpInsideAction(this.buttonClicked, this);
        btn.setSwallowTouches(false);
        bgNode.addChild(btn, 2);

        // 大頭照 要切成圓形
        var stencilSprite = new cc.Sprite("#lobby_photo_clip.png");
        stencilSprite.setScale(isSelf ? 0.62 : 0.52);
        var clipNode = new cc.ClippingNode(stencilSprite);
        clipNode.setAlphaThreshold(0.5);
        clipNode.setCascadeColorEnabled(true);
        clipNode.setCascadeOpacityEnabled(true);
        btn.addChildToContentNode(clipNode);

        var headPhotoSize = isSelf ? 33 : 30;
        var headPhoto = this._headPhoto = new PhotoSprite("", headPhotoSize, headPhotoSize);
        clipNode.addChild(headPhoto);

        this.changeArrowDirection(BaseMessageNode.Direct.LEFT);
        this.refresh();
    },

    refresh: function (data, level) {
        this._level = level || 0;
        this._round = data && data.round;
        this._bestRoundLabel.setVisible(false);

        // 有大頭貼網址表示有人
        if (data && data.playerImgUrl) {
            this._hasPlayer = true;
            this.setVisible(true);
            this._headPhoto.setPhotoUrlString(data.playerImgUrl);

            this._arrowSp.setLocalZOrder(1);
            this._bgNode.setLocalZOrder(2);

            this._bestTitleSp.setPosition(0, -18);
            this._bestTitleSp.setVisible(false);

            // 要是是自己, 又是第一名, 要不一樣
            if (this._type === CardKingMapPlayerNode.Type.SELF) {
                var bgName = "cardKing_pic_selfPlayer";
                if (data.isTop) {
                    bgName = "cardKing_pic_bestPlayer";

                    // 要把最強字移到上面
                    this._bestTitleSp.setPosition(0, 18);
                    this._bestTitleSp.setVisible(true);
                }
                this._bg.setSpriteFrame(JSStringUtility.format("%sBG.png", bgName));
                this._arrowSp.setSpriteFrame(JSStringUtility.format("%sArrow.png", bgName));
            } else if (data.isTop) {
                this._bestTitleSp.setVisible(true);
                this._bestRoundLabel.setVisible(true);
                this._bestRoundLabel.setString(JSStringUtility.format("(%d)", data.realRound || data.round));

                this._bg.setSpriteFrame("cardKing_pic_bestPlayerBG.png");
                this._arrowSp.setSpriteFrame("cardKing_pic_bestPlayerArrow.png");
            } else {
                this._bg.setSpriteFrame("cardKing_pic_PlayerBG.png");
                this._arrowSp.setSpriteFrame("information_whiteShadow_arrow_1.png");
                this._arrowSp.setLocalZOrder(2);
                this._bgNode.setLocalZOrder(1);
            }
        }
        // 沒玩家就關掉不顯示
        else {
            this.setVisible(false);
            this._hasPlayer = false;
        }

        if (this._type === CardKingMapPlayerNode.Type.OTHER)
            this._bg.setScale(0.9);

        this.changeArrowDirection(this._direction);
    },

    changeArrowDirection: function (newDirection) {
        if (this._direction !== newDirection) {
            this._bestRoundLabel.setPosition(0, 20);
            switch (newDirection) {
                case BaseMessageNode.Direct.DOWN:
                    this._arrowSp.setRotation(0);
                    this._arrowSp.setPosition(0, 1.5);
                    this._bgNode.setPosition(0, 29);

                    break;
                case BaseMessageNode.Direct.LEFT:
                    this._arrowSp.setRotation(90);
                    this._arrowSp.setPosition(1.5, 0);
                    this._bgNode.setPosition(29, 0);
                    break;
                case BaseMessageNode.Direct.UP:
                    this._arrowSp.setRotation(180);
                    this._arrowSp.setPosition(0, -1.5);
                    this._bgNode.setPosition(0, -29);

                    // 要是有最強, 局數壓在下面會壓到原本節點上的數字
                    this._bestRoundLabel.setPosition(0, -28);
                    break;
                case BaseMessageNode.Direct.RIGHT:
                    this._arrowSp.setRotation(270);
                    this._arrowSp.setPosition(-1.5, 0);
                    this._bgNode.setPosition(-29, 0);
                    break;
            }
            this._direction = newDirection;
        }
    },

    setButtonEnabled: function (enable) {
        this._btn.setEnabled(enable);
    },

    buttonClicked: function () {
        var pos = this.convertToWorldSpace(this._bgNode.getPosition());
        GS.dispatchCustomEvent("NotifyCardKingMapShowPlayerBubble", {
            level: this._level,
            round: this._round,
            direct: this._direction,
            pos: pos
        });
    },

    setOpen: function (open, doneCallback) {
        this.stopAllActions();
        if (open && !this._open) {
            this.setVisible(true);
            this.runAction(cc.sequence(cc.scaleTo(0.3, 1).easing(cc.easeBackIn()), cc.callFunc(() => {
                this._open = true;
                doneCallback && doneCallback();
            })));
        } else if (!open && this._open) {
            this.runAction(cc.sequence(cc.scaleTo(0.3, 0).easing(cc.easeBackIn()), cc.hide(), cc.callFunc(() => {
                this._open = false;
                doneCallback && doneCallback();
            })));
        }
    },

    checkNeedToShow: function (visible) {
        // 自己有玩家要出現才需要出現
        this.setVisible(this._hasPlayer && visible);
    },

    // 設定是不是第一, 只有自己的node會用到這個功能
    setIsTop: function (isTop) {
        if (this._type === CardKingMapPlayerNode.Type.SELF) {
            var bgName = "cardKing_pic_selfPlayer";
            if (isTop) {
                bgName = "cardKing_pic_bestPlayer";

                this._bestTitleSp.setPosition(0, 18);
                this._bestTitleSp.setVisible(true);
            } else {
                this._bestTitleSp.setPosition(0, -18);
                this._bestTitleSp.setVisible(false);
            }
            this._bg.setSpriteFrame(JSStringUtility.format("%sBG.png", bgName));
            this._arrowSp.setSpriteFrame(JSStringUtility.format("%sArrow.png", bgName));
        }
    },
});

// 這個node的類別
CardKingMapPlayerNode.Type = {
    SELF: 0,        // 自己
    OTHER: 1        // 其他人
};
