/**
 * Cangkulan的背景畫面
 */

var Cangkulan_BackgroundLayer = cc.Layer.extend({

    ctor: function () {
        this._super();

        // 背景
        var bgSprite = new cc.Sprite("background/Domino/game_cangkulan_background.jpg");
        bgSprite.setPosition(JSScreenMidPos);
        this.addChild(bgSprite, -10);

        // 地板、桌子
        var res = ["game/Domino/game_cangkulan_table_01.png", "game/Domino/game_cangkulan_table_01.png"];
        res.forEach(cur => {
            for (var i = 0; i < 2; i++) {
                var bgSp = new cc.Sprite(cur);
                bgSp.setAnchorPoint(1, 0.5);
                bgSp.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 54);
                bgSp.setScaleX(i === 0 ? 1 : -1);
                this.addChild(bgSp, -10);
            }
        });

        // 棄牌文字
        var foldWordSp = this._foldWordSp = new cc.Sprite("#cangkulan_word_06.png");
        foldWordSp.setPosition(cc.pAdd(cc.p(JSScreenMidPos.x, JSScreenMidPos.y + 40), Cangkulan_Offset.FOLD));
        foldWordSp.setVisible(false);
        this.addChild(foldWordSp);

        // Logo
        var logoSp = new cc.Sprite("#cangkulan_word_cangkulan.png");
        logoSp.setPosition(JSScreenMidPos.x, 151 + JSScreenBonusHalfHeight);
        this.addChild(logoSp);

        // Dealer的圖(黑色圓圖、上面寫著D，是莊家的意思)
        var dealerSprite = this._dealerSprite = new cc.Sprite("#game_pic_dealer.png");
        dealerSprite.setPosition(Cangkulan_GameUtility.getDealerPosition(0));
        dealerSprite.setVisible(false);
        this.addChild(dealerSprite);

        // 網速
        var antenna = new AntennaLayer(AntennaType.GAME_RIGHT);
        this.addChild(antenna, 2);

        // 底注文字跟背景
        var betBgPos = cc.p(JSScreenMidPos.x, 110 + JSScreenBonusHalfHeight);
        var betBgSprite = this._betBgSprite = new ccui.Scale9Sprite("cangkulan_pic_bet_bg.png");
        betBgSprite.setPosition(betBgPos);
        betBgSprite.setOpacity(100);
        betBgSprite.setVisible(false);
        this.addChild(betBgSprite);

        var betLabel = this._betLabel = new cc.LabelTTF("", JSFontName, 9);
        betLabel.setPosition(betBgPos);
        betLabel.setOpacity(100);
        this.addChild(betLabel, 1);

        // 場編
        var serialLabel = this._serialLabel = new cc.LabelTTF("", JSFontName, 7);
        serialLabel.enableStroke(JSColor.BLACK, 2);
        serialLabel.setAnchorPoint(1, 0.5);
        serialLabel.setPosition(JSVisibleSize.width - JSScreenSafeWidth - 24, JSVisibleSize.height - 12);
        this.addChild(serialLabel, 1);

        // 事件
        GS.addListener("NotifyGameTurnPositionFinish", this.notifyGameTurnPositionFinish.bind(this), this);
    },

    cleanData: function () {
        this._dealerServerSitNum = -1;
        this._dealerSprite.setVisible(false);

        this._foldWordSp.setVisible(false);

        // 場編清掉
        this._serialLabel.setString("");
    },

    /**
     * 抓取莊家位置
     */
    getDealerPosition: function () {
        return this._dealerServerSitNum;
    },

    /**
     * 設定莊家位置
     * @param {serverSitNum} server的位置
     */
    setDealerPosition: function (serverSitNum) {
        var dealerSprite = this._dealerSprite;
        if (serverSitNum === -1) {
            // 代表要關掉
            dealerSprite.setVisible(false);
        } else {
            var sitNum = DataModal.gameData.getDirectionByServerDirection(serverSitNum);
            var pos = Cangkulan_GameUtility.getDealerPosition(sitNum);
            dealerSprite.setVisible(true);
            dealerSprite.stopAllActions();
            dealerSprite.runAction(cc.moveTo(0.6, pos));
        }
    },

    /**
     * 顯示器牌的文字
     */
    showFoldWard: function (isVisible) {
        this._foldWordSp.setVisible(isVisible);
    },

    /**
     * 收到OLEH重置外觀
     */
    cmd_OLEH: function () {
        if (DataModal.gameData.gameSerialID)
            this._serialLabel.setString(LocalizedString.Game("場編資訊:") + " " + DataModal.gameData.gameSerialID);
        else
            this._serialLabel.setString("");

        this._dealerServerSitNum = -1;
        this._dealerSprite.setVisible(false);
    },


    /**
     * dealer x 莊家的位置
     * @param {value} socke收到的value
     */
    cmd_dealer: function (value) {
        this._dealerServerSitNum = value;
        this.setDealerPosition(value);
    },

    /**
     * 底注的文字
     */
    cmd_roomparam: function () {
        var gameData = DataModal.gameData;
        var betBgSprite = this._betBgSprite;
        var betLabel = this._betLabel;

        // 設定底注文字
        betLabel.setString("Buta:" + TexasUtility.getSimpleMoneyString(gameData.anteValue));

        // 背景大小調整
        betBgSprite.setPreferredSize(cc.size(betLabel.getContentSize().width + 32, 20));
        betBgSprite.setVisible(true);
    },

    /**
     * 換位置時自已轉到畫面上0的位置結束時觸發,修改Dealer的位置
     * @private
     */
    notifyGameTurnPositionFinish: function () {
        if (!this._dealerSprite.isVisible())
            return;

        this.setDealerPosition(this._dealerServerSitNum);
    },
});