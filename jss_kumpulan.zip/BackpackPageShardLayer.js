/**
 * v5.4.5 背包 - 背包的碎片頁面
 * 原點在左下角
 * 因為會有不同地方add所以這邊的position在外面加
 */
var BackpackPageShardLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        var mainNode = new cc.Node();
        this.addChild(mainNode);

        // 碎片獲得的提示(常駐在頁面上)
        var explainLabel = new cc.LabelTTF(LocalizedString.Profile("透過遊戲的各個功能獲得碎片\n自動合成後，會出現在對應系統或背包中"), JSFontBoldName, 10);
        explainLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        explainLabel.setPosition(132, 163);
        this.addChild(explainLabel);

        // 擁有的碎片
        var viewSize = this._viewSize = cc.size(270, 140);
        var mainLayer = this._mainLayer = new cc.Layer();
        var scrollView = this._scrollView = new cc.ScrollView(viewSize, mainLayer);
        scrollView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        mainNode.addChild(scrollView);

        // 加Loading
        var loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(129, 105);
        loadingSprite.start();
        mainNode.addChild(loadingSprite);

        DataProcess.sendString("item_piece_info");

        // 註冊
        GS.addListener("NotifyShardDone", this.notifyShardDone.bind(this), this);
    },

    /**
     * 刷新scrollView的內容
     * @private
     */
    _refreshView: function () {
        this._loadingSprite.stop();

        var shardData = DataModal.shardData;
        if (!shardData)
            return;

        // 有幾個碎片
        var list = shardData.shardList;
        var shardLen = list.length;

        // 沒有碎片
        var isNoShard = shardLen === 0;

        // 沒有碎片的要顯示文字提示
        this._showLabel(isNoShard);

        // 碎片scrollView是否打開
        this._scrollView.setVisible(!isNoShard);

        // 沒有碎片
        if (isNoShard)
            return;

        // 有碎片
        this._mainLayer.removeAllChildren();
        var totalHeight = shardLen * BackpackShardNode.HEIGHT;

        // 刷新scrollView的高度
        this._scrollView.setContentSize(cc.size(this._viewSize.width, totalHeight));
        this._scrollView.setContentOffset(cc.p(0, -(totalHeight - this._viewSize.height)));

        // 創建碎片
        var imgBaseHost = shardData.imgBaseHost;
        list.forEach((cur, index) => {
            var shardNode = new BackpackShardNode(imgBaseHost, cur);
            shardNode.setPosition(0, index * BackpackShardNode.HEIGHT);
            this._mainLayer.addChild(shardNode);
        });
    },

    /**
     * show 沒有碎片的提示
     * @param isShow
     * @private
     */
    _showLabel: function (isShow) {
        if (!isShow) {
            this._infoLabel && this._infoLabel.setVisible(false);
            return;
        }

        if (!this._infoLabel) {
            var infoLabel = this._infoLabel = new cc.LabelTTF(LocalizedString.Profile("目前沒有碎片哦"), JSFontBoldName, 12);
            infoLabel.setPosition(135, 90);
            this.addChild(infoLabel);
        }
        this._infoLabel.setVisible(true);
    },

    /**
     * 通知收到資料
     */
    notifyShardDone: function () {
        // 刷新頁面
        this._refreshView();
    }
});