/**
 * v5.6.1 分身模組 - 轉盤獎勵系統領獎畫面 移植中撲 16.7
 */

var CloneModelWheelAwardSystemHelpDialog = BaseDialogLayer.extend({
    ctor: function () {
        this._super();

        this.key = "CloneModelWheelAwardSystemHelpDialog";

        var animationLayer = this._animationLayer;

        // 背景
        var bgSprite = new ccui.Scale9Sprite("cloneModel_bg_windows.png");
        bgSprite.setPreferredSize(GS.isLuxyPoker ? cc.size(260, 150.5) : cc.size(300, 149));
        bgSprite.setPosition(JSScreenMidPos);
        animationLayer.addChild(bgSprite);

        // 小幫手幫您領獎
        var label = new cc.LabelTTF(LocalizedString.Purchase("小幫手") + (GS.isLuxyPoker ? "\n" : " ") + LocalizedString.Purchase("幫您領獎"), JSFontBoldName, 12);
        label.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 10);
        animationLayer.addChild(label);

        // ok按鈕
        var buttonSize = GS.isLuxyPoker ? cc.size(77.5, 39) : cc.size(92, 39);
        var okButton = this._okButton = new Texas_Button(Texas_Button.Style.YELLOW, buttonSize, "OK");
        okButton.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 40);
        okButton.addTouchUpInsideAction(this._closeDialogAnimation, this);
        animationLayer.addChild(okButton);
    },

    // 避免從主畫面的頂光上閃過去所以動畫跑完才加
    _dialogOpenAnimationDone: function () {
        this._super();

        // 頂光
        var patternBgSprite = new cc.Sprite("#cloneModel_bg_light_01.png");
        patternBgSprite.setAnchorPoint(0.5, 1);
        patternBgSprite.setScale(5);
        patternBgSprite.setPosition(JSScreenMidPos.x, JSVisibleSize.height + 50);
        this._animationLayer.addChild(patternBgSprite, 10);
    },
});