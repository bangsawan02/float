/**
 * 5.4.0 副系統 - 激戰任務排行榜基本cell
 * created by Jim.Chen
 */

var FierceBattleRankCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        var midPosY = FierceBattleRankCell.HEIGHT / 2;

        // 黑底
        var colorLayer = new cc.LayerColor(cc.color(0, 0, 0, 128), FierceBattleRankCell.WIDTH - 6, FierceBattleRankCell.HEIGHT);
        colorLayer.setPosition(2, 0);
        this.addChild(colorLayer);

        // 自己才有的紫色底
        var selfBgSp = this._selfBgSp = new ccui.Scale9Sprite("fierceBattle_pic_line_pink.png");
        selfBgSp.setPreferredSize(cc.size(FierceBattleRankCell.WIDTH - 10, FierceBattleRankCell.HEIGHT - 6));
        selfBgSp.setOpacity(128);
        selfBgSp.setPosition(FierceBattleRankCell.WIDTH / 2, midPosY);
        this.addChild(selfBgSp);

        // 名次 從第四名開始
        var rankLabel = this._rankLabel = new cc.LabelTTF("", JSFontName, 12);
        rankLabel.setPosition(19, midPosY);
        this.addChild(rankLabel);

        // 獎牌圖
        var medalSp = new cc.Sprite("#fierceBattle_pic_badge.png");
        medalSp.setPosition(191, midPosY);
        this.addChild(medalSp);

        // 勳章數
        var medalLabel = this._medalLabel = new cc.LabelTTF("0", JSFontName, 11);
        medalLabel.setAnchorPoint(0, 0.5);
        medalLabel.setPosition(202, midPosY);
        this.addChild(medalLabel);

        // 大頭照 裁切的node
        var stencilSprite = new cc.Sprite("#lobby_photo_clip.png");
        var clipNode = new cc.ClippingNode(stencilSprite);
        clipNode.setCascadeColorEnabled(true);
        clipNode.setAlphaThreshold(0.5);
        this.addChild(clipNode);

        // 大頭照
        var photoSprite = this._photoSprite = new PhotoSprite("", 60, 60);
        photoSprite.setDefaultSprite(JSCodeUtility.getRandomInt(0, 1) ? "photo_male.png" : "photo_female.png");
        clipNode.setScale(30 / 60);
        clipNode.setPosition(54, midPosY);
        clipNode.addChild(photoSprite);

        // 暱稱
        var nicknameLabel = this._nicknameLabel = new cc.LabelTTF("", JSFontName, 11);
        nicknameLabel.setAnchorPoint(0, 0.5);
        nicknameLabel.setPosition(73, midPosY);
        this.addChild(nicknameLabel);

        // 寶箱
        var btnSize = cc.size(37, 31);

        // 用來當底的Node
        var node = new ccui.Scale9Sprite();
        node.setContentSize(btnSize);

        // 主要放東西的node
        var mainNode = this._mainNode = new cc.Node();
        mainNode.setCascadeColorEnabled(true);
        mainNode.setCascadeOpacityEnabled(true);
        mainNode.setPosition(btnSize.width / 2, btnSize.height / 2);
        node.addChild(mainNode);

        var chestSp = this._chestSp = new cc.Sprite("#lobby_pic_chest_04.png");
        mainNode.addChild(chestSp);

        // 按鈕
        var chestBtn = this._chestBtn = new cc.ControlButton();
        chestBtn.setPreferredSize(btnSize);         // 一定要加這行 Native才會是對的
        chestBtn.setBackgroundSpriteForState(node, cc.CONTROL_STATE_NORMAL);
        chestBtn.addTargetWithActionForControlEvents(this, (sender, controlEvent) => {
                var isTouched = (controlEvent === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || controlEvent === cc.CONTROL_EVENT_TOUCH_DOWN);
                this._mainNode.setColor(isTouched ? JSColor.GRAY : JSColor.WHITE);

                this._chestBtnClicked(sender, controlEvent);
            },
            cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
            cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
            cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
        chestBtn.setAdjustBackgroundImage(false);
        chestBtn.setZoomOnTouchDown(false);
        chestBtn.setPosition(276, midPosY);
        this.addChild(chestBtn);

    },

    /**
     * 更新畫面
     */
    refreshCellWithParam: function (index, param) {
        this.setVisible(index !== 0);

        if (index > 0) {
            var param = param;
            var rank = param.rank;

            // 判斷是不是自己
            var isSelf = param.nickname === DataModal.profileData.nickname;

            // 自己底色
            this._selfBgSp.setVisible(isSelf);

            // 名次
            this._rankLabel.setString(rank);

            // 暱稱
            this._nicknameLabel.setString(JSStringUtility.cutStringReplaceByEllipsis(param.nickname, 11, 110));

            // 大頭貼
            this._photoSprite.setPhotoUrlString(param.photoUrl);

            // 勳章數量
            this._medalLabel.setString(CommonUtility.getSimpleNumber(param.score, 1));

            // 寶箱的資料
            this._chestBtn.setVisible(param.rewards.length > 0);
            this._chestBtn.rewards = param.rewards;
            if (param.rewards.length > 0) {
                var chestImg = "lobby_pic_chest_04.png";
                if (3 < rank && rank <= 25) {
                    chestImg = "lobby_pic_chest_04.png";
                } else if (rank <= 50) {
                    chestImg = "lobby_pic_chest_05.png";
                }
                this._chestSp.setSpriteFrame(chestImg);
            }
        }
    },

    /**
     * 點擊寶箱
     */
    _chestBtnClicked: function (sender, controlEvent) {
        // show獎勵泡泡框
        var obj = {
            controlEvent: controlEvent,
            pos: this.convertToWorldSpace(sender.getPosition()),
            rewards: sender.rewards
        };
        GS.dispatchCustomEvent("NotifyFierceBattleRankShowMessage", obj);
    },
});

// Cell 寬/高
FierceBattleRankCell.HEIGHT = 38;
FierceBattleRankCell.WIDTH = 305;