/**
 * v5.5.1 夾娃娃機儲值觸發 - 分頁面
 * created by Jim.Chen
 */

var ClawMachineChallengePageLayer = PurchaseTriggerIntegrationPageLayer.extend({
    ctor: function (dialog) {
        this._super(dialog);

        this.key = "ClawMachineChallengePageLayer";

        this.type = PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE;

        this._progressIncrementValue = 0;  // 每一趴進度要增加的累積值(跑進度動畫用)
        this._nowProgressValue = 0;        // 進度條累積值
        this._maxProgressValue = 0;        // 進度條最大值

        // 要讀的素材
        this.loadFileArray = [
            "purchaseTriggerIntegration/clawMachineChallenge.plist", "purchaseTriggerIntegration/clawMachineChallenge.png",
            "common/number/num_26.plist", "common/number/num_26.png"
        ];
    },

    /**
     * @override
     */
    loadFileDone: function () {
        this._super();

        var purchaseStr = LocalizedString.Purchase;

        // 需要反灰的Node
        var turnGrayAreaNode = this._turnGrayAreaNode = new cc.Node();
        turnGrayAreaNode.setCascadeColorEnabled(true);
        this.addChild(turnGrayAreaNode);

        // 機台後面窗
        [cc.p(339.25, 158), cc.p(351.1, 158)].forEach((pos, idx) => {
            var backWindowSp = new cc.Sprite("#clawMachineChallenge_bg_window_02.png");
            backWindowSp.setFlippedX(idx === 0);
            backWindowSp.setAnchorPoint(idx, 0.5);
            backWindowSp.setPosition(pos.x + JSScreenBonusHalfWidth, pos.y + JSScreenBonusHalfHeight);
            turnGrayAreaNode.addChild(backWindowSp);
        });

        // 獎勵堆圖(要切換KL/RP獎勵)
        var rewardStackSp = new cc.Sprite(ProfileData.getKoinLuxyRes("#clawMachineChallenge_bg_window_03"));
        rewardStackSp.setPosition(348 + JSScreenBonusHalfWidth, 158 + JSScreenBonusHalfHeight);
        turnGrayAreaNode.addChild(rewardStackSp);

        // 夾子
        var clawSp = new cc.Sprite("#clawMachineChallenge_pic_claws_01.png");
        clawSp.setPosition(345 + JSScreenBonusHalfWidth, 184 + JSScreenBonusHalfHeight);
        turnGrayAreaNode.addChild(clawSp);

        // 機台前窗
        [cc.p(343.9, 136), cc.p(344.1, 136)].forEach((pos, idx) => {
            var frontWindowSp = new cc.Sprite("#clawMachineChallenge_bg_window_01.png");
            frontWindowSp.setFlippedX(idx === 0);
            frontWindowSp.setAnchorPoint(idx, 0.5);
            frontWindowSp.setPosition(pos.x + JSScreenBonusHalfWidth, pos.y + JSScreenBonusHalfHeight);
            turnGrayAreaNode.addChild(frontWindowSp);
        });

        // 左右兩排機台燈泡
        var aniTime = 0.6;
        var rowNum = 5;
        [
            [cc.p(207, 213), cc.p(481, 213)],
            [cc.p(209, 189), cc.p(479, 189)],
            [cc.p(211, 164), cc.p(477, 164)],
            [cc.p(213, 141), cc.p(475, 141)],
            [cc.p(215, 114), cc.p(473, 114)]
        ].forEach((posArr) => {
            posArr.forEach((curPos) => {
                var lightSp = new cc.Sprite("#clawMachineChallenge_pic_light02.png");
                lightSp.setVisible(false);
                lightSp.setPosition(curPos.x + JSScreenBonusHalfWidth, curPos.y + JSScreenBonusHalfHeight);
                turnGrayAreaNode.addChild(lightSp);

                lightSp.runAction(cc.repeatForever(
                    cc.sequence(
                        cc.delayTime(3 - aniTime * rowNum),
                        cc.show(),
                        cc.delayTime(aniTime),
                        cc.hide(),
                        cc.delayTime(aniTime * (rowNum - 1))
                    )
                ));
            });
            rowNum--;
        });

        // 標題
        var titleSp = new cc.Sprite("#clawMachineChallenge_word_logo.png");
        titleSp.setPosition(347 + JSScreenBonusHalfWidth, 251 + JSScreenBonusHalfHeight);
        turnGrayAreaNode.addChild(titleSp);

        // 副標背景
        var subTitleBgSp = new ccui.Scale9Sprite("clawMachineChallenge_pic_frame_04.png", cc.rect(8, 8, 12, 8));
        subTitleBgSp.setPreferredSize(cc.size(230, 23));
        subTitleBgSp.setPosition(330 + JSScreenBonusHalfWidth, 68 + JSScreenBonusHalfHeight);
        turnGrayAreaNode.addChild(subTitleBgSp);

        // 副標文字圖
        var subTitleSp = new cc.Sprite("#clawMachineChallenge_word_01.png");
        subTitleSp.setPosition(330 + JSScreenBonusHalfWidth, 68 + JSScreenBonusHalfHeight);
        turnGrayAreaNode.addChild(subTitleSp);

        // 把手
        var handleSp = new cc.Sprite("#clawMachineChallenge_pic_rocker_01.png");
        handleSp.setPosition(464 + JSScreenBonusHalfWidth, 85 + JSScreenBonusHalfHeight);
        turnGrayAreaNode.addChild(handleSp);

        // 倒數時間+背景的Node
        var countdownAreaNode = this._countdownAreaNode = new cc.Node();
        countdownAreaNode.setCascadeColorEnabled(true);
        countdownAreaNode.setPosition(344 + JSScreenBonusHalfWidth, 230 + JSScreenBonusHalfHeight);
        turnGrayAreaNode.addChild(countdownAreaNode);

        // 黑底
        var blackBgSp = new ccui.Scale9Sprite("lobby_pic_black.png");
        blackBgSp.setPreferredSize(cc.size(88, 16));
        countdownAreaNode.addChild(blackBgSp);

        // 水平排版:時鐘Icon + 倒數時間
        var timeLayoutNode = this._countdownLayoutNode = new GSAutoLayoutNode();
        timeLayoutNode.setSpace(2);

        // 時鐘Icon
        var clockSp = new cc.Sprite("#lobby_pic_clock_02.png");
        clockSp.setScale(0.5);
        timeLayoutNode.addChild(clockSp);

        // 活動倒數時間
        var countdownLabel = this._countdownLabel = new GSTimeLabel("", JSFontBoldName, 9);
        countdownLabel.setMultiFormat("%dd Hari", "%hh:%mm:%ss", "%hh:%mm:%ss");
        timeLayoutNode.addChild(countdownLabel);
        countdownAreaNode.addChild(timeLayoutNode);

        // 底座
        var wheelBaseSp = new cc.Sprite("#clawMachineChallenge_pic_base.png");
        wheelBaseSp.setPosition(151.5 + JSScreenBonusHalfWidth, 43.75 + JSScreenBonusHalfHeight);
        this.addChild(wheelBaseSp);

        // 進度條背景
        [0, 1].forEach(cur => {
            var barBgSp = new cc.Sprite("#clawMachineChallenge_pic_bar_05.png");
            barBgSp.setPosition(152 + JSScreenBonusHalfWidth, 143 + JSScreenBonusHalfHeight);
            barBgSp.setAnchorPoint(cur, 0.5);
            barBgSp.setFlippedX(cur === 0);
            this.addChild(barBgSp);
        });

        // 進度條
        var progressTimer = this._progressTimer = new GSProgressTimer("clawMachineChallenge_pic_bar_01.png", "clawMachineChallenge_pic_bar_02.png", cc.size(128, 15), cc.size(128, 11.5), false);
        progressTimer.setPosition(152 + JSScreenBonusHalfWidth, 121 + JSScreenBonusHalfHeight);
        progressTimer.setDirection(GSProgressTimerDirection.VERTICAL);
        progressTimer.setAnimationTime(0.5);
        progressTimer.setPercentage(100);
        progressTimer.setUpdateProgressCallback((progress) => {
            // 進度條更新時更新累積值(有儲值資料才會進去)
            if (this._progressIncrementValue > 0) {
                // 目前跑了幾%
                var gapPercent = progress * 100 - this._nowPercent;

                // 累積數值跟隨進度增加，累積數值可超過最大值。
                var nowNumber = TexasUtility.getSimpleMoneyString(Math.floor(this._progressIncrementValue * gapPercent + this._nowProgressValue), 2);
                this._progressLabel1.setString(JSStringUtility.format("IDR %s", nowNumber));
                this._progressLabel2.setString(JSStringUtility.format("/%s", TexasUtility.getSimpleMoneyString(this._maxProgressValue, 2)));
            }
        });
        this.addChild(progressTimer);

        // 標題背板
        var wheelBoardSp = new cc.Sprite("#clawMachineChallenge_pic_board.png");
        wheelBoardSp.setPosition(151.5 + JSScreenBonusHalfWidth, 236 + JSScreenBonusHalfHeight);
        this.addChild(wheelBoardSp);

        // 標題美術字：GRAND PRIZE
        var wheelTitleSp = new cc.Sprite("#clawMachineChallenge_word_title_01.png");
        wheelTitleSp.setPosition(151.5 + JSScreenBonusHalfWidth, 245.5 + JSScreenBonusHalfHeight);
        this.addChild(wheelTitleSp);

        // 板子上的燈泡
        [cc.p(138, 255), cc.p(151, 257.5), cc.p(164, 255), cc.p(116, 234), cc.p(117, 224), cc.p(125, 215), cc.p(187, 232), cc.p(186, 222), cc.p(176, 215.5)].forEach((cur, index) => {
            var isOffFirst = (index % 3) === 1;
            var bulbPos = cc.pAdd(cur, cc.p(JSScreenBonusHalfWidth, JSScreenBonusHalfHeight));

            // 沒亮的燈泡
            var bulbSp = new cc.Sprite("#clawMachineChallenge_pic_light01.png");
            bulbSp.setPosition(bulbPos);
            bulbSp.setScale(0.5);
            this.addChild(bulbSp);

            // 會亮的燈泡
            var bulbSp2 = new cc.Sprite("#clawMachineChallenge_pic_light02.png");
            bulbSp2.setPosition(bulbPos);
            bulbSp2.setScale(0.5);
            isOffFirst && bulbSp2.setOpacity(0);
            this.addChild(bulbSp2);

            if (isOffFirst) {
                // 先變亮再變暗
                bulbSp2.runAction(cc.sequence(
                    cc.fadeIn(0.5),
                    cc.delayTime(0.7),
                    cc.fadeOut(0.5),
                    cc.delayTime(0.7)
                ).repeatForever());
            } else {
                // 先變暗再變亮
                bulbSp2.runAction(cc.sequence(
                    cc.fadeOut(0.5),
                    cc.delayTime(0.7),
                    cc.fadeIn(0.5),
                    cc.delayTime(0.7)
                ).repeatForever());
            }
        });

        // 大獎數字
        var wheelJackpotLabel = this._wheelJackpotLabel = new cc.LabelTTF("", JSFontName, 11);
        wheelJackpotLabel.setPosition(151.5 + JSScreenBonusHalfWidth, 231.5 + JSScreenBonusHalfHeight);
        wheelJackpotLabel.setFontFillColor(cc.color(255, 235, 120));
        wheelJackpotLabel.enableStroke(cc.color(95, 5, 100), 2.5);
        this.addChild(wheelJackpotLabel);

        // 轉輪
        var wheel = this._wheel = new ClawMachineChallengeWheelNode(this);
        this.addChild(wheel, 2);

        // 累積進度標籤1
        var progressLabel1 = this._progressLabel1 = new cc.LabelTTF("IDR XXX.X mlr", JSFontName, 9);
        progressLabel1.setPosition(152 + JSScreenBonusHalfWidth, 39 + JSScreenBonusHalfHeight);
        this.addChild(progressLabel1);

        // 累積進度標籤2
        var progressLabel2 = this._progressLabel2 = new cc.LabelTTF("/NNN.N mlr", JSFontName, 9);
        progressLabel2.setPosition(152 + JSScreenBonusHalfWidth, 29.5 + JSScreenBonusHalfHeight);
        this.addChild(progressLabel2);

        // 說明按鈕
        var infoBtn = this._infoBtn = new Texas_ExplainButton(this._explainBtnStyle);
        infoBtn.setPosition(216 + JSScreenBonusHalfWidth, 240 + JSScreenBonusHalfHeight);
        infoBtn.addTouchUpInsideAction(this._infoBtnClicked, this);
        turnGrayAreaNode.addChild(infoBtn);

        // 馬上夾按鈕
        var goPurchaseBtn = this._goPurchaseBtn = ButtonUtility.createSimpleButton("clawMachineChallenge_btn_green_01.png", cc.size(106, 38), JSStringUtility.format(purchaseStr("馬上夾\n(%d)"), 999), JSColor.WHITE, 12);
        goPurchaseBtn.label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        goPurchaseBtn.rewardCount = 0;
        goPurchaseBtn.setPosition(342 + JSScreenBonusHalfWidth, 27 + JSScreenBonusHalfHeight);
        goPurchaseBtn.addTouchUpInsideAction(this._goPurchaseBtnClicked, this);
        turnGrayAreaNode.addChild(goPurchaseBtn);

        // 刷新畫面
        this._refreshView();

        // 監聽
        GS.addListener("NotifyClawMachineChallengeInfoDone", this.notifyClawMachineChallengeInfoDone.bind(this), this);
        GS.addListener("NotifyClawMachineChallengeGetDone", this.notifyClawMachineChallengeGetDone.bind(this), this);
        GS.addListener("NotifyClawMachineChallengeRewardDone", this.notifyClawMachineChallengeRewardDone.bind(this), this);
    },

    onEnter: function () {
        this._super();

        // 埋點：進入夾娃娃機頁籤人數
        DataProcess.sendString("track_recharge_integrate 3");

        // 更新小紅點
        DataModal.purchaseTriggerIntegrationData.setBadgeRecordByType(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE);

        // 5.6.0埋點 進入頁籤人數(3053)：統計進到夾娃娃頁
        DataModal.purchaseTriggerIntegrationData.sendClawMachineChallengeUserAnalyticsTrack(3053);
    },

    // Override
    setVisible: function (value) {
        this._super(value);

        // 沒有顯示不做事
        if (!value)
            return;

        // 刷新畫面，判斷是否要跑進度動畫
        if (this.isVisibleRecursive())
            this._refreshView();
    },

    // 更新畫面
    _refreshView: function () {
        this.visibleSemaphore.acquire().then((key) => {
            if (this.__isDestroyed)
                return;

            // 釋放
            this.visibleSemaphore.release(key);

            // 動畫中不做事，畫面還沒準備好（左側切換至夾豪康會呼叫 setVisible，而 setVisible 會呼叫 _refreshView）
            if (this._isAnimating || !this._isLoadFileDone)
                return;

            // 拿掉loading
            this.setLoadingSprite(false, false);

            // 拿資料
            var clawMachineData = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE);
            if (!clawMachineData || !clawMachineData.isOpen) {
                return;
            }

            this._progressIncrementValue = 0;                                   // 進度條更新1%時，累積更新的值(跑動畫用)
            var nowPercent = this._nowPercent = clawMachineData.nowPercent;     // 目前進度條%數
            var nowProgressValue = this._nowProgressValue = clawMachineData.nowProgressValue;       // 進度累積值
            var maxProgressValue = this._maxProgressValue = clawMachineData.maxProgressValue;       // 進度最大值

            // 倒數時間
            this._countdownLabel.countdownSeconds(JSCodeUtility.getRemainTimeByParam(clawMachineData), () => {
                this._countdownAreaNode.setVisible(false);

                // 清掉儲值中心副系統顯示
                DataModal.purchaseData.cleanSubSystemDataByName(PurchaseData.SubSystemName.CLAW_MACHINE);

                // 正在轉不做事
                if (!this._wheel.isSpining) {
                    // 活動結束在儲值整合Icon會重拿資料。這邊只要卡Loading
                    this.setLoadingSprite(true, true);
                }
            }, (seconds) => {
                // 時間格式改變，刷新排版
                if (seconds === 86399)
                    this._countdownLayoutNode.refresh();
            });
            this._countdownLayoutNode.refresh();

            // 更新馬上夾按鈕
            this._goPurchaseBtn.setEnabled(true);
            this._goPurchaseBtn.rewardCount = clawMachineData.getRewardCount;
            this._goPurchaseBtn.label.setString(JSStringUtility.format(LocalizedString.Purchase("馬上夾\n(%d)"), clawMachineData.getRewardCount));

            // 馬上夾按鈕縮放動畫
            this._playGoPurchaseBtnAnim(true);

            // 更新進度條顯示
            this._progressTimer.setPercentage(nowPercent, false);
            // 更新進度條累積文字
            this._progressLabel1.setString(JSStringUtility.format("IDR %s", TexasUtility.getSimpleMoneyString(nowProgressValue, 2)));
            this._progressLabel2.setString(JSStringUtility.format("/%s", TexasUtility.getSimpleMoneyString(maxProgressValue, 2)));

            // 更新大獎文字
            this._wheelJackpotLabel.setString(TexasUtility.getSimpleMoneyString(clawMachineData.wheelData.maxReward || "", 1));

            // 刷新轉輪
            this._wheel.refreshView();

            // 有次數可以轉的話開啟轉盤介面
            if (clawMachineData.getWheelRewardCount > 0)
                this._wheel.runWheelMoveAnimate();

            // 有儲值累積資料，算新進度 -> 跑進度條動畫
            var rechargeResultParam = clawMachineData.rechargeResultParam;
            if (rechargeResultParam) {

                // 記下數值
                var newProgressValue = rechargeResultParam.newProgressValue;         // 儲值後累積進度值

                // 計算累積值差額
                var progressGapValue = newProgressValue - nowProgressValue;
                if (progressGapValue > 0) {
                    // 算新的%數
                    var newPercent = newProgressValue / maxProgressValue * 100;
                    if (newPercent > 100)
                        newPercent = 100;

                    // %數增加
                    if (newPercent > clawMachineData.nowPercent) {
                        // 算%數差值
                        var gapPercent = newPercent - clawMachineData.nowPercent;
                        // 算增加1%要加多少數值(進度條更新時用)
                        this._progressIncrementValue = progressGapValue / gapPercent;

                        var aniParam = {
                            // 目標%數
                            newPercent: newPercent
                        };

                        // 跑動畫
                        this._playProgressIncreaseAnim(aniParam);
                    } else {
                        // 進度沒增加，表示原先就100％，不跑動畫。直接更新數值
                        this._progressLabel1.setString(JSStringUtility.format("IDR %s", TexasUtility.getSimpleMoneyString(nowProgressValue, 2)));
                        this._progressLabel2.setString(JSStringUtility.format("/%s", TexasUtility.getSimpleMoneyString(maxProgressValue, 2)));
                    }

                    // 更新儲值進度資料
                    clawMachineData.nowPercent = newPercent;                     // 新百分比
                    clawMachineData.nowProgressValue = newProgressValue;         // 新累積值
                }

                // 清空儲值累積資料
                clawMachineData.rechargeResultParam = undefined;
            }
        });
    },

    /**
     * 建立說明頁 dialog
     */
    _createInfoDialog: function () {
        return new WebViewDialog(TexasUtility.getSimpleInfoURLByKey("claw_machine_challenge"));
    },

    /**
     * 馬上抓按鈕縮放動畫
     * @param isStart 開始或停止動畫
     */
    _playGoPurchaseBtnAnim: function (isStart) {
        var action, aniTime = 0.75;
        if (isStart) {
            // 持續縮放動畫
            action = cc.repeatForever(cc.sequence(
                cc.scaleTo(aniTime, 1.1),
                cc.scaleTo(aniTime, 1)
            ));
        } else {
            // 回到一般大小
            action = cc.scaleTo(aniTime, 1).easing(cc.easeBackOut());
        }

        this._goPurchaseBtn.stopAllActions();
        this._goPurchaseBtn.runAction(action);
    },

    /**
     * 跑進度條增加動畫
     * @param aniParam 跑動畫需要的參數
     */
    _playProgressIncreaseAnim: function (aniParam) {
        // 可視才可播動畫
        this.visibleSemaphore.acquire().then((key) => {
            if (this.__isDestroyed)
                return;

            // 釋放
            this.visibleSemaphore.release(key);

            // 跑動畫中
            this._isAnimating = true;

            // 擋整合視窗返回&切換頁籤
            this.setAllBtnEnabled(false);

            this._playChangeMachineColorAsync(false)                  // 機台變暗
                .then(() => this._playRiseProgressAsync(aniParam))    // 跑進度條動畫
                .then(() => this._playChangeMachineColorAsync(true))  // 機台亮起
                .then(() => {
                    // 可視才可處理
                    this.visibleSemaphore.acquire().then((key) => {
                        if (this.__isDestroyed)
                            return;

                        // 釋放
                        this.visibleSemaphore.release(key);

                        // 動畫結束
                        this._isAnimating = false;

                        // 打開整合視窗返回&切換頁籤
                        this.setAllBtnEnabled(true);

                        // 卡loading
                        this.setLoadingSprite(true, true);

                        // 重要資料
                        DataModal.purchaseTriggerIntegrationData.startGetInfoByType(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE);
                    });
                });
        });
    },

    /**
     * 調整娃娃機亮起/變暗
     */
    _playChangeMachineColorAsync: function (isLight) {
        // 可視才可播動畫
        return this.visibleSemaphore.acquire()
            .then((key) => new Promise((resolve, reject) => {
                if (this.__isDestroyed)
                    return reject();

                // 釋放
                this.visibleSemaphore.release(key);

                if (isLight) {
                    // 機台亮起
                    this._turnGrayAreaNode.runAction(cc.tintTo(0.5, 255, 255, 255));

                    // 馬上抓按鈕，開始縮放動畫
                    this._playGoPurchaseBtnAnim(true);

                } else {
                    // 機台變暗
                    this._turnGrayAreaNode.runAction(cc.tintTo(0.5, 128, 128, 128));

                    // 馬上抓按鈕回到一般大小
                    this._playGoPurchaseBtnAnim(false);
                }

                this.runAction(cc.sequence(
                    cc.delayTime(0.5),
                    cc.callFunc(resolve)
                ));
            }));
    },

    /**
     * 跑進度條變動動畫
     */
    _playRiseProgressAsync: function (aniParam) {
        // 可視才可播動畫
        return this.visibleSemaphore.acquire()
            .then((key) => new Promise((resolve, reject) => {
                if (this.__isDestroyed)
                    return reject();

                // 釋放
                this.visibleSemaphore.release(key);

                var newPercent = aniParam.newPercent;

                // 進度條動畫完成要做的事
                this._progressTimer.setFinishProgressCallback(() => {
                    if (newPercent >= 100) {
                        // 進度滿了

                        // 轉盤背景光亮起
                        this._wheel.playProcessFullAni();

                        // 等時間resolve
                        this.runAction(cc.sequence(
                            cc.delayTime(2.5),
                            cc.callFunc(resolve)
                        ));

                    } else {
                        resolve();
                    }
                });

                this._progressTimer.setPercentage(newPercent, true);
            }));
    },

    /**
     * 說明按鈕點擊
     */
    _infoBtnClicked: function () {
        if (this._isAnimating)
            return;

        this.showInfoDialog();
    },

    /**
     * 馬上夾按鈕點擊
     * 有可夾次數 -> 領獎
     * 不能夾    -> 引導儲值中心
     */
    _goPurchaseBtnClicked: function (sender) {
        // 埋點 1:點擊馬上夾
        DataProcess.sendString("track_claw_machine_challenge 1");

        // 5.6.0埋點 點擊馬上夾
        DataModal.purchaseTriggerIntegrationData.sendClawMachineChallengeUserAnalyticsTrack(3054);

        // 動畫中不做事
        if (this._isAnimating)
            return;

        sender.setEnabled(false);

        if (sender.rewardCount > 0) {
            // 可領獎，加loading
            this.setLoadingSprite(true, true);

            // 鎖掉所有按鈕
            this.setAllBtnEnabled(false);

            // 送領獎cmd
            DataProcess.sendString("claw_machine_challenge_get");
        } else {
            // 埋點
            DataProcess.sendString("track_claw_machine_challenge 9");

            // 不可領獎，引導儲值中心
            PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);

            // 關閉Dialog
            this.closeDialogAnimation();
        }
    },

    /**
     * 通知
     */

    /**
     * 收到活動資料
     */
    notifyClawMachineChallengeInfoDone: function () {
        // 刷新頁面
        this._refreshView();
    },

    /**
     * 領取夾娃娃獎勵
     */
    notifyClawMachineChallengeGetDone: function (event) {
        // 拿掉loading
        this.setLoadingSprite(false, false);

        // 解鎖所有按鈕
        this.setAllBtnEnabled(true);

        // 跳獎勵Dialog
        if (event && event.getUserData()) {
            var param = event.getUserData();
            if (param.isSuccess) {
                // 5.6.0埋點 實際夾娃娃
                TexasUtility.sendUserAnalyticsTrack(3055);

                // 跳獎勵Dialog
                let dialog = new ClawMachineChallengeSystemMessageDialog(param.rewardTxtArray);
                dialog.setCloseCallback(() => {
                    // 活動頁面卡Loading，更新活動資料
                    this.setLoadingSprite(true, true);

                    // 重要資料
                    DataProcess.sendString("claw_machine_challenge_info");
                });
                this.showDialog(dialog);
            } else {
                // 失敗
                this.showDialog(new Dialog({
                    content: LocalizedString.Common("伺服器發生錯誤 請稍候再試。"),
                    buttons: ["OK"]
                }));
            }
        }
    },

    /**
     * 領取累積進度獎勵
     */
    notifyClawMachineChallengeRewardDone: function (event) {
        // 沒有顯示不做事
        if (!this.isVisibleRecursive())
            return;

        // 拿掉loading
        this.setLoadingSprite(false, false);

        if (event && event.getUserData()) {
            var param = event.getUserData();
            if (param.isSuccess) {
                // 跳獎勵Dialog
                this.showDialog(new ClawMachineChallengeSystemMessageDialog(param.rewardTxtArray));
            } else {
                // 失敗
                this.showDialog(new Dialog({
                    content: LocalizedString.Common("伺服器發生錯誤 請稍候再試。"),
                    buttons: ["OK"]
                }));
            }
        }
    },

    /**
     * ========== Debug ==========
     */
    createDebugTestObject: function () {
        return new TestMenuDebugObject("夾娃娃機大挑戰", {
            "info": () => DataProcess.sendCustomStringToSelf('claw_machine_challenge_info {"wheel_data":{"isGet":[],"max_reward":"2800000000","list":["2.8mlr","2.5mlr","2.5mlr","2.3mlr","2.3mlr","2mlr","2mlr","1.5mlr"],"level":"1"},"value":"0","refresh_bill":"1","error":"0","red_point_refresh":"1708556400","left_time":"1220456","group":"1","img_url":"https://d.mwsrv.com/texas9/store/iapp/download/multi/HD/","first_day":"0","count":"0","pop":"0","goal":"90000"}'),
            "recharge": () => {
                DataProcess.sendCustomStringToSelf('claw_machine_challenge_recharge {"goal":"90000","count":"1","value":"75000"}');

                // 重近dialog才會演動畫
                DialogManager.cleanAllDialog();
                DialogManager.addLobbyDialog(new PurchaseTriggerIntegrationDialog(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE));
            },
            "info2": () => DataProcess.sendCustomStringToSelf('claw_machine_challenge_info {"first_day":"0","count":"1","value":"75000","img_url":"https://d.mwsrv.com/texas9/store/iapp/download/multi/HD/","wheel_data":{"isGet":[],"max_reward":"2800000000","list":["2.8mlr","2.5mlr","2.5mlr","2.3mlr","2.3mlr","2mlr","2mlr","1.5mlr"],"level":"1"},"group":"1","goal":"90000","pop":"0","left_time":"1220381","error":"0","red_point_refresh":"1708556400"}'),
            "get": () => DataProcess.sendCustomStringToSelf('claw_machine_challenge_get {"error":"0","reward_txt":["350jt chips"]}'),
            "info3": () => DataProcess.sendCustomStringToSelf('claw_machine_challenge_info {"count":"1","first_day":"0","value":"150000","img_url":"https://d.mwsrv.com/texas9/store/iapp/download/multi/HD/","group":"1","wheel_data":{"level":"1","list":["2.8mlr","2.5mlr","2.5mlr","2.3mlr","2.3mlr","2mlr","2mlr","1.5mlr"],"max_reward":"2800000000","isGet":[]},"goal":"90000","pop":"0","left_time":"1220256","red_point_refresh":"1708556400","error":"0"}'),
            "reward": () => DataProcess.sendCustomStringToSelf('claw_machine_challenge_wheel_reward {"error":"0","wheel_data":{"isGet":["7"],"max_reward":"2800000000","list":["2.8mlr","2.5mlr","2.5mlr","2.3mlr","2.3mlr","2mlr","2mlr","1.5mlr"],"level":"1"},"reward_txt":["1500000000"],"value":"60000"}')
        });
    },
});