/**
 *  鑽石賽 兌換畫面
 */

var DiamondExchangeLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 背景
        var bgLayer = new cc.LayerColor(cc.color(30, 0, 0, 255), JSVisibleSize.width + 2, JSVisibleSize.height + 2);
        bgLayer.setPosition(-1, -1);
        this.addChild(bgLayer);

        // 上方的底
        var posY = JSVisibleSize.height - TITLE_BG_HEIGHT / 2;
        var titleNode = new TitleBackgroundNode(LocalizedString.Compete("兌換獎勵"), true);
        titleNode.setPosition(JSScreenMidPos.x, posY);
        titleNode.setTitleAnchorPoint(0, 0.5);
        titleNode.setTitlePosition(40 - JSScreenMidPos.x + JSScreenSafeWidth, 3);
        this.addChild(titleNode, 10);

        // 資產
        {
            // 資產資訊
            var assetsNode = this._assetsNode = new cc.Node();
            assetsNode.setVisible(false);
            assetsNode.setPosition(JSScreenBonusHalfWidth, JSVisibleSize.height - 42);
            this.addChild(assetsNode);

            // 鑽石圖示
            var diamondIconSprite = new cc.Sprite("#pic_diamond.png");
            diamondIconSprite.setPositionX(56);
            assetsNode.addChild(diamondIconSprite);

            // 鑽石數量
            var diamondLabel = this._diamondLabel = new GSNumberLabel(0, JSFontBoldName, 10);
            diamondLabel.setUseCurrencyString(true);
            diamondLabel.setAnchorPoint(0, 0.5);
            diamondLabel.setPositionX(diamondIconSprite.getPositionX() + 12);
            assetsNode.addChild(diamondLabel);

            // 德撲幣圖示
            var moneyIconSprite = new cc.Sprite("#chip_pic.png");
            moneyIconSprite.setPositionX(130);
            assetsNode.addChild(moneyIconSprite);

            // 德撲幣數量
            var moneyLabel = this._moneyLabel = new GSNumberLabel(0, JSFontBoldName, 10);
            moneyLabel.setUseCurrencyString(true);
            moneyLabel.setAnchorPoint(0, 0.5);
            moneyLabel.setPositionX(moneyIconSprite.getPositionX() + 12);
            assetsNode.addChild(moneyLabel);

            // 階級
            var classLabel = this._classLabel = new cc.LabelTTF("", JSFontBoldName, 10);
            classLabel.setAnchorPoint(1, 0.5);
            classLabel.setPositionX(464 + JSScreenBonusHalfWidth);
            assetsNode.addChild(classLabel);
        }

        // 兌換區
        var exchangeNode = this._exchangeNode = new cc.Node();
        this.addChild(exchangeNode);

        // Loading
        var loading = this._loadingSp = new GSLoadingSprite();
        loading.start();
        loading.setPosition(JSScreenMidPos);
        this.addChild(loading);

        // 要兌換頁資料
        DataProcess.sendString("diamond_info");

        // 註冊通知
        GS.addListener("NotifyCompeteRewardDone", this.notifyCompeteRewardDone.bind(this), this);
        GS.addListener("NotifySessionStatusDone", this.notifySessionStatusDone.bind(this), this);
    },

    /**
     * 刷新資產
     */
    _refreshAsset: function () {
        var competeString = LocalizedString.Compete;

        // 刷新資產
        var profileData = DataModal.profileData;
        this._assetsNode.setVisible(true);
        this._moneyLabel.setToNumber(profileData.money);
        this._diamondLabel.setToNumber(profileData.diamond);
        this._classLabel.setString(JSStringUtility.format("%s : %s", competeString("鑽石階級"), competeString(DataModal.regionsData.getDiamondClassName(profileData.diamond))));
    },

    /**
     * 刷新兌換區商品
     */
    _refreshExchangeNode: function () {
        // 停掉loading
        this._loadingSp.stop();

        var competeString = LocalizedString.Compete;

        // 先清掉原本的
        var exchangeNode = this._exchangeNode;
        exchangeNode.removeAllChildren();

        // 下方資訊
        var infoLabel = new cc.LabelTTF(competeString("※每天早上6點更新兌換次數和項目"), JSFontName, 10);
        infoLabel.setAnchorPoint(0, 0.5);
        infoLabel.setPosition(48 + JSScreenBonusHalfWidth, 20);
        exchangeNode.addChild(infoLabel);

        // 按鈕
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        exchangeNode.addChild(menu);

        // 下方刷新按鈕
        var btnSize = cc.size(142, 26);
        var title = JSStringUtility.format(competeString("刷新項目(消耗%d顆鑽石)"), DataModal.regionsData.diamondInfo.refreshCost);
        var refreshBtn = ButtonUtility.createSimpleButton("lobby_btn_01.png", btnSize, title, JSColor.BLACK, 10);
        refreshBtn.setAnchorPoint(1, 0.5);
        refreshBtn.setPosition(464 + JSScreenBonusHalfWidth, 20);
        refreshBtn.addTouchUpInsideAction(this._refreshBtnClicked, this);
        refreshBtn.label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        exchangeNode.addChild(refreshBtn);

        // 抓最新清單
        var itemArray = DataModal.regionsData.diamondInfo.exchangeItemArray;
        // 商品node大小
        var boxSize = cc.size(204, (JSVisibleSize.height - 100) / 2);
        // 間距
        var gap = 8;

        // 依序建出來商品
        for (var i = 0, boxIdx = -1, len = itemArray.length; i < Math.min(len, 4); i++) {
            var param = itemArray[i];
            if (!param.name)
                continue;

            boxIdx++;

            // 調整位置
            var pos = cc.p(48 + JSScreenBonusHalfWidth + (boxIdx % 2) * (gap + boxSize.width), 40 + ((1.5 - Math.floor(boxIdx / 2)) * (boxSize.height + 5)));

            // 建立兌換商品
            var diamondExchangeNode = new DiamondExchangeNode(boxSize, param);
            diamondExchangeNode.setPosition(pos);
            exchangeNode.addChild(diamondExchangeNode);
        }

        // 刷新資產
        this._refreshAsset();

        // 檢查要不要跳教學
        var account = DataModal.profileData.account;
        var needTeach = parseInt(GS.localStorage.getItem(UserDefaultKey.DiamondExchangeTeachLayer + account, 0, true)) === 0;
        if (needTeach) {
            // 教學
            var teachLayer = new CompeteTeachLayer(CompeteTeachLayer.TeachType.Diamond_Exchange);
            this.addChild(teachLayer, 20);

            // 記下來跳過了
            GS.localStorage.setItem(UserDefaultKey.DiamondExchangeTeachLayer + account, "1", true);
        }
    },

    /**
     * 按鈕點擊事件
     */

    /**
     * 點擊更新商品按鈕
     */
    _refreshBtnClicked: function () {
        var refreshCost = DataModal.regionsData.diamondInfo.refreshCost;
        // 鑽石不夠
        if (DataModal.profileData.diamond < refreshCost) {
            DialogManager.addDialog(new AvatarDialog({content: LocalizedString.Compete("鑽石不足")}));
        }
        // 跳詢問是否要換
        else {
            DialogManager.addDialog(new AvatarDialog({
                content: JSStringUtility.format(LocalizedString.Compete("是否以%d顆鑽石刷新兌換商品？"), refreshCost),
                callback: (index) => {
                    // 按確定要重新要資料並刷新畫面
                    if (index === 0) {
                        DataProcess.sendString("diamond_refresh");

                        this._exchangeNode.removeAllChildren();
                        this._loadingSp.start();
                    }
                }
            }));
        }
    },

    /**
     * 通知事件
     */
    // 通知拿到資料
    notifySessionStatusDone: function () {
        this._refreshAsset();
    },

    // 通知拿到新的商品清單
    notifyCompeteRewardDone: function () {
        this._refreshExchangeNode();
    }
});