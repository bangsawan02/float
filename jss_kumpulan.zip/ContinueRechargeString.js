var LocalizedString = LocalizedString || {};

(function() {
    let keyValue = {
        // 標題
        "寶石集市": "Bazaar Permata",

        // 副標題
        "收集": "Kumpulkan",
        "累積進度，贏取超級大獎": ", menangkan hadiah super",

        // 獎勵區
        "免費": "Gratis",
        "領獎": "Klaim",
        "限儲值中心": "Khusus Toko Chips",
        "點擊任一處繼續": "Klik area mana saja untuk lanjut",

        // Dialog
        "活動時間已結束！": "Event telah berakhir!",
        "確定": "OK",
        "恭喜獲得": "Selamat mendapatkan",
        "恭喜獲得超級大獎": "Selamat mendapatkan hadiah super",
        "領獎失敗，請稍後再試": "Pembelian gagal, mohon coba beberapa saat lagi",

        // 教學模式
        "點擊領獎即可\n獲得獎勵": "Klik untuk\nambil hadiah",
        "超級大獎\n等著你哦！": "Grand Prize\nmenanti Anda!"
    }
    LocalizedString.ContinueRecharge = function (str) {
        return USE_i18n ? (keyValue[str] || str) : str;
    }
})()
