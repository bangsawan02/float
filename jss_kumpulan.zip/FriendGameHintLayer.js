/**
 * 好友相關的桌內提示: (依造順序跳出)
 * @ 好友上線/下線
 * @ 加好友
 */
var FriendGameHintLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 動畫移動的時間
        this._moveTime = 0.2;

        // 創一個Queue來輪流撥放
        this._queue = [];

        GS.addListener("NotifyShowFriendOnlineHint", this.notifyShowFriendOnlineHint.bind(this), this);
        GS.addListener("NotifyShowFriendAddHint", this.notifyShowFriendAddHint.bind(this), this);
        GS.addListener("NotifyFriendChangeDone", this.notifyFriendChangeDone.bind(this), this);
    },

    /**
     * 創加好友的提示UI
     */
    _initAddHint: function (param) {
        var bgSize = cc.size(140, 79);

        var addNode = new cc.Node();
        addNode.setContentSize(bgSize);
        this.addChild(addNode);

        var localStr = LocalizedString.Friend;

        // 用來當底的Node
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_list_02.png");
        bgSprite.setAnchorPoint(0, 0);
        bgSprite.setPreferredSize(cc.size(140, 79));
        addNode.addChild(bgSprite);

        // 名字
        var nameLabel = new cc.LabelTTF(param.nickname, JSFontName, 12);
        nameLabel.setAnchorPoint(0, 0.5);
        nameLabel.setPosition(43, 60);
        addNode.addChild(nameLabel);

        // 玩家大頭照
        var photoNode = new GamePlayerPhotoNode(param.photo);
        photoNode.setPosition(24, 59);
        photoNode.setScale(0.5);
        addNode.addChild(photoNode);

        // 上線訊息
        var hintLabel = new cc.LabelTTF(localStr("想要加你好友"), JSFontName, 9);
        hintLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        hintLabel.setPosition(69, 35);
        addNode.addChild(hintLabel);

        var showTime = 5;
        if (param.type === 1) {
            // 1: 加好友的提示
            addNode.userID = param.userID;

            // Menu
            var menu = addNode.menu = new cc.Menu();
            menu.setPosition(0, 0);
            addNode.addChild(menu);

            // 拒絕按鈕
            itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_02.png", cc.size(56, 20), localStr("拒絕"), 10, JSColor.WHITE);
            var noMenuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._menuItemClicked, this);
            noMenuItem.setPosition(37, 15);
            noMenuItem.setTag(0);
            menu.addChild(noMenuItem);

            // 接受按鈕
            var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", cc.size(56, 20), localStr("接受"), 10, JSColor.BLACK);
            var okMenuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._menuItemClicked, this);
            okMenuItem.setPosition(100, 15);
            okMenuItem.setTag(1);
            menu.addChild(okMenuItem);
        } else if (param.type === 2) {
            // 2: 同意邀請文案
            hintLabel.setPositionY(28);
            hintLabel.setFontFillColor(JSColor.YELLOW);
            hintLabel.setString(localStr("與你已成為好友!"));
            showTime = 2;
        } else if (param.type === 3) {
            // 3: 不同意邀請文案
            hintLabel.setPositionY(28);
            hintLabel.setOpacity(178);
            hintLabel.setString(localStr("你已拒絕成為好友"));
            showTime = 2;
        }

        var hintObj = {
            hintNode: addNode,
            showTime: showTime,
            showPos: cc.p(JSVisibleSize.width - bgSize.width, JSVisibleSize.height - bgSize.height),
            closePos: cc.p(JSVisibleSize.width + bgSize.width, JSVisibleSize.height - bgSize.height)
        };
        this._addMessageToQuene(hintObj);
    },

    /**
     * 創好友上線提示的UI
     */
    _initOnlineHint: function (param) {
        var bgSize = cc.size(135, 45);

        var onlineNode = new cc.Node();
        onlineNode.setContentSize(bgSize);
        this.addChild(onlineNode);

        // 用來當底的Node
        var bgSp = new ccui.Scale9Sprite("lobby_bg_list_02.png");
        bgSp.setAnchorPoint(0, 0);
        bgSp.setPreferredSize(bgSize);
        onlineNode.addChild(bgSp);

        // 名字
        var nameLabel = new cc.LabelTTF(param.name, JSFontName, 12);
        nameLabel.setPosition(86, 31);
        onlineNode.addChild(nameLabel);

        // 玩家大頭照
        var photoNode = new GamePlayerPhotoNode(param.photo);
        photoNode.setScale(0.49);
        photoNode.setPosition(22, 23);
        onlineNode.addChild(photoNode);

        // 上線訊息
        var hintLabel = new cc.LabelTTF("Online", JSFontName, 12);
        hintLabel.setFontFillColor(cc.color(176, 255, 0));
        hintLabel.setPosition(78, 15);
        onlineNode.addChild(hintLabel);

        // 綠燈
        var onlineSp = new cc.Sprite("#lobby_prompt_bg3.png");
        onlineSp.setScale(0.5);
        onlineSp.setPosition(103, 15);
        onlineNode.addChild(onlineSp);

        var hintWidth = hintLabel.getContentSize().width;
        onlineSp && onlineSp.setPositionX(83 + hintWidth / 2);

        var hintObj = {
            hintNode: onlineNode,
            showTime: 2,
            showPos: cc.p(JSVisibleSize.width - bgSize.width, JSVisibleSize.height - bgSize.height),
            closePos: cc.p(JSVisibleSize.width + bgSize.width, JSVisibleSize.height - bgSize.height)
        };
        this._addMessageToQuene(hintObj);
    },


    /**
     * 把做好的Node放在Queue裡
     */
    _addMessageToQuene: function (hintObj) {
        // 把他設到最右邊 然後看不到
        hintObj.hintNode.setPosition(hintObj.closePos);
        hintObj.hintNode.setVisible(false);

        // Queue起來
        this._queue.push(hintObj);

        // 去撥放它
        this._playQueueNode();
    },

    /**
     * 去撥放Queue裡的東西
     */
    _playQueueNode: function () {
        if (this._isShow || this._queue.length === 0)
            return;

        this._isShow = true;

        // 開始撥放 抓最前面的
        var hintObj = this._moveObj = this._queue.shift();
        hintObj.hintNode.runAction(cc.sequence(
            cc.show(),
            cc.moveTo(this._moveTime, hintObj.showPos),
            cc.delayTime(hintObj.showTime),
            cc.moveTo(this._moveTime, hintObj.closePos),
            cc.callFunc(() => {
                // 把現在有出現的Flag清掉
                this._isShow = false;

                // 去撥下一個
                this._playQueueNode();
            }),
            cc.removeSelf()
        ));
    },

    /**
     * 點擊同意/不同意按鈕
     */
    _menuItemClicked: function (sender) {
        var hintNode = this._moveObj.hintNode;

        // 2:同意 3:不同意
        var tag = sender.getTag();
        var obj = {
            userid: hintNode.userID,
            type: (tag) ? 2 : 3
        };
        DataProcess.sendString("user_invite_friend " + JSON.stringify(obj));

        // 先把按鈕關掉
        if (hintNode.menu) {
            hintNode.menu.setVisible(false);
        }

        // 把提示關掉
        hintNode.stopAllActions();
        hintNode.runAction(cc.sequence(
            cc.moveTo(this._moveTime, this._moveObj.closePos),
            cc.callFunc(() => {
                // 把現在有出現的Flag清掉
                this._isShow = false;

                // 去撥下一個
                this._playQueueNode();
            }),
            cc.removeSelf()
        ));
    },

    /**
     * 通知有好友上線
     * @param event
     */
    notifyShowFriendOnlineHint: function (event) {
        var settingOn = parseInt(GS.localStorage.getItem("UserDefaultfriendOnlineShowPushNotify", 1)) === 1;
        if (settingOn) {
            if (event && event.getUserData()) {
                // 創UI
                this._initOnlineHint(event.getUserData());
            }
        }
    },

    /**
     * 通知有好友邀請
     * @param event
     */
    notifyShowFriendAddHint: function (event) {
        if (event && event.getUserData()) {
            var param = event.getUserData();
            // 設定顯示加好友的提示
            param.type = 1;
            this._initAddHint(param);
        }
    },

    /**
     * 通知顯示同意/拒絕加好友
     * @param event
     */
    notifyFriendChangeDone: function (event) {
        if (event && event.getUserData()) {
            this._initAddHint(event.getUserData());
        }
    }
});