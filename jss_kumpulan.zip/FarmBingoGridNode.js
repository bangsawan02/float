/**
 * v5.6.0 齋戒副系統 - 賓果格子
 * @param index {int} 格子所在的 index
 */
var FarmBingoGridNode = cc.Node.extend({
    ctor: function (index) {
        this._super();

        this._index = index;

        switch (index) {
            case 12:
                this._normalFileName = "farm_bingo_pic_grass.png";
                break;

            case 0:
            case 4:
                this._normalFileName = "farm_bingo_pic_grid_01.png";
                this._wonFileName = "farm_bingo_pic_grid-2_01.png";
                break;

            case 20:
            case 24:
                this._normalFileName = "farm_bingo_pic_grid_03.png";
                this._wonFileName = "farm_bingo_pic_grid-2_03.png";
                break;

            default:
                this._normalFileName = "farm_bingo_pic_grid_02.png";
                this._wonFileName = "farm_bingo_pic_grid-2_02.png";
                break;
        }

        // 格子背景圖
        const bgSprite = this._bgSprite = new cc.Sprite("#" + this._normalFileName);
        bgSprite.setScale(1.14);
        if (index === 4 || index === 24) {
            // 右上角與右下角要鏡像
            bgSprite.setFlippedX(true);
        }
        this.addChild(bgSprite);

        if (index !== 12) {
            // 獎勵罐
            const potSprite = this.potSprite = new cc.Sprite("#farm_bingo_pic_apple_2.png");
            potSprite.setVisible(false);
            potSprite.setPosition(0, 1);
            this.addChild(potSprite);

            // 一般數字
            const numberLabel = this.label = new GSSpriteNumberNode({
                number: 0,
                numStr: "#farm_bingo_num_r_",
                spW: 12,
                spH: 18
            });
            numberLabel.setVisible(false);
            this.addChild(numberLabel);

            // 跑中格子漸入動畫
            const wonNode = this._wonNode = new cc.Node();
            wonNode.setCascadeOpacityEnabled(true);
            wonNode.setPosition(0, 0);
            wonNode.setVisible(false);
            this.addChild(wonNode);

            // 中獎格子背景
            const wonBgSprite = new cc.Sprite("#" + this._wonFileName);
            wonBgSprite.setScale(bgSprite.getScale());
            if (index === 4 || index === 24) {
                // 右上角與右下角要鏡像
                wonBgSprite.setFlippedX(true);
            }
            wonNode.addChild(wonBgSprite);

            // 贏得數字
            const wonNumberLabel = wonNode.label = new GSSpriteNumberNode({
                number: 0,
                numStr: "#farm_bingo_num_y_",
                spW: 12,
                spH: 18
            });
            wonNode.addChild(wonNumberLabel);
        }
    },

    setIsWon: function (isWon) {
        if (this._index === 12) {
            return;
        }

        // 紀錄
        this._isWon = isWon;

        // UI 更新
        this._wonNode.setVisible(isWon);
        this._bgSprite.setVisible(!isWon);
        this.label.setVisible(!isWon);
        this.potSprite.setVisible(!isWon);
    },

    playWonAnimeAsync: function () {
        return new Promise((resolve) => {
            this._wonNode.setVisible(true);
            this._wonNode.setOpacity(0);
            this._wonNode.runAction(cc.sequence(
                cc.fadeIn(0.2),
                cc.callFunc(() => {
                    this.setIsWon(true);
                    resolve();
                })
            ));
        });
    },

    setPotSpriteVisible: function (isVisible) {
        this.potSprite?.setVisible(!this._isWon && isVisible);
    },

    setNumber: function (number) {
        if (this.label && this._index !== 12) {
            this.label.setVisible(true);
            this.label.setNumber(number);
            this._wonNode.label.setNumber(number);
        }
    }
});