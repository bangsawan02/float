/**
 * 9T 幸運彩票 - 前期結果 頁面
 */

var BigLotteryHistoryLayer = BigLotteryBaseLayer.extend({
    ctor: function () {
        this._super();

        this.pageType = BigLotteryLayer.PageType.HISTORY_PAGE;
        var bigLotteryStr = LocalizedString.BigLottery;

        // 主要畫面的node
        var mainNode = this._mainNode;

        // 裝紀錄的node
        var recordNode = this._recordNode = new cc.Node();
        mainNode.addChild(recordNode);

        // Domino移植設定 在地化文案/調整描邊
        // 沒有紀錄的文字
        var noRecordLabel = this._noRecordLabel = new cc.LabelTTF(bigLotteryStr("目前沒有開獎紀錄唷!"), JSFontName, 16);
        noRecordLabel.enableStroke(cc.color(190, 30, 0, 255), 2);
        noRecordLabel.setPosition(JSScreenMidPos.x, 150 + JSScreenBonusHalfHeight);
        mainNode.addChild(noRecordLabel);

        // 中間線
        var lineSprite = new ccui.Scale9Sprite("bigLottery_pic_line.png");
        lineSprite.setPreferredSize(cc.size(300, 4));
        lineSprite.setPosition(253 + JSScreenBonusHalfWidth, 84 + JSScreenBonusHalfHeight);
        mainNode.addChild(lineSprite);

        // Domino移植設定 加上倒數
        var clockNode = new BigLotteryClockNode();
        clockNode.setScale(0.75);
        clockNode.setPosition(462 + JSScreenBonusHalfWidth, JSVisibleSize.height - 28);
        mainNode.addChild(clockNode);

        // Domino移植設定 客製畫面
        // 下方
        {
            // 紅色背景
            var redBgSprite = new ccui.Scale9Sprite("bigLottery_bg_redLine02.png");
            redBgSprite.setPreferredSize(cc.size(410, 72));
            redBgSprite.setPosition(312 + JSScreenBonusHalfWidth, 41 + JSScreenBonusHalfHeight);
            mainNode.addChild(redBgSprite);

            // 錢幣堆
            var coinSprite = new cc.Sprite("#bigLottery_pic_money.png");
            coinSprite.setPosition(464 + JSScreenBonusHalfWidth, 86);
            mainNode.addChild(coinSprite);

            // 按鈕
            var menu = new cc.Menu();
            menu.setPosition(0, 0);
            mainNode.addChild(menu);

            // 三個按鈕
            var btnImages = ["lobby_btn_03.png", "lobby_btn_03.png", "lobby_btn_06.png"];
            var btnCenterImages = ["#bigLottery_pic_lastHistoryBtn.png", "#bigLottery_pic_getRewardListBtn.png", "#bigLottery_pic_chooseHistoryBtn.png"];
            var imgScale = [1, 1, 0.8];
            var btnStrings = ["前期結果", "中獎名單", "歷史紀錄"].map(string => bigLotteryStr(string));
            this._btnList = [];
            for (var i = 0; i < 3; i++) {
                var btnSize = cc.size(80, 60);
                var itemNode = [];
                for (var j = 0; j < 3; j++) {
                    var node = itemNode[j] = new cc.Node();
                    node.setContentSize(btnSize);
                    node.setCascadeColorEnabled(true);

                    // 按鈕背景
                    var bgSprite = new ccui.Scale9Sprite(btnImages[j]);
                    bgSprite.setPreferredSize(btnSize);
                    bgSprite.setPosition(btnSize.width / 2, btnSize.height / 2);
                    node.addChild(bgSprite);

                    // 圖片
                    var btnImageSprite = new cc.Sprite(btnCenterImages[i]);
                    btnImageSprite.setPosition(btnSize.width / 2, btnSize.height / 2 + 7);
                    btnImageSprite.setScale(imgScale[i]);
                    node.addChild(btnImageSprite);

                    // 文字內容
                    var btnLabel = new cc.LabelTTF(btnStrings[i], JSFontName, 11, cc.size(80, 40), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_BOTTOM);
                    btnLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                    btnLabel.enableStroke(((j === 2) ? TexasUtility.OutlineColor.GRAY : TexasUtility.OutlineColor.BLUE), 2);
                    btnLabel.setAnchorPoint(0.5, 0);
                    btnLabel.setPosition(btnSize.width / 2, 7);
                    node.addChild(btnLabel);
                }
                itemNode[1].setColor(JSColor.GRAY);
                var btn = this._btnList[i] = new cc.MenuItemSprite(itemNode[0], itemNode[1], itemNode[2], this._btnClicked, this);
                btn.setPosition(153 + 95 * i + JSScreenBonusHalfWidth, 41 + JSScreenBonusHalfHeight);
                menu.addChild(btn);
            }
        }

        // 通知
        GS.addListener("NotifyBigLotteryHistoryInfoDone", this.notifyBigLotteryHistoryInfoDone.bind(this), this);
    },

    /**
     * override
     */
    _enterPage: function () {
        var bigLotteryData = DataModal.bigLotteryData;

        // 有資料了直接重刷
        if (bigLotteryData.historyParam && !bigLotteryData.needRefreshHistoryPage) {
            this._refreshView();
        } else {
            // 初始化狀態
            this._loadingSprite.start();
            this._mainNode.setVisible(false);

            // 要資料
            DataProcess.sendString("big_lottery_history");
        }
    },

    /**
     * 更新畫面
     */
    _refreshView: function () {
        this._loadingSprite.stop();

        // 抓資料
        var historyParam = DataModal.bigLotteryData.historyParam;
        if (historyParam) {
            this._mainNode.setVisible(true);

            var recordNode = this._recordNode;
            var noRecordLabel = this._noRecordLabel;

            // 有開獎紀錄
            var historyList = historyParam.historyList;
            if (historyList && historyList.length) {
                // 先清掉畫面
                recordNode.removeAllChildren();
                recordNode.setPosition(0, 0);

                // 上期的資料
                var lastPeriodParam = historyList[0];

                // 有紅包
                if (historyParam.envelopeHistoryList && historyParam.envelopeHistoryList.length > 0) {
                    // 把紅包資訊存成彩票可以吃的狀態
                    var param = historyParam.envelopeHistoryList[0];
                    var envelopeParam = {
                        count: param.winnerCount,   // 大紅包得獎人數
                        numList: param.numList,     // 大紅包號碼
                        period: param.period        // 期數
                    };

                    // scroll view
                    var scrollViewSize = cc.size(300, 200);
                    var container = new cc.Layer();
                    var scrollView = this._scrollView = new cc.ScrollView(scrollViewSize, container);
                    scrollView.setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
                    scrollView.setContentSize(cc.size(620, 200));
                    scrollView.setPosition(116 + JSScreenBonusHalfWidth, 70 + JSScreenBonusHalfHeight);
                    recordNode.addChild(scrollView);

                    // 上期畫面
                    var rewardNode = this._createResultNode(lastPeriodParam, envelopeParam);
                    rewardNode.setPosition(140, 80);
                    scrollView.addChild(rewardNode);
                } else {
                    // 上期畫面
                    var rewardNode = this._createResultNode(lastPeriodParam);
                    rewardNode.setPosition(JSScreenMidPos.x, 150 + JSScreenBonusHalfHeight);
                    recordNode.addChild(rewardNode);
                }

                // 有幸運數字
                if (historyParam.luckyHistoryList && historyParam.luckyHistoryList.length > 0) {
                    // 幸運數字開獎框
                    // Domino移植設定 改成放mainNode才不會被硬幣擋住、位置調整
                    var bingoNode = this._createBingoNode(historyParam.luckyHistoryList[0].number);
                    bingoNode.setPosition(398 + JSScreenBonusHalfWidth, 104 + JSScreenBonusHalfHeight);
                    this._mainNode.addChild(bingoNode, 10);

                    // Domino移植設定 沒有財神
                    // 財神要往下移
                    // this._godSprite.setPositionY(38 + JSScreenBonusHalfHeight);

                    // 左方票券整個往左移
                    recordNode.setPositionX(-10);
                }

                // 調整畫面
                recordNode.setVisible(true);
                noRecordLabel.setVisible(false);

                // 調整按鈕
                this._btnList.forEach(btn => {
                    btn.setEnabled(true);
                });
            } else {
                // 調整畫面
                recordNode.setVisible(false);
                noRecordLabel.setVisible(true);

                // 調整按鈕
                this._btnList.forEach(btn => {
                    btn.setEnabled(false);
                });
            }
        }
    },

    /**
     * 創結果node
     * @param param             彩票資料
     * @param envelopeParam     紅包資料
     */
    _createResultNode: function (param, envelopeParam = undefined) {
        var bigLotteryStr = LocalizedString.BigLottery;

        var node = new cc.Node();

        // 開獎紀錄
        var titleSprite = new cc.Sprite(envelopeParam ? "#bigLottery_word_seeEnvelopeNumber.png" : "#bigLottery_word_lastNumber.png");
        titleSprite.setPosition(0, 44);
        node.addChild(titleSprite);

        // 票
        var ticketCell = new BigLotteryMyTicketCell(false);
        ticketCell.refreshCell(param);
        ticketCell.setPosition(-160, -38);
        node.addChild(ticketCell);

        // 裝文字的node
        var labelNode = new GSAutoLayoutNode();
        labelNode.setPosition(0, -46);
        node.addChild(labelNode);

        // 文字: 開出頭獎：
        var label = new cc.LabelTTF(bigLotteryStr("開出頭獎:"), JSFontName, 16);
        label.enableStroke(cc.color(190, 30, 0, 255), 2);
        labelNode.addChild(label);

        // 文字: 是 or 否
        label = new cc.LabelTTF(bigLotteryStr(param.hasWinner ? "是" : "否"), JSFontName, 16);
        label.setFontFillColor(JSColor.YELLOW);
        label.enableStroke(cc.color(190, 30, 0, 255), 2);
        labelNode.addChild(label);

        // 如果有紅包資料
        if (envelopeParam) {
            // 按鈕
            var menu = new cc.Menu();
            menu.setPosition(0, 0);
            node.addChild(menu);

            // 箭頭按鈕
            for (var i = 0; i < 2; i++) {
                var arrowItemNode = [];
                for (var j = 0; j < 3; j++) {
                    arrowItemNode[j] = new cc.Node();
                    arrowItemNode[j].setCascadeColorEnabled(true);

                    // 箭頭
                    var arrowSprite = new cc.Sprite(j === 2 ? "#bigLottery_pic_arrow_off.png" : "#bigLottery_pic_arrow.png");
                    arrowSprite.setScale(0.8);
                    arrowSprite.setFlippedX(i === 1);
                    arrowSprite.setPosition(cc.p(arrowSprite.getContentSize().width / 2, arrowSprite.getContentSize().height / 2));
                    arrowItemNode[j].setContentSize(arrowSprite.getContentSize());
                    arrowItemNode[j].addChild(arrowSprite);
                }
                arrowItemNode[1].setColor(JSColor.GRAY);
                var arrowBtn = new cc.MenuItemSprite(arrowItemNode[0], arrowItemNode[1], arrowItemNode[2], this._arrowBtnClicked, this);
                arrowBtn.idx = i;
                arrowBtn.setPosition(150 + i * 40, 0);
                menu.addChild(arrowBtn);
            }

            // 大紅包往左滑看前期號碼文字
            var titleSprite = new cc.Sprite("#bigLottery_word_seeLastNumber.png");
            titleSprite.setPosition(340, 44);
            node.addChild(titleSprite);

            // 票
            var ticketCell = new BigLotteryMyTicketCell(false, true);
            ticketCell.refreshCell(envelopeParam);
            ticketCell.setPosition(180, -38);
            node.addChild(ticketCell);

            // 裝文字的node
            var labelNode = new GSAutoLayoutNode();
            labelNode.setPosition(320, -46);
            node.addChild(labelNode);

            // 文字: 開出頭獎：
            var label = new cc.LabelTTF(bigLotteryStr("中獎人數："), JSFontName, 16);
            label.enableStroke(cc.color(190, 30, 0, 255), 2);
            labelNode.addChild(label);

            // 文字: XXX人
            label = new cc.LabelTTF(JSStringUtility.format(bigLotteryStr("%d人"), envelopeParam.count), JSFontName, 16);
            label.setFontFillColor(JSColor.YELLOW);
            label.enableStroke(cc.color(190, 30, 0, 255), 2);
            labelNode.addChild(label);
        }

        return node;
    },

    /**
     * 創賓果球node
     */
    _createBingoNode: function (number) {
        var midPos = cc.p(55, 55);

        var bingoNode = new cc.Node();

        // 背景
        var bgSize = cc.size(76, 80);
        var bgSprite = new ccui.Scale9Sprite("bigLottery_bg_purpleboard2.png");
        bgSprite.setPreferredSize(bgSize);
        bgSprite.setPosition(midPos);
        bingoNode.addChild(bgSprite);

        // 彩帶
        var ribbonSprite = new cc.Sprite("#bigLottery_pic_ribbon.png");
        ribbonSprite.setPosition(midPos.x, midPos.y + 24);
        bingoNode.addChild(ribbonSprite);

        // 標題
        // Domino移植設定 圖片
        var titleLabel = new cc.Sprite("#bigLottery_word_luckyBingo.png");
        titleLabel.setPosition(midPos.x, midPos.y + 30);
        bingoNode.addChild(titleLabel);

        // 賓果球
        var ballNode = new BigLotteryBingoBallNode(number);
        ballNode.setPosition(midPos.x, midPos.y - 10);
        bingoNode.addChild(ballNode);

        return bingoNode;
    },

    /**
     * 按鈕
     */
    // 點擊下方三個按鈕
    _btnClicked: function (sender) {
        MusicUtility.playEffect("Music/Effect/e_clickButton.mp3", false);

        // 找出現在按的是哪一個按鈕
        var clickedIndex = 0;
        for (var i = 0, len = this._btnList.length; i < len; i++) {
            if (sender === this._btnList[i]) {
                // 記下index
                clickedIndex = i;

                break;
            }
        }

        // 埋點
        DataProcess.sendString(JSStringUtility.format("big_lottery_record_log %d", clickedIndex + 5));

        // 通知主畫面點擊了按鈕
        var param = {
            isShow: true,
            clickedIndex: clickedIndex
        };
        GS.dispatchCustomEvent("NotifyBigLotteryHistoryShowPage", param);
    },

    // 點擊箭頭按鈕
    _arrowBtnClicked: function (sender) {
        var scrollView = this._scrollView;

        // 防呆 && 滑動中不給按
        if (!sender || !scrollView.isTouchEnabled())
            return;

        // 鎖住畫面
        scrollView.setTouchEnabled(false);

        // 滑到最左或最右
        var offsetX = (sender.idx) ? 0 : -scrollView.getContentSize().width / 2 - 10;
        scrollView.setContentOffsetInDuration(cc.p(offsetX, 0), 0.5);

        // 滑完打開scroll view
        this.runAction(cc.sequence(
            cc.delayTime(0.5),
            cc.callFunc(() => {
                scrollView.setTouchEnabled(true);
            })
        ));
    },

    /**
     * 通知
     */

    // 通知收到歷史資料
    notifyBigLotteryHistoryInfoDone: function () {
        this._refreshView();
    }
});
