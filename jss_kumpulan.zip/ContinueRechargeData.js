/**
 * 5.5.9 移植中撲 連續儲值 - data
 * created by kai.wu
 */

var ContinueRechargeData = cc.Class.extend({
    ctor: function () {
        this.clean();

        // 註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            "continue_recharge_icon": this.cmd_continue_recharge_icon,
            "continue_recharge_info": this.cmd_continue_recharge_info,
            "continue_recharge_free": this.cmd_continue_recharge_free,
            "continue_recharge_reward": this.cmd_continue_recharge_reward
        });
    },

    /**
     * 砍掉Data
     */
    destroyData: function () {
        DataProcess.removeSocketKeyDispatch(this);
    },

    clean: function () {
        this.isOpen = false;
        this.info = undefined;
        this.continueRechargeTeachMode = false;
    },

    // 抓取進大廳所需要的資訊
    startGetInfo: function () {
        DataProcess.sendString("continue_recharge_icon");
    },

    /**
     *  大廳按鈕
     *  C -> S continue_recharge_icon
     *  S -> C continue_recharge_icon
     */
    cmd_continue_recharge_icon: function (key, value) {
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value || "{}");

        // 活動有沒有開
        this.isOpen = JSCodeUtility.getBooleanValue(jsonValue["success"]);

        if (this.isOpen) {
            // 小紅點
            this.isShowRedPoint = JSCodeUtility.getBooleanValue(jsonValue["redPoint"]);
            // 活動剩餘時間
            this.remainTime = JSCodeUtility.getIntValue(jsonValue["timeLeft"]);
            // 收到的時間
            this.socketTime = JSCodeUtility.getNowTime();
            // 要不要主動彈跳
            this.isPop = JSCodeUtility.getBooleanValue(jsonValue["pop"]);
            // 週期
            this.period = JSCodeUtility.getStringValue(jsonValue["period"]);

            // 檢查需不需要教學，一個活動週期內只跳一次教學
            this.continueRechargeTeachMode = this.period !== GS.localStorage.getItem("continueRechargePeriod" + DataModal.profileData.account, "");
        }

        // 通知畫面
        GS.dispatchCustomEvent("NotifyContinueRechargeIconDone");
    },

    /**
     *  Dialog 相關
     *  C -> S continue_recharge_info
     *  S -> C continue_recharge_info
     */
    cmd_continue_recharge_info: function (key, value) {
        var jsonValue = JSON.parse(value || "{}");
        var param = this.info = {};

        param.isSuccess = JSCodeUtility.getBooleanValue(jsonValue["success"]);
        if (param.isSuccess) {
            param.timeLeft = JSCodeUtility.getIntValue(jsonValue["timeLeft"]);
            param.socketTime = JSCodeUtility.getNowTime();
            param.template = JSCodeUtility.getIntValue(jsonValue["template"]);
            param.canReward = JSCodeUtility.getBooleanValue(jsonValue["canReward"]);

            // 大獎相關
            var bigPrizeValue = jsonValue["bigPrize"];
            param.bigPrizeInfo = {
                // 進度元素多少會滿
                goalNum: JSCodeUtility.getIntValue(bigPrizeValue["goal"], 1),
                // 目前的進度元素
                achievedNum: JSCodeUtility.getIntValue(bigPrizeValue["achieved"]),
                rewardList: (bigPrizeValue["rewards"] || []).map(cur => {
                    return {
                        img: JSCodeUtility.getStringValue(cur["img"]),
                        name: JSCodeUtility.getStringValue(cur["name"])
                    };
                })
            };

            // 後續獎勵相關
            var planValue = jsonValue["plans"];
            param.rewardInfoArray = (planValue || []).map(cur => {
                return {
                    price: JSCodeUtility.getIntValue(cur["price"]),
                    rewardList: (cur["rewards"] || []).map(innerCur => {
                        return {
                            // token 1：收集進度元素  0:其他獎勵
                            isToken: JSCodeUtility.getStringValue(innerCur["isToken"]) === "1",
                            img: JSCodeUtility.getStringValue(innerCur["img"]),
                            name: JSCodeUtility.getStringValue(innerCur["name"])
                        };
                    })
                };
            });
        }

        // 通知畫面
        GS.dispatchCustomEvent("NotifyContinueRechargeInfoDone", param);
    },

    /**
     *  後續獎勵的內容
     *  C -> S continue_recharge_free
     *  S -> C continue_recharge_free
     */
    cmd_continue_recharge_free: function (key, value) {
        var jsonValue = JSON.parse(value || "{}");

        var param = {
            isSuccess: JSCodeUtility.getBooleanValue(jsonValue["success"]),
            type: ContinueRechargeRewardDialog.Type.free
        };

        if (param.isSuccess) {
            param.rewardMessage = JSCodeUtility.getStringValue(jsonValue["rewardMsg"]);

            // 新的後續獎勵
            var newPlan = jsonValue["newPlan"];
            param.newPlan = {
                price: JSCodeUtility.getIntValue(newPlan["price"]),
                productId: JSCodeUtility.getStringValue(newPlan["pid"]),
                rewardList: (newPlan["rewards"] || []).map(cur => {
                    return {
                        // isToken 1：收集進度元素  0:其他獎勵
                        isToken: JSCodeUtility.getStringValue(cur["isToken"]) === "1",
                        img: JSCodeUtility.getStringValue(cur["img"]),
                        name: JSCodeUtility.getStringValue(cur["name"])
                    };
                })
            };
        }
        // 通知畫面
        GS.dispatchCustomEvent("NotifyContinueRechargeRewardDone", param);
    },

    // 大獎的獎勵內容
    cmd_continue_recharge_reward: function (key, value) {
        var jsonValue = JSON.parse(value || "{}");

        var param = {
            isSuccess: JSCodeUtility.getBooleanValue(jsonValue["success"]),
            type: ContinueRechargeRewardDialog.Type.bigPrize
        };

        if (param.isSuccess) {
            param.rewardMessage = JSCodeUtility.getStringValue(jsonValue["rewardMsg"]);
            // 剩餘的進度元素
            param.tokens = JSCodeUtility.getIntValue(jsonValue["tokens"]);
        }
        // 通知畫面
        GS.dispatchCustomEvent("NotifyContinueRechargeRewardDone", param);
    },
});