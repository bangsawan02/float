/**
 * 牌王
 */

var CardKingData = cc.Class.extend({
    ctor: function () {
        // 初始化
        this.clean();

        // 註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            "crown_king_info": this.cmd_crown_king_info,
            "invitation_crown_king": this.cmd_invitation_crown_king,
            "all_invitation_crown_king": this.cmd_all_invitation_crown_king,
            "crown_king_map_main": this.cmd_crown_king_map_main,
            "crown_king_map_info": this.cmd_crown_king_map_info,
            "crown_king_map_player": this.cmd_crown_king_map_player,
            "crown_king_map_detail": this.cmd_crown_king_map_detail,
        });
    },

    /**
     * 砍掉Data
     */
    destroyData: function () {
        DataProcess.removeSocketKeyDispatch(this);
    },

    /**
     * 清除資料
     */
    clean: function () {
        // 現在狀態
        this.status = CardKingData.Status.NONE;

        // 收到cmd時間
        this.socketTime = 0;

        // 剩下多少時間
        this.remainTime = 0;

        // 獎章資料
        this.medalDetail = {};

        // 結算文字
        this.finalMsg = "";

        // 哪一年
        this.year = 0;

        // 哪一季
        this.season = 0;

        // 小紅點
        this.isRedDot = false;

        // 各等級牌王地圖
        this.mapInfo = {};

        // 自己
        this.selfMapInfo = {};

        // 自己舊的資料
        this.oldSelfInfo = {};

        // 大頭貼要用的
        this.baseURLObj = [];

        // 地圖節點細節
        this.nodeDetail = {};

        // 小紅點
        this.mapRedDot = {};

        // 這個按鈕看不看得到
        this.mapVisible = {};

        // 地圖多久更新
        this.mapRefreshHint = "";

        // 地圖頁籤有沒有紅點
        this.mapTabHasRedDot = false;
    },

    // 要資料
    startGetInfo: function () {
        // 普通資料
        DataProcess.sendString("crown_king_info");

        // 地圖資料
        DataProcess.sendString("crown_king_map_main");
    },

    // 要特定級別的地圖資料
    startGetMapInfoByLevel: function (level) {
        DataProcess.sendString(JSStringUtility.format('crown_king_map_info {"level":%d}', level));
        this.cleanNodeDetail(level);
    },

    // 要特定級別的自己資料
    startGetSelfInfo: function (level) {
        DataProcess.sendString(JSStringUtility.format('crown_king_map_player {"level":%d}', level));
    },

    // 要特定節點的資料
    startGetNodeInfo: function (level, round) {
        DataProcess.sendString(JSStringUtility.format('crown_king_map_detail {"level":%d,"node":%d}', level, round));
    },

    // 更新舊的自己資料
    refreshOldSelfInfo: function (level) {
        this.oldSelfInfo[level] = this.selfMapInfo[level];
    },

    // 功能是否是開啟的
    getIsOpen: function () {
        return this.status === CardKingData.Status.CALCULATING || this.status === CardKingData.Status.OPEN;
    },

    // 這個局數適用哪個規則
    getRuleGroupByRound: function (round) {
        if (this.mapRule && this.mapRule.length) {
            var index = 0;
            this.mapRule.every((cur, i) => {
                if (cur.startRound <= round)
                    index = i;
                return cur.startRound <= round;
            });
            return this.mapRule[index] || {};
        }
    },

    // 依局數給予顏色
    getColorTypeByRound: function (round) {
        var ret = this.getRuleGroupByRound(round).colorType || 1;
        ret = Math.max(1, ret);
        ret = Math.min(4, ret);
        return ret;
    },

    // 拿該等級的地圖資料
    getMapInfoByLevel: function (level) {
        return this.mapInfo[level];
    },

    // 拿地圖上特定cell所含有的局數
    getMapNodeRoundByIndex: function (index) {
        // 先拿出節點, 第幾個節點
        var nodeCount = index * 2;

        var calcFunc = (count) => {
            var ret = 0;
            for (var i = 0; i < count; ++i) {
                ret += this.getRuleGroupByRound(ret).nodeCount;
            }
            return ret;
        };

        // 先算第一個, 第二個再加上去就好
        var firstRound = calcFunc(nodeCount);

        return [firstRound, firstRound + this.getRuleGroupByRound(firstRound).nodeCount];
    },

    // 依現有的地圖資料找特定局數代表的idx
    getIndexBySearchCurrentDetail: function (level, round) {
        var mapInfo = this.getMapInfoByLevel(level);
        if (mapInfo && mapInfo.mapRouteList.length) {
            var ret = 0;
            mapInfo.mapRouteList.some((cur, i) => {
                // 是屬於上一個的
                if (cur[0].round > round)
                    return true;

                ret = i;

                // 是屬於這一個的
                if (cur[1].round >= round)
                    return true;
            });
            return ret;
        }
        return 0;
    },

    // 拿取特定節點的詳細資料
    getNodeDetail: function (level, round) {
        if (this.nodeDetail[level])
            return this.nodeDetail[level][round];
        return null;
    },

    // 清掉某張地圖的節點資料
    cleanNodeDetail: function (level) {
        this.nodeDetail[level] = {};
    },

    // 把玩家頭像路徑跟baseUrl組合起來
    // picJson格式:
    //     ["d","default_pic/photo_m-4.png"]    // 第一個參數代表base url的索引
    //     ["ori","https://graph.facebook.com/410205269861703/picture?type=normal&height=130&width=130"] // 索引是ori代表他是完整網址
    getPlayerImageURL: function (picJson) {
        picJson = picJson || [];
        if (picJson.length < 2) return "";

        var urlType = picJson[0];
        var urlStr = JSCodeUtility.getStringValue(picJson[1]);

        // 索引是ori代表他是完整網址 直接回傳
        if (urlType === "ori") return urlStr;

        return GS.httpScheme + JSCodeUtility.getStringValue(this.baseURLObj[urlType]) + "/" + urlStr;
    },

    // 確認顯有地圖有沒有要擴張
    checkMapNeedToExpend: function (level, maxRound) {
        var mapInfo = this.getMapInfoByLevel(level);

        if (mapInfo) {
            if (mapInfo.mapRouteList.length) {
                if (mapInfo.mapRouteList[mapInfo.mapRouteList.length - 1][1].round < maxRound) {
                    return true;
                }
            }
        }
        return false;
    },

    // 擴充地圖
    expendMap: function (level, maxRound) {
        if (this.checkMapNeedToExpend(level, maxRound)) {
            var routeList = this.getMapInfoByLevel(level).mapRouteList;

            // 所適用的規則多少node為一個節點
            var ruleNodeCount = this.getRuleGroupByRound(maxRound).nodeCount;
            // 最靠近的節點是誰
            var endRound = Math.ceil(maxRound / ruleNodeCount) * ruleNodeCount;

            // 從哪裡開始
            var startRound = routeList[routeList.length - 1][1].round;
            startRound += this.getRuleGroupByRound(startRound).nodeCount;

            var tempDetail = [];
            for (var i = startRound, j = 0; i <= endRound; i += this.getRuleGroupByRound(i).nodeCount, ++j) {
                if (j % 2 === 0) {
                    tempDetail = [];
                    routeList.push(tempDetail);
                }

                tempDetail.push({
                    round: i
                });
            }

            // 補足兩個, 之後cell才不會有問題
            if (!tempDetail[1]) {
                var tempRound = tempDetail[0].round + this.getRuleGroupByRound(tempDetail[0].round).nodeCount;
                tempDetail.push({
                    round: tempRound
                });
            }
        }
    },

    // 頁面資料
    cmd_crown_king_info: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value || "{}");

        // 狀態
        this.status = JSCodeUtility.getIntValue(jsonValue["status"]);

        // 剩餘時間
        this.remainTime = JSCodeUtility.getIntValue(jsonValue["left_time"]);
        this.socketTime = JSCodeUtility.getNowTime();

        // 結算文字
        this.finalMsg = JSCodeUtility.getStringValue(jsonValue["final_msg"]);

        // 哪一年
        this.year = JSCodeUtility.getIntValue(jsonValue["year"]);

        // 哪一季
        this.season = JSCodeUtility.getIntValue(jsonValue["season"], 1);
        // 防呆, 只有1,2,3,4季
        this.season = Math.max(this.season, 1);
        this.season = Math.min(this.season, 4);

        // 小紅點
        this.isRedDot = JSCodeUtility.getIntValue(jsonValue["red_point"]);

        // 獎章資訊
        var medalValue = jsonValue["badge_detail"] || [];

        // 額外禮物
        var extraGift = (jsonValue["extra_gift"] || {})["msg"] || "";

        medalValue.forEach(cur => {
            var detail = {};
            var level = JSCodeUtility.getIntValue(cur["level"]);

            // 要導去的盲注桌
            detail.fee = JSCodeUtility.getIntValue(cur["fee"]);

            // 入場費
            detail.needMoney = JSCodeUtility.getIntValue(cur["min_bring_in"]);

            // 顯示訊息(盲注桌)
            detail.msg = JSCodeUtility.getStringValue(cur["msg"]);

            // 本季獲得
            detail.isCurrentSeasonHave = JSCodeUtility.getIntValue(cur["this_season_get"]);

            // 本季獲得幾局
            detail.thisSeasonAchieveRoundCount = JSCodeUtility.getIntValue(cur["season_reelected"]);

            // 歷史蟬聯最高局數
            detail.maxWinRound = JSCodeUtility.getIntValue(cur["life_reelected"]);

            // 獎勵
            detail.rewards = (cur["reward"] || []).map(innerCur => {
                return JSCodeUtility.getStringValue(innerCur);
            });

            detail.rewards.push(extraGift);

            this.medalDetail[level] = detail;
        });

        // 地圖個節點的小紅點
        var redDotInfo = jsonValue["red_point_sub"] || {};
        var mapRedDotValue = redDotInfo["crown_king_map_level"] || [];

        // 地圖頁籤有沒有紅點
        this.mapTabHasRedDot = !!mapRedDotValue.length;

        mapRedDotValue.forEach(cur => {
            this.mapRedDot[JSCodeUtility.getIntValue(cur)] = true;
        });

        // 看大廳需不需要小紅點
        this.isRedDot = this.isRedDot || this.mapTabHasRedDot;

        GS.dispatchCustomEvent("NotifyCardKingInfoDone");
    },

    // 邀請
    cmd_invitation_crown_king: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        // 埋點
        DataProcess.sendString('track_crown_king {"type":"13"}');

        var jsonValue = JSON.parse(value || "{}");

        var param = {};

        // 誰邀請的
        param.userNickName = JSCodeUtility.getStringValue(jsonValue["nick"]);

        // 小盲
        param.smallBlind = JSCodeUtility.getIntValue(jsonValue["fee"]);

        // 大盲
        param.bigBlind = JSCodeUtility.getIntValue(jsonValue["bigblind"]);

        // 要多少錢
        param.needMoney = JSCodeUtility.getIntValue(jsonValue["need_money"]);

        // 房號
        param.roomID = JSCodeUtility.getStringValue(jsonValue["roomid"]);

        // 跳dialog
        DialogManager.addLobbyDialog(new CardKingInviteDialog(param));
    },

    // 桌內提示邀請多少人
    cmd_all_invitation_crown_king: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        // 不在遊戲內也不跳
        if (!PushScene.isGame)
            return;

        // 邀請多少人
        var peopleCount = JSCodeUtility.getIntValue(value);

        var msg = JSStringUtility.format(LocalizedString.CardKing("已發出戰帖給 %d 位線上玩家"), peopleCount);

        DialogManager.addDialog(new SimpleAlertDialog(msg), false);
    },

    // 地圖規則
    cmd_crown_king_map_main: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value || "{}");

        // 規則資料
        var ruleValue = jsonValue["node_rule"] || [];

        // 節點規則
        this.mapRule = ruleValue.map((cur, i) => {
            var ret = {};
            // 哪裡開始
            ret.startRound = JSCodeUtility.getIntValue(cur[0]);
            //幾局會是一個節點
            ret.nodeCount = JSCodeUtility.getIntValue(cur[2]);
            ret.colorType = i + 1;
            return ret;
        });

        // 牌王按鈕看不看得見
        this.mapVisible = {};
        (jsonValue["level"] || []).forEach(cur => {
            this.mapVisible[JSCodeUtility.getIntValue(cur)] = true;
        });

        // 大頭貼的網址
        this.baseURLObj = jsonValue["base_url"] || [];

        // 地圖更新的提示
        this.mapRefreshHint = JSCodeUtility.getStringValue(jsonValue["update_map_msg"]);

        GS.dispatchCustomEvent("NotifyCardKingMapMainDone");
    },

    // 地圖資訊
    cmd_crown_king_map_info: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value || "{}");

        this.mapInfo = this.mapInfo || {};

        // 這是哪張地圖
        var level = JSCodeUtility.getStringValue(jsonValue["crown_level"]);

        var mapInfo = this.mapInfo[level] = {};

        mapInfo.level = level;
        mapInfo.mapRouteList = [];

        var tempList = jsonValue["node_list"] || [];

        // 等等拿資料比較方便
        var findInfoObj = {};

        // 有哪幾個節點有資料
        var mapNodeInfo = tempList.map(cur => {
            var ret = {};
            ret.round = JSCodeUtility.getIntValue(cur["node"]);
            ret.playerImgUrl = this.getPlayerImageURL(cur["pic"]);
            findInfoObj[ret.round] = ret;
            return ret;
        });

        // 排名最高玩家
        var topValue = jsonValue["top_player"] || {};
        var topPlayer = mapInfo.topPlayer = {};
        topPlayer.round = JSCodeUtility.getIntValue(topValue["node"]);
        topPlayer.playerImgUrl = this.getPlayerImageURL(topValue["pic"]);
        // 是不是全服最強
        topPlayer.isTop = true;

        // 全服最強要的節點
        var topPlayerRound = this.getRuleGroupByRound(topPlayer.round).nodeCount;

        topPlayerRound = Math.ceil(topPlayer.round / topPlayerRound) * topPlayerRound;

        // 要秀到哪個節點
        var endRound = 0;
        if (mapNodeInfo.length)
            endRound = mapNodeInfo[mapNodeInfo.length - 1].round;

        // 所適用的規則多少node為一個節點
        var ruleNodeCount = this.getRuleGroupByRound(endRound).nodeCount;
        // 最靠近的節點是誰
        endRound = Math.ceil(endRound / ruleNodeCount) * ruleNodeCount;

        endRound = Math.max(endRound, topPlayerRound);

        topPlayer.roundOnCell = endRound;

        // 然後把所有node兩個兩個放一起, 方便之後刷新地圖, 地圖是兩個node一個cell
        var tempDetail = [];
        for (var i = 0, j = 0; i <= endRound; i += this.getRuleGroupByRound(i).nodeCount, ++j) {
            if (j % 2 === 0) {
                tempDetail = [];
                mapInfo.mapRouteList.push(tempDetail);
            }

            // 上面資料就有了
            if (findInfoObj[i]) {
                tempDetail.push(findInfoObj[i]);
                // 如果是全服最強
                if (i === endRound) {
                    findInfoObj[i].isTop = true;
                    findInfoObj[i].realRound = topPlayer.round;
                }
            } else {
                // 要創空的
                tempDetail.push({
                    round: i
                });
            }
        }

        // 補足兩個, 之後cell才不會有問題
        if (!tempDetail[1]) {
            var tempRound = tempDetail[0].round + this.getRuleGroupByRound(tempDetail[0].round).nodeCount;
            tempDetail.push({
                round: tempRound
            });
        }

        // 多久之後更新
        mapInfo.remainTime = JSCodeUtility.getIntValue(jsonValue["remain"]);
        mapInfo.socketTime = JSCodeUtility.getNowTime();

        // 跑馬燈
        mapInfo.marqueeArray = (jsonValue["marquee"] || []).map(cur => JSCodeUtility.getStringValue(cur));

        GS.dispatchCustomEvent("NotifyCardKingMapInfoDone", level);
    },

    // 玩家資訊
    cmd_crown_king_map_player: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value || "{}");

        // 什麼等級的資料
        var level = JSCodeUtility.getStringValue(jsonValue["crown_level"]);

        var info = this.selfMapInfo[level] = {};

        // 初始化後, 給一次值, 之後都要等動畫演完才會付值, 重登就算了
        if (!this.oldSelfInfo[level])
            this.oldSelfInfo[level] = this.selfMapInfo[level];

        // 目前蟬聯局數
        info.round = JSCodeUtility.getIntValue(jsonValue["node"]);
        // 圖片
        info.playerImgUrl = this.getPlayerImageURL(jsonValue["pic"]);

        // 有沒有變成第一名
        var mapInfo = this.getMapInfoByLevel(level);

        // 跑馬燈
        var marqueeArray = jsonValue["marquee"];
        if (marqueeArray)
            mapInfo.marqueeArray = marqueeArray.map(cur => JSCodeUtility.getStringValue(cur));

        if (info.round >= mapInfo.topPlayer.round) {
            info.isTop = true;
            // 如果之前當過第一名就不用演動畫
            if (this.oldSelfInfo[level] && !this.oldSelfInfo[level].isTop) {
                info.needToPlayCongratsAnimaiton = true;
            }
            // 表示舊地圖第一名玩家要拿掉
            var lastData = mapInfo.mapRouteList[mapInfo.mapRouteList.length - 1];
            if (lastData[0] && lastData[0].realRound && lastData[0].realRound === mapInfo.topPlayer.round)
                lastData[0] = {round: lastData[0].round};
            else if (lastData[1] && lastData[1].realRound && lastData[1].realRound === mapInfo.topPlayer.round)
                lastData[1] = {round: lastData[1].round};
        }

        // 看看地圖有沒有要擴張
        this.expendMap(level, info.round);

        GS.dispatchCustomEvent("NotifyCardKingMapPlayerInfoDone", level);
    },

    // 地圖上某節點的資料
    cmd_crown_king_map_detail: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value || "{}");

        // 什麼等級
        var level = JSCodeUtility.getStringValue(jsonValue["crown_level"]);

        // 幾局
        var round = JSCodeUtility.getStringValue(jsonValue["node"]);

        // 下面拿特定節點
        var levelObj = this.nodeDetail[level];

        if (!levelObj)
            levelObj = this.nodeDetail[level] = {};

        var detailObj = levelObj[round];

        if (!detailObj)
            detailObj = levelObj[round] = {};

        // 總共多少人
        detailObj.totalCount = JSCodeUtility.getIntValue(jsonValue["total"]);

        detailObj.playerList = (jsonValue["list"] || []).map(cur => {
            var ret = {};
            ret.nickName = JSCodeUtility.getStringValue(cur["name"]);
            ret.playerImgUrl = this.getPlayerImageURL(cur["pic"]);
            return ret;
        });

        GS.dispatchCustomEvent("NotifyCardKingMapNodeDetailDone");
    },
});

// 可能的狀態
CardKingData.Status = {
    NONE: -1,       //
    CLOSE: 0,       // 關閉
    OPEN: 1,        // 開放中
    CALCULATING: 2  // 結算中
};

// 地圖路線的顏色
CardKingData.MapRouteColorType = {
    BLUE: 1,        // 藍色
    GREEN: 2,       // 綠色
    PURPLE: 3,      // 紫色
    PEACH_PINK: 4,  // 桃紅
};