/**
 * 9T 幸運彩票 - 購買彩券Cell
 * Domino移植設定 印尼排版與中撲不同
 */

var BigLotteryPurchaseCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        var cellWidth = BigLotteryPurchaseCell.WIDTH - 10;
        var cellHeight = BigLotteryPurchaseCell.HEIGHT - 10;
        var midPosX = cellWidth / 2 + 15;    // 整體物件向右偏移讓chipsBox可以完整顯示
        var midPosY = cellHeight / 2;

        // 預設開啟
        this.setCascadeColorEnabled(true);
        this.setCascadeOpacityEnabled(true);
        this.ignoreAnchorPointForPosition(true);

        // 背景
        var bgSprite = new ccui.Scale9Sprite("lobby_btn_09.png");
        bgSprite.setPreferredSize(cc.size(cellWidth, cellHeight));
        bgSprite.setPosition(midPosX, midPosY);
        this.addChild(bgSprite);

        // 內容
        var contentLabel = this._contentLabel = new cc.LabelTTF("", JSFontName, 11, cc.size(94, 30), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        contentLabel.enableStroke(cc.color(90, 70, 0, 255), 2);
        contentLabel.setFontFillColor(JSColor.YELLOW);
        contentLabel.setPosition(midPosX + 36, midPosY + 12);
        this.addChild(contentLabel);

        // 儲值按鈕
        var purchaseBtn = this._purchaseBtn = ButtonUtility.createSimpleButton("lobby_btn_03.png", cc.size(86, 22), " ");
        purchaseBtn.label.enableStroke(cc.color(0, 35, 90, 255), 2);
        purchaseBtn.setPosition(midPosX + 36, midPosY - 16);
        purchaseBtn.addTouchUpInsideAction(this.purchaseBtnClicked, this);
        this.addChild(purchaseBtn);

        // 熱銷
        {
            // 裝熱銷東西的node
            var hotTagNode = this._hotTagNode = new cc.Node();
            hotTagNode.setVisible(false);
            hotTagNode.setCascadeOpacityEnabled(true);
            this.addChild(hotTagNode);

            // 金框
            var goldFrameSprite = new ccui.Scale9Sprite("lobby_recommend.png");
            goldFrameSprite.setPreferredSize(cc.size(cellWidth + 4, cellHeight + 4));
            goldFrameSprite.setPosition(midPosX, midPosY);
            hotTagNode.addChild(goldFrameSprite);

            // 標籤
            var hotTagSprite = new cc.Sprite("#lobby_pic_hot.png");
            hotTagSprite.setPosition(midPosX - 32, midPosY + 28);
            hotTagNode.addChild(hotTagSprite);
        }

        // 德撲幣或寶箱圖
        var chipSprite = this._chipSprite = new cc.Sprite("#bigLottery_pic_chips.png");
        chipSprite.setPosition(midPosX - 53, midPosY);
        this.addChild(chipSprite);
    },

    // 更新cell
    refreshCell: function (idx, param) {
        // 記下資料
        this._param = param;

        // 刷新內文
        this._contentLabel.setString(param.content);

        // 刷新德撲幣圖
        if (idx === 0) {
            // 籌碼箱圖
            this._chipSprite.setSpriteFrame(JSStringUtility.format("bigLottery_pic_chipsBox.png"));
        }

        // 刷新儲值按鈕文字
        this._purchaseBtn.label.setString(JSStringUtility.format("%s %s", TexasUtility.CURRENCY_STRING, param.price));

        // 刷新熱銷
        this._hotTagNode.setVisible(param.isHot);
    },

    /**
     * 按鈕相關
     */
    // 按下按鈕
    purchaseBtnClicked: function () {
        var param = this._param;                                // 整個按鈕的資訊
        var providerParam = param.providerParam;                // 第三方儲值視窗需要的資訊
        var productIDList = providerParam.productIDList;

        MusicUtility.playEffect("Music/Effect/e_clickButton.mp3", false);

        if (productIDList) {
            if (productIDList.length === 1) {
                // 只有一個 送儲值
                DataModal.purchaseData.sendPurchase(productIDList[0]);
                // 埋點
                DataProcess.sendString(JSStringUtility.format("big_lottery_purchase %s", productIDList[0]));
            } else if (productIDList.length > 1) {
                // 一個以上開選擇dialog
                // 有第三方儲值時要到視窗後選擇方案才送big_lottery_purchase
                providerParam.callBackFunc = function (btnNum) {
                    // 埋點
                    DataProcess.sendString(JSStringUtility.format("big_lottery_purchase %s", productIDList[btnNum]));
                };

                DialogManager.addDialog(new ProviderChooseDialog(providerParam), false);
            }

            // 存會獲得多少彩券
            DataModal.bigLotteryData.purchaseTicketNum = param.productList[0].ticketNum;
        }
    },

    // 點到他 高亮
    setIsHighlight: function (isSelect) {
        this.setOpacity(isSelect ? 150 : 255);
    }
});

// Cell寬高 有圖片會超出cell影響顯示 所以cell寬高比實際物體大
BigLotteryPurchaseCell.WIDTH = 180;
BigLotteryPurchaseCell.HEIGHT = 78;