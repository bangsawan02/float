/**
 * 通行證 - 購買 pass dialog
 * ```
 * config: {
 *     messageDialogBgFileName: "",             // dialog 背景圖
 *     messageDialogSize: cc.size(246, 153),    // dialog size
 *     messageDialogFontColor: JSColor.WHITE,   // dialog 文字顏色
 *     ticketIconFileName: "",                  // 豪華票券圖檔
 * }
 * ```
 */
var BasePassBuyPassDialog = BasePassCommonDialog.extend({
    ctor: function (config, param) {
        config.messageDialogSize = config.messageDialogSize || cc.size(246, 153);
        param.isShowCloseButton = true;
        this._super(config, param);

        this.key = "BasePassBuyPassDialog";
    },

    /**
     * 建立標題（買 pass 無標題）
     * @protected
     */
    _createTitleView: function () { },

    /**
     * 建立內容畫面
     * 你可以自行繼承以建立自己的內容畫面
     * @protected
     */
    _createContentView: function () {
        let isCycleReward = this.param.isCycleReward;
        let fontColor = this.config.messageDialogFontColor || JSColor.WHITE;
        let ticketIconFileName = this.config.ticketIconFileName || "luxyPass_pic_ticket_01.png";

        /**
         * 印尼的內文：開始
         */
        let textParam = [
            [   // 第一行
                {
                    type: BasePassRichTextNode.Type.TEXT,
                    text: LocalizedString.BasePass(isCycleReward ? "獲得（循環獎勵）" : "需先"),
                    fontColor: fontColor
                },
                {
                    type: BasePassRichTextNode.Type.SPRITE,
                    fileName: "#" + ticketIconFileName,
                    scale: 0.6
                },
                {
                    type: BasePassRichTextNode.Type.TEXT,
                    text: LocalizedString.BasePass(isCycleReward ? "解鎖" : "獲得"),
                    fontColor: fontColor
                }
            ],
            [   // 第二行
                {
                    type: BasePassRichTextNode.Type.TEXT,
                    text: (isCycleReward ? "Bonus Bank! " : "") + LocalizedString.BasePass(isCycleReward ? "獎勵次數無上限!" : "解鎖喔"),
                    fontColor: fontColor
                }
            ]
        ];
        /**
         * 印尼的內文：結束
         */

        let richTextNode = new BasePassRichTextNode(textParam);
        richTextNode.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 24);
        this._animationLayer.addChild(richTextNode);
    },

    /**
     * 建立購買按鈕
     * 你可以自行繼承以建立自己的購買按鈕
     * @protected
     */
    _createButtonGroup: function () {
        let purchaseParam = this.param.purchaseParam;
        let purchaseButton = this.purchaseButton = new BasePassPurchaseButton({
            ticketIconFileName: this.config.ticketIconFileName,
            isUseOldBtnStyle: this.config.isUseOldBtnStyle,
            purchaseBtnIsShowTicketIcon: true,
            purchaseBtnIsShowDiscount: true,
            purchaseBtnStyle: this.config.purchaseBtnStyle,
            purchaseBtnOnClick: this._purchaseClicked.bind(this)
        });
        purchaseButton.refreshView(purchaseParam);
        purchaseButton.setPosition(JSScreenMidPos.x, 109 + JSScreenBonusHalfHeight);
        this._animationLayer.addChild(purchaseButton);
    },

    _purchaseClicked: function (sender) {
        this.param.purchaseBtnOnClick && this.param.purchaseBtnOnClick(sender);
        // 送儲值
        DataModal.purchaseData.goPurchase(sender.productParam);

        this._closeDialogAnimation();
    },
});

BasePassBuyPassDialog.Type = GSEnumHelper({
    DEFAULT: -1,
    CYCLE_REWARD: -1,
});