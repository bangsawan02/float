/**
 * 9T 幸運彩票 - 前期結果內 小畫面的base
 * Domino移植設定 客製介面
 */

var BigLotteryHistoryBaseLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 主頁面的node
        var mainNode = this._mainNode = new cc.Node();
        this.addChild(mainNode);

        // 按鈕
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        mainNode.addChild(menu);

        // 紅色透明背景
        var redBgSprite = new cc.Sprite("#bigLottery_bg_light.png");
        redBgSprite.setScale(11, 5);
        redBgSprite.setPosition(JSScreenMidPos.x, 114 + JSScreenBonusHalfHeight);
        mainNode.addChild(redBgSprite);

        // 側邊光
        var sideSprite = this._sideSprite = new cc.Sprite("#bigLottery_bg_halfLight.png");
        sideSprite.setScale(3, 2);
        sideSprite.setAnchorPoint(0, 0.5);
        sideSprite.setPosition(94 + JSScreenBonusHalfWidth, 114 + JSScreenBonusHalfHeight);
        mainNode.addChild(sideSprite);

        // 返回按鈕
        var images = ["lobby_btn_07.png", "lobby_btn_07.png", "lobby_btn_07.png"];
        var itemNode = ButtonUtility.createArrayScale9NodesWithIcon(images, cc.size(20, 20), "#lobby_btn_back.png", 0.7);
        var backBtn = new cc.MenuItemSprite(itemNode[0], itemNode[1], itemNode[2], this._backClicked, this);
        backBtn.setPosition(12 + JSScreenSafeWidth, JSVisibleSize.height - 71);
        menu.addChild(backBtn);
    },

    onEnter: function () {
        this._super();

        PushScene.addBackKeyEnableLayer(this);
    },

    onExit: function () {
        PushScene.removeBackKeyEnableLayer(this);

        this._super();
    },

    /**
     * Override掉 假如有BackKey一起關掉
     */
    setVisible: function (isVisible) {
        this._super(isVisible);

        if (isVisible)
            PushScene.addBackKeyEnableLayer(this);
        else
            PushScene.removeBackKeyEnableLayer(this);
    },

    /**
     * 按鈕
     */

    // an返回
    keyBackPressed: function () {
        this._backClicked();
    },

    // 點擊返回按鈕
    _backClicked: function () {
        MusicUtility.playEffect("Music/Effect/e_clickButton.mp3", false);

        // 通知主畫面點擊了按鈕
        var param = {
            isShow: false
        };
        GS.dispatchCustomEvent("NotifyBigLotteryHistoryShowPage", param);
    }
});