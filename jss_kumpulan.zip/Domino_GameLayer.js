var Domino_GameLayer = cc.Layer.extend({
    Z_TAG_PROFILE_LAYER: 198300001,

    ctor: function () {
        this._super();

        this._isPlaying = false;                        // 是否正在玩
        this._enableProcessMessage = true;              // 是否可以執行cmd
        this._isStandUp = false;                        // 是否站立
        this._isFirstSitDown = false;                   // 第一次坐下
        this._isFirstComeToTheDestop = true;            // 第一次到新的桌子
        this._isReplaceingRoom = false;                 // 是否正在換房間(給stand & updateSeat用)
        this._isReplacedRoom = false;                   // 是否正在換房間(給toGame 顯示訊息用)
        this._isReplaceRoomByClickedUIButton = false;   // 是否是利用按下左上UI換房間(另一種是太久沒動作換房間)
        this._totalPool = 1;                            // 代表分池有幾池
        this._showNeedPayDialog = false;                // 是否有出現破產的Dialog 這樣收到stand就不處理
        this._playingPlayers = [];                      // 遊戲現在有哪些活人需要發牌給他的
        this._backgroundListener = null;                // 到背景的監聽
        this._playCardNumber = 0;                       // 手牌是幾張牌
        this._playTime = new Date().getTime();          // Firebase 埋點, 記錄遊戲時間

        this._cleanGameLayerData(true);

        // 背景(含網速、Dealer)
        this._bgLayer = new Domino_BackgroundLayer();
        this.addChild(this._bgLayer, -10000);

        // Domino_SpotLightLayer
        this._spotLightLayer = new Domino_SpotLightLayer();
        this.addChild(this._spotLightLayer);

        // 玩家們
        this._playersLayer = new Domino_PlayersLayer();
        this.addChild(this._playersLayer);

        // 坐下
        this._sitsLayer = new Domino_SitsLayer();
        this.addChild(this._sitsLayer);

        // 邀請玩家按鈕Layer
        this._sitsInviteLayer = new SitInviteNodesLayer();
        this.addChild(this._sitsInviteLayer, -1);

        // 荷官(含小費按鈕)
        this._dealerLayer = new Domino_DealerLayer();
        this.addChild(this._dealerLayer);

        // 牌的畫面
        this._dealCardLayer = new Domino_DealCardLayer();
        this.addChild(this._dealCardLayer);

        // 互動表情選擇人物畫面
        this._actMoodAimLayer = new ActMoodAimLayer();
        this.addChild(this._actMoodAimLayer);

        // 遊戲積分
        this._gameRankLayer = new GameRankGameLayer();
        this.addChild(this._gameRankLayer);

        // 新增聚寶盆icon (5.4.2 跳提示泡泡框 要比玩家層級高)
        var treasureBowlIcon = new TreasureBowlGameIconNode();
        treasureBowlIcon.setScale(0.8);
        treasureBowlIcon.setPosition(JSVisibleSize.width - 25 - JSScreenSafeWidth, JSVisibleSize.height - 59);
        this.addChild(treasureBowlIcon);

        // 互動表情動畫
        this._actMoodAnimationLayer = new ActMoodAnimationLayer();
        this.addChild(this._actMoodAnimationLayer);

        // 遊戲介面
        this._uiLayer = new Domino_UILayer();
        this.addChild(this._uiLayer);

        // 對話的泡泡匡
        var gameChatMessageLayer = new GameChatMessageLayer();
        this.addChild(gameChatMessageLayer);

        // 玩家決策
        var confirmCardLayer = this._confirmCardLayer = new Domino_ConfirmCardLayer();
        confirmCardLayer.setVisible(false);
        this.addChild(confirmCardLayer);

        // 左上選單
        this._optionUILayer = new Domino_UIOptionLayer();
        this.addChild(this._optionUILayer);

        // 遊戲中的上方提示
        this._gameHintLayer = new Domino_GameHintLayer();
        this.addChild(this._gameHintLayer);

        // 牌型提醒
        this._cardRankNode = new Domino_UICardRankNode();
        this.addChild(this._cardRankNode);

        // 大牌動畫
        this._bigCardAnimationLayer = new Domino_BigCardAnimationLayer();
        this.addChild(this._bigCardAnimationLayer);

        // 介面新手教學
        this._uiTeachNode = new Domino_UITeachNode();
        this.addChild(this._uiTeachNode);

        // 聊天選單
        this._gameChatLayer = new GameChatLayer();
        this.addChild(this._gameChatLayer);

        // 比賽推廣提示
        var tournamentPromoteNode = this._tournamentPromoteNode = new TournamentPromoteGameNode();
        this.addChild(tournamentPromoteNode, 10);

        // 紀錄該玩家是不是當日第一手
        var isFirstPlayToday = false;
        var dt = new Date();
        var today = JSStringUtility.format("%d%d", dt.getMonth() + 1, dt.getDate());
        var date = GS.localStorage.getItem(JSStringUtility.format("%s_loginDate", DataModal.profileData.account), "0");
        if (date != today) {
            isFirstPlayToday = true;
            GS.localStorage.setItem(JSStringUtility.format("%s_loginDate", DataModal.profileData.account), today);
        }

        // 聊天浮動按鈕(icon在哪個畫面上)
        var friendChatNode = new ChatRoomIconLayer(ChatRoomIconLayer.POS_TYPE.DOMINO);
        this.addChild(friendChatNode, 100);

        //註冊通知
        GS.addListener("NotifyGameProcessCMD", this.notifyGameProcessCMD.bind(this), this);
        GS.addListener("NotifyEnableProcessMessage", this.notifyEnableProcessMessage.bind(this), this);
        GS.addListener("NotifyGameUISitDownClicked", this.notifyGameUISitDownClicked.bind(this), this);
        GS.addListener("NotifyGameUIChangePlaceClicked", this.notifyGameUIChangePlaceClicked.bind(this), this);
        GS.addListener("NotifyGameUIBackToLobbyClicked", this.notifyGameUIBackToLobbyClicked.bind(this), this);
        GS.addListener("NotifyGameSendTips", this.notifyGameSendTips.bind(this), this);
        GS.addListener("NotifyStartGame", this.notifyStartGame.bind(this), this);
    },

    onEnter: function () {
        this._super();

        DataProcess.sendString("get_camp_mood_list");           // 抓special表情
        DataProcess.sendString("act_moods_backpack");           // 抓互動道具
        DataProcess.sendString("store_mood_backpack");          // 抓商城表情

        // 每日任務
        DataModal.dailyMissionData.startGetInfo(DailyMissionEnum.whereType.Game, GSEnum.Game.Domino);

        if (this._isFirstComeToTheDestop) {
            this._processAllCommand();
        }
    },

    onExit: function () {
        // Firebase 埋點, 記錄遊戲時間
        GameFirebaseTracker.trackPlayingTime(this._playTime);

        this._backgroundListener && cc.eventManager.removeListener(this._backgroundListener);

        this._super();
    },

    /**
     * 跑所有指令
     */
    _processAllCommand: function () {
        var action1 = cc.delayTime(0.1);
        var action2 = cc.callFunc(function () {
            while (this.processMessage() && this._enableProcessMessage) {
            }
        }, this);
        this.runAction(cc.sequence(action1, action2));
    },

    /**
     * 更新玩一手的Tracking
     */
    _updatePlayTimesTracking: function () {
        // 先判斷是否在遊戲內遊玩
        if (this._playingPlayers.indexOf(DataModal.gameData.myPos) > -1) {
            GameAppsFlyerTracker.trackPlayingTimes();
        }
    },

    /**
     * 清除GameLayer的資訊
     * @param isOnload 是否為初始資料階段
     * @private
     */
    _cleanGameLayerData: function (isOnload) {
        //清掉其他畫面
        if (!isOnload) {
            this._spotLightLayer.cleanData();
            this._bgLayer.cleanData();
            this._sitsInviteLayer.cleanData();
        }

        this._showNeedPayDialog = false;                // 是否有出現破產的Dialog 這樣收到stand就不處理
    },

    /**
     * 檢查需要跳哪種沒錢的Dialog
     * @param canGoToSmallDesktop 是否能進小桌 QQ沒有
     */
    _checkBrokePaymentDialog: function (canGoToSmallDesktop) {
        NoMoneyDialogHelper.showGameDialog(false);
    },

    /**
     * 處理
     */
    //處理GameData Message
    processMessage: function () {
        var haveMessage = false;
        var newMessageCommand = DataModal.gameData.popQueuedMessage();

        if (newMessageCommand) {
            haveMessage = true;

            var socketKey = newMessageCommand.key;
            var socketValue = newMessageCommand.value;

            //cc.log("processMessage:" + newMessageCommand.key);
            switch (socketKey) {
                case "OLEH":
                    // 重置外觀
                    this._playersLayer.cmd_OLEH();
                    this._uiLayer.cmd_OLEH();
                    this._bgLayer.cmd_OLEH();
                    this._dealerLayer.cmd_OLEH();
                    this._confirmCardLayer.cleanData();

                    // 重置分池
                    this._totalPool = 1;
                    break;

                case "myPos":
                    this._cmd_myPos();
                    break;

                case "dealer":
                    // 決定現在誰是dealer
                    this._bgLayer.cmd_dealer(parseInt(newMessageCommand.value));
                    break;

                case "roomparam":
                    // 處理進入房間的資訊
                    if (this._isReplacedRoom) {
                        this._isReplacedRoom = false;
                        DialogManager.closeDialogByKey("ReplaceRoomDialog");
                        DialogManager.closeDialogByKey("InviteFriendListDialog");

                        //Reset
                        this._cleanGameLayerData(false);
                        this._optionUILayer.tmpStopReplaceRoom();
                        this._playersLayer.setIsFirstSitDown(true);
                    }

                    // 更新背景的名稱
                    this._bgLayer.cmd_roomparam();

                    break;

                case "updateSeat":
                    this._enableProcessMessage = false;
                    this._cmd_updateSeat();
                    break;

                case "last_cmd":
                    this._playersLayer.cmd_last_cmd();
                    break;

                case "current_playing":
                    // 牌局重現
                    var array = newMessageCommand.value.split(" ");
                    if (array[0] == "1") {
                        var jsonValue = JSON.parse(array[1]);
                        // 設定dealer
                        this._bgLayer.cmd_dealer(jsonValue.dealer);

                        // 設定丟出去的錢
                        this._playersLayer.cmd_current_playing(jsonValue);

                        // 設定現在有誰在玩
                        this._playingPlayers = jsonValue.playing;

                        this._isPlaying = true;
                    } else {
                        this._isPlaying = false;
                    }
                    break;

                case "updateChips":
                    this._dealerLayer.cmd_updateChips();
                    this._playersLayer.cmd_updateChips();
                    break;

                case "updateInfo":
                    // 更新配件資訊
                    this._playersLayer.cmd_updateInfo(newMessageCommand.value);
                    break;

                case "stand":
                    var serverSitNum = parseInt(newMessageCommand.value);
                    this._playersLayer.cmd_stand(serverSitNum);

                    // 已經跳破產提醒 就不要顯示其他Dialog
                    if (this._showNeedPayDialog)
                        break;

                    var haveMe = DataModal.gameData.haveMe;

                    // 等太久被要求換桌(自已stand + 非按自已站起 + 非自已換桌)
                    if (serverSitNum == DataModal.gameData.myPos) {
                        if (!this._optionUILayer.getIsClickStandUpButton() && !this._isReplaceRoomByClickedUIButton) {
                            if (!DialogManager.isExist("GameWaitToLong")) {
                                // 比賽時被server強制站起會直接顯示賽況，而不需要提醒使用者太久沒動作
                                var dialog = new AvatarDialog(DialogHelper("GameWaitToLong"));
                                DialogManager.addDialog(dialog);
                            }
                        }

                        // 是自己站起來 再做關閉flag的動作
                        this._optionUILayer.setIsClickStandUpButton(false);
                        this._isReplaceRoomByClickedUIButton = false;
                    }

                    // 其它stand要做的事
                    if (haveMe) {
                        this._sitsLayer.setAllSitsVisible(false);
                    } else {
                        this._isStandUp = true;
                        if (this._isReplaceingRoom) {
                            this._sitsLayer.setAllSitsVisible(false);
                        } else {
                            this._sitsLayer.updateSeat();
                        }
                        this._dealerLayer.setStand();

                        // 起立後關掉站起觀戰按鈕
                        this._optionUILayer.setStandUpButtonEnabled(false);

                        // 把UILayer的決策清掉
                        this._uiLayer.setMenuStatus(DOMINO_UILAYER_STATUS.EMPTY);

                        // 刮刮卡暫停
                        DataModal.scratchCardData.stopCountDown();
                    }

                    this._sitsInviteLayer.setAllSitsVisible(haveMe);

                    break;

                case "playerSit":
                    var valueArray = newMessageCommand.value.split(" ");
                    if (valueArray.length >= 3) {
                        if (DataModal.profileData.account == valueArray[1]) {
                            this._isStandUp = false;
                            this._optionUILayer.tmpStopReplaceRoom();
                            this._uiLayer.setMenuStatus(DOMINO_UILAYER_STATUS.WAIT_NEXT_GAME2);
                        }
                    }
                    break;

                case "showPlayerClass":
                    // 積分系統 入桌階級顯示
                    //   {
                    //        "pos":"5",   #位置
                    //        "dealerSay":"Selamat datang Aries Mo para pemain hebat di meja profesional", #荷官恭迎
                    //        "userClass":{"score":"0","class":"0","ranking":"1"} #此玩家階級資料
                    //   }
                    var jsonValue = JSON.parse(newMessageCommand.value);
                    var serverPos = JSCodeUtility.getIntValue(jsonValue["pos"]);
                    var isMe = DataModal.gameData.myPos === serverPos;

                    var classValue = jsonValue["userClass"];
                    if (classValue) {
                        // 如果是自己的話更新左下角積分系統
                        if (isMe && classValue["showProtecIcon"]) {
                            var userClass = {
                                isShowProtectIcon: JSCodeUtility.getIntValue(classValue["showProtecIcon"])
                            };
                            this._gameRankLayer.cmd_showPlayerClass(userClass);
                        }

                        if (classValue["class"]) {
                            // 給PlayersLayer做進來的動畫
                            this._playersLayer.cmd_showPlayerClass(jsonValue);

                            // 荷官說話的訊息
                            var dealerMessage = JSCodeUtility.getStringValue(jsonValue["dealerSay"]);
                            if (dealerMessage) {
                                this._dealerLayer.dealerMsg(dealerMessage);
                            }
                        }
                    }

                    break;

                case "gameRank_protect_info":
                    // 用來跳桌內上方的保護令提示
                    this._gameHintLayer.cmd_gameRank_protect_info(socketValue);
                    break;

                case "gameRank_protect_remain":
                    // 更新個人的階級
                    this._gameRankLayer.cmd_gameRank_protect_remain(socketValue);
                    break;

                case "gameRank_update":
                    // 積分系統 自己的分數變動
                    this._gameRankLayer && this._gameRankLayer.cmd_gameRank_update(newMessageCommand.value);
                    break;

                case "gameRank_class":
                    // 拿個人積分資訊 要更新左下角Icon
                    var jsonValue = JSON.parse(newMessageCommand.value);
                    var param = {
                        class: JSCodeUtility.getIntValue(jsonValue["class"]),
                        score: JSCodeUtility.getIntValue(jsonValue["score"]),
                        nextScore: JSCodeUtility.getIntValue(jsonValue["nextClassScore"]),
                        ranking: JSCodeUtility.getIntValue(jsonValue["ranking"])
                    };

                    this._gameRankLayer.cmd_gameRank_class(param);

                    break;

                case "gameRank_booster_info":
                    // 積分系統 加速器的狀態
                    this._gameRankLayer && this._gameRankLayer.cmd_gameRank_booster_info(newMessageCommand.value);
                    break;

                case "koin_luxy_room_status":
                    // koinluxy更動
                    this._uiLayer.cmd_koin_luxy_room_status(newMessageCommand.value);
                    break;

                case "ante":
                    // 下底注
                    this._playersLayer.cmd_ante(newMessageCommand.value);

                    this._isPlaying = (DataModal.gameData.myPos != -1);

                    // 把有下注記下來
                    DataModal.gameData.isMeBet = true;

                    // 撥放開始語音
                    MusicUtility.playVoice("gameStart.mp3");

                    break;

                case "playing":
                    // 把現在遊戲中哪些活人記下來
                    this._playingPlayers = JSON.parse(newMessageCommand.value);
                    break;

                case "FirstParam":
                case "FirstParam3":
                    // 先判斷是發幾張
                    var cardsCount = this._playCardNumber = (newMessageCommand.key === "FirstParam3" ? 3 : 2);

                    // 拿到 兩張 or 三張 手牌 要從dealer開始發牌
                    var valueArray = newMessageCommand.value.split(" ");

                    var dealerPos = this._bgLayer.getDealerPosition();
                    var playingLen = this._playingPlayers.length;
                    // 先找出dealer的Index
                    var dealerIndex = this._playingPlayers.indexOf(dealerPos);
                    dealerIndex = (dealerIndex < 0 ? 0 : dealerIndex);

                    var self = this;
                    var callback = function (serverPos, cardNumberString) {
                        self._playersLayer.addHandCard(serverPos, cardNumberString);
                    };
                    for (var i = 0; i < cardsCount; i++) {
                        var cardNumber = valueArray[i] ? valueArray[i] : "0";
                        for (var p = 0; p < playingLen; p++) {
                            var nowPos = this._playingPlayers[(p + dealerIndex) % playingLen];
                            var playerData = DataModal.gameData.playerDataArray[nowPos];
                            if (playerData && playerData.getIsExist())
                                this._dealCardLayer.dealCardToPlayer(nowPos, cardNumber, callback);
                        }
                    }

                    // 判斷是否要把手上的狀態更改掉
                    if (this._playingPlayers.indexOf(DataModal.gameData.myPos) > -1) {
                        // 先判斷現在手上有幾張牌 低於4張牌在處理
                        var nowHandCardCount = this._playersLayer.getSelfHandCardCount();
                        if (nowHandCardCount < 4) {
                            // 把Menu設定現在在幹麻 假如已經Allin過 不顯示
                            var myData = DataModal.gameData.getMyPlayerData();
                            if (myData && myData.tableChips > 0)
                                this._uiLayer.setMenuStatus(DOMINO_UILAYER_STATUS.NO_RAISE);
                        }
                    }

                    // 清掉上一回合的籌碼記錄
                    this._playersLayer.cleanPlayerPotChips();

                    // 關閉比賽推廣
                    this._tournamentPromoteNode.closeGapleKOPromoteHint();

                    // 關掉抓Socket
                    this._enableProcessMessage = false;

                    // 介面新手教學：當玩家進行第三、四手時跳出
                    this._uiTeachNode.show(newMessageCommand.key);

                    //AppsFlyer
                    if (GameAppsFlyerTracker.isNeedTrackFirstClick()) {
                        GameAppsFlyerTracker.startTime = new Date().getTime();
                    }

                    break;

                case "ThirdParam":
                case "ForthParam":
                    // 拿到第三張 or 第四張手牌 要從dealer開始發牌
                    var cardNumberString = newMessageCommand.value;

                    var dealerPos = this._bgLayer.getDealerPosition();
                    var playingLen = this._playingPlayers.length;
                    // 先找出dealer的Index
                    var dealerIndex = this._playingPlayers.indexOf(dealerPos);
                    dealerIndex = (dealerIndex < 0 ? 0 : dealerIndex);

                    var self = this;
                    var callback = function (serverPos, cardNumberString) {
                        self._playersLayer.addHandCard(serverPos, cardNumberString);
                    };
                    for (var p = 0; p < playingLen; p++) {
                        var nowPos = this._playingPlayers[(p + dealerIndex) % playingLen];
                        var playerData = DataModal.gameData.playerDataArray[nowPos];
                        if (playerData.getIsExist())
                            this._dealCardLayer.dealCardToPlayer(nowPos, cardNumberString, callback);
                    }

                    // 判斷是否要把手上的狀態更改掉
                    if (this._playingPlayers.indexOf(DataModal.gameData.myPos) > -1) {
                        // 先判斷現在手上有幾張牌 低於4張牌在處理
                        var nowHandCardCount = this._playersLayer.getSelfHandCardCount();
                        if (nowHandCardCount < 4) {
                            // 把Menu設定現在在幹麻 假如已經Allin過 不顯示
                            var myData = DataModal.gameData.getMyPlayerData();
                            if (myData.tableChips > 0)
                                this._uiLayer.setMenuStatus(DOMINO_UILAYER_STATUS.NO_RAISE);

                            // 介面新手教學：當玩家進行第二手發第三張牌時跳出
                            this._uiTeachNode.show(newMessageCommand.key);
                        }
                    }

                    // 清掉上一回合的籌碼記錄
                    this._playersLayer.cleanPlayerPotChips();

                    // 關掉抓Socket
                    this._enableProcessMessage = false;

                    break;

                case "BestCard":
                    // Server幫運算的最佳手牌 要強制幫他換掉
                    this._playersLayer.cmd_BestCard(newMessageCommand.value);
                    break;

                case "play":
                    this._cmd_play(newMessageCommand.value);
                    break;

                case "raiseList":
                    // 加注的設定
                    this._uiLayer.cmd_raiseList(newMessageCommand.value);
                    break;

                case "pot":
                    // 要先set Pot, 才可以把錢丟給荷官(荷官身上的錢才不會錯)
                    this._playersLayer.cmd_pot(newMessageCommand.value);
                    this._spotLightLayer.stop();
                    break;

                case "call":
                    //玩家本人跟牌
                    this._uiLayer.cmd_call(newMessageCommand.value);
                    break;

                case "fold":
                    //玩家本人棄牌
                    var value = JSCodeUtility.getIntValue(newMessageCommand.value);
                    if (value === 0) {
                        this._uiLayer.cmd_fold(newMessageCommand.value);
                        this._dealerLayer.setFold();
                    }
                    break;

                case "check":
                    //玩家本人過牌
                    this._uiLayer.cmd_check(newMessageCommand.value);
                    break;

                case "raise":
                    // 玩家本人加注，也不是All In
                    this._uiLayer.cmd_raise(newMessageCommand.value);
                    break;

                case "plcall":
                    // 玩家跟注
                    this._playersLayer.cmd_plcall_plraise(newMessageCommand.key, newMessageCommand.value);

                    break;

                case "plraise":
                    // 玩家加注
                    this._playersLayer.cmd_plcall_plraise(newMessageCommand.key, newMessageCommand.value);
                    this._uiLayer.cmd_plraise();
                    this._dealerLayer.cmd_plraise(newMessageCommand.value);

                    break;

                case "plfold":
                    // 玩家棄牌
                    this._playersLayer.cmd_plfold(newMessageCommand.value);

                    MusicUtility.playVoice("fold.mp3");

                    break;

                case "plcheck":
                    // 玩加過牌
                    this._playersLayer.cmd_plcheck(newMessageCommand.value);

                    MusicUtility.playEffect("Music/Effect/check.mp3");
                    MusicUtility.playVoice("check.mp3");

                    break;

                case "waiting_confirm":
                    // 開啟等待決策的畫面 要判斷是否有自己在裡面玩
                    var haveMe = this._playingPlayers.indexOf(DataModal.gameData.myPos) > -1;
                    if (haveMe) {
                        this._confirmCardLayer.startConfirm(parseInt(newMessageCommand.value));

                        // 有出現 把Dialog關掉先
                        DialogManager.cleanAllDialog();
                    }

                    // 把下方UI設空
                    this._uiLayer.setMenuStatus(DOMINO_UILAYER_STATUS.EMPTY);

                    // 把玩家顯示正在確認牌型
                    var self = this;
                    this._playingPlayers.forEach(function (cur) {
                        self._playersLayer.setPlayerConfirmStatus(cur, DOMINO_PLAYER_CONFIRM_STATUS.WAITING);
                    });

                    break;

                case "confirmed":
                    // 玩家確認牌型
                    this._playersLayer.setPlayerConfirmStatus(parseInt(newMessageCommand.value), DOMINO_PLAYER_CONFIRM_STATUS.DONE);
                    break;

                case "finish1":
                    // 結算 每個人的牌型 finish1 [["12","33","36","00"],"","","","",["44","01","46","11"],""]
                    this._isPlaying = false;
                    this._playersLayer.cmd_finish1(newMessageCommand.value);

                    // 把狀態清掉
                    this._uiLayer.setMenuStatus(DOMINO_UILAYER_STATUS.EMPTY);

                    // 清掉確認牌型畫面
                    this._confirmCardLayer.cleanData();

                    // 把資料給大牌動畫記下來
                    this._bigCardAnimationLayer.cmd_finish1(newMessageCommand.value);


                    // 更新聚寶盆 透過網址
                    var myPos = DataModal.gameData.myPos;
                    // 有在玩
                    if (this._playingPlayers.indexOf(myPos) > -1) {
                        // 有下注
                        if (DataModal.gameData.playerDataArray[myPos].tableChips)
                            DataModal.treasureBowlData.treasureBowlParam && DataModal.treasureBowlData.updateDataBy(1, false);

                        // 跳新玩家牌桌內功能提示
                        DataModal.newbieData.showGameTableFunctionHint();
                    }

                    // Firebase 追蹤
                    var eventName = GSAnalyticsAdapter.record.game + "QiuQiu牌桌玩法";
                    var eventKey = "桌列表";
                    var eventValue = undefined;
                    var gameData = DataModal.gameData;
                    if (this._playCardNumber === 2) {
                        if (gameData.smallBlind <= 400000)
                            eventValue = "QiuQiu2張低底台局數";
                        else
                            eventValue = "QiuQiu2張高底台局數";
                    } else {
                        if (gameData.smallBlind <= 400000)
                            eventValue = "QiuQiu3張低底台局數";
                        else if (gameData.smallBlind <= 2000000)
                            eventValue = "QiuQiu3張中底台局數";
                        else
                            eventValue = "QiuQiu3張高底台局數";
                    }

                    GSAnalyticsAdapter.logEventByFirebaseAll(eventName, [eventKey], [eventValue]);

                    break;

                case "winCards":
                    // 贏家牌型與位置 用來顯示大牌動畫用
                    // winCards {"pos":"0","ct":0}
                    this._bigCardAnimationLayer.cmd_winCards(newMessageCommand.value);

                    break;

                case "allPool":
                    // 告知有多少分池 用在showdown用
                    this._totalPool = parseInt(newMessageCommand.value) || 1;
                    break;

                case "showdown":
                    // 結算要分錢 有可能噴很多個回來
                    var jsonValue = JSON.parse(newMessageCommand.value);
                    this._dealerLayer.cmd_showdown(jsonValue);
                    this._playersLayer.cmd_showdown(jsonValue, this._totalPool);

                    if (this._totalPool === parseInt(jsonValue.poolIndex) + 1) {
                        // 假如抓完所有彩池了 要把socket先停
                        this._enableProcessMessage = false;
                    }

                    // 把狀態清掉
                    this._uiLayer.setMenuStatus(DOMINO_UILAYER_STATUS.EMPTY);

                    // Tracking
                    this._updatePlayTimesTracking();

                    break;

                case "noshowdown":
                    // 大家都棄牌 沒有結算直接分錢 noshowdown 5 740 0 19940
                    this._enableProcessMessage = false;

                    this._playersLayer.cmd_noshowdown(newMessageCommand.value);
                    this._dealerLayer.cmd_noshowdown(newMessageCommand.value);

                    // 把狀態清掉
                    this._uiLayer.setMenuStatus(DOMINO_UILAYER_STATUS.EMPTY);

                    // Tracking
                    this._updatePlayTimesTracking();

                    break;

                case "fianlMsg":
                    this._dealerLayer.cmd_fianlMsg(newMessageCommand.value);
                    break;

                case "update_getexp":
                    // 獲得多少EXP
                    this._playersLayer.cmd_update_getexp(newMessageCommand.value);
                    break;

                case "update_upgrade":
                    // 有沒有升級
                    this._playersLayer.cmd_update_upgrade(newMessageCommand.value);
                    break;

                case "update_gameRankUpdate":
                    // 積分更動
                    this._playersLayer.cmd_update_gameRankUpdate(newMessageCommand.value);
                    break;

                case "auto_bring_inFail":
                    // 輸光的時候如果自動攜入失敗
                    this._showNeedPayDialog = true;

                    // 檢查需要跳哪種沒錢的Dialog
                    this._checkBrokePaymentDialog();

                    // 把UILayer關掉
                    this._uiLayer.setMenuStatus(DOMINO_UILAYER_STATUS.EMPTY);

                    // 要送stand通知server
                    DataProcess.sendString("stand");
                    break;

                case "stopGame":
                    this._isPlaying = false;
                    this._playersLayer.cmd_stopGame();
                    this._uiLayer.setMenuStatus(DOMINO_UILAYER_STATUS.EMPTY);
                    this._spotLightLayer.stop();
                    this._bgLayer.cleanData();

                    // 刮刮卡暫停
                    DataModal.scratchCardData.stopCountDown();
                    break;

                case "need_chips":
                    // 假如已經跳破產 就不要跳攜入的畫面了
                    if (this._showNeedPayDialog)
                        break;

                    // 玩家沒錢了，之前有自動攜入就自動帶錢進來；否則要在問一次帶多少錢進來
                    var gameData = DataModal.gameData;
                    if (gameData.autoBringInMoney > 0 && DataModal.profileData.money > gameData.autoBringInMoney) {
                        DataProcess.sendString("bring_in " + gameData.autoBringInMoney);
                    } else {
                        var valueArray = newMessageCommand.value.split(" ");

                        // 沒有自動攜入或是身上的錢小於自動攜入金額，跳出攜入籌碼dialog
                        if (gameData.myPos != -1) {
                            var param = {
                                min: gameData.minBringIn,
                                max: gameData.maxBringIn,
                                money: DataModal.profileData.money,
                                bringInTime: JSCodeUtility.getIntValue(parseInt(valueArray[2])),
                                type: BringMoneyDialog.Type.NEED_CHIPS
                            };
                            var dialog = new BringMoneyDialog(param);
                            DialogManager.addDialog(dialog);
                        }
                    }
                    break;

                case "auto_bring_in_msg":
                    // 自動攜入的提醒文字
                    this._gameHintLayer.cmd_auto_bring_in_msg(newMessageCommand.value);
                    break;

                case "need_pay":
                    // need_pay pos 能不能進小桌
                    // 玩家破產了
                    // 這邊不用判段myPos了 因為GameData那邊判斷過了
                    this._showNeedPayDialog = true;

                    // 檢查需要跳哪種沒錢的Dialog
                    this._checkBrokePaymentDialog();

                    // 把UILayer關掉
                    this._uiLayer.setMenuStatus(DOMINO_UILAYER_STATUS.EMPTY);

                    // AppsFlyer 因破產而無法入桌或遭踢出牌局
                    GSAppsFlyerWrapper.logEvent("bankrupt_hint");

                    break;

                // 入座失敗
                case "sitFail":
                    var jsonValue = JSON.parse(newMessageCommand.value);
                    var gameString = LocalizedString.Game;
                    var dialogObj = {
                        title: gameString("貼心提醒"),
                        buttons: [gameString("返回大廳")],
                        callback: function (index) {
                            // 回大廳
                            GS.dispatchCustomEvent("NotifyGameUIBackToLobbyClicked");
                        }
                    };

                    var code = JSCodeUtility.getIntValue(jsonValue["code"]);
                    if (code === 1) {
                        // 吃Server給的參數
                        dialogObj.content = decodeURIComponent(JSCodeUtility.getStringValue(jsonValue["msg"]));
                        DialogManager.addDialog(new AvatarDialog(dialogObj));
                    } else {
                        // code = 0 or 舊格式(沒有code), 不吃server參數, 直接顯示訊息
                        DialogManager.addDialog(new AvatarDialog(DialogHelper("GameNoMoney_SitFail")));
                    }
                    break;

                // 玩家破產補幣
                case "broken_reward":
                    DialogManager.addDialog(new GameBrokenRewardDialog(newMessageCommand.value));
                    break;

                // 表情
                case "mood":
                case "amood":
                    this._playersLayer.cmd_mood(newMessageCommand.value);
                    break;
                case "vmood":
                    this._playersLayer.cmd_vmood(newMessageCommand.value);
                    break;

                case "store_mood":
                    this._playersLayer.cmd_store_mood(newMessageCommand.value);
                    break;

                // 互動表情
                case "act_moods":
                    this._actMoodAnimationLayer.cmd_act_moods(newMessageCommand.value);
                    break;

                // 送禮物
                case "gift_accessory":
                    this._playersLayer.cmd_gift_accessory(newMessageCommand.value);
                    break;

                // 送禮包
                case "gift_package":
                    var array = newMessageCommand.value.split(" ");
                    this._actMoodAnimationLayer.cmd_gift_package(array);
                    break;

                default:
                    this._enableProcessMessage = true;
                    this.processMessage();
                    break;
            }
        }
        return haveMessage;
    },

    /**
     * 處理自已的坐位
     * @private
     */
    _cmd_myPos: function () {
        if (DataModal.gameData.myPos == -1) {
            this._isStandUp = true;
            this._isFirstSitDown = false;
        } else {
            this._isStandUp = false;

            // 有在座位上 代表已經站起結束或換桌結束
            this._optionUILayer.setIsClickStandUpButton(false);
            this._isReplaceRoomByClickedUIButton = false;
        }
    },

    /**
     * 更新位置資訊
     * @private
     */
    _cmd_updateSeat: function () {
        // 拿掉第一次進來的LoadingView
        if (this._isFirstComeToTheDestop) {
            GSLoading.removeLoadingView();
            this._isFirstComeToTheDestop = false;
        }

        // 更新是否有坐下的畫面
        var haveMe = DataModal.gameData.haveMe;
        if (haveMe) {
            // 有我了 代表換完房間了
            this._isReplaceingRoom = false;

            this._sitsLayer.setAllSitsVisible(false);
        } else {
            if (this._isReplaceingRoom) {

                // 關掉sitsLayer
                this._sitsLayer.setAllSitsVisible(false);
            } else {
                this._sitsLayer.updateSeat();
            }
        }

        this._playersLayer.updateSeat(haveMe);
        this._sitsInviteLayer.update(haveMe);

        // 第一次坐下 / 站起後坐下才會設定桌面上每個人的狀態
        if (this._isFirstSitDown == false && DataModal.gameData.myPos != -1) {
            this._isFirstSitDown = true;

            this._playersLayer.processLastCmd();
            this._dealerLayer.setSit();
        }

        this._dealerLayer.cmd_updateSeat();

        // UI去判斷要不要顯示表情與對話按鈕
        this._uiLayer.cmd_updateSeat();

        // 給互動道具選擇畫面更新
        this._actMoodAimLayer.cmd_updateSeat();

        // 判斷是否站起 且滿人 是的話要出現提示
        var showHint = false;
        if (this._isStandUp) {
            var haveEmptySit = DataModal.gameData.playerDataArray.some(function (player) {
                // 假如有人不在 回傳true
                return !player.getIsExist();
            });
            if (!haveEmptySit)
                showHint = true;
        }
        this._gameHintLayer.setChangeTableHintVisible(showHint);
    },

    /**
     * 輪到誰
     * play pos is_self delay chips call nextRaise (is_self 為 0 則不會有 call 和 nextRaise)
     * @param {value} socket 傳過來的值
     * @private
     */
    _cmd_play: function (value) {
        var valueArray = value.split(" ");
        var len = valueArray.length;
        var serverSitNum = JSCodeUtility.getIntValue(valueArray[0]);
        var isMeFlag = JSCodeUtility.getIntValue(valueArray[1]);
        var delay = JSCodeUtility.getIntValue(valueArray[2]);
        var myBringMoney = JSCodeUtility.getIntValue(valueArray[3]);
        var callMoney = 0;
        var minRaiseMoney = 0;
        if (4 < len)
            callMoney = JSCodeUtility.getIntValue(valueArray[4]);
        if (5 < len)
            minRaiseMoney = JSCodeUtility.getIntValue(valueArray[5]);

        var param = {
            isMeFlag: isMeFlag,
            myBringMoney: myBringMoney,
            minRaiseMoney: minRaiseMoney,
            callMoney: callMoney
        };

        this._uiLayer.cmd_play(param);                              // 修改下面的介面、設定Raise
        this._spotLightLayer.play(serverSitNum);                    // just chang spot light
        this._playersLayer.playerCountDown(serverSitNum, delay);    // 倒數計時

        //輪到自己
        if (isMeFlag) {
            // 撥放音效
            this.runAction(cc.sequence(
                cc.delayTime(0.5),
                cc.callFunc(function () {
                    MusicUtility.playEffect("Music/Effect/e_youturn.mp3");
                })
            ));

            // 判斷是否要震動
            if (DataModal.settingData.domino.vibrateWhenTurnSelf && cc.sys.isNative) {
                cc.Device.vibrate(0.2);
            }

            // 介面新手教學：當玩家進行第一手可選擇決策按鈕時跳出
            this._uiTeachNode.show("play");

            // 輪到自己要把Dialog關掉先
            DialogManager.cleanAllDialog();
        }
    },

    /**
     * 通知 開始處理Socket CMD
     */
    notifyGameProcessCMD: function (event) {
        if (this._enableProcessMessage)
            this.processMessage();
    },

    /**
     * 開啟處理Socket CMD
     */
    notifyEnableProcessMessage: function (event) {
        this._enableProcessMessage = true;
        while (this.processMessage() && this._enableProcessMessage) {
        }
    },

    /**
     * 通知點擊坐下
     * @private
     */
    notifyGameUISitDownClicked: function (event) {
        var param = event.getUserData();

        //確定身上的錢 >= 小攜 要跳攜入Dialog
        if (param.money >= param.min) {
            this._showNeedPayDialog = false;
            var dialog = new BringMoneyDialog(param);
            DialogManager.addDialog(dialog);
        } else {
            if (this._showNeedPayDialog) {
                // 檢查需要跳哪種沒錢的Dialog
                this._checkBrokePaymentDialog();
            } else {
                // 沒有儲值Dialog 就跳一般沒錢的Dialog
                var dialog = new AvatarDialog(
                    DialogHelper("RoomNoMoney", JSCodeUtility.getCurrencyString(DataModal.gameData.minBringIn)));
                DialogManager.addDialog(dialog);
            }
        }
    },

    /**
     * 按"更換房間"按鈕
     */
    notifyGameUIChangePlaceClicked: function (event) {
        // Dialog提示
        var dialog = new SimpleDialog(LocalizedString.Game("更換牌桌中 請稍候..."));
        dialog.key = "ReplaceRoomDialog";
        DialogManager.addDialog(dialog);

        //設定參數
        this._isReplaceRoomByClickedUIButton = true;
        this._isReplaceingRoom = true;
        this._isReplacedRoom = true;

        var eventObject = event.getUserData();
        var isToSmallTable = false;
        if (eventObject) {
            this._isReplaceRoomByClickedUIButton = event.getUserData().isReplaceRoomByClickedUIButton;
            isToSmallTable = eventObject.isToSmallTable;
        }

        // 送出 (統一送quickJoinP就好)
        if (isToSmallTable)
            DataProcess.sendString("quickJoinP");
        else
            DataProcess.sendString("quickJoinP " + DataModal.gameData.anteValue);

        // 刮刮卡暫停
        DataModal.scratchCardData.stopCountDown();
    },

    /**
     * 按下左上UI返回大廳按鈕回Lobby
     */
    notifyGameUIBackToLobbyClicked: function (event) {
        DataProcess.sendString("toLobby");

        // 強制GameLayer不要收東西了
        this._enableProcessMessage = false;

        GSLoading.addLoadingView();
    },

    /**
     * 送小費
     */
    notifyGameSendTips: function (event) {
        if (event && event.getUserData()) {
            // 這邊直接送一個籌碼出去
            var array = event.getUserData().split(" ");
            var serverPos = JSCodeUtility.getIntValue(array[0]);
            var playerData = DataModal.gameData.playerDataArray[serverPos];

            if (playerData) {
                var money = "+" + JSCodeUtility.getIntValue(array[1]);
                var message = playerData.nickname + '\n' + decodeURIComponent(array[2]);

                // 有玩家在
                var playerPos = Domino_GameUtility.getPlayerPosition(DataModal.gameData.getDirectionByServerDirection(serverPos));
                var chipSprite = new cc.Sprite("#game_pic_chips_big_02.png");
                chipSprite.setPosition(playerPos.x - 15, playerPos.y);
                this.addChild(chipSprite);

                // 飛到荷官
                chipSprite.runAction(cc.sequence(
                    cc.moveTo(0.5, cc.p(JSScreenMidPos.x, 253 + JSScreenBonusHalfHeight)).easing(cc.easeOut(0.5)),
                    cc.callFunc(function () {
                        // 通知背景要出現對話
                        this._dealerLayer.dealerMsg(message, money);
                    }, this),
                    cc.fadeOut(0.3),
                    cc.removeSelf()
                ));
            }
        }
    },

    // 收到開始遊戲的CMD
    notifyStartGame: function () {
        // 清空東西
        this._cleanGameLayerData(false);
        this._uiLayer.setMenuStatus(DOMINO_UILAYER_STATUS.WAIT_NEXT_GAME2);

        // 清掉畫面
        this._playersLayer.cleanData();
        this._confirmCardLayer.cleanData();

        // 清掉Dialog
        DialogManager.cleanAllDialog();

        // 設定可以讀取Socket
        this._enableProcessMessage = true;
    }
});
