/**
 * 簡單聊天的按鈕 不能移動(目前只有多人機台用)
 */
var ChatButton = cc.ControlButton.extend({
    ctor: function () {
        this._super();

        // 預設開啟
        this.setCascadeColorEnabled(true);
        this.setCascadeOpacityEnabled(true);

        // 設定大小
        var btnSize = this._btnSize = cc.size(34, 34);
        var midPos = cc.p(btnSize.width / 2, btnSize.height / 2);

        // btn容器
        var mainNode = this._mainNode = new ccui.Scale9Sprite();
        mainNode.setCascadeColorEnabled(true);
        mainNode.setCascadeOpacityEnabled(true);
        mainNode.setContentSize(btnSize);

        // 背景
        var bgSprite = new cc.Sprite("#lobby_btn_circle_04.png");
        bgSprite.setScale(1.1);
        bgSprite.setPosition(midPos);
        mainNode.addChild(bgSprite);

        // icon
        var icon = new cc.Sprite("#chat_btn_icon_talk.png");
        icon.setScale(0.75);
        icon.setPosition(midPos);
        mainNode.addChild(icon);

        // 自己的設定
        this.setPreferredSize(btnSize);         // 一定要加這行 Native才會是對的
        this.setBackgroundSpriteForState(mainNode, cc.CONTROL_STATE_NORMAL);
        this.addTargetWithActionForControlEvents(this, this._buttonClicked,
            cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
            cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
            cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
        this.setAdjustBackgroundImage(false);
        this.setZoomOnTouchDown(false);
    },

    /**
     * 按到的時候 要改變顏色
     */
    _buttonClicked: function (sender, type) {
        var isTouched = (type === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || type === cc.CONTROL_EVENT_TOUCH_DOWN);
        this._mainNode.setColor(isTouched ? JSColor.GRAY : JSColor.WHITE);
    },

    /**
     * 加入按鈕按下去的Callback
     * @param {function}    func    傳Function
     * @param {context}     target  傳Context
     * 用法 button.addTouchUpInsideAction(this._testClicked, this);
     */
    addTouchUpInsideAction: function (func, target) {
        this.addTargetWithActionForControlEvents(target, func, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
    },
});