/**
 * Cangkulan 棄牌區
 */
var Cangkulan_FoldCardLayer = cc.Node.extend({
    ctor: function () {
        this._super();

        var foldPos = this._foldPos = cc.pAdd(JSScreenMidPos, Cangkulan_Offset.FOLD);

        // 棄牌堆的數量
        this._foldCardCount = 0;

        // 疊起來的牌
        this._flodStackCard = [];
        this._flodStackCount = 0;

        var foldNode = this._foldNode = new cc.Node();
        this.addChild(foldNode);

        // 放堆疊的牌
        var stackCardNode = this._stackCardNode = new cc.Node();
        this.addChild(stackCardNode);

        // 棄牌的底圖
        var foldSp = new cc.Sprite("#cangkulan_pic_fold.png");
        foldSp.setPosition(foldPos);
        foldNode.addChild(foldSp);

        // 棄牌區顯示的牌(不表演)
        var foldCardNode = this._foldCardNode = new PokerCardNode("11");
        foldCardNode.setPosition(foldPos);
        foldCardNode.setVisible(false);
        this.addChild(foldCardNode, 10);

        // 表演用的牌
        var cardAnimNode = this._cardAnimNode = new PokerCardNode("11");
        cardAnimNode.setPosition(foldPos);
        cardAnimNode.setVisible(false);
        this.addChild(cardAnimNode, 11);

        this.clean();
    },

    clean: function () {
        // 停止動畫的牌
        this._cardAnimNode.stopAllActions();
        this._cardAnimNode.setVisible(false);

        // reset棄牌區顯示的牌
        this._foldCardNode.setPositionY(this._foldPos.y);
        this._foldCardNode.setVisible(false);
        this._foldNode.setVisible(false);

        this._foldCardCount = 0;

        // 移除堆疊的牌
        this._flodStackCard = [];
        this._flodStackCount = 0;
        this._stackCardNode.removeAllChildren();
    },

    /**
     * 設置棄牌堆的牌(牌局重現時)
     * @param foldCard 棄牌堆最上面的牌
     * @param foldCount 棄牌區的張數
     */
    setCurrentFoldCard: function (foldCard, foldCount) {
        for (var i = 0; i < (foldCount - 1); i++) {
            this._foldCardCount++;
            this.addFoldStackCard();
        }

        this.showFoldCard(foldCard);
        this._foldCardNode.setPositionY(this._foldPos.y + this._flodStackCount * 0.4);
        this.showFoldSp();
    },

    /**
     * 產生堆疊起來的牌
     */
    addFoldStackCard: function () {
        // 最多會有12張疊起來的牌 棄4張牌會產生一張疊起來的牌
        if (Math.floor(this._foldCardCount / 4) > this._flodStackCount) {
            this._flodStackCount++;

            // 產生牌
            var cardNode = new PokerCardNode();
            cardNode.setPosition(this._foldPos.x, this._foldPos.y + this._flodStackCount * 0.4);
            this._stackCardNode.addChild(cardNode);
            this._flodStackCard.push(cardNode);
        }
    },

    /**
     * 顯示器牌的底圖(沒牌的時候要show)
     */
    showFoldSp: function () {
        this._foldNode.setVisible(true);
    },

    /**
     * 顯示棄牌區的牌
     */
    showFoldCard: function (cardNum) {
        // 棄牌堆牌++
        this._foldCardCount++;
        var oldStackCount = this._flodStackCount;
        this.addFoldStackCard();

        // 顯示最上方牌的位置(因為下面的牌會疊起來 上方的牌會跟著移動)
        if (this._flodStackCount !== oldStackCount) {
            // 有新的堆疊牌才重設最上面的牌
            if (this._foldCardCount === 0)
                this._foldCardNode.setPositionY(this._foldPos.y);
            else
                this._foldCardNode.setPositionY(this._foldPos.y + this._flodStackCount * 0.4);
        }

        // 設置最上方的氣牌
        this._foldCardNode.setCardNumber(cardNum);
        this._foldCardNode.setVisible(true);
    },

    /**
     * 手牌飛入棄牌 or 棄牌飛入手牌
     * @param playerPos      : 玩家位置
     * @param flyType        : 飛的方向
     * @param card           : 棄牌區要飛入手牌的牌
     * @param handPos        : 要飛入自己的手牌要塞入手牌中的位置
     * @param showFoldCard   : 飛完手牌後棄牌區最上面要顯示的牌
     */
    runFoldFlyCardAnim: function (playerPos, flyType, card, handPos, showFoldCard) {
        var scaleCard = (handPos) ? 1 : 0.5;

        if (handPos)
            // 從棄牌區飛入自己的手牌中
            var cardPos = handPos;
        else {
            // 飛入其他玩家的手牌 or 從手牌飛到棄牌區
            var direction = DataModal.gameData.getDirectionByServerDirection(playerPos);
            var cardPos = Cangkulan_GameUtility.getDealCardPosition(direction);
        }

        // 設定要表演的初始位置跟尺寸
        switch (flyType) {
            case Cangkulan_FoldCardLayer.FLY_TYPE.FOLD_TO_HAND:
                // 棄牌區飛入手牌
                this._cardAnimNode.setPosition(this._foldPos);
                this._cardAnimNode.setScale(1);

                if (showFoldCard) {
                    // 顯示下一張牌
                    this._foldCardNode.setCardNumber(showFoldCard);
                    this._foldCardNode.setVisible(true);
                } else {
                    // 沒有下一張牌隱藏
                    this._foldCardNode.setVisible(false);
                }

                var endScale = scaleCard;
                var endPos = cardPos;

                var cb = () => {
                    // 加入手牌
                    if (handPos) {
                        // 通知顯示在手牌中
                        GS.dispatchCustomEvent("NotifyGameShowDrawCard");
                    } else
                        // 其他玩家的牌
                        GS.dispatchCustomEvent("NotifyAddPlayerHandCard", playerPos);

                    GS.dispatchCustomEvent("NotifyEnableProcessMessage");
                };
                break;

            case Cangkulan_FoldCardLayer.FLY_TYPE.HAND_TO_FOLD:
                // 手牌飛入棄牌區
                this._cardAnimNode.setPosition(cardPos);
                this._cardAnimNode.setScale(scaleCard);

                var endScale = 1;
                var endPos = this._foldPos;

                var cb = () => {
                    // 打開要顯示的牌
                    this.showFoldCard(card);
                    GS.dispatchCustomEvent("NotifyEnableProcessMessage");
                };
                break;
        }

        // 以正面飛入 設置要表演牌的號碼
        var cardNumber = (card) ? card : this._foldCardNode.cardNumber;
        this._cardAnimNode.setCardNumber(cardNumber);

        this._cardAnimNode.setVisible(true);

        var moveTime = 0.3;
        this._cardAnimNode.runAction(cc.sequence(
            cc.spawn(
                cc.moveTo(moveTime, endPos),
                cc.scaleTo(moveTime, endScale)
            ),
            cc.callFunc(cb),
            cc.hide()
        ));

    }

});

Cangkulan_FoldCardLayer.FLY_TYPE = {
    HAND_TO_FOLD: 0,     // 手牌飛入棄牌區
    FOLD_TO_HAND: 1,     // 棄牌區飛入手牌
};