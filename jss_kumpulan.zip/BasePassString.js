var LocalizedString = LocalizedString || {};

LocalizedString.BasePass = function (str) {
    let keyValue = {
        "全部領取": "Klaim semua",
        "馬上玩": "Segera Main",
        "馬上領": "Segera klaim",
        "獎勵價值": "Senilai",
        "豐富獎勵": "hadiah mewah",
        "跳過動畫": "Lewati Animasi",

        // 購買 pass dialog
        "需先": "Harus buka",
        "獲得": "terlebih",
        "解鎖喔": "untuk membuka!",
        "解鎖 pass": "Beli",

        // 購買 pass dialog（循環獎勵）
        "獲得（循環獎勵）": "Dapatkan",
        "解鎖": "dan buka",
        "獎勵次數無上限!": "Hadiah tiada batas!",
    };

    return USE_i18n ? (keyValue[str] || str) : str;
};