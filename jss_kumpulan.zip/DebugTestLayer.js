/**
 * 測試主頁面
 */

var DebugTestLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this._testBtnSize = cc.size(120, 20);               // 測試按鈕大小
        this._grayNodeWidth = JSVisibleSize.width - 50;     // 灰底寬度

        this._smDeleteIdx = 0;

        // 背景
        var bgSp = new cc.Sprite(SelectGameManager.getNowGameFile("lobby_background.jpg"));
        bgSp.setPosition(JSScreenMidPos);
        this.addChild(bgSp, -1);

        // 標題
        var titleNode = new TitleBackgroundNode("測試功能");
        titleNode.setPosition(JSScreenMidPos.x, JSVisibleSize.height - TITLE_BG_HEIGHT / 2);
        this.addChild(titleNode, 10);

        // 下方主畫面
        var container = this._container = new cc.Layer();
        var scrollView = this._scrollView = new cc.ScrollView(cc.size(JSVisibleSize.width, JSVisibleSize.height - 30), container);
        scrollView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        this.addChild(scrollView);

        // 內容參數
        this._paddingY = 10;            // 位移高度
        this._contentHeight = 0;        // 內容高度
        this._testNodeArray = [];       // 測試區塊

        // 加入基礎資訊
        this._addBaseInfoNode();

        // 加入Slot機台測試入口
        this._addSlotMachineTest();

        // 自動化測試
        if (GS.isDevEnviroment) {
            this._addAutoTest();
        }

        // 加入View選單
        this._addViewBtn();

        // 加入白帳號測試
        this._addBlackAccountTest();

        // 加入Banner引導測試
        this._addBigBannerTest();

        // 加上儲值測試功能
        this._addPurchaseTest();

        // 加上自送CMD功能
        this._addSendCMDTest();

        // 加入推播測試
        this._addLocalNotificationTest();

        // 加入廣告測試
        this._addMovieAdTest();

        // 加入第三方分享訊息測試
        this._addThirdShareMessageTest();

        // 加入網頁排版測試
        this._addWebViewTest();

        // 加入網頁可以打開DevTools
        this._addWebViewDevTools();

        // 加入刮刮卡測試
        this._addScratchCardTest();

        // 加入閃退測試
        this._addCrashTest();

        // 重新排位置
        this._refreshTestNodePos();
    },

    /**
     * 創灰底Node，以中間對位
     * 必須加入，會根據這邊計算 scrollView 的尺寸及位移
     * @param height    高度
     */
    _createGrayNode: function (height) {
        // 增加高度及間隔
        this._contentHeight += height + this._paddingY;

        // 創灰底
        var grayNode = new ccui.Scale9Sprite("lobby_bg_window_02.png");
        grayNode.setPreferredSize(cc.size(this._grayNodeWidth, height));
        this._container.addChild(grayNode);

        // 存起來，好排位置
        this._testNodeArray.push(grayNode);

        return grayNode;
    },

    /**
     * 創說明按鈕
     * @param grayNode  灰底Node
     * @param msg       說明訊息
     */
    _createInfoBtn: function (grayNode, msg) {
        // 灰底高度
        var grayNodeHeight = grayNode.getContentSize().height;

        // 創說明按鈕
        var infoBtn = ButtonUtility.createSimpleImageButton("lobby_btn_circle_05.png", null, "#explain_icon.png");
        infoBtn.addTouchUpInsideAction(() => {
            // 說明的文字
            var msgLabel = new cc.LabelTTF(msg, JSFontBoldName, 10);
            msgLabel.setFontFillColor(JSColor.BLACK);

            // 加入泡泡框
            var msgParam = {
                mainNode: msgLabel,
                style: BaseMessageNode.Style.WHITE_SHADOW,
                direct: BaseMessageNode.Direct.UP_LEFT,
                arrowType: BaseMessageNode.ArrowType.STRAIGHT,
                arrowPadding: 0
            };
            var msgNode = new BaseMessageNode(msgParam);
            msgNode.setPosition(12, grayNodeHeight - 18);
            msgNode.show();
            grayNode.addChild(msgNode, 1);

            // 加一層UI擋Touch
            var dummyTouch = new DummyTouchLayer(JSVisibleSize);
            dummyTouch.setOnTouchCallback(() => {
                // 點任意處關閉泡泡框
                msgNode.close();

                // 避免點擊馬上透下去 用runAction砍掉
                dummyTouch.stopAllActions();
                dummyTouch.runAction(cc.removeSelf());
            });
            this.addChild(dummyTouch, 10);
        }, this);
        infoBtn.setScale(0.8);
        infoBtn.setPosition(0, grayNodeHeight);
        infoBtn.setAnchorPoint(0, 1);
        grayNode.addChild(infoBtn);
    },

    /**
     * 建立有簡易 ScrollBar 的選單 (這裡算是用 hack 的去做，如果之後 SelectItemListDialog 本身有自己的 ScrollBar，這裡就可以換掉了)
     */
    _createSelectItemDialogWithScrollBar: function (theList, theIndex, callback) {
        var dialog = new SelectItemListDialog(theList, theIndex, callback);

        // 額外強制加入 scroll bar
        var tableView = dialog._tableView;
        if (tableView) {
            var tableViewPos = tableView.getPosition();

            var scrollBar = dialog._scrollBar = new GSScrollBar(tableView);
            scrollBar.setBarOpacity(200);
            scrollBar.setBarSize(cc.size(8, 0));
            scrollBar.setMinBarLength(20);
            scrollBar.setBarDragCallback((percentValue) => {
                // scrollBar被拖動 根據拖動到多少百分比調整tableView的位置
                tableView.setContentOffset(cc.p(tableView.getContentOffset().x, -tableView.getContentSize().height * percentValue));
            });
            scrollBar.setPosition(tableViewPos.x, tableViewPos.y);
            dialog._animationLayer.addChild(scrollBar, 1);

            // 這裡獨立加入 delegate function，這樣沒有加的就不會 call 進去
            dialog.scrollViewDidScroll = function () {
                // 改變滾動條
                this._scrollBar.refresh();
            };
        }

        return dialog;
    },

    /**
     * 重新排測試Node位置
     */
    _refreshTestNodePos: function () {
        var paddingY = this._paddingY;                  // 間隔
        var scrollView = this._scrollView;              // scrollView
        var contentHeight = this._contentHeight;        // 內容總高度
        var testNodeArray = this._testNodeArray;        // 所有測試Node
        var testNodeArrayLen = testNodeArray.length;    // 測試Node個數

        // 設定ScrollView
        var contentOffsetY = scrollView.getViewSize().height - contentHeight - paddingY;
        scrollView.setContentSize(JSVisibleSize.width, contentHeight + paddingY);   // 加上最後間隔
        scrollView.setContentOffset(cc.p(0, contentOffsetY));

        // 排列位置function
        var setNodePosition = (node, idx) => {
            var nodeHeight = node.getContentSize().height;
            node.setPosition(JSScreenMidPos.x, contentHeight - nodeHeight / 2);
            node.setLocalZOrder(testNodeArrayLen - idx);

            // 調整下一個Node高度
            contentHeight -= nodeHeight + paddingY;
        };

        // 重新排位置
        var crashNode = null;
        testNodeArray.forEach((node, idx) => {
            // Crash測試 位置排在最後面
            if (node.key === "crash_test")
                crashNode = node;
            else
                setNodePosition(node, idx);

            // 最後一個判斷有沒有 crashNode
            if (testNodeArrayLen - 1 === idx && crashNode)
                setNodePosition(crashNode, idx);
        });
    },

    /**
     * 加入基礎資訊
     */
    _addBaseInfoNode: function () {
        // 加灰底
        var haveAccount = DataModal.profileData.account.length > 0;
        var grayNodeHeight = haveAccount ? 70 : 50;
        var equalHeight = grayNodeHeight / 3;
        var grayNode = this._createGrayNode(grayNodeHeight);

        // 玩家帳號
        if (haveAccount) {
            var menu = new cc.Menu();
            menu.setPosition(0, 0);
            grayNode.addChild(menu, 2);

            var itemNode = [];
            for (var i = 0; i < 2; i++) {
                var node = itemNode[i] = new cc.Node();
                node.setCascadeColorEnabled(true);
                node.setCascadeOpacityEnabled(true);

                var account = node.account = new GSRichTextNode("遊戲帳號(點擊可複製): #!FFFF00!#" + DataModal.profileData.account, JSFontBoldName, 12);
                node.addChild(account);

                var bgSize = cc.size(account.getContentSize().width, account.getContentSize().height);
                account.setPosition(bgSize.width / 2, bgSize.height / 2);
                node.setContentSize(bgSize);
            }
            var accountMenuItem = new cc.MenuItemSprite(itemNode[0], itemNode[1], function () {
                cc.sys.setTextToClipboard(DataModal.profileData.account);

                // 提示
                grayNode.removeChildByName("tipLabel");
                var tipLabel = new cc.LabelTTF("帳號已複製至剪貼簿", JSFontBoldName, 10);
                tipLabel.setPosition(30 + bgSize.width, equalHeight * 1.5);
                tipLabel.setAnchorPoint(0, 0.5);
                tipLabel.setFontFillColor(JSColor.CYAN);
                tipLabel.setOpacity(0);
                tipLabel.setName("tipLabel");
                grayNode.addChild(tipLabel);
                tipLabel.runAction(cc.sequence(
                    cc.spawn(cc.fadeIn(0.3), cc.moveBy(0.3, cc.p(0, equalHeight / 2))),
                    cc.delayTime(1),
                    cc.fadeOut(0.3),
                    cc.removeSelf()
                ));
            }, this);
            accountMenuItem.setPosition(24, equalHeight * 2);
            accountMenuItem.setAnchorPoint(0, 0.5);
            menu.addChild(accountMenuItem);
        } else {
            // 沒有帳號 就直接置中
            equalHeight = grayNodeHeight / 2;
        }

        // 是否在測試區
        var domainArea = GS.domain.match(GS.reallyDomain) ? "正式區" : "#!FFFF00!#測試區";

        // 測試環境
        var title = new GSRichTextNode("目前遊戲版本：#!FFFF00!#v" + GS.gameVersion + "\n#!FFFFFF!#目前連線環境：" + domainArea + " " + GS.domain, JSFontBoldName, 12);
        title.setPosition(24, equalHeight);
        title.setAnchorPoint(0, 0.5);
        grayNode.addChild(title, 1);

        // 有讀取到 build_revision 的話，就加上 revision
        cc.sys.isNative && cc.loader.load("build_revision.txt", (err, txtString) => {
            txtString[0] && title.setText("目前遊戲版本：" + (cc.sys.isNative ? JSStringUtility.format("#!FF0000!#%s ", cc.sys.getVersion().substring(0, 5)) : "") + "#!FFFF00!#v" + GS.gameVersion + txtString[0] + "\n#!FFFFFF!#目前連線環境：" + domainArea + " " + GS.domain, JSFontBoldName, 12);
        });
    },

    /**
     * 加入白帳號測試
     */
    _addBlackAccountTest: function () {
        // 是否已開啟強制白帳號
        var isForceWhiteAccount = DataModal.debugTestData.isForceWhiteAccount;

        // 加灰底
        var grayNodeHeight = 50;
        var grayNode = this._createGrayNode(grayNodeHeight);

        // 標題
        var title = new cc.LabelTTF("強制白帳號 (踢回登入畫面)", JSFontBoldName, 12);
        title.setPosition(24, grayNodeHeight / 2);
        title.setAnchorPoint(0, 0.5);
        grayNode.addChild(title, 1);

        // 按鈕
        var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", this._testBtnSize, isForceWhiteAccount ? "點我關閉" : "點我開啟", 12);
        var accountBtn = new GSControlButton(itemNodes[0]);
        accountBtn.addTouchUpInsideAction(this._accountBtnClicked, this);
        accountBtn.setPosition(this._grayNodeWidth - 80, grayNodeHeight / 2);
        grayNode.addChild(accountBtn);

        // 加入說明按鈕
        this._createInfoBtn(grayNode, "僅限測試區使用，正式區請直接找Client拿正式區專用版本");
    },

    /**
     * Banner引導測試
     */
    _addBigBannerTest: function () {
        // Banner引導索引
        this._bannerIdx = 0;

        // 加灰底
        var grayNodeHeight = 70;
        var grayNode = this._createGrayNode(grayNodeHeight);

        // Big Banner 引導
        var title = new cc.LabelTTF("開啟 Big Banner 選單\n\n自訂", JSFontBoldName, 12);
        title.setPosition(24, grayNodeHeight / 2);
        title.setAnchorPoint(0, 0.5);
        grayNode.addChild(title, 1);

        // 輸入Big Banner的欄位
        var editBoxSp1 = new ccui.Scale9Sprite("select_01.png");
        var editBoxSp2 = new ccui.Scale9Sprite("select_01.png");
        editBoxSp2.setColor(JSColor.GRAY);
        var typeEditBox = new cc.EditBox(cc.size(60, 20), editBoxSp1, editBoxSp2);
        typeEditBox.setPlaceHolder("Type");
        typeEditBox.setPlaceholderFont(JSFontName, 12);
        typeEditBox.setReturnType(cc.KEYBOARD_RETURNTYPE_DONE);
        typeEditBox.setInputFlag(cc.EDITBOX_INPUT_FLAG_SENSITIVE);
        typeEditBox.setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC);
        typeEditBox.setPosition(52, grayNodeHeight / 3 - 2);
        typeEditBox.setFontColor(JSColor.BLACK);
        typeEditBox.setFontName(JSFontName);
        typeEditBox.setAnchorPoint(0, 0.5);
        grayNode.addChild(typeEditBox);

        // 輸入url的欄位
        editBoxSp1 = new ccui.Scale9Sprite("select_01.png");
        editBoxSp2 = new ccui.Scale9Sprite("select_01.png");
        editBoxSp2.setColor(JSColor.GRAY);
        var urlEditBox = new cc.EditBox(cc.size(115, 20), editBoxSp1, editBoxSp2);
        urlEditBox.setPlaceHolder("Url，可空白");
        urlEditBox.setPlaceholderFont(JSFontName, 12);
        urlEditBox.setReturnType(cc.KEYBOARD_RETURNTYPE_DONE);
        urlEditBox.setInputFlag(cc.EDITBOX_INPUT_FLAG_SENSITIVE);
        urlEditBox.setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE);
        urlEditBox.setPosition(120, grayNodeHeight / 3 - 2);
        urlEditBox.setFontColor(JSColor.BLACK);
        urlEditBox.setFontName(JSFontName);
        urlEditBox.setAnchorPoint(0, 0.5);
        grayNode.addChild(urlEditBox);

        // 導引按鈕
        var testBtnSize = this._testBtnSize;
        var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", testBtnSize, "[0] 無", 12);
        var bannerNode = this._bannerNode = itemNodes[0];
        var bannerBtn = new GSControlButton(bannerNode);
        bannerBtn.addTouchUpInsideAction(this._bannerBtnClicked, this);
        bannerBtn.setPosition(this._grayNodeWidth - 80, grayNodeHeight * 2 / 3 + 3);
        grayNode.addChild(bannerBtn);

        //  送出自訂Banner
        itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", testBtnSize, "前往自訂", 12);
        var customBtn = new GSControlButton(itemNodes[0]);
        customBtn.addTouchUpInsideAction(() => {
            var bannerType = JSCodeUtility.getIntValue(typeEditBox.getString());
            var url = urlEditBox.getString();
            // 有輸入才引導
            bannerType && PushLayerHelper.pushLayer(url, bannerType);
        }, this);
        customBtn.setPosition(this._grayNodeWidth - 80, grayNodeHeight / 3 - 3);
        grayNode.addChild(customBtn);

        // 取得引導說明
        var lobbyBannerModeInfo = this.LOBBY_BANNER_MODE_INFO;

        // 創Banner清單
        var bannerList = this._bannerList = [];
        var bannerIdxArray = this._bannerIdxArray = [];
        for (var idx in lobbyBannerModeInfo) {
            bannerIdxArray.push(parseInt(idx));                             // 存索引
            bannerList.push("[" + idx + "] " + lobbyBannerModeInfo[idx]);   // 存名稱
        }

        // 加入說明按鈕
        this._createInfoBtn(grayNode, "未立即導引原因:\n1. 表示非此遊戲用編號\n2. 僅供對照編號的用途\n\n自訂:\n1. 第一欄請輸入Banner Type\n2. 若需帶參數可於第二欄輸入");
    },

    /**
     * Slot機台測試入口
     */
    _addSlotMachineTest: function () {
        // 機台列 (這邊加入機台數字)
        var smArray = this._smArray = Object.keys(VegasVersion);

        // 機台列
        this._smNameArray = smArray.map(sm => JSStringUtility.format("%s %s (v%s)", sm, SlotConfig.getSlotNameByID(sm), VegasVersion[sm]));

        // 額外刪除功能
        var extraArray = ["刪除全部賠付表", "刪除全部機台資源包"];
        this._smArrayOffset = extraArray.length;

        // 特別加入額外選項
        this._smDeleteArray = extraArray.concat(this._smNameArray);

        // 加灰底
        var grayNodeHeight = 75;
        var grayNode = this._createGrayNode(grayNodeHeight);

        var testBtnSize = this._testBtnSize;

        // 標題
        var title = new cc.LabelTTF("Slot機台測試入口", JSFontBoldName, 12);
        title.setPosition(24, grayNodeHeight / 2 + testBtnSize.height);
        title.setAnchorPoint(0, 0.5);
        grayNode.addChild(title, 1);

        // 按鈕
        var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", testBtnSize, "選擇機台", 12);
        var packNode = itemNodes[0];
        var packBtn = new GSControlButton(packNode);
        packBtn.addTouchUpInsideAction(this._smClicked, this);
        packBtn.setPosition(this._grayNodeWidth - 230, 55);
        grayNode.addChild(packBtn);

        // 分隔線
        var lineSprite = new cc.Sprite("#users_line.png");
        lineSprite.setScaleX(((grayNodeHeight / 2) - 10) / lineSprite.getContentSize().width);
        lineSprite.setRotation(90);
        lineSprite.setPosition(this._grayNodeWidth - 140, 55);
        grayNode.addChild(lineSprite);

        // 輸入機台編號的欄位
        var editBoxSp1 = new ccui.Scale9Sprite("select_01.png");
        var editBoxSp2 = new ccui.Scale9Sprite("select_01.png");
        editBoxSp2.setColor(JSColor.GRAY);
        var slotNumEditBox = this._slotNumEditBox = new cc.EditBox(cc.size(60, 20), editBoxSp1, editBoxSp2);
        slotNumEditBox.setPlaceHolder("機台編號");
        slotNumEditBox.setFontName(JSFontName);
        slotNumEditBox.setPlaceholderFontName(JSFontName);
        slotNumEditBox.setPlaceholderFontSize(11);
        slotNumEditBox.setFontSize(11);
        slotNumEditBox.setReturnType(cc.KEYBOARD_RETURNTYPE_DONE);
        slotNumEditBox.setInputFlag(cc.EDITBOX_INPUT_FLAG_SENSITIVE);
        slotNumEditBox.setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE);
        slotNumEditBox.setPosition(this._grayNodeWidth - 125, 55);
        slotNumEditBox.setFontColor(JSColor.BLACK);
        slotNumEditBox.setAnchorPoint(0, 0.5);
        grayNode.addChild(slotNumEditBox);

        // 如果有記住之前選擇的機台 幫他填入
        if (DataModal.debugTestData.testLayerSelectSlotIdx !== undefined) {
            slotNumEditBox.setString(this._smArray[DataModal.debugTestData.testLayerSelectSlotIdx].replace("Slot_", ""));
        }

        //  送出自訂Banner
        itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", cc.size(55, testBtnSize.height), "Go機台", 12);
        var customBtn = new GSControlButton(itemNodes[0]);
        customBtn.addTouchUpInsideAction(() => {
            var inputStr = slotNumEditBox.getString().trim();
            if (!inputStr)
                return;

            var slotName = "Slot_" + inputStr;

            var smIdx = this._smArray.findIndex(cur => ((cur === inputStr) || (cur === slotName)));
            if (smIdx !== -1) {
                this._goVegasSlot(smIdx);
            } else {
                DialogManager.addDialog(new CommonDialog({
                    title: slotName,
                    content: "目前Client端版本不支援此機台！\n\n若不確定機台編號，請點選左邊#!FFFF00!#選擇機台#!FFFFFF!#按鈕"
                }));
            }
        }, this);
        customBtn.setPosition(this._grayNodeWidth - 35, 55);
        grayNode.addChild(customBtn);

        // 分隔線 -- 分隔線下方是機台相關的測試功能
        var lineSprite = new cc.Sprite("#users_line.png");
        lineSprite.setScaleX((this._grayNodeWidth - 20) / lineSprite.getContentSize().width);
        lineSprite.setPosition(this._grayNodeWidth / 2, grayNodeHeight / 2);
        grayNode.addChild(lineSprite);

        // 按鈕
        itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", testBtnSize, "刪除指定機台資源", 12);
        var deleteBtn = new GSControlButton(itemNodes[0]);
        deleteBtn.addTouchUpInsideAction(this._deleteSlotClick, this);
        deleteBtn.setPosition(this._grayNodeWidth - 80, 18);
        grayNode.addChild(deleteBtn);

        // 加入說明按鈕
        this._createInfoBtn(grayNode, "測試功能說明：\n[刪除指定機台資源] 點選選項後刪除指定機台資源");
    },

    // 自動化測試
    _addAutoTest: function () {
        // 加灰底
        var grayNodeHeight = 60;
        var grayNode = this._createGrayNode(grayNodeHeight);
        var midPosY = grayNodeHeight / 2;

        // 顯示獎圖編號
        {
            var menu = new cc.Menu();
            menu.setPosition(0, 0);
            grayNode.addChild(menu);

            var toggleItemText = new GSRichTextNode("顯示獎圖編號(預設:關閉)", JSFontBoldName, 12);
            toggleItemText.setPosition(56, midPosY + 12.5);
            toggleItemText.setAnchorPoint(0, 0.5);
            grayNode.addChild(toggleItemText, 1);

            var toggleOn = new cc.MenuItemSprite(new cc.Sprite("#select_02.png"), new cc.Sprite("#select_02.png"));
            var toggleOff = new cc.MenuItemSprite(new cc.Sprite("#select_01.png"), new cc.Sprite("#select_01.png"));
            var toggleItem = new cc.MenuItemToggle(toggleOff, toggleOn, (sender) => {
                var index = sender.getSelectedIndex();
                cc.log("valerie: 獎圖編號= ", index);

                // 紀錄目前選擇 並 更新文字
                DataModal.debugTestData.setIsShowSymbolValue(index.toString());
            }, this);
            toggleItem.setPosition(toggleItemText.getPositionX() - 20, toggleItemText.getPositionY());
            toggleItem.setSelectedIndex(DataModal.debugTestData.getIsShowSymbolValue() ? 1 : 0);    // 目前是否顯示獎圖編號，預設是關閉
            menu.addChild(toggleItem);
        }

        // 顯示黑幕
        {
            var menu = new cc.Menu();
            menu.setPosition(0, 0);
            grayNode.addChild(menu);

            var toggleItemText = new GSRichTextNode("顯示黑幕(預設:開啟)", GSFont.TTF.OmnesSemibold, 12);
            toggleItemText.setPosition(56, midPosY - 12.5);
            toggleItemText.setAnchorPoint(0, 0.5);
            grayNode.addChild(toggleItemText, 1);

            var toggleOn = new cc.MenuItemSprite(new cc.Sprite("#select_02.png"), new cc.Sprite("#select_02.png"));
            var toggleOff = new cc.MenuItemSprite(new cc.Sprite("#select_01.png"), new cc.Sprite("#select_01.png"));
            var toggleItem = new cc.MenuItemToggle(toggleOff, toggleOn, (sender) => {
                var index = sender.getSelectedIndex();

                cc.log("valerie: 顯示黑幕= ", index);

                // 紀錄目前選擇 並 更新文字
                DataModal.debugTestData.setIsBlackMask(index.toString());
            }, this);
            toggleItem.setPosition(toggleItemText.getPositionX() - 20, toggleItemText.getPositionY());
            toggleItem.setSelectedIndex(DataModal.debugTestData.getIsBlackMask() ? 1 : 0); // 目前是否顯示黑幕，預設是開啟
            menu.addChild(toggleItem);
        }

        // 加入說明按鈕
        this._createInfoBtn(grayNode, "自動化測試需求:自行調整設定");
    },

    /**
     * 推播測試
     */
    _addLocalNotificationTest: function () {
        // 本地已有推播表
        var localNotificationList = this._localNotificationList = [];
        var notifyMapObject = DataModal.localNotificationData.notifyMapObject;
        for (var key in notifyMapObject)
            localNotificationList.push(key);

        // 檢查是否有推播
        if (!localNotificationList.length)
            localNotificationList.push("目前尚未有任何推播");

        // 加灰底
        var grayNodeHeight = 70;
        var grayNodeWidth = this._grayNodeWidth;
        var grayNode = this._createGrayNode(grayNodeHeight);

        // 標題
        var title = new cc.LabelTTF("推播秒數\n\n推播內容", JSFontBoldName, 12);
        title.setPosition(24, grayNodeHeight / 2);
        title.setAnchorPoint(0, 0.5);
        grayNode.addChild(title, 1);

        // 欄位大小
        var editBoxSize = cc.size(145, 20);

        // 秒數欄位
        var editBoxSp1 = new ccui.Scale9Sprite("select_01.png");
        var editBoxSp2 = new ccui.Scale9Sprite("select_01.png");
        editBoxSp2.setColor(JSColor.GRAY);
        var timeEditBox = this._timeEditBox = new cc.EditBox(editBoxSize, editBoxSp1, editBoxSp2);
        timeEditBox.setReturnType(cc.EDITBOX_INPUT_MODE_PHONENUMBER);
        timeEditBox.setInputFlag(cc.EDITBOX_INPUT_MODE_PHONENUMBER);
        timeEditBox.setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE);
        timeEditBox.setPosition(90, grayNodeHeight * 2 / 3 + 2);
        timeEditBox.setFontColor(JSColor.BLACK);
        timeEditBox.setFontName(JSFontName);
        timeEditBox.setAnchorPoint(0, 0.5);
        grayNode.addChild(timeEditBox);

        // 內容欄位
        var editBoxSp1 = new ccui.Scale9Sprite("select_01.png");
        var editBoxSp2 = new ccui.Scale9Sprite("select_01.png");
        editBoxSp2.setColor(JSColor.GRAY);
        var msgEditBox = this._msgEditBox = new cc.EditBox(editBoxSize, editBoxSp1, editBoxSp2);
        msgEditBox.setInputFlag(cc.EDITBOX_INPUT_FLAG_SENSITIVE);
        msgEditBox.setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE);
        msgEditBox.setFontColor(JSColor.BLACK);
        msgEditBox.setFontName(JSFontName);
        msgEditBox.setAnchorPoint(0, 0.5);
        msgEditBox.setPosition(90, grayNodeHeight / 3 - 2);
        grayNode.addChild(msgEditBox);

        // 推播表
        var testBtnSize = this._testBtnSize;
        var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", testBtnSize, "查看已有推播表", 12);
        var localListBtn = new GSControlButton(itemNodes[0]);
        localListBtn.addTouchUpInsideAction(this._localListBtnClicked, this);
        localListBtn.setPosition(grayNodeWidth - 80, grayNodeHeight * 2 / 3 + 3);
        grayNode.addChild(localListBtn);

        // 推播按鈕
        var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", testBtnSize, "推播", 12);
        var localNotificationBtn = new GSControlButton(itemNodes[0]);
        localNotificationBtn.addTouchUpInsideAction(this._localNotificationBtnClicked, this);
        localNotificationBtn.setPosition(grayNodeWidth - 80, grayNodeHeight / 3 - 3);
        grayNode.addChild(localNotificationBtn);

        // 加入說明按鈕
        this._createInfoBtn(grayNode, "設定幾秒後推播設定內容\n使用前請記得先把app通知開啟");
    },

    /**
     * 開啟 LogView 選單
     */
    _addViewBtn: function () {
        // 加灰底
        var grayNodeHeight = 50;
        var grayNode = this._createGrayNode(grayNodeHeight);

        // 標題
        var title = new cc.LabelTTF("LogView 選單", JSFontBoldName, 12);
        title.setPosition(24, grayNodeHeight / 2);
        title.setAnchorPoint(0, 0.5);
        grayNode.addChild(title, 1);

        // 按鈕
        var isLogViewShow = cc.director.getNotificationNode().getChildByName("LogView");
        var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", this._testBtnSize, isLogViewShow ? "點我關閉" : "點我開啟", 12);
        var logViewNode = this._logViewNode = itemNodes[0];
        var logViewBtn = new GSControlButton(logViewNode);
        logViewBtn.addTouchUpInsideAction(this._logViewBtnClicked, this);
        logViewBtn.setPosition(this._grayNodeWidth - 80, grayNodeHeight / 2);
        grayNode.addChild(logViewBtn);
    },

    /**
     * 加入刮刮卡測試
     */
    _addScratchCardTest: function () {
        // 去送資料
        DataProcess.sendString('scratch_card_v2 ["shop_list"]');

        // 註冊
        GS.addListenerOnce("NotifyScratchCardShopListDone", () => {
            // 先抓有多少刮刮卡
            var cardList = DataModal.scratchCardShopData.shopList;
            var cardListLen = cardList.length;

            // 加灰底
            var grayNodeHeight = 30 + 13 * (cardListLen + 4);
            var grayNode = this._createGrayNode(grayNodeHeight);

            // 標題
            var title = new cc.LabelTTF("刮刮卡測試：", JSFontBoldName, 12);
            title.setPosition(24, grayNodeHeight / 2);
            title.setAnchorPoint(0, 0.5);
            grayNode.addChild(title, 1);

            // 刮刮卡說明
            var explainLabel = new cc.LabelTTF("[編號] 名稱:Server:版號 / Client:版號", JSFontBoldName, 12);
            explainLabel.setPosition(100, grayNodeHeight - 14);
            explainLabel.enableStroke(JSColor.BLACK, 2);
            explainLabel.setAnchorPoint(0, 0.5);
            grayNode.addChild(explainLabel);

            // 刮刮卡內容
            var richText = "";
            if (!cardListLen) {
                richText = JSColor.colorToRichColor(JSColor.YELLOW) + "目前尚未開啟任何刮刮卡哦!";
            } else {
                var whiteRich = JSColor.colorToRichColor(JSColor.WHITE);
                var greenRich = JSColor.colorToRichColor(JSColor.GREEN);
                var redRich = JSColor.colorToRichColor(JSColor.RED);
                cardList.sort((a, b) => {
                    return a.cardID - b.cardID;
                }).forEach((param, idx) => {
                    // 刮刮卡編號
                    richText += whiteRich + "[" + param.cardID + "] ";
                    // 刮刮卡名稱
                    richText += param.name + ":";
                    // Server下載包版號
                    richText += greenRich + "Server:" + param.serverVersion + whiteRich + " / ";
                    // Client下載包版號
                    var isEqualVersion = param.serverVersion === param.clientVersion;
                    richText += (isEqualVersion ? greenRich : redRich) + "Client:" + param.clientVersion + (cardListLen - 1 === idx ? "" : "\n");
                });
            }

            var scratchCardRichText = new GSRichTextNode(richText, JSFontBoldName, 12);
            scratchCardRichText.setPosition(100, grayNodeHeight - 24);
            scratchCardRichText.setAnchorPoint(0, 1);
            grayNode.addChild(scratchCardRichText);

            // 按鈕
            var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", this._testBtnSize, "砍掉資源包", 12);
            var scratchCardBtn = new GSControlButton(itemNodes[0]);
            scratchCardBtn.addTouchUpInsideAction(this._scratchCardBtnBtnClicked, this);
            scratchCardBtn.setPosition(this._grayNodeWidth - 80, 20);
            grayNode.addChild(scratchCardBtn);

            // 加入說明按鈕
            this._createInfoBtn(grayNode, "若有更新資源包，請點擊「砍掉資源包」後，重登即可下載到新版資源包");

            // 重新排位置
            this._refreshTestNodePos();
        }, this);
    },

    /**
     * 廣告測試
     */
    _addMovieAdTest: function () {
        // 加灰底
        var grayNodeHeight = 50;
        var grayNode = this._createGrayNode(grayNodeHeight);

        // 標題
        var title = new cc.LabelTTF("廣告測試", JSFontBoldName, 12);
        title.setPosition(24, grayNodeHeight / 2);
        title.setAnchorPoint(0, 0.5);
        grayNode.addChild(title, 1);

        // 導引按鈕
        var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", this._testBtnSize, "播個廣告看看", 12);
        var movieAdBtn = new GSControlButton(itemNodes[0]);
        movieAdBtn.addTouchUpInsideAction(this._movieAdBtnClicked, this);
        movieAdBtn.setPosition(this._grayNodeWidth - 80, grayNodeHeight / 2);
        grayNode.addChild(movieAdBtn);

        // 加入說明按鈕
        this._createInfoBtn(grayNode, "測試影片播放，不會跟server要獎勵");
    },

    /**
     * 閃退測試
     */
    _addCrashTest: function () {
        // 加灰底
        var grayNodeHeight = 70;
        var grayNode = this._createGrayNode(grayNodeHeight);
        grayNode.key = "crash_test";

        // 標題
        var title = new cc.LabelTTF("[Client限定使用] 錯誤回報測試", JSFontBoldName, 12);
        title.setPosition(24, grayNodeHeight / 2);
        title.setAnchorPoint(0, 0.5);
        grayNode.addChild(title, 1);

        var btnList = ["閃退測試(Firebase)", "錯誤測試(CrashEye)"];
        btnList.forEach((cur, index) => {
            // 閃退按鈕
            var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_02.png", this._testBtnSize, cur, 12);
            var crashBtn = new GSControlButton(itemNodes[0]);
            crashBtn.addTouchUpInsideAction((sender) => {
                switch (index) {
                    // 閃退測試
                    case 0:
                        this.addChild(null);
                        break;
                    // 錯誤測試
                    case 1:
                        // 因為按了不會壞 所以把按鈕鎖起來避免連點
                        sender.setEnabled(false);

                        var errorTest = undefined;
                        errorTest.join("");
                        break;
                }
            }, this);
            crashBtn.setPosition(this._grayNodeWidth - 80, 50 - (index * 30));
            grayNode.addChild(crashBtn);
        });

        // 加入說明按鈕
        this._createInfoBtn(grayNode, "非Client人員請勿使用此功能\n\n1. Firebase觸發閃退後需重啟app才會回傳(需上傳)");
    },

    /**
     * 網頁排版測試
     */
    _addWebViewTest: function () {
        // 加灰底
        var grayNodeHeight = 70;
        var grayNode = this._createGrayNode(grayNodeHeight);
        grayNode.key = "WebView測試";

        // 標題
        var title = new cc.LabelTTF("網頁排版測試", JSFontBoldName, 12);
        title.setPosition(24, grayNodeHeight / 2);
        title.setAnchorPoint(0, 0.5);
        grayNode.addChild(title, 1);

        var titleArray = ["大(Large)", "中(Middle)", "小(Small)", "全版面"];

        // callback
        var url = "http://g.mwsrv.com/bigad/mjpoker/event/web/app_web/test/index.html";
        var callbackFuncs = [
            () => DialogManager.addDialog(new WebViewDialog(url, "Title - LARGE", () => {
                cc.log("Large web view close callack");
            }, false, GSEnum.DialogSize.LARGE)),
            () => DialogManager.addDialog(new WebViewDialog(url, "Title - MIDDLE", null, false, GSEnum.DialogSize.MIDDLE)),
            () => DialogManager.addDialog(new WebViewDialog(url, "Title - SMALL", null, false, GSEnum.DialogSize.SMALL)),
            () => PushScene.pushLayer(new LobbyWebViewLayer("LobbyWebViewLayer", url))
        ];

        // 按鈕
        var pos = [cc.p(234, 50), cc.p(80, 50), cc.p(234, 20), cc.p(80, 20)];
        titleArray.forEach((cur, index) => {
            var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", this._testBtnSize, cur, 12);
            var btn = new GSControlButton(itemNodes[0]);
            btn.addTouchUpInsideAction(callbackFuncs[index], this);
            btn.setPosition(this._grayNodeWidth - pos[index].x, pos[index].y);
            grayNode.addChild(btn);
        });

        // 加入說明按鈕
        this._createInfoBtn(grayNode, "給網頁組測試排版");
    },

    /**
     * 使用Chrome DevTools網頁除錯, 打開後在網址列打 chrome://inspect
     * https://developer.chrome.com/docs/devtools/remote-debugging/webviews/
     */
    _addWebViewDevTools: function () {
        // 加灰底
        var grayNodeHeight = 50;
        var grayNode = this._createGrayNode(grayNodeHeight);

        // 標題
        var title = new cc.LabelTTF("讓網頁使用DevTools", JSFontBoldName, 12);
        title.setPosition(24, grayNodeHeight / 2);
        title.setAnchorPoint(0, 0.5);
        grayNode.addChild(title, 1);

        // 導引按鈕
        var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", this._testBtnSize, "打開", 12);
        var movieAdBtn = new GSControlButton(itemNodes[0]);
        movieAdBtn.addTouchUpInsideAction(() => {
            jsb.reflection.callStaticMethod("com/gamesofa/GSDeviceInfo", "setWebContentsDebuggingEnabled", "()V");
        }, this);
        movieAdBtn.setPosition(this._grayNodeWidth - 80, grayNodeHeight / 2);
        grayNode.addChild(movieAdBtn);

        // 加入說明按鈕
        this._createInfoBtn(grayNode, "可以在手機上使用Chrome DevTools網頁除錯");
    },

    /**
     * 第三方分享訊息測試
     */
    _addThirdShareMessageTest: function () {
        // 設定標題
        var titleArray = ["內建程式 分享訊息", "LINE分享訊息", "Whatsapp分享訊息", "截圖並分享", "截圖並存到相簿", "FB Message分享訊息", "FB分享圖片(登FB)", "FB分享連結訊息(登FB)"];
        var len = titleArray.length;

        // 加灰底
        var grayNodeHeight = 30 * (Math.ceil(len / 2)) + 20;
        var grayNode = this._createGrayNode(grayNodeHeight);

        // 標題
        var title = new cc.LabelTTF("分享測試", JSFontBoldName, 12);
        title.setPosition(24, grayNodeHeight / 2);
        title.setAnchorPoint(0, 0.5);
        grayNode.addChild(title, 1);

        // callback
        var callbackFuncs = [
            () => GSOpenAppWrapper.shareMessage("app Message Test"),
            () => GSOpenAppWrapper.shareMessageByLine("LINE Message Test"),
            () => GSOpenAppWrapper.shareMessageByWhatsapp("Whatsapp Message Test"),
            () => {
                JSCodeUtility.screenCapture(cc.director.getRunningScene(), cc.size(JSVisibleSize.width, JSVisibleSize.height), true, "ShareImage.jpg", cc.IMAGE_FORMAT_JPEG, () => {
                        var filePath = JSWriteablePath + "ShareImage.jpg";
                        GSOpenAppWrapper.shareImage(filePath);
                    }
                );
            },
            () => {
                // 截圖並存到相簿
                GSCaptureToAlbumWrapper.captureScreen((isSuccess, errorType) => {
                    AlertDialog.showAlert(isSuccess ? "儲存成功" : "儲存失敗 errorType:" + errorType);
                });
            },
            () => {
                var shareMsg = "https://www.yahoo.com.tw";
                if (GSOpenAppWrapper.shareMessageByFBMessager(shareMsg)) {
                    // 沒有做事
                } else {
                    // 失敗 沒有App 要導去下載
                    var url;
                    if (cc.sys.os === cc.sys.OS_IOS)
                        url = "https://apps.apple.com/tw/app/messenger/id454638411";
                    else
                        url = "https://play.google.com/store/apps/details?id=com.facebook.orca&hl=zh_TW";
                    cc.sys.openURL(url);
                }
            },
            () => {
                var texture = JSCodeUtility.screenCapture(cc.director.getRunningScene(), cc.size(JSVisibleSize.width, JSVisibleSize.height), true, "ShareImage.jpg", cc.IMAGE_FORMAT_JPEG, () => {
                    if (texture) {
                        var shareFunc = () => {
                            var fileName = JSWriteablePath + "ShareImage.jpg";
                            GSFacebookHelper.share({
                                dialog: "sharePhoto",
                                photo: fileName
                            }, () => {
                                // callback結束 目前不做事
                            });
                        };
                        GSFacebookHelper.login((type, param) => {
                            if (type === 0) {
                                // 開始分享圖片
                                shareFunc();
                            } else if (type === 1 && cc.sys.isNative) {
                                GSFacebookHelper.showError(param);
                            }
                        });
                    }
                });
            },
            () => {
                var shareFunc = () => {
                    GSFacebookHelper.share({
                        dialog: "messageLink",
                        link: "http://www.yahoo.com.tw",
                        quote: "Yahoo!"
                    }, () => {
                        // callback結束 目前不做事
                    });
                };
                if (GSFacebookHelper.isLoggedIn()) {
                    // 已登入過 開始走分享圖片
                    shareFunc();
                } else {
                    GSFacebookHelper.login((type, param) => {
                        if (type === 0) {
                            // 開始分享圖片
                            shareFunc();
                        } else if (type === 1 && cc.sys.isNative) {
                            GSFacebookHelper.showError(param);
                        }
                    });
                }
            }
        ];

        var btnSize = this._testBtnSize;

        // 按鈕
        var pos;
        for (var i = 0; i < len; i++) {
            var posX = (i % 2 === 0) ? 234 : 80;
            var posY = Math.floor(i / 2) * 30 + 20;
            pos = cc.p(posX, posY);

            var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", btnSize, titleArray[i], 12);
            var btn = new GSControlButton(itemNodes[0]);
            btn.addTouchUpInsideAction(callbackFuncs[i], this);
            btn.setPosition(this._grayNodeWidth - pos.x, pos.y);
            grayNode.addChild(btn);
        }

        // 加入說明按鈕
        this._createInfoBtn(grayNode, "如果點了沒反應 請先確認有沒有安裝該app");
    },

    /**
     * 加上儲值測試功能
     */
    _addPurchaseTest: function () {
        // 加灰底
        var grayNodeHeight = 50;
        var grayNode = this._createGrayNode(grayNodeHeight);

        // 標題
        var title = new cc.LabelTTF(JSStringUtility.format("儲值productID"), JSFontBoldName, 12);
        title.setPosition(24, grayNodeHeight / 2);
        title.setAnchorPoint(0, 0.5);
        grayNode.addChild(title, 1);

        var editBoxSize = cc.size(185, 20);
        var editBoxSp1 = new ccui.Scale9Sprite("select_01.png");
        var editBoxSp2 = new ccui.Scale9Sprite("select_01.png");
        editBoxSp2.setColor(JSColor.GRAY);
        var pidEditBox = new cc.EditBox(editBoxSize, editBoxSp1, editBoxSp2);
        pidEditBox.setPosition(110, grayNodeHeight / 2);
        pidEditBox.setFontColor(JSColor.BLACK);
        pidEditBox.setFontName(JSFontName);
        pidEditBox.setReturnType(cc.KEYBOARD_RETURNTYPE_DONE);
        pidEditBox.setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE);
        pidEditBox.setMaxLength(200);
        pidEditBox.setPlaceHolder("productID");
        pidEditBox.setPlaceholderFont(JSFontName, 12);
        pidEditBox.setAnchorPoint(0, 0.5);
        grayNode.addChild(pidEditBox);

        // 按鈕
        var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", this._testBtnSize, "儲值", 12);
        var switchPurchaseBtn = new GSControlButton(itemNodes[0]);
        switchPurchaseBtn.addTouchUpInsideAction(function () {
            DataModal.purchaseData.sendPurchase(pidEditBox.getString());
        }, this);

        switchPurchaseBtn.setPosition(this._grayNodeWidth - 80, grayNodeHeight / 2);
        grayNode.addChild(switchPurchaseBtn);

        // 加入說明按鈕
        this._createInfoBtn(grayNode, "用來測試顯示金額以及pid存不存在(非測試帳號不要儲值會真的扣款)");
    },

    /**
     * 加上自送CMD功能
     */
    _addSendCMDTest: function () {
        // 加灰底
        var grayNodeHeight = 50;
        var grayNode = this._createGrayNode(grayNodeHeight);

        // 標題
        var title = new cc.LabelTTF(JSStringUtility.format("送CMD給自己"), JSFontBoldName, 12);
        title.setPosition(24, grayNodeHeight / 2);
        title.setAnchorPoint(0, 0.5);
        grayNode.addChild(title, 1);

        var editBoxSize = cc.size(185, 20);
        var editBoxSp1 = new ccui.Scale9Sprite("select_01.png");
        var editBoxSp2 = new ccui.Scale9Sprite("select_01.png");
        editBoxSp2.setColor(JSColor.GRAY);
        var pidEditBox = new cc.EditBox(editBoxSize, editBoxSp1, editBoxSp2);
        pidEditBox.setPosition(110, grayNodeHeight / 2);
        pidEditBox.setFontColor(JSColor.BLACK);
        pidEditBox.setFontName(JSFontName);
        pidEditBox.setReturnType(cc.KEYBOARD_RETURNTYPE_DONE);
        pidEditBox.setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE);
        pidEditBox.setMaxLength(-1);
        pidEditBox.setPlaceHolder("CMD");
        pidEditBox.setPlaceholderFont(JSFontName, 12);
        pidEditBox.setAnchorPoint(0, 0.5);
        grayNode.addChild(pidEditBox);

        // 按鈕
        var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", this._testBtnSize, "送CMD", 12);
        var sendCMDBtn = new GSControlButton(itemNodes[0]);
        sendCMDBtn.addTouchUpInsideAction(function () {
            var cmd = pidEditBox.getString();
            if (cmd && cmd.length)
                DataProcess.sendCustomStringToSelf(pidEditBox.getString());
            else
                DialogManager.addDialog(new Dialog({content: "請輸入CMD!!"}));
        }, this);

        sendCMDBtn.setPosition(this._grayNodeWidth - 80, grayNodeHeight / 2);
        grayNode.addChild(sendCMDBtn);

        // 加入說明按鈕
        this._createInfoBtn(grayNode, "用來送CMD給Client");
    },

    /**
     * 按鈕
     */
    // 強制白帳號點擊
    _accountBtnClicked: function () {
        // 更改強制白帳號
        DataModal.debugTestData.isForceWhiteAccount = !DataModal.debugTestData.isForceWhiteAccount;

        // 踢回登入大廳
        cc.director.runScene(new LoginScene());
    },

    // 引導按鈕點擊
    _bannerBtnClicked: function () {
        // 跳清單的Callback
        var listDialogCallback = clickedIdx => {
            // 記下點選索引
            this._bannerIdx = clickedIdx;
            // 更改按鈕文字
            this._bannerNode.label.setString(this._bannerList[clickedIdx]);
            // 導引
            PushLayerHelper.pushLayer("", this._bannerIdxArray[clickedIdx]);
        };

        // 跳清單
        DialogManager.addDialog(new SelectItemListDialog(this._bannerList, this._bannerIdx, listDialogCallback));
    },

    /**
     * 點擊Slot機台
     */
    _smClicked: function () {
        DialogManager.addDialog(this._createSelectItemDialogWithScrollBar(this._smNameArray, DataModal.debugTestData.testLayerSelectSlotIdx, (index) => this._goVegasSlot(index)));
    },

    // LogView選單點擊
    _logViewBtnClicked: function () {
        // 打開View選單
        var notificationNode = cc.director.getNotificationNode();

        // 已顯示就關閉
        if (notificationNode.getChildByName("LogView")) {
            notificationNode.removeChildByName("LogView");

            // 更改按鈕文字
            this._logViewNode.label.setString("點我開啟");
        } else {
            // 沒有加過再加
            var logView = new LogView();
            notificationNode.addChild(logView, -1, "LogView");

            if (!cc.sys.isNative) {
                // Html去讀別的套件
                if (typeof (eruda) === 'undefined') {
                    GS.loadJSFile("//g.mwsrv.com/p1h5/share/thirdLibrary/eruda.js", () => {
                        eruda.init();

                        // 他只有override console 要把他再指給cc.log
                        cc.log = console.log;
                    });
                }
            }

            // 更改按鈕文字
            this._logViewNode.label.setString("點我關閉");
        }
    },

    // 刮刮卡點擊
    _scratchCardBtnBtnClicked: function () {
        if (!cc.sys.isNative) {
            cc.error("Error:只適用native");
            return;
        }

        // 抓刮刮卡資料
        var scratchCardData = DataModal.scratchCardShopData;
        var cardList = scratchCardData.shopList;

        // 將Client版本都改成0
        var setCardClientVersion = scratchCardData.setCardClientVersion;
        cardList.forEach(param => setCardClientVersion(param, 0));

        // 把全部下載的 刮刮卡 砍掉
        var savePath = scratchCardData.getCardSavePath();
        if (jsb.fileUtils.isDirectoryExist(savePath)) {
            jsb.fileUtils.removeDirectory(savePath);
        }

        // 踢回登入大廳
        DataModal.loginData.logout();
    },

    // 推播測試
    _localNotificationBtnClicked: function () {
        // 抓推播內容 跟 秒數
        var msg = this._msgEditBox.getString();
        var trigger = this._timeEditBox.getString();

        // 如果都有資料的話
        if (msg && trigger.match(/^\d+$/)) {
            var stopTime = 0;
            var startTime = 8;

            // 送推播資料
            JSNotify.scheduleNotify({
                msg: msg,
                id: JSNotify.key.TEST_MAIN,
                trigger: trigger,
                stopTime: stopTime * 3600,
                startTime: startTime * 3600
            });
            AlertDialog.showAlert(null, JSStringUtility.format("%d秒後有推播！\n請將App切換至背景或關閉\n(在%02d點~%02d點不會推播喔！)", trigger, stopTime, startTime));
        } else {
            AlertDialog.showAlert(null, "請輸入正確的推播秒數與內容！");
        }
    },

    // 推播清單
    _localListBtnClicked: function () {
        var callback = (idx) => {
            var param = DataModal.localNotificationData.notifyMapObject[this._localNotificationList[idx]];
            var endTime = param.socketTime + param.trigger * 1000;
            var str =  "手機本地推播時間:\n" + new Date(endTime).toString() + "\n\n";
            str += JSON.stringify(param, null, "    ");
            AlertDialog.showAlert(null, str);
        };
        // 跳清單
        DialogManager.addDialog(new SelectItemListDialog(this._localNotificationList, 0, callback));
    },

    // 廣告點擊
    _movieAdBtnClicked: function () {
        // 是否可播放廣告
        if (GSIronSourceWrapper.getHaveRewardedVideo()) {
            // 開始播放廣告
            GSIronSourceWrapper.showRewardedVideo(
                (result) => {
                    switch (result) {
                        case GSIronSourceWrapper.Result.CLOSE_AND_GET_AWARD:
                        case GSIronSourceWrapper.Result.GET_AWARD_AFTER_CLOSE:
                            AlertDialog.showAlert(null, "廣告有看完，可領獎");
                            break;
                        case GSIronSourceWrapper.Result.CLOSE:
                            AlertDialog.showAlert(null, "廣告沒看完");
                            break;
                        case GSIronSourceWrapper.Result.FAILED_TO_START_AD:
                            AlertDialog.showAlert(null, "播放廣告失敗");
                            break;
                    }
                },
                MusicUtility
            );
        } else {
            // 廣告商沒有提供影片可以看 跳dialog
            AlertDialog.showAlert(null, "目前沒有影片可以觀看");
        }
    },

    /**
     * 刪除機台功能
     */
    _deleteSlotClick: function () {
        if (!cc.sys.isNative) {
            cc.error("Error:只適用native");
            return;
        }

        var cb = index => {
            var msg;
            switch (index) {
                case 0:
                    // 把全部下載的 slot 說明圖砍掉
                    if (jsb.fileUtils.isDirectoryExist(CommonUtility.slotsSavePath)) {
                        jsb.fileUtils.removeDirectory(CommonUtility.slotsSavePath);
                    }
                    msg = "全部 slot 下載的賠付表(說明圖)皆已刪除！";
                    break;

                case 1:
                    // 直接刪全部機台檔案，沒有該機台也會執行
                    this._smArray.forEach(slotName => VegasDownloadManager.deleteDownloadedBundle(slotName));
                    msg = "全部 slot 機台資源包皆已刪除！";
                    break;

                default:
                    // 直接刪機台檔案，沒有該機台也會執行
                    var slotName = this._smArray[index - this._smArrayOffset];    // 這裡 要扣掉額外項目數字,才會回到正確的 index
                    VegasDownloadManager.deleteDownloadedBundle(slotName);
                    msg = slotName + "資源包已刪除！";
            }

            // 記下點選索引
            this._smDeleteIdx = index;

            DialogManager.addDialog(new Dialog({content: msg}));
        };

        // 根據遊戲跳清單
        DialogManager.addDialog(this._createSelectItemDialogWithScrollBar(this._smDeleteArray, this._smDeleteIdx, cb));
    },

    // 前往slot機台
    _goVegasSlot: function (smIdx) {
        // 記下點選索引
        DataModal.debugTestData.testLayerSelectSlotIdx = smIdx;

        var smArray = this._smArray;

        // 更新機台編號欄位
        var slotNum = JSCodeUtility.getIntValue(smArray[smIdx].replace("Slot_", ""));
        this._slotNumEditBox.setString(smArray[smIdx].replace("Slot_", ""));

        // 進去機台
        var slotName = smArray[smIdx];
        var theSlot = DataModal.vegasData.getVegasMachineByName(slotName);
        if (theSlot) {
            LobbySelectGameSetting.goToVegasMachineBy({
                lockVip: false,
                toCustomOpenPage: "DebugTestLayer",
                slotName: slotName,
                machineType: theSlot.type > 100 ? VegasGameType[slotName] : theSlot.type,
                chooseAreaState: theSlot.chooseAreaState
            });
        } else {
            DialogManager.addDialog(new CommonDialog({
                title: this._smNameArray[smIdx],
                content: "vegas_lobby尚未開放此機台！\n\n若目前測試區不支援此機台#!FFFF00!#直接加會炸#!FFFFFF!#哦！",
                buttons: ["先等等", "直接加"],
                callback: (index) => {
                    if (index === 1) {
                        var machineType = slotNum;
                        if (slotNum > 100) {
                            // 機台
                            machineType = VegasGameType[slotName];
                        } else if (slotName.indexOf("Multi") >= 0) {
                            // 多人機台
                            machineType = slotName.toUpperCase();
                            machineType = machineType.replace("MULTI", "MULTI_");
                            machineType = VegasGameType[machineType];
                        }

                        // 跳過vegas_lobby檢查直接加
                        var param = {
                            lockVip: false,
                            toCustomOpenPage: "DebugTestLayer",
                            slotName: slotName,
                            machineType: machineType
                        };
                        LobbySelectGameSetting.goToVegasDownloadMachineBy(param);
                    }
                }
            }));
        }
    },

    /**
     * 所有Banner 引導說明
     * 可去 LobbyBannerMode 檢查是否有更新
     */
    LOBBY_BANNER_MODE_INFO: {
        0: "無",
        1: "儲值",
        2: "活動",
        3: "馬上玩",
        4: "商城",
        5: "設定",
        7: "外連",
        8: "比賽桌",
        10: "21點",
        11: "普通遊戲桌列表",
        12: "特殊遊戲桌列表",
        13: "在遊戲內開URL",
        20: "公會",
        29: "SNG大廳(LuxyPoker)",
        31: "娛樂城 Bonus",
        37: "好友專區",
        43: "客服中心(回報結果頁)",
        45: "娛樂城 骰寶",
        69: "娛樂城 魚蝦蟹",
        75: "娛樂城 水果拉霸",
        76: "娛樂城 黃金拉霸",
        82: "天梯",
        85: "娛樂城 5PK",
        91: "鑽石賽大廳(LuxyPoker)",
        92: "VIP中心",
        103: "娛樂城 百家樂",
        104: "娛樂城 足球機台",
        115: "Koin Luxy",
        116: "金庫寶箱(Domino)",
        118: "熊貓機台",
        122: "週任務(Domino)",
        126: "Gaple淘汰賽大廳(Domino)",
        129: "TebakQQ比牌機台(Domino)",
        132: "裂變活動",
        141: "大樂彩 主頁",
        142: "大樂彩 購買頁面",
        145: "娛樂城 熱力海灘(25線)",
        147: "引導Slot機台",
        146: "娛樂城 Vip貴賓廳",
        149: "積分系統(Poin)",
        152: "大富翁(Domino)",
        155: "累積儲值活動(Domino)",
        158: "娛樂城-金銀島",
        159: "恭喜發財拉霸(Domino)",
        167: "幸運轉輪/轉輪儲值(Domino)",
        168: "集點卡(Domino)"
    }
});