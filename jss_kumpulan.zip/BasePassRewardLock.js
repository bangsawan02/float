/**
 * 通行證 - 獎勵 node 鎖頭
 * @param {BasePassRewardLock.TYPE}     type        鎖頭類型
 * @param {string}                      fileName    檔名
 */
var BasePassRewardLock = cc.Node.extend({
    ctor: function (type = BasePassRewardLock.TYPE.SPINE, fileName = "spine/luxyPass/luxyPass_ani_lock") {
        this._super();

        this._fileName = fileName;

        this.setAnchorPoint(0.5, 0.5);

        let createMap = {};
        createMap[BasePassRewardLock.TYPE.SPRITE] = this._createSprite.bind(this);
        createMap[BasePassRewardLock.TYPE.SPINE] = this._createSpine.bind(this);

        createMap[type] && createMap[type]();
    },

    /**
     * Create a sprite.
     * @private
     */
    _createSprite: function () {
        let sprite = this._sprite = new cc.Sprite("#lobby_pic_profile_lock.png");
        this.setContentSize(sprite.getContentSize());
        sprite.setPosition(this.getContentSize().width / 2, this.getContentSize().height / 2);
        this.addChild(sprite);
    },

    /**
     * Create a spine.
     * @private
     */
    _createSpine: function () {
        // 動態鎖頭
        GSSpine.create(this._fileName, 0.25, (spine) => {
            this._spine = spine;
            this.addChild(spine);
        });
    },

    /**
     * Reset the spine to the default state.
     */
    resetSpine: function () {
        if (this._spine) {
            this._spine.clearTracks();
            this._spine.setToSetupPose();
        }
    },

    /**
     * 播放 Spine 動畫
     * @param {int}     trackIndex  The index of the animation track.
     * @param {string}  name        The name of the animation
     * @param {boolean} isLoop      是否重複播放
     */
    setAnimation: function (trackIndex, name, isLoop) {
        this._spine && this._spine.setAnimation(trackIndex, name, isLoop);
    },

    /**
     * 設定完成監聽
     * @param {function} callback
     */
    setCompleteListener: function (callback) {
        this._spine && this._spine.setCompleteListener(callback);
    },
});
BasePassRewardLock.TYPE = {
    SPRITE: 0,
    SPINE: 1,
};