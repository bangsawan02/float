/**
 * Cangkulan 用來撥放Player上面出現的動畫
 */

var Cangkulan_PlayerAnimLayer = cc.Layer.extend({
    ctor: function () {
        this._super();
        this.setCascadeOpacityEnabled(true);

        this._animNodeArray = [];
        for (var i = 0; i < DataModal.gameData.playerNumber; i++) {
            // 在玩家身上的動畫都會放在這裡
            var animNode = this._animNodeArray[i] = new Cangkulan_PlayerAnimNode();
            animNode.setPosition(Cangkulan_GameUtility.getPlayerPosition(i));
            this.addChild(animNode);
        }
    },

    clean: function () {
        this._animNodeArray.forEach(aniNode => aniNode.clean());
    },

    /**
     * 撥放玩家上面的動畫
     * @param serverPos 位置
     * @param type 哪一種動畫 Cangkulan_PlayerAnimNode.Type
     * @param value 這動畫有帶參數的話需要
     */
    playAnimation: function (serverPos, type, value) {
        var playerPos = DataModal.gameData.getDirectionByServerDirection(serverPos);
        var aniNode = this._animNodeArray[playerPos];
        switch (type) {
            case Cangkulan_PlayerAnimNode.Type.SIT:
                aniNode.playSitAnim();
                break;
            case Cangkulan_PlayerAnimNode.Type.GET_CHIPS:
                aniNode.playGetChips(value);
                break;
            case Cangkulan_PlayerAnimNode.Type.EXP:
                aniNode.playExp(value);
                break;
            case Cangkulan_PlayerAnimNode.Type.LEVEL_UP:
                aniNode.playLevelUp(value);
                break;
            case Cangkulan_PlayerAnimNode.Type.GAME_RANK_SCORE_CHANGE:
                aniNode.playGameRankScoreChange(value);
                break;
            case Cangkulan_PlayerAnimNode.Type.WIN:
                aniNode.playWinAnim();
                break;
            case Cangkulan_PlayerAnimNode.Type.SHOW_CARD:
                aniNode.playShowCard(value, playerPos);
                break;
            case Cangkulan_PlayerAnimNode.Type.SCORE:
                aniNode.playScoreAnim(value, playerPos);
                break;
            case Cangkulan_PlayerAnimNode.Type.BELL:
                aniNode.playBellAnim(playerPos);
                break;
        }
    },
});