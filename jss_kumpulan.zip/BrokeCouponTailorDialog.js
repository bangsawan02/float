/**
 * 破產再儲值 量身定做方案
 */

var BrokeCouponTailorDialog = BaseDialogLayer.extend({
    ctor: function () {
        this._super();

        this.key = "BrokeCouponTailorDialog";

        var aniLayer = this._animationLayer;

        var tailorArray = DataModal.purchaseCouponData.brokeCoupon.tailorArray;

        // 背景底
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(cc.size(322, 210));
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite, -1);

        // 光
        var lightSprite = new cc.Sprite("#lobby_pic_pink_light.png");
        lightSprite.setScale(100, 50);
        lightSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(lightSprite, -1);

        // Avatar
        var avatarNode = null;
        if (GS.useSpineAvatar) {
            var spineArray = [
                SelectGameManager.getNowGameFile("avatar_domino_half.json"),
                SelectGameManager.getNowGameFile("avatar_domino_half.atlas"),
                SelectGameManager.getNowGameFile("avatar_domino_half.png")
            ];
            avatarNode = new cc.Node();
            avatarNode.setScale(GS.isLuxyPoker ? 0.85 : 1);
            avatarNode.setPosition(150 + JSScreenBonusHalfWidth, (GS.isLuxyPoker ? 140 : 30) + JSScreenBonusHalfHeight);
            aniLayer.addChild(avatarNode);

            var addSpineAvatar = function () {
                var avatar = new sp.SkeletonAnimation(spineArray[0], spineArray[1], 0.25);
                avatar.setAnimation(0, 'animation', true);
                avatarNode.addChild(avatar);
            };
            if (!cc.sys.isNative) {
                // H5要先去讀
                cc.loader.load(spineArray, function (a, b) {
                    addSpineAvatar();
                });
            } else {
                // 原生不用讀
                addSpineAvatar();
            }
        } else {
            // 5.5.8改看板娘有額外調整(之後如果要改回原版看板娘要再調整回去)
            avatarNode = new cc.Sprite(SelectGameManager.getNowGameFile("common_avatar.png"));
            avatarNode.setScale(GS.isLuxyPoker ? -0.52 : 0.55, GS.isLuxyPoker ? 0.52 : 0.55);
            avatarNode.setAnchorPoint(JSAnchorPoint.M_BOTTOM);
            avatarNode.setPosition(144 + JSScreenBonusHalfWidth, 44 + JSScreenBonusHalfHeight);
            aniLayer.addChild(avatarNode, -1);
        }

        // 標題
        var titleLabel = new cc.LabelTTF(LocalizedString.PurchaseCoupon("為您量身定做的專屬方案"), JSFontName, 16);
        titleLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        titleLabel.setPosition(301 + JSScreenBonusHalfWidth, 220 + JSScreenBonusHalfHeight);
        titleLabel.enableStroke(JSColor.BLACK, 2);
        titleLabel.setFontFillColor(cc.color(230, 200, 20));
        aniLayer.addChild(titleLabel);

        var nodeSize = cc.size(100, 150);
        ["lobby_btn_03.png", "lobby_btn_01.png"].forEach((cur, index) => {
            var param = tailorArray[index];
            var posX = JSScreenMidPos.x + 45 + (index - 0.5) * (nodeSize.width + 5);
            var posY = JSScreenMidPos.y - 20;

            // 背景
            var bgSprite = new ccui.Scale9Sprite("lobby_bg_gold_black.png");
            bgSprite.setPreferredSize(nodeSize);
            bgSprite.setPosition(posX, posY);
            aniLayer.addChild(bgSprite);

            // 籌碼
            var chipSprite = new cc.Sprite(JSStringUtility.format("#broke_coupon_chips_%d.png", index + 1));
            chipSprite.setPosition(posX, posY + 25);
            aniLayer.addChild(chipSprite);

            // 儲值按鈕
            var btnString = JSStringUtility.format("Rp. %s", param.payMoney);
            var purchaseBtn = ButtonUtility.createSimpleButton(cur, cc.size(nodeSize.width - 20, 30), btnString, JSColor.WHITE, 12);
            purchaseBtn.setPosition(posX, posY - 15);
            purchaseBtn.index = index;
            purchaseBtn.param = param;
            purchaseBtn.addTouchUpInsideAction(this._purchaseClicked, this);
            aniLayer.addChild(purchaseBtn);

            // 文字
            var string = JSStringUtility.format(LocalizedString.PurchaseCoupon("獲得\n%s"), JSCodeUtility.getCurrencyString(param.chips));
            var label = new cc.LabelTTF(string, JSFontName, 10);
            label.setPosition(posX, posY - 45);
            label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            aniLayer.addChild(label);

            if (index === 1) {
                // 緞帶
                var ribbonSprite = new cc.Sprite("#lobby_bg_countdownTag.png");
                ribbonSprite.setPosition(posX - 6, posY + 60);
                aniLayer.addChild(ribbonSprite);

                // 文字
                var saleLabel = new cc.LabelTTF(LocalizedString.PurchaseCoupon("SALE"), JSFontName, 12);
                saleLabel.setPosition(posX - 6, posY + 60);
                aniLayer.addChild(saleLabel);

                // 金額排版的node
                var autoLayoutNode = new GSAutoLayoutNode();
                autoLayoutNode.setScale(0.375);
                autoLayoutNode.setSpace(-14);
                autoLayoutNode.setPosition(posX, posY + 15);
                aniLayer.addChild(autoLayoutNode);

                // 金額
                ["+", "2", "0", "%", "!"].forEach(cur => {
                    var numberSprite = new cc.Sprite(JSStringUtility.format("#broke_coupon_number_%s.png", cur));
                    autoLayoutNode.addChild(numberSprite);
                });
            }
        });

        // 關閉按鈕
        var closeBtn = ButtonUtility.createSimpleImageButton("lobby_btn_circle_04.png", undefined, "#lobby_btn_pic_window_x.png");
        closeBtn.setPosition(JSScreenMidPos.x + 156, JSScreenMidPos.y + 100);
        closeBtn.addTouchUpInsideAction(this._closeClicked, this);
        aniLayer.addChild(closeBtn);

        GS.addListener("NotifyPurchaseSuccess", this.notifyPurchaseSuccess.bind(this), this);
    },

    onEnter: function () {
        this._super();

        // 紀錄已經跳過
        DataModal.purchaseCouponData.brokeCoupon.showTailor = false;

        // 埋點
        DataProcess.sendString("broke_login_payment_click 1");
    },

    keyBackPressed: function () {
        this._closeClicked();
    },

    /**
     * 按鈕
     */
    // 點擊關閉按鈕
    _closeClicked: function () {
        var purchaseCouponString = LocalizedString.PurchaseCoupon;

        DialogManager.addDialog(new Dialog({
            content: purchaseCouponString("確定要放棄專屬給你的優惠？"),
            buttons: [purchaseCouponString("放棄"), purchaseCouponString("再想想")],
            callback: (index) => {
                if (index === 0)
                    this._closeDialogAnimation();
            }
        }), false);
    },

    // 點擊儲值按鈕
    _purchaseClicked: function (sender) {
        var param = sender.param;
        if (!param)
            return;

        // 判斷是否開第三方 超過一個要開管道多選dialog
        var productList = param.productIDList;

        if (productList.length === 1)
        // 只有一個 送儲值
            DataModal.purchaseData.sendPurchase(productList[0]);
        else if (productList.length > 1)
        // 一個以上開選擇dialog
            DialogManager.addDialog(new ProviderChooseDialog(param), false);

        // 儲值按鈕埋點
        DataProcess.sendString(JSStringUtility.format("broke_login_payment_click %d", sender.index + 1));
    },

    /**
     * 通知
     */
    // 通知儲值成功
    notifyPurchaseSuccess: function () {
        // 沒有顯示的時候不處理
        if (!this.isVisibleRecursive())
            return;

        this._closeDialogAnimation();
    },
});