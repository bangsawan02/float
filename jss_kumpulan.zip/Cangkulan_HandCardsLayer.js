/**
 * Cangkulan 自家的手牌
 */
var Cangkulan_HandCardsLayer = cc.Layer.extend({
    SHAKE_CARD_ACTION_TAG: 7426,

    ctor: function () {
        this._super();

        // 自己手牌的位置
        this._handCardBasePos = cc.p(JSScreenMidPos.x - Cangkulan_HandCardPosX, Cangkulan_HandCardPosY);

        // 設定其他參數
        this.clean();

        // 加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this._onTouchBegan.bind(this)
        }, this);

        // 監聽
        GS.addListener("NotifyGameShakeCard", this.notifyGameShakeCard.bind(this), this);
        GS.addListener("NotifyGamePlayerCountDownFinish", this.notifyGamePlayerCountDownFinish.bind(this), this);
        GS.addListener("NotifyGameShowDrawCard", this.notifyGameShowDrawCard.bind(this), this);
        GS.addListener("NotifyGameShowFirstHint", this.notifyGameShowFirstHint.bind(this), this);
    },

    clean: function () {
        // 自己的手牌張數
        this._handCardCount = 0;
        // 清空手牌
        this._handCardArray && this._handCardArray.forEach(cur => cur.card.removeFromParent());
        this._handCardArray = [];

        // 手牌的間隔
        this._cardOffsetX = Cangkulan_HandCardOffsetX;
        // 最一張牌的位置(預設第一張牌)
        this._handCardPosX = this._handCardBasePos.x - this._cardOffsetX;

        // 是否要晃動手牌
        this._needShakeCard = false;

        // 是否可以Touch
        this._canTouch = false;
        // 當下是不是棄牌階段
        this._isFold = false;

        // 清空點選的牌
        this._touchedCard = null;
        // 清空抽到牌區抽的牌
        this._drawCardObj = null;

        // 預設不能攤牌
        this._isChangeOffset = false;

        // 清空指定棄牌
        this.setFoldSuit(null);
    },

    /**
     * 設定是棄牌階段
     * @param isFold
     */
    setHandCardStatus: function (isFold, isDraw) {
        // 設定棄牌狀態
        this._isFold = isFold;
        this.setTouch(isFold, isDraw);
    },

    /**
     * 設定手牌可點擊(棄牌階段)
     * @param isTouch
     */
    setTouch: function (isTouch, isDraw) {
        // 確認手牌哪些是可以點的
        this._handCardArray.forEach(cur => {
            // 有指定的棄牌花色 or 當前沒有指定的花色  都是可以點擊的
            cur.isTouch = cur.suit === this._foldSuit || !this._foldSuit;

            // 自己抽牌: 灰階 不可點擊
            // 自己丟牌時: 灰階 可點擊狀態
            // 其他玩家出牌時: 亮起手牌 不可點擊
            cur.card.setGray(isDraw || !cur.isTouch && isTouch);
        });

        if (isTouch) {
            // 非首輪決策者 不是抽牌的情況下
            if (this._foldSuit && !this._touchedCard) {
                // 玩家可出牌的數量
                var canTouchHandCard = this._handCardArray.filter(cur => cur.isTouch);
                // 玩家手上可出的花色數量剩1張要提起此牌
                this._touchedCard = (canTouchHandCard.length === 1) ? canTouchHandCard[0].card : null;
            }

            // 手牌可以點的時候確認可出的牌要不要拉大間距
            this._sortCardsByPosition(true, true);

            // 等手牌都排序好才打開手牌點擊
            this.runAction(cc.sequence(
                cc.delayTime(0.3),
                cc.callFunc(() => {
                    if (this._touchedCard)
                        GS.dispatchCustomEvent("NotifyGameUISetMenuStatus", Cangkulan_UILayer.DecisionStatus.CAN_FOLD);
                    this._canTouch = true;
                })));
        } else
            this._canTouch = false;
    },

    /**
     * 設定棄牌指定的花色
     * @param foldCardSuit : 棄牌花色
     */
    setFoldSuit: function (foldCardSuit) {
        // 沒有指定花色就是任意牌都可以丟
        this._foldSuit = (foldCardSuit) ? Cangkulan_CardSuit[foldCardSuit[0]] : null;
    },

    /**
     * 理牌
     * @param isAction : 要不要演移動的動畫
     */
    sortHandCards: function (isAction) {
        // 排序 黑桃>愛心>梅花>方塊 數字 大>小
        this._handCardArray.sort((a, b) => b.sortSuit - a.sortSuit);

        // 把手牌排序一下
        this._sortCardsByPosition(isAction, this._canTouch);
    },

    /**
     * 先把抽到的牌放入手牌中 並回傳那張牌在手牌中的位置
     * @param obj
     * @returns {number|*}
     */
    getDrawCardPosByHandCard: function (obj) {
        // 產生一張牌
        this.addCard(obj);

        // 回傳在手牌中的位置
        return this._drawCardObj.card.getPosition();
    },

    /**
     * 取得要棄的牌
     * @returns {*|number|BigInt|string}
     */
    getFoldCard: function () {
        // 停止搖晃
        if (this._needShakeCard)
            this._stopSakeCards();

        if (this._touchedCard)
            return this._touchedCard.cardNumber;
    },

    /**
     * 加手牌
     */
    addCard: function (obj) {
        var index = this._handCardCount++;
        var handCard = new Cangkulan_CardNode(obj.card);
        handCard.setPosition(this._handCardPosX += this._cardOffsetX, this._handCardBasePos.y);
        this.addChild(handCard, index);

        // 手牌的資訊
        var cardObj = {
            // 牌本體
            card: handCard,
            // 依造花色大->小  數字大->小 排序的編號
            sortSuit: handCard.getCounterBySuit(),
            // 花色的編號
            suit: handCard.getSuit(),
            // 可不可以點擊
            isTouch: false
        };

        this._handCardArray.push(cardObj);

        if (obj.isDraw) {
            // 設定抽到的牌

            // 先隱藏
            handCard.setVisible(false);

            // 排序一下位置
            this._sortCardsByPosition(true, this._canTouch);

            // 抽牌區抽到的最後一張牌 (棄牌區抽出來的牌不能點擊)
            if (cardObj.suit === this._foldSuit && !obj.isFold)
                // 抽到可以出的牌要設成可點擊
                cardObj.isTouch = true;
            else
                // 抽到到不可以出的牌要壓黑
                handCard.setGray(true);

            // 記下這張牌是不是從棄牌區抽到的 (從棄牌區抽到的牌不亮起)
            cardObj.isFold = obj.isFold;

            // 先記下抽到這張牌
            this._drawCardObj = cardObj;
        }

    },

    /**
     * 直接加入整個手牌(牌局重現時)
     */
    addCardByCards: function (handCards) {
        this._handCardArray = [];
        handCards.forEach(cur => this.addCard({card: cur}));
        this.sortHandCards(false);
    },

    /**
     * 棄牌
     */
    foldCard: function (foldCard) {
        return new Promise(resolve => {
            if (this._needShakeCard)
                this._stopSakeCards();

            this._handCardCount--;
            this.setTouch(false);

            // 清空點到的牌
            this._touchedCard = null;
            // 清空需要攤開的花色
            this._sortTouchSuit = null;

            // 找出要棄的牌
            var index = this._handCardArray.findIndex(cur => cur.card.cardNumber === foldCard);
            if (index < 0)
                return;

            // 飛入棄牌區
            var card = this._handCardArray[index].card;
            this._handCardArray.splice(index, 1);
            card.runAction(cc.sequence(
                cc.moveTo(0.4, cc.pAdd(JSScreenMidPos, Cangkulan_Offset.FOLD)),
                cc.callFunc(() => {
                    // 排序手牌
                    this.sortHandCards(true);

                    // 手牌剩餘2張要顯示提示鈴鐺
                    if (this._handCardCount === Cangkulan_SHOW_BELL_COUNT)
                        GS.dispatchCustomEvent("NotifyGameShowBell", 0);

                    resolve();
                }),
                cc.delayTime(0.2),
                cc.removeSelf()
            ));
        });
    },

    /**
     * 關閉搖晃
     * @private
     */
    _stopSakeCards: function () {
        this._handCardArray.forEach(cur => {
            cur.card.stopActionByTag(this.SHAKE_CARD_ACTION_TAG);
            cur.card.setRotation(0);
        });
        this._needShakeCard = false;
    },

    /**
     * 排序手牌的位置
     * 棄牌階段 手牌數量>Cangkulan_MaxHandCard(16張) 會把牌可以出牌的間隔拉大 其他不可以打出的牌間隔變小
     * 當手牌數量<Cangkulan_DealCount(7張) 手牌會以中間點為初始位置開始放牌
     * 當手牌數量>Cangkulan_DealCount(7張) 手牌會以頭像旁邊為初始位置開始放牌
     * 其他時候會依照手牌寬度Cangkulan_HandCardWidth(300)平均分配手牌的間距
     */
    _sortCardsByPosition: function (isAction, isTouch) {
        // 計算當前手牌的間距
        this._cardOffsetX = (this._handCardCount < Cangkulan_HandCardMaxOffsetCount)
            ? Cangkulan_HandCardOffsetX
            : Cangkulan_HandCardWidth / this._handCardCount;

        // 是否要調整間距: 可以出牌 && 當前沒有抽到的牌(因為抽到可以出的牌會放在最後面) && 手牌 > 16張
        var isChangeOffset = isTouch && !this._drawCardObj && this._handCardCount > Cangkulan_MaxHandCard;

        // 預設每張牌的間隔(預設的間隔每張間隔都一樣)
        var offsetX = this._cardOffsetX;
        // 第一張牌的基準點
        var movePosX = this._handCardBasePos.x - offsetX;

        if (isChangeOffset) {
            // 需要改變間距 可出的牌：大間距 不可出的牌：小間距

            // 大間距
            var bigOffset = Cangkulan_HandCardOffsetX - 10;
            // 小間距
            var smallOffset = 0;

            // 大間距的總數長度
            var totalBigOffset = 0;
            // 拉寬間距的花色
            var choseSuit = 0;

            if (this._foldSuit) {
                // 有指定出牌花色

                // 設定需要拉寬間距的花色
                choseSuit = this._foldSuit;

                // 設定要攤牌
                this._isChangeOffset = false;
            } else {
                // 沒有指定出牌花色
                // 各花色的最後一張牌為大間距 其他牌都是縮在一起小間距

                // 找出手牌中有幾種花色 算出大間距的總和
                for (var key in Cangkulan_CardSuit) {
                    var value = Cangkulan_CardSuit[key];
                    var suitCardIndex = this._handCardArray.findIndex(cur => cur.suit === value);
                    if (suitCardIndex > -1)
                        totalBigOffset += bigOffset;
                }

                // 設定需要拉寬間距的花色
                choseSuit = this._sortTouchSuit;

                this._isChangeOffset = true;
            }

            // 找出需要拉寬間距的牌
            if (choseSuit) {
                var touchArray = this._handCardArray.filter(cur => cur.suit === choseSuit);
                var touchLen = touchArray.length;

                // 加上要扣掉的尺寸
                totalBigOffset += touchLen * bigOffset;
            }

            // 小間距的尺寸 尺寸<0就直接塞0 讓牌直接重疊 變成負數牌會反向堆疊
            smallOffset = (Cangkulan_HandCardWidth > totalBigOffset)
                ? (Cangkulan_HandCardWidth - totalBigOffset) / this._handCardCount
                : 0;

            // 目前的花色(預設第一張牌的花色)
            var nowSuit = this._handCardArray[0].suit;

            // 是不是當前的花色
            var isChoseSuit = choseSuit === nowSuit;

            // 第一張牌的位移量要用大間隔or小間隔
            offsetX = (isChoseSuit) ? bigOffset : smallOffset;
            movePosX = this._handCardBasePos.x - offsetX;
        } else {
            if (this._handCardCount < Cangkulan_DealCount) {
                // 手牌<7張時要往中間靠

                // 往中間放第一張的起始點
                var midNum = (this._handCardCount + 1) / 2;
                movePosX = JSScreenMidPos.x - midNum * offsetX;
            }
        }

        // 排序手牌的位置
        this._handCardArray.forEach((cur, index) => {
            // 牌node
            var cardNode = cur.card;

            // 抽牌後最後一張要被提起 && 可出牌花色剩最後一張要被提起 其他情況的牌都是在原位
            var movePosY = this._handCardBasePos.y;
            if (this._touchedCard === cardNode && this._foldSuit) {
                cardNode.setPositionY(movePosY += 10);
            }

            if (isChangeOffset) {
                // 牌的花色
                var curSuit = cur.suit;

                if (this._foldSuit) {
                    // 不可手動攤牌(有指定出牌的花色)

                    movePosX += (isChoseSuit) ? bigOffset : smallOffset;
                    isChoseSuit = choseSuit === curSuit;
                } else {
                    // 可手動攤牌(所有手牌都可以選擇) 該round的第一個出牌玩家

                    // 該花色的最後一張牌要拉大間距 or 當前玩家所選到的花色要拉大間距
                    movePosX += (nowSuit !== curSuit || choseSuit === curSuit) ? bigOffset : smallOffset;
                    nowSuit = curSuit;
                }
            } else {
                // 不可出牌 or 可出牌手牌數量沒有超過Cangkulan_MaxHandCard

                // 小於7張時要把排往中間靠 (基準點在中間) 其他數量以大頭照旁邊為中心開始放牌
                movePosX += offsetX;
            }

            if (isAction)
                // 移動的動畫
                cardNode.runAction(cc.moveTo(0.2, cc.p(movePosX, movePosY)));
            else
                cardNode.setPosition(cc.p(movePosX, movePosY));

            this._handCardPosX = movePosX;
            cardNode.setLocalZOrder(index);
        });
    },

    /**
     * 通知自己的倒數秒數
     */
    notifyGameShakeCard: function () {
        if (this._isFold) {
            // 棄牌階段 低於3秒手牌要震動
            this._needShakeCard = true;

            // 手牌在倒數三秒還沒出就需要搖晃
            this._handCardArray.forEach(cur => {
                // 亮的在晃
                if (cur.isTouch) {
                    var cardNode = cur.card;
                    var shakeAction = cc.repeatForever(cc.sequence(
                        cc.rotateTo(0.025, 4),
                        cc.rotateTo(0.05, -8),
                        cc.rotateTo(0.05, 4),
                        cc.rotateTo(0.025, 0)
                    ));
                    shakeAction.setTag(this.SHAKE_CARD_ACTION_TAG);

                    cardNode.stopActionByTag(this.SHAKE_CARD_ACTION_TAG);
                    cardNode.setRotation(0);
                    cardNode.runAction(shakeAction);
                }
            });
        }
    },

    /**
     * 在手牌中顯示抽到的牌
     */
    notifyGameShowDrawCard: function () {
        if (this._drawCardObj && this._drawCardObj.card) {
            var cardNode = this._drawCardObj.card;
            cardNode.setVisible(true);

            if (this._drawCardObj.isFold) {
                // 從棄牌區抽的牌只有一張 棄牌區抽到的牌不能出牌 只做理牌的動作

                // 先把牌放進手牌 讓玩家看一下抽到的牌 0.3秒後 移動排序移動手牌
                this.runAction(cc.sequence(
                    cc.delayTime(0.3),
                    cc.callFunc(() => {
                        this.setTouch(false);
                        this.sortHandCards(true);
                    })
                ));
            } else {
                // 從抽牌區抽到的牌最後一張是可以出的牌
                if (this._drawCardObj.isTouch)
                    this._touchedCard = cardNode;
            }
        }

        // 清掉抽到的牌
        this._drawCardObj = null;
    },

    /**
     * 玩家倒數結束要關閉搖晃手牌
     */
    notifyGamePlayerCountDownFinish: function () {
        if (this._needShakeCard) {
            this._stopSakeCards();
        }
    },

    /**
     * 玩牌提示步驟1、2手牌需要顯示黃框
     * @param event
     */
    notifyGameShowFirstHint: function (event) {
        var step = event && event.getUserData() || false;

        if (!step) {
            // 關閉提示框
            this._firstHintNode && this._firstHintNode.removeFromParent();
            this._firstHintNode = null;
            return;
        }

        // 打開提示框

        // 目前的玩牌提示步驟(只有步驟1、2手牌會顯示框框)
        this._firstHintStep = step;

        // 找出需要被框起來的牌
        var canTouchCardArray = this._handCardArray.filter(cur => cur.isTouch);
        var canTouchCardLen = canTouchCardArray.length;

        // 有牌可出
        if (canTouchCardLen > 0) {

            // 放提示的node
            var index = canTouchCardArray[0].card.getLocalZOrder();
            var firstHintNode = this._firstHintNode = new cc.Node();
            this.addChild(firstHintNode, index);

            // 等手牌移動完後顯示提示(當手牌可以點的時候會有一個縮牌的排序處理)
            firstHintNode.runAction(cc.sequence(cc.delayTime(0.3), cc.callFunc(() => {
                // 黃框的範圍跟位置
                var firstCardNode = canTouchCardArray[0].card;
                var firstCardPos = firstCardNode.getPosition();
                var endCardNode = canTouchCardArray[canTouchCardLen - 1].card;
                var endCardPosX = endCardNode.getPositionX();
                var width = endCardPosX - firstCardPos.x + 66;

                // 手牌的黃框
                var posY = (canTouchCardLen === 1) ? firstCardPos.y : this._handCardBasePos.y;
                var lightSp = new ccui.Scale9Sprite("cangkulan_pic_frame.png");
                lightSp.setPreferredSize(cc.size(width, 83));
                lightSp.setAnchorPoint(0, 0.5);
                lightSp.setPosition(firstCardPos.x - 33, posY);
                firstHintNode.addChild(lightSp);

                // 提示手指
                var finger = new cc.Sprite("#game_pic_finger_01.png");
                finger.setRotation(90);
                finger.setPosition(firstCardPos.x - 50, firstCardPos.y);
                firstHintNode.addChild(finger);

                // 閃框動畫 & 手指動畫
                lightSp.runAction(cc.repeatForever(cc.sequence(cc.fadeIn(0.3), cc.fadeOut(0.2))));
                finger.runAction(cc.repeatForever(cc.sequence(cc.rotateBy(0.3, -30), cc.rotateBy(0.3, 30))));
            })));
        }
    },

    /**
     * 手牌點擊事件
     * @private
     */
    _onTouchBegan: function (touch) {
        if (!this._canTouch)
            return false;

        var touchPos = this.convertToNodeSpace(touch.getLocation());

        // 因為重疊的關係index要反著找
        for (var i = this._handCardCount - 1; i >= 0; i--) {
            var cardNode = this._handCardArray[i].card;
            if (cc.rectContainsPoint(cardNode.getCardBoundingBox(), touchPos)) {
                if (!this._handCardArray[i].isTouch)
                    return false;

                var basePosY = this._handCardBasePos.y;

                // 牌太多要攤開牌
                var suitNum = this._handCardArray[i].suit;
                if (this._isChangeOffset && this._sortTouchSuit !== suitNum) {

                    // 設定需要攤開的花色
                    this._sortTouchSuit = suitNum;

                    // 點到不同花色去把牌攤開
                    this._sortCardsByPosition(true, true);

                    // 點到的牌清空
                    this._touchedCard = null;
                    GS.dispatchCustomEvent("NotifyGameUISetMenuStatus", Cangkulan_UILayer.DecisionStatus.NOT_FOLD);

                    return true;
                }

                if (this._touchedCard) {
                    // 上一張點到的牌

                    // 點到不同張牌 上一個點的牌要回到原本的位置
                    this._touchedCard.setPositionY(basePosY);

                    // 點到同一張牌 回到原位
                    if (this._touchedCard === cardNode) {
                        this._touchedCard = null;
                        GS.dispatchCustomEvent("NotifyGameUISetMenuStatus", Cangkulan_UILayer.DecisionStatus.NOT_FOLD);
                        return true;
                    }
                }

                // 玩牌提示步驟1時要顯示小手在出牌按鈕傍邊
                if (this._firstHintStep === "1") {
                    GS.dispatchCustomEvent("NotifyShowGameIntroHint");
                    this._firstHintStep = null;
                }

                // 點到要往上移
                cardNode.setPositionY(basePosY + 10);
                this._touchedCard = cardNode;

                // 出現棄牌按鈕
                GS.dispatchCustomEvent("NotifyGameUISetMenuStatus", Cangkulan_UILayer.DecisionStatus.CAN_FOLD);
                return true;
            }
        }

        return false;
    }
});
