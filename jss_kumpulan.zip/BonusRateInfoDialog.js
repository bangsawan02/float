/**
 * Bonus機台 賠率說明 頁面
 */
var BonusRateInfoDialog = BaseDialogLayer.extend({
    ctor: function () {
        this._super();

        this.key = "BonusRateInfoDialog";
        var bonusStr = LocalizedString.Bonus;

        // 用來當底的Node
        var mainNode = this._mainNode = new cc.Node();
        mainNode.setCascadeOpacityEnabled(true);
        mainNode.setPosition(JSScreenMidPos);
        this._animationLayer.addChild(mainNode);

        // 背景底
        var bgSp = this._bgSp = new ccui.Scale9Sprite("bg_slim.png");
        bgSp.setPreferredSize(cc.size(245, 172));
        mainNode.addChild(bgSp);

        // 燈光
        var bgLightSp = new cc.Sprite("#bg_light.png");
        bgLightSp.setScale(8, 5);
        mainNode.addChild(bgLightSp);

        // 線
        var lineSp = new cc.Sprite("#btn_function_line.png");
        lineSp.setScaleY(7);
        lineSp.setRotation(90);
        lineSp.setPosition(0, 56);
        mainNode.addChild(lineSp);

        // 離開按鈕
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        mainNode.addChild(menu);

        var imageStr = "#btn_close_on.png";
        var itemSprite1 = new cc.Sprite(imageStr);
        var itemSprite2 = new cc.Sprite(imageStr);
        itemSprite2.setColor(JSColor.GRAY);
        var menuItem = new cc.MenuItemSprite(itemSprite1, itemSprite2, this._closeDialogAnimation, this);
        menuItem.setPosition(107, 70);
        menu.addChild(menuItem);

        // 標題
        var bonusTitleX = -40, bonusRateX = 50, contentFontSize = 10;
        var titleLabel = new cc.LabelTTF(bonusStr("2張手牌"), JSFontBoldName, 12, cc.size(100, 20), cc.TEXT_ALIGNMENT_LEFT);
        titleLabel.setPosition(bonusTitleX, 68);
        mainNode.addChild(titleLabel);

        var rateLabel = new cc.LabelTTF(bonusStr("BONUS賠率"), JSFontBoldName, 12, cc.size(70, 20), cc.TEXT_ALIGNMENT_LEFT);
        rateLabel.setPosition(bonusRateX, 68);
        mainNode.addChild(rateLabel);

        // 三個灰階背景
        var startY = 45, biasY = 20;
        for (var i = 0; i < 3; i++) {
            var shallowSp = new ccui.Scale9Sprite("bonus_rate_table_shallow.png");
            shallowSp.setPreferredSize(cc.size(243, 20));
            shallowSp.setPosition(0, startY - (i * 2 + 1) * biasY);
            mainNode.addChild(shallowSp);
        }

        // 賠付資訊
        [
            {title: "A-A", rate: "30"},
            {title: "A-K同花", rate: "25"},
            {title: "A-Q、A-J同花", rate: "20"},
            {title: "A-K非同花", rate: "15"},
            {title: "K-K、Q-Q、J-J一對", rate: "10"},
            {title: "A-Q、A-J非同花", rate: "5"},
            {title: "2-2至10-10一對", rate: "3"}
        ].forEach((cur, idx) => {
            var posY = startY - biasY * idx;
            // 標題
            var titleLabel = new cc.LabelTTF(bonusStr(cur.title), JSFontName, contentFontSize, cc.size(100, 20), cc.TEXT_ALIGNMENT_LEFT);
            titleLabel.setOpacity(230);
            titleLabel.setPosition(bonusTitleX, posY);
            mainNode.addChild(titleLabel);

            // 賠率
            var rateLabel = new cc.LabelTTF(cur.rate, JSFontName, contentFontSize, cc.size(50, 20), cc.TEXT_ALIGNMENT_CENTER);
            rateLabel.setOpacity(230);
            rateLabel.setPosition(bonusRateX, posY);
            mainNode.addChild(rateLabel);
        });

        // 加Touch監聽是否有點到
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: false,
            onTouchBegan: this._onTouchBegan.bind(this),
            onTouchEnded: this._onTouchEnded.bind(this),
            onTouchCancelled: this._onTouchEnded.bind(this)
        }, this);
    },

    _onTouchBegan: function (touch, event) {
        var target = event.getCurrentTarget();
        for (var c = target.parent; c != null; c = c.parent) {
            if (!c.isVisible())
                return false;
        }
        return this.isVisible();
    },

    _onTouchEnded: function (touch, event) {
        var touchPos = this._mainNode.convertToNodeSpace(touch.getLocation());
        var raiseBarBoundBox = this._bgSp.getBoundingBox();

        if (!cc.rectContainsPoint(raiseBarBoundBox, touchPos)) {
            this._closeDialogAnimation();
        }
    }
});
