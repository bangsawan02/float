/**
 * 牌王獎章右邊的細節畫面
 * 用layer比較好排位置, 全部靠右對齊
 */

var CardKingMedalDetailLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 當前選的等級
        this._level = -1;

        var cardKingString = LocalizedString.CardKing;

        // 背景亮點
        var dotSprite = new cc.Sprite("#cardKing_pic_star.png");
        dotSprite.setPosition(408 + JSScreenBonusHalfWidth, 163 + JSScreenBonusHalfHeight);
        this.addChild(dotSprite);

        // 背景光芒
        var bgLightSprite = new cc.Sprite("#cardKing_pic_light_02.png");
        bgLightSprite.setScale(20, 10);
        bgLightSprite.setPosition(410 + JSScreenBonusHalfWidth, 165 + JSScreenBonusHalfHeight);
        this.addChild(bgLightSprite);

        // 背景太陽
        var sunSprite = new cc.Sprite("#cardKing_pic_light_01.png");
        sunSprite.setPosition(410 + JSScreenBonusHalfWidth, 165 + JSScreenBonusHalfHeight);
        this.addChild(sunSprite);

        // 講台
        var tableSp = new cc.Sprite("#cardKing_pic_table.png");
        tableSp.setPosition(410 + JSScreenBonusHalfWidth, 125 + JSScreenBonusHalfHeight);
        this.addChild(tableSp);

        // 中間獎章
        var medalSp = this._medalSp = new cc.Sprite();
        medalSp.setPosition(410 + JSScreenBonusHalfWidth, 165 + JSScreenBonusHalfHeight);
        this.addChild(medalSp);

        // 影子
        var shadowSp = new cc.Sprite("#cardKing_pic_shadow.png");
        shadowSp.setPosition(410 + JSScreenBonusHalfWidth, 125 + JSScreenBonusHalfHeight);
        shadowSp.setOpacity(180);
        shadowSp.setScale(2, 0.4);
        this.addChild(shadowSp);

        // 漂浮動畫
        var floatingAct = function () {
            return cc.sequence(
                cc.moveBy(1, cc.p(0, 3)).easing(cc.easeOut(1.5)),
                cc.moveBy(0.7, cc.p(0, -3)).easing(cc.easeIn(1.5)),
                cc.moveBy(0.7, cc.p(0, -3)).easing(cc.easeOut(1.5)),
                cc.moveBy(1, cc.p(0, 3)).easing(cc.easeIn(1.5))
            ).repeatForever();
        };

        medalSp.runAction(floatingAct());

        // // 明暗動畫
        // bgLightSprite.runAction(cc.sequence(
        //     cc.spawn(cc.scaleTo(2, 1.5, 1.2), cc.fadeTo(1, 255)),
        //     cc.spawn(cc.scaleTo(1, 1.2, 1), cc.fadeTo(1, 130))
        // ).repeatForever());

        // 影子比較遠要變淡變大(要配合漂浮的速度)
        shadowSp.runAction(cc.sequence(
            cc.spawn(cc.fadeTo(1, 100), cc.scaleTo(1, 2.6, 0.52)).easing(cc.easeOut(1.5)),
            cc.spawn(cc.fadeTo(0.7, 180), cc.scaleTo(0.7, 2, 0.4)).easing(cc.easeIn(1.5)),
            cc.spawn(cc.fadeTo(0.7, 210), cc.scaleTo(0.7, 1.8, 0.36)).easing(cc.easeOut(1.5)),
            cc.spawn(cc.fadeTo(1, 180), cc.scaleTo(1, 2, 0.4).easing(cc.easeIn(1.5))
            )).repeatForever()
        );

        // 牌王等級文字
        var levelSprite = new cc.Sprite("#cardKing_word_title_03.png");
        levelSprite.setPosition(402 + JSScreenBonusHalfWidth, 229 + JSScreenBonusHalfHeight);
        this.addChild(levelSprite);

        // 等級數字
        var levelNumberNode = this._levelNumberNode = new GSSpriteNumberNode({
            number: 1,
            numStr: "#num_20_",
            spW: 12,
        });
        levelNumberNode.setPosition(484 + JSScreenBonusHalfWidth, 231 + JSScreenBonusHalfHeight);
        this.addChild(levelNumberNode);

        // 下方說明
        var infoLabel = this._infoLabel = new cc.LabelTTF("", JSFontName, 10);
        infoLabel.setPosition(410 + JSScreenBonusHalfWidth, 72 + JSScreenBonusHalfHeight);
        this.addChild(infoLabel, 1);

        var btnSize = cc.size(88, 30);

        // 結算獎勵按鈕
        var rewardBtn = ButtonUtility.createSimpleButton("lobby_btn_01.png", btnSize, cardKingString("結算獎勵"), JSColor.BLACK, 10);
        rewardBtn.label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        rewardBtn.setPosition(362 + JSScreenBonusHalfWidth, 25 + JSScreenBonusHalfHeight);
        rewardBtn.setDisabledColor(JSColor.WHITE);
        rewardBtn.addTouchUpInsideAction(this._showRewardClicked, this);
        this.addChild(rewardBtn, 7);

        // 前往牌桌
        var buttonSps = [];
        for (var i = 0; i < 2; ++i) {
            var btnBg = new ccui.Scale9Sprite((i) ? "lobby_btn_04.png" : "lobby_btn_01.png");
            btnBg.setPreferredSize(btnSize);
            i === 0 && btnBg.setCascadeColorEnabled(true);

            // 文字
            var btnLabel = new cc.LabelTTF(cardKingString("前往牌桌"), JSFontName, 10);
            btnLabel.setFontFillColor(JSColor.BLACK);
            btnLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            btnLabel.setPosition(btnSize.width / 2, btnSize.height / 2);
            btnBg.addChild(btnLabel);

            buttonSps.push(btnBg);
        }
        var goBtn = this._goBtn = new cc.ControlButton(null, buttonSps[0]);
        goBtn.setPreferredSize(btnSize);
        goBtn.setBackgroundSpriteForState(buttonSps[1], cc.CONTROL_STATE_DISABLED);
        goBtn.addTargetWithActionForControlEvents(this, this._goClicked,
            cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
            cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
            cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
        goBtn.setPosition(458 + JSScreenBonusHalfWidth, 25 + JSScreenBonusHalfHeight);
        goBtn.setZoomOnTouchDown(false);
        this.addChild(goBtn, 7)
    },

    // 用牌王等級刷新
    refreshByLevel: function (level) {
        this._levelNumberNode.setNumber(level);
        this._medalSp.setSpriteFrame(TexasUtility.getCardKingMedalName(level));

        var data = DataModal.cardKingData.medalDetail[level];
        var cardKingString = LocalizedString.CardKing;

        if (data) {
            this._level = level;
            var infoStr = "";

            //開放中
            if (DataModal.cardKingData.status === CardKingData.Status.OPEN) {
                this._goBtn.setEnabled(true);
                infoStr = JSStringUtility.format(
                    "· %s : %s\n· %s : %s %s\n· %s : %s %s",
                    cardKingString("盲注桌"),
                    data.msg,
                    cardKingString("本季最高蟬聯數"),
                    TexasUtility.getSimpleMoneyString(data.thisSeasonAchieveRoundCount),
                    cardKingString("局"),
                    cardKingString("歷史最高蟬聯數"),
                    TexasUtility.getSimpleMoneyString(data.maxWinRound),
                    cardKingString("局")
                );
                this._infoLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
            }
            // 結算中
            else if (DataModal.cardKingData.status === CardKingData.Status.CALCULATING) {
                infoStr = DataModal.cardKingData.finalMsg || cardKingString("牌王系統結算中...");
                this._infoLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                this._goBtn.setEnabled(false);
            }

            this._infoLabel.setString(infoStr);
        }

    },

    // 顯示獎勵
    _showRewardClicked: function (sender) {
        // 把按鈕設定不能按
        sender.setEnabled(false);

        // 獎勵文字
        var rewardStr = DataModal.cardKingData.medalDetail[this._level].rewards.reduce((acc, curr) => {
            return (acc + ((acc) ? "\n" : "") + curr);
        }, "");

        var rewardLabel = new GSRichTextNode("", JSFontName, 12);
        rewardLabel.setDefaultTextColor(JSColor.BLACK);
        rewardLabel.setText(rewardStr, JSFontName, 12);

        // 避免超出螢幕 (410 + 7(框框寬度))
        var diff = JSVisibleSize.width - (rewardLabel.getContentSize().width / 2 + 417 + (JSScreenBonusHalfWidth * 1.5));

        var padding;

        // 框框太短要處理一下, 讓他大致在中間, 太短就沒有位移
        if (diff > 52)
            padding = 0;
        else if (diff >= 0)
            padding = 48;
        else
            padding = 48 + diff;

        // 跳出訊息
        var param = {
            mainNode: rewardLabel,
            style: BaseMessageNode.Style.WHITE_SHADOW,
            direct: BaseMessageNode.Direct.DOWN,
            arrowType: BaseMessageNode.ArrowType.STRAIGHT,
            arrowPadding: padding,
        };
        var messageNode = new BaseMessageNode(param);
        messageNode.setPosition(362 + JSScreenBonusHalfWidth, 40 + JSScreenBonusHalfHeight);
        messageNode.show();
        this.addChild(messageNode, 10);

        // 加上點到關掉畫面
        var dummyTouch = new DummyTouchLayer(JSVisibleSize);
        dummyTouch.setOnTouchCallback(() => {
            // 把訊息關掉
            messageNode.close();

            // 把按鈕打開 需delay一下 因為DummyTouch會把Touch往下傳給按鈕 又跳出來一次
            sender.runAction(cc.sequence(
                cc.delayTime(0.1),
                cc.callFunc(() => sender.setEnabled(true), this)
            ));

            dummyTouch.removeFromParent();
        });
        this.addChild(dummyTouch, 9);
    },

    // 前往牌桌
    _goClicked: function (sender, type) {
        var isTouched = (type === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || type === cc.CONTROL_EVENT_TOUCH_DOWN);
        this._goBtn.getBackgroundSpriteForState(cc.CONTROL_STATE_NORMAL).setColor(isTouched ? JSColor.GRAY : JSColor.WHITE);

        var data = DataModal.cardKingData.medalDetail[this._level];

        // 沒資料跳掉
        if (data) {
            if (type === cc.CONTROL_EVENT_TOUCH_UP_INSIDE) {
                // 埋點
                DataProcess.sendString('track_crown_king {"type":"10"}');

                var notEnoughMoney = data.needMoney - DataModal.profileData.money;
                // 夠錢
                if (notEnoughMoney <= 0) {
                    // 入桌cmd
                    var json = {
                        game: GS.isLuxyPoker ? GSEnum.Game.Texas19 : GSEnum.Game.Texas,
                        fee: data.fee,
                        playType: "casual"
                    };
                    DataProcess.sendString("mix_quickJoin " + JSON.stringify(json));

                    // 設定現在遊戲
                    DataModal.setGameData(json.game);

                    GSLoading.addLoadingView();
                } else {
                    // 跳金額不足
                    DialogManager.addDialog(new AvatarDialog(DialogHelper("RoomNoMoney", JSCodeUtility.getCurrencyString(notEnoughMoney))));
                }
            }
        }
    }
});