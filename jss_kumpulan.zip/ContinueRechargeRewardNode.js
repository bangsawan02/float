/**
 * 5.5.9 移植中撲 連續儲值 - 獎勵的node
 * created by kai.wu
 */

var ContinueRechargeRewardNode = cc.Node.extend({
    ctor: function (type, rewardNodeContent) {
        this._super();

        this._type = type;

        // 這個node的獎勵列表
        this.rewardList = rewardNodeContent.rewardList;

        // 這個node要多少錢
        this.price = rewardNodeContent.price;

        // 這個node的productId
        this.productId = rewardNodeContent.productId;

        // 這個node有多少個進度元素
        this.tokenNumber = 0;
    },

    onEnter: function () {
        this._super();

        if (DataModal.continueRechargeData.info) {
            this._refreshView();
        }
    },

    _refreshView: function () {
        this.removeAllChildren();
        // type 目前獎勵 後續獎勵
        var rewardSprite = this._rewardSprite = new ccui.Scale9Sprite("continue_recharge_bg_frame_0" + this._type + ".png");
        var isCurrent = (this._type === ContinueRechargeRewardNode.Type.CURRENT_REWARD);

        // 當前獎勵比較大
        rewardSprite.setPreferredSize(isCurrent ? cc.size(126, 150) : cc.size(115.25, 90.75));
        this.addChild(rewardSprite);

        // 獎勵內容
        var rewardContentNode = this._rewardContentNode = new GSAutoLayoutNode();
        rewardContentNode.setPositionX(-2);
        this._createRewardContent(isCurrent);
        this.addChild(rewardContentNode);
    },

    // 創出獎勵內容
    _createRewardContent: function (isCurrent) {
        var rewardContentNode = this._rewardContentNode;

        this.rewardList.forEach((cur) => {
            if (cur.isToken) {
                // 記下有多少進度元素
                this.tokenNumber = parseInt(cur.name);

                var diamondSpriteNode = this._diamondSpriteNode = new cc.Node();

                // 跑購買成功後留在原地的鑽石
                var diamondSprite = new cc.Sprite("#continue_recharge_pic_diamond.png");
                diamondSprite.setScale(isCurrent ? 1 : 0.6);
                diamondSpriteNode.addChild(diamondSprite);

                // 用來跑購買成功後的動畫鑽石
                var animationDiamondSprite = this._animationDiamondSprite = new GSShaderSprite("#continue_recharge_pic_diamond.png");
                animationDiamondSprite.setScale(isCurrent ? 1 : 0.6);
                diamondSpriteNode.addChild(animationDiamondSprite);

                // 數量
                var label = new cc.LabelTTF(cur.name, JSFontBoldName, isCurrent ? 12 : 10);
                label.enableStroke(JSColor.BLACK, isCurrent ? 2 : 1.5);
                label.setPositionY(isCurrent ? -29 : -19);
                diamondSpriteNode.addChild(label);

                rewardContentNode.addChild(diamondSpriteNode);
            } else {
                // 除了進度元素的另一個獎勵
                var otherRewardSpriteNode = new cc.Node();

                var imageUrl = TexasUtility.getItemImageUrl(cur.img);
                var savePath = JSWriteablePath + "shop/" + cur.img + ".png";
                var otherRewardSprite = this._otherRewardSprite = new GSDownloadSprite("", imageUrl, savePath);
                otherRewardSprite.setTargetSize(isCurrent ? cc.size(58, 58) : cc.size(40, 40));
                otherRewardSpriteNode.addChild(otherRewardSprite);

                // 數量
                var label = new cc.LabelTTF(cur.name, JSFontBoldName, isCurrent ? 12 : 10);
                label.enableStroke(JSColor.BLACK, isCurrent ? 2 : 1.5);
                label.setPosition(1, isCurrent ? -29 : -19);
                otherRewardSpriteNode.addChild(label);

                rewardContentNode.addChild(otherRewardSpriteNode);
                if (this.tokenNumber && cur.img === "7086")
                    rewardContentNode.setPositionX(3);
            }
            rewardContentNode.setSpace(isCurrent ? 50 : 40);
            rewardContentNode.setPositionY(isCurrent ? 32 : 21);
        });

        //  後續獎勵方案
        if (!isCurrent) {
            var followUpRewardTypeButton = this._followUpRewardTypeButton = ButtonUtility.createSimpleButton("lobby_btn_16.png", cc.size(88.75, 26.5), this.price === 0 ? LocalizedString.ContinueRecharge("免費") : TexasUtility.getCurrencyPriceString(this.price), JSColor.WHITE, 10);
            followUpRewardTypeButton.setPositionY(-16);
            followUpRewardTypeButton.setChangeColorWhenDisabled(false);
            followUpRewardTypeButton.setEnabled(false);
            followUpRewardTypeButton.label.enableStroke(JSColor.OUTLINE_BLUE, 2);
            this.addChild(followUpRewardTypeButton);

            var lockSprite = new cc.Sprite("#continue_recharge_lock.png");
            lockSprite.setScale(0.7);
            lockSprite.setPositionX(33);
            followUpRewardTypeButton.addChildToContentNode(lockSprite);
        }
    },

    // 位移鑽石且放大 -> 鑽石恢復大小 -> 鑽石發亮
    _diamondFlyAnime: function (targetWorldPos) {
        var animationDiamondSprite = this._animationDiamondSprite;

        targetWorldPos = this._rewardContentNode.convertToNodeSpace(targetWorldPos);

        var brightenAction = cc.callFunc(() => {
            var brightParam = new BrightenShaderParam();
            animationDiamondSprite.setShader(new GSBrightenShader(brightParam));
        });

        var finalAction = cc.callFunc( () => {
            animationDiamondSprite.removeFromParent();
            this._animationDiamondSprite = undefined;
        });

        this._diamondSpriteNode.runAction(cc.sequence(
            cc.scaleTo(0.2, 0.9, 0.9),
            cc.scaleTo(0.2, 1, 1)
        ));

        animationDiamondSprite.runAction(cc.sequence(
            cc.delayTime(0.3),
            cc.spawn(cc.moveTo(0.6, targetWorldPos.x, targetWorldPos.y), cc.scaleTo(0.6, 1.1, 1.1)),
            cc.scaleTo(0.2, 0.6, 0.6),
            brightenAction,
            cc.delayTime(0.8),
            finalAction
        ));
    },

    // 後續獎勵變換背景且拿掉底下按鈕
    changeRewardBgSprite: function () {
        var rewardSprite = this._rewardSprite;
        rewardSprite.setSpriteFrame("continue_recharge_bg_frame_01.png");
        rewardSprite.setPreferredSize(cc.size(126, 150));

        var rewardContentNode = this._rewardContentNode;
        rewardContentNode.removeAllChildren();
        this._createRewardContent(true);
        rewardContentNode.setScale(0.1);
        rewardContentNode.runAction(cc.sequence(
            cc.spawn(cc.scaleTo(0.6, 1, 1), cc.fadeIn(0.6))
        ));
    },

    // 加一個Shader製造變身特效
    currentRewardLighteningAnimation: function () {
        var animationRewardSprite = new ccui.Scale9Sprite("continue_recharge_bg_frame_01.png");
        animationRewardSprite.setPreferredSize(cc.size(126, 150));
        var animationRewardShaderSprite = GSShaderSpriteTools.changeNodeToGSShaderSprite(animationRewardSprite);

        var brightenAction = cc.sequence(cc.scaleTo(0.3, 1.1, 1.3), cc.spawn(cc.scaleTo(0.7, 1.4, 1.8), cc.fadeOut(0.7)));

        var brightParam = new BrightenShaderParam();
        brightParam.cycleTime = 2;
        brightParam.updateTime = 1;
        animationRewardShaderSprite.setShader(new GSBrightenShader(brightParam));
        animationRewardShaderSprite.runAction(cc.sequence(brightenAction, cc.removeSelf()));
        this.addChild(animationRewardShaderSprite);
    },

    removeFollowUpRewardTypeButton: function () {
        // 後續獎勵按鈕拿掉
        this._followUpRewardTypeButton.runAction(cc.sequence(
            cc.fadeOut(0.2),
            cc.removeSelf()
        ));
    }
});

ContinueRechargeRewardNode.Type = {
    CURRENT_REWARD: 1,      // 目前獎勵
    FOLLOW_UP_REWARD: 2     // 後續獎勵
};