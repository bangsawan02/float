/**
 * 足球機台下注的按鈕
 * @param multiple  傳倍數進來
 */

var FootballBetButton = GSControlButton.extend({
    ctor: function (multiple) {
        this._super(undefined, cc.size(90, 40));

        this._multiple = multiple;
        this._changeColorWhenDisabled = false;

        // 背景
        var bgSprite = this._bgSprite = new cc.Sprite("#football_btn_blue_off.png");
        this._contentNode.addChild(bgSprite);

        // 文字
        var titleLabel = this._betTitleLabel = new GSAutoSizeLabel("", JSFontBoldName, 12, cc.size(68, 16), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        titleLabel.setPosition(0, 7);
        titleLabel.setLineBreak(false);
        this._contentNode.addChild(titleLabel);
    },

    /**
     * 設定開關
     */
    setEnabled: function (enable) {
        this._super(enable);

        // 更換背景
        this._bgSprite.setSpriteFrame(enable ? "football_btn_blue_off.png" : "football_btn_orange_on.png");
        this._betTitleLabel.setPositionY(enable ? 7 : 0);
    },

    /**
     * 設定現在下注的金額
     */
    setBetMoney: function (money) {
        this._betTitleLabel.setString(JSStringUtility.format("%s x %d", TexasUtility.getSimpleMoneyString(money), this._multiple));
    },
});