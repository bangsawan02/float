/**
 * 骰寶的桌面 這邊的Position都是已432, 288來當基準 因為外面會自己去判斷做Scale的動作
 * 要改紀承cc.Node 不然在Android上會有問題
 */

var DiceBoTableLayer = cc.Node.extend({
    COLOR_YELLOW: cc.color(255, 250, 30),

    ctor: function (betCallback) {
        this._super();

        this.setCascadeOpacityEnabled(true);

        this._nowTotalBetMoney = 0;                     // 現在總下注金額
        this._betChipsIndex = 0;                        // 現在下注的按鈕Index
        this._betCallback = betCallback;
        this._usedFreeTicketCount = 0;                  // 現在用掉幾張免費券

        this._chipsArray = [];                          // 桌面上的籌碼

        // 下注區的下注金額跟上限金額
        this._zoneMaxMoney = {};
        this._zoneBetMoney = {};
        this._zoneBetChipCountArray = {};
        this._zoneBetChipSprite = {};
        for (var key in DiceBoZoneType) {
            var zoneType = DiceBoZoneType[key];
            this._zoneMaxMoney[zoneType] = 0;
            this._zoneBetMoney[zoneType] = 0;
            this._zoneBetChipCountArray[zoneType] = [];
            this._zoneBetChipSprite[zoneType] = [];
        }

        // 下注籌碼的Offset
        this._betChipsOffset = [cc.p(-7, 0), cc.p(7, 0), cc.p(0, 10), cc.p(-11, 10), cc.p(11, 10)];

        // 感應區塊
        var zoneButtonObjects = this._zoneButtonObjects = {};

        // 以下要創建按鈕區塊 跟 圖片 跟 文字, 統一區塊在zOrder:0 圖片系列都在1 Label都在2 為了節省Drawcall
        // 大 & 小 的部份
        var zones = [DiceBoZoneType.BIG, DiceBoZoneType.SMALL];
        var posX = [387, 45];
        var imageWord1s = ["#db_word_big.png", "#db_word_small.png"];
        var imageWord2s = ["#db_word_big_02.png", "#db_word_small_02.png"];
        for (var i = 0; i < 2; i++) {
            var tableButton = zoneButtonObjects[zones[i]] = new DiceBoTableButton(cc.size(74, 90), zones[i], this._tableZoneClicked, this);
            tableButton.setPosition(posX[i], 198);
            this.addChild(tableButton);

            var tableWordSprite = new cc.Sprite(imageWord1s[i]);
            tableWordSprite.setPosition(posX[i], 225);
            this.addChild(tableWordSprite, 1);

            tableWordSprite = new cc.Sprite(imageWord2s[i]);
            tableWordSprite.setPosition(posX[i], 204);
            this.addChild(tableWordSprite, 1);

            var tableText = new cc.LabelTTF("1:1.02", JSFontBoldName, 13);
            tableText.setPosition(posX[i], 186);
            tableText.setFontFillColor(this.COLOR_YELLOW);
            tableText.enableShadow(JSColor.BLACK, cc.size(-1, 1), 1);
            this.addChild(tableText, 2);

            // 豹子通殺文字
            tableWordSprite = new cc.Sprite("#db_grid_word01.png");
            tableWordSprite.setPosition(posX[i], 165);
            this.addChild(tableWordSprite, 1);
        }

        // 單一豹子部份 先做說明的文字區塊
        for (var i = 0; i < 2; i++) {
            var posX = i === 0 ? 120.5 : 311.5;
            var zoneBgSprite = new ccui.Scale9Sprite("db_grid.png");
            zoneBgSprite.setPreferredSize(cc.size(74, 12));
            zoneBgSprite.setPosition(posX, 237);
            this.addChild(zoneBgSprite, -1);        // 這個會檔到中獎的文字 所以zOrder往下移

            var tableWordSprite = new cc.Sprite("#db_grid_word02.png");
            tableWordSprite.setPosition(posX - 17, 237);
            this.addChild(tableWordSprite, 1);

            var tableText = new cc.LabelTTF("1:210", JSFontBoldName, 9);
            tableText.setPosition(posX + 19, 237);
            tableText.setFontFillColor(this.COLOR_YELLOW);
            tableText.enableShadow(JSColor.BLACK, cc.size(-1, 1), 1);
            this.addChild(tableText, 2);
        }

        zones = [
            DiceBoZoneType.TRIPLE_1, DiceBoZoneType.TRIPLE_2, DiceBoZoneType.TRIPLE_3,
            DiceBoZoneType.TRIPLE_4, DiceBoZoneType.TRIPLE_5, DiceBoZoneType.TRIPLE_6
        ];
        for (var i = 0; i < 6; i++) {
            var posX = (i < 3) ? 120.5 : 311.5;
            var posY = 217 - (26 * (i % 3));
            var tableButton = zoneButtonObjects[zones[i]] = new DiceBoTableButton(cc.size(74, 24), zones[i], this._tableZoneClicked, this);
            tableButton.setPosition(posX, posY);
            this.addChild(tableButton);

            // 骰子圖
            for (var j = 0; j < 3; j++) {
                var diceSprite = new cc.Sprite(JSStringUtility.format("#db_dice_0%d.png", i + 1));
                diceSprite.setPosition(posX - 20 + 20 * j, posY);
                this.addChild(diceSprite, 1);
            }
        }

        // 任意豹子
        var tableButton = zoneButtonObjects[DiceBoZoneType.TRIPLE_ANY] = new DiceBoTableButton(cc.size(114, 90), DiceBoZoneType.TRIPLE_ANY, this._tableZoneClicked, this);
        tableButton.setPosition(216, 198);
        this.addChild(tableButton);

        var diceBasePoint = [cc.p(179, 219), cc.p(170, 203), cc.p(188, 203)];
        for (var i = 0; i < 2; i++) {
            for (var x = 0; x < 3; x++) {
                for (var y = 2; y >= 0; y--) {
                    var diceSprite = new cc.Sprite(JSStringUtility.format("#db_dice_0%d.png", i * 3 + x + 1));
                    diceSprite.setPosition(cc.pAdd(diceBasePoint[y], cc.p(36 * x, -36 * i)));
                    this.addChild(diceSprite, 1);
                }
            }
        }

        var tableWordSprite = new cc.Sprite("#db_grid_word03.png");
        tableWordSprite.setPosition(200, 237);
        this.addChild(tableWordSprite, 1);

        var tableText = new cc.LabelTTF("1:34", JSFontBoldName, 9);
        tableText.setPosition(254, 237);
        tableText.setFontFillColor(this.COLOR_YELLOW);
        this.addChild(tableText, 2);

        // 數字壓注 數字4~17
        var zoneSize = cc.size(28, 38);
        var zonePosX = 22;
        var zonePosY = 131;
        var zoneRatio = ["69", "34", "20", "13", "9", "7.45", "6.8", "6.8", "7.45", "9", "13", "20", "34", "69"];
        for (var i = 0; i < 14; i++) {
            var tableButton = zoneButtonObjects[DiceBoZoneType.NUMBER_4 + i] = new DiceBoTableButton(zoneSize, DiceBoZoneType.NUMBER_4 + i, this._tableZoneClicked, this);
            tableButton.setPosition(zonePosX, zonePosY);
            this.addChild(tableButton);

            // 數字
            var tableWordSprite = new cc.Sprite(JSStringUtility.format("#db_grid_word_%02d.png", i + 4));
            tableWordSprite.setPosition(zonePosX, zonePosY + 8);
            this.addChild(tableWordSprite, 1);

            // 倍率
            var tableText = new cc.LabelTTF("1:" + zoneRatio[i], JSFontBoldName, 9);
            tableText.setPosition(zonePosX, zonePosY - 10);
            tableText.setFontFillColor(this.COLOR_YELLOW);
            this.addChild(tableText, 2);

            zonePosX += 29.85;
        }

        // 骰面數字壓注 Zone_24~29 先做說明的文字區塊
        var zoneBgSprite = new ccui.Scale9Sprite("db_grid.png");
        zoneBgSprite.setPreferredSize(cc.size(416, 12));
        zoneBgSprite.setPosition(216, 76);
        this.addChild(zoneBgSprite, -1);        // 這個會檔到中獎的文字 所以zOrder往下移

        var diceBoString = LocalizedString.DiceBo;
        var zoneRatioTexts = [
            diceBoString("單骰1:1"),
            diceBoString("雙骰1:2.3"),
            diceBoString("三骰1:12")
        ];
        for (var i = 0; i < 3; i++) {
            var tableText = new cc.LabelTTF(zoneRatioTexts[i], JSFontBoldName, 9);
            tableText.setPosition(78 + (138 * i), 76);
            tableText.setFontFillColor(this.COLOR_YELLOW);
            tableText.enableShadow(JSColor.BLACK, cc.size(-1, 1), 1);
            this.addChild(tableText, 2);
        }

        zoneSize = cc.size(68, 26);
        zonePosX = 42;
        zonePosY = 97;
        for (var i = 0; i < 6; i++) {
            var tableButton = zoneButtonObjects[DiceBoZoneType.DICE_NUM1 + i] = new DiceBoTableButton(zoneSize, DiceBoZoneType.DICE_NUM1 + i, this._tableZoneClicked, this);
            tableButton.setPosition(zonePosX, zonePosY);
            this.addChild(tableButton);

            // 數字
            var tableWordSprite = new cc.Sprite(JSStringUtility.format("#db_grid_word_nb%02d_big.png", i + 1));
            tableWordSprite.setPosition(zonePosX - 16, zonePosY);
            this.addChild(tableWordSprite, 1);

            // 骰子
            var diceSprite = new cc.Sprite(JSStringUtility.format("#db_dice_0%d.png", i + 1));
            diceSprite.setPosition(zonePosX + 10, zonePosY);
            this.addChild(diceSprite, 1);

            zonePosX += 69.6;
        }

        // 放中獎文字的Node
        var winWordNode = this._winWordNode = new cc.Node();
        winWordNode.setCascadeOpacityEnabled(true);
        this.addChild(winWordNode, 10);

        // 放籌碼的Node
        var chipsNode = this._chipsNode = new cc.Node();
        chipsNode.setCascadeOpacityEnabled(true);
        this.addChild(chipsNode, 10);

        // 先重置一次 讓每個區的最大金額算出來
        this.clean();

        // 是否第一次進來
        if (!GS.localStorage.getItem("FirstDiceBo")) {
            GS.localStorage.setItem("FirstDiceBo", "1");

            // 要出現亮的動畫
            this._tableAllLight();
        }
    },

    /**
     * 清除畫面
     */
    clean: function () {
        // 把所有東西都重置
        for (var key in DiceBoZoneType) {
            var zoneType = DiceBoZoneType[key];

            // 重置下注區金額 & 上限
            var maxBetMoney;
            if (zoneType >= DiceBoZoneType.TRIPLE_1 && zoneType <= DiceBoZoneType.NUMBER_17) {
                // 任意、指定豹子, 數字押注
                maxBetMoney = DiceBoMoneyType.Big_UP;
            } else {
                // 大小單雙三骰上限
                maxBetMoney = DiceBoMoneyType.Big_DOWN;
            }

            this._zoneMaxMoney[zoneType] = maxBetMoney;
            this._zoneBetMoney[zoneType] = 0;
            this._zoneBetChipCountArray[zoneType] = [];
            this._zoneBetChipSprite[zoneType] = [];

            // 清掉按鈕顯示
            var zoneButton = this._zoneButtonObjects[zoneType];
            zoneButton.clean();
        }

        // 總金額清掉
        this._nowTotalBetMoney = 0;

        // 把中獎文字砍掉
        this._winWordNode.removeAllChildren();

        // 把下注的籌碼砍光
        this._chipsNode.removeAllChildren();
    },

    /**
     * 設定桌面上的籌碼
     */
    seTableBetChips: function (chipArray) {
        this._chipsArray = chipArray;
        this._chipsArrayLen = chipArray.length;
    },

    /**
     * 用來判斷是否可以搖骰 跟 重新下注
     */
    // 回傳是否可以搖骰
    getCanStart: function () {
        return this._nowTotalBetMoney > 0;
    },

    // 回傳是否可以重新下注
    getCanReBetChips: function () {
        return this._oldTotalBetMoney > 0;
    },

    /**
     * 抓現在下注的金額
     */
    getNowTotalBetMoney: function () {
        return this._nowTotalBetMoney;
    },

    /**
     * 抓現在用掉多少免費券
     */
    getUsedFreeTicketCount: function () {
        // 回傳下注金額除以最小金額
        return this._usedFreeTicketCount;
    },

    /**
     * 清掉用掉的免費券
     */
    clearUsedFreeTicketCount: function () {
        this._usedFreeTicketCount = 0;
    },

    /**
     * 設定現在的總金額
     */
    _setNowTotalBetTotalMoney: function (totalMoney) {
        this._nowTotalBetMoney = totalMoney;

        var info = DataModal.vegasData.diceBoBetInfo;
        var freeBetMoney = (info) ? info.betArray[0] : 1000000;
        // 當作判斷用掉幾張免費券
        this._usedFreeTicketCount = totalMoney / freeBetMoney;

        // 更新LED
        GS.dispatchCustomEvent("NotifyDiceBoUpdateLED", totalMoney);
    },

    /**
     * 設定現在下注是按鈕是哪一個 小注到大注左到右是 0, 1, 2, 3, 4, 5
     */
    setBetChipsIndex: function (index) {
        this._betChipsIndex = index;
    },

    /**
     * 重新下注上一次的籌碼
     */
    reBetChips: function () {
        // 先清掉桌面上的東西
        this.clean();

        // 先判斷上次下注金額有沒有超過身上的錢
        var myMoney = DataModal.profileData.money;

        // 假如有免費券 要把自己手上的錢往上加 因為那是免費給的
        var freeTicketCount = DataModal.vegasData.freeTicket.DiceBo;
        var info = DataModal.vegasData.diceBoBetInfo;
        var freeBetMoney = (info) ? info.betArray[0] : 1000000;
        if (freeTicketCount)
            myMoney += (freeTicketCount * freeBetMoney);

        if (this._oldTotalBetMoney > myMoney) {
            // 超過 要跳Dialog
            DialogManager.addDialog(new NoMoneyDialog(this._oldTotalBetMoney - myMoney));

            // 清空下注金額
            this._setNowTotalBetTotalMoney(0);
            return;
        }

        var self = this;
        for (var zoneType in this._oldZoneBetChipCountArray) {
            // 先把那區下注金額歸0
            this._zoneBetMoney[zoneType] = 0;

            // 抓出那一區下注的次數
            var countArray = this._oldZoneBetChipCountArray[zoneType];
            var haveBetChips = false;
            countArray.forEach(function (cur, index) {
                if (cur) {
                    for (var i = 0; i < cur; i++) {
                        self._addChip(zoneType, index);
                    }
                    haveBetChips = true;
                }
            });

            // 看是否需要把按鈕的區域打開
            var zoneButton = this._zoneButtonObjects[zoneType];
            zoneButton.setChooseLightVisible(haveBetChips);
        }

        // 更新下注金額
        this._setNowTotalBetTotalMoney(this._oldTotalBetMoney);

        // 撥放音樂
        Vegas_MusicUtility.playEffect("Music/Effect/blackjack_btn2.mp3");
    },

    /**
     * 送出搖骰的Socket CMD
     */
    sendStartCMD: function () {
        // 先把上一次下注的東西記下來
        this._oldZoneBetChipCountArray = _.clone(this._zoneBetChipCountArray);
        this._oldTotalBetMoney = this._nowTotalBetMoney;

        // 轉成Server吃的規格
        var zoneArray = [];

        for (var key in DiceBoZoneType) {
            var zoneType = DiceBoZoneType[key];
            zoneArray.push(this._zoneBetMoney[zoneType]);

            // 清掉所有選到的區域亮光
            this._zoneButtonObjects[zoneType].setChooseLightVisible(false);
        }

        // 送出
        DataProcess.sendString("slot_machine 12 " + JSON.stringify(zoneArray));

        // Firebase 埋點
        var eventName = GSAnalyticsAdapter.record.game + "娛樂城玩法";
        GSAnalyticsAdapter.logEventByFirebaseAll(eventName, ["大廳"], ["骰寶下注"]);
    },

    /**
     * 按到下注的區塊
     */
    _tableZoneClicked: function (sender) {
        var zoneType = sender.zoneType;
        if (zoneType > 0) {
            var myMoney = DataModal.profileData.money;
            var chipIndex = this._betChipsIndex;
            // 抓出要放多少錢
            var info = DataModal.vegasData.diceBoBetInfo;
            var betMoneyArray = info.betArray;
            var chipMoney = betMoneyArray && betMoneyArray[chipIndex];

            // 假如沒有資料就return不做事情
            if (!betMoneyArray || !chipMoney)
                return;

            // 判斷還能不能繼續放
            if (this._checkZoneMaxMoney(zoneType, chipMoney))
                return;

            // 總金額更新
            this._setNowTotalBetTotalMoney(this._nowTotalBetMoney + chipMoney);

            // 把按鈕的區域打開
            var zoneButton = this._zoneButtonObjects[zoneType];
            zoneButton.setChooseLightVisible(true);

            // 加上籌碼
            this._addChip(zoneType, chipIndex);

            // 自己按的要出現籌碼的文字
            var moneyLabel = new cc.LabelTTF("+" + TexasUtility.getSimpleMoneyString(chipMoney), JSFontName, 10);
            moneyLabel.enableStroke(JSColor.BLACK, 2);
            this.addChild(moneyLabel, 15);

            // 要判斷文字放左邊還右邊 裡面的位置是用432當做底的 然後整個Layer Scale 所以要用432算
            var basePosition = zoneButton.getPosition();
            var isLeft = basePosition.x > (432 - 70);
            moneyLabel.setPosition(basePosition.x + (isLeft ? -15 : 15), basePosition.y);
            moneyLabel.setAnchorPoint(isLeft ? 1 : 0, 0.5);
            moneyLabel.setOpacity(0);
            moneyLabel.runAction(cc.fadeIn(0.1));
            moneyLabel.runAction(cc.sequence(
                cc.moveBy(1, cc.p(0, 20)),
                cc.fadeOut(0.1),
                cc.removeSelf()
            ));

            // 撥放音樂
            Vegas_MusicUtility.playEffect("Music/Effect/blackjack_btn2.mp3");

            // callback回去
            this._betCallback && this._betCallback(zoneType);
        }
    },

    /**
     * 加籌碼 傳下注的籌碼Index
     */
    _addChip: function (zoneType, betChipIndex) {
        if (!this._chipsArray[betChipIndex])
            return;

        var zoneButton = this._zoneButtonObjects[zoneType];

        // 先抓現在同顏色有多少籌碼
        var chipIndexCount = this._zoneBetChipCountArray[zoneType][betChipIndex] || 0;

        // 抓出要放在哪個位置
        var basePosition = cc.pAdd(zoneButton.getPosition(), this._betChipsOffset[betChipIndex % 5]);

        // 抓出要放多少錢
        var info = DataModal.vegasData.diceBoBetInfo;
        var betMoneyArray = info.betArray;

        // 開始加籌碼
        var newChipSprite = new cc.Sprite(this._chipsArray[betChipIndex]);
        newChipSprite.setScale(0.8);
        newChipSprite.setPosition(cc.pAdd(basePosition, cc.p(0, 2 * chipIndexCount - zoneButton.zoneSize.height / 6)));
        this._chipsNode.addChild(newChipSprite, parseInt(zoneType) + 3 - betChipIndex);

        // 把這個Sprite記下來
        this._zoneBetChipSprite[zoneType].push(newChipSprite);

        // 同顏色籌碼+1
        this._zoneBetChipCountArray[zoneType][betChipIndex] = chipIndexCount + 1;

        // 金額往上加
        this._zoneBetMoney[zoneType] += betMoneyArray[betChipIndex];
    },

    /**
     * 判斷該區的壓注金額上線
     */
    _checkZoneMaxMoney: function (zoneType, betMoney) {
        var myMoney = DataModal.profileData.money;
        var tableMaxMoney = DiceBoMoneyType.Big_MAX;
        var newTotalBetMoney = this._nowTotalBetMoney + betMoney;

        // 假如有免費券 要把自己手上的錢往上加 因為那是免費給的
        var freeTicketCount = DataModal.vegasData.freeTicket.DiceBo;
        var info = DataModal.vegasData.diceBoBetInfo;
        var freeBetMoney = info.betArray[0];
        if (freeTicketCount)
            myMoney += (freeTicketCount * freeBetMoney);

        var needFillUp = false;
        if (myMoney < newTotalBetMoney) {
            // 手上的錢比下注的金額少 要跳Dialog
            var lessMoney = newTotalBetMoney - myMoney;

            DialogManager.addDialog(new NoMoneyDialog(lessMoney));
            return true;
        } else if (this._zoneBetMoney[zoneType] + betMoney > this._zoneMaxMoney[zoneType]) {
            // 下注區金額超過上限 要跳Dialog
            var diceBoString = LocalizedString.DiceBo;
            var maxString = JSCodeUtility.getCurrencyString(this._zoneMaxMoney[zoneType]);
            var dialog = new AvatarDialog({
                title: diceBoString("超過上限"),
                content: diceBoString("本區下注金額上限為") + "\n#!E6AA00!#" + maxString + "#!FFFFFF!#"
            });
            DialogManager.addDialog(dialog);

            // 剛好的話 代表已經補滿不用做事
            if (this._zoneBetMoney[zoneType] === this._zoneMaxMoney[zoneType])
                return true;
            else
                needFillUp = true;
        } else if (newTotalBetMoney > tableMaxMoney) {
            // 下注金額超過最大上限 要跳Dialog
            var diceBoString = LocalizedString.DiceBo;
            var maxString = JSCodeUtility.getCurrencyString(tableMaxMoney);
            var dialog = new AvatarDialog({
                title: diceBoString("超過上限"),
                content: diceBoString("總下注金額上限為") + "\n#!E6AA00!#" + maxString + "#!FFFFFF!#"
            });
            DialogManager.addDialog(dialog);

            // 剛好的話 代表已經補滿不用做事
            if (this._nowTotalBetMoney === tableMaxMoney)
                return true;
            else
                needFillUp = true;
        }

        // 下注金額有問題時
        // 1.總下注金額已超過上限,幫他下滿到總下注金額上限即可
        // 2.區下注金額已超過上限,幫他下滿到區下注金額上限即可
        // 3.以上兩點發生,但如果玩家手上的錢不足以下滿,則不幫他下注
        if (needFillUp) {
            // 幫使用者重新下注
            var tableMoneyLess = tableMaxMoney - this._nowTotalBetMoney;                            // 距離桌上限還差多少
            var zoneMoneyLess = this._zoneMaxMoney[zoneType] - this._zoneBetMoney[zoneType];        // 區上限還差多少
            var needFillUpMoney = (tableMoneyLess < zoneMoneyLess ? tableMoneyLess : zoneMoneyLess);
            if (myMoney >= needFillUpMoney) {
                // 抓出要放多少錢
                var betMoneyArray = info.betArray;
                var fillUpMoney = needFillUpMoney;
                for (var i = 2; i > -1; i--) {
                    // 抓出要放多少錢
                    var chipMoney = betMoneyArray[i];

                    // 抓出要補幾次
                    var totalTimes = Math.floor(fillUpMoney / chipMoney);
                    for (var x = 0; x < totalTimes; x++) {
                        this._addChip(zoneType, i);
                    }
                    fillUpMoney = fillUpMoney % chipMoney;
                }

                if (needFillUpMoney !== fillUpMoney) {
                    // 代表有幫他補 要把那區域亮起來
                    var zoneButton = this._zoneButtonObjects[zoneType];
                    zoneButton.setChooseLightVisible(true);

                    // 更新現在下注的金額
                    this._setNowTotalBetTotalMoney(this._nowTotalBetMoney + needFillUpMoney - fillUpMoney);

                    // callback回去 更新按鈕
                    this._betCallback && this._betCallback(zoneType);
                }
            }

            return true;
        }

        // 沒事 回傳false
        return false;
    },

    /**
     * 全部的Table動畫 讓他亮一陣子
     */
    _tableAllLight: function () {
        // 先檔Touch
        var dummyTouch = new DummyTouchLayer(JSVisibleSize);
        this.addChild(dummyTouch, 1000);

        // 讓他一閃一閃的
        this.runAction(cc.sequence(
            cc.repeat(cc.sequence(
                cc.callFunc(function () {
                    // 把所有東西都亮起
                    for (var key in this._zoneButtonObjects) {
                        var zoneButton = this._zoneButtonObjects[key];
                        zoneButton.setZoneLightVisible(true);
                    }
                }, this),
                cc.delayTime(0.5),
                cc.callFunc(function () {
                    // 把所有東西都關掉
                    for (var key in this._zoneButtonObjects) {
                        var zoneButton = this._zoneButtonObjects[key];
                        zoneButton.setZoneLightVisible(false);
                    }
                }, this),
                cc.delayTime(0.5)
            ), 3),
            cc.callFunc(function () {
                // 拿掉檔Touch
                dummyTouch.removeFromParent();
            }, this)
        ));
    },

    /**
     * 結算處理
     */
    showFinishResult: function (diceParam, callback) {
        // 先找出有哪些屬於中獎區域
        var showZones = [];
        var diceNum = diceParam.diceNum;
        var diceNumTotal = diceNum[0] + diceNum[1] + diceNum[2];

        //是不是豹子
        var isTriple = false;
        if (diceNum[0] === diceNum[1] && diceNum[1] === diceNum[2])
            isTriple = true;

        // 單骰的次數
        var singleDiceCountArray = [0, 0, 0, 0, 0, 0];
        for (var i = 0; i < 3; i++) {
            singleDiceCountArray[diceNum[i] - 1]++;
        }

        if (isTriple) {
            // 加入任意豹跟 幾點的豹
            showZones.push(DiceBoZoneType.TRIPLE_1 + diceNum[0] - 1);
            showZones.push(DiceBoZoneType.TRIPLE_ANY);
        } else {
            // 大小判斷
            showZones.push(diceNumTotal > 10 ? DiceBoZoneType.BIG : DiceBoZoneType.SMALL);
        }

        // 數字
        if (diceNumTotal > 3 && diceNumTotal < 18)
            showZones.push(DiceBoZoneType.NUMBER_4 + diceNumTotal - 4);

        // 單一數字區
        showZones.push(DiceBoZoneType.DICE_NUM1 + diceNum[0] - 1);
        if (diceNum[1] !== diceNum[0])
            showZones.push(DiceBoZoneType.DICE_NUM1 + diceNum[1] - 1);
        if (diceNum[2] !== diceNum[1] && diceNum[2] !== diceNum[0])
            showZones.push(DiceBoZoneType.DICE_NUM1 + diceNum[2] - 1);

        // 亮起來那些區域
        var self = this;
        var haveTripleReward = false;
        var winZoneBetChipSprite = {};
        showZones.forEach(function (zoneType) {
            var zoneButton = self._zoneButtonObjects[zoneType];
            // 判斷有沒有壓到中獎區域
            var haveReward = self._zoneBetMoney[zoneType] > 0;
            if (haveReward) {
                // 有中獎 要判斷是否中豹子
                if (zoneType >= DiceBoZoneType.TRIPLE_1 && zoneType <= DiceBoZoneType.TRIPLE_6)
                    haveTripleReward = true;
            }

            // 閃的動畫
            zoneButton.runAction(cc.sequence(
                // 先各閃兩次
                cc.repeat(cc.sequence(
                    cc.callFunc(function () {
                        zoneButton.setZoneLightVisible(true);
                    }),
                    cc.delayTime(0.5),
                    cc.callFunc(function () {
                        zoneButton.setZoneLightVisible(false);
                    }),
                    cc.delayTime(0.5)
                ), 2),
                // 最後在都出來
                cc.callFunc(function () {
                    zoneButton.setZoneLightVisible(true);
                })
            ));

            // 中獎文字的出現
            if (haveReward) {
                var winSprite = new cc.Sprite("#db_word_win.png");
                winSprite.setScale(0.8);
                winSprite.setPosition(cc.pAdd(zoneButton.getPosition(), cc.p(0, zoneButton.zoneSize.height / 2)));
                self._winWordNode.addChild(winSprite);

                winSprite.runAction(cc.sequence(
                    // 先各閃兩次
                    cc.repeat(cc.sequence(
                        cc.show(),
                        cc.delayTime(0.5),
                        cc.hide(),
                        cc.delayTime(0.5)
                    ), 2),
                    // 最後在都出來
                    cc.show()
                ));
            }

            // 如果中獎 先把那一區記下來的Sprite拿掉 剩下來的Sprite就代表是要移掉的
            if (haveReward) {
                winZoneBetChipSprite[zoneType] = self._zoneBetChipSprite[zoneType];
                self._zoneBetChipSprite[zoneType] = [];
            }
        });

        // 兩秒後閃完的事情
        var zoneLightDoneFunc = function () {
            // 把沒中的籌碼移掉
            for (var key in self._zoneBetChipSprite) {
                self._zoneBetChipSprite[key].forEach(function (cur) {
                    cur.runAction(cc.moveTo(1, cc.p(216, JSVisibleSize.height + 30)));
                });
            }

            // 撥放收掉的音樂
            Vegas_MusicUtility.playEffect("Music/Effect/chippool.mp3");

            // 判斷是否有中獎
            if (diceParam.reward === 0) {
                // 沒有中獎 處理完收籌碼就可以callback了
                self.runAction(cc.sequence(
                    cc.delayTime(1),
                    cc.callFunc(function () {
                        callback && callback(self._nowTotalBetMoney, haveTripleReward);
                    })
                ));

                return;
            }

            // 抓出要放多少錢
            var info = DataModal.vegasData.diceBoBetInfo;
            var chipsMoney = info.betArray;
            // 中獎的籌碼分發 先算出總共有幾個籌碼
            var bigTableIndex = 0;
            var chipsArray = this._chipsArray;
            var chipsSpriteName;
            if (this._chipsArrayLen <= bigTableIndex + 2)
                chipsSpriteName = [chipsArray[bigTableIndex], chipsArray[bigTableIndex + 1], chipsArray[bigTableIndex + 2]];
            else
                chipsSpriteName = ["#vegas_chip_red.png", "#vegas_chip_blue.png", "#vegas_chip_green.png"];

            for (var zoneType in winZoneBetChipSprite) {
                // 抓出賠率
                var winRatio;
                if (zoneType <= 23) {
                    winRatio = DiceBoWinRatio[zoneType];
                } else {
                    // 單骰的數字 賠率按照數量來計算
                    winRatio = DiceBoWinRatio[DiceBoZoneType.DICE_NUM1 + singleDiceCountArray[zoneType - DiceBoZoneType.DICE_NUM1] - 1];
                }

                // 算出要賠的數量
                var winChipsCount = [0, 0, 0];
                var zoneWinChips = 0;
                self._zoneBetChipCountArray[zoneType].forEach(function (cur, index) {
                    zoneWinChips += (cur * winRatio);

                    // 算出小 中 大的籌碼數
                    winChipsCount[index] = cur * winRatio;
                });

                // 如果數量超過 把小籌碼換成較大的籌碼給他
                if (zoneWinChips > 300) {
                    if (zoneWinChips < 600) {
                        // 小轉中就好
                        var changeRatio = Math.floor(chipsMoney[1] / chipsMoney[0]);
                        winChipsCount[1] += Math.floor(winChipsCount[0] / changeRatio);
                        winChipsCount[0] %= changeRatio;
                    } else {
                        // 小轉中 中轉大
                        var changeRatio = Math.floor(chipsMoney[1] / chipsMoney[0]);
                        winChipsCount[1] += Math.floor(winChipsCount[0] / changeRatio);
                        winChipsCount[0] %= changeRatio;

                        changeRatio = Math.floor(chipsMoney[2] / chipsMoney[1]);
                        winChipsCount[2] += Math.floor(winChipsCount[1] / changeRatio);
                        winChipsCount[1] %= changeRatio;
                    }
                }

                // 創籌碼 先算好總數量 然後倒著放回來
                var stackPerChips = 20;         // 一疊最多幾個籌碼
                var stackCount = 0;             // 有幾疊籌碼
                winChipsCount.forEach(function (count) {
                    stackCount += Math.floor(count / stackPerChips);
                    // 要多加一疊
                    if (count % stackPerChips !== 0)
                        stackCount++;
                });

                // 開始擺放
                var chipOneRowMaxStack = 3;                                     // 一列最多幾疊
                if (stackCount > 20)
                    chipOneRowMaxStack = 9;
                else if (stackCount > 10)
                    chipOneRowMaxStack = 6;
                var chipStackOffset = cc.p(14, 14);                             // 每疊位移多少
                var lastRowStack = (stackCount % chipOneRowMaxStack);           // 最前面那一行有幾疊
                var otherRowBaseX = chipStackOffset.x * (chipOneRowMaxStack - 1) / 2;       // 後面行數 最右邊的X
                var firstRowBaseX = chipStackOffset.x * (lastRowStack - 1) / 2;             // 第一行 最右邊的X
                var winChipsAllPos = [];
                for (var i = 0; i < stackCount; i++) {
                    var pos;
                    if (i < lastRowStack) {
                        // 排前面的位置
                        pos = cc.p(firstRowBaseX - chipStackOffset.x * i, 0);
                    } else {
                        // 排後面的位置
                        var nowIndex = i - lastRowStack;
                        pos = cc.p(otherRowBaseX - chipStackOffset.x * (nowIndex % chipOneRowMaxStack), chipStackOffset.y * (Math.floor(nowIndex / chipOneRowMaxStack) + 1));
                    }
                    winChipsAllPos.push(pos);
                }

                var winChipsNode = new cc.Node();   // 用來放贏家籌碼
                winChipsNode.setCascadeOpacityEnabled(true);
                winChipsNode.setPosition(216, JSVisibleSize.height + 10);
                self._chipsNode.addChild(winChipsNode, zoneType);

                winChipsCount.forEach(function (count, index) {
                    for (var i = 0; i < count; i++) {
                        if (i % stackPerChips === 0 && i !== 0) {
                            stackCount--;
                        }

                        var newChipSprite = new cc.Sprite(chipsSpriteName[index]);
                        newChipSprite.setColor(cc.color(255, 200, 200));
                        newChipSprite.setScale(0.8);
                        newChipSprite.setPosition(cc.pAdd(winChipsAllPos[stackCount - 1], cc.p(0, 2 * (i % stackPerChips))));
                        winChipsNode.addChild(newChipSprite);
                    }

                    // 換下一個顏色籌碼
                    if (count > 0)
                        stackCount--;
                });

                // 只透過winChipsNode來做動作 為了怕zoneType被改掉 用一層包起來
                var moveFunc = function (zoneType) {
                    var basePosition = self._zoneButtonObjects[zoneType].getPosition();
                    winChipsNode.runAction(cc.sequence(
                        cc.moveTo(1, basePosition),
                        cc.delayTime(1),
                        cc.callFunc(function () {
                            // 把壓注區原本的籌碼也收回來
                            var moveByPos = cc.pSub(cc.p(216, 80), basePosition);
                            winZoneBetChipSprite[zoneType].forEach(function (cur) {
                                cur.runAction(cc.moveBy(1, moveByPos));
                            });
                        }),
                        cc.moveTo(1, cc.p(216, 80))
                    ));
                };
                moveFunc(zoneType);
            }

            // 有中獎 處理完送跟收就可以callback了
            self.runAction(cc.sequence(
                cc.delayTime(2),
                cc.callFunc(function () {
                    // 撥放收回來的音效
                    Vegas_MusicUtility.playEffect("Music/Effect/blackjack_btn3.mp3");
                }),
                cc.delayTime(1),
                cc.callFunc(function () {
                    // 把所有籌碼清掉
                    self._chipsNode.removeAllChildren();

                    // callback回去 把總下注金額 跟 是否壓中豹子傳出去
                    callback && callback(self._nowTotalBetMoney, haveTripleReward);
                })
            ));
        };
        this.runAction(cc.sequence(
            cc.delayTime(2),
            cc.callFunc(zoneLightDoneFunc)
        ));
    }
});