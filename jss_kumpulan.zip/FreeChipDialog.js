/**
 * v5.4.4 FreeChip - 免費幣Dialog
 * 大廳右下角點開的FreeChip
 * https://hackmd.io/@6Zn44G-wR1alkvuCFrr3ng/rkhROHgbo
 * created by lichieh on 2022/9/23
 */
var FreeChipDialog = BaseDialogLayer.extend({
    ctor: function (isGetChip = true) {
        this._super();

        this.key = "FreeChipDialog";

        this._isGetChip = isGetChip; // 預設我要德撲幣
        this._isTouchTab = false;    // 第一次進來才去做預設頁籤
        this._curList = [];          // 當前的清單
        this._totalCellCount = 0;    // totalCell

        var aniLayer = this._animationLayer;
        var localStr = LocalizedString.FreeChip;

        // dialog背景底
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(cc.size(492, 280));
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite);

        // 兩側霓虹燈
        for (var i = 0; i < 2; i++) {
            var neonSp = new cc.Sprite("#daliy_mission_pic_light_neon_01.png");
            neonSp.setScale(-2 * i + 1, 1);
            neonSp.setPosition(53 + 407 * i + JSScreenBonusHalfWidth, 198 + JSScreenBonusHalfHeight);
            aniLayer.addChild(neonSp);
        }

        // 黑底
        var bgLayer = new cc.LayerGradient(cc.color(0, 0, 0, 255), cc.color(0, 0, 0, 0), cc.p(-1, 1));
        bgLayer.setContentSize(369, 195);
        bgLayer.setPosition(115 + JSScreenBonusHalfWidth, 16 + JSScreenBonusHalfHeight);
        aniLayer.addChild(bgLayer);

        // 中間背景
        var bgMidPosX = 295 + JSScreenBonusHalfWidth;

        // 上方光暈
        var bgLightUpSprite = new cc.Sprite("#lobby_pic_light_gold.png");
        bgLightUpSprite.setAnchorPoint(0.5, 0);
        bgLightUpSprite.setPosition(bgMidPosX, 211 + JSScreenBonusHalfHeight);
        aniLayer.addChild(bgLightUpSprite);

        // 標題文字
        var title = new cc.Sprite("#lobby_word_title_freeChip.png");
        title.setPosition(JSScreenMidPos.x, 256 + JSScreenBonusHalfHeight);
        aniLayer.addChild(title);

        // 上方按鈕底圖
        var topBgSprite = this._topBgSprite = new ccui.Scale9Sprite("lobby_bar_black_02.png");
        topBgSprite.setPreferredSize(cc.size(220, 20));
        topBgSprite.setPosition(JSScreenMidPos.x, 225 + JSScreenBonusHalfHeight);
        aniLayer.addChild(topBgSprite);

        /****************************************************************************/
        // 左邊頁籤
        var container = new cc.Layer();
        var scrollView = this._scrollView = new cc.ScrollView(cc.size(90, 194), container);
        scrollView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        scrollView.setPosition(33 + JSScreenBonusHalfWidth, 17 + JSScreenBonusHalfHeight);
        aniLayer.addChild(scrollView);

        var displayTab = [
            {page: FreeChipDialog.Page.MISSION, title: "任務"},
            {page: FreeChipDialog.Page.LOGIN, title: "簽到&登入"},
            {page: FreeChipDialog.Page.PLAY, title: "玩牌"},
            {page: FreeChipDialog.Page.EVENT, title: "限時活動"},
            {page: FreeChipDialog.Page.VIP, title: "VIP專區"},
            {page: FreeChipDialog.Page.CHANGE, title: "兌換"}
        ];

        this._tabButtons = displayTab.map(cur => {
            var tabBtn = new FreeChipTabButton(cur);
            tabBtn.enableTouchCancel(cc.SCROLLVIEW_DIRECTION_VERTICAL);
            tabBtn.addTouchUpInsideAction(this._tabClicked, this);
            container.addChild(tabBtn);
            return tabBtn;
        });

        // 右邊TableView
        var tableView = this._tableView = new cc.TableView(this, cc.size(FreeChipDialog.TABLE_VIEW_WIDTH, 193), new cc.Layer());
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.haveDownloadObject = true;
        tableView.setPosition(121 + JSScreenBonusHalfWidth, 15 + JSScreenBonusHalfHeight);
        aniLayer.addChild(tableView);

        // 提示
        var hintLabel = this._hintLabel = new cc.LabelTTF(localStr("目前沒有活動喔!"), JSFontName, 12);
        hintLabel.setPosition(305 + JSScreenBonusHalfWidth, 116 + JSScreenBonusHalfHeight);
        aniLayer.addChild(hintLabel);

        // 上面的兩個按鈕
        this._topBtns = [
            {
                image: "#lobby_pic_chips_big_01.png",
                title: localStr("我要chips"),
                type: FreeChipDialog.ButtonType.CHIP
            },
            {
                image: ProfileData.getKoinLuxyRes("#lobby_icon_koinLuxy"),
                title: ProfileData.getKoinLuxyRes("我要KL", localStr("我要KL")),
                scale: 0.5,
                type: FreeChipDialog.ButtonType.CURRENCY
            }].map((cur, i) => {
            var topBtn = new ButtonUtility.createSimpleButton(undefined, cc.size(110, 18));
            topBtn.setPosition(201 + 110 * i + JSScreenBonusHalfWidth, 225 + JSScreenBonusHalfHeight);
            topBtn.addTouchUpInsideAction(this._topBtnClicked, this);
            topBtn.position = cc.p(201 + 110 * i + JSScreenBonusHalfWidth, 225 + JSScreenBonusHalfHeight);
            topBtn.type = cur.type;
            aniLayer.addChild(topBtn);

            var autoLayout = new GSAutoLayoutNode();
            autoLayout.setType(GSAutoLayout.TYPE.HORIZONTAL);

            var iconSprite = new cc.Sprite(cur.image);
            cur.scale && iconSprite.setScale(cur.scale);
            autoLayout.addChild(iconSprite);

            autoLayout.setSpace(1);

            var titleLabel = new cc.LabelTTF(cur.title, JSFontName, 10);
            autoLayout.addChild(titleLabel);

            topBtn.addChildToContentNode(autoLayout);

            // 灰階
            var grayBgSprite = new ccui.Scale9Sprite("lobby_btn_oval_01.png");
            grayBgSprite.setPreferredSize(cc.size(110, 18));

            var grayAutoLayout = new GSAutoLayoutNode();
            grayAutoLayout.setPosition(55, 9);
            grayAutoLayout.setType(GSAutoLayout.TYPE.HORIZONTAL);

            var grayIconSprite = new cc.Sprite(cur.image);
            cur.scale && grayIconSprite.setScale(cur.scale);
            grayAutoLayout.addChild(grayIconSprite);

            grayAutoLayout.setSpace(1);

            var grayLabel = new cc.LabelTTF(cur.title, JSFontName, 10);
            grayLabel.setFontFillColor(JSColor.BLACK);
            grayAutoLayout.addChild(grayLabel);

            grayBgSprite.addChild(grayAutoLayout);

            topBtn.setBackgroundSpriteForState(grayBgSprite, cc.CONTROL_STATE_DISABLED);

            return topBtn;
        });

        /****************************************************************************/

        // 關閉按鈕
        var closeBtn = ButtonUtility.createSimpleImageButton("lobby_btn_circle_04.png", null, "#lobby_btn_pic_window_x.png");
        closeBtn.addTouchUpInsideAction(this._closeDialogAnimation, this);
        closeBtn.setPosition(496 + JSScreenBonusHalfWidth, 274 + JSScreenBonusHalfHeight);
        aniLayer.addChild(closeBtn, 10);

        // 更新清單
        DataModal.freeChipsData.refreshAvailableList();

        // 更新Tab位置
        this._updateTabPosition();

        this._refreshView();

        // 埋點: 可兌換pulsa且進入FreeChip介面
        if (DataModal.freeChipsData.pulsaParam) {
            DataProcess.sendString("track_free_pulsa 1");
        }

        // 註冊
        var refreshFunc = this.notifyItemRefresh.bind(this);
        GS.addListener("NotifyFreeChipAvailableListRefresh", this.notifyFreeChipAvailableListRefresh.bind(this), this);
        GS.addListener("NotifyUpdateDailyMission", refreshFunc, this);
        GS.addListener("NotifyUpdateDailyScratch", refreshFunc, this);
        GS.addListener("NotifyShowAdInfoDone", refreshFunc, this);
        GS.addListener("NotifyActionListDone", refreshFunc, this);
        GS.addListener("NotifyGetGuildInfo", refreshFunc, this);                        // 公會要第一筆資料
        GS.addListener("NotifyGuildInformationDone", refreshFunc, this);                // 公會後續更新資料
        GS.addListener("NotifyGuildShowSurpriseReward", refreshFunc, this);             // 領過獎的更新
        GS.addListener("NotifySerialNumberPrizeInfoDone", refreshFunc, this);           // 序號領獎
        GS.addListener("NotifySerialNumberPrizeTimeOut", refreshFunc, this);            // 序號時間結束
        GS.addListener("NotifyContinueSignInInfoDone", refreshFunc, this);              // 連續簽到
        GS.addListener("NotifyMasterPokerInfoDone", refreshFunc, this);                 // 猜手牌遊戲
        GS.addListener("NotifyReturnMissionInfoDone", refreshFunc, this);               // 回流任務
        GS.addListener("NotifyUpdateEventRewardInfo", refreshFunc, this);               // 活動可領獎
        GS.addListener("NotifyFetchAchievementTabInfoDone", refreshFunc, this);         // 成就可領獎
        GS.addListener("NotifyCardKingInfoDone", refreshFunc, this);                    // 牌王
        GS.addListener("NotifyVipDailyDone", refreshFunc, this);                        // vip每日獎勵
        GS.addListener("NotifyVipInfoDone", refreshFunc, this);                         // vip
        GS.addListener("NotifyPhoneToGiftInfoDone", refreshFunc, this);                 // 填寫手機資料
        GS.addListener("NotifyLuckyDiceCollectionIconDone", refreshFunc, this);         // 幸運集集樂
        GS.addListener("NotifyCheckUpdateVersionDone", refreshFunc, this);              // 版本更新
        // GS.addListener("NotifyRamadanIconDone", refreshFunc, this);                     // 齋戒副系統-icon裡面給的25天簽到資訊
        GS.addListener("NotifyVegasMapMissionIconDone", refreshFunc, this);             // 地圖式機台任務
        GS.addListener("NotifyTokenSubsystemIconDone", refreshFunc, this);              // 代幣副系統
        GS.addListener("NotifyFarmBingoIconDone", refreshFunc, this);                   // 賓果農場
        GS.addListener("NotifyLimitedGroupBonusInfoDone", refreshFunc, this);           // 限時加贈
    },

    onExit: function () {
        this._super();
        const data = DataModal.freeChipsData;
        data.isDialogPop = false;
    },

    /**
     * 設定選擇上方的按鈕
     */
    _setSelectTopButton: function (button) {
        // 設定是不是chip
        this._isGetChip = button.type === FreeChipDialog.ButtonType.CHIP;
        this._topBtns.forEach(cur => cur.setEnabled(true));
        button.setEnabled(false);

        // 刷新清單
        this._updateList();
    },

    /**
     * 刷新畫面
     */
    _refreshView: function () {
        var param = DataModal.freeChipsData.freeChipParam;
        this._param = param;
        if (!param) {
            this._closeDialogAnimation();
            return;
        }

        // 刷新頁簽紅點
        this._tabButtons.forEach(cur => cur.updateBadge(param));

        // 第一次進來才去做預設頁籤
        if (!this._isTouchTab) {
            var defaultButton = undefined;
            // 從Priority指定的順序逐一檢查第一個小紅點的頁籤，作為顯示的預設
            for (let i = 0; i < FreeChipDialog.Priority.length; i++) {
                defaultButton = this._tabButtons.find(btn => btn.getIsBadgeVisible() && btn.page === FreeChipDialog.Priority[i]);
                // 找到就跳出搜尋
                if (defaultButton)
                    break;
            }
            // 都沒有找到則預設顯示玩牌
            if (!defaultButton)
                defaultButton = this._tabButtons[0];

            defaultButton && this._tabClicked(defaultButton);
        }

        // 刷新清單
        this._updateList();
    },

    /**
     * 更新清單
     */
    _updateList: function () {
        this._curList = [];

        if (!this._param)
            return;

        // 是chip or KL/RP
        var data = (this._isGetChip) ? this._param.chips : this._param.koinLuxy;
        if (!data)
            return;

        // 取得當前的清單
        var availableList = [];
        switch (this._curPage) {
            case FreeChipDialog.Page.PLAY:
                // 玩牌
                availableList = data.playList;
                break;

            case FreeChipDialog.Page.LOGIN:
                // 簽到＆登入
                availableList = data.loginList;
                break;

            case FreeChipDialog.Page.MISSION:
                // 任務
                availableList = data.missionList;
                break;

            case FreeChipDialog.Page.EVENT:
                // 限時活動
                availableList = data.eventList;
                break;

            case FreeChipDialog.Page.VIP:
                // vip
                availableList = data.vipList;
                break;

            case FreeChipDialog.Page.CHANGE:
                // 兌換
                availableList = data.changeList;
                break;
        }

        this._curList = availableList.filter(cur => cur.isOpen);

        // 刷新清單數量
        this._totalCellCount = this._curList.length;
        // 是否顯示提示
        this._hintLabel.setVisible(this._totalCellCount <= 0);
        // 刷新清單
        this._tableView.reloadData(true);
    },

    /**
     * 更新上面的按鈕
     */
    _updateTopButton: function () {
        var chipBtn = this._topBtns[FreeChipDialog.ButtonType.CHIP];
        var currencyBtn = this._topBtns[FreeChipDialog.ButtonType.CURRENCY];
        switch (this._curPage) {
            case FreeChipDialog.Page.PLAY:
                // 頁簽玩牌: 只有我要KL/RP
                chipBtn.setVisible(false);
                currencyBtn.setVisible(true);
                this._topBgSprite.setVisible(false);

                currencyBtn.setPosition(chipBtn.position);
                // 點在我要KL/RP
                this._setSelectTopButton(currencyBtn);
                break;

            case FreeChipDialog.Page.LOGIN:
            case FreeChipDialog.Page.CHANGE:
                // 頁簽簽到&登入: 單一版只有我要Chip
                // 頁簽兌換: 只有我要chips
                currencyBtn.setVisible(false);
                chipBtn.setVisible(true);
                this._topBgSprite.setVisible(false);

                // 點在我要chip
                this._setSelectTopButton(chipBtn);
                break;

            default:
                currencyBtn.setVisible(true);
                currencyBtn.setPosition(currencyBtn.position);
                chipBtn.setVisible(true);
                this._topBgSprite.setVisible(true);

                this._setSelectTopButton(this._isGetChip ? chipBtn : currencyBtn);
                break;
        }
    },

    /**
     * 更新Tab位置
     */
    _updateTabPosition: function () {
        var nowPos = cc.p(42, 16);
        var paddingY = 35;
        var showTabCount = 0;

        // 反轉一下 從最下面開始排
        var tabButtonsReverse = this._tabButtons.reverse();
        tabButtonsReverse.forEach(button => {
            button.setPosition(nowPos);

            // 下一個位置
            nowPos.y += paddingY;

            showTabCount++;
        });

        // 依照當前的數量設定尺寸&位置
        this._scrollView.setContentSize(cc.size(90, 35 * showTabCount + 3));
        this._scrollView.setContentOffsetInDuration(cc.p(0, this._scrollView.minContainerOffset().y), 0);

        // 反轉回去
        this._tabButtons.reverse();
    },

    /**
     * 頁簽按鈕
     */
    _tabClicked: function (sender) {
        this._isTouchTab = true;

        // 把所有Tab設定可以按
        this._tabButtons.forEach(btn => btn && btn.setEnabled(btn !== sender));

        // 當前頁面
        this._curPage = sender.page;

        // 更新上方的按鈕
        this._updateTopButton();

        // 刷新清單
        this._updateList();

        switch (this._curPage) {
            case FreeChipDialog.Page.PLAY:
                // 玩牌埋點
                DataProcess.sendString("track_new_free_chip 10");
                break;

            case FreeChipDialog.Page.LOGIN:
                // 簽到＆登入埋點
                DataProcess.sendString("track_new_free_chip 5");
                break;

            case FreeChipDialog.Page.MISSION:
                // 任務埋點
                DataProcess.sendString("track_new_free_chip 6");
                break;

            case FreeChipDialog.Page.EVENT:
                // 限時活動埋點
                DataProcess.sendString("track_new_free_chip 7");
                break;

            case FreeChipDialog.Page.VIP:
                // vip埋點
                DataProcess.sendString("track_new_free_chip 8");
                break;

            case FreeChipDialog.Page.CHANGE:
                // 兌換埋點
                DataProcess.sendString("track_new_free_chip 9");
                break;
        }

        // 觸發看到xx頁的埋點
        this._topBtnClicked();
    },

    /**
     * 上方按鈕點擊
     */
    _topBtnClicked: function (sender) {
        // 真的點擊時才做的事情
        if (sender) {
            this._setSelectTopButton(sender);

            // 埋點
            if (this._isGetChip)
                DataProcess.sendString("track_new_free_chip 2");
            else
                DataProcess.sendString("track_new_free_chip 3");
        }

        // 看到xx頁時的埋點
        switch (this._curPage) {
            case FreeChipDialog.Page.PLAY:
                // 玩牌埋點
                break;

            case FreeChipDialog.Page.LOGIN:
                // 簽到＆登入埋點
                break;

            case FreeChipDialog.Page.MISSION:
                // 任務埋點
                break;

            case FreeChipDialog.Page.EVENT:
                // 限時活動埋點
                if (this._isGetChip && DataModal.tokenSubsystemData.getEventIsOpen()) {
                    // 埋點: 代幣副系統 獲得活動進入我要Chips頁簽
                    DataProcess.sendString("user_analytics_track " + JSON.stringify([{type: 39}]));
                }

                if (DataModal.luxyPassData.getEventIsOpen()) {
                    // 埋點: luxy pass 獲得活動進入頁簽
                    DataProcess.sendString("user_analytics_track " + JSON.stringify([{type: this._isGetChip ? 732 : 1323}]));
                }
                if (DataModal.vegasMapMissionData.getEventIsOpen()) {
                    // 埋點：機台任務 獲得活動進入頁籤
                    TexasUtility.sendUserAnalyticsTrack(this._isGetChip ? 3878 : 3879);
                }
                if (DataModal.stoneGamblingData.getEventIsOpen() && this._isGetChip) {
                    // 埋點：賭石大師 獲得活動進入我要 Chips 頁簽人數
                    TexasUtility.sendUserAnalyticsTrack(3614, DataModal.stoneGamblingData.group);
                }
                break;

            case FreeChipDialog.Page.VIP:
                // vip埋點
                break;

            case FreeChipDialog.Page.CHANGE:
                // 兌換埋點
                break;
        }
    },

    /**
     * TableView delegate
     */
    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        if (cell == null) {
            cell = new FreeChipCell();
            cell.setAnchorPoint(cc.p(0, 0));
        }
        cell.refreshCell(this._curList[idx], this._curPage, this._isGetChip);

        return cell;
    },

    numberOfCellsInTableView: function () {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function () {
        return cc.size(FreeChipDialog.TABLE_VIEW_WIDTH, FreeChipCell.HEIGHT);
    },

    /**
     * 通知免費幣整合介面更新通知
     */
    notifyFreeChipAvailableListRefresh: function () {
        // 更新免費幣清單
        this._refreshView();
    },

    /**
     * 通知收到項目資訊更新通知 要讓data更新availableList
     */
    notifyItemRefresh: function () {
        DataModal.freeChipsData.refreshAvailableList();
    }
});

// 左側頁籤
FreeChipDialog.Page = {
    PLAY: 0,        // 玩牌
    LOGIN: 1,       // 簽到&登入
    MISSION: 2,     // 任務
    EVENT: 3,       // 限時任務
    VIP: 4,         // vip專區
    CHANGE: 5       // 兌換
};

// 上方按鈕
FreeChipDialog.ButtonType = {
    CHIP: 0,        // 我要德撲幣
    CURRENCY: 1     // 我要KL/RP
};

// 有紅點時，預設開啟頁籤的優先度，越上面越高(mission> login > play > event > vip >  change)
FreeChipDialog.Priority = [
    FreeChipDialog.Page.MISSION,
    FreeChipDialog.Page.LOGIN,
    FreeChipDialog.Page.PLAY,
    FreeChipDialog.Page.EVENT,
    FreeChipDialog.Page.VIP,
    FreeChipDialog.Page.CHANGE
];

FreeChipDialog.TABLE_VIEW_WIDTH = 368;    // Table欄位的寬度