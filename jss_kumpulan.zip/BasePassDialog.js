/**
 * 通行證 Dialog Template
 *```
 * Notes:
 *      - 圖檔 **不要** 加 #，裡面會根據使用情況自動加
 *      - 如果客製化的背景圖壓在有包的 components 上，請將背景圖的 z-order 設成 < 0 的任意值
 *
 * 架構：（前方打 + 代表必須繼承）
 *    + BasePassDialog                                  主 dialog（需繼承）
 *          BasePassTokenBar                            左上角代幣數量顯示區（沒包）
 *          BasePassTableHeaderNode                     TableView 左側票券區域（有包）
 *          BasePassTableView                           中央獎勵區 TableView（有包）
 *              BasePassRewardCell                      TableView 裡面的單一 Cell（有包）
 *                  BasePassNormalRewardCellNode        普通獎勵 cell
 *    +                 BasePassNormalRewardNode        單一普通獎勵 node（豪華、普通共用）（需繼承）
 *                  BasePassCycleRewardCellNode         循環獎勵 cell
 *    +                 BasePassCycleRewardCellNode     循環獎勵 node（需繼承，如果不開啟循環獎勵功能不用繼承）
 *          BasePassEmphasizeRewardNode                 TableView 右側強調獎勵（有包，可繼承）
 *          BasePassButtonGroup                         TableView 下面的按鈕群（有包）
 *
 * Sample Config: {
 *     // Dialog Settings:
 *     key: "",                                                 // Dialog key
 *
 *     // General Settings:
 *     isHaveCycleReward: false,                                // 是否開啟循環獎勵功能
 *     tokenIconFileName: "",                                   // 代幣圖檔
 *     ticketIconFileName: "",                                  // 豪華票券圖檔
 *     superTicketIconFileName: "",                             // 超級豪華票券圖檔（三通行證系統）
 *     freeTicketIconFileName: "",                              // 免費票券圖檔
 *     isHaveExplainButton: true,                               // 要不要顯示說明按鈕
 *     closeButtonStyle: undefined                              // 關閉按鈕 style (Texas_CloseButton.Style)
 *     closeButtonPosition: cc.p()                              // 關閉按鈕位置
 *
 *
 *     isUseOldBtnStyle: false,                                 // 是否使用舊的按鈕樣式（Common Style）
 *     isUseThreePassSystem: false,                             // 是否啟用三通行證系統（兩個付費，一個免費）
 *
 *     // TableView Settings:
 *     tableViewPosition: cc.p(0, 0),                           // TableView 位置
 *     tableViewSize: cc.size(0, 0),                            // TableView 尺寸
 *     tableViewCellSize: cc.size(0, 0),                        // TableView 普通獎勵 cell size
 *     tableViewCycleCellSize: cc.size(0, 0),                   // TableView 循環獎勵 cell size
 *
 *     // TableView 中間進度條設定
 *     progressBarBgFileName: "",                               // 進度條背景圖檔
 *     progressBarThumbnailFileName: "",                        // 進度條進度圖檔
 *     progressBarAnimeTime: 0.5,                               // 進度條動畫速度
 *     progressBarHeigh: 12                                     // 進度條高度
 *
 *     // TableView 獎勵相關設定
 *     tableViewNodeClass: BasePassNormalRewardNode,            // 獎勵 item node 的 class（必要）
 *     tableViewCellGap: 0,                                     // 豪華 or 免費獎勵與中心點的距離
 *     tableViewCycleCellSize: cc.size(0, 0),                   // 循環獎勵 cell size
 *     tableViewCycleCellClass: BasePassCycleRewardNode,        // 循環獎勵 cell class（必要）
 *
 *     // 強調獎勵區設定
 *     emphasizeRewardNodeClass: BasePassEmphasizeRewardNode,   // 指定強調獎勵區的 class
 *     emphasizeRewardNodeBgFileName: "",                       // 強調獎勵區背景圖
 *     emphasizeRewardNodeBgCapInsets: cc.rect(16, 22, 16, 21), // 強調獎勵背景的 capInsets
 *     emphasizeRewardOriginPositionY: JSScreenMidPos.y,        // 強調獎勵原點的 y 座標
 *     emphasizeRewardShowPositionX: 0,                         // 強調獎勵顯示的 x 座標
 *     emphasizeRewardCellOffset: cc.p(0, 0),                   // 強調獎勵 reward cell 的偏移
 *
 *     // 按鈕群設定
 *     buttonGroupPosition: cc.p(JSScreenMidPos.x, 38 + JSScreenBonusHalfHeight),  // 按鈕群位置
 *     buttonGroupAlignment: BasePassButtonGroup.Alignment.HORIZONTAL,             // 按鈕群對齊方式
 *     claimAllBtnText: "",                                                        // 全部領獎按鈕文字
 *     playNowBtnText: "",                                                         // 馬上玩按鈕文字
 *
 *     // 左側票券設定
 *     tableViewHeaderPosition: cc.p(0, 0),                     // TableView 左側標題位置
 *     ticketGradientFileName: "",                              // 豪華票券背景漸層圖
 *     isHasTicketGradient: true                                // 要不要顯示漸層
 *     ticketGradientHeight: 85,                                // 豪華票券背景漸層高度（三通行證系統時會自動調整）
 *     ticketSpotFileName: "",                                  // 豪華票券背景光點
 *     superTicketIconPosition: cc.p(0, 78),                    // 超級豪華票券圖檔位置（三通行證系統）
 *     ticketIconPosition: cc.p(0, 46),                         // 豪華票券圖檔位置
 *     freeTicketIconPosition: cc.p(0, -44),                    // 免費票券圖檔位置
 *
 *     // 前段短的進度條設定
 *     isEnableShortProgressBar: true,                          // 是否啟用短進度條
 *     shortProgressBarTokenScale: 1,                           // 短進度條代幣縮放倍率
 *
 *     // 代幣數量門檻標籤設定
 *     goalLabelBgFileName: "",                                 // 目標代幣數量的背景圖
 *     goalLabelFinishBgFileName: "",                           // 目標代幣數量完成的背景圖
 *     goalLabelBgScale: 1,                                     // 目標代幣數量背景圖縮放
 *     goalLabelOffset: cc.p(0, 0),                             // 目標代幣數量標籤位置偏移量
 *
 *     // 儲值按鈕設定
 *     purchaseBtnIsShowTicketIcon: false,                      // 是否顯示票券
 *     purchaseBtnMessage: "",                                  // 按鈕顯示的文字
 *     purchaseBtnIsShowPrice: true,                            // 購買按鈕要不要顯示價格
 *     purchaseBtnAlwaysUseDiscountMessage: false,              // 是否總是使用折扣訊息
 *     purchaseBtnTicketScale: 0.7                              // 購買按鈕 icon 縮放
 *     purchaseBtnTicketIconFileName                            // 購買票券圖示圖檔的檔名。(未設定則使用 config.ticketIconFileName)
 *     purchaseBtnIsShowDiscount: false,                        // 是否顯示折扣標籤
 *     purchaseBtnDiscountMessage: "",                          // 折扣標籤文字
 *     purchaseBtnDiscountFileName: "",                         // 折扣標籤圖檔
 *     purchaseBtnDiscountPosition: cc.p(76, 6),                // 折扣標籤位置
 *     purchaseBtnDiscountRotation: 10,                         // 折扣標籤旋轉角度
 *     purchaseBtnDiscountScale: 0.9,                           // 折扣標籤縮放倍率
 *     purchaseBtnDiscountFontColor: cc.color(255, 255, 153),   // 折扣標籤顏色
 *     purchaseBtnDiscountFontSize: 10,                         // 折扣標籤字體大小
 *     purchaseBtnDiscountLabelOffsetY: 0,                      // 折扣標籤 y 偏移量
 *     purchaseBtnOnClick: () => {},                            // 點擊 callback
 *
 *     // 增加代幣按鈕設定
 *     plusBtnBgFileName: "",                                   // 背景圖
 *     plusBtnWordFileName: "",                                 // 字圖
 *
 *     // 普通獎勵 node 設定
 *     normalRewardNormalNodeSize: cc.size(0, 0),               // 免費獎勵 node 尺寸
 *     normalRewardLuxuryNodeSize: cc.size(0, 0),               // 付費獎勵 node 尺寸
 *     normalRewardSuperNodeSize: cc.size(0, 0),                // 超級付費獎勵 node 尺寸（三通行證系統）
 *     normalRewardNormalBgFileName: "",                        // 免費獎勵背景圖檔
 *     normalRewardLuxuryBgFileName: "",                        // 付費獎勵背景圖檔
 *     normalRewardSuperBgFileName: "",                         // 超級付費獎勵背景圖檔（三通行證系統）
 *     normalRewardGlowFrame: [                                 // 獎勵框發光效果
 *         {
 *              fileName: "",
 *              isLoop: true,
 *              zOrder: -1
 *         },
 *     //  ...
 *     ],
 *     normalRewardNormalFontColor: cc.color(20, 48, 102),      // 普通獎勵數量標籤顏色
 *     normalRewardLuxuryFontColor: cc.color(75, 15, 15),       // 付費獎勵數量標籤顏色
 *     normalRewardSuperFontColor: cc.color(75, 15, 15),        // 超級付費獎勵數量標籤顏色（三通行證系統）
 *     normalRewardNormalFrameFileName: "",                     // 普通獎勵框
 *     normalRewardLuxuryFrameFileName: "",                     // 付費獎勵框
 *     normalRewardSuperFrameFileName: "",                      // 超級付費獎勵框（三通行證系統）
 *     tableViewCellGapThreePass: 5,                            // 三通行證系統獎勵與中心點的距離
 *     normalRewardCheckFileName: "",                           // 打勾圖檔
 *     normalRewardNodeFreeYOffset: 0                           // 普通 Node 的偏移量
 *     normalRewardNodeLuxuryYOffset: 0                         // 付費 Node 的偏移量
 *     normalRewardNodeSuperYOffset: 0                          // 超級付費 Node 的偏移量
 *
 *     // 循環獎勵進度條設定
 *     cycleRewardProgressBarSize: cc.size(0, 0),               // 進度條尺寸
 *     cycleRewardProgressBarStrokeColor: cc.color(0, 0, 0),    // 進度條文字邊框顏色
 *
 *     // 循環獎勵 node 設定
 *     cycleRewardBgFileName: "",                               // 背景圖
 *     cycleRewardSize: cc.size(0, 0),                          // Node Size
 *     cycleRewardTitleBgFileName: "",                          // 上方標題背景圖
 *     cycleRewardTitleBgSize: cc.size(0, 0),                   // 上方標題背景圖尺寸
 *     cycleRewardTitleFileName: "",                            // 上方標題字圖
 *     cycleRewardBgFileName: "",                               // 進度條背景圖
 *     cycleRewardBarFileName: "",                              // 進度條 bar 圖
 *     cycleRewardTagFileName: "",                              // 可領次數標籤圖
 *
 *     // Common dialog 設定
 *     messageDialogSize: cc.size(0, 0),                        // Common dialog size
 *     messageDialogBgFileName: "",                             // Common dialog background image
 *     messageDialogFontColor: cc.color(0, 0, 0),               // Common dialog default font color.
 *
 *     // 有儲值獲獎 dialog 設定
 *     getRewardDialogContentBgFileName: "",                    // 獎勵列表背景
 *     getRewardDialogContentOpacity: 255,                      // 獎勵列表背景透明度
 *     getRewardDialogTitleFileName: "",                        // 標題圖檔
 *
 *     // 無儲值獲獎 dialog 設定
 *     getRewardNodeSpacing: 5,                                 // 獎勵之間的間距
 *     getRewardNodeScale: 0.7,                                 // 獎勵縮放倍率
 *     getRewardNodeContextBgFileName: ""                       // 獎勵區域背景
 * }
 * ```
 *
 * 以下是更新資料時需代入數值的 property
 * @property {object[]}                     _rewardArray            獎勵陣列
 * @property {number}                       _oldTokenCount          紀錄的代幣數量
 * @property {int}                          _currentTokenCount      目前的代幣數量
 * @property {int}                          _maxTokenRequired       最大的代幣數量
 *
 * 以下是唯讀的 property
 * @property {object}                       _config                 設定內容
 * @property {boolean}                      _isHaveCycleReward      是否有循環獎勵
 * @property {BasePassTableView}            _tableView              TableView
 * @property {BasePassButtonGroup}          _buttonGroup            底部按鈕群
 * @property {BasePassEmphasizeRewardNode}  _emphasizeRewardLayer   強調獎勵
 * @property {GSProgressTimer}              _shortProgressBar       左側較短的進度條
 * @property {cc.Sprite}                    _progressBarTokenSprite 左側進度條的代幣圖
 * @property {GSControlButton}              _luxuryTicketBtn        左側豪華票券按鈕
 * @property {GSControlButton}              _superTicketBtn         左側超級豪華票券按鈕（三通行證系統）
 * @property {Texas_CloseButton}            _closeButton            關閉按鈕
 * @property {boolean}                      _isInAnimation          是否在動畫中
 * @property {boolean}                      _isInCycleReward        是否在循環獎勵中
 * @property {boolean}                      _isSkipped              是否跳過動畫
 * @property {boolean}                      _isUseThreePassSystem   是否使用三通行證系統
 */
var BasePassDialog = BaseEventDialog.extend({
    ctor: function (config = {}) {
        this._super();

        this._config = config;
        this.key = config.key || "BasePassDialog";
        this._isHaveCycleReward = config.isHaveCycleReward;
        this._isUseThreePassSystem = config.isUseThreePassSystem || false;
        this._isHaveExplainButton = config.isHaveExplainButton !== undefined && config.isHaveExplainButton;

        this._rewardArray = [];
        this._currentTokenCount = 0;

        GS.addListener("NotifyBasePassShowLoading", this.notifyBasePassShowLoading.bind(this), this);
        GS.addListener("NotifyBasePassCloseDialog", this.closeDialogAnimation.bind(this), this);
        GS.addListener("NotifyPurchaseSuccess", this.notifyPurchaseSuccess.bind(this), this);
        GS.addListener("NotifyProviderChooseDialogManuallyClosed", this.notifyPurchaseFail.bind(this), this);
    },

    onExit: function () {
        // 恢復顯示Dialog
        DialogManager.resumeShowDialog();

        this._super();
    },

    loadFileDone: function () {
        this._super();

        let aniLayer = this._animationLayer;

        // tableView
        let tableViewPosition = this._config.tableViewPosition || cc.p(JSScreenMidPos.x - 152, JSScreenMidPos.y - 84);
        let tableView = this._tableView = new BasePassTableView(this._config);
        tableView.setPosition(tableViewPosition);
        tableView.onCellRefresh(this._onCellRefresh.bind(this));
        tableView.setDelegate(this);
        aniLayer.addChild(tableView);

        // 按鈕群
        let buttonGroupPosition = this._config.buttonGroupPosition || cc.p(JSScreenMidPos.x, 38 + JSScreenBonusHalfHeight);
        let buttonGroup = this._buttonGroup = new BasePassButtonGroup(this._config);
        buttonGroup.setPosition(buttonGroupPosition);
        aniLayer.addChild(buttonGroup);

        // 跳過動畫按鈕
        let btnStyle = this._config.isUseOldBtnStyle ? Texas_Button.Style.COMMON_BLUE : Texas_Button.Style.BLUE;
        let skipBtn = this._skipBtn = new Texas_Button(btnStyle, cc.size(130, 38), LocalizedString.BasePass("跳過動畫"));
        skipBtn.addTouchUpInsideAction(this._skipBtnClicked, this);
        skipBtn.setPosition(JSScreenMidPos.x, 38 + JSScreenBonusHalfHeight);
        skipBtn.setVisible(false);
        aniLayer.addChild(skipBtn, 11);

        // 強調獎勵
        let emphasizeClass = this._config.emphasizeRewardNodeClass || BasePassEmphasizeRewardNode;
        let emphasizeRewardLayer = this._emphasizeRewardLayer = new emphasizeClass(this._config);
        aniLayer.addChild(emphasizeRewardLayer, 1);

        // TableView 左側標題 node
        let tableViewHeaderNodePos = this._config.tableViewHeaderPosition || cc.p(JSScreenMidPos.x - 184, JSScreenMidPos.y - 4);
        let tableViewHeaderNode = this.tableViewHeaderNode = new BasePassTableHeaderNode(this._config);
        tableViewHeaderNode.setPosition(tableViewHeaderNodePos);
        aniLayer.addChild(tableViewHeaderNode);

        // 取得票券按鈕的參考
        this._luxuryTicketBtn = tableViewHeaderNode.getLuxuryTicketBtn();
        if (this._isUseThreePassSystem) {
            this._superTicketBtn = tableViewHeaderNode.getSuperTicketBtn();
        }

        // 說明頁按鈕
        if (this._isHaveExplainButton) {
            let explainButton = new Texas_ExplainButton();
            explainButton.setScale(0.8);
            explainButton.setPosition(16 + JSScreenBonusHalfWidth, 271 + JSScreenBonusHalfHeight);
            explainButton.addTouchUpInsideAction(this._infoBtnClicked, this);
            aniLayer.addChild(explainButton, 1);
        }

        // 關閉按鈕
        let closeButtonPosition = this._config.closeButtonPosition || cc.p(497 + JSScreenBonusHalfWidth, 272 + JSScreenBonusHalfHeight);
        let closeButton = this._closeButton = new Texas_CloseButton(this._config.closeButtonStyle);
        closeButton.addTouchUpInsideAction(this._closeBtnClicked, this);
        closeButton.setPosition(closeButtonPosition);
        aniLayer.addChild(closeButton, 12);
    },

    /**
     * 是否跳過動畫
     * @param isSkipped
     */
    setSkipped: function (isSkipped) {
        if (this.__isDestroyed) {
            return;
        }

        this._isSkipped = isSkipped;

        let cycleRewardCell = this._tableView.getCycleRewardCell();
        cycleRewardCell && cycleRewardCell.setSkipped(isSkipped);
    },

    /**
     * 設定進度條
     * @param currentTokenCount   {int}         目前擁有的代幣數量
     * @param isAnimation         {boolean}     要不要演動畫
     * @param callback            {function}    動畫結束後的 callback
     * @protected
     */
    setProgress: function (currentTokenCount, isAnimation = false, callback = undefined) {
        if (this.__isDestroyed) {
            return;
        }

        let rewardArray = this._rewardArray;
        let firstGoalTokenCount = rewardArray[0].goal;
        let tableViewProgressBar = this._tableView.getProgressBar();

        if (currentTokenCount < firstGoalTokenCount) {
            // 最前面一段進度條(是使用2段進度條拼接出來)
            let halfGoal = firstGoalTokenCount / 2;
            if (currentTokenCount <= halfGoal) {
                // 只有第一段進度條的一半 只需處理第一段進度條
                let percent = (currentTokenCount / halfGoal) * 100;
                this.tableViewHeaderNode.getShortProgressBar().setPercentage(percent, isAnimation);
                this.tableViewHeaderNode.getShortProgressBar().setFinishProgressCallback(callback);
                tableViewProgressBar.setPercentage(0, false);
            } else {
                // 要處理兩段進度條
                // 有壓賓果的那段進度條
                this.tableViewHeaderNode.getShortProgressBar().setPercentage(100, isAnimation);
                // 在tableView上面的進度條
                let firstOffset = 10;   // 被裁切的長度
                // 34是避免被賓果需求的圖片背景壓到無法看到進度條調整的長度
                let percent = (firstOffset + ((currentTokenCount - halfGoal) / halfGoal) * (34 - firstOffset)) / tableViewProgressBar.fullWidth * 100;
                if (isAnimation) {
                    this.tableViewHeaderNode.getShortProgressBar().setFinishProgressCallback(() => {
                        tableViewProgressBar.setPercentage(percent, true);
                        tableViewProgressBar.setFinishProgressCallback(callback);
                    });
                } else {
                    tableViewProgressBar.setPercentage(percent, false);
                }
            }
        } else {
            let percent = 0;    // 第二段進度條的進度
            if (currentTokenCount >= this._maxTokenRequired) {
                // 超過最大等級的賓果數量
                percent = 100;
            } else {
                // 獎勵清單上哪幾個賓果數已經達成
                let achieveArray = rewardArray.filter(cur => cur.goal <= currentTokenCount);
                let achieveArrayLen = achieveArray.length;
                if (achieveArrayLen === 0) {
                    tableViewProgressBar.setPercentage(0, false);
                } else {
                    // 第一段進度條的長度(因為有裁切過)
                    let firstWidth = 50 / tableViewProgressBar.fullWidth * 100;
                    // 每一段進度條的長度
                    let width = this._tableView.getCellSize().width / tableViewProgressBar.fullWidth * 100;
                    let lastGoal = achieveArray[achieveArrayLen - 1].goal;
                    // 下一個獎勵
                    let nextReward = rewardArray.find(cur => cur.goal > currentTokenCount);
                    // 下一個獎勵需要的賓果數量
                    let nextGoal = nextReward ? nextReward.goal : -1;
                    let newProgress = (nextGoal === -1) ? 0 : (currentTokenCount - lastGoal) / (nextGoal - lastGoal) * width;
                    // achieveArrayLen - 1是因為要扣掉第一段的長度用加的
                    percent = width * (achieveArrayLen - 1) + firstWidth + newProgress;
                }
            }

            if (isAnimation) {
                // 第一段進度條直接填滿
                this.tableViewHeaderNode.getShortProgressBar().setPercentage(100, true);
                this.tableViewHeaderNode.getShortProgressBar().setFinishProgressCallback(() => {
                    // 設定進度條
                    tableViewProgressBar.setPercentage(percent, true);
                    // 確認有沒有cb
                    tableViewProgressBar.setFinishProgressCallback(callback);
                });
            } else {
                // 第一段進度條直接填滿
                this.tableViewHeaderNode.getShortProgressBar().setPercentage(100, false);
                // 設定進度條
                tableViewProgressBar.setPercentage(percent, false);
            }
        }
    },

    /**
     * 跳過動畫按鈕點擊
     */
    _skipBtnClicked: function () {
        cc.error("_skipBtnClicked not implemented");
    },

    /**
     * 跑進度條動畫
     * @param {object[]} progressArray          可領獎勵陣列
     * @param {int}      newTokenCount          新代幣數量
     * @return {Promise<void>}
     * @protected
     */
    runProgressAnimeAsync: function (progressArray, newTokenCount) {
        return new Promise((resolve, reject) => {
            if (this._isSkipped || this.__isDestroyed) {
                return reject();
            }

            let progress = progressArray.shift();

            if (!progress) {
                this.setProgress(newTokenCount, true, () => resolve());
                return;
            }

            this.setProgress(progress.goal, true, () => {
                // 跑完進度條要讓該區間cell亮起
                let index = this._rewardArray.findIndex(curReward => curReward.goal === progress.goal);
                if (this._tableView.cellAtIndex(index))
                    this._tableView.cellAtIndex(index).refreshCell(this._rewardArray[index], newTokenCount, this._rewardArray[index].goal);

                this.scrollTableViewByTokenCount(progress.goal, true);

                // 等一下cell刷新在跑下一段進度
                this.stopAllActions();
                this.runAction(cc.sequence(
                    cc.delayTime(0.1),
                    cc.callFunc(() => {
                        this.runProgressAnimeAsync(progressArray, newTokenCount)
                            .then(() => resolve())
                            .catch(() => reject());
                    })
                ));
            });
        });
    },

    /**
     * 刷新強調的獎勵是否要出現
     * @param {Number}  offsetX     Table View 的 scrolling offset.
     * @private
     */
    _refreshEmphasizeRewardVisible: function (offsetX) {
        if (this.__isDestroyed) {
            return;
        }

        if (offsetX >= this._tableView.minContainerOffset().x + this._tableView.getLastCellSize().width) {
            this._emphasizeRewardLayer.showReward();
        } else {
            this._emphasizeRewardLayer.hideReward();
        }
    },

    /**
     * 刷新領獎按鈕要不要特效光（僅 LuxyPass 使用）
     * @param isShow
     * @protected
     * @deprecated 特效光已調整為常駐發光，非 LuxyPass 請勿使用
     */
    refreshSpineButtonLight: function (isShow) {
        if (!this._buttonGroup || !this._buttonGroup.claimAllButton || this.__isDestroyed)
            return;

        isShow && this._buttonGroup.claimAllButton.playLightSpineEffect();
    },

    /**
     * TableView cell 更新時呼叫
     * @param {int} index
     * @protected
     */
    _onCellRefresh: function (index) {
        cc.warn("可能忘記 override _onCellRefresh");
    },

    /**
     * TableView Delegate: Called on the end of scrolling.
     * @param view
     * @protected
     */
    scrollViewDidScroll: function (view) {
        this._refreshEmphasizeRewardVisible(view.getContentOffset().x);
    },

    /**
     * 取得紀錄的賓果球數量
     * @param {String} userKey UserDefaultKey
     * @return {number}
     * @protected
     */
    getTokenRecord: function (userKey) {
        return parseInt(GS.localStorage.getItem(userKey + DataModal.profileData.account, "0"));
    },

    /**
     * 儲存賓果球數量
     * @param {String} userKey UserDefaultKey
     * @param {number} quantity
     * @protected
     */
    saveTokenRecord: function (userKey, quantity) {
        GS.localStorage.setItem(userKey + DataModal.profileData.account, quantity.toString());
    },

    /**
     * 滑動 tableView 到當前代幣數量的位置
     * @param {number} tokenCount   代幣數量
     * @param {boolean} isAnimation  要不要動畫
     * @protected
     */
    scrollTableViewByTokenCount: function (tokenCount, isAnimation = false) {
        let index = tokenCount <= this._maxTokenRequired ? this._rewardArray.findIndex(cur => cur.goal >= tokenCount) : (this._rewardArray.length - 1);
        let offsetX = this._tableView.maxContainerOffset().x - this._tableView.getCellSize().width * (index - 1);

        offsetX = cc.clampf(offsetX, 0, this._tableView.minContainerOffset().x);

        this._tableView.setContentOffset(cc.p(offsetX, 0), isAnimation);
        !isAnimation && this._refreshEmphasizeRewardVisible(offsetX);
    },

    /**
     * 表演一般獎勵的進度條動畫
     * @param {number} oldTokenCount 舊的代幣數量
     * @param {number} newTokenCount 新的代幣數量
     * @returns {Promise<void>}
     * @protected
     */
    playProgressAnimationAsync: function (oldTokenCount, newTokenCount) {
        if (this.__isDestroyed || this._isSkipped || this._isInCycleReward)
            return Promise.reject();

        // 要表演的進度條區間
        let progressArray = this._rewardArray.filter(cur => oldTokenCount < cur.goal && newTokenCount >= cur.goal);

        // 跑每一段進度條區間
        return this.runProgressAnimeAsync(progressArray, newTokenCount);
    },

    /**
     * 檢查是否使用三通行證系統
     * @returns {boolean}
     */
    isUseThreePassSystem: function () {
        return this._isUseThreePassSystem;
    },

    /**
     * 檢查是否擁有豪華通行證
     * @param {object} stageParam 階段資料
     * @returns {boolean}
     */
    isHaveLuxuryPass: function (stageParam) {
        return stageParam.isHaveLuxuryPass || stageParam.isHavePass || false;
    },

    /**
     * 檢查是否擁有超級豪華通行證
     * @param {object} stageParam 階段資料
     * @returns {boolean}
     */
    isHaveSuperPass: function (stageParam) {
        return stageParam.isHaveSuperPass || false;
    },

    /**
     * 獲取通行證類型
     * @param {object} stageParam 階段資料
     * @returns {number} 通行證類型 (0:免費, 1:豪華, 2:超級豪華)
     */
    getPassType: function (stageParam) {
        if (this._isUseThreePassSystem) {
            if (this.isHaveSuperPass(stageParam)) {
                return BasePassType.SUPER;
            } else if (this.isHaveLuxuryPass(stageParam)) {
                return BasePassType.LUXURY;
            }
            return BasePassType.FREE;
        } else {
            // 向後相容
            return this.isHaveLuxuryPass(stageParam) ? BasePassType.LUXURY : BasePassType.FREE;
        }
    },

    /**
     * 通行證解鎖動畫
     * @param {number|number[]} [passTypes] 指定要播放解鎖動畫的通行證層級
     *                                      - 不帶參數: 舊行為，全部播放
     *                                      - 傳入 BasePassType 或其陣列: 僅播放指定層
     * @return {Promise<void>}
     */
    playUnlockAnimationAsync: function (passTypes) {
        return new Promise((resolve, reject) => {
            if (this.__isDestroyed) {
                return reject();
            }

            // 動畫開始
            this.isLockBackKey = true;
            this._closeButton.setEnabled(false);
            this._isInAnimation = true;
            this._emphasizeRewardLayer.playUnlockAnimation(passTypes);
            this.setLoadingSprite(false, true);

            // tableView不給按
            this._tableView.setTouchEnabled(false);
            for (let i = 0; i < this._rewardArray.length; i++) {
                if (this._tableView.cellAtIndex(i))
                    this._tableView.cellAtIndex(i).playUnlockAnimation(passTypes);
            }

            // 等解鎖完要做的callback
            this.runAction(
                cc.sequence(
                    cc.delayTime(1.8),
                    cc.callFunc(() => {
                        // 動畫結束
                        this._isInAnimation = false;
                        this.isLockBackKey = false;
                        this._closeButton.setEnabled(true);

                        // 打開tableView點擊
                        this._tableView.setTouchEnabled(true);

                        // 卡 loading
                        this.setLoadingSprite(true, true);

                        resolve();
                    })
                )
            );
        });
    },

    /**
     * 通知壓 loading
     */
    notifyBasePassShowLoading: function () {
        this.setLoadingSprite(true, true);
    },

    /**
     * 儲值成功
     */
    notifyPurchaseSuccess: function () {
        // 沒有顯示的時候不處理
        if (!this.isVisibleRecursive())
            return;

        // 卡Loading等過帳回來
        this.setLoadingSprite(true, true);

        // 等過帳回來，不給關
        this.isLockBackKey = true;
        this._closeButton.setEnabled(false);
    },

    /**
     * 第三方網頁儲值失敗
     */
    notifyPurchaseFail: function () {
        this._super();
        // 這邊點儲值按鈕會停掉所有Dialog(避免轉金樂or誰儲值完直接衝出來)
        // 但是第三方儲值網頁會將其他Dialog隱藏起來(setTempHide)
        // 所以儲值失敗的時候再幫他顯示Dialog
        DialogManager.resumeShowDialog();
    },
});