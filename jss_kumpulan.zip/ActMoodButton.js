/**
 * 互動道具的按鈕
 */

var ActMoodButton = cc.ControlButton.extend({
    ctor: function (actMoodParam, type) {
        this._super();

        // 把參數記下來
        this.actMoodParam = actMoodParam;

        // 是哪裡的互動道具按鈕
        type = type || ActMoodsType.NORMAL_GAME;

        // 先把此按鈕的圖片做好
        if (type === ActMoodsType.NORMAL_GAME) {
            var btnSize = cc.size(54, 54);  //互動道具size比較大
            var nameColor = JSColor.WHITE;  //字預設白色
        } else {
            //個人資訊頁
            var btnSize = cc.size(42, 42);  //互動道具size比較小
            var nameColor = JSColor.WHITE;  //字預設白色
        }

        var node = this._mainNode = new ccui.Scale9Sprite();
        node.setCascadeColorEnabled(true);
        node.setCascadeOpacityEnabled(true);
        node.setContentSize(btnSize);

        // 圖片
        var imageUrl = GS.httpScheme + "//g2.mwsrv.com/texas9/store/iapp/download/multi/HD/" + actMoodParam.serial + ".png";
        var savePath = JSWriteablePath + "actMoods/" + actMoodParam.serial + ".png";
        var imageSprite = new GSDownloadSprite("", imageUrl, savePath);
        imageSprite.setTargetSize(cc.size(btnSize.width - 10, btnSize.height - 10));
        imageSprite.setPosition(btnSize.width / 2, 30);
        node.addChild(imageSprite);

        // 名稱
        var nameString = actMoodParam.isDefault ? LocalizedString.Game("免費") : "x" + actMoodParam.count.toString();
        var nameLabel = new cc.LabelTTF(nameString, JSFontBoldName, 10);
        nameLabel.setPosition(btnSize.width / 2, (type === ActMoodsType.NORMAL_GAME) ? 2 : 8);
        node.addChild(nameLabel, 1);

        if (!actMoodParam.isDefault && actMoodParam.count < 2)
            nameLabel.setFontFillColor(JSColor.RED);
        else
            nameLabel.setFontFillColor(nameColor);

        // 自己的設定
        this.setPreferredSize(btnSize);         // 一定要加這行 Native才會是對的
        this.setBackgroundSpriteForState(node, cc.CONTROL_STATE_NORMAL);
        this.addTargetWithActionForControlEvents(this, this._buttonClicked,
            cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
            cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
            cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
        this.setAdjustBackgroundImage(false);
        this.setZoomOnTouchDown(false);
        this.setSwallowTouches(false);
        this.setTouchDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
    },

    /**
     * 按到的時後 要改變顏色
     */
    _buttonClicked: function (sender, type) {
        var isTouched = (type === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || type === cc.CONTROL_EVENT_TOUCH_DOWN);
        this._mainNode.setColor(isTouched ? JSColor.GRAY : JSColor.WHITE);
    },
});