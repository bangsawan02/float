/**
 * 用來給一些Layer可以直接設定back key 就不用自己寫註冊跟砍掉
 */

var GSBackKeyLayer = cc.Layer.extend({
    ctor: function () {
        this._super();
    },

    onEnter: function() {
        this._super();

        PushScene.addBackKeyEnableLayer(this);
    },

    onExit: function() {
        PushScene.removeBackKeyEnableLayer(this);

        this._super();
    },
});