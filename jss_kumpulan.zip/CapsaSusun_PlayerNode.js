/**
 * CapsaSusun 玩家的Node 很多東西都放在這 圖片盡量放在zOrder 0  Label放在 1
 */

var CapsaSusun_PlayerNode = cc.Node.extend({
    ctor: function (serverSitNum) {
        this._super();

        this.setCascadeColorEnabled(true);
        this.setCascadeOpacityEnabled(true);

        this._playerData = null;
        this.money = 0;                         //身上的籌碼

        //用來移動位子(public)
        this.sitNum = serverSitNum;             //畫面上看到的位置(自已是0，往左+1)
        this.serverSitNum = serverSitNum;       //server的位置
        this.sitNumTmp = 0;                     //暫時記錄目標位置的值
        this.prevPlayer = null;                 //前一個PlayerNode
        this.nextPlayer = null;                 //後一個PlayerNode

        // 先創一個Node 用來縮放大頭照相關的大小
        var mainNode = this._mainNode = new cc.Node();
        mainNode.setCascadeOpacityEnabled(true);
        this.addChild(mainNode);

        // 照片 要切成圓形
        var stencilSprite = new cc.Sprite("#lobby_photo_clip.png");
        var clipNode = new cc.ClippingNode(stencilSprite);
        clipNode.setAlphaThreshold(0.5);
        clipNode.setCascadeOpacityEnabled(true);
        mainNode.addChild(clipNode);

        var photoSize = cc.size(56, 56);
        var photoSprite = this._photoSprite = new PhotoSprite("", photoSize.width, photoSize.height);
        clipNode.addChild(photoSprite);

        // 點玩家大頭會出現詳細資訊
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        mainNode.addChild(menu, 100);

        var itemNode = ButtonUtility.createEmptyNodes(photoSize);
        var btn = new cc.MenuItemSprite(itemNode[0], itemNode[1], this._showDetailClicked, this);
        btn.setPosition(photoSprite.getPosition());
        menu.addChild(btn);

        // 頭像匡
        var identifyNode = this._identifyNode = new PlayerIdentityNode();
        identifyNode.setScale(1.45);
        identifyNode.setPosition(-0.5, 1);
        mainNode.addChild(identifyNode);

        // 禮物按鈕
        var giftButton = this._giftButton = new PlayerAccessoryNode();
        giftButton.setScale(0.9);
        giftButton.setPosition(-29, -12);
        giftButton.addTargetWithActionForControlEvents(this, this._sendGiftClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        giftButton.setEnabled(true);
        mainNode.addChild(giftButton);

        // 積分Icon
        var rankIconNode = this._rankIconNode = new GameRankIconNode();
        rankIconNode.setScale(0.3);
        var rankIconBtn = this._rankIconBtn = new GSControlButton(rankIconNode, rankIconNode.getBoundingBox());
        rankIconBtn.setChangeColorWhenDisabled(false);
        rankIconBtn.addTouchUpInsideAction(() => {
            DialogManager.addDialog(new GameRankGameInfoDialog());
        }, this);
        rankIconBtn.setEnabled(false);
        rankIconBtn.setPosition(29, -12);
        mainNode.addChild(rankIconBtn);

        // 玩家的表情
        var moodNode = this._moodNode = new cc.Node();
        this.addChild(moodNode);

        // 下方的資訊框
        var infoNode = this._infoNode = new cc.Node();
        infoNode.setCascadeOpacityEnabled(true);
        this.addChild(infoNode);

        // 金錢背景底
        var moneyBgSprite = new ccui.Scale9Sprite("lobby_pic_square_black.png");
        moneyBgSprite.setPreferredSize(cc.size(56, 12));
        moneyBgSprite.setPosition(0, -29);
        moneyBgSprite.setOpacity(100);
        infoNode.addChild(moneyBgSprite);

        // 金錢圖片
        var moneySprite = new cc.Sprite("#lobby_pic_chips_big_01.png");
        moneySprite.setPosition(-26, -29);
        infoNode.addChild(moneySprite);

        // 金錢
        var moneyLabel = this._moneyLabel = new GSAutoSizeLabel("", JSFontName, 9, cc.size(48, 12), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        moneyLabel.setPosition(3, -29);
        moneyLabel.resizeToFit(7);              // 設定最小的Size
        infoNode.addChild(moneyLabel, 1);

        // 名字與決策
        var nameLabel = this._nameLabel = new GSAutoSizeLabel("", JSFontName, 9, cc.size(70, 12), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        nameLabel.setPosition(0, -42);
        nameLabel.setFontFillColor(cc.color(252, 252, 252));
        nameLabel.resizeToFit(7);              // 設定最小的Size
        nameLabel.enableShadow(JSColor.BLACK, cc.size(1, -1), 0);
        infoNode.addChild(nameLabel, 1);

        // 如果是0 把這個設成自己
        this.setPlayerIsSelf(serverSitNum === 0);
    },

    /**
     * 重置所有資訊 / 外觀
     */
    cleanData: function () {
        this.setVisible(false);

        this._playerData = null;
        this._photoSprite.setPhotoUrlString("");
        this._nameLabel.setString("");
        this._moneyLabel.setString("0");

        this._firstSitRankAnimation = false;        // 是否在撥第一次坐下的積分動畫, 是的話updateSeat來的積分先不顯示
    },

    /**
     * 設定此Player是否為玩家本人 CapsaSusun目前的四家大小是一樣
     */
    setPlayerIsSelf: function (isSelf) {
        // 把人像變大
        this._mainNode.setScale(isSelf ? 0.7 : 0.7);

        // 表情要同步放大
        this._moodNode.setScale(isSelf ? 0.7 : 0.7);
    },

    /**
     * 抓此玩家的PlayerData
     */
    getPlayerData: function () {
        return this._playerData;
    },

    /**
     * 這個玩家目前是否存在
     * @returns {boolean}
     */
    getIsExist: function () {
        return !!this._playerData;
    },

    /**
     * 判斷這玩家是否是自己
     * @returns {boolean}
     */
    getIsSelf: function () {
        return this._playerData && this._playerData.getIsSelf();
    },

    /**
     * 換位置後，要換SitNum，改變外觀位置
     * @param {sitNum} 畫面上的位置
     */
    setSitNum: function (sitNum) {
        this.sitNum = sitNum;
    },

    /**
     * 撥放表情
     */
    playMood: function (moodString) {
        // 撥放GAF
        var self = this;
        var url = MOOD_DOWNLOAD_URL + moodString + ".zip";
        var entryFile = moodString + "/" + moodString + ".gaf";
        var saveFileName = JSStringUtility.format("%smood/%s.zip", JSWriteablePath, moodString);
        gaf.createAndDownloadWithBundle(url, saveFileName, entryFile, this, function (gafAsset) {
            var moodNode = new cc.Node();
            moodNode.setCascadeOpacityEnabled(true);
            moodNode.setOpacity(0);
            self._moodNode.addChild(moodNode, 10);

            var bgSprite = new cc.Sprite("#lobby_photo_clip.png");
            bgSprite.setColor(JSColor.BLACK);
            bgSprite.setOpacity(100);
            moodNode.addChild(bgSprite);

            var gafObject = gafAsset.createObjectAndRun(true);
            gafObject.setScale(0.6);
            moodNode.addChild(gafObject);

            // 設定撥放完要砍掉
            moodNode.runAction(cc.sequence(
                cc.fadeIn(0.1),
                cc.delayTime(2),
                cc.fadeOut(0.4),
                cc.removeSelf()
            ));

            // 撥放音效
            MusicUtility.playEffect("Music/Effect/mood/mood_" + moodString + ".mp3");
        }, function () {
            // 失敗
            cc.log("表情 加失敗 URL=" + url);
        });
    },

    // 秀該玩家詳細資料
    _showDetailClicked: function () {
        if (this._playerData) {
            var profileDialog = new ProfileDialog(this._playerData.account);
            DialogManager.addDialog(profileDialog, true, true);
        }
    },

    // 按到送禮物
    _sendGiftClicked: function () {
        if (!this._playerData)
            return;

        var type = this.getIsSelf() ? ChipShopDialog.Type.GAME_SELF : ChipShopDialog.Type.GAME_FRIEND;
        DialogManager.addDialog(new ChipShopDialog(type, this._playerData.account));
    },


    /**
     * 更新玩家金錢
     */
    updateChips: function (value) {
        this._moneyLabel.setString(TexasUtility.getSimpleMoneyString(value));
        //noshowdown與showdown分錢後無法更新tableChips，更新是為了比賽時可以正確算自已的名次
        if (this._playerData) {
            this._playerData.tableChips = value;
        }
    },

    /**
     * 更新玩家資料
     */
    updateSeat: function (data) {
        if (data) {
            this.setVisible(data.getIsExist());

            // 判斷是否是自己
            this.setPlayerIsSelf(data.getIsSelf());

            // 大頭照
            this._photoSprite.setDefaultSprite(data.isMale ? "photo_male.png" : "photo_female.png");

            // 判斷是否有被禁言
            var photoURL = data.photoURL;
            if (DataModal.blacklistData.isAccountInList(data.account))
                photoURL = "";
            this._photoSprite.setPhotoUrlString(photoURL);

            // 金錢
            this._moneyLabel.setString(TexasUtility.getSimpleMoneyString(data.money));

            // 暱稱(自己不顯示)
            var nicknameStr = (data.getIsSelf()) ? "" : data.nickname;
            this._nameLabel.setString(nicknameStr);

            // 更新配件
            this._giftButton.refresh(data);

            // 邊框
            this._identifyNode && this._identifyNode.setIdentity(data.identity);

            // 更新積分階級圖片 多一層防呆判斷保險點
            if (GameRankClass.isValid(data.userClass) && !this._firstSitRankAnimation) {
                this._rankIconBtn.setVisible(true);
                this._rankIconNode.setLevelClass(data.userClass);
            } else {
                this._rankIconBtn.setVisible(false);
            }
            // 是自己才可以點
            this._rankIconBtn.setEnabled(data.getIsSelf());
        } else
            this.setVisible(false);

        this._playerData = data;
    },

    /**
     * 設定大頭照是否為灰色
     * @param {value} 是否變色
     */
    transToGray: function (value) {
        this._photoSprite.setColor(value ? JSColor.GRAY : JSColor.WHITE);
    },

    /**
     * 是否倒數計時
     * @param {isPlay} 是否開始
     */
    playCountDown: function (isPlay, delay) {
    },

    /**
     * 轉位完要重設，不然畫面會怪怪的
     */
    resetCountDown: function () {
    },

    /**
     * 更新身上的配件
     */
    updateAccessory: function () {
        // 更新配件
        this._giftButton.refresh(this._playerData);
    },

    /**
     * 更新黑名單將大頭照設置成預設
     */
    updateIsForbidden: function (photoUrl) {
        this._photoSprite.setPhotoUrlString(photoUrl, this._playerData.account);
    },

    /**
     * 坐下後出現階級的動畫
     * 閃個兩次後 跑到積分Icon那位置去
     * @param {GameRankClass} levelClass 階級
     */
    showFirstSitGameRankAnimation: function (levelClass) {
        // 先判斷這個階級是不是合法支援
        if (!GameRankClass.isValid(levelClass))
            return;

        this._firstSitRankAnimation = true;

        // 先創一個新的Icon圖放在頭像上
        var newRankIcon = new GameRankIconNode(levelClass);
        newRankIcon.setScale(0.7);
        this._mainNode.addChild(newRankIcon, 8);

        // 把原本的圖先顯示看不到
        var rankIconNode = this._rankIconNode;
        var rankIconBtn = this._rankIconBtn;
        rankIconBtn.setVisible(false);

        // 閃個兩下後跑去右下角
        newRankIcon.showShineAnimationAsync(2)
            .then(res => {
                // 跑去右下角
                var aniTime = 0.4;
                newRankIcon.runAction(cc.sequence(
                    cc.spawn(
                        cc.scaleTo(aniTime, rankIconNode.getScale()),
                        cc.moveTo(aniTime, rankIconBtn.getPosition())
                    ),
                    cc.callFunc(function () {
                        // 把原本圖示顯示出來
                        rankIconNode.setLevelClass(levelClass);
                        rankIconBtn.setVisible(true);

                        this._firstSitRankAnimation = false;
                    }, this),
                    cc.removeSelf()
                ));
            });
    },

    /**
     * 更改階級的動畫
     * 選轉兩次後 跑到積分Icon那位置去
     * @param {GameRankClass} levelClass 階級
     */
    showChangeGameRankClassAnimation: function (levelClass) {
        // 先判斷這個階級是不是合法支援
        if (!GameRankClass.isValid(levelClass))
            return;

        // 先創一個新的Icon圖放在頭像上
        var newRankIcon = new GameRankIconNode(levelClass);
        newRankIcon.setScale(0.7);
        this._mainNode.addChild(newRankIcon, 8);

        // 把原本的圖先顯示看不到
        var rankIconNode = this._rankIconNode;
        var rankIconBtn = this._rankIconBtn;
        rankIconBtn.setVisible(false);

        // 閃個兩下後跑去右下角
        newRankIcon.showTurnAnimationAsync()
            .then(res => {
                // 跑去右下角
                var aniTime = 0.4;
                newRankIcon.runAction(cc.sequence(
                    cc.spawn(
                        cc.scaleTo(aniTime, rankIconNode.getScale()),
                        cc.moveTo(aniTime, rankIconBtn.getPosition())
                    ),
                    cc.callFunc(function () {
                        // 把原本圖示顯示出來
                        rankIconNode.setLevelClass(levelClass);
                        rankIconBtn.setVisible(true);
                    }, this),
                    cc.removeSelf()
                ));
            });
    }
});
