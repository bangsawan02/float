/**
 * 5.4.0 副系統 - 激戰任務排行榜前三名Node
 * created by Jim.Chen
 */

var FierceBattleTopNode = cc.Node.extend({
    ctor: function (rankList) {
        this._super();

        var fierceStr = LocalizedString.FierceBattle;
        var midPosX = 152;

        // 頭像
        var playerPosX = [midPosX, midPosX - 93, midPosX + 93];
        var flagHeight = [105, 96, 94];
        for (var i = 0; i < 3; i++) {
            // 拿前三名玩家資料 沒有塞空的
            var playerData = (rankList.length >= i + 1) ? rankList[i] : undefined;

            // 背後三旗子
            var flagSp = new ccui.Scale9Sprite(JSStringUtility.format("fierceBattle_pic_banner_%02d.png", i + 1));
            flagSp.setPreferredSize(cc.size(86, flagHeight[i]));
            flagSp.setPosition(playerPosX[i], (i === 0) ? 68 : 64);
            this.addChild(flagSp);

            var playerNode = new FierceBattleRankPlayerButton(playerData, i + 1);
            playerNode.setPosition(playerPosX[i], 98);
            playerNode.setOpacity(playerData ? 255 : 150);
            playerNode.setScale(0.8);
            playerNode.addTargetWithActionForControlEvents(this, this._playerButtonClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
            this.addChild(playerNode);

            // 有玩家資料
            if (playerData) {
                // 獎牌&獎牌數用 autoNode排列
                var medalLayoutNode = new GSAutoLayoutNode();
                medalLayoutNode.setSpace(2);
                medalLayoutNode.setPosition(playerPosX[i] - 5, 55);
                this.addChild(medalLayoutNode);

                // 獎牌
                var medalSp = new cc.Sprite("#fierceBattle_pic_badge.png");
                medalSp.setScale(0.8);
                medalLayoutNode.addChild(medalSp);

                // 獎牌數
                var medalNumLabel = new cc.LabelTTF(CommonUtility.getSimpleNumber(playerData.score, 1), JSFontBoldName, 9);
                medalNumLabel.setFontFillColor(JSColor.BLACK);
                medalLayoutNode.addChild(medalNumLabel);

                // 寶箱按鈕 有玩家才顯示
                var chestBtn = ButtonUtility.createSimpleButton(JSStringUtility.format("lobby_pic_chest_%02d.png", i + 1), cc.size(37, 31));
                chestBtn.addTargetWithActionForControlEvents(this, this._chestBtnClicked,
                    cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
                    cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
                    cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
                chestBtn.setAdjustBackgroundImage(false);
                chestBtn.setZoomOnTouchDown(false);
                chestBtn.setScale(0.8);
                chestBtn.setPosition(playerPosX[i], 34);
                chestBtn.rewards = playerData.rewards;
                chestBtn.pos = this.convertToNodeSpace(this.convertToWorldSpace(chestBtn.getPosition()));
                this.addChild(chestBtn);
            } else {
                // 未上榜文字
                var emptyLabel = new cc.LabelTTF(fierceStr("未上榜"), JSFontBoldName, 11, null, cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
                emptyLabel.setPosition(playerPosX[i], 55);
                emptyLabel.setFontFillColor(JSColor.BLACK);
                this.addChild(emptyLabel);
            }
        }

        // 下方分隔圖
        var bannerPosY = 7;
        var splitSprite = new ccui.Scale9Sprite("lobby_pic_banner_04.png");
        splitSprite.setPreferredSize(cc.size(300, 15));
        splitSprite.setPosition(midPosX, bannerPosY);
        this.addChild(splitSprite);

        // 分隔文字
        var titles = [fierceStr("名次"), fierceStr("名字"), fierceStr("獎牌數"), fierceStr("獎勵")];
        var titlePosX = [20, 110, 214, 280];
        for (var i = 0; i < 4; i++) {
            var titleLabel = new cc.LabelTTF(titles[i], JSFontBoldName, 8);
            titleLabel.setPosition(titlePosX[i], bannerPosY);
            this.addChild(titleLabel);
        }
    },

    /**
     * 按鈕
     */

    // 按到前三名的玩家
    _playerButtonClicked: function (sender) {
        // 跳個人資訊Dialog
        DialogManager.addDialog(new ProfileDialog(sender.player.account), false, true);
    },

    //  寶箱點擊
    _chestBtnClicked: function (sender, controlEvent) {
        // show獎勵泡泡框 TopNode跳框的方向會不同
        var obj = {
            controlEvent: controlEvent,
            pos: this.convertToWorldSpace(sender.getPosition()),
            rewards: sender.rewards,
            isTopNode: true
        };
        GS.dispatchCustomEvent("NotifyFierceBattleRankShowMessage", obj);
    }
});