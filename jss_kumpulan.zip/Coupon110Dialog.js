/**
 *  v5.1.5移入
 *  v5.4.3調整新包裝
 *  v5.4.5調整包裝
 *  原IDTexas : Coupon110Layer.cpp
 *  再儲值小額送10%
 */

var Coupon110Dialog = BaseDialogLayer.extend({
    ctor: function () {
        this._super();

        this.key = "Coupon110Dialog";

        this.loadFileArray = ["lobby/lobby_coupons.plist", "lobby/lobby_coupons.png"];

        // 先檔掉back key 等讀完在打開
        this.isLockBackKey = true;
    },

    // 離開時砍掉資源
    onExit: function () {
        // 砍掉資源
        cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[0]);

        this._super();
    },

    // An 返回鍵
    keyBackPressed: function () {
        if (this.isLockBackKey)
            return;

        this._showLeaveCheckDialog();
    },

    // 載入
    loadFileDone: function () {
        this._super();

        cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[0], this.loadFileArray[1]);

        var aniLayer = this._animationLayer;

        // 不檔back key
        this.isLockBackKey = false;

        var data = DataModal.purchaseCouponData.coupon110Data;
        this._param = data;

        var giftNode = new cc.Node();
        giftNode.setCascadeOpacityEnabled(true);
        giftNode.setScale(0.5);
        giftNode.setOpacity(0);
        giftNode.setPosition(JSScreenMidPos);
        aniLayer.addChild(giftNode);

        var ribbonSprite = new cc.Sprite("#coupon110_pic_ribbon_02.png");
        ribbonSprite.setPosition(-144, -2);
        giftNode.addChild(ribbonSprite);

        // 背景
        for (var i = 0; i < 2; i++) {
            // 禮物盒
            var background = new ccui.Scale9Sprite("coupon110_pic_giftbox.png");
            background.setCapInsets(cc.rect(44, 66, 24, 34));
            background.setPreferredSize(cc.size(145, 220));
            background.setScale(-2 * i + 1, 1);
            background.setAnchorPoint(1, 0.5);
            background.setPosition(-i, -26);
            giftNode.addChild(background);

            // 硬幣
            var coinSprite = new cc.Sprite("#coupon110_pic_coins.png");
            coinSprite.setScale(-2 * i + 1, 1);
            coinSprite.setPosition(17 + 502 * i + JSScreenBonusHalfWidth, 72 + JSScreenBonusHalfHeight);
            aniLayer.addChild(coinSprite);

            coinSprite = new cc.Sprite("#coupon110_pic_coins.png");
            coinSprite.setScale(-2 * i + 1, 1);
            coinSprite.setPosition(446 - 381 * i + JSScreenBonusHalfWidth, 32 + JSScreenBonusHalfHeight);
            aniLayer.addChild(coinSprite);
        }

        var ribbonLineSprite = new cc.Sprite("#coupon110_pic_ribbon_04.png");
        ribbonLineSprite.setScaleX(1.2);
        ribbonLineSprite.setPosition(2, 62);
        giftNode.addChild(ribbonLineSprite);

        // 禮物盒彩帶
        var ribbonSprite2 = new cc.Sprite("#coupon110_pic_ribbon_01.png");
        ribbonSprite2.setPosition(-1, 79);
        giftNode.addChild(ribbonSprite2);

        var ribbonSprite3 = new cc.Sprite("#coupon110_pic_ribbon_03.png");
        ribbonSprite3.setPosition(123, -80);
        giftNode.addChild(ribbonSprite3);

        // 文字的背景框
        var frameSprite = new ccui.Scale9Sprite("coupon110_bg_cube.png");
        frameSprite.setPreferredSize(cc.size(216, 68));
        frameSprite.setPosition(1, -24);
        giftNode.addChild(frameSprite);

        // 標題
        var titleSprite = new cc.Sprite("#coupon110_world.png");
        titleSprite.setPosition(JSScreenMidPos.x, 189 + JSScreenBonusHalfHeight);
        titleSprite.setOpacity(0);
        aniLayer.addChild(titleSprite);

        var contentNode = new cc.Node();
        contentNode.setCascadeOpacityEnabled(true);
        contentNode.setOpacity(0);
        aniLayer.addChild(contentNode);

        // 儲值按鈕
        var purchaseBtn = ButtonUtility.createSimpleButton("coupon110_btn_green.png", cc.size(120, 46), JSStringUtility.format("%s %s", TexasUtility.CURRENCY_STRING, data.payMoney) + LocalizedString.PurchaseCoupon("馬上購買"), JSColor.WHITE, 12);
        purchaseBtn.label.enableStroke(JSColor.BLACK, 2);
        purchaseBtn.label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        purchaseBtn.setPosition(JSScreenMidPos.x, 53 + JSScreenBonusHalfHeight);
        purchaseBtn.addTouchUpInsideAction(() => {
            // 送儲值方案
            DataModal.purchaseData.sendPurchase(data.productID);
            // 點擊埋點
            DataProcess.sendString("small_payment_gift_click");
        }, this);
        contentNode.addChild(purchaseBtn);

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.addTouchUpInsideAction(this._showLeaveCheckDialog, this);
        closeBtn.setPosition(484 + JSScreenBonusHalfWidth, 262 + JSScreenBonusHalfHeight);
        contentNode.addChild(closeBtn);

        var autoLayout = new GSAutoLayoutNode();
        autoLayout.setPosition(JSScreenMidPos.x, 121 + JSScreenBonusHalfHeight);
        autoLayout.setType(GSAutoLayout.TYPE.VERTICAL);

        // 可以拿到多少德撲幣
        var nowPrice1 = new cc.LabelTTF(data.newChipsWillGet, JSFontName, 24);
        nowPrice1.setFontFillColor(cc.color(255, 255, 0));
        autoLayout.addChild(nowPrice1);

        autoLayout.addEmptyNode(cc.size(3, 0));

        // 德撲幣
        var nowPrice2 = new cc.LabelTTF("Chips!", JSFontName, 14);
        autoLayout.addChild(nowPrice2);

        contentNode.addChild(autoLayout);

        // 跳出禮物盒動畫
        giftNode.runAction(cc.spawn(
            cc.scaleTo(0.5, 1).easing(cc.easeBackOut()),
            cc.fadeIn(0.5).easing(cc.easeIn(0.8))
        ));

        // 標題淡入->文字按鈕淡入->彩帶動畫
        titleSprite.runAction(cc.sequence(
            cc.delayTime(0.5),
            cc.fadeIn(0.5).easing(cc.easeIn(0.8)),
            cc.callFunc(() => {
                contentNode.runAction(cc.fadeIn(0.5).easing(cc.easeIn(0.8)));

                purchaseBtn.runAction(cc.sequence(
                        cc.scaleTo(0.8, 1.05).easing(cc.easeBackOut()),
                        cc.scaleTo(0.8, 1).easing(cc.easeBackOut())
                    ).repeatForever()
                );

                // 噴彩帶
                gaf.create("gaf/paperFlower.gaf", this, true, (gafAsset) => {
                    if (!gafAsset)
                        return;

                    var gafObject = gafAsset.createObjectAndRun(false);
                    gafObject.setPosition(280 + JSScreenBonusHalfWidth, JSScreenMidPos.y);
                    aniLayer.addChild(gafObject);
                });
            }),
            cc.delayTime(0.3),
            cc.callFunc(() => {
                // 噴彩帶
                gaf.create("gaf/paperFlower.gaf", this, true, (gafAsset) => {
                    if (!gafAsset)
                        return;

                    var gafObject = gafAsset.createObjectAndRun(false);
                    gafObject.setScale(0.8);
                    gafObject.setPosition(70 + JSScreenBonusHalfWidth, JSScreenMidPos.y);
                    aniLayer.addChild(gafObject);
                });
            })
        ));

        GS.addListener("NotifyPurchaseSuccess", this._closeDialogAnimation.bind(this), this);
        GS.addListener("NotifyStartWebPurchase", this.notifyStartWebPurchase.bind(this), this);
        GS.addListener("NotifyRemovePurchaseWebView", this.notifyRemovePurchaseWebView.bind(this), this);
    },

    // 放棄時的挽回Dialog
    _showLeaveCheckDialog: function () {
        var dialog = new Coupon110CommonDialog(this._param);
        dialog.startDialogAnimation();
        this._animationLayer.addChild(dialog, 100);
    },

    /**
     * 通知
     */
    // 打開網頁儲值
    notifyStartWebPurchase: function (event) {
        if (event && event.getUserData()) {
            var param = event.getUserData();
            var url = param["url"];
            DialogManager.startShowDialog(new PurchaseWebViewDialog(url));
        }
    },

    // 關閉網頁儲值
    notifyRemovePurchaseWebView: function () {
        // 關閉網頁儲值Dialog
        DialogManager.closeDialogByKey("PurchaseWebViewDialog");
    }
});