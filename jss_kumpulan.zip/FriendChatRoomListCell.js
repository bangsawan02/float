/**
 * 聊天室清單Cell
 * 顯示玩家頭像跟暱稱
 */

var FriendChatRoomListCell = cc.TableViewCell.extend({
    ctor: function (cellType, isGameGaple) {
        this._super();
        this._cellType = cellType;          // cell狀態 1:正常狀態 2:刪除狀態
        this._isDelete = false;             // 刪除是否被勾選
        this._isGameGaple = isGameGaple;

        this.setCascadeColorEnabled(true);
        this.setCascadeOpacityEnabled(true);

        if (isGameGaple)
            this._initGapleView();
        else
            this._initView();
    },

    _initView: function () {
        var midPosY = FriendChatRoomListCell.HEIGHT / 2 + 1;

        // 大頭照
        var photoNode = this._photoSprite = new LobbyCircleProfileNode();
        photoNode.setPosition(26, midPosY);
        photoNode.setScale(0.65);
        this.addChild(photoNode);

        // 暱稱
        var nicknameLabel = this._nicknameLabel = new cc.LabelTTF("", JSFontBoldName, 12, cc.size(120, 14), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_TOP);
        nicknameLabel.setPosition(103, midPosY);
        this.addChild(nicknameLabel);

        // 箭頭
        var arrowSp = this._arrowSp = new cc.Sprite("#lobby_pic_arrow.png");
        arrowSp.setRotation(180);
        arrowSp.setPosition(173, midPosY);
        arrowSp.setVisible(this._cellType === ChatCellType.NORMAL);
        this.addChild(arrowSp);

        // cell分隔線
        var lineSp = new ccui.Scale9Sprite("lobby_brown_line.png");
        lineSp.setPreferredSize(cc.size(170, 4));
        lineSp.setPosition(92, 2);
        this.addChild(lineSp);

        // 刪除對話框checkBox
        {
            var toggleSize = cc.size(23, 23);
            var toggleMidPos = cc.p(toggleSize.width / 2, toggleSize.height / 2);

            var deleteToggleNode = this._deleteToggleNode = new cc.Node();
            deleteToggleNode.setCascadeColorEnabled(true);
            deleteToggleNode.setCascadeOpacityEnabled(true);
            deleteToggleNode.setAnchorPoint(0.5, 0.5);
            deleteToggleNode.setContentSize(toggleSize);
            deleteToggleNode.setPosition(173, midPosY);
            deleteToggleNode.setScale(0.6);
            deleteToggleNode.setVisible(this._cellType === ChatCellType.DELETE);
            this.addChild(deleteToggleNode);

            // 白底框
            var selectBg = new ccui.Scale9Sprite("select_03.png");
            selectBg.setPreferredSize(toggleSize);
            selectBg.setPosition(toggleMidPos);
            deleteToggleNode.addChild(selectBg);

            // 勾勾
            var checkSp = this._checkSp = new cc.Sprite("#check.png");
            checkSp.setScale(1.5);
            checkSp.setVisible(this._isDelete);
            checkSp.setPosition(toggleMidPos);
            deleteToggleNode.addChild(checkSp);
        }
    },

    _initGapleView: function () {
        var midPosY = FriendChatRoomListCell.HEIGHT / 2 + 1;

        // 內容背景
        var bgSprite = new ccui.Scale9Sprite("gaple_bg_black.png");
        bgSprite.setPreferredSize(cc.size(186, 43));
        bgSprite.setPosition(100, midPosY);
        bgSprite.setOpacity(127);
        this.addChild(bgSprite);

        var photoBgSprite = new cc.Sprite("#gaple_pic_frame_photo.png");
        photoBgSprite.setPosition(26, midPosY);
        this.addChild(photoBgSprite);

        // 大頭照 要切成圓形
        var stencilSprite = new cc.Sprite("#gaple_pic_frame_photo.png");
        var clipNode = new cc.ClippingNode(stencilSprite);
        clipNode.setAlphaThreshold(0.5);
        clipNode.setCascadeColorEnabled(true);
        clipNode.setCascadeOpacityEnabled(true);
        this.addChild(clipNode);
        var photoSprite = this._photoSprite = new PhotoSprite("", 38, 38);
        clipNode.addChild(photoSprite);
        clipNode.setScale(0.95);
        clipNode.setPosition(26, midPosY);

        // 暱稱
        var nicknameLabel = this._nicknameLabel = new cc.LabelTTF("", JSFontBoldName, 12, cc.size(120, 14), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_TOP);
        nicknameLabel.setPosition(103, midPosY);
        this.addChild(nicknameLabel);

        // 箭頭
        var arrowSp = this._arrowSp = new cc.Sprite("#gaple_pic_back.png");
        arrowSp.setFlippedX(true);
        arrowSp.setScale(1.2);
        arrowSp.setPosition(173, midPosY);
        arrowSp.setVisible(this._cellType === ChatCellType.NORMAL);
        this.addChild(arrowSp);
    },

    /**
     * 刷新cell
     * @param param
     * @param idx : cell的index
     */
    refreshCell: function (param, idx, cellType) {
        if (!param)
            return;

        this._cellType = cellType;

        // cell index
        this.idx = idx;
        // 玩家的uid
        this.UID = param.UID;
        // 玩家的userID
        this.userID = param.userID;
        // 玩家的暱稱
        this.nickname = param.nickname;

        // 刷新紅點的顯示
        this._checkRedPoint(param.redPoint);

        // 刷新大頭貼
        if(this._isGameGaple)
            this._photoSprite.setPhotoUrlString(param.photo);
        else
            this._photoSprite.setPhotoUrl(param.photo);

        // 刷新暱稱
        this._nicknameLabel.setString(param.nickname);

        if (!this._isGameGaple) {
            // 是否刪除該對話框
            this._isDelete = param.isDelete;

            // 右邊箭頭顯示
            this._arrowSp.setVisible(this._cellType === ChatCellType.NORMAL);
            // 刪除框顯示
            this._deleteToggleNode.setVisible(this._cellType === ChatCellType.DELETE);
            this._checkSp.setVisible(this._isDelete);
        }
    },

    /**
     * 點到他 高亮
     */
    setIsHighlight: function (isSelect) {
        this.setOpacity(isSelect ? 150 : 255);
    },

    /**
     * 確認紅點
     * @param isShow 顯示紅點
     * @private
     */
    _checkRedPoint: function (isShow) {
        if (!isShow) {
            // 不顯示有的話把它關掉
            this._badge && this._badge.setVisible(false);
            return;
        }

        // 顯示紅點
        if (!this._badge) {
            var badge = this._badge = new BadgeNode();
            badge.useDefaultStyle();
            badge.setPosition(12, 35);
            this.addChild(badge);
        }
        this._badge.setVisible(true);
    },

    // 給外界檢查是否刪除
    isDelete: function () {
        return this._isDelete;
    },

    // 刪除核取方塊點擊
    toggleClicked: function () {
        // 切換刪除狀態
        this._isDelete = !this._isDelete;
        this._checkSp.setVisible(this._isDelete);
    },
});

FriendChatRoomListCell.HEIGHT = 44;
// Gaple系列牌桌用的
FriendChatRoomListCell.GAPLE_HEIGHT = 44;