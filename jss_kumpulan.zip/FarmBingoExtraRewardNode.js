var FarmBingoExtraRewardNode = cc.Node.extend({
    ctor: function () {
        this._super();
        this.setCascadeOpacityEnabled(true);

        // 特殊獎勵背景
        let bgSprite = new ccui.Scale9Sprite("farm_bingo_bg_frame_pot.png");
        bgSprite.setPosition(0, 0);
        bgSprite.setPreferredSize(cc.size(59, 51));
        this.addChild(bgSprite);

        // 特殊獎勵圖示
        let iconSprite = this._iconSprite = new GSShaderSprite("#farm_bingo_pic_apple_1.png");
        iconSprite.setPosition(0, 0);
        iconSprite.setShader(new GSGrayShader());
        this.addChild(iconSprite);

        // 倒數計時
        let timeLabel = this._timeLabel = new RemainTimeLabel(RemainTimeLabel.Style.WHITE, {
            enableImg: false,
            enableBg: true,
            fontSize: 8,
        });
        timeLabel.setPosition(0, -4);
        timeLabel.setVisible(false);
        this.addChild(timeLabel);

        // 按鈕
        let button = this._button = new Texas_Button(Texas_Button.Style.GRAY, cc.size(66, 25), "");
        button.setPosition(0, -21);
        button.setChangeColorWhenDisabled(false);
        button.setChangeOpacityWhenDisabled(false);
        button.setVisible(false);
        button.getTitleLabel().setFontSize(9);
        this.addChild(button);

        // 按鈕上的 KL/RP
        let buttonRpSprite = button.koinSprite = new cc.Sprite(ProfileData.getKoinLuxyRes("#lobby_icon_koinLuxy"));
        buttonRpSprite.setPosition(-18, 0);
        buttonRpSprite.setScale(0.4);
        buttonRpSprite.setVisible(false);
        button.addChildToContentNode(buttonRpSprite, 2);    // 要在光點之上

        // 小紅點
        let badgeNode = this._badgeNode = new BadgeNode();
        badgeNode.useDefaultStyle();
        badgeNode.setCascadeOpacityEnabled(true);
        badgeNode.setVisible(false);
        badgeNode.setPosition(26, 5);
        button.addChildToContentNode(badgeNode);
    },

    refreshView: function (data, index) {
        this._button.index = index;
        this._button.setEnabled(data);
        if (data) {
            // 有獎勵
            this._iconSprite.restoreNormalShader();
            this._button.setVisible(true);

            // 罐子的剩餘時間
            let remainTime = JSCodeUtility.getRemainTime(data.remainTime, data.socketTime);
            if (remainTime > 0) {
                // 倒數中
                // 按鈕
                this._button.setBtnStyle(Texas_Button.Style.GREEN);
                this._button.getTitleLabel().setString(JSCodeUtility.getCurrencyString(data.cost));
                this._button.getTitleLabel().setPositionX(10);
                this._button.koinSprite.setVisible(true);
                this._button.cost = data.cost;
                this._badgeNode.setVisible(false);

                this._timeLabel.setVisible(true);
                this._timeLabel.countdownSeconds(remainTime, () => {
                    this.refreshView(data, index);
                });
            } else {
                // 按鈕
                this._button.setBtnStyle(Texas_Button.Style.ORANGE);
                this._button.getTitleLabel().setString(LocalizedString.FarmBingo("領獎"));
                this._button.getTitleLabel().setPositionX(0);
                this._button.koinSprite.setVisible(false);
                this._button.cost = 0;
                this._timeLabel.setVisible(false);
                this._badgeNode.setVisible(true);
            }
        } else {
            // 無獎勵
            this._iconSprite.setShader(new GSGrayShader());
            this._button.setVisible(false);
            this._timeLabel.setVisible(false);
            this._badgeNode.setVisible(false);
        }
    },

    getButton: function () {
        return this._button;
    },
});