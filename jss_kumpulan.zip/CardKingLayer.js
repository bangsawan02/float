/**
 * 牌王頁面
 * 移植自中文德撲
 */

var CardKingLayer = cc.Layer.extend({
    ctor: function (page) {
        this._super();

        this._pageArray = [];           // 用來放頁面內容
        this._defaultPage = page;       // 預設開啟頁面

        // 要倒數更新資料用的
        this._remainTime = 0;
        this._socketTime = 0;

        // 素材是否讀取完畢
        this._loadFileDone = false;

        var resources = this._resourceArray = [
            "cardKing/cardKing.plist", "cardKing/cardKing.png",
            "common/number/num_19.plist", "common/number/num_19.png",
            "common/number/num_20.plist", "common/number/num_20.png"
        ];

        if (cc.sys.isNative || (cc.textureCache.getTextureForKey(resources[1]) && cc.textureCache.getTextureForKey(resources[3]) && cc.textureCache.getTextureForKey(resources[5]))) {
            this.loadFileDone();
        } else {
            // H5要先Loader
            cc.loader.load(resources, () => {
                this.loadFileDone();
            });
        }
    },

    onExit: function () {
        if (this._loadFileDone) {
            cc.spriteFrameCache.removeSpriteFramesFromFile(this._resourceArray[0]);
            cc.spriteFrameCache.removeSpriteFramesFromFile(this._resourceArray[2]);
            cc.spriteFrameCache.removeSpriteFramesFromFile(this._resourceArray[4]);
        }

        this._super();
    },

    // 讀取素材完畢
    loadFileDone: function () {
        this._loadFileDone = true;

        // 加素材
        cc.spriteFrameCache.addSpriteFrames(this._resourceArray[0], this._resourceArray[1]);
        cc.spriteFrameCache.addSpriteFrames(this._resourceArray[2], this._resourceArray[3]);
        cc.spriteFrameCache.addSpriteFrames(this._resourceArray[4], this._resourceArray[5]);

        var cardKingData = DataModal.cardKingData;
        var cardKingString = LocalizedString.CardKing;

        // 背景
        var bgLayer = new cc.LayerColor(cc.color(9, 5, 26), JSVisibleSize.width, JSVisibleSize.height);
        this.addChild(bgLayer, -1000);

        // 上方文字底 / 按鈕
        var titleNode = new TitleBackgroundNode(cardKingString("牌王"));
        titleNode.setTitleToLeft();
        titleNode.addTabButton([cardKingString("說明"), cardKingString("牌王地圖"), cardKingString("牌王徽章")], this._tabClicked, this);
        titleNode.setPosition(JSScreenMidPos.x, JSVisibleSize.height - TITLE_BG_HEIGHT / 2);
        this.addChild(titleNode, 10);

        // 抓出按鈕
        this._tabItems = titleNode.getTabItems();

        // 放小紅點
        this._tabBadge = [];
        this._generateBadge();

        // 放畫面用的node
        var layerNode = this._layerNode = new cc.Node();
        layerNode.setVisible(false);
        this.addChild(layerNode);

        // 轉圈圈
        var loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.setVisible(false);
        loadingSprite.setPosition(JSScreenMidPos);
        this.addChild(loadingSprite);

        // 判斷現在應該打開哪一頁
        var defaultPage = this._defaultPage;
        if (!defaultPage) {
            // 如果沒有預設就看地圖頁有沒有小紅點
            if (cardKingData.mapTabHasRedDot)
                defaultPage = CardKingLayer.PageType.MAP;
            else
                defaultPage = CardKingLayer.PageType.MEDAL;
        }

        // 打開預設的頁面
        titleNode.setTabClickedIndex(defaultPage);

        // 檢查要不要跳出教學
        var key = UserDefaultKey.CardKingTeachLayer + DataModal.profileData.account;
        if (defaultPage === CardKingLayer.PageType.MEDAL && !parseInt(GS.localStorage.getItem(key, 0, true))) {
            // 要顯示的泡泡匡位置
            var index = 4;
            var data = cardKingData.medalDetail;
            for (var i = 5; i > 0; --i) {
                if (data[i] && !data[i].isCurrentSeasonHave) {
                    index = i - 1;
                    break;
                }
            }
            var pos = this._pageArray[CardKingLayer.PageType.MEDAL].getMedalPosByIndex(index);

            // 跳教學
            this.addChild(new CardKingTeachLayer(pos), 10);

            // 紀錄已跳過
            GS.localStorage.setItem(key, "1", true);
        }

        // 時間到要更新資訊
        if (JSCodeUtility.getRemainTime(cardKingData.remainTime, cardKingData.socketTime) <= 0) {
            // 重要資料
            cardKingData.startGetInfo();

            // 卡loading
            loadingSprite.start();
        } else {
            layerNode.setVisible(true);

            this._remainTime = DataModal.cardKingData.remainTime;
            this._socketTime = DataModal.cardKingData.socketTime;

            this.schedule(this._scheduleUpdateData, 0.5, cc.REPEAT_FOREVER);
        }

        // 通知
        GS.addListener("NotifyCardKingInfoDone", this.notifyCardKingInfoDone.bind(this), this);
    },

    // 看是不是要創小紅點, 會先把小紅點清掉
    _generateBadge: function () {
        this._tabBadge.forEach(cur => cur && cur.removeFromParent());
        for (var i = 0; i < this._tabItems.length; ++i) {
            var badge = undefined;
            // 要不要創紅點
            var needToCreate = false;
            switch (i) {
                case CardKingLayer.PageType.MAP:
                    needToCreate = DataModal.cardKingData.mapTabHasRedDot;
                    break;
                default:
                    break;
            }

            // 有tab要創再創
            if (needToCreate && this._tabItems[i]) {
                badge = new BadgeNode();
                badge.useDefaultStyle();
                badge.setPosition(58, 24);
                badge.setScale(0.8);
                this._tabItems[i].addChild(badge);
            }

            this._tabBadge.push(badge);
        }
    },

    /**
     * 按鈕
     */
    // 按到Tab
    _tabClicked: function (index) {
        var pageArray = this._pageArray;

        // 先把所有頁面關掉
        pageArray.forEach(page => page && page.setVisible(false));

        var page = pageArray[index];
        if (!page) {
            switch (index) {
                // 說明頁
                case CardKingLayer.PageType.INFO:
                    // 埋點
                    DataProcess.sendString('track_crown_king {"type":"4"}');
                    page = this._pageArray[index] = new CardKingInfoLayer();
                    break;
                // 牌王地圖
                case CardKingLayer.PageType.MAP:
                    // 埋點
                    DataProcess.sendString('track_crown_king {"type":"16"}');
                    // 消紅點
                    DataModal.cardKingData.mapTabHasRedDot = false;
                    page = this._pageArray[index] = new CardKingMapLayer();
                    break;
                // 牌王頁面
                case CardKingLayer.PageType.MEDAL:
                    page = this._pageArray[index] = new CardKingMedalLayer();
                    break;
            }
            this._layerNode.addChild(page, 1);
        }
        // 已經創過的才改 visible
        else {
            page.setVisible(true);
        }

        // 拿掉小紅點
        if (this._tabBadge[index]) {
            this._tabBadge[index].removeFromParent();
            this._tabBadge[index] = null;
        }
    },

    _scheduleUpdateData: function () {
        // 時間到要資料
        if (JSCodeUtility.getRemainTime(this._remainTime, this._socketTime) <= 0) {
            this.unschedule(this._scheduleUpdateData);
            if (this._socketTime !== 0) {
                DataModal.cardKingData.startGetInfo();
                this._loadingSprite.start();
            }
        }
    },

    /**
     * 通知
     */
    notifyCardKingInfoDone: function () {
        this._layerNode.setVisible(true);
        this._loadingSprite.stop();

        var cardKingData = DataModal.cardKingData;
        if (cardKingData.getIsOpen() && JSCodeUtility.getRemainTimeByParam(cardKingData) > 0) {
            this._remainTime = cardKingData.remainTime;
            this._socketTime = cardKingData.socketTime;

            this.unschedule(this._scheduleUpdateData);
            this.schedule(this._scheduleUpdateData, 0.5, cc.REPEAT_FOREVER);
        } else {
            if (this._pageArray[CardKingLayer.PageType.INFO]?.isVisible()) {
                // 若說明頁可見，則隱藏
                this._pageArray[CardKingLayer.PageType.INFO].setVisible(false);
            }

            // 跳結束 dialog
            const dialog = new Dialog({
                content: LocalizedString.CardKing("本季已結束"),
                buttons: ["OK"],
                closeButton: false,
            });
            dialog.setCloseCallback(() => {
                PushScene.popLayer();
            });
            dialog.startDialogAnimation();
            this.addChild(dialog, 100);
        }
    }
});

// 頁面類型
CardKingLayer.PageType = {
    INFO: 0,        // 說明
    MAP: 1,         // 牌王地圖
    MEDAL: 2       // 牌王徽章
};