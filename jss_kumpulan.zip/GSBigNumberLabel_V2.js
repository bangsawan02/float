/**
 * 大數字跑動
 * 操作的並非數字所以獨立不繼承 GSNumberLabel_V2
 */
var GSBigNumberLabel_V2 = GSCustomRunnerNumberLabel.extend({
    ctor: function (label, fontName, fontSize, dimensions, hAlignment, vAlignment) {
        // 因為我們要自己調runner, 避免他一開始就設定數字, 這邊先不傳
        let tempLabel = label;
        label = "";
        this._super(label, fontName, fontSize, dimensions, hAlignment, vAlignment);
        this._isAddSymbol = false;          // 是否要加前面的符號
        this._isSymbolAtFront = false;      // 符號是否加在前面

        this.isUseCurrencyString = false;   // 是否使用金錢用數字
        this.symbol = "";                   // 符號字串
        this._format = undefined;

        // 設定跑整數
        GSCustomRunnerNumberLabel.prototype.setRunner.call(this, new GSBigIntegerRunner());

        // 向下相容
        let number = JSCodeUtility.getFloatValue(tempLabel, 0);
        if (number !== 0) {
            this.setNumber(number);
        }
    },

    /**
     * 為了修jsDoc的提示QQ
     * 設定數字
     * @param {string} number
     */
    setNumber: function (number) {
        this._super(number);
    },

    /**
     * 為了修jsDoc的提示QQ
     * 更新目標數字
     * @param {string} toNumber
     * @param {number} duration
     */
    updateToNumber: function (toNumber, duration = GSNumberRunner.DefaultUpdateTime) {
        this._super(toNumber, duration)
    },

    // 取目前的數字字串(有逗號) 大數做法
    _getCurrencyString: function (number) {
        return this.isUseCurrencyString ? number.replace(/\d(?=(?:\d{3})+$)/g, c => c + ",") : number;
    },

    /**
     * 設定目標數字
     * @param {string} toNumber
     * @param {boolean} isAnimation
     */
    setToNumber: function (toNumber, isAnimation = true) {
        toNumber = JSCodeUtility.getStringValue(toNumber).match(/^[1-9]\d*|^0$/);
        toNumber = toNumber ? toNumber[0] : "";

        if (toNumber.length === 0) {
            cc.log("Error: GSBigNumberLabel_V2 Number is invalid");
            return;
        }

        if (isAnimation) {
            this.updateToNumber(toNumber);
        } else {
            this.setNumber(toNumber);
        }
    },

    setRunner: function (_) {
        // 不支援自定義runner
        cc.log("Error: GSBigNumberLabel_V2 does not support custom runner.");
    },

    setCustomFormatFunc: function (_) {
        // 不支援自定義格式
        cc.log("Error: GSBigNumberLabel_V2 does not support custom format function.");
    },

    _getNumberString: function (number) {
        return this.reformat(this.getNowNumber());
    },

    // delegate為了向下相容
    setNumberUpdateCallback: function (callback) {
        this.setNumberChangeCallback(callback);
    },

    // 是否使用貨幣字串
    setUseCurrencyString: function (enable) {
        this.isUseCurrencyString = enable;
    },

    /**
     * 設定是否要加符號
     * @param symbol 空值表示不設定
     * @param isFront 是否加在前方
     */
    setSymbol: function (symbol, isFront = false) {
        this.symbol = symbol;
        this._isAddSymbol = !!symbol.length;

        // 有設定symbol才能設定位置
        if (this._isAddSymbol)
            this._isSymbolAtFront = isFront;
    },

    /**
     * 設定要顯示的格式
     * @param format ex: "x%s倍", %s就是上數的數字
     * 如果有有貨幣轉換會出錯，盡量傳 %s
     * 有symbol 就不會套用format
     */
    setFormat: function (format) {
        this._format = format;
    },

    /**
     * 重刷新字串格式
     * @param number
     */
    reformat: function (number) {
        var label = this._getCurrencyString(number);
        if (this._isAddSymbol) {
            if (this._isSymbolAtFront)
                label = this.symbol + label;
            else
                label = label + this.symbol;

        } else {
            if (this._format) {
                // 如果有貨幣轉換，先把數字轉成文字
                if (this.isUseCurrencyString) {
                    this._format = this._format.replace("%d", "%s");
                    this._format = this._format.replace("%f", "%s");
                }
                label = JSStringUtility.format(this._format, label);
            }
        }
        return label;
    },
});