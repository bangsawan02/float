/**
 * 足球機台的數字Led
 */
var FootballLedNode = cc.Node.extend({
    ctor: function () {
        this._super();

        this.setCascadeOpacityEnabled(true);

        this.nowMoney = 0;
        this._totalMoney = 0;
        this._updateTime = 0.3;         // 更新數字要多久

        // 上方文字
        var betSprite = new cc.Sprite("#football_word_TotalBet.png");
        betSprite.setPosition(0, 17);
        this.addChild(betSprite, 1);

        // 背景
        var bgSprite = new ccui.Scale9Sprite("bg_black_and_gray_frame.png");
        bgSprite.setPreferredSize(cc.size(144, 26));
        this.addChild(bgSprite);

        // 數字 從右邊開始放到左邊 每3個後會有1個逗號
        this._ledNumberArray = [];
        this._ledDotArray = [];
        var posX = 64;
        for (var i = 0; i < 11; i++) {
            if (i % 3 === 0 && i !== 0) {
                // 要加逗號
                var dotSprite = new cc.Sprite("#vegas_led10.png");
                dotSprite.setPosition(posX + 2.5, -8);
                this.addChild(dotSprite);

                this._ledDotArray.push(dotSprite);

                posX -= 6;
            }

            var ledSprite = new cc.Sprite("#vegas_led0.png");
            ledSprite.setPosition(posX, 0);
            this.addChild(ledSprite);

            this._ledNumberArray.push(ledSprite);

            posX -= 11;
        }
    },

    /**
     * 設定金錢 可以讓他有動畫
     * @param money
     * @param isAnimation 是否要有動畫
     */
    setMoney: function (money, isAnimation) {
        var len = arguments.length;
        if (len < 2)
            isAnimation = true;

        if (isAnimation) {
            this._totalMoney = money;
            this._floorNumber = this.nowMoney;
            this._usedTime = 0;

            if (this._floorNumber === this._totalMoney)
                return;

            this.unschedule(this._scheduleUpdateMoney);
            this.schedule(this._scheduleUpdateMoney);
        } else {
            this._totalMoney = money;
            this._floorNumber = this.nowMoney;
            this._scheduleUpdateMoney(999999)
        }
    },

    // 真正更新金錢的地方
    _updateMoney: function (money) {
        var moneyString = (money || "0").toString();
        var moneyStringLen = moneyString.length;
        for (var i = 0; i < 11; i++) {
            var ledSprite = this._ledNumberArray[i];
            var nowPos = moneyStringLen - i - 1;
            var nowMoneyChar = (nowPos < 0 ? "0" : moneyString[nowPos]);

            ledSprite.setSpriteFrame("vegas_led" + nowMoneyChar + ".png");
        }
    },

    //運算
    _scheduleUpdateMoney: function (dt) {
        this._usedTime += dt;
        if (this._usedTime < this._updateTime)
            this.nowMoney = Math.floor(this._floorNumber + (this._totalMoney - this._floorNumber) * (this._usedTime / this._updateTime));
        else {
            this.unschedule(this.scheduleUpdateLabel);
            this.nowMoney = this._totalMoney;
        }

        this._updateMoney(this.nowMoney);
    },
});