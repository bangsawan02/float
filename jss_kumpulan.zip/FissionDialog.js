/**
 * 裂變的Dialog
 */
var FissionDialog = BaseDialogLayer.extend({
    ctor: function (param) {
        this._super();

        this.key = "FissionDialog";

        this._param = param;
        this._shareLink = param.shareLink;
        this._shareMsg = param.shareMsg;

        var aniLayer = this._animationLayer;

        // 背景底
        var bgSprite = this._bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(cc.size(420, 280));
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite);

        // 下方光暈
        var bgLightSprite = new cc.Sprite("#lobby_pic_light_gold.png");
        bgLightSprite.setScale(0.8, -0.5);
        bgLightSprite.setPosition(JSScreenMidPos.x, 48 + JSScreenBonusHalfHeight);
        aniLayer.addChild(bgLightSprite);

        var titleLabel = new cc.LabelTTF(LocalizedString.KoinLuxy("分享邀請碼"), JSFontBoldName, 12);
        titleLabel.setPosition(JSScreenMidPos.x, 45 + JSScreenBonusHalfHeight);
        aniLayer.addChild(titleLabel);

        // 關閉按鈕
        var closeBtn = ButtonUtility.createSimpleImageButton("lobby_btn_circle_04.png", null, "#lobby_btn_pic_window_x.png");
        closeBtn.setPosition(463 + JSScreenBonusHalfWidth, 275 + JSScreenBonusHalfHeight);
        closeBtn.addTouchUpInsideAction(this._closeDialogAnimation, this);
        aniLayer.addChild(closeBtn, 1);

        // 排版的node
        var autoLayoutNode = new GSAutoLayoutNode();
        autoLayoutNode.setSpace(4);
        autoLayoutNode.setPosition(JSScreenMidPos.x, 25 + JSScreenBonusHalfHeight);
        aniLayer.addChild(autoLayoutNode, 1);

        // whatsApp分享按鈕
        var whatsAppShareBtn = ButtonUtility.createSimpleButton("common_icon_Whatsapp.png");
        whatsAppShareBtn.addTouchUpInsideAction(this._whatsAppShareClicked, this);
        autoLayoutNode.addChild(whatsAppShareBtn);

        // fb分享按鈕
        var fbShareBtn = ButtonUtility.createSimpleButton("common_icon_FB.png");
        fbShareBtn.addTouchUpInsideAction(this._fbShareClicked, this);
        autoLayoutNode.addChild(fbShareBtn);

        // 分享按鈕
        var shareBtn = ButtonUtility.createSimpleButton("common_icon_share.png");
        shareBtn.addTouchUpInsideAction(this._shareClicked, this);
        autoLayoutNode.addChild(shareBtn);
    },

    // 打開畫面結束
    _dialogOpenAnimationDone: function () {
        this._super();

        // WebView
        var webView = this._webView = new GSWebView();
        webView.setContentSize(390, 215);
        webView.setPosition(JSScreenMidPos.x, 164 + JSScreenBonusHalfHeight);
        !cc.sys.isNative && webView.setTransparent(true);
        this._animationLayer.addChild(webView);

        webView.loadURL(this._param.url);
        cc.log(this.key + " 連到: " + this._param.url);
    },

    // 關掉Dialog
    _closeDialogAnimation: function () {
        this._webView && this._webView.setVisible(false);

        this._super();
    },

    /**
     * whatsApp分享
     */
    _whatsAppShareClicked: function () {
        // 去分享
        if (cc.sys.isNative) {
            if (!GSOpenAppWrapper.shareMessageByWhatsapp(this._shareMsg)) {
                // 代表沒App 要跳沒App畫面
                var message = JSStringUtility.format(LocalizedString.KoinLuxy("請先下載%s"), "WhatsApp");
                // 原生的然後又是Error 跳視窗
                AlertDialog.showAlert("", message);
            }
        }
    },

    /**
     * FB分享
     */
    _fbShareClicked: function () {
        // 去分享 先判斷是否登入FB了
        var shareFunc = () => {
            GSFacebookHelper.share({
                dialog: "messageLink",
                link: this._shareLink,
                quote: this._shareMsg
            }, () => {
                // callback結束 目前不做事
            });
        };

        if (GSFacebookHelper.isLoggedIn()) {
            // 已登入過 開始走分享
            shareFunc();
        } else {
            GSFacebookHelper.login(function (type, param) {
                if (type === 0) {
                    // 開始分享
                    shareFunc();
                } else if (type === 1 && cc.sys.isNative) {
                    GSFacebookHelper.showError(param);
                }
            });
        }
    },

    /**
     * 選擇分享app
     */
    _shareClicked: function () {
        GSOpenAppWrapper.shareMessage(this._shareMsg);
    }
});