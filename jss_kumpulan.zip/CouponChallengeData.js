class CouponChallengeData extends PurchaseTriggerIntegrationDataTemplate {
    constructor() {
        super();
        this.registerSocket({
            "coupon_challenge_info": this.cmd_coupon_challenge_info.bind(this),
            "coupon_challenge_recharge_done": this.cmd_coupon_challenge_recharge_done.bind(this),
        });
    }

    requestIcon() {
        // 這邊沒有 icon，直接要 info
        DataProcess.sendString("coupon_challenge_info");
    }

    requestInfo() {
        DataProcess.sendString("coupon_challenge_info");
    }

    /**
     * 更新紅點
     * 儲值整合 icon 每 1s 更新一次
     */
    refreshBadge() {
        // Restore state.
        this.isShowBadge = false;

        if (this.getIsOpen()) {
            // 每日小紅點
            const oldTime = GS.localStorage.getItem(UserDefaultKey.CouponChallengeDayFirstIn + DataModal.profileData.account, 0);
            this.isShowBadge |= TexasUtility.getNowIsChangeDay(oldTime);

            // 顯示過的小紅點
            const nowIndex = this.tickets?.findIndex((item) => item.status === CouponChallengeData.TicketStatus.AVAILABLE);
            const lastIndex = GS.localStorage.getItem(UserDefaultKey.CouponChallengeLastShowCoupon + DataModal.profileData.account, -1);
            this.isShowBadge |= (nowIndex + "") !== lastIndex;
        }
    }

    /**
     * {
     *     "error": 0, // 0: 活動開啟, 1: 活動關閉, 2: 版本不符, 3: 等級不符, 4: 剩餘時間小於3hr, 5: 用完三張
     *     "pop": 1, // 0 不彈跳 1 彈跳
     *     "cluster": 1, // 玩家分群，埋點用
     *     "left_time" : "12345", // 活動剩餘時間
     *     "zones": [ // 每張優惠券的資料
     *          //  KEY定義：
     *          //    - zone => 第N張優惠券
     *          //    - bonus => coupon %數
     *          //    - status => 0: 不可用, 1: 可使用, 2: 已使用
     *          //    - limit => 可用券的最低儲值金額，該券為IAP時才會有這個key
     *         { "zone": 1, "bonus": 100, "status": 1, limit: 15000 },
     *         { "zone": 2, "bonus": 200, "status": 0 },
     *         { "zone": 3, "bonus": 300, "status": 0, limit: 15000 },
     *     ],
     * }
     * @param key
     * @param value
     */
    cmd_coupon_challenge_info(key, value) {
        const jsonValue = JSON.parse(value || "{}");

        this.needRefreshData = false;

        this.error = JSCodeUtility.getIntValue(jsonValue["error"]);

        if (this.error === 0 && jsonValue["zones"]?.length === 3) {
            // 分群
            this.group = JSCodeUtility.getIntValue(jsonValue["cluster"]);
            // 倒數
            this.setRemainTime(jsonValue["left_time"]);
            // 三張票
            this.tickets = jsonValue["zones"].sort((a, b) => {
                return JSCodeUtility.getIntValue(a["zone"]) - JSCodeUtility.getIntValue(b["zone"]);
            }).map((item) => {
                return {
                    // 加倍
                    bonus: JSCodeUtility.getIntValue(item["bonus"], 0),
                    // 使用狀態
                    status: JSCodeUtility.getIntValue(item["status"], 0),
                    // 多少錢以上才能用
                    limit: JSCodeUtility.getIntValue(item["limit"], 0),
                };
            });
            // 主動彈出
            if (JSCodeUtility.getBooleanValue(jsonValue["pop"], false)) {
                this.setPopType(PurchaseTriggerIntegrationData.purchaseType.COUPON_CHALLENGE);
            }

            // 成功有優惠券，更新一下優惠券背包
            DataModal.purchaseCouponData.startGetCouponAssembleInfo();
        }

        // 更新小紅點
        this._integrationData.refreshPurchaseActivityRedPoint();

        // 刷畫面
        this._integrationData.updateOpenPurchaseActivityCount();
        GS.dispatchCustomEvent("NotifyCouponChallengeInfoDone");
    }

    // 儲值完用掉優惠券 server 會傳這個過來，點開活動才去要資料
    cmd_coupon_challenge_recharge_done(key, value) {
        this.needRefreshData = true;
        GS.dispatchCustomEvent("NotifyCouponChallengeInfoDone");
    }
}

CouponChallengeData.TicketStatus = {
    UNAVAILABLE: 0,
    AVAILABLE: 1,
    USED: 2,
};
