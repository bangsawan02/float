/**
 * 共用的 loading layer。GSLoadingSprite 會置中顯示在 DummyTouchLayer 上。
 *
 * @param {cc.size} [touchLayerSize] Touch Layer 的大小
 */
var CommonLoadingLayer = cc.Layer.extend({
    ctor: function (size = JSVisibleSize) {
        this._super();

        // 檔Touch用
        let dummyTouchLayer = this._dummyTouchLayer = new DummyTouchLayer(size, JSDebugMode);
        dummyTouchLayer.setPosition(0, 0);
        this.addChild(dummyTouchLayer);

        // 加一個Loading
        let loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(SizeUtils.getMidPoint(size));
        loadingSprite.start();
        dummyTouchLayer.addChild(loadingSprite);
    },

    /**
     * 設定 Loading Sprite
     * @param {boolean} isLoadingVisible 是否顯示 Loading
     * @param {boolean} isLockTouch 是否鎖定 Touch
     */
    setLoadingSprite: function (isLoadingVisible, isLockTouch) {
        this._loadingSprite && (isLoadingVisible ? this._loadingSprite.start() : this._loadingSprite.stop());
        this._dummyTouchLayer && this._dummyTouchLayer.setVisible(isLoadingVisible || isLockTouch);
    },
});