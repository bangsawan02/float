/**
 * Cangkulan 玩家的手牌
 */
var Cangkulan_HandCardCountNode = cc.Node.extend({
    ctor: function () {
        this._super();

        var mainNode = this._mainNode = new cc.Node();
        this.addChild(mainNode);

        var cardNodes = this._cardNodes = new cc.Node();
        cardNodes.setPosition(0, -20);
        mainNode.addChild(cardNodes);

        this._isShowCounter = false;

        // 手牌數量
        this.cardCount = 0;

        // 手牌
        this._cards = [];

        // 牌要旋轉的角度
        this._cardRotation =
            [1, -15, 18, -25, 37, -40, 55];
        this._cardPos =
            [cc.p(-0.2, 11.9), cc.p(-0.6, 7.5), cc.p(2.2, 16.5), cc.p(-2.2, 3.7),
                cc.p(4.9, 20.3), cc.p(0, 0), cc.p(8.3, 22.0)];

        // 手牌上的數量 加上粗框
        var numLabel = this._numLabel = new cc.LabelTTF("", JSFontBoldName, 11);
        numLabel.enableStroke(JSColor.BLACK, 3);
        numLabel.setPosition(6, 4);
        this.addChild(numLabel);
    },

    clean: function () {
        this._isShowCounter = false;
        this._mainNode.setScale(1);
        this.cardCount = 0;
        this._setCardCount();
        this._cards = [];
        this._cardNodes.removeAllChildren();
    },

    /**
     * 加入手牌
     */
    addCard: function () {
        this.cardCount++;
        // 實體牌最多顯示7張 超過7張用數字顯示
        if (this.cardCount <= Cangkulan_DealCount && this.cardCount >= 1) {
            var index = this.cardCount - 1;
            var card = new PokerCardNode();
            card.setPosition(this._cardPos[index]);
            card.setScale(0.52);
            card.setAnchorPoint(0, 0);
            card.setRotation(this._cardRotation[index]);
            card.setCardIsInBack(true);
            var zoderIdx = (this.cardCount % 2) ? Cangkulan_DealCount - this.cardCount : Cangkulan_DealCount + this.cardCount;
            this._cardNodes.addChild(card, zoderIdx);

            this._cards.push(card);
        }

        if (this._isShowCounter)
            this._setCardCount();
    },

    /**
     * 棄牌
     */
    foldCard: function () {
        this.cardCount--;
        if (this.cardCount < Cangkulan_DealCount) {
            var card = this._cards.pop();
            card && card.removeFromParent();
        }
        this._setCardCount();
    },

    /**
     * 發牌完成
     */
    dealDone: function () {
        this._mainNode.runAction(cc.sequence(
            cc.scaleTo(0.1, 0.4),
            cc.callFunc(() => {
                this._isShowCounter = true;
                this._setCardCount();
            })));
    },

    /**
     * 設定手牌的數量
     * @private
     */
    _setCardCount: function () {
        var str = (this.cardCount <= 0) ? "" : this.cardCount;
        this._numLabel.setString(str);
    }
});