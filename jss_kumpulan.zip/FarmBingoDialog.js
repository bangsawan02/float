/**
 *  v5.6.5 農場賓果 - 主Dialog
 */
var FarmBingoDialog = BaseEventDialog.extend({
    ctor: function () {
        this._super();

        this.key = "FarmBingoDialog";

        this._isAutoRunning = false;                        // 初始化自動領獎狀態
        this._isQueueRunning = false;                       // 是否正在跑領球中
        this._isExtraRewardBuyAbort = false;                // 是否先領
        this._bingoReadyHandInfoArr = Array(12).fill(0);    // 賓果連線情況

        // 發光 spine 列表
        this._gridGlowingSpineList = [];

        // 要讀的圖檔
        this.loadFileArray = [
            "luxyPass/luxyPass.plist", "luxyPass/luxyPass.png",
            "farmBingo/farmBingo.plist", "farmBingo/farmBingo.png",
            "common/number/farm_bingo.plist", "common/number/farm_bingo.png",
            "common/number/ramadan_round.plist", "common/number/ramadan_round.png",
        ];

        // 讓背景黑一點
        this.dialogBgColor = cc.color(0, 0, 0, 218);

        SemaphoreManager.create("FarmBingoDialogEventEndSemaphore", 1);
    },

    onEnter: function () {
        this._super();

        // 埋點
        UserAnalyticsTrackUtils.sendTrack("農場賓果 >=8.4 進入介面", DataModal.farmBingoData.group);

        // 取得進入次數資料
        let enterTimesData = JSON.parse(GS.localStorage.getItem(UserDefaultKey.FarmBingoDialogEnterTimes, JSON.stringify({
            lastEnterDate: TexasUtility.getNowTimeMillisecondString(),
            enterTimes: 0,
        })));

        if (TexasUtility.getNowIsChangeDay(enterTimesData.lastEnterDate)) {
            // 距離上次進入已換天，次數歸零
            enterTimesData.enterTimes = 0;
        }

        // 更新進入次數資料
        enterTimesData.lastEnterDate = TexasUtility.getNowTimeMillisecondString();
        enterTimesData.enterTimes++;
        GS.localStorage.setItem(UserDefaultKey.FarmBingoDialogEnterTimes, JSON.stringify(enterTimesData));

        // 記錄今天進過dialog
        var key = UserDefaultKey.FarmBingoIconRedPoint + DataModal.profileData.account;
        GS.localStorage.setItem(key, TexasUtility.getNowTimeMillisecondString());

        // 進入次數
        this._enteringTimes = enterTimesData.enterTimes;
    },

    onExit: function () {
        // 更新icon
        GS.dispatchCustomEvent("NotifyFarmBingoIconRefresh");

        this._super();
    },

    loadFileDone: function () {
        this._super();

        let aniLayer = this._animationLayer;

        // 賓果板背景
        let bingoBgSprite = new ccui.Scale9Sprite("farm_bingo_bg_frame_bingo_1.png");
        bingoBgSprite.setPreferredSize(cc.size(395, 233));
        bingoBgSprite.setPosition(JSScreenMidPos.x + 42, JSScreenMidPos.y - 22);
        aniLayer.addChild(bingoBgSprite);

        // 抽球區背景
        let machineBgSprite = new ccui.Scale9Sprite("farm_bingo_pic_window_01.png", cc.rect(77, 77, 77, 10));
        machineBgSprite.setPreferredSize(cc.size(156, 194));
        machineBgSprite.setPosition(JSScreenMidPos.x + 151, JSScreenMidPos.y - 19);
        aniLayer.addChild(machineBgSprite);

        // 賓果抽球機背景 (右 左)
        for (let i = 0; i < 2; i++) {
            let machineBgSprite = new cc.Sprite("#farm_bingo_pic_machine_02.png");
            machineBgSprite.setAnchorPoint(i, 0.5);
            machineBgSprite.setFlippedX(!i);
            machineBgSprite.setPosition(JSScreenMidPos.x + 151 + 0.25 * (i - 0.5), JSScreenMidPos.y + 8);
            aniLayer.addChild(machineBgSprite);
        }

        let spineWrapperNode = new cc.Node();
        aniLayer.addChild(spineWrapperNode);

        // 賓果抽球動畫
        GSSpine.create("spine/FarmBingo/bingo ball/PIC_bingo-ball", 0.25, (spine) => {
            spine.setPosition(JSScreenMidPos.x + 151, JSScreenMidPos.y);
            spine.setAnimation(0, "ani_1", false);
            spineWrapperNode.addChild(spine);

            spine.setAnimationListener(this, (node, trackEntry, type) => {
                if (type === sp.ANIMATION_EVENT_TYPE.COMPLETE) {
                    // 隨機抽一個動畫（ani_2 ~ 4）
                    let random = Math.floor(Math.random() * 3 + 2);
                    node.setAnimation(0, "ani_" + random, false);
                }
            });
        });

        // 賓果球標題
        let bingoBallTitleSprite = new cc.Sprite("#farm_bingo_w_title_bingo_2.png");
        bingoBallTitleSprite.setPosition(JSScreenMidPos.x - 38, JSScreenMidPos.y + 97);
        aniLayer.addChild(bingoBallTitleSprite);

        // 倒數時間
        let remainTimeLabel = this._remainTimeLabel = new RemainTimeLabel(RemainTimeLabel.Style.BLACK);
        remainTimeLabel.setScale(0.83);
        remainTimeLabel.setPosition(JSScreenMidPos.x + 151, JSScreenMidPos.y + 83);
        aniLayer.addChild(remainTimeLabel);

        let tokenBar = this._tokenBar = new BasePassTokenBar({
            tokenBarBgFileName: "farm_bingo_bg_frame_coin.png",     // 背景圖案
            tokenIconFileName: "farm_bingo_pic_clover.png",         // 代幣圖示
            tokenBarIconScale: 1,                                    // 代幣縮放倍率
            tokenBarFontColor: JSColor.WHITE,                       // 代幣數量文字顏色
            tokenBarIsShowPlusBtn: true,                            // 是否顯示增加按鈕
            tokenBarPlusBtnOnClick: () => this._plusBtnClicked(),   // 點擊 callback
        });
        tokenBar.setPosition(JSScreenMidPos.x - 175, JSVisibleSize.height - 17);
        aniLayer.addChild(tokenBar);

        // 回合獎勵 node
        let roundRewardNode = this._roundRewardNode = new cc.Node();
        roundRewardNode.setPosition(JSScreenMidPos.x, JSVisibleSize.height - 18);
        aniLayer.addChild(roundRewardNode);

        // 回合獎勵背景
        let roundRewardBgSprite = new ccui.Scale9Sprite("farm_bingo_bg_bingo_top.png");
        roundRewardBgSprite.setPreferredSize(cc.size(230, 35));
        roundRewardNode.addChild(roundRewardBgSprite);

        // 進度條
        let progressBar = this._progressBar = new GSProgressTimer("farm_bingo_pic_bar_02-2.png", "farm_bingo_pic_bar_01-2.png", cc.size(165, 18), cc.size(157, 10), true);
        progressBar.setAnimationTime(0.5);
        progressBar.setPosition(4, 0);
        roundRewardNode.addChild(progressBar);

        // 進度條中央的數字：%d / %d
        let progressBarLabel = this._progressBarLabel = new cc.LabelTTF("", JSFontBoldName, 10);
        progressBarLabel.enableStroke(cc.color(59, 92, 31), 2);
        progressBarLabel.setPosition(progressBar.getPosition());
        roundRewardNode.addChild(progressBarLabel);

        // 上方寶箱
        let topChestSprite = new cc.Sprite("#farm_bingo_pic_shop.png");
        topChestSprite.setPosition(-84, 0);
        topChestSprite.setScale(0.5);
        roundRewardNode.addChild(topChestSprite);

        // 進度條右側大獎
        let goalButton = this._goalButton = ButtonUtility.createSimpleImageButton("farm_bingo_pic_bingo.png");
        goalButton.setPosition(88, 0);
        goalButton.setScale(0.3);
        goalButton.setChangeColorWhenDisabled(false);
        goalButton.globalPos = cc.pAdd(goalButton.getPosition(), roundRewardNode.getPosition());
        goalButton.addTouchUpInsideAction(() => {
            UserAnalyticsTrackUtils.sendTrack("農場賓果 >=8.4 點擊德擋幣ICON", DataModal.farmBingoData.group);
            this._showRoundRewardPopup(false);
        }, this);
        roundRewardNode.addChild(goalButton);

        // PASS 按鈕
        let passButton = this._passButton = new FarmPassIconNode();
        passButton.setPosition(JSScreenMidPos.x + 200, JSVisibleSize.height - 24);
        passButton.addTouchUpInsideAction(this._passButtonClicked, this);
        aniLayer.addChild(passButton);

        // 抽球按鈕位置
        let playBtnPosition = cc.p(JSScreenMidPos.x + 151, JSScreenMidPos.y - 90);

        // 抽球按鈕發光 spine wrapper node
        let playBtnGlowingWrapperNode = new cc.Node();
        playBtnGlowingWrapperNode.setPosition(playBtnPosition);
        aniLayer.addChild(playBtnGlowingWrapperNode);

        // 抽球按鈕
        let playButton = this._playButton = new Texas_Button(Texas_Button.Style.ORANGE, cc.size(128, 45), LocalizedString.FarmBingo("Play"), {
            fontSize: GS.isLuxyPoker ? 18 : 20,
        });
        playButton.addTargetWithActionForControlEvents(this, this._playButtonClicked, cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_UP_INSIDE | cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_CANCEL);
        playButton.setPosition(playBtnPosition);
        playButton.titlePos = cc.p(0, 8 + GS.isLuxyPoker);
        playButton.getTitleLabel().setPosition(playButton.titlePos);
        aniLayer.addChild(playButton);

        // 抽球按鈕下方的價格標籤
        let oneRunCostAutoLayout = playButton.priceLabel = new GSAutoLayoutNode();
        oneRunCostAutoLayout.setPosition(0, -10 + GS.isLuxyPoker * 3);
        oneRunCostAutoLayout.setSpace(2);
        playButton.addChildToContentNode(oneRunCostAutoLayout);

        // 換一顆賓果球代幣 icon
        let oneRunCostIconLabel = new cc.Sprite("#farm_bingo_pic_clover.png");
        oneRunCostIconLabel.setScale(0.8);
        oneRunCostAutoLayout.addChild(oneRunCostIconLabel);

        // 換一顆賓果球金額
        let oneRunCostLabel = this._oneRunCostLabel = new cc.LabelTTF("-", JSFontName, 10);
        oneRunCostLabel.setFontFillColor(Texas_Button.getOutlineColorByFileName(Texas_Button.ButtonImg.ORANGE));
        oneRunCostAutoLayout.addChild(oneRunCostLabel);

        // 抽球按鈕發光 spine
        GSSpine.create("spine/ramadan/bingo_play_button_light/skeleton", 0.25, (spine) => {
            playBtnGlowingWrapperNode.addChild(spine);
            playButton.glowingSpine = spine;
        });

        // 抽球按鈕小紅點
        let playButtonSize = playButton.getContentSize();
        let playButtonBadge = this._playButtonBadge = new BadgeNode();
        playButtonBadge.setCascadeOpacityEnabled(true);
        playButtonBadge.setPosition(playButtonSize.width / 2 - 8, playButtonSize.height / 2 - 2);
        playButtonBadge.setScale(1.3);
        playButton.addChildToContentNode(playButtonBadge);

        // 抽球按鈕小紅點上的數字
        let playButtonBadgeLabel = playButtonBadge.label = new cc.LabelTTF("", JSFontName, 7);
        playButtonBadgeLabel.setPosition(playButtonBadge.getPosition());
        playButton.addChildToContentNode(playButtonBadgeLabel);

        // 長按自動
        let holdLabel = new cc.LabelTTF(LocalizedString.FarmBingo("長按自動"), JSFontName, 10);
        holdLabel.setPosition(JSScreenMidPos.x + 151, JSScreenMidPos.y - 125);
        holdLabel.setFontFillColor(JSColor.BLACK);
        aniLayer.addChild(holdLabel);

        // 賓果盤本人
        let bingoNode = this._bingoNode = new cc.Node();
        bingoNode.setPosition(JSScreenMidPos.x - 38, JSScreenMidPos.y - 23);
        aniLayer.addChild(bingoNode);

        // 賓果盤背景
        for (let i = 0; i < 4; i++) {
            let bgSprite = new cc.Sprite("#farm_bingo_bg_frame_bingo_2.png");
            bgSprite.setPosition((i % 2) - 0.5, (i < 2) - 0.5);
            bgSprite.setAnchorPoint(i % 2, i < 2 ? 1 : 0);
            bgSprite.setFlippedX(i % 2 === 0);
            bgSprite.setFlippedY(i < 2);
            bgSprite.setScale(1.14);
            bingoNode.addChild(bgSprite);
        }

        // 儲存 25 個格子
        this._bingoGridNodeList = [];

        // 25 個格子
        for (let i = 0; i < 5; i++) {
            for (let j = 0; j < 5; j++) {
                let index = i * 5 + j;

                // 一般格子
                let bingoGridNode = this._bingoGridNodeList[index] = new FarmBingoGridNode(index);
                bingoGridNode.setPosition((j - 2) * 40, (2 - i) * 40);
                bingoNode.addChild(bingoGridNode);
            }
        }

        // 聽牌發光框 layer
        let glowingFrameLayer = this._glowingFrameLayer = new cc.Node();
        glowingFrameLayer.setPosition(bingoNode.getPosition());
        glowingFrameLayer.setCascadeOpacityEnabled(true);
        aniLayer.addChild(glowingFrameLayer);

        // 額外獎勵區背景
        let extraRewardBgSprite = new ccui.Scale9Sprite("farm_bingo_bg_frame_bingo_3.png");
        extraRewardBgSprite.setPreferredSize(cc.size(75, 205));
        extraRewardBgSprite.setPosition(JSScreenMidPos.x - 201, JSScreenMidPos.y - 31);
        aniLayer.addChild(extraRewardBgSprite);

        // 左側箱子按鈕
        let chestButton = this._chestButton = ButtonUtility.createSimpleImageButton("farm_bingo_pic_shop.png");
        chestButton.setPosition(JSScreenMidPos.x - 201, JSScreenMidPos.y + 78);
        chestButton.setChangeColorWhenDisabled(false);
        chestButton.addTouchUpInsideAction(() => {
            UserAnalyticsTrackUtils.sendTrack("農場賓果 >=8.4 點擊寶箱", DataModal.farmBingoData.group);
            this._showExtraRewardPopup();
        }, this);
        aniLayer.addChild(chestButton);

        // 額外獎勵 node
        this._extraRewardNodeList = [];
        for (let i = 0; i < 3; i++) {
            let extraRewardNode = this._extraRewardNodeList[i] = new FarmBingoExtraRewardNode();
            extraRewardNode.setPosition(JSScreenMidPos.x - 201, JSScreenMidPos.y + 26 - 57 * i);
            aniLayer.addChild(extraRewardNode);
            extraRewardNode.getButton().addTouchUpInsideAction(this._extraRewardClicked, this);
        }

        // 說明按鈕
        let infoBtn = new Texas_ExplainButton(Texas_ExplainButton.Style.WHITE);
        infoBtn.setScale(0.8);
        infoBtn.addTouchUpInsideAction(this._infoBtnClicked, this);
        infoBtn.setPosition(JSScreenMidPos.x - 240, JSVisibleSize.height - 17);
        aniLayer.addChild(infoBtn);

        // 關閉按鈕
        let closeBtn = new Texas_CloseButton(Texas_CloseButton.Style.WHITE);
        closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
        closeBtn.setPosition(JSScreenMidPos.x + 241, JSVisibleSize.height - 17);
        aniLayer.addChild(closeBtn, 12);

        // 監聽通知
        GS.addListener("NotifyFarmBingoInfoDone", this.notifyFarmBingoInfoDone.bind(this), this);
        GS.addListener("NotifyFarmBingoGetBallDone", this.notifyFarmGetBallDone.bind(this), this);
        GS.addListener("NotifyFarmBingoBuyExtraRewardDone", this.notifyFarmBingoBuyExtraRewardDone.bind(this), this);
        GS.addListener("NotifySocketResult", this.notifySocketResult.bind(this), this);

        // 要賓果的資料
        DataModal.farmBingoData.startGetInfo();

        DataProcess.sendCustomStringToSelf('farm_bingo_info {"round":{"done_card_num":"0","reward":"900000","goal":"1","stage":"2"},"play_group":"1","img_url":"https://d.mwsrv.com/19_60/store/iapp/goods/","error":"0","unlockRP_group":"1","bingo_card":["3","20","32","47","70","1","23","35","58","66","7","19","-1","56","63","11","25","37","57","72","14","27","33","59","73"],"recharge":{"img_url":"https://d.mwsrv.com/19_60/store/iapp/download/payment/ID/","product_list":{"productID":["texas9id_android_tmoney_1_303t_scratchoffrp"],"pic":["Google_01.png"],"top_msg":"Top-up Rp. 150,000 dapat 7.5mlr chips+RP*4,000(Google Play, Indosat,XL,3)\\nTop-up Rp. 100,000 dapat 5mlr chips+RP*4,000(Telkomsel)"}},"extra_reward_pos":["18","4","19"],"card_num":"2","total_ball":"37","left_time":"9487487","bingo_pos":["1","1","1","1","0","0","0","0","0","0","0","0","1","0","0","0","0","0","0","0","0","0","0","0","0"],"one_run":"5","token":"115","extra_reward":{"reward_list":[{"get_left_time":"10"},{"get_left_time":"0"}],"need_RP":"200"},"pass_icon":{"pop":"0","can_reward":"1","goal":["2","5","10","20","30","40","50","60","75","90","105","120","135","150","165","180","195","210","230","250"]},"ball_reward_pot":[{"wid_pic":"5009","count":"0"},{"wid_pic":"7097","count":"0"}],"add":{"is_vip":"0","play_btn":[{"type":"3","url":"38","lobby_type":"9901","track_type":"92"},{"type":"3","url":"95","lobby_type":"9911","track_type":"1374"}],"slot_btn":[{"track_type":"89","lobby_type":"133","url":"133","type":"147"},{"track_type":"90","lobby_type":"134","url":"134","type":"147"},{"track_type":"91","lobby_type":"42","url":"0","type":"192"}]}}');
    },

    _createEventInfoDialog: function () {
        return new WebViewDialog(TexasUtility.getSimpleInfoURLByKey(
            "farm_bingo_info",
            JSStringUtility.format("group=%s", DataModal.farmBingoData.group))
        );
    },

    /**
     * 創活動結束dialog. BaseEventDialog 會呼叫。
     */
    _createEventEndDialog: function () {
        return new FarmBingoCommonDialog({
            type: FarmBingoCommonDialog.DialogType.COMMON,
            content: LocalizedString.FarmBingo("活動已結束！"),
            callback: () => {
                // 關掉dialog
                this.closeDialogAnimation();
            }
        });
    },

    /**
     * Override掉 假如有WebView一起關掉
     */
    setVisible: function (isVisible) {
        this._super(isVisible);

        // 有 pass 也要隱藏
        if (this._passDialog) {
            this._passDialog.setVisible(isVisible);
        }
    },

    /**
     * 刷新畫面
     */
    _refreshView: function () {
        if (this.__isDestroyed) {
            return;
        }

        // 拿掉loading
        this.setLoadingSprite(false, false);

        this._isInAnimation = false;
        this._isExtraRewardBuyAbort = false;

        // 如果說明頁有開幫他關掉說明頁
        if (this._infoDialog) {
            this._infoDialog.closeDialogAnimation();
        }

        // 無資料 exception
        let data = DataModal.farmBingoData;
        let bingoData = data.bingoParam;
        if (!bingoData || bingoData.errorCode !== 0) {
            this.showEventEndDialog();
            return;
        }

        // 詢問是否購買獎勵罐
        // 被強制關閉 dialog 前有跳則回來時也要詢問
        if (data.buyExtraRewardData && data.buyExtraRewardData.isShowDialog) {
            this._showPotLimitDialog(data.buyExtraRewardData.cost);
        }

        // 開始倒數
        let remainTime = JSCodeUtility.getRemainTime(bingoData.remainTime, bingoData.socketTime);
        this._remainTimeLabel.countdownSeconds(remainTime, () => {
            // 倒數結束
            let semaphore = SemaphoreManager.get("FarmBingoDialogEventEndSemaphore");
            semaphore.acquire().then((key) => {
                if (this._passDialog) {
                    this._passDialog.closeDialogAnimation();
                }
                this.showEventEndDialog();
                semaphore.release(key);
            });
            this._stopAutoRunning();
        });

        this._refreshTokenView();
        this._refreshPlayButtonView();
        this._refreshProgressBar();
        this._refreshExtraRewardView();
        this._passButton.refreshView();

        if (!this._isFirstIn) {
            // 首次進入
            this._isFirstIn = true;

            switch (this._enteringTimes) {
                case 1:
                    // 首次進入
                    // 跳上方大獎泡泡框
                    this._showRoundRewardPopup(true);
                    break;

                case 2:
                    // 第二次進入
                    // 跳 pass
                    if (data?.passIconParam?.isPop) {
                        this._passButtonClicked();
                        data.passIconParam.isPop = false;
                    }
                    break;
            }
        }

        // 聽牌相關
        this._gridGlowingSpineList.forEach((spine) => spine?.setVisible(false));
        this._bingoReadyHandInfoArr = Array(12).fill(0);    // 賓果連線情況
        this._updateReadyHandInfo(12);

        // 更新格子
        for (let i = 0; i < 25; i++) {
            let gridNode = this._bingoGridNodeList[i];
            gridNode.setVisible(true);
            gridNode.setIsWon(false);

            if (i === 12) {
                // 中間贈送的格子
                continue;
            }

            let cardNum = bingoData.cardData.numArray[i];
            let isWon = bingoData.cardData.wonArray[i];

            gridNode.setNumber(cardNum);
            gridNode.setIsWon(isWon);

            if (isWon) {
                this._updateReadyHandInfo(i);
            }

            // 這個位置有獎勵罐
            gridNode.setPotSpriteVisible(bingoData.extraRewardPosition.indexOf(i) !== -1);
        }
    },

    // 更新代幣數量
    _refreshTokenView: function () {
        this._tokenBar.setQuantity(DataModal.farmBingoData.bingoParam.token);
    },

    // 顯示箱子泡泡框
    _showExtraRewardPopup: function () {
        this._chestButton.setEnabled(false);

        // Data
        const rewardList = DataModal.farmBingoData.bingoParam.ballRewardPot;
        const isAccumulated = rewardList.some((item) => item.count > 0);

        // 大獎內容
        let contentNode;
        if (isAccumulated) {
            contentNode = new cc.Node();
            contentNode.setContentSize(cc.size(60, 35));
            rewardList.forEach((element, i) => {
                // UI 空間只允許兩個獎勵，超過的不顯示
                if (i > 1) {
                    return;
                }

                // 獎勵圖示
                const imageUrl = TexasUtility.getItemImageUrl(element.picFileName);
                const savePath = JSWriteablePath + "shop/" + element.picFileName + ".png";
                const rewardSprite = new GSDownloadSprite("", imageUrl, savePath);
                rewardSprite.setTargetSize(cc.size(20, 20));
                rewardSprite.setPosition(-19, 9 - i * 20);
                contentNode.addChild(rewardSprite);

                // 獎勵數量
                const countLabel = new cc.LabelTTF((element.picFileName === "5009" ? "" : "x ") + element.count, JSFontName, 9);
                countLabel.setColor(JSColor.BLACK);
                countLabel.setAnchorPoint(0, 0.5);
                countLabel.setPosition(-6, 9 - i * 20);
                contentNode.addChild(countLabel);
            });
        } else {
            contentNode = new cc.LabelTTF(LocalizedString.FarmBingo("累積賓果球解鎖"), JSFontName, 9);
            contentNode.setColor(JSColor.BLACK);
        }

        // 大獎泡泡框
        let msgNode = new BaseMessageNode({
            mainNode: contentNode,
            style: BaseMessageNode.Style.WHITE_SHADOW,
            direct: BaseMessageNode.Direct.LEFT,
            arrowType: BaseMessageNode.ArrowType.STRAIGHT,
            isFlip: false,
            closeCallback: () => {
                this._chestButton.setEnabled(true);
            },
        });
        msgNode.setPosition(cc.pAdd(this._chestButton.getPosition(), cc.p(24, 6)));
        this._animationLayer.addChild(msgNode);

        // 3s
        msgNode.show(3);
    },

    // 顯示回合獎勵泡泡框
    _showRoundRewardPopup: function (isFirstTime) {
        this._goalButton.setEnabled(false);

        // Data
        const roundData = DataModal.farmBingoData.bingoParam.round;

        const contentNode = new cc.LabelTTF(JSCodeUtility.getCurrencyString(roundData.reward) + " chips", JSFontName, 12);
        contentNode.setFontFillColor(JSColor.BLACK);

        // 大獎泡泡框
        const bigRewardMsgNode = new BaseMessageNode({
            mainNode: contentNode,
            style: BaseMessageNode.Style.WHITE_SHADOW,
            direct: BaseMessageNode.Direct.UP,
            arrowType: BaseMessageNode.ArrowType.STRAIGHT,
            isFlip: false,
            closeCallback: () => {
                this._goalButton.setEnabled(true);
            }
        });
        bigRewardMsgNode.setPosition(cc.pAdd(this._goalButton.globalPos, cc.p(0, -6)));

        if (isFirstTime) {
            // 當日首次進入
            bigRewardMsgNode.show(3);
        } else {
            // 手動點擊
            bigRewardMsgNode.show();

            // DummyTouch
            const dummyTouch = new DummyTouchLayer(JSVisibleSize, JSDebugMode);
            dummyTouch.setPosition(0, 0);
            dummyTouch.setOnTouchCallback(() => {
                // 關閉泡泡框
                bigRewardMsgNode.close();
                dummyTouch.removeFromParent();
            });
            this._animationLayer.addChild(dummyTouch);
        }

        this._animationLayer.addChild(bigRewardMsgNode);
    },

    // 更新抽球按鈕與下方單次購買金額畫面
    _refreshPlayButtonView: function () {
        let bingoData = DataModal.farmBingoData.bingoParam;

        // 更新抽球按鈕小紅點
        let playRound = Math.floor(Math.max(0, bingoData.oneRunCost <= 0 ? 100 : bingoData.token / bingoData.oneRunCost));

        if (playRound > 0) {
            this._playButtonBadge.setVisible(true);
            this._playButtonBadge.label.setVisible(true);
            this._playButtonBadge.label.setString(playRound > 99 ? "99+" : playRound);
        } else {
            this._playButtonBadge.label.setVisible(false);
            this._playButtonBadge.setVisible(false);
        }

        // 更新抽球按鈕下方單次購買金額
        this._oneRunCostLabel.setString(JSCodeUtility.getCurrencyString(bingoData.oneRunCost));
    },

    // 更新獎勵罐
    _refreshExtraRewardView: function () {
        let bingoData = DataModal.farmBingoData.bingoParam;

        let extraRewardDataList = bingoData.extraRewardList;
        for (let i = 0; i < 3; i++) {
            this._extraRewardNodeList[i].refreshView(extraRewardDataList[i], i);
        }
    },

    // 更新進度條 GSProgressTimer 畫面
    _refreshProgressBar: function () {
        let bingoData = DataModal.farmBingoData.bingoParam;
        let achievedNum = bingoData.round.doneCardNum;
        let goalNum = bingoData.round.goal;
        let percent = Math.max(0, Math.min(achievedNum * 100 / goalNum, 100));
        this._progressBar.setPercentage(percent);
        this._progressBarLabel.setString(JSStringUtility.format("%s / %s", achievedNum, goalNum));
    },

    /**
     *  聽牌相關
     */

    // 更新聽牌之連線情況
    _updateReadyHandInfo: function (gridIndex = -1) {
        if (0 <= gridIndex && gridIndex <= 24) {
            let rowIndex = Math.floor(gridIndex / 5);
            let columnIndex = Math.floor(gridIndex % 5);
            let diagonalLT = gridIndex % 6 === 0;
            let diagonalRT = gridIndex !== 0 && gridIndex !== 24 && gridIndex % 4 === 0;
            let infoArr = this._bingoReadyHandInfoArr;

            let bingoData = DataModal.farmBingoData.bingoParam;

            let i;

            // 0..4 橫向連線情況
            infoArr[rowIndex]++;
            if (infoArr[rowIndex] >= 4) {
                // 已經有四格中獎，剩下的那格聽牌
                for (i = 0; i < 5; i++) {
                    let isWon = bingoData.cardData.wonArray[rowIndex * 5 + i];
                    if (!isWon) {
                        // 這格聽牌
                        this._updateReadyHandGridNode(rowIndex * 5 + i);
                    }
                }
            }

            // 5..9 縱向連線情況
            infoArr[5 + columnIndex]++;
            if (infoArr[5 + columnIndex] >= 4) {
                // 已經有四格中獎，剩下的那格聽牌
                for (i = 0; i < 5; i++) {
                    let isWon = bingoData.cardData.wonArray[columnIndex + i * 5];
                    if (!isWon) {
                        // 這格聽牌
                        this._updateReadyHandGridNode(columnIndex + i * 5);
                    }
                }
            }

            // 左上至右下連線情況
            infoArr[10] += diagonalLT;
            if (infoArr[10] >= 4) {
                // 已經有四格中獎，剩下的那格聽牌
                for (i = 0; i < 5; i++) {
                    let isWon = bingoData.cardData.wonArray[6 * i];
                    if (!isWon) {
                        // 這格聽牌
                        this._updateReadyHandGridNode(6 * i);
                    }
                }
            }

            // 右上至左下連線情況
            infoArr[11] += diagonalRT;
            if (infoArr[11] >= 4) {
                // 已經有四格中獎，剩下的那格聽牌
                for (i = 1; i < 6; i++) {
                    let isWon = bingoData.cardData.wonArray[4 * i];
                    if (!isWon) {
                        // 這格聽牌
                        this._updateReadyHandGridNode(4 * i);
                    }
                }
            }
        }
    },

    // 更新聽牌時發光的格子
    _updateReadyHandGridNode: function (gridIndex) {
        if (gridIndex === 12) {
            // 中間格
            return;
        }

        if (this._gridGlowingSpineList[gridIndex]) {
            // 已有 spine
            this._gridGlowingSpineList[gridIndex].setVisible(true);
        } else {
            GSSpine.create("spine/ramadan/bingo_frame-light/PIC_frame-light", 0.25, (spine) => {
                spine.setPosition(this._bingoGridNodeList[gridIndex].getPosition());
                spine.setAnimation(0, "animation", true);
                spine.setScale(1.14);
                this._glowingFrameLayer.addChild(spine);

                this._gridGlowingSpineList[gridIndex] = spine;
            });
        }
    },

    /**
     *  按鈕相關
     */

    // 點擊新增代幣按鈕
    _plusBtnClicked: function () {
        // 埋點：點擊新增代幣 4388
        DataModal.farmBingoData.sendTrackingData(4388);

        let bingoData = DataModal.farmBingoData.bingoParam;

        // 已達代幣上限
        if (bingoData.token >= 999999999) {
            // 埋點：跳出達上限 dialog 4486
            DataModal.farmBingoData.sendTrackingData(4486);

            this.showDialog(new FarmBingoCommonDialog({
                type: FarmBingoCommonDialog.DialogType.COMMON,
                content: LocalizedString.FarmBingo("您已達累積上限\n請先遊玩賓果才可繼續累積呦"),
                trackType: 4487
            }));
        } else {
            this._showGetTokenDialog();
        }
    },

    // 點擊 or 長按 play button
    _playButtonClicked: function (sender, event) {
        if (!sender) {
            return;
        }

        switch (event) {
            case cc.CONTROL_EVENT_TOUCH_DOWN:
                this._playButtonTouchDownTime = Date.now();

                if (!this._isAutoRunning) {
                    let action = cc.spawn(
                        cc.sequence(
                            cc.delayTime(1),
                            cc.callFunc(() => {
                                // 延遲一秒後，開始自動換賓果球
                                this._startAutoRunning();
                            })
                        ),
                        cc.sequence(
                            cc.delayTime(0.5),
                            cc.callFunc(() => {
                                this._playButton.glowingSpine.setAnimation(0, "ani_ButtonLight", false);
                            })
                        )
                    );
                    action.setTag(0);
                    sender.runAction(action);
                }
                break;
            case cc.CONTROL_EVENT_TOUCH_UP_INSIDE:
            case cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE:
            case cc.CONTROL_EVENT_TOUCH_CANCEL:
                let pressedTime = Date.now() - this._playButtonTouchDownTime;
                this._playButtonTouchDownTime = undefined;

                if (pressedTime < 1000) {
                    // 若點擊時間比一秒短：視為單擊
                    // 停掉延遲
                    sender.stopActionByTag(0);

                    if (this._isAutoRunning) {
                        // 此時為自動領獎，單擊視為停止自動領獎
                        this._stopAutoRunning();
                    } else {
                        // 此時為非自動領獎，單擊視為單次領獎

                        UserAnalyticsTrackUtils.sendTrack("農場賓果 >=8.4 抽一次", DataModal.farmBingoData.group);

                        this._getBingoBall();

                        // Disable button for 1 second.
                        sender.setEnabled(false);
                        sender.runAction(cc.sequence(
                            cc.delayTime(1),
                            cc.callFunc(() => {
                                sender.setEnabled(true);
                            })
                        ));
                    }
                }
                break;
        }
    },

    // 開始自動抽球
    _startAutoRunning: function () {
        let token = DataModal.farmBingoData.bingoParam.token;
        let oneRunCost = DataModal.farmBingoData.bingoParam.oneRunCost;

        this._getBingoBall();

        if (!this._isAutoRunning && token >= oneRunCost) {
            UserAnalyticsTrackUtils.sendTrack("農場賓果 >=8.4 進入長按模式", DataModal.farmBingoData.group);

            this._isAutoRunning = true;
            let label = this._playButton.getTitleLabel();
            label.setString("STOP");
            label.setPosition(0, GS.isLuxyPoker ? 2 : 0);
            this._playButton.priceLabel.setVisible(false);
        }
    },

    // 停止自動抽球
    _stopAutoRunning: function () {
        if (this._isAutoRunning) {
            // 此時為自動領獎，單擊視為停止自動領獎
            this._isAutoRunning = false;
            let label = this._playButton.getTitleLabel();
            label.setString(LocalizedString.FarmBingo("Play"));
            label.setPosition(this._playButton.titlePos);
            this._playButton.priceLabel.setVisible(true);
        }
    },

    // 換賓果球
    _getBingoBall: function () {
        let data = DataModal.farmBingoData;
        let bingoParam = data.bingoParam;
        let token = bingoParam.token;
        let oneRunCost = bingoParam.oneRunCost;

        if (token < oneRunCost) {
            if (this._isAutoRunning) {
                // 代幣不足，停止自動抽
                this._stopAutoRunning();
            }

            this._showGetTokenDialog();
        } else {
            // 送請求給 server
            DataModal.farmBingoData.startGetBingoBall();
        }
    },

    // 獎勵罐領獎
    _extraRewardClicked: function (sender) {
        if (sender) {
            // De-bounce
            sender.setEnabled(false);
            sender.runAction(cc.sequence(
                cc.delayTime(1),
                cc.callFunc(() => sender.setEnabled(true))
            ));

            UserAnalyticsTrackUtils.sendTrack(sender.cost ? "農場賓果 >=8.4 點擊RP購買" : "農場賓果 >=8.4 點擊領取", DataModal.farmBingoData.group);
        }

        // 尋找可領獎的獎勵
        let bingoData = DataModal.farmBingoData.bingoParam;
        let extraRewardDataList = bingoData.extraRewardList;
        let index = extraRewardDataList.findIndex((element) => {
            return JSCodeUtility.getRemainTime(element.remainTime, element.socketTime) <= 0;
        });

        if (sender.cost && index === -1) {
            // 購買獎勵
            let koinNum = DataModal.koinLuxyData.myKoin;
            if (koinNum >= sender.cost) {
                // RP 足夠可購買
                this.showDialog(new FarmBingoCommonDialog({
                    type: FarmBingoCommonDialog.DialogType.RP_BUY_POT,
                    cost: sender.cost,
                    isCloseButtonShow: true,
                    callback: (isAccepted) => {
                        if (isAccepted) {
                            this.setLoadingSprite(true, true);
                            DataProcess.sendString("farm_bingo_buy_extra_reward");
                        } else {
                            // Stop de-bounce and enable button
                            sender.stopAllActions();
                            sender.setEnabled(true);
                        }
                    }
                }));
            } else {
                UserAnalyticsTrackUtils.sendTrack("農場賓果 >=8.4 跳RP不足Dialog", DataModal.farmBingoData.group);

                // 顯示 RP 不足 dialog
                this.showDialog(new FarmBingoCommonDialog({
                    type: FarmBingoCommonDialog.DialogType.RP_NOT_ENOUGH
                }));

                // Stop de-bounce and enable button
                sender.stopAllActions();
                sender.setEnabled(true);
            }
        } else {
            this._isExtraRewardBuyAbort = sender.cost && index !== -1;
            this.setLoadingSprite(true, true);
            DataProcess.sendString("farm_bingo_buy_extra_reward");
        }
    },

    _passButtonClicked: function (sender) {
        // 埋點4387: 點擊農場pass icon
        sender && DataModal.farmBingoData.sendTrackingData(4387);

        let dialog = this._passDialog = new FarmPassDialog();
        dialog.setCloseCallback(() => {
            // 清除
            this._passDialog = undefined;
            this._passButton.refreshGoalArray();
            this._passButton.refreshView();
        });
        this.showDialog(dialog, true);

        // 紀錄點過 pass button
        GS.localStorage.setItem(UserDefaultKey.FarmPassIconRedPoint + DataModal.profileData.account, TexasUtility.getNowTimeMillisecondString());

        // 進入 pass 頁停止自動抽球
        this._stopAutoRunning();
    },

    /**
     *  領球相關
     */

    // 領到賓果球後 recursively 跑完所有 task
    _processQueue: function () {
        return new Promise((resolve, reject) => {
            // Dialog 已經被刪除，停止做事
            if (this.__isDestroyed) {
                return reject();
            }

            let data = DataModal.farmBingoData;
            let bingoData = data.bingoParam;
            let param = data.newBallParam;
            if (param.taskQueue.length === 0) {
                //  task queue 空了
                this._isQueueRunning = false;

                // 如果賓果頁被隱藏則停止抽球
                if (!this.isVisible()) {
                    this._stopAutoRunning();
                }

                // 如果正在自動抽球，繼續抽球
                if (this._isAutoRunning) {
                    this._getBingoBall();
                }

                return reject();
            }

            this._isQueueRunning = true;

            // 取得 task
            let taskParam = param.taskQueue.shift();
            switch (taskParam.type) {
                case FarmBingoData.FarmBingoTaskType.GET_BALL:
                    // 抽球成功，更新代幣
                    bingoData.token = taskParam.token;
                    bingoData.oneRunCost = taskParam.oneRunCost;
                    data.currentBingoBall = taskParam.currentBingoBall;
                    this._refreshTokenView();
                    this._refreshPlayButtonView();

                    // 更新 pass 按鈕小紅點
                    this._passButton.refreshRedPoint();

                    this._isInAnimation = true;
                    this._playGetBallAnimation(taskParam)
                        .then(() => {
                            // 更新資料
                            bingoData.extraRewardList = Array.from(taskParam.extraReward.rewardList);
                            bingoData.ballRewardPot = Array.from(taskParam.ballRewardPot);
                            bingoData.cardData = taskParam.cardData;

                            this._isInAnimation = false;

                            // 更新畫面
                            this._refreshView();
                            resolve();
                        });
                    break;

                case FarmBingoData.FarmBingoTaskType.LINE_UP:
                    // 連線 task：停止自動抽
                    this._stopAutoRunning();

                    this._isInAnimation = true;
                    this.setLoadingSprite(false, true);
                    this._playLineUpAnimation(taskParam)
                        .then(() => {
                            this._isInAnimation = false;
                            this._refreshView();
                            resolve();
                        });
                    break;
            }
        })
            .then(() => this._processQueue());
    },

    // 領到賓果球之動畫
    _playGetBallAnimation: function (taskParam) {
        return new Promise((resolve, reject) => {
            const animeLayer = this._animationLayer;
            const bingoData = DataModal.farmBingoData.bingoParam;

            // 球的數字與在卡上的位置
            const ballNum = taskParam.num;
            const ballPos = taskParam.pos ?? bingoData.cardData.numArray.indexOf(ballNum);
            const isInRange = -1 < ballPos && ballPos < 25;

            // 賓果球
            const ballNode = new FarmBingoBallNode(ballNum);
            ballNode.setPosition(JSScreenMidPos.x + 152, JSScreenMidPos.y + 30);
            ballNode.setOpacity(0);
            ballNode.setRotation(-180);
            ballNode.setScale(0.1);
            animeLayer.addChild(ballNode);

            ballNode.runAction(cc.sequence(
                cc.spawn(
                    cc.fadeIn(0.2),
                    cc.scaleTo(0.3, 1.4),
                    cc.rotateTo(0.2, 0),
                    cc.sequence(
                        cc.moveTo(0.2, ballNode.getPositionX(), JSScreenMidPos.y + 42),
                        cc.moveTo(0.2, ballNode.getPositionX(), JSScreenMidPos.y - 25),
                        cc.moveTo(0.1, ballNode.getPositionX(), JSScreenMidPos.y - 20),
                        cc.moveTo(0.1, ballNode.getPositionX(), JSScreenMidPos.y - 25)
                    )
                ),
                cc.delayTime(0.5),
                cc.callFunc(() => {
                    // 位置在範圍內
                    isInRange && this._playFlyToGridAnimation(taskParam).then(() => resolve());
                }),
                cc.spawn(
                    cc.moveTo(0.5, this._passButton.getPosition()),
                    cc.scaleTo(0.5, 0.3)
                ),
                cc.fadeOut(0.2),
                cc.callFunc(() => !isInRange && resolve()),
                cc.removeSelf()
            ));
        });
    },

    // 播放球飛到格子的動畫
    _playFlyToGridAnimation: function (taskParam) {
        return new Promise((resolve, reject) => {
            const data = DataModal.farmBingoData;
            const bingoData = data.bingoParam;

            // 球的數字與在卡上的位置
            const ballNum = taskParam.num;
            const ballPos = taskParam.pos ?? bingoData.cardData.numArray.indexOf(ballNum);

            // 計算球飛行最高點
            const currentPos = cc.p(JSScreenMidPos.x + 152, JSScreenMidPos.y - 25);
            const gridNode = this._bingoGridNodeList[ballPos];
            const bingoGridPos = cc.pAdd(this._bingoNode.getPosition(), gridNode.getPosition());
            const maxPosition = cc.p(
                currentPos.x - (currentPos.x - bingoGridPos.x) / 3,
                Math.max(currentPos.y, bingoGridPos.y) + 50
            );

            // 賓果球
            const ballNode = new FarmBingoBallNode(ballNum);
            ballNode.setPosition(currentPos);
            ballNode.setScale(1.4);
            this._animationLayer.addChild(ballNode);

            // 飛到格子內
            ballNode.runAction(cc.sequence(
                cc.spawn(
                    cc.scaleTo(0.5, 0.3),
                    cc.sequence(
                        cc.spawn(
                            cc.moveBy(0.2, 0, maxPosition.y - currentPos.y).easing(cc.easeOut(2)),
                            cc.moveBy(0.2, maxPosition.x - currentPos.x, 0)
                        ),
                        cc.spawn(
                            cc.moveBy(0.3, 0, bingoGridPos.y - maxPosition.y).easing(cc.easeIn(2)),
                            cc.moveBy(0.3, bingoGridPos.x - maxPosition.x, 0)
                        )
                    )
                ),
                cc.fadeOut(0.2),
                cc.callFunc(() => {
                    // 如果有新的獎勵罐且是必須馬上購買的
                    if (taskParam.extraReward.buyExtraRewardNow) {
                        // 停止自動抽球
                        this._stopAutoRunning();

                        // 詢問是否購買獎勵罐
                        this._showPotLimitDialog(taskParam.extraReward.cost);
                    }

                    if (bingoData.cardData.wonArray[ballPos]) {
                        // 之前獲得過，結束
                        resolve();
                    } else {
                        // 之前沒獲得過，更新格子狀態
                        bingoData.cardData.wonArray[ballPos] = true;

                        gridNode.playWonAnimeAsync()
                            .then(() => {
                                // 計算聽牌狀況
                                this._updateReadyHandInfo(ballPos);

                                resolve();
                            });
                    }
                })
            ));
        });
    },

    // 連線動畫
    _playLineUpAnimation: function (taskParam) {
        return new Promise((resolve, reject) => {
            // 賓果連線時以賓果盤為中心做縮放時用的 node
            let animeBingoNode = new cc.Node();
            animeBingoNode.setPosition(this._bingoNode.getPosition());
            animeBingoNode.spineList = [];
            this._animationLayer.addChild(animeBingoNode);

            taskParam.linesList.forEach((element, i) => {
                if (element === false) {
                    return;
                }

                for (let j = 0; j < 5; j++) {
                    let index;
                    // taskParam.linesList 0..4 橫向連線
                    if (0 <= i && i <= 4) {
                        index = i * 5 + j;
                    }
                    // taskParam.linesList 5..9 縱向連線
                    if (5 <= i && i <= 9) {
                        index = i - 5 + j * 5;
                    }
                    // taskParam.linesList 10 左上->右下連線
                    if (i === 10) {
                        index = 6 * j;
                    }
                    // taskParam.linesList 11 右上->左下連線
                    if (i === 11) {
                        index = 4 * (j + 1);
                    }
                    this._bingoGridNodeList[index].setVisible(false);
                    let glowingGridNode = new FarmBingoGlowingGridNode(index);
                    glowingGridNode.setPosition(this._bingoGridNodeList[index].getPosition());
                    animeBingoNode.spineList.push(glowingGridNode);
                    animeBingoNode.addChild(glowingGridNode);
                }
            });

            animeBingoNode.runAction(cc.sequence(
                cc.sequence(
                    cc.scaleTo(0.3, 1.1),
                    cc.scaleTo(0.3, 1)
                ).repeat(2),
                cc.callFunc(() => {
                    animeBingoNode.spineList.forEach((element) => {
                        element.getSpine().runAction(cc.fadeOut(0.1));
                    });

                    // 跳連線獎勵 dialog
                    let lineUpDialog = new FarmBingoLineUpRewardDialog({
                        // Bingo 動畫結束，箱子飛出前隱藏箱子按鈕
                        onBingoAnimeEnd: () => this._chestButton.setOpacity(0),
                    });
                    lineUpDialog.setCloseCallback(() => {
                        this._chestButton.runAction(cc.fadeIn(0.2));

                        let bingoData = DataModal.farmBingoData.bingoParam;

                        // 更新卡面資料
                        bingoData.cardData = taskParam.nextCard.cardData;
                        bingoData.extraRewardPosition = Array.from(taskParam.nextCard.extraRewardPosition);
                        bingoData.ballRewardPot = Array.from(taskParam.nextCard.ballRewardPot);

                        // 移除縮放動畫
                        animeBingoNode.removeFromParent();

                        // 顯示格子
                        this._bingoGridNodeList.forEach((element) => {
                            element.setVisible(true);
                        });

                        if (++bingoData.round.doneCardNum >= bingoData.round.goal) {
                            // 階段達成，跑階段動畫
                            this._playRoundAnimation().then(() => {
                                // 更新回合獎勵
                                this._updateRoundData(taskParam);
                                resolve();
                            });
                        } else {
                            // 更新回合獎勵
                            this._updateRoundData(taskParam);
                            resolve();
                        }
                    });
                    this.showDialog(lineUpDialog);
                })
            ));
        });
    },

    // 更新回合獎勵資料
    _updateRoundData: function (taskParam) {
        let bingoData = DataModal.farmBingoData.bingoParam;

        bingoData.round.goal = taskParam.nextCard.round.goal;
        bingoData.round.reward = taskParam.nextCard.round.reward;
        bingoData.round.stage = taskParam.nextCard.round.stage;
        bingoData.round.doneCardNum = taskParam.nextCard.round.doneCardNum;
    },

    // 回合獎勵達成動畫
    _playRoundAnimation: function () {
        let animeLayer = this._animationLayer;

        return new Promise((resolve, reject) => {
            // 設定動畫完成後的 callback
            this._progressBar.setFinishProgressCallback(() => {
                // 進度條右側賓果球動畫
                GSSpine.create("spine/FarmBingo/PIC_-bingo-light/PIC_-bingo-light", 0.25, (spine) => {
                    spine.setPosition(cc.pAdd(this._goalButton.getPosition(), this._roundRewardNode.getPosition()));
                    spine.setAnimation(0, "ani_1", false);
                    animeLayer.addChild(spine);

                    spine.runAction(cc.sequence(
                        cc.delayTime(0.5),
                        cc.spawn(
                            cc.fadeOut(0.5),
                            cc.callFunc(() => {
                                let roundRewardDialog = new FarmBingoRoundRewardDialog();
                                roundRewardDialog.setCloseCallback(() => {
                                    // 清除 callback
                                    this._progressBar.setFinishProgressCallback(undefined);
                                    resolve();
                                });
                                this.showDialog(roundRewardDialog);
                            })
                        )
                    ));
                });
            });

            this._refreshProgressBar();
        });
    },

    _showGetTokenDialog: function () {
        const data = DataModal.farmBingoData;

        UserAnalyticsTrackUtils.sendTrack("農場賓果 >=8.4 跳出獲得代幣畫面", data.group);

        // 跳獲得代幣的 dialog
        this.showDialog(new FarmBingoGetTokenDialog());
    },

    /**
     * 跳詢問是否購買獎勵罐 dialog
     *
     * 被強制關閉 dialog 後也要跳詢問，所以需要在這裡存一下購買獎勵罐的資料
     * 在 _refreshView 時再判斷是否要顯示 dialog
     *
     * 限制只跳一次，因為抽球結束後會跑一次 _refreshView，造成重複詢問
     * 如果是自動抽會停止，不會有多個獎勵罐同時需要詢問的問題
     *
     * @param cost {number} 購買獎勵罐的金額
     * @private
     */
    _showPotLimitDialog: function (cost) {
        if (this._buyExtraRewardNowDialog) {
            // 已經有詢問了
            return;
        }

        let data = DataModal.farmBingoData;
        data.buyExtraRewardData = {
            isShowDialog: true,
            cost: cost,
        };
        this._buyExtraRewardNowDialog = new FarmBingoCommonDialog({
            type: FarmBingoCommonDialog.DialogType.POT_LIMIT,
            cost: cost,
            isCloseButtonShow: true,
            callback: (isAccepted) => {
                data.buyExtraRewardData = this._buyExtraRewardNowDialog = undefined;
                if (isAccepted) {
                    // 接受購買
                    this._isBuyExtraRewardNow = true;
                    this.setLoadingSprite(true, true);
                    DataProcess.sendString("farm_bingo_buy_extra_reward 1");
                }
            }
        });
        this.showDialog(this._buyExtraRewardNowDialog);
    },

    /**
     *  Notifications
     */
    notifyFarmBingoInfoDone: function () {
        this._refreshView();
    },

    notifyFarmGetBallDone: function () {
        let param = DataModal.farmBingoData.newBallParam;
        if (!param) {
            return;
        }

        switch (param.errorCode) {
            case 0:
                if (!this._isQueueRunning) {
                    this._processQueue().then(() => {
                    }).catch(() => {
                    });
                }
                break;
            default:
                // 出錯了，停止自動抽球
                this._stopAutoRunning();
        }
    },

    notifyFarmBingoBuyExtraRewardDone: function (event) {
        this.setLoadingSprite(false, false);
        if (!event && !event.getUserData()) {
            return;
        }

        let data = DataModal.farmBingoData;
        let param = event.getUserData();

        switch (param.errorCode) {
            case 0:     // 正常
                this.showDialog(new FarmBingoCommonDialog({
                    type: this._isExtraRewardBuyAbort ? FarmBingoCommonDialog.DialogType.OPEN_AVAILABLE : FarmBingoCommonDialog.DialogType.REWARD,
                    rewardArray: param.rewardMsg,
                    callback: () => {
                        this.setLoadingSprite(true, true);
                        data.startGetInfo();
                    }
                }));
                break;
            case 1:     // 活動未開
                this.showEventEndDialog();
                break;
            case 4:     // 扣 RP 失敗
                this.showDialog(new FarmBingoCommonDialog({
                    type: FarmBingoCommonDialog.DialogType.RP_NOT_ENOUGH
                }));
                break;
        }
    },

    /**
     * Socket連線通知
     */
    notifySocketResult: function (e) {
        var result = e.getUserData();
        switch (result) {
            case "ReconnectDone":
                // 斷線重連成功了
                // 停止自動抽球
                this._stopAutoRunning();
                break;
        }
    },

    createDebugTestObject: function () {
        return new TestMenuDebugObject("農場賓果", {
            "info": () => DataProcess.sendCustomStringToSelf('farm_bingo_info {"round":{"done_card_num":"0","reward":"900000","goal":"1","stage":"2"},"play_group":"1","img_url":"https://d.mwsrv.com/19_60/store/iapp/goods/","error":"0","unlockRP_group":"1","bingo_card":["3","20","32","47","70","1","23","35","58","66","7","19","-1","56","63","11","25","37","57","72","14","27","33","59","73"],"recharge":{"img_url":"https://d.mwsrv.com/19_60/store/iapp/download/payment/ID/","product_list":{"productID":["texas9id_android_tmoney_1_303t_scratchoffrp"],"pic":["Google_01.png"],"top_msg":"Top-up Rp. 150,000 dapat 7.5mlr chips+RP*4,000(Google Play, Indosat,XL,3)\\nTop-up Rp. 100,000 dapat 5mlr chips+RP*4,000(Telkomsel)"}},"extra_reward_pos":["18","4","19"],"card_num":"2","total_ball":"37","left_time":"9487487","bingo_pos":["1","1","1","1","0","0","0","0","0","0","0","0","1","0","0","0","0","0","0","0","0","0","0","0","0"],"one_run":"5","token":"115","extra_reward":{"reward_list":[{"get_left_time":"10"},{"get_left_time":"0"}],"need_RP":"200"},"pass_icon":{"pop":"0","can_reward":"1","goal":["2","5","10","20","30","40","50","60","75","90","105","120","135","150","165","180","195","210","230","250"]},"ball_reward_pot":[{"wid_pic":"5009","count":"0"},{"wid_pic":"7097","count":"0"}],"add":{"is_vip":"0","play_btn":[{"type":"3","url":"38","lobby_type":"9901","track_type":"92"},{"type":"3","url":"95","lobby_type":"9911","track_type":"1374"}],"slot_btn":[{"track_type":"89","lobby_type":"133","url":"133","type":"147"},{"track_type":"90","lobby_type":"134","url":"134","type":"147"},{"track_type":"91","lobby_type":"42","url":"0","type":"192"}]}}'),
            "info 有獎": () => DataProcess.sendCustomStringToSelf('farm_bingo_info {"round":{"done_card_num":"0","reward":"900000","goal":"1","stage":"2"},"play_group":"1","img_url":"https://d.mwsrv.com/19_60/store/iapp/goods/","error":"0","unlockRP_group":"1","bingo_card":["3","20","32","47","70","1","23","35","58","66","7","19","-1","56","63","11","25","37","57","72","14","27","33","59","73"],"recharge":{"img_url":"https://d.mwsrv.com/19_60/store/iapp/download/payment/ID/","product_list":{"productID":["texas9id_android_tmoney_1_303t_scratchoffrp"],"pic":["Google_01.png"],"top_msg":"Top-up Rp. 150,000 dapat 7.5mlr chips+RP*4,000(Google Play, Indosat,XL,3)\\nTop-up Rp. 100,000 dapat 5mlr chips+RP*4,000(Telkomsel)"}},"extra_reward_pos":["18","4","19"],"card_num":"2","total_ball":"37","left_time":"9487487","bingo_pos":["1","1","1","1","0","0","0","0","0","0","0","0","1","0","0","0","0","0","0","0","0","0","0","0","0"],"one_run":"5","token":"115","extra_reward":{"reward_list":[{"get_left_time":"10"},{"get_left_time":"0"}],"need_RP":"200"},"pass_icon":{"pop":"0","can_reward":"1","goal":["2","5","10","20","30","40","50","60","75","90","105","120","135","150","165","180","195","210","230","250"]},"ball_reward_pot":[{"wid_pic":"5009","count":"100"},{"wid_pic":"7097","count":"1"}],"add":{"is_vip":"0","play_btn":[{"type":"3","url":"38","lobby_type":"9901","track_type":"92"},{"type":"3","url":"95","lobby_type":"9911","track_type":"1374"}],"slot_btn":[{"track_type":"89","lobby_type":"133","url":"133","type":"147"},{"track_type":"90","lobby_type":"134","url":"134","type":"147"},{"track_type":"91","lobby_type":"42","url":"0","type":"192"}]}}'),
            "10s info": () => DataProcess.sendCustomStringToSelf('farm_bingo_info {"round":{"done_card_num":"0","reward":"900000","goal":"1","stage":"2"},"play_group":"1","img_url":"https://d.mwsrv.com/19_60/store/iapp/goods/","error":"0","unlockRP_group":"1","bingo_card":["3","20","32","47","70","1","23","35","58","66","7","19","-1","56","63","11","25","37","57","72","14","27","33","59","73"],"recharge":{"img_url":"https://d.mwsrv.com/19_60/store/iapp/download/payment/ID/","product_list":{"productID":["texas9id_android_tmoney_1_303t_scratchoffrp"],"pic":["Google_01.png"],"top_msg":"Top-up Rp. 150,000 dapat 7.5mlr chips+RP*4,000(Google Play, Indosat,XL,3)\\nTop-up Rp. 100,000 dapat 5mlr chips+RP*4,000(Telkomsel)"}},"extra_reward_pos":["18","4","19"],"card_num":"2","total_ball":"37","left_time":"10","bingo_pos":["1","1","1","1","0","0","0","0","0","0","0","0","1","0","0","0","0","0","0","0","0","0","0","0","0"],"one_run":"5","token":"115","extra_reward":{"reward_list":[{"get_left_time":"10"},{"get_left_time":"0"}],"need_RP":"200"},"pass_icon":{"pop":"0","can_reward":"1","goal":["2","5","10","20","30","40","50","60","75","90","105","120","135","150","165","180","195","210","230","250"]},"ball_reward_pot":[{"wid_pic":"5009","count":"0"},{"wid_pic":"7097","count":"0"}],"add":{"is_vip":"0","play_btn":[{"type":"3","url":"38","lobby_type":"9901","track_type":"92"},{"type":"3","url":"95","lobby_type":"9911","track_type":"1374"}],"slot_btn":[{"track_type":"89","lobby_type":"133","url":"133","type":"147"},{"track_type":"90","lobby_type":"134","url":"134","type":"147"},{"track_type":"91","lobby_type":"42","url":"0","type":"192"}]}}'),
            "獎勵罐領獎": () => DataProcess.sendCustomStringToSelf('farm_bingo_buy_extra_reward {"img_url":"https://d.mwsrv.com/19_60/store/iapp/goods/","reward_msg":["10rb chips","Kunci Emas 1 Hari"],"error":"0","reward":[{"count":"10000","wid":"-3409"},{"count":"1","wid":"3622"}]}'),
            "Dialog": {
                "代幣達上限": () => this.showDialog(new FarmBingoCommonDialog({
                    type: FarmBingoCommonDialog.DialogType.COMMON,
                    content: LocalizedString.FarmBingo("您已達累積上限\n請先遊玩賓果才可繼續累積呦"),
                    trackType: 4487
                })),
                "RP 不足": () => this.showDialog(new FarmBingoCommonDialog({
                    type: FarmBingoCommonDialog.DialogType.RP_NOT_ENOUGH
                })),
                "RP 購買": () => this.showDialog(new FarmBingoCommonDialog({
                    type: FarmBingoCommonDialog.DialogType.RP_BUY_POT,
                    cost: 100,
                    isCloseButtonShow: true,
                })),
                "罐子達上限 dialog": () => this.showDialog(new FarmBingoCommonDialog({
                    type: FarmBingoCommonDialog.DialogType.POT_LIMIT,
                    cost: 300,
                    isCloseButtonShow: true
                })),
                "幫領 dialog": () => this.showDialog(new FarmBingoCommonDialog({
                    type: FarmBingoCommonDialog.DialogType.OPEN_AVAILABLE,
                    rewardArray: ["Something", "Something", "Something"],
                })),
            },
            "Koin += 1000": () => DataModal.koinLuxyData.myKoin += 1000,
            "領球 - 一般無罐情況": () => DataProcess.sendCustomStringToSelf('farm_bingo_get_ball {"bingo_card":["1","21","42","58","70","5","18","38","48","61","4","24","-1","52","63","14","30","32","59","64","15","23","40","57","67"],"bingo_pos":["0","0","0","0","0","0","0","0","0","0","0","1","1","0","0","0","0","0","0","0","0","0","0","0","0"],"extra_reward_pos":["7","20","6"],"new_balls":["24"],"play_group":"1","one_run":"1","round":{"stage":"2","goal":"3","done_card_num":"1","reward":"20000"},"extra_reward":{"need_RP":"100","reward_list":[]},"error":"0","unlockRP_group":"1","ball_reward_pot":[{"count":"30rb","wid_pic":"5009"},{"wid_pic":"7097","count":"30"}],"img_url":"https://d.mwsrv.com/19_60/store/iapp/goods/","card_num":"4","new_balls_pos":["11"]}'),
            "領球 - 一般有罐情況": () => DataProcess.sendCustomStringToSelf('farm_bingo_get_ball {"bingo_card":["1","21","42","58","70","5","18","38","48","61","4","24","-1","52","63","14","30","32","59","64","15","23","40","57","67"],"bingo_pos":["0","0","0","0","0","0","0","0","0","0","0","1","1","0","0","0","0","0","0","0","0","0","0","0","0"],"extra_reward_pos":["7","20","6"],"new_balls":["24"],"play_group":"1","one_run":"1","round":{"stage":"2","goal":"3","done_card_num":"1","reward":"20000"},"extra_reward":{"buy_extra_reward_now":"1","reward_list":[{"get_left_time":"10"},{"get_left_time":"300"}],"need_RP":"100"},"error":"0","unlockRP_group":"1","ball_reward_pot":[{"count":"30rb","wid_pic":"5009"},{"wid_pic":"7097","count":"30"}],"img_url":"https://d.mwsrv.com/19_60/store/iapp/goods/","card_num":"4","new_balls_pos":["11"]}'),
            "領球 - 橫向連線": () => DataProcess.sendCustomStringToSelf('farm_bingo_get_ball {"ball_reward_pot":[{"count":"30rb","wid_pic":"5009"},{"count":"30","wid_pic":"7097"}],"bingo_card":["1","21","42","58","70","5","18","38","48","61","4","24","-1","52","63","14","30","32","59","64","15","23","40","57","67"],"bingo_pos":["0","0","0","0","0","0","0","0","0","0","0","0","1","0","0","0","0","0","0","0","0","0","0","0","0"],"card_num":"4","error":"0","extra_reward":{"reward_list":[],"need_RP":"100"},"extra_reward_pos":["7","20","6"],"img_url":"https://d.mwsrv.com/19_60/store/iapp/goods/","lines_list":["1","0","1","0","1","0","0","0","0","0","0","0"],"new_balls":["38"],"new_balls_pos":["7"],"next_card":{"extra_reward_pos":["19","13","20"],"bingo_pos":["0","0","0","0","0","0","0","0","0","0","0","0","1","0","0","0","0","0","0","0","0","0","0","0","0"],"bingo_card":["7","26","35","60","64","8","30","34","58","65","13","16","-1","59","62","2","28","42","56","61","10","29","43","50","68"],"unlockRP_group":"1","ball_reward_pot":[{"count":"0","wid_pic":"5009"},{"count":"0","wid_pic":"7097"}],"play_group":"1","round":{"goal":"3","reward":"20000","done_card_num":"2","stage":"2"},"card_num":"5"},"one_run":"0","play_group":"1","pot_reward_msg":["160rb chips","160 RP(Koin Luxy)"],"recharge":{"img_url":"https://d.mwsrv.com/19_60/store/iapp/download/payment/ID/","product_list":{"productID":["texas9id_android_tmoney_1_303t_scratchoffrp"],"pic":["Google_01.png"],"top_msg":"Top-up Rp. 150,000 dapat 7.5mlr chips+RP*4,000(Google Play, Indosat,XL,3)\\nTop-up Rp. 100,000 dapat 5mlr chips+RP*4,000(Telkomsel)"}},"round":{"done_card_num":"1","stage":"2","reward":"20000","goal":"3"},"token":"115","total_ball":"37","unlockRP_group":"1"}'),
            "領球 - 縱向連線": () => DataProcess.sendCustomStringToSelf('farm_bingo_get_ball {"ball_reward_pot":[{"count":"30rb","wid_pic":"5009"},{"count":"30","wid_pic":"7097"}],"bingo_card":["1","21","42","58","70","5","18","38","48","61","4","24","-1","52","63","14","30","32","59","64","15","23","40","57","67"],"bingo_pos":["0","0","0","0","0","0","0","0","0","0","0","0","1","0","0","0","0","0","0","0","0","0","0","0","0"],"card_num":"4","error":"0","extra_reward":{"reward_list":[],"need_RP":"100"},"extra_reward_pos":["7","20","6"],"img_url":"https://d.mwsrv.com/19_60/store/iapp/goods/","lines_list":["0","0","0","0","0","1","0","1","0","1","0","0"],"new_balls":["38"],"new_balls_pos":["7"],"next_card":{"extra_reward_pos":["19","13","20"],"bingo_pos":["0","0","0","0","0","0","0","0","0","0","0","0","1","0","0","0","0","0","0","0","0","0","0","0","0"],"bingo_card":["7","26","35","60","64","8","30","34","58","65","13","16","-1","59","62","2","28","42","56","61","10","29","43","50","68"],"unlockRP_group":"1","ball_reward_pot":[{"count":"0","wid_pic":"5009"},{"count":"0","wid_pic":"7097"}],"play_group":"1","round":{"goal":"3","reward":"20000","done_card_num":"2","stage":"2"},"card_num":"5"},"one_run":"0","play_group":"1","pot_reward_msg":["160rb chips","160 RP(Koin Luxy)"],"recharge":{"img_url":"https://d.mwsrv.com/19_60/store/iapp/download/payment/ID/","product_list":{"productID":["texas9id_android_tmoney_1_303t_scratchoffrp"],"pic":["Google_01.png"],"top_msg":"Top-up Rp. 150,000 dapat 7.5mlr chips+RP*4,000(Google Play, Indosat,XL,3)\\nTop-up Rp. 100,000 dapat 5mlr chips+RP*4,000(Telkomsel)"}},"round":{"done_card_num":"1","stage":"2","reward":"20000","goal":"3"},"token":"115","total_ball":"37","unlockRP_group":"1"}'),
            "領球 - 斜向連線": () => DataProcess.sendCustomStringToSelf('farm_bingo_get_ball {"ball_reward_pot":[{"count":"30rb","wid_pic":"5009"},{"count":"30","wid_pic":"7097"}],"bingo_card":["1","21","42","58","70","5","18","38","48","61","4","24","-1","52","63","14","30","32","59","64","15","23","40","57","67"],"bingo_pos":["0","0","0","0","0","0","0","0","0","0","0","0","1","0","0","0","0","0","0","0","0","0","0","0","0"],"card_num":"4","error":"0","extra_reward":{"reward_list":[],"need_RP":"100"},"extra_reward_pos":["7","20","6"],"img_url":"https://d.mwsrv.com/19_60/store/iapp/goods/","lines_list":["0","0","0","0","0","0","0","0","0","0","1","1"],"new_balls":["38"],"new_balls_pos":["7"],"next_card":{"extra_reward_pos":["19","13","20"],"bingo_pos":["0","0","0","0","0","0","0","0","0","0","0","0","1","0","0","0","0","0","0","0","0","0","0","0","0"],"bingo_card":["7","26","35","60","64","8","30","34","58","65","13","16","-1","59","62","2","28","42","56","61","10","29","43","50","68"],"unlockRP_group":"1","ball_reward_pot":[{"count":"0","wid_pic":"5009"},{"count":"0","wid_pic":"7097"}],"play_group":"1","round":{"goal":"3","reward":"20000","done_card_num":"2","stage":"2"},"card_num":"5"},"one_run":"0","play_group":"1","pot_reward_msg":["160rb chips","160 RP(Koin Luxy)"],"recharge":{"img_url":"https://d.mwsrv.com/19_60/store/iapp/download/payment/ID/","product_list":{"productID":["texas9id_android_tmoney_1_303t_scratchoffrp"],"pic":["Google_01.png"],"top_msg":"Top-up Rp. 150,000 dapat 7.5mlr chips+RP*4,000(Google Play, Indosat,XL,3)\\nTop-up Rp. 100,000 dapat 5mlr chips+RP*4,000(Telkomsel)"}},"round":{"done_card_num":"1","stage":"2","reward":"20000","goal":"3"},"token":"115","total_ball":"37","unlockRP_group":"1"}'),
            "看出球": () => {
                if (this._debugBallNode) {
                    this._debugBallNode.removeFromParent();
                    this._debugBallNode = undefined;
                } else {
                    this._debugBallNode = new FarmBingoBallNode(Math.floor(Math.random() * 75));
                    this._debugBallNode.setPosition(JSScreenMidPos);
                    this._animationLayer.addChild(this._debugBallNode);
                }
            },
            "Semaphore Acquire": () => {
                SemaphoreManager.get("FarmBingoDialogEventEndSemaphore").acquire().then((key) => {
                    this._debugSemaphoreKey = key;
                    console.log("Semaphore Acquired");
                });
            },
            "Semaphore Release": () => {
                SemaphoreManager.get("FarmBingoDialogEventEndSemaphore").release(this._debugSemaphoreKey);
                this._debugSemaphoreKey = undefined;
                console.log("Semaphore Released");
            },
        });
    },
});