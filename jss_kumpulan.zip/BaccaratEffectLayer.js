/**
 *  百家樂特效畫面
 */

var BaccaratEffectLayer = cc.Layer.extend({
    ctor: function () {
        this._super();
    },

    /**
     * 清除畫面
     */
    clean: function () {
        this.removeAllChildren();
    },

    /**
     * 出現結算畫面
     */
    showFinishResultAsync: function (param, totalBetMoney) {
        return new Promise(resolve => {
            var winMoney = param.winMoney;

            var resultNode = new cc.Node();
            resultNode.setCascadeOpacityEnabled(true);
            this.addChild(resultNode);

            // 黑底
            var bgLayer = new cc.LayerColor(cc.color(0, 0, 0, 210), JSVisibleSize.width + 2, JSVisibleSize.height + 2);
            bgLayer.setPosition(-1, -1);
            resultNode.addChild(bgLayer);

            // 判斷東西
            var bgName, wordName, wordY;
            switch (param.winStatus) {
                case 0:
                    // 和局
                    bgName = "#brc_light_bg2.png";
                    wordName = "#vegas_word_draw.png";
                    wordY = JSScreenMidPos.y - 34;
                    Vegas_MusicUtility.playEffect("Music/Effect/blackjack_draw.mp3");
                    break;
                case 1:
                    // 贏
                    bgName = "#brc_light_bg1.png";
                    wordName = "#vegase_word_win.png";
                    wordY = JSScreenMidPos.y - 12;
                    Vegas_MusicUtility.playEffect("Music/Effect/blackjack_win.mp3");
                    break;
                case -1:
                    // 輸
                    bgName = "#brc_light_bg2.png";
                    wordName = "#vegase_word_lose.png";
                    wordY = JSScreenMidPos.y - 34;
                    Vegas_MusicUtility.playEffect("Music/Effect/blackjack_lose.mp3");
                    break;
            }

            // 勝利撥放光條
            if (winMoney > 0 && param.winStatus === 1) {
                var self = this;
                resultNode.schedule(function () {
                    resultNode.addChild(self._createFlashLight());
                }, 0.3);
            }

            var bgSprite = new cc.Sprite(bgName);
            var scaleX = JSVisibleSize.width / bgSprite.getContentSize().width;
            bgSprite.setScaleX(scaleX);
            bgSprite.setScaleY(0);
            bgSprite.setPosition(JSScreenMidPos);
            bgSprite.setOpacity(0);
            resultNode.addChild(bgSprite);

            bgSprite.runAction(cc.scaleTo(1, scaleX, 1));
            bgSprite.runAction(cc.fadeTo(2, 200).easing(cc.easeInOut(2)));

            // 文字
            var wordSprite = new cc.Sprite(wordName);
            wordSprite.setAnchorPoint(0.5, 0);
            wordSprite.setPosition(JSScreenMidPos.x, wordY);
            wordSprite.setScale(0.8);
            wordSprite.setOpacity(0);
            resultNode.addChild(wordSprite, 1);

            wordSprite.runAction(cc.spawn(
                cc.scaleTo(1, 1),
                cc.fadeTo(2, 255).easing(cc.easeInOut(2))
            ));

            // 判斷是否要出現金額 平手不show
            if (winMoney > 0 && param.winStatus === 1) {
                var moneyPosY = JSScreenMidPos.y - 26;
                var moneyNode = this._createMoneyNode(winMoney);
                moneyNode.setPosition(JSScreenMidPos.x, moneyPosY);
                moneyNode.setOpacity(0);
                moneyNode.setScale(0.8);
                resultNode.addChild(moneyNode, 1);

                // 動畫
                moneyNode.runAction(cc.scaleTo(1, 1));
                moneyNode.runAction(cc.fadeIn(2).easing(cc.easeInOut(2)));
            }

            // 最後要設定關掉
            resultNode.runAction(cc.sequence(
                cc.delayTime(2),
                cc.fadeOut(0.3),
                cc.callFunc(function () {
                    // 更新現在的金錢
                    DataModal.profileData.money = param.nextMoney;

                    // 通知UI更新金錢
                    GS.dispatchCustomEvent("NotifySetTMoney");

                    // 結束
                    resolve();
                }),
                cc.removeSelf()
            ));
        });
    },

    // 創金錢的數字
    _createMoneyNode: function (money) {
        // 先計算Sprite總寬度 數字高度固定為50 逗點寬26 其他寬40
        var retNode = new cc.Node();
        retNode.setCascadeOpacityEnabled(true);

        var moneyString = JSCodeUtility.getCurrencyString(money);
        var moneyLen = moneyString.length;
        var moneyPosX = 0;
        for (var i = 0; i < moneyLen; i++) {
            var moneyChar = moneyString[i];
            var isDot = (moneyChar === ",");
            var moneySprite = new cc.Sprite("#vegase_number" + moneyChar + ".png");
            moneySprite.setPosition(moneyPosX, isDot ? -15 : 0);
            moneySprite.setAnchorPoint(0, 0.5);
            retNode.addChild(moneySprite);

            moneyPosX += (isDot ? 16 : 30);
        }

        // 要重新對位
        var offsetX = moneyPosX / 2;
        retNode.getChildren().forEach(function (cur) {
            var originPos = cur.getPosition();
            cur.setPosition(originPos.x - offsetX, originPos.y);
        });


        return retNode;
    },

    // 亮光點的動畫
    _createLightBall: function (isRight, scaleSize, speed) {
        var point = isRight ? cc.p(JSVisibleSize.width - 1, 30) : cc.p(1, JSScreenMidPos.y + 99);
        var width = JSVisibleSize.width - 2;
        var height = 213 + JSScreenBonusHalfHeight;
        var pointArray = [
            cc.p(0, 0),
            cc.p(isRight ? -width : width, 0),
            cc.p(isRight ? -width : width, isRight ? height : -height),
            cc.p(0, isRight ? height : -height),
            cc.p(0, 0)
        ];

        var lightBallSprite = new cc.Sprite("#vegas_effectLight_02.png");
        lightBallSprite.setScale(scaleSize);
        lightBallSprite.setPosition(point);

        // 動畫
        lightBallSprite.runAction(cc.repeatForever(cc.cardinalSplineBy(speed, pointArray, 1)));

        lightBallSprite.runAction(cc.repeatForever(cc.rotateBy(1, 360)));

        if (scaleSize < 1) {
            lightBallSprite.runAction(cc.repeatForever(cc.sequence(
                cc.fadeTo(0.5, 40),
                cc.fadeTo(0.5, 255)
            )));
        }

        return lightBallSprite;
    },

    // 亮光條的動畫
    _createFlashLight: function () {
        var retNode = new cc.Node();
        retNode.setCascadeOpacityEnabled(true);

        for (var i = 0; i < 2; i++) {
            var lightSprite = new cc.Sprite("#brc_win_light.png");
            lightSprite.setScale(2);
            lightSprite.setAnchorPoint(0.5, 0);
            lightSprite.setPosition(JSScreenMidPos.x + (i === 0 ? -154 : 154), JSScreenMidPos.y - 56);
            lightSprite.setRotation(i === 0 ? -90 : 90);
            lightSprite.setOpacity(0);
            retNode.addChild(lightSprite);

            lightSprite.runAction(cc.rotateBy(1.3, i === 0 ? 180 : -180));
            lightSprite.runAction(cc.sequence(
                cc.fadeTo(0.2, 30),
                cc.delayTime(0.8),
                cc.fadeTo(0.3, 0),
                cc.removeSelf()
            ));
        }

        return retNode;
    },

    // 金幣的動畫
    _createCoinAnimation: function () {
        var retNode = new cc.Node();
        retNode.setCascadeOpacityEnabled(true);

        var coinSprite = new cc.Sprite("#anim_chip_0.png");
        coinSprite.setOpacity(0);
        coinSprite.setPosition(JSScreenMidPos.x + JSCodeUtility.getRandomInt(-230, 230), JSScreenMidPos.y + JSCodeUtility.getRandomInt(-44, 0));
        retNode.addChild(coinSprite);

        // 一直換圖
        var aniFramesArray = [];
        for (var i = 0; i < 6; i++) {
            aniFramesArray.push(cc.spriteFrameCache.getSpriteFrame(JSStringUtility.format("anim_chip_%d.png", i)));
        }
        coinSprite.runAction(cc.repeatForever(cc.animate(new cc.Animation(aniFramesArray, 0.1))));

        // 動畫
        coinSprite.runAction(cc.sequence(
            cc.fadeIn(0.2),
            cc.delayTime(1),
            cc.fadeOut(0.2),
            cc.removeSelf()
        ));
        coinSprite.runAction(cc.jumpTo(1.4, cc.p(JSScreenMidPos.x + JSCodeUtility.getRandomInt(-230, 230), -30), 200, 1));

        return retNode;
    },
});