/**
 * 百家樂的開獎紀錄的點數
 */
var BaccaratRecordPointNode = cc.Node.extend({
    ctor: function () {
        this._super();
    },

    /**
     * 更新贏家畫面 回傳Type
     */
    _updateWhoWin: function (whoWin) {
        // 0:閒贏 1:莊贏 2:平手
        var type, imageString, opacity = 255;
        switch (whoWin) {
            case 0:
                type = BaccaratWinType.PLAYER;
                imageString = "#bcr_point2.png";
                break;
            case 1:
                type = BaccaratWinType.BANKER;
                imageString = "#bcr_point1.png";
                break;
            case 2:
                type = BaccaratWinType.SERI;
                imageString = "#bcr_point3.png";
                break;
            default:
                return BaccaratWinType.NONE;
        }

        var bgSprite = new cc.Sprite(imageString);
        this.addChild(bgSprite);

        return type;
    },

    /**
     * 設定大路的贏牌資訊 回傳這次的贏家
     */
    showBigRoad: function (roadString) {
        //  大路
        // 0：閒嬴
        // 1：閒嬴閒一對
        // 2：閒嬴莊一對
        // 3：閒嬴閒莊各一對
        // 4：莊嬴
        // 5：莊嬴閒一對
        // 6：莊嬴莊一對
        // 7：莊嬴閒莊各一對
        // 8：和
        // 9：和閒一對
        // A：和莊一對
        // B：和莊閒各一對
        var number = 0;
        if (roadString === "A")
            number = 10;
        else if (roadString === "B")
            number = 11;
        else
            number = parseInt(roadString);

        var whoWin = Math.floor(number / 4);
        var whoPair = number % 4;
        var winType = this._updateWhoWin(whoWin);

        var needShowPlayer, needShowBanker;
        switch (whoPair) {
            case 0:
                // 都沒有一對
                break;
            case 1:
                // 閒一對
                needShowPlayer = true;
                break;
            case 2:
                // 莊一對
                needShowBanker = true;
                break;
            case 3:
                // 閒莊一對
                needShowPlayer = true;
                needShowBanker = true;
                break;
        }
        if (needShowPlayer) {
            var pairSprite = new cc.Sprite("#bcr_point5.png");
            pairSprite.setPosition(3, -3);
            this.addChild(pairSprite, 1);
        }
        if (needShowBanker) {
            var pairSprite = new cc.Sprite("#bcr_point4.png");
            pairSprite.setPosition(-3, 3);
            this.addChild(pairSprite, 1);
        }

        return winType;
    },

    /**
     * 設定珠盤路的贏牌資訊
     */
    showBeadRoad: function (roadString) {
        // 珠盤路
        // 左 0:閒贏 1:莊贏 2:平手
        // 右 表示那一局的分數
        var whoWin = parseInt(roadString[0]);
        var number = roadString[1];

        this._updateWhoWin(whoWin);

        // 分數
        var numberLabel = new cc.LabelTTF(number, JSFontBoldName, 9);
        this.addChild(numberLabel, 2);
    },
});