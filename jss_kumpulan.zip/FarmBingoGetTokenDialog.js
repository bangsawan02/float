/**
 *  v5.6.0 齋戒副系統 - 我要代幣Dialog
 */

var FarmBingoGetTokenDialog = BaseGetTokenDialog.extend({
    ctor: function () {
        this._super();

        this.key = "FarmBingoGetTokenDialog";

        // 讓dialog黑一點
        this.dialogBgColor = cc.color(0, 0, 0, 218);

        var locString = LocalizedString.FarmBingo;
        var data = DataModal.farmBingoData;

        // 設定背景圖檔
        this._bgImg = "farm_bingo_bg_frame_dialog-1.png";
        this._bgSize = cc.size(358, 216);

        // 設定標題相關參數
        this._titleColor = cc.color(120, 91, 49);
        this._titleFontSize = 10;
        this._titleString = this._titleString = JSStringUtility.format(locString("代幣若達%s時，\n需先消耗才可繼續累積呦"), JSCodeUtility.getCurrencyString(data.limitToken));

        // 設定中間資訊框相關參數
        this._frameSize = cc.size(322, 125);
        this._frameImg = "farm_bingo_bg_frame_dialog-2.png";

        // 設定中間的玩法參數
        var tokenThreshold = TexasUtility.getSimpleMoneyString(data.getTokensSill || 9999999);
        this._centerTitleFontSize = 10;
        this._centerStringColor = cc.color(84, 61, 26);
        this._centerSettingArray = [
            {
                title: locString("指定機台"),
                content: JSStringUtility.format(locString("投注額>=%s且每%s可獲得1代幣"), tokenThreshold, tokenThreshold),
                btnArray: data.slotBtnArray
            },
            {
                title: locString("指定玩法"),
                content: locString("每玩1手拿代幣"),
                btnArray: data.playBtnArray
            }
        ];
    },

    onEnter: function () {
        this._super();

        // 埋點：進入獲得代幣頁面 4479
        DataModal.farmBingoData.sendTrackingData(4479);
    },

    loadFileDone: function () {
        this._super();

        var aniLayer = this._animationLayer;

        // 花朵
        [
            {posX: 104, posY: 253},
            {posX: 405, posY: 51, rotate: -20, flippedX: true}
        ].forEach(cur => {
            var flowerSprite = new cc.Sprite("#farm_bingo_bg_frame_dialog-3.png");
            flowerSprite.setPosition(cur.posX + JSScreenBonusHalfWidth, cur.posY + JSScreenBonusHalfHeight);
            cur.flippedX && flowerSprite.setFlippedX(true);
            cur.rotate && flowerSprite.setRotation(cur.rotate);
            aniLayer.addChild(flowerSprite);
        });
    },

    /**
     * 創分隔線
     */
    _createLineSprite: function () {
        var lineSprite = new ccui.Scale9Sprite("farm_bingo_pic_line.png");
        lineSprite.setPreferredSize(cc.size(2, 100));
        return lineSprite;
    },

    /**
     * 創馬上玩按鈕
     */
    _createPlayBtn: function () {
        return new Texas_Button(Texas_Button.Style.GREEN, cc.size(95, 32), LocalizedString.Lobby("馬上玩"), {fontSize: 14});
    },

    /**
     * 點擊玩法按鈕
     * @override
     */
    _gameBtnClicked: function (sender) {
        // 按鈕資料
        var btnParam = sender.btnParam;

        // 埋點
        switch (btnParam.lobbyType) {
            case LobbySelectGameSetting.GameType.Texas:
            case LobbySelectGameSetting.GameType.Texas19:
                // 埋點：點擊poker 4483
                DataModal.farmBingoData.sendTrackingData(4483);
                break;
            case LobbySelectGameSetting.GameType.GaplePlus:
                // 埋點：點擊gaple plus 4484
                DataModal.farmBingoData.sendTrackingData(4484);
                break;
            case LobbySelectGameSetting.GameType.TigerSlot:
                // 埋點：點擊虎機台 4480
                DataModal.farmBingoData.sendTrackingData(4480);
                break;
            case LobbySelectGameSetting.GameType.Dragon5Slot:
                // 埋點：點擊龍機台 4481
                DataModal.farmBingoData.sendTrackingData(4481);
                break;
            case LobbySelectGameSetting.GameType.MultiDiceBo:
            case LobbySelectGameSetting.GameType.MultiDiceBo_TEST_A:
                // case LobbySelectGameSetting.GameType.MultiDiceBo_TEST_B:
                // 埋點：點擊百人骰寶 4482
                DataModal.farmBingoData.sendTrackingData(4482);
                break;
        }

        // 這邊是各種玩法類型要擋掉不導遊戲
        // 牌桌玩法
        if (btnParam.lobbyType > 1000) {
            // 不在大廳 -> 不給導
            if (!PushScene.isLobby) {
                // 在桌內同個遊戲
                if (btnParam.url === GS.nowGame && PushScene.isGame && !cc.director.getRunningScene().isVegasScene)
                    this._closeOtherDialog();
                else
                    this._showDialog("請先回大廳再去其\n他玩法遊玩呦!");
                return;
            }
        } else {    // 機台玩法
            // 在Game -> 不給導
            if (PushScene.isGame) {
                // 在同一個機台 -> 關掉主dialog
                if (btnParam.lobbyType === DataModal.lastVegasType && cc.director.getRunningScene().isVegasScene) {
                    // 關掉dialog
                    this._closeOtherDialog();
                } else {
                    this._showDialog("請先回大廳再去其\n他機台遊玩呦!");
                }
                return;
            }

            // 在Slot機台 然後是要導一般機台 -> 不給導
            if (PushScene.isSlot && btnParam.lobbyType < 100) {
                this._showDialog("請先回大廳再去其\n他機台遊玩呦!");
                return;
            }
        }

        // 上面都沒走到才會導該玩法

        // 關掉dialog
        this._closeOtherDialog();

        // 牌桌另外導
        if (btnParam.lobbyType > 1000) {
            var gameParam = {
                game: GSEnum.Game.Texas
            };
            var data = DataModal.farmBingoData;
            switch (btnParam.lobbyType) {
                case LobbySelectGameSetting.GameType.Texas:
                    gameParam.game = GSEnum.Game.Texas;
                    gameParam.limitFee = data.accumulateFeeData.minFeeTexas;
                    gameParam.limitFeeCeil = data.accumulateFeeData.maxFeeTexas;
                    break;
                case LobbySelectGameSetting.GameType.Texas19:
                    gameParam.game = GSEnum.Game.Texas19;
                    gameParam.limitFee = data.accumulateFeeData.minFeeTexas;
                    gameParam.limitFeeCeil = data.accumulateFeeData.maxFeeTexas;
                    break;
                case LobbySelectGameSetting.GameType.GaplePlus:
                    gameParam.game = GSEnum.Game.GaplePlus;
                    gameParam.limitFee = data.accumulateFeeData.minFeeGaplePlus;
                    gameParam.limitFeeCeil = data.accumulateFeeData.maxFeeGaplePlus;
                    break;
            }
            GS.dispatchCustomEvent("NotifyGoDirectGame", gameParam);
        } else {
            // 導指定機台
            PushLayerHelper.pushLayer(btnParam.url, btnParam.type);
        }
    },

    /**
     * 點擊馬上玩按鈕
     * @override
     */
    _playBtnClicked: function () {
        // 埋點：點擊馬上玩 4485
        DataModal.farmBingoData.sendTrackingData(4485);

        if (PushScene.isGame) {
            // 在非slot機台 -> 跳dialog
            this._showDialog("請先回大廳再去其\n他機台遊玩呦!");
            return;
        }

        // 關掉dialog
        this._closeOtherDialog();

        // 導馬上玩
        var data = DataModal.farmBingoData;
        switch (DataModal.lastGameType) {
            case GSEnum.GameType.TABLE:         // 牌桌類
                // 導Poker
                GS.dispatchCustomEvent("NotifyGoDirectGame", {
                    game: GSEnum.Game.Texas,
                    limitFee: data.accumulateFeeData.minFeeTexas,
                    limitFeeCeil: data.accumulateFeeData.maxFeeTexas,
                });
                break;
            case GSEnum.GameType.SLOT:          // Slot機台
                // VIP1以上導龍
                if (DataModal.profileData.vipRank > 1) {
                    LobbySelectGameSetting.checkMachineOpenAndToGo(VegasGameType.Slot_134);
                } else {
                    LobbySelectGameSetting.checkMachineOpenAndToGo(VegasGameType.Slot_133);
                }
                break;
            case GSEnum.GameType.MULTI_VEGAS:   // 百人機台
            default:                            // 預設走百人骰寶
                // 導百人骰寶
                PushLayerHelper.pushLayer("", LobbyBannerMode.MultiDiceBo);
                break;
        }
    },

    /**
     * 創一般的dialog
     */
    _createCommonDialog: function (content) {
        return new FarmBingoCommonDialog({
            type: FarmBingoCommonDialog.DialogType.COMMON,
            content: LocalizedString.FarmBingo(content),
        });
    },

    /**
     * 關掉其他 dialog
     */
    _closeOtherDialog: function () {
        // 去找要關掉哪些
        var dialogKeyArray = ["FarmBingoDialog"];
        for (var i = 0, len = dialogKeyArray.length; i < len; i++) {
            var dialog = DialogManager.getDialogByKey(dialogKeyArray[i]);
            if (dialog) {
                dialog.closeDialogAnimation();

                // 有找到就不砍下一個了
                break;
            }
        }
    }
});