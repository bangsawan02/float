/**
 * 通行證 - 目前代幣數量槽
 * ```
 * config: {
 *     tokenBarBgFileName: "",                  // 背景圖案
 *     tokenIconFileName: "",                   // 代幣圖示
 *     tokenBarNodeSize: cc.size(102, 24),      // 代幣數量槽大小
 *     tokenBarIconScale: 0.7,                  // 代幣縮放倍率
 *     tokenBarIconOffset: cc.p(0, 0),          // 代幣圖示偏移
 *     tokenBarFontColor: cc.color(0, 0, 0),    // 代幣數量文字顏色
 *     tokenBarFontSize: 12,                    // 代幣數量預設文字大小（Implement by GSAutoSizeLabel）
 *     tokenBarIsShowPlusBtn: false,            // 是否顯示增加按鈕
 *     tokenBarPlusBtnOnClick: () => {},        // 點擊 callback
 * }
 * ```
 */
var BasePassTokenBar = cc.Node.extend({
    ctor: function (config) {
        this._super();

        this.setCascadeOpacityEnabled(true);
        this.setCascadeColorEnabled(true);

        let bgFileName = config.tokenBarBgFileName || "luxyPass_pic_frame_star_01.png";
        let iconFileName = config.tokenIconFileName || "luxyPass_pic_star.png";
        let iconScale = this.iconScale = config.tokenBarIconScale || 0.7;
        let iconOffset = config.tokenBarIconOffset || cc.p(0, 0);
        let fontColor = config.tokenBarFontColor || cc.color(252, 230, 145);
        let fontSize = config.tokenBarFontSize || 12;
        let isShowPlusBtn = config.tokenBarIsShowPlusBtn;
        let nodeSize = config.tokenBarNodeSize || cc.size(102, 24);

        // 背景圖案
        let bgSprite = new ccui.Scale9Sprite(bgFileName);
        bgSprite.setPreferredSize(nodeSize);
        this.addChild(bgSprite);

        // Token 圖案
        let tokenSprite = this._tokenSprite = new cc.Sprite("#" + iconFileName);
        tokenSprite.setScale(iconScale);
        tokenSprite.setPosition(cc.pAdd(iconOffset, cc.p(11 - nodeSize.width / 2, 0)));
        this.addChild(tokenSprite);

        // 增加按鈕
        if (isShowPlusBtn) {
            let plusBtn = this._plusBtn = new BasePassPlusButton(config);
            plusBtn.addTouchUpInsideAction(config.tokenBarPlusBtnOnClick, this);
            plusBtn.setScale(0.8);
            plusBtn.setPositionX(nodeSize.width / 2 - 11);
            this.addChild(plusBtn);
        }

        // Token 數量
        let tokenWidth = tokenSprite.getContentSize().width * tokenSprite.getScaleX();
        let plusBtnWidth = isShowPlusBtn ? this._plusBtn.getContentSize().width * this._plusBtn.getScaleX() : 0;
        let dimension = cc.size(nodeSize.width - tokenWidth - plusBtnWidth, 24);
        let label = this._quantityLabel = new GSAutoSizeLabel("0", JSFontName, fontSize, dimension, cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        label.setPositionX(isShowPlusBtn ? 0 : tokenWidth / 2);
        label.setFontFillColor(fontColor);
        this.addChild(label);
    },

    /**
     * 設定數量
     * @param {int} quantity 數量
     */
    setQuantity: function (quantity) {
        this._quantityLabel.setString(JSCodeUtility.getCurrencyString(quantity));
    },

    /**
     * 取得代幣 icon 位置
     * @returns {cc.Point}
     */
    getTokenSpritePosition: function () {
        return cc.pAdd(this.getPosition(), this._tokenSprite.getPosition());
    },

    /**
     * 取得左上+號按鈕
     */
    getPlusBtn: function () {
        return this._plusBtn;
    }
});