/**
 * 破產再登入 大廳icon
 */
var BrokeCouponPackLobbyNode = LobbyTimeIconNode.extend({
    ctor: function () {
        this._super();

        this.key = "BrokeCouponPackLobbyNode";

        // 註冊
        GS.addListener("NotifyBrokeCouponInfoDone", this.notifyBrokeCouponInfoDone.bind(this), this);
    },

    /**
     * 更新畫面
     */
    _refreshView: function () {
        var mainNode = this._mainNode;
        mainNode.removeAllChildren();

        // 沒有資料
        var param = DataModal.purchaseCouponData.brokeCoupon;
        if (!param) {
            // 隱藏icon
            this.setVisible(false);

            return;
        }

        // 沒有倒數時間
        var remainTime = JSCodeUtility.getRemainTimeByParam(param);
        if (remainTime > 0) {
            // 設定看的到
            this.setVisible(true);

            // icon
            var iconSprite = new cc.Sprite("#lobby_icon_brokeCoupon.png");
            mainNode.addChild(iconSprite);

            // 加入倒數時間
            this.createTimeLabelWithBackground(remainTime, () => {
                // 隱藏icon
                this.setVisible(false);

                // 重要資料
                DataModal.purchaseCouponData.startGetInfo();
            });

            // 要不要主動跳
            param.needPop && this._iconClicked();

        } else {
            // 隱藏icon
            this.setVisible(false);

            // 重要資料
            DataModal.purchaseCouponData.startGetInfo();
        }

    },

    /**
     * 按到的時後 要改變顏色
     */
    _iconClicked: function () {
        var param = DataModal.purchaseCouponData.brokeCoupon;

        // 跳dialog
        DialogManager.addLobbyDialog(new PurchasePackDialog(param), true, true);
    },

    /**
     * 通知
     */

    // 收到資訊
    notifyBrokeCouponInfoDone: function () {
        this._refreshView();
    },
});