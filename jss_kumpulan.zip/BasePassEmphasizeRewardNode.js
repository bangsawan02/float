/**
 * 通行證 - 最右邊的強調獎勵不會跟著滑動
 * ```
 * config: {
 *     tableViewCellSize: cc.size(0, 0),                    // 強調獎勵 cell size
 *     emphasizeRewardNodeBgFileName: "",                   // 背景圖
 *     emphasizeRewardNodeBgCapInsets: cc.rect(16, 22, 16, 21) // 強調獎勵背景的 capInsets
 *     emphasizeRewardOriginPositionY: JSScreenMidPos.y,    // 強調獎勵原點的 y 座標
 *     emphasizeRewardShowPositionX: 0,                     // 強調獎勵顯示的 x 座標
 *     emphasizeRewardCellOffset: cc.p(0, 0),               // 強調獎勵 reward cell 的偏移
 *
 *     // Debug flags:
 *     isShowDebugPoints: false,                            // 是否顯示除錯定位點
 * }
 * ```
 * ```
 * Notes:
 *      - 因為強調獎勵尺寸與 TableView 普通獎勵的 cell size 相同
 *        所以直接用相同的 key (tableViewCellSize).
 * ```
 */
var BasePassEmphasizeRewardNode = cc.Node.extend({
    ctor: function (config) {
        this._super();

        this._config = config;

        let cellSize = this._size = config.tableViewCellSize || BasePassRewardCell.NormalRewardCellSize;
        let bgFileName = config.emphasizeRewardNodeBgFileName || "luxyPass_pic_frame_05.png";
        let bgCapInsets = config.emphasizeRewardNodeBgCapInsets || cc.rect(16, 22, 16, 21);

        let nodeSize = cc.size(cellSize.width, cellSize.height + 6);

        let midPos = this._midPos = cc.p(nodeSize.width / 2, nodeSize.height / 2);
        let originPosY = config.emphasizeRewardOriginPositionY || JSScreenMidPos.y;
        let showPosX = config.emphasizeRewardShowPositionX || (435 + JSScreenBonusHalfWidth);
        this._originPos = cc.p(JSVisibleSize.width + midPos.x + 4, originPosY - midPos.y);
        this._showPos = cc.p(showPosX - midPos.x, this._originPos.y);
        let emphasizeRewardCellOffset = config.emphasizeRewardCellOffset || cc.p(0, 0);

        let animationNode = this._animationNode = new cc.Node();
        animationNode.setContentSize(cellSize.width, nodeSize.height + 4);
        animationNode.setPosition(this._originPos);
        this.addChild(animationNode);

        // 擋touch, 這邊有可能會跑來跑去, 不希望他出現時玩家按到下面的東西
        let dummyTouchSize = cc.size(nodeSize.width + 10, nodeSize.height);
        let dummyTouchLayer = new DummyTouchLayer(dummyTouchSize);
        dummyTouchLayer.setPosition(-5, 0);
        animationNode.addChild(dummyTouchLayer);

        let backgroundSprite = new ccui.Scale9Sprite(bgFileName);
        backgroundSprite.setCapInsets(bgCapInsets);
        backgroundSprite.setPreferredSize(nodeSize);
        backgroundSprite.setPosition(midPos);
        animationNode.addChild(backgroundSprite);

        let cellNode = this._cellNode = new BasePassNormalRewardCellNode(config);
        cellNode.setAnchorPoint(0.5, 0.5);
        cellNode.setPosition(midPos.x - cellSize.width / 2 + 2 + emphasizeRewardCellOffset.x, midPos.y - cellSize.height / 2 + emphasizeRewardCellOffset.y);
        animationNode.addChild(cellNode);

        if (JSDebugMode) {
            this._debugComponents = [];
            let debugDrawNode = new cc.DrawNode();
            debugDrawNode.drawDot(cellNode.getPosition(), 3, cc.color(255, 0, 0, 128));
            debugDrawNode.drawDot(midPos, 3, cc.color(0, 255, 255, 128));
            animationNode.addChild(debugDrawNode, 100);
            this._debugComponents.push(debugDrawNode);

            let dummyTouchLayerColor = new cc.LayerColor(cc.color(255, 0, 0, 128), dummyTouchSize.width, dummyTouchSize.height);
            dummyTouchLayerColor.setPosition(dummyTouchLayer.getPosition());
            animationNode.addChild(dummyTouchLayerColor, -1);
            this._debugComponents.push(dummyTouchLayerColor);
        }
    },

    /**
     * 強調獎勵要顯示哪一個等級的任務
     * @param   {int}       index   Cell Index
     * @param   {int}       length  rewardArray.length
     * @returns {int}
     */
    getEmphasizeIndex: function (index, length) {
        let emphasizeIndex = (index % 10 === 0) ? ((index / 10) + 1) * 10 : Math.ceil(index / 10) * 10;
        return cc.clampf(emphasizeIndex, Math.min(length - 1, 10), length - 1);
    },

    /**
     * 解析資料並更新 cell node
     * @param {object}  stageParam          階段獎勵資料
     * @param {int}     currentTokenCount   目前擁有的代幣數量
     * @param {int}     goalTokenCount      目標代幣數量
     */
    refreshView: function (stageParam, currentTokenCount, goalTokenCount) {
        this._cellNode.refreshView(stageParam, currentTokenCount, goalTokenCount);
        JSDebugMode && this._debugComponents.forEach(node => node.setVisible(this._config.isShowDebugPoints));
    },

    /**
     * 隱藏獎勵
     */
    hideReward: function () {
        if (!this._isOpen) {
            return;
        }
        this._isOpen = false;
        this._animationNode.stopAllActions();
        this._animationNode.runAction(
            cc.sequence(
                cc.moveTo(0.5, this._originPos)
            )
        );
    },

    /**
     * 顯示獎勵
     */
    showReward: function () {
        if (this._isOpen) {
            return;
        }
        this._isOpen = true;
        this._animationNode.stopAllActions();
        this._animationNode.runAction(
            cc.sequence(
                cc.moveTo(1, this._showPos).easing(cc.easeBackOut())
            )
        );
    },

    /**
     * 播放解鎖動畫
     * @param {number|number[]} [passTypes] 指定要播放解鎖動畫的通行證層級
     */
    playUnlockAnimation: function (passTypes) {
        this._cellNode.playUnlockAnimation(passTypes);
    }
});