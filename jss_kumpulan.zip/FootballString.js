var LocalizedString = LocalizedString || {};

(function () {
    var keyValue = {
        "教學": "Tutorial",
        "紀錄": "Record",
        "請下注": "Taruh Bet",
        "提醒": "Perhatian",
        "請先選擇射門方向再下注哦": "Mohon pilih arah tembakan terlebih dahulu, baru pilih jumlah bet",
        "下注": "Bertaruh",
        "選擇注額": "Pilih jumlah bet",
        "選擇射門方向與倍數": "Pilih arah & jumlah kelipatan",
        "射門下注": "Tembak & Bertaruh",
        "點擊螢幕繼續>>": "Klik di layar untuk melanjutkan >>"
    };

    LocalizedString.Football = function (str) {
        return USE_i18n ? (keyValue[str] || str) : str;
    };
})();
