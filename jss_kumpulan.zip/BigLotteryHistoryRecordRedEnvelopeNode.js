/**
 * [9T] 幸運彩票各期紀錄紅包node
 */

var BigLotteryRecordRedEnvelopeNode = cc.Node.extend({
    ctor: function (type) {
        this._super();

        this._param = {};
        this._param.type = type;
        this._param.data = type === BigLotteryHistoryRecordLayer.pageType.RED_ENVELOPE ?
            DataModal.bigLotteryData.historyParam.envelopeHistoryList : DataModal.bigLotteryData.historyParam.luckyHistoryList;

        this._totalCellCount = 0;   // table view cell 數量

        // 紅色背景
        var redBgSprite = new ccui.Scale9Sprite("bigLottery_bg_redLine02.png");
        redBgSprite.setPreferredSize(cc.size(360, 20));
        redBgSprite.setPosition(JSScreenMidPos.x + 16, JSVisibleSize.height - 108);
        this.addChild(redBgSprite);

        // Domino移植設定 調整描邊/位移
        // table view上方條
        var titleStrings = type === BigLotteryHistoryRecordLayer.pageType.RED_ENVELOPE ? ["彩票開獎日", "開獎號碼", "中獎人數"] : ["幸運數字期號", "幸運數字號碼", "中獎人數"];
        titleStrings = titleStrings.map(string => LocalizedString.BigLottery(string));
        var posX = [JSScreenMidPos.x - 110, JSScreenMidPos.x + 10, JSScreenMidPos.x + 125];
        for (var i = 0; i < 3; i++) {
            var label = new cc.LabelTTF(titleStrings[i], JSFontName, 10);
            label.enableStroke(cc.color(190, 30, 0, 255), 2);
            label.setFontFillColor(JSColor.YELLOW);
            label.setPosition(posX[i], JSVisibleSize.height - 108);
            this.addChild(label);
        }

        // TableView
        var tableViewSize = cc.size(380, 170 + JSScreenBonusHeight);
        var mainLayer = this._mainLayer = new cc.Layer();
        var tableView = this._tableView = new cc.TableView(this, tableViewSize, mainLayer);
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setPositionX(JSScreenMidPos.x - 180);
        this.addChild(tableView);

        // 刷新畫面
        this._refreshView();
    },

    /**
     * 刷新畫面
     */
    _refreshView: function () {
        // 抓資料
        if (this._param.data.length) {
            // 把資料記起來
            var historyList = this._historyList = this._param.data;

            // 刷新table view
            this._totalCellCount = historyList.length;
            this._tableView.reloadData(true);
        }
    },

    /**
     * TableView delegate
     */

    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        // 創cell
        if (cell == null) {
            cell = new BigLotteryHistoryRecordCell(true);
            cell.setAnchorPoint(0, 0);
        }

        // 刷新cell
        var historyList = this._historyList;
        if (historyList && idx < historyList.length) {
            var param = historyList[idx];
            cell.refreshCell(param, idx === historyList.length - 1);
        }

        return cell;
    },

    numberOfCellsInTableView: function (table) {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function (table, idx) {
        return cc.size(BigLotteryHistoryRecordCell.WIDTH, BigLotteryHistoryRecordCell.HEIGHT);
    }
});