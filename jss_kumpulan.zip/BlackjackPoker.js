/**
 * 21點的牌
 */
var BlackjackPoker = PokerCardNode.extend({
    ctor: function () {
        this._super();
    },

    /**
     * 翻轉牌
     */
    turnCard: function (number, callback) {
        var scaleSize = this.getScaleY();
        var scaleTime = 0.15;

        var self = this;
        this.runAction(cc.sequence(
            cc.scaleTo(scaleTime, 0, scaleSize),
            cc.callFunc(function () {
                // 開始出現牌
                self.setCardNumber(number);

                self.runAction(cc.sequence(
                    cc.scaleTo(scaleTime, scaleSize),
                    cc.callFunc(function () {
                        callback && callback();
                    })
                ));
            })
        ));

        // 撥放音樂
        Vegas_MusicUtility.playEffect("Music/Effect/turn_river.mp3");
    },

});