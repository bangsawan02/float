class DebugUtils {
    static tryGetClassName(object) {
        let constructorName = Object.keys(window)
            .find(key => window[key] === object || window[key] === object.constructor);
        return constructorName ?? object.constructor.name;
    }
}