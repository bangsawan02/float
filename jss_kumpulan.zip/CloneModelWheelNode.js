/**
 * v5.6.1 分身模組 - 轉盤獎勵轉盤 移植中撲 16.7
 */

var CloneModelWheelNode = BaseWheelNode.extend({
    ctor: function () {
        var cloneModelData = DataModal.cloneModelData;

        // 舊的獎勵們
        this._rewardArray = cloneModelData.infoParam.wheelList;

        // 新的獎勵們
        this._newRewardArray = cloneModelData.rechargeParam ? cloneModelData.rechargeParam.wheelList : [];

        // 中獎的index
        this._rewardIndex = cloneModelData.rechargeParam ? cloneModelData.rechargeParam.hit : -1;

        // 速度快一點
        this._wheelSpeed = 6;

        // 至少轉5圈
        this._wheelTargetRotate = 5;

        this._super();

        this.setCascadeColorEnabled(true);
    },

    /**
     * 生成轉盤
     */
    _initWheel: function () {
        // 框框
        for (var i = 0; i < 2; i++) {
            var frameSp = new cc.Sprite("#cloneModel_pic_wheel_frame.png");
            frameSp.setFlippedX(i);
            frameSp.setAnchorPoint(i, 0.5);
            frameSp.setPosition((i ? 0.2 : -0.2), 0);
            this.addChild(frameSp, 2);
        }

        // 用來指向的框框
        var arrowSp = new cc.Sprite("#cloneModel_pic_wheel_frame_02.png");
        arrowSp.setPosition(0, 55);
        this.addChild(arrowSp, 2);

        // 轉盤容器
        var wheelContainer = this._wheelContainer;

        // 各色不相鄰的盤面
        var posArray = [4, 3, 2, 1, 2, 3, 2, 1];

        this._rewardContentArray = [];
        // 轉輪內的東西
        this._rewardNodeArray = posArray.map((rewardNum, index) => {
            var rewardNode = new cc.Node();
            rewardNode.setRotation(index * 45);
            rewardNode.setCascadeColorEnabled(true);
            wheelContainer.addChild(rewardNode);

            // 獎項背景
            var rewardBg = new cc.Sprite(JSStringUtility.format("#cloneModel_pic_wheel_0%d.png", rewardNum));
            rewardBg.setAnchorPoint(0.5, 0);
            rewardBg.setPosition(0, 0);
            rewardNode.addChild(rewardBg);

            var reward = this._rewardArray[index];
            var imageUrl = TexasUtility.getItemImageUrl(reward.pic);
            var savePath = JSWriteablePath + "shop/" + reward.pic + ".png";
            var rewardSp = new GSDownloadSprite("", imageUrl, savePath);
            rewardSp.setTargetSize(cc.size(38, 38));
            rewardSp.setPosition(0, 83);
            rewardNode.addChild(rewardSp);

            // 獎項數量
            var rewardNumber = new cc.LabelTTF(this._rewardArray[index].txt, JSFontBoldName, 9);
            rewardNumber.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            rewardNumber.enableStroke(cc.color(55, 30, 5), 2);
            rewardNumber.setPositionY(55);
            this._rewardContentArray.push({rewardSp: rewardSp, rewardNumber: rewardNumber});
            rewardNode.addChild(rewardNumber);

            if (index === 0) {
                GSSpine.create("spine/cloneModel/ani_wheel_vfx", 0.25, (spine) => {
                    spine.setAnimation(0, 'ani_01', true);
                    rewardNode.addChild(spine);
                });
            }

            return rewardNode;
        });

        var center = new cc.Sprite("#cloneModel_pic_wheel_center.png");
        this.addChild(center, 3);

        // 燈泡們
        var bulbPosArray = [];
        for (var i = 0; i < 15; ++i) {
            bulbPosArray.push(cc.p(Math.cos(i * 30 / 180 * Math.PI) * 118, Math.sin(i * 30 / 180 * Math.PI) * 118))
        }
        Texas_AnimationUtility.createBulbLightAnimation(this, bulbPosArray, "cloneModel_pic_wheel_light_02.png", "cloneModel_pic_wheel_light_01.png", 3);
    },

    _spinBtnClicked: function (sender) {
        this._super(sender);

        // 計算轉盤最終位置
        this._targetRotation = 360 * this._wheelTargetRotate + this._rewardIndex * -45;

        this._rewardNodeArray.forEach(node => node.setColor(JSColor.WHITE));
    },

    // 給外部一個旋轉的機會
    spineClicked: function (sender) {
        this._spinBtnClicked(sender);
    },

    refreshRewardAsync: function () {
        return new Promise((resolve) => {
            if (this.__isDestroyed)
                return;

            var delayValue = [0, 0.2, 0.4, 0.6, 0.8, 0.9, 1, 1.1];
            this._rewardNodeArray.map((cur, index) => {
                cur.runAction(cc.sequence(
                    cc.delayTime(delayValue[index]),
                    cc.callFunc(() => {
                        GSSpine.create("spine/cloneModel/ani_wheel_vfx", 0.25, (spine) => {
                            spine.setAnimation(0, 'ani_02', true);
                            spine.setCompleteListener(() => {
                                // 移除自己
                                spine.removeFromParent();
                            });
                            cur.addChild(spine, 10);
                        });
                    })
                ));

                this._rewardContentArray[index].rewardSp.runAction(cc.sequence(
                    cc.delayTime(delayValue[index]),
                    cc.scaleTo(0.2, 0.5, 1),
                    cc.scaleTo(0.2, 1, 1)
                ));

                this._rewardContentArray[index].rewardNumber.runAction(cc.sequence(
                    cc.delayTime(delayValue[index]),
                    cc.scaleTo(0.2, 0.1, 1),
                    cc.callFunc(() => {
                        this._rewardContentArray[index].rewardNumber.setString(this._newRewardArray[index].txt);
                    }),
                    cc.scaleTo(0.2, 1, 1),
                    cc.callFunc(() => index === 7 ? resolve() : undefined)
                ));
            });
        });
    }
});