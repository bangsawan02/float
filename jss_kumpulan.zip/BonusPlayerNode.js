/**
 * Bonus機台 玩家 Node
 */
var BonusPlayerNode = cc.Node.extend({
    ctor: function () {
        this._super();
        this.playerData = null;
        this.playerIdx = 0;

        // 大頭照
        var mainNode = new cc.Node();
        mainNode.setScale(0.8);
        mainNode.setCascadeOpacityEnabled(true);
        this.addChild(mainNode);

        // 照片 要切成圓形
        var stencilSprite = new cc.Sprite("#lobby_photo_clip.png");
        var clipNode = new cc.ClippingNode(stencilSprite);
        clipNode.setAlphaThreshold(0.5);
        clipNode.setCascadeOpacityEnabled(true);
        mainNode.addChild(clipNode);

        // 玩家大頭貼
        var photoSize = cc.size(56, 56);
        var headPhoto = this._headPhoto = new PhotoSprite("", photoSize.width, photoSize.height);
        headPhoto.setHaveBackgroundFrame(false);
        clipNode.addChild(headPhoto);

        // 點玩家大頭會出現詳細資訊
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        mainNode.addChild(menu, 100);

        var itemNode = ButtonUtility.createEmptyNodes(photoSize);
        var btn = new cc.MenuItemSprite(itemNode[0], itemNode[1], this._headPhotoBtnClicked, this);
        btn.setPosition(headPhoto.getPosition());
        menu.addChild(btn);

        // 配件
        var accessoryItemBtn = this._accessoryItemBtn = new PlayerAccessoryNode(null);
        accessoryItemBtn.setScale(0.55);
        accessoryItemBtn.setPosition(-26, -18);
        this.addChild(accessoryItemBtn);

        // 玩家暱稱
        var nickNameLabel = this._nickNameLabel = new GSAutoSizeLabel("", JSFontName, 12, cc.size(50, 16), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        nickNameLabel.resizeToFit(6);
        nickNameLabel.setPosition(0, 31);
        this.addChild(nickNameLabel);

        // 錢的底
        var moneyBg = new ccui.Scale9Sprite("lobby_pic_square_black.png");
        moneyBg.setPreferredSize(cc.size(50, 12));
        moneyBg.setPosition(0, -32);
        this.addChild(moneyBg);

        // 玩家金錢數量
        var moneyLabel = this._moneyLabel = new GSNumberLabel("0", JSFontName, 11, cc.size(50, 16), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        moneyLabel.setUseCurrencyString(true);
        moneyLabel.resizeToFit(5);
        moneyLabel.setPosition(0, -32);
        this.addChild(moneyLabel);

        // 玩家倒數外框
        var countDownNode = this._countDownNode = new BonusCountdownNode();
        countDownNode.setVisible(false);
        this.addChild(countDownNode, -1);

        // 用來顯示贏牌的動畫
        var winTitleSp = this._winTitleSp = new cc.Sprite();
        winTitleSp.setPosition(0, 31);
        winTitleSp.setVisible(false);
        this.addChild(winTitleSp);

        this.setScale(0.9);
    },

    clean: function () {
        if (!this.playerData)
            return;

        this._nickNameLabel.setString(this.playerData.nickname);
        this._countDownNode.stop();
    },

    /**
     * 更新玩家大頭貼
     */
    refreshImage: function () {
        if (this.playerData) {
            var param = this.playerData;

            // 大頭照
            this._headPhoto.setDefaultSprite(param.isMale ? "photo_male.png" : "photo_female.png");

            // 判斷是否有被禁言
            var photoURL = param.photoURL;
            if (DataModal.blacklistData.isAccountInList(param.account))
                photoURL = "";
            this._headPhoto.setPhotoUrlString(photoURL, param.account);
        }
    },

    /**
     * 更新玩家配件
     */
    _refreshAccessoryImage: function () {
        if (!this.playerData)
            return;

        var playerData = this.playerData;
        // 配件
        this._accessoryItemBtn.refresh(playerData);
    },

    /**
     * 玩家暱稱及獲勝圖輪播動畫
     */
    _switchBonusWinAni: function (cardList) {
        this._winTitleSp.setVisible(false);

        this._nickNameLabel.setFontFillColor(cc.color(255, 214, 11));
        this._nickNameLabel.setString(this._convertBonusWinString(cardList));
        this._nickNameLabel.runAction(cc.sequence(
            cc.delayTime(1.5),
            cc.fadeOut(0.3),
            cc.callFunc(() => {
                this._nickNameLabel.setString(this.playerData.nickname);
                this._nickNameLabel.setFontFillColor(JSColor.WHITE);
            }),
            cc.fadeIn(0.3)
        ));
    },

    /**
     * 轉換獲勝牌型文字
     * @return {string}
     */
    _convertBonusWinString: function (cardList) {
        var retStr;
        if (cardList[1][1] === "1") {
            // 只有當第二張牌是A的時候才會在前面
            retStr = BonusSetting.convertAceAndTen(cardList[1]) + BonusSetting.convertAceAndTen(cardList[0]);
        } else {
            retStr = BonusSetting.convertAceAndTen(cardList[0]) + BonusSetting.convertAceAndTen(cardList[1]);
        }

        var bonusStr = LocalizedString.Bonus;
        switch (this._bonusType) {
            case 0:
            case 4:
            case 6:
                retStr += bonusStr("一對");
                break;
            case 1:
            case 2:
                retStr += bonusStr("同花");
                break;
            case 3:
            case 5:
                retStr += bonusStr("非同花");
                break;
            default:
                break;
        }

        return retStr.concat(" " + JSStringUtility.format("%d %s", this._bonusRate, bonusStr("倍")));
    },

    /**
     * 設定玩家資料
     * @param {Object}  playerData  玩家資料
     */
    setPlayerData: function (playerData) {
        if (playerData) {
            this.playerData = playerData;
            this.refreshImage();
            this._refreshAccessoryImage();
            this._nickNameLabel.setString(playerData.nickname);
        }
    },

    /**
     * 取得玩家表情位置
     * @return {cc.Point}
     */
    getPlayerEmoPos: function () {
        return cc.p(this.pos.x + 26, this.pos.y + 15);
    },

    /**
     * 設定玩家金錢數量
     * @param {Number}  money   玩家金錢數量
     */
    setPlayerMoney: function (money) {
        if (this.playerData)
            this.playerData.money = money;
        this._moneyLabel.setToNumber(money);
    },

    /**
     * 設定玩家位置
     * @param {cc.p} pos 玩家位置
     */
    setPlayerPosition: function (pos) {
        this.pos = pos;         // 額外記下來
        this.setPosition(pos);
    },

    /**
     * 設定玩家的index
     * @param {Number} idx 玩家的index
     */
    setPlayerIdx: function (idx) {
        this.playerIdx = idx;
    },

    /**
     * 玩家倒數框開始倒數
     * @param {Number} time 玩家倒數時間
     */
    startClock: function (time) {
        this.stopClock();
        this._countDownNode.start(time, this.playerData.isMe);
    },

    /**
     * 玩家倒數框停止倒數
     */
    stopClock: function () {
        this._countDownNode.stop();
    },

    /**
     * 顯示玩家入桌動畫
     */
    showJoinTableAni: function () {
        // 瞄準圖
        var enterSp = new cc.Sprite("#bonus_player_point.png");
        enterSp.setOpacity(0);
        enterSp.setScale(0.05);
        this.addChild(enterSp, 10);

        // 動畫
        enterSp.runAction(cc.sequence(
            cc.spawn(
                cc.repeat(cc.rotateBy(3.5, 360), 2),
                cc.sequence(
                    cc.delayTime(0.5),
                    cc.spawn(
                        cc.fadeIn(0.3),
                        cc.scaleTo(0.3, 1)
                    ),
                    cc.delayTime(3),
                    cc.spawn(
                        cc.fadeOut(0.3),
                        cc.scaleTo(0.3, 0.05)
                    )
                )
            ),
            cc.removeSelf()
        ));
    },

    /**
     * 顯示Bonus獲勝輪播動畫
     * @param rate      贏的倍率
     * @param type      贏的種類
     * @param cardList  牌
     */
    showBonusWinAni: function (rate, type, cardList) {
        this._bonusRate = rate;
        this._bonusType = type;
        this._nickNameLabel.setString("");

        // 換圖
        this._winTitleSp.setSpriteFrame("bonus_word_win.png");
        this._winTitleSp.setVisible(true);
        this._winTitleSp.setOpacity(255);
        this._winTitleSp.stopAllActions();
        // 淡出動畫
        this._winTitleSp.runAction(cc.sequence(
            cc.fadeOut(0.3),
            cc.callFunc(() => this._switchBonusWinAni(cardList))
        ));
    },

    /**
     * 顯示一般獲勝動畫
     */
    showWinAni: function () {
        this._nickNameLabel.setOpacity(0);

        if (this._winBg)
            this._winBg.setVisible(true);
        else {
            this._winBg = new cc.Sprite("#bonus_bet_winning_card_circle.png");
            this._winBg.setScale(0.99);
            this.addChild(this._winBg, -1);
        }

        this._winTitleSp.setSpriteFrame("bonus_word_line_winner.png");
        this._winTitleSp.runAction(cc.sequence(
            cc.show(),
            cc.fadeIn(0.1),
            cc.fadeOut(0.5),
            cc.callFunc(() => {
                this._nickNameLabel.runAction(cc.fadeIn(0.2));
                this._winBg.setVisible(false);
            }),
            cc.hide()
        ));
    },

    /**
     * 點擊事件
     */

    /**
     * 點擊玩家大頭貼，跳出玩家資訊
     */
    _headPhotoBtnClicked: function () {
        this.unschedule(this._headPhotoBtnClicked);

        var playerData = DataModal.playerProfileData.getPlayerProfileDataByAccount(this.playerData.account);
        if (playerData) {
            playerData.isHideBackpackTab = true;
            var profileDialog = new ProfileDialog(this.playerData.account);
            profileDialog.setCloseCallback(() => playerData.isHideBackpackTab = false);
            DialogManager.addDialog(profileDialog);
        } else {
            DataModal.playerProfileData.checkAccountNeedRefresh(this.playerData.account);
            this.schedule(this._headPhotoBtnClicked, 0, 0, 0.5);
        }
    }
});