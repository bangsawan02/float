/**
 * v5.5.2 分身模組 - 主視窗
 * created by Jim.chen
 */

var CloneModelMainDialog = BaseDialogLayer.extend({
    ctor: function (whereType) {
        // 先做繼承的東西
        this._super();

        this.key = "CloneModelMainDialog";
        this.dialogBgColor = cc.color(0, 0, 0, 240);

        this._whereType = whereType;

        this.loadFileArray = [
            "cloneModel/cloneModel.plist", "cloneModel/cloneModel.png",
            SelectGameManager.getNowGameFile("cloneModel.plist", "cloneModel/"), SelectGameManager.getNowGameFile("cloneModel.png", "cloneModel/")
        ];

        TestMenu.delegate(this);
    },

    onExit: function () {
        // 砍素材
        if (this._loadFileDone) {
            for (let i = 0; i < this.loadFileArray.length; i += 2)
                cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[i]);
        }

        this._super();
    },

    loadFileDone: function () {
        this._super();

        // 讀素材
        for (let i = 0; i < this.loadFileArray.length; i += 2) {
            cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[i], this.loadFileArray[i + 1]);
        }

        var aniLayer = this._animationLayer;

        // 放畫面的Node
        this._mainNode = new cc.Node();
        aniLayer.addChild(this._mainNode);

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.setPosition(490 + JSScreenBonusHalfWidth, 266 + JSScreenBonusHalfHeight);
        closeBtn.addTouchUpInsideAction(this._closeDialogAnimation, this);
        aniLayer.addChild(closeBtn);

        // 加Loading
        this.addLoadingLayer();

        // 註冊
        GS.addListener("NotifyPlanReplacementInfoDone", this.notifyPlanReplacementInfoDone.bind(this), this);
        GS.addListener("NotifyCloseCloneMainDialog", this.notifyCloseCloneMainDialog.bind(this), this);

        // 去要資料
        DataModal.cloneModelData.startGetInfo();
    },

    onEnter: function () {
        this._super();

        // 埋點 4: 進入介面
        DataProcess.sendString("track_plan_replacement 4");
    },

    /**
     * 跳活動結束視窗
     */
    _showEventOverDialog: function () {
        // 活動結束
        var dialog = new Dialog({
            content: LocalizedString.Purchase("活動已結束"),
            closeButton: false,
            callback: () => {
                this._closeDialogAnimation();
            }
        });
        dialog.startDialogAnimation();
        this._animationLayer.addChild(dialog, 1000);
    },

    _refreshView: function () {
        this.removeLoadingLayer();

        var mainNode = this._mainNode;
        mainNode.removeAllChildren();

        var infoParam = this._infoParam = DataModal.cloneModelData.infoParam;
        if (!DataModal.cloneModelData.isEventOpen() || !infoParam.isSuccess) {
            // 跳活動結束視窗
            this._showEventOverDialog();
            return;
        }

        // 準備背景所需東西
        var bgSize = cc.size(512, 288);
        var imageSavePath = JSStringUtility.format("%sCloneModel/%s", JSWriteablePath, infoParam.img);
        var imageUrl = JSStringUtility.format("%s/%s/%s", infoParam.baseUrl, GS.resourcesFolder, infoParam.img);

        // 判斷是圖片還是GAF
        if (imageUrl.indexOf(".zip") === imageUrl.length - 4) {
            // 卡loading
            this.addLoadingLayer();

            // 是GAF的檔案
            var fileName = imageUrl.split("/").pop();
            var fileNameNoExt = fileName.substring(0, fileName.indexOf(".zip"));

            var entryFile = JSStringUtility.format("%s/%s.gaf", fileNameNoExt, fileNameNoExt);
            gaf.createAndDownloadWithBundle(imageUrl, imageSavePath, entryFile, this, (gafAsset) => {
                // 假如此畫面不見 跳掉
                if (this.__isDestroyed)
                    return;

                if (gafAsset) {
                    var gafObject = gafAsset.createObjectAndRun(true);
                    // 因為美術設計尺寸是HD，但是我們的設計尺寸是SD所以要除2
                    var sceneSize = cc.size(gafAsset.getSceneWidth() / 2, gafAsset.getSceneHeight() / 2);
                    gafObject.setScaleX(bgSize.width / sceneSize.width);
                    gafObject.setScaleY(bgSize.height / sceneSize.height);
                    gafObject.setPosition(JSScreenMidPos);
                    mainNode.addChild(gafObject, -1);
                }

                this.removeLoadingLayer();
            });
        } else {
            // 卡loading
            this.addLoadingLayer();

            // 是圖片
            var bgSprite = new GSDownloadSprite("", imageUrl, imageSavePath, (msg) => {
                // 解掉loading
                this.removeLoadingLayer();

                // 載圖有問題
                if (msg) {
                    DialogManager.addDialog(new Dialog({
                        content: LocalizedString.Common("系統忙碌中，請稍後再試！"),
                        callback: () => {
                            this._closeDialogAnimation();
                        }
                    }), false);
                }
            });
            bgSprite.setTargetSize(bgSize);
            bgSprite.setPosition(JSScreenMidPos);
            mainNode.addChild(bgSprite);
        }

        // 倒數時間+背景的Node
        var countdownAreaNode = new cc.Node();
        countdownAreaNode.setPosition(460 + JSScreenBonusHalfWidth, 16 + JSScreenBonusHalfHeight);
        mainNode.addChild(countdownAreaNode);

        // 黑底
        var blackBgSp = new ccui.Scale9Sprite("lobby_pic_black.png");
        blackBgSp.setPreferredSize(cc.size(80, 16));
        countdownAreaNode.addChild(blackBgSp);

        // 水平排版:時鐘Icon + 倒數時間
        var timeLayoutNode = new GSAutoLayoutNode();
        timeLayoutNode.setSpace(2);

        // 時鐘Icon
        var clockSp = new cc.Sprite("#lobby_pic_clock_02.png");
        clockSp.setScale(0.5);
        timeLayoutNode.addChild(clockSp);

        // 活動倒數時間
        var countdownLabel = new GSTimeLabel("", JSFontBoldName, 9);
        countdownLabel.setMultiFormat("%dd Hari", "%hh:%mm:%ss", "%hh:%mm:%ss");
        countdownLabel.countdownSeconds(DataModal.cloneModelData.getRemainTime(), () => {
            countdownAreaNode.setVisible(false);

            // 關掉說明頁面
            this._webInfoDialog && this._webInfoDialog.closeDialogAnimation();

            // 跳活動結束視窗
            this._showEventOverDialog();
        }, (seconds) => {
            // 時間格式改變，刷新排版
            if (seconds === 86399)
                timeLayoutNode.refresh();
        });
        timeLayoutNode.addChild(countdownLabel);
        countdownAreaNode.addChild(timeLayoutNode);

        // 去儲值按鈕，有縮放動畫
        var aniTime = 0.75;
        var goPurchaseBtnSize = GS.isLuxyPoker ? cc.size(84, 39) : cc.size(79, 37);
        var goPurchaseBtn = new Texas_Button(Texas_Button.Style.YELLOW, goPurchaseBtnSize, LocalizedString.Purchase("馬上獲得（分身模組）"), JSColor.WHITE, 11);
        goPurchaseBtn.addTouchUpInsideAction(this._goPurchaseBtnClicked, this);
        goPurchaseBtn.setPosition(256 + JSScreenBonusHalfWidth, 40 + JSScreenBonusHalfHeight);
        goPurchaseBtn.runAction(cc.sequence(
            cc.scaleTo(aniTime, 1.1),
            cc.scaleTo(aniTime, 1)
        ).repeatForever());
        mainNode.addChild(goPurchaseBtn);

        // 說明按鈕
        var explainBtn = new Texas_ExplainButton();
        explainBtn.setPosition(20 + JSScreenBonusHalfWidth, 266 + JSScreenBonusHalfHeight);
        explainBtn.addTouchUpInsideAction(this._explainBtnClicked, this);
        mainNode.addChild(explainBtn);

        // 籌碼顯示Node
        var rewardChipsNode = new CloneModelRewardChipsNode(this._whereType);
        rewardChipsNode.setPosition(438 + JSScreenBonusHalfWidth, 45 + JSScreenBonusHalfHeight);
        rewardChipsNode.setMainNodeScale(0.5);
        rewardChipsNode.setClickEnabled(true);
        mainNode.addChild(rewardChipsNode);

        // 如果從儲值中心打開，直接跳轉盤介面
        if (this._whereType === CloneModelIconNode.WhereType.PURCHASE_LAYER_IN_LOBBY || this._whereType === CloneModelIconNode.WhereType.PURCHASE_LAYER_IN_GAME) {
            let isShownBefore = !!this._wheelAwardDialog;

            if (this._wheelAwardDialog) {
                // 已經跳過，直接移除，不跑關閉動畫
                this._wheelAwardDialog.removeFromParent();
            }

            let dialog = this._wheelAwardDialog = rewardChipsNode.createWheelAwardDialog(true);

            // 若已經顯示過，不跑開啟動畫
            dialog.openNeedAnimation = !isShownBefore;
            DialogManager.addDialog(dialog, false);
        }
    },

    /**
     * 按鈕
     */
    /**
     * 去儲值按鈕點擊
     */
    _goPurchaseBtnClicked: function () {
        // 埋點 5: 點馬上儲值
        DataProcess.sendString("track_plan_replacement 5");

        // 關掉視窗
        this._closeDialogAnimation();

        // 引導儲值中心
        if (this._whereType === CloneModelIconNode.WhereType.LOBBY) {
            PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
        }
    },

    /**
     * 說明按鈕點擊
     */
    _explainBtnClicked: function () {
        if (!this._infoParam)
            return;

        var infoParam = this._infoParam;
        var url = TexasUtility.getSimpleInfoURLByKey("plan_replacement", ["skin=" + infoParam.skinType, "plan_money=" + infoParam.planMoneyStr]);
        var webInfoDialog = this._webInfoDialog = new WebViewDialog(url);
        webInfoDialog.setCloseCallback(() => {
            this._webInfoDialog = undefined;
        });
        DialogManager.addDialog(webInfoDialog, false);
    },

    /**
     * 監聽
     */

    /**
     * 收到活動資訊
     */
    notifyPlanReplacementInfoDone: function () {
        this._refreshView();
    },

    /**
     * 通知關閉
     */
    notifyCloseCloneMainDialog: function (event) {
        const param = event?.getUserData();
        const isAnimeEnabled = param?.isAnimeEnabled ?? true;

        if (isAnimeEnabled) {
            this._closeDialogAnimation();
        } else {
            this.removeFromParent();
        }
    },

    createDebugTestObject: function () {
        return new TestMenuDebugObject("分身模組", {
            "info": () => DataProcess.sendCustomStringToSelf('plan_replacement_info {"group":"1","banner_img":"3_1_0.png","banner_url":"https://v.mwsrv.com/texas9/store/9T_Billbanner/VN_Banner/poker","wheel_list":[{"pic":"5005","txt":"7,5M"},{"pic":"7086","txt":"25"},{"txt":"20","pic":"7086"},{"pic":"5005","txt":"4,5M"},{"txt":"4M","pic":"5005"},{"pic":"7086","txt":"15"},{"pic":"5005","txt":"1,5M"},{"txt":"1","pic":"7109"}],"success":"1","progress_total":"3","user_progress":"0","skin":"3","plan_money":"0","cluster":"0"}'),
            "info 2枚硬幣": () => DataProcess.sendCustomStringToSelf('plan_replacement_info {"group":"1","banner_img":"3_1_0.png","banner_url":"https://v.mwsrv.com/texas9/store/9T_Billbanner/VN_Banner/poker","wheel_list":[{"pic":"5005","txt":"7,5M"},{"pic":"7086","txt":"25"},{"txt":"20","pic":"7086"},{"pic":"5005","txt":"4,5M"},{"txt":"4M","pic":"5005"},{"pic":"7086","txt":"15"},{"pic":"5005","txt":"1,5M"},{"txt":"1","pic":"7109"}],"success":"1","progress_total":"3","user_progress":"2","skin":"3","plan_money":"0","cluster":"0"}'),
            "info 3枚硬幣": () => DataProcess.sendCustomStringToSelf('plan_replacement_info {"group":"1","banner_img":"3_1_0.png","banner_url":"https://v.mwsrv.com/texas9/store/9T_Billbanner/VN_Banner/poker","wheel_list":[{"pic":"5005","txt":"7,5M"},{"pic":"7086","txt":"25"},{"txt":"20","pic":"7086"},{"pic":"5005","txt":"4,5M"},{"txt":"4M","pic":"5005"},{"pic":"7086","txt":"15"},{"pic":"5005","txt":"1,5M"},{"txt":"1","pic":"7109"}],"success":"1","progress_total":"3","user_progress":"3","skin":"3","plan_money":"0","cluster":"0"}'),
            "recharge": () => DataProcess.sendCustomStringToSelf('plan_replacement_recharge_done {"hit":"7","progress_reward":{"count":"1","pic":"7109"},"wheel_list":[{"pic":"5005","txt":"15M"},{"txt":"50","pic":"7086"},{"pic":"7086","txt":"40"},{"pic":"5005","txt":"9M"},{"pic":"5005","txt":"8M"},{"txt":"30","pic":"7086"},{"pic":"5005","txt":"3M"},{"txt":"1","pic":"7109"}],"success":"1","user_progress":"3","reward_msg":["1M Chip","30 Đá Quý","Phiếu Xì Dách Online 1 Phiếu","Phiếu Tài Xỉu Online 1 Phiếu","Phiếu Bầu Cua Online 1 Phiếu","Phiếu Baccarat Online 1 Phiếu"]}'),
        });
    },
});