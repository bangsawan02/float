/**
 * 通行證 - 一般獎勵 Cell node
 * config: {
 *     tableViewCellSize: cc.size(0, 0),                    // 使用 TableView 普通獎勵的 cell size
 *     tableViewNodeClass: BasePassNormalRewardNode,        // 獎勵 item node 的 class
 *     tableViewCellGap: 0,                                 // 豪華 or 免費獎勵與中心點的距離
 *     goalLabelOffset: cc.p(0, 0),                         // 目標代幣數量標籤位置偏移量
 *     isUseThreePassSystem: false,                         // 是否使用三通行證系統（兩付費一免費）
 *     tableViewCellGapThreePass: 5,                        // 三通行證系統中獎勵與中心點的距離
 *     normalRewardNodeFreeYOffset: 0                       // free Node 的偏移量
 *     normalRewardNodeLuxuryYOffset: 0                     // luxury Node 的偏移量
 *     normalRewardNodeSuperYOffset: 0                      // super Node 的偏移量
 * }
 */
var BasePassNormalRewardCellNode = cc.Node.extend({
    ctor: function (config) {
        this._super();

        this._config = config;

        let cellSize = config.tableViewCellSize || BasePassRewardCell.NormalRewardCellSize;
        this._nodeClass = config.tableViewNodeClass || BasePassNormalRewardNode;
        this._isUseThreePassSystem = config.isUseThreePassSystem || false;
        this._cellGap = this._isUseThreePassSystem ? (config.tableViewCellGapThreePass || 5) : (config.tableViewCellGap || 10);
        this._goalLabelOffset = config.goalLabelOffset || cc.p(0, -6);

        this._midPos = cc.p(cellSize.width / 2, cellSize.height / 2);

        if (JSDebugMode) {
            this._debugComponents = [];
            let debugDrawNode = this._debugDrawNode = new cc.DrawNode();
            this.addChild(debugDrawNode, 1);
            this._debugComponents.push(debugDrawNode);
        }

        this._createGoalLabel();
        this._createFreeItemNode();
        this._createLuxuryItemNode();

        // 新增超級豪華獎勵節點（僅在三通行證系統中）
        if (this._isUseThreePassSystem) {
            this._createSuperItemNode();
        }
    },

    _createGoalLabel: function () {
        let goalLabel = this._goalLabel = new BasePassGoalLabel(this._config);
        goalLabel.setPosition(cc.pAdd(this._midPos, this._goalLabelOffset));
        this.addChild(goalLabel, 1);
    },

    _createFreeItemNode: function () {
        let goalLabelPos = cc.pAdd(this._midPos, this._goalLabelOffset);
        let freeItem = this._freeRewardNode = new this._nodeClass(this._config, false, true, BasePassNormalRewardNode.Where.TABLE_VIEW, 0);
        freeItem.setAnchorPoint(0.5, 1);
        let yOffset = this._config.normalRewardNodeFreeYOffset || 0;

        if (this._isUseThreePassSystem) {
            // 三通行證系統：免費獎勵在最下方
            freeItem.setPosition(goalLabelPos.x, goalLabelPos.y - this._cellGap * 2 + yOffset);
        } else {
            // 原始系統：免費獎勵在下方
            freeItem.setPosition(goalLabelPos.x, goalLabelPos.y - this._cellGap + yOffset);
        }
        this.addChild(freeItem);

        JSDebugMode && this._debugDrawNode.drawDot(freeItem.getPosition(), 4, cc.color(255, 0, 0, 128));
    },

    _createLuxuryItemNode: function () {
        let goalLabelPos = cc.pAdd(this._midPos, this._goalLabelOffset);
        let luxuryItem = this._luxyRewardNode = new this._nodeClass(this._config, true, true, BasePassNormalRewardNode.Where.TABLE_VIEW, 1);
        luxuryItem.setAnchorPoint(0.5, 0.5);
        let yOffset = this._config.normalRewardNodeLuxuryYOffset || 0;

        if (this._isUseThreePassSystem) {
            // 三通行證系統：豪華獎勵在中間
            luxuryItem.setPosition(goalLabelPos.x, goalLabelPos.y + yOffset);
        } else {
            // 原始系統：豪華獎勵在上方
            luxuryItem.setAnchorPoint(0.5, 0);
            luxuryItem.setPosition(goalLabelPos.x, goalLabelPos.y + this._cellGap + yOffset);
        }
        this.addChild(luxuryItem);

        JSDebugMode && this._debugDrawNode.drawDot(luxuryItem.getPosition(), 4, cc.color(255, 0, 0, 128));
    },

    _createSuperItemNode: function () {
        let goalLabelPos = cc.pAdd(this._midPos, this._goalLabelOffset);
        let superItem = this._superRewardNode = new this._nodeClass(this._config, true, true, BasePassNormalRewardNode.Where.TABLE_VIEW, 2);
        superItem.setAnchorPoint(0.5, 0);
        let yOffset = this._config.normalRewardNodeSuperYOffset || 0;

        // 超級豪華獎勵在最上方
        superItem.setPosition(goalLabelPos.x, goalLabelPos.y + this._cellGap + yOffset);
        this.addChild(superItem);

        JSDebugMode && this._debugDrawNode.drawDot(superItem.getPosition(), 4, cc.color(0, 255, 0, 128));
    },

    /**
     * 更新畫面
     * @param {object}  stageParam          階段資料
     * @param {int}     currentTokenCount   目前擁有的代幣數量
     * @protected
     */
    refreshView: function (stageParam, currentTokenCount) {
        // 目標的數量
        this._goalLabel.setString(stageParam.goal);
        this._goalLabel.setFinish(currentTokenCount >= stageParam.goal);

        // 刷新獎勵的部分
        this._freeRewardNode.refreshByData(stageParam, currentTokenCount);
        this._luxyRewardNode.refreshByData(stageParam, currentTokenCount);

        // 如果啟用了三通行證系統，則更新超級獎勵
        if (this._isUseThreePassSystem && this._superRewardNode) {
            this._superRewardNode.refreshByData(stageParam, currentTokenCount);
        }

        JSDebugMode && this._debugComponents.forEach(node => node.setVisible(this._config.isShowDebugPoints));
    },

    /**
     * 播放解鎖動畫
     * @param {number|number[]} [passTypes] 指定要播放解鎖動畫的通行證層級
     *                                      - 不帶參數: 保持舊行為，全部播放
     *                                      - 傳入 BasePassType 或其陣列: 僅播放指定層
     */
    playUnlockAnimation: function (passTypes) {
        // 舊版相容：未指定時，全部播放
        if (passTypes === undefined || passTypes === null) {
            this._freeRewardNode.playUnlockAnimation();
            this._luxyRewardNode.playUnlockAnimation();

            // 如果啟用了三通行證系統，則播放超級獎勵解鎖動畫
            if (this._isUseThreePassSystem && this._superRewardNode) {
                this._superRewardNode.playUnlockAnimation();
            }
            return;
        }

        // 正規化為陣列
        let list = Array.isArray(passTypes) ? passTypes : [passTypes];

        // 逐層播放
        if (list.indexOf(BasePassType.FREE) !== -1) {
            this._freeRewardNode && this._freeRewardNode.playUnlockAnimation();
        }
        if (list.indexOf(BasePassType.LUXURY) !== -1) {
            this._luxyRewardNode && this._luxyRewardNode.playUnlockAnimation();
        }
        if (this._isUseThreePassSystem && this._superRewardNode && list.indexOf(BasePassType.SUPER) !== -1) {
            this._superRewardNode.playUnlockAnimation();
        }
    }
});