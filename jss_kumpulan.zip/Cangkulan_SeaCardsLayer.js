/**
 * Cangkulan 桌上洗牌 & 要發的牌
 */
var Cangkulan_SeaCardsLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 發牌音效ID
        this._shuffleAudioID = -1;

        this._washPos = cc.pAdd(JSScreenMidPos, Cangkulan_Offset.WASH);
    },

    /**
     * 加入要發的牌
     */
    _addSeaCard: function (playerNum) {
        this._sendCardArray = [];
        var startNum = Cangkulan_DeawDrawStackCount;
        var sendCard = Cangkulan_DeawDrawStackCount + Cangkulan_DealCount;
        for (var i = startNum; i < sendCard; i++) {
            for (var j = 0; j < playerNum; j++) {
                var cardNode = new PokerCardNode();
                cardNode.setCardIsInBack(true);
                cardNode.setPosition(this._washPos.x, this._washPos.y + i * 0.4);
                this.addChild(cardNode);

                this._sendCardArray.push(cardNode);
            }
        }

        // 顯示抽牌區疊好的牌
        GS.dispatchCustomEvent("NotifyShowDrawCards");
    },

    /**
     * 洗牌
     * @returns {Promise<any>}
     */
    shuffleAsync: function (playerNum) {
        return new Promise((resolve, reject) => {
            if (this.__isDestroyed) {
                return reject();
            }

            // 播放發牌音效
            this._shuffleAudioID = MusicUtility.playEffect("Music/Effect/cangkulan_dealCard.mp3");

            var self = this;
            gaf.create("gaf/game/remi_shuffle.gaf", this, true, function (asset) {
                var gafObject = asset.createObjectAndRun(false);
                gafObject.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 10);
                self.addChild(gafObject, 1);
                // 設定播完動畫後的事
                gafObject.runAction(cc.sequence(
                    cc.delayTime(0.8),
                    cc.callFunc(() => {
                        // 產生要發出去的牌
                        self._addSeaCard(playerNum);
                        resolve();
                    }),
                    cc.removeSelf()
                ));
            });
        });
    },

    /**
     * 開始把發牌
     * @param sendPosArray  要發給哪幾家
     */
    startDealAsync: function (dealerPos, sendPosArray, handCards) {
        return new Promise((resolve, reject) => {
            if (this.__isDestroyed) {
                return reject();
            }

            // 先記下來是否有自己
            this._selfPlaying = !!handCards;

            var sendPosLen = sendPosArray.length;
            var totalCards = sendPosLen * Cangkulan_DealCount;
            var selfCardCount = 0;
            var nowCount = 0;
            var handCardScaleArray = [this._selfPlaying ? 1 : 0.5, 0.5, 0.5, 0.5];
            var handCardPosArray = [
                this._selfPlaying ? 0 : Cangkulan_GameUtility.getDealCardPosition(0),
                Cangkulan_GameUtility.getDealCardPosition(1),
                Cangkulan_GameUtility.getDealCardPosition(2),
                Cangkulan_GameUtility.getDealCardPosition(3),
            ];

            this.runAction(cc.repeat(cc.sequence(
                cc.callFunc(function () {
                    // 算現在的位置
                    var nowLen = (dealerPos + nowCount) % sendPosLen;
                    var direction = sendPosArray[nowLen];

                    // 把最後一張牌取出來
                    var cardNode = this._sendCardArray.pop();

                    // 判斷要送去哪
                    var toPos;
                    if (direction === 0 && this._selfPlaying) {
                        // 自己的手牌
                        var handPos = cc.p(JSScreenMidPos.x - 3 * Cangkulan_HandCardOffsetX, Cangkulan_HandCardPosY);
                        toPos = cc.pAdd(handPos, cc.p(selfCardCount * Cangkulan_HandCardOffsetX, 0));
                    } else {
                        // 沒有自己在的手牌
                        toPos = cc.pAdd(handCardPosArray[direction], cc.p(selfCardCount * 3, selfCardCount * 2));
                    }

                    // 發送到各家
                    var moveTime = 0.2;
                    var isLast = nowCount === totalCards - 1;
                    cardNode && cardNode.runAction(cc.sequence(
                        cc.spawn(
                            cc.moveTo(moveTime, toPos),
                            cc.rotateBy(moveTime, 360),
                            cc.scaleTo(moveTime, handCardScaleArray[direction])
                        ),
                        cc.callFunc(function () {
                            if (direction === 0 && this._selfPlaying) {
                                // 自己的手牌 創一個牌出來
                                var obj = {
                                    card: handCards[selfCardCount],
                                    isFold: false
                                };
                                GS.dispatchCustomEvent("NotifyShowHandCards", obj);
                                selfCardCount++;
                            } else {
                                // 通知PlayerLayer去加手牌
                                var playerNum = DataModal.gameData.getServerDirectionByDirection(direction);
                                GS.dispatchCustomEvent("NotifyAddPlayerHandCard", playerNum);
                            }

                            // 如果是最後的牌 要resolve掉
                            if (isLast) {
                                // 中斷發牌音效
                                if (this._shuffleAudioID != -1) {
                                    MusicUtility.stopEffect(this._shuffleAudioID);
                                    this._shuffleAudioID = -1;
                                }
                                resolve();
                            }
                        }, this),
                        cc.removeSelf()
                    ));

                    // 個數++
                    nowCount++;
                }, this),
                cc.delayTime(0.1)
            ), totalCards));
        });
    }
});