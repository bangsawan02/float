/**
 * Bonus 遊戲狀態
 * @type {{BET_ANTE: number, FLOP_START: number, BET_BONUS: number, RIVER_START: number, TURN_START: number}}
 */
var BonusStateType = {
    BET_ANTE: 0,
    BET_BONUS: 1,
    FLOP_START: 2,
    TURN_START: 3,
    RIVER_START: 4
};

/**
 * Bonus設定
 * 目前只有德撲有
 * Voice是用到Vegas_MusicUtility
 */
var BonusSetting = {
    convertAceAndTen: function (cardNumber) {
        if (cardNumber[1] === "T")
            return "10";
        else if (cardNumber[1] === "1")
            return "A";

        return cardNumber[1];
    },

    /**
     * 轉換文字
     * @param {Number}  type
     * @param {String}  hand
     * @param {Boolean} isMeWin
     * @return {String}
     */
    convertHandToText: function (type, hand, isMeWin) {
        var cardType, cardNum;
        var bonusStr = LocalizedString.Bonus;
        // type參照socket回傳, 0=烏龍, 1=一對, 2=兩對, 3=三條, 4=順子, 5=同花, 6=葫蘆, 7=鐵支, 8=同花順
        switch (type) {
            case 0 :
                cardType = bonusStr("高牌");
                cardNum = this.convertAceAndTen(hand[4]);
                if (isMeWin)
                    Vegas_MusicUtility.playVoice("highCardWin.mp3");
                break;
            case 1 :
                cardType = bonusStr("一對");
                cardNum = this.convertAceAndTen(hand[0]);
                if (isMeWin)
                    Vegas_MusicUtility.playVoice("onePairWin.mp3");
                break;
            case 2 :
                cardType = bonusStr("兩對");
                cardNum = JSStringUtility.format("%s,%s", this.convertAceAndTen(hand[0]), this.convertAceAndTen(hand[3]));
                if (isMeWin)
                    Vegas_MusicUtility.playVoice("twoPairWin.mp3");
                break;
            case 3 :
                cardType = bonusStr("三條");
                cardNum = this.convertAceAndTen(hand[0]);
                if (isMeWin)
                    Vegas_MusicUtility.playVoice("threeKindWin.mp3");
                break;
            case 4 :
                cardType = bonusStr("順子");
                cardNum = JSStringUtility.format("%s~%s", this.convertAceAndTen(hand[0]), this.convertAceAndTen(hand[4]));
                if (isMeWin)
                    Vegas_MusicUtility.playVoice("straightWin.mp3");
                break;
            case 5 :
                cardType = bonusStr("同花");
                cardNum = this.convertAceAndTen(hand[4]);
                if (isMeWin)
                    Vegas_MusicUtility.playVoice("flushWin.mp3");
                break;
            case 6 :
                cardType = bonusStr("葫蘆");
                cardNum = this.convertAceAndTen(hand[0]);
                if (isMeWin)
                    Vegas_MusicUtility.playVoice("fullHouseWin.mp3");
                break;
            case 7 :
                cardType = bonusStr("四條");
                cardNum = this.convertAceAndTen(hand[0]);
                if (isMeWin)
                    Vegas_MusicUtility.playVoice("fourKindWin.mp3");
                break;
            case 8 :
                cardType = bonusStr("同花順");
                cardNum = JSStringUtility.format("%s~%s", this.convertAceAndTen(hand[0]), this.convertAceAndTen(hand[4]));
                if (isMeWin)
                    Vegas_MusicUtility.playVoice("straightFlushWin.mp3");
                break;
            case 9 :
                cardType = bonusStr("同花大順");
                cardNum = JSStringUtility.format("%s~%s", this.convertAceAndTen(hand[0]), this.convertAceAndTen(hand[4]));
                if (isMeWin)
                    Vegas_MusicUtility.playVoice("royalFlushWin.mp3");
                break;
            default:
                break;
        }

        return JSStringUtility.format("%s(%s)%s", cardType, cardNum, bonusStr("獲勝"));
    }
};
