/**
 * Created by terry on 2021/7/1.
 * 德撲輪播的東西, 是淡出淡入的輪播,
 * warning:child必須是CarouselItemNode及其子類別
 */
var CarouselNode = cc.Node.extend({
    ctor: function (isAutoRun = true) {
        this._super();

        // 表演清單
        this._showList = [];

        // 當前播放到誰
        this._currentIndex = 0;

        // 畫面要停留多久
        this._stayDurationTime = 2;

        // 是不是要自動跑
        this._isAutoRun = isAutoRun;

        // act的tag
        this._carouselActTag = 9596;

        // 淡出淡入時間
        this._fadeTime = 0.5;
    },

    /**
     * override
     */
    addChild: function () {
        this._super.apply(this, arguments);

        this.refresh();
    },

    // 設定東西停在畫面上的時間
    setStayDurationTime: function (time) {
        this._stayDurationTime = time;
    },

    // 設定淡出淡入時間
    setFadeTime: function (time) {
        this._fadeTime = time;
    },

    // 設定更新後是不是自動跑
    setIsAutoRun: function (isAutoRun) {
        this._isAutoRun = isAutoRun;
    },

    // 開始輪播
    startCarousel: function (startWithIndex) {
        this.stopCarousel();

        this._doCarousel(startWithIndex);
    },

    // 停止輪播,isStayCurrentCondition畫面是不是要停在最後一個顯示的物件
    stopCarousel: function (isStayCurrentCondition) {
        this.stopAllActions();
        this.getChildren().forEach(cur => {
            cur.stopActionByTag(this._carouselActTag);
            cur.setOpacity(0);
            cur.setVisible(false);
        });

        // 顯示他
        if (isStayCurrentCondition) {
            var node = this._showList[this._currentIndex];
            node.setOpacity(255);
            node.setVisible(true);
        }
    },

    /**
     * 給外部call的 強制重整畫面
     */
    refresh: function () {
        this.stopAllActions();
        var children = this.getChildren();
        var childrenLen = children.length;
        if (childrenLen === 0)
            return;

        this._showList = [];

        // 檢查有出現的再加進表演清單
        children.forEach(cur => {
            cur.stopActionByTag(this._carouselActTag);

            if (cur.isNeedToCarousel) {
                this._showList.push(cur);
                cur.setOpacity(0);
                cur.setVisible(false);
            }
        });

        // 有自動輪播
        if (this._isAutoRun)
            this._doCarousel();
    },

    // 跑輪播
    _doCarousel: function (startWithIndex) {
        this.stopAllActions();
        this._currentIndex = startWithIndex || 0;

        if (this._showList.length) {
            // 只有一人不需要輪播
            if (this._showList.length === 1) {
                var node = this._showList[0];
                node.setOpacity(255);
                node.setVisible(true);
            } else {
                // 把換index擺在 delayTime後面比較正確(當前在跑的動畫)
                this.runAction(cc.sequence(
                    cc.callFunc(() => {
                        var actNode = this._showList[this._currentIndex];
                        actNode.setOpacity(0);
                        this._doFadeAnimation(actNode);
                    }),
                    cc.delayTime(this._fadeTime * 2 + this._stayDurationTime),
                    cc.callFunc(() => {
                        this._currentIndex = (this._currentIndex + 1) % this._showList.length;
                    })).repeatForever());
            }
        }
    },

    // 做淡出淡入動畫
    // 開觸碰->眼動畫->關觸碰
    _doFadeAnimation: function (node) {
        var act = cc.sequence(
            cc.show(),
            cc.fadeIn(this._fadeTime),
            cc.delayTime(this._stayDurationTime),
            cc.fadeOut(this._fadeTime),
            cc.hide()
        );
        act.setTag(this._carouselActTag);
        node.runAction(act);
    }
});
