/**
 * Bonus機台 籌碼 Layer
 */
var BonusChipsLayer = cc.Layer.extend({
    CHIP_MOVE_TIME: 0.6,
    CHIP_MERGE_TIME: 0.3,

    ctor: function () {
        this._super();

        this._playerChips = [];
        this._dealerChips = [];

        this.clean();
    },

    /**
     * 清空畫面
     */
    clean: function () {
        this._anteBet = 0;
        this._bonusBet = 0;
        this._isAnteWin = false;
        this._passStatus = {};
        this._playerWin = -1;

        this._initPlayerChip();
        this._initDealerChip();
    },

    /**
     * 清空玩家籌碼
     */
    _removePlayerChips: function () {
        this._playerChips.forEach(cur => cur && cur.removeFromParent());
        this._playerChips = [];
    },

    /**
     * 清空莊家籌碼
     */
    _removeDealerChips: function () {
        this._dealerChips.forEach(cur => cur && cur.removeFromParent());
        this._dealerChips = [];
    },

    /**
     * 回收Bonus籌碼
     */
    _returnBonusWin: function (winRate) {
        var mergePos = cc.p(240 + JSScreenBonusHalfWidth, 44 + JSScreenBonusHalfHeight);
        var aniTime = this.CHIP_MOVE_TIME;

        if (this._bonusBet !== 0 && winRate > 0) {
            this._dealerChips[4].runAction(cc.moveTo(aniTime, mergePos).easing(cc.easeExponentialOut()));
            //需要加回之前拿掉的下注的bonus籌碼才是正確的數字
            this.runAction(cc.sequence(cc.delayTime(aniTime), cc.callFunc(() => this.removeBonusChip())));
            if (this._playerChips[4].isVisible()) {
                this._playerChips[4].runAction(cc.moveTo(aniTime, mergePos).easing(cc.easeExponentialOut()));
                Vegas_MusicUtility.playEffect("Music/Effect/chippool.mp3");
            }
        } else {
            // 如果Bonus沒贏的話一律回收
            this._playerChips[4].runAction(cc.moveTo(aniTime * 2, cc.p(240 + JSScreenBonusHalfWidth, JSVisibleSize.height * 1.1)).easing(cc.easeExponentialOut()));
            this.runAction(cc.sequence(cc.delayTime(aniTime * 2), cc.callFunc(() => this.removeBonusChip())));
        }
    },

    /**
     * 將所有籌碼合成一個
     */
    _mergeChips: function () {
        var mergePos = JSScreenMidPos;

        var mergeChip = this._mergeChip = new BonusChipNode();
        mergeChip.setPosition(mergePos);
        mergeChip.setVisible(false);
        this.addChild(mergeChip, 1);

        this._calculateMergeChipValue();

        if (this._playerWin > -1) {
            // Bonus不用
            this._playerChips.slice(0, 4).forEach(cur => cur.runAction(cc.moveTo(this.CHIP_MERGE_TIME, mergePos)));
            this._dealerChips.slice(0, 4).forEach(cur => cur.runAction(cc.moveTo(this.CHIP_MERGE_TIME, mergePos)));
        } else {
            this._playerChips.slice(0, 4).forEach(cur => cur.runAction(cc.moveTo(this.CHIP_MERGE_TIME, mergePos)));
        }

        this.runAction(cc.sequence(
            cc.delayTime(this.CHIP_MERGE_TIME + 0.1),
            cc.callFunc(() => this._displayMergeChip())
        ));
    },

    /**
     * 計算所有籌碼合成後的金額
     */
    _calculateMergeChipValue: function () {
        var value = 0;
        var playerWin = this._playerWin;
        var passStatus = this._passStatus;

        if (playerWin === 1) {
            // 玩家贏
            value += this._playerChips[0].chipValue;
            if (this._isAnteWin) {
                value += this._playerChips[0].chipValue;
            }
            // Flop一定會下, 也一定會贏
            value += this._playerChips[1].chipValue * 2;
            if (!passStatus["bonus_turn"])
                value += this._playerChips[2].chipValue * 2;
            if (!passStatus["bonus_river"])
                value += this._playerChips[3].chipValue * 2;
        } else if (playerWin === 0) {
            // 平手
            value += this._playerChips[0].chipValue;
            value += this._playerChips[1].chipValue;
            if (!passStatus["bonus_turn"])
                value += this._playerChips[2].chipValue;
            if (!passStatus["bonus_river"])
                value += this._playerChips[3].chipValue;
        } else {
            // 玩家輸
            value += this._playerChips[0].chipValue;
            if (!passStatus["bonus_flop"]) {
                value += this._playerChips[1].chipValue;
            } else {
                if (!passStatus["bonus_turn"])
                    value += this._playerChips[2].chipValue;
                if (!passStatus["bonus_river"])
                    value += this._playerChips[3].chipValue;
            }
        }
        this._mergeChip.setChipValue(value);
    },

    /**
     * 顯示所有籌碼合成的一個籌碼
     */
    _displayMergeChip: function () {
        this._mergeChip.setVisible(true);
        this.removeAllChips();

        var mergePos, aniTime;
        if (this._playerWin > -1) {
            mergePos = cc.p(240 + JSScreenBonusHalfWidth, 28 + JSScreenBonusHalfHeight);
            aniTime = this.CHIP_MOVE_TIME;
        } else {
            mergePos = cc.p(236 + JSScreenBonusHalfWidth, JSVisibleSize.height * 1.1);
            aniTime = this.CHIP_MOVE_TIME * 2;
        }

        this.runAction(cc.sequence(
            cc.delayTime(this.CHIP_MOVE_TIME / 2),
            cc.callFunc(() => {
                this._mergeChip.runAction(cc.moveTo(aniTime, mergePos).easing(cc.easeExponentialOut()));
                this.runAction(cc.sequence(cc.delayTime(aniTime), cc.callFunc(() => this._removeMergeChip())));
                Vegas_MusicUtility.playEffect("Music/Effect/chippool.mp3");
            })
        ));
    },

    /**
     * 移除合成後的籌碼
     */
    _removeMergeChip: function () {
        this._mergeChip.removeFromParent();
        this._mergeChip = null;
    },

    /**
     * 玩家棄牌
     */
    playerFold: function () {
        var endPos = cc.p(240 + JSScreenBonusHalfWidth, JSVisibleSize.height * 1.1);
        var aniTime = this.CHIP_MOVE_TIME;

        this._playerChips[0].runAction(cc.moveTo(aniTime * 2, endPos).easing(cc.easeExponentialOut()));
        if (this._bonusBet !== 0)
            this._playerChips[4].runAction(cc.moveTo(aniTime * 2, endPos).easing(cc.easeExponentialOut()));

        this.runAction(cc.sequence(cc.delayTime(aniTime * 2), cc.callFunc(() => this.removeAllChips())));
    },

    /**
     * init玩家bet的籌碼
     */
    _initPlayerChip: function () {
        this._removePlayerChips();

        // 依序是 底注、翻牌、轉牌、河牌、BONUS
        for (var i = 0; i < 5; i++) {
            var chip = this._playerChips[i] = new BonusChipNode();
            chip.setVisible(false);
            chip.setPosition(236 + JSScreenBonusHalfWidth, 54 + JSScreenBonusHalfHeight);
            this.addChild(chip);
        }
    },

    /**
     * init莊家付給玩家的籌碼
     */
    _initDealerChip: function () {
        this._removeDealerChips();

        // 依序是 底注、翻牌、轉牌、河牌、BONUS
        for (var i = 0; i < 5; i++) {
            var chip = this._dealerChips[i] = new BonusChipNode();
            chip.setVisible(false);
            chip.setPosition(230 + JSScreenBonusHalfWidth, 260 + JSScreenBonusHalfHeight);
            this.addChild(chip);
        }
    },

    /**
     * 移除Bonus籌碼
     */
    removeBonusChip: function () {
        this._playerChips[4] && this._playerChips[4].removeFromParent();
        this._playerChips[4] = null;
        if (!this._passStatus["bonus_flop"]) {
            this._dealerChips[4] && this._dealerChips[4].removeFromParent();
            this._dealerChips[4] = null;
        }
    },

    /**
     * 移除所有籌碼
     */
    removeAllChips: function () {
        this._removePlayerChips();
        if (!this._passStatus["bonus_flop"]) {
            this._removeDealerChips();
        }
    },

    /**
     * 放置玩家籌碼的動作
     */
    placePlayerChip: function (gameState, bet, callback) {
        if (bet === 0) {
            // 如果是flop表示棄牌，不播放check音效
            gameState !== BonusStateType.FLOP_START && Vegas_MusicUtility.playEffect("Music/Effect/check.mp3");
            callback && callback();
            return;
        }

        var chipNode, pos;
        // 依照不同的GameState來處理
        switch (gameState) {
            case BonusStateType.BET_ANTE:
                this._anteBet = bet;
                // AnteChip
                chipNode = this._playerChips[0];
                pos = cc.pAdd(BonusTableLayer.BET_PLACEMENT_POS_ARRAY[0], cc.p(0, 0.5));
                break;

            case BonusStateType.BET_BONUS:
                this._bonusBet = bet;

                // BonusChip
                chipNode = this._playerChips[4];
                chipNode.changeToBonus();
                pos = cc.pAdd(BonusTableLayer.BET_PLACEMENT_POS_ARRAY[4], cc.p(0.5, -4));
                break;

            case BonusStateType.FLOP_START:
                // FlopChip
                chipNode = this._playerChips[1];
                pos = cc.pAdd(BonusTableLayer.BET_PLACEMENT_POS_ARRAY[1], cc.p(0, 0.5));
                break;

            case BonusStateType.TURN_START:
                // TurnChip
                chipNode = this._playerChips[2];
                pos = cc.pAdd(BonusTableLayer.BET_PLACEMENT_POS_ARRAY[2], cc.p(0, 0.5));
                break;

            case BonusStateType.RIVER_START:
                // TurnChip
                chipNode = this._playerChips[3];
                pos = cc.pAdd(BonusTableLayer.BET_PLACEMENT_POS_ARRAY[3], cc.p(0, 0.5));
                break;
            default:
                return;
        }

        chipNode.setVisible(true);
        chipNode.setChipValue(bet);
        chipNode.runAction(cc.sequence(
            cc.moveTo(this.CHIP_MOVE_TIME, pos).easing(cc.easeExponentialOut()),
            cc.callFunc(() => {
                callback && callback();
            })
        ));
        Vegas_MusicUtility.playEffect("Music/Effect/chipone.mp3");
    },

    checkBonusBet: function (bet, winRate) {
        // 因為server吐的數字是連同下注的總total, 所以要扣掉自己壓的那一份
        bet -= this._bonusBet;
        if (this._dealerChips[4] && bet > 0 && winRate > 0) {
            this._dealerChips[4].changeToBonus();
            this._dealerChips[4].setVisible(true);
            this._dealerChips[4].setChipValue(bet);
            this._dealerChips[4].runAction(cc.moveTo(this.CHIP_MOVE_TIME * 2, cc.p(300 + JSScreenBonusHalfWidth, 132 + JSScreenBonusHalfHeight)).easing(cc.easeExponentialOut()));
            Vegas_MusicUtility.playEffect("Music/Effect/chipwin.mp3");
        }

        this.runAction(cc.sequence(
            cc.delayTime(this.CHIP_MOVE_TIME * 3),
            cc.callFunc(() => this._returnBonusWin(winRate))
        ));
    },

    cmd_bonus_showdown: function (playerWin, passStatus, isAnteWin) {
        this._playerWin = playerWin;
        this._isAnteWin = isAnteWin;
        this._passStatus = passStatus;

        if (playerWin === 1) {
            // 玩家贏
            this._placeDealChip();
            Vegas_MusicUtility.playEffect("Music/Effect/light_ring.mp3");
        }

        this.runAction(cc.sequence(
            cc.delayTime(this.CHIP_MOVE_TIME * 3),
            cc.callFunc(() => this._mergeChips())
        ));
    },

    /**
     * 放置莊家的籌碼
     */
    _placeDealChip: function () {
        var passStatus = this._passStatus;
        if (!passStatus["bonus_flop"]) {
            // FlopChip
            this._dealerChips[1].setVisible(true);
            this._dealerChips[1].setChipValue(this._anteBet * 2);
            this._dealerChips[1].runAction(cc.moveTo(this.CHIP_MOVE_TIME * 2, cc.p(212 + JSScreenBonusHalfWidth, 156 + JSScreenBonusHalfHeight)).easing(cc.easeExponentialOut()));
            if (!passStatus["bonus_turn"]) {
                // TurnChip
                this._dealerChips[2].setVisible(true);
                this._dealerChips[2].setChipValue(this._anteBet);
                this._dealerChips[2].runAction(cc.moveTo(this.CHIP_MOVE_TIME * 2, cc.p(241 + JSScreenBonusHalfWidth, 156 + JSScreenBonusHalfHeight)).easing(cc.easeExponentialOut()));
            }
            if (!passStatus["bonus_river"]) {
                // RiverChip
                this._dealerChips[3].setVisible(true);
                this._dealerChips[3].setChipValue(this._anteBet);
                this._dealerChips[3].runAction(cc.moveTo(this.CHIP_MOVE_TIME * 2, cc.p(270 + JSScreenBonusHalfWidth, 156 + JSScreenBonusHalfHeight)).easing(cc.easeExponentialOut()));
            }
        }

        if (this._isAnteWin) {
            // AnteChip
            this._dealerChips[0].setVisible(true);
            this._dealerChips[0].setChipValue(this._anteBet);
            this._dealerChips[0].runAction(cc.moveTo(this.CHIP_MOVE_TIME * 2, cc.p(246 + JSScreenBonusHalfWidth, 130 + JSScreenBonusHalfHeight)).easing(cc.easeExponentialOut()));
        }
    }
});