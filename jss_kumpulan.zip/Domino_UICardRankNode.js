var Domino_UICardRankNode = cc.Layer.extend({
    ctor: function () {
        this._super();

        this._isShowing = false;                // 現在是否出現了

        var cardRankParams = [
            {   // Six Devil 都是六
                title: "Six Devil",
                content: "Semua nilai kartu\nmenjadi 6. Kartu spesial\nyang terbesar.",
                cards: ["06", "15", "24", "33"]
            },
            {   // Twin Cards 都是對子
                title: "Twin Cards",
                content: "Nilai kartu di atas sama\ndengan yang di bawah\nsemuanya.",
                cards: ["00", "11", "22", "44"]
            },
            {   // Small Card 小牌 加起來小於9的牌
                title: "Small Cards",
                content: "Nilai total kartu semuan\nya menjadi kurang dari\natau sama dengan 9.",
                cards: ["00", "01", "02", "03"]
            },
            {   // Big Cards 大牌 加起來大於39的牌
                title: "Big Cards",
                content: "Nilai total 39 atau lebih.\n(0,0) bisa jadi 0/10 poin.",
                cards: ["66", "56", "55", "46"]
            },
            {   // Qiu Qiu 前後兩個加起來是9的牌
                title: "Qiu Qiu",
                content: "Nilai total kartu di sebelah\nkiri dan kanan sama-sama\nmenjadi 9.",
                cards: ["04", "05", "66", "16"]
            },
            {   // Kartu Biasa 普通的牌
                title: "Kartu Biasa",
                content: "Kartu yang bukan\nkartu spesial.",
                cards: ["03", "13", "24", "01"]
            },

        ];

        var bgSize = this._bgSize = cc.size(186, JSVisibleSize.height);

        var container = this._container = new cc.Node();
        container.setCascadeOpacityEnabled(true);
        container.setPosition(-bgSize.width, 0);
        container.setVisible(false);
        this.addChild(container);

        // 背景
        var bgSprite = this._bgSprite = new ccui.Scale9Sprite("game_bg_option.png");
        bgSprite.setPreferredSize(bgSize);
        bgSprite.setAnchorPoint(cc.p(0, 0));
        container.addChild(bgSprite);

        // 選單列背景光
        var lightSprite = new cc.Sprite("#game_bg_white_light.png");
        lightSprite.setScaleX(4);
        lightSprite.setScaleY(8);
        lightSprite.setPosition(bgSize.width / 2, bgSize.height / 2);
        container.addChild(lightSprite);

        // 開始排版
        var totalLen = cardRankParams.length;
        var eachHeight = bgSize.height / totalLen;                  // 每一格的高度
        var basePosY = JSVisibleSize.height - eachHeight / 2;       // 最上面那格的Y
        for (var i = 0; i < totalLen; i++) {
            var cardRankParam = cardRankParams[i];
            var thisPosY = basePosY - eachHeight * i;

            // 排牌
            cardRankParam.cards.forEach(function (cur, index) {
                var cardNode = new Domino_CardNode(cur);
                cardNode.setCardIsInBack(false);
                cardNode.setPosition(14 + 20 * index, thisPosY);
                container.addChild(cardNode);
            });

            // 文字 Title
            var titleLabel = new cc.LabelTTF(cardRankParam.title, JSFontName, 11);
            titleLabel.setFontFillColor(cc.color(255, 153, 0));
            titleLabel.setAnchorPoint(0, 0.5);
            titleLabel.setPosition(87, thisPosY + 14);
            container.addChild(titleLabel, 1);

            // 文字 內容
            var contentLabel = new cc.LabelTTF(cardRankParam.content, JSFontName, 7, cc.size(0, 0), cc.TEXT_ALIGNMENT_LEFT, cc.VERTICAL_TEXT_ALIGNMENT_TOP);
            contentLabel.setAnchorPoint(0, 1);
            contentLabel.setPosition(87, thisPosY + 7);
            container.addChild(contentLabel, 1);

            // 下面要加線
            if (i < totalLen - 1) {
                var lineSprite = new cc.Sprite("#lobby_pic_function_line.png");
                lineSprite.setPosition(bgSize.width / 2, thisPosY - eachHeight / 2);
                lineSprite.setRotation(90);
                lineSprite.setScaleY(4);
                container.addChild(lineSprite);
            }
        }

        //加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this._onTouchBegan.bind(this)
        }, this);

        // 注冊通知
        GS.addListener("NotifyGameUIShowCardRankLayer", this.notifyGameUIShowCardRankLayer.bind(this), this);
        GS.addListener("NotifyGameUICloseCardRankLayer", this.notifyGameUICloseCardRankLayer.bind(this), this);
    },

    /**
     * 展開牌型
     */
    show: function () {
        if (this._isShowing)
            return;

        this._isShowing = true;

        var container = this._container;
        container.setVisible(true);
        container.stopAllActions();
        container.runAction(cc.moveTo(0.3, cc.p(0, 0)).easing(cc.easeBackOut()));
    },

    /**
     * 關閉牌型
     */
    close: function () {
        if (!this._isShowing)
            return;

        this._isShowing = false;

        var container = this._container;
        container.stopAllActions();
        container.runAction(cc.sequence(
            cc.moveTo(0.3, cc.p(-this._bgSize.width, 0)).easing(cc.easeBackIn()),
            cc.hide()
        ));
    },

    /**
     * 通知
     */
    // 出現牌型
    notifyGameUIShowCardRankLayer: function () {
        this.show();
    },

    // 關掉牌型
    notifyGameUICloseCardRankLayer: function () {
        this.close();
    },

    /**
     * Touch
     * @private
     */
    _onTouchBegan: function (touch, event) {
        var target = event.getCurrentTarget();
        if (!target.isVisible())
            return false;
        if (!this._container.isVisible())
            return false;

        for (var c = target.parent; c != null; c = c.parent) {
            if (!c.isVisible())
                return false;
        }

        var boundBox = this._bgSprite.getBoundingBox();
        var touchPos = this.convertToNodeSpace(touch.getLocation());
        if (!cc.rectContainsPoint(boundBox, touchPos)) {
            this.close();
        }
        return true;
    }
});