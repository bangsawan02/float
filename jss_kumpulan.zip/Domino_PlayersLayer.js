var Domino_PlayersLayer = cc.Layer.extend({

    ctor: function () {
        this._super();

        // 是否第一次坐下
        this._isFirstSitDown = true;

        // 每一個玩家 下注的總金額 不包含(ante)
        this._playerPotChips = [];

        // 所有玩家的大頭照內容物
        // 畫面位置自已是0，自已的左邊是1、右邊是6
        var players = this._players = [];
        var playerLen = DataModal.gameData.playerNumber;
        for (var serverSitNum = 0; serverSitNum < playerLen; serverSitNum++) {
            var player = new Domino_PlayerNode(serverSitNum);
            player.setPosition(Domino_GameUtility.getPlayerPosition(serverSitNum));
            player.setVisible(false);
            this.addChild(player);

            players.push(player);
        }

        // 注冊畫面的Players(單純為了方便找位置，別做其它事)
        DataModal.gameData.registerPlayersLayer(this._players);

        // 為了向右、向左轉 記下來前後的Player
        for (var i = 0; i < playerLen; i++) {
            var nowPlayer = players[i];
            nowPlayer.prevPlayer = players[(i - 1) < 0 ? playerLen - 1 : i - 1];
            nowPlayer.nextPlayer = players[(i + 1) % playerLen];
        }

        // 送籌碼的Layer 要放在這 因為要在手牌底下
        this._chipsLayer = new Domino_PlayerChipsLayer();
        this.addChild(this._chipsLayer, 2);

        // 自己的手牌
        var handCardNode = this._handCardSetNode = new Domino_CardSetNode();
        handCardNode.setPosition(296 + JSScreenBonusHalfWidth, 87 + JSScreenBonusHalfHeight);
        handCardNode.setIsSelfCard(true);
        this.addChild(handCardNode, 5);

        // 玩家的動畫, 因為要蓋在手牌上面 所以另外創一個
        this._playerAnimLayer = new Domino_PlayerAnimLayer();
        this.addChild(this._playerAnimLayer, 10);

        //註冊通知
        GS.addListener("NotifyConfirmCardDone", this.notifyConfirmCardDone.bind(this), this);
        GS.addListener("NotifyUpdateGameRankClass", this.notifyUpdateGameRankClass.bind(this), this);
        GS.addListener("NotifyRefreshIsForbidden", this.notifyRefreshIsForbidden.bind(this), this);
    },

    /**
     * 清掉所有資料 & 畫面
     */
    cleanData: function () {
        this._isFirstSitDown = true;

        for (var i = 0; i < this._players.length; i++) {
            this._players[i].stopAllActions();
            this._players[i].setPosition(Domino_GameUtility.getPlayerPosition(i));
            this._players[i].cleanData();
            this._players[i].setSitNum(i);
            this._players[i].serverSitNum = i;
        }

        this._handCardSetNode.cleanData();

        // 清掉籌碼
        this._chipsLayer.cleanData();
        this._playerPotChips = [];
    },

    /**
     * 清掉舊的一回合的籌碼記錄
     */
    cleanPlayerPotChips: function () {
        this._playerPotChips = [];
    },

    /**
     * 設定是否第一次坐下(換桌後設定false讓它有換桌動畫動)
     * @param value
     */
    setIsFirstSitDown: function (value) {
        this._isFirstSitDown = value;
    },

    /**
     *  所有Player向左 or 向右轉多少格. ex.turnAllPlayer(-2) 向右轉兩格；turnAllPlayer(3) 向左轉3格
     *  @param {value} 向左向右幾格
     *  @private
     */
    _turnAllPlayer: function (value) {
        var total = 0;
        var len = this._players.length;

        if (value != 0) {
            for (var i = 0; i < len; i++) {
                var nowPlayer = this._players[i];
                if (value < 0) {
                    nowPlayer.sitNumTmp = nowPlayer.prevPlayer.sitNum;
                } else if (value > 0) {
                    nowPlayer.sitNumTmp = nowPlayer.nextPlayer.sitNum;
                }
            }
            for (var i = 0; i < len; i++) {
                var nowPlayer = this._players[i];
                var pos = Domino_GameUtility.getPlayerPosition(nowPlayer.sitNumTmp);
                nowPlayer.setSitNum(nowPlayer.sitNumTmp);

                if (this._isFirstSitDown) {
                    // 第一次坐下 不做動畫
                    nowPlayer.setPosition(pos);
                    total++;
                    if (total === len) {
                        this._turnAllPlayer((value > 0) ? value - 1 : value + 1);
                    }
                } else {
                    //之後起立坐下才要做換位置的動畫
                    nowPlayer.stopAllActions();
                    nowPlayer.runAction(cc.sequence(
                        cc.moveTo(0.26, pos),
                        cc.callFunc(function () {
                            total++;
                            if (total === len) {
                                this._turnAllPlayer((value > 0) ? value - 1 : value + 1);
                            }
                        }, this)
                    ));
                }
            }
        } else {
            // 代表換完位了
            this._isFirstSitDown = false;
            for (var serverSitNum = 0; serverSitNum < DataModal.gameData.playerNumber; serverSitNum++) {
                DataModal.gameData.serverSitNum[this._players[serverSitNum].sitNum] = serverSitNum;

                var player = this._players[serverSitNum];
                // 撥放坐下是自己的動畫
                if (player.getIsSelf())
                    this._playerAnimLayer.playAnimation(serverSitNum, Domino_PlayerAnimNode.Type.SIT);

                // 重置倒數
                player.resetCountDown();
            }

            // 再次去抓取SocketCMD
            GS.dispatchCustomEvent("NotifyEnableProcessMessage");
            GS.dispatchCustomEvent("NotifyUpdateSitsInviteLayer");
        }

        // 要換 dealer & spotlight 的位置
        GS.dispatchCustomEvent("NotifyGameTurnPositionFinish");
        GS.dispatchCustomEvent("NotifyUpdateSitsInviteLayer");
    },

    /**
     * 玩家第一次進來會初始化目前玩家的狀態
     */
    processLastCmd: function () {
        for (var i = 0; i < DataModal.gameData.playerNumber; i++) {
            this._players[i].processLastCmd();
        }
    },

    /**
     * 更新狀態
     * @param haveMe 是否有自已, 要把位子橋到正前方
     */
    updateSeat: function (haveMe) {
        // 更新每個玩家基本資訊
        for (var i = 0; i < DataModal.gameData.playerNumber; i++) {
            var data = DataModal.gameData.playerDataArray[i];
            this._players[i].updateSeat(data);
        }

        // 有自已在坐位上的話，把自已放在坐位正前方
        var myPos = DataModal.gameData.myPos;
        if (haveMe && myPos >= 0 && myPos < DataModal.gameData.playerNumber) {
            var sitNum = DataModal.gameData.getDirectionByServerDirection(myPos);
            if (sitNum == 0) {
                this._isFirstSitDown = false;

                GS.dispatchCustomEvent("NotifyEnableProcessMessage");
                GS.dispatchCustomEvent("NotifyGameOpenCardAnalysisWhenTuneSeatFinished");
                GS.dispatchCustomEvent("NotifyUpdateSitsInviteLayer");
                return;
            }

            // 轉的時後先把倒數計時關掉
            for (var i = 0; i < DataModal.gameData.playerNumber; i++) {
                this._players[i].playCountDown(false);
            }
            if (sitNum <= 3) {
                // 1~4的位置向右
                this._turnAllPlayer(-sitNum);
            } else {
                // 其他位置向左
                this._turnAllPlayer(7 - sitNum);
            }
        } else {
            GS.dispatchCustomEvent("NotifyEnableProcessMessage");
        }
    },

    /**
     * 收到牌
     * @param serverPos
     * @param numberString 牌的號碼
     */
    addHandCard: function (serverPos, numberString) {
        if (!numberString)
            return;

        var sitNum = DataModal.gameData.getDirectionByServerDirection(serverPos);
        for (var i = 0; i < DataModal.gameData.playerNumber; i++) {
            var player = this._players[i];
            if (player.sitNum === sitNum) {
                // 是這位玩家
                if (player.getIsSelf() && numberString.length === 2) {
                    // 是自己 加手牌在自己身上
                    this._handCardSetNode.addCard(numberString, true);
                } else {
                    // 是其他玩加
                    player.addHandCard();
                }

                break;
            }
        }
    },

    /**
     * 倒數計時
     * @param serverSitNum  server的位置
     * @param delay         倒數幾秒收到Player指令
     */
    playerCountDown: function (serverSitNum, delay) {
        this._players[serverSitNum] && this._players[serverSitNum].playCountDown(true, delay);
    },

    /**
     * 取得玩每個玩家PlayerNode
     * @returns {Array}
     */
    getPlayers: function () {
        return this._players;
    },

    /**
     * 抓取自己手上牌的數量
     */
    getSelfHandCardCount: function () {
        return this._handCardSetNode.getCardCount();
    },

    /**
     * 設定現在玩家決定牌的狀態
     */
    setPlayerConfirmStatus: function (serverPos, status) {
        if (serverPos >= 0 && serverPos < DataModal.gameData.playerNumber)
            this._players[serverPos].setConfirmStatus(status);
    },

    /**
     * 下一局時，重設外觀
     */
    cmd_OLEH: function () {
        this._players.forEach(function (cur) {
            cur.cleanDisplayWhenOLEH();
            cur.refreshStatus(GAME_PLAYER_STATUS.UNKNOW);
        });

        // 把手牌清掉
        this._handCardSetNode.cleanData();

        // 把籌碼也清掉
        this._chipsLayer.cleanData();
        this._playerPotChips = [];
    },

    /**
     * 積分系統入坐動畫
     */
    cmd_showPlayerClass: function (value) {
        //   {
        //        "pos":"5",   #位置
        //        "dealerSay":"Selamat datang Aries Mo para pemain hebat di meja profesional", #荷官恭迎
        //        "userClass":{"score":"0","class":"0","ranking":"1"} #此玩家階級資料
        //   }
        var serverPos = value["pos"];               // GameLayer已經轉成數字了
        var player = this._players[serverPos];

        if (player && value.userClass) {
            var levelClass = JSCodeUtility.getIntValue(value.userClass["class"]);
            player.showFirstSitGameRankAnimation(levelClass);
        }
    },

    /**
     * 丟底注
     */
    cmd_ante: function (value) {
        // 直接給籌碼Layer處理
        this._chipsLayer.cmd_ante(value);
    },

    /**
     * Server幫運算的最佳手牌 要強制幫他換掉
     */
    cmd_BestCard: function (value) {
        // 直接丟到裡面處理
        this._handCardSetNode.cmd_BestCard(value);
    },

    /**
     * 收到這個command會決定玩家是否棄牌 || 選位下注(Fold)
     */
    cmd_last_cmd: function () {
        for (var serverSitNum = 0; serverSitNum < DataModal.gameData.playerNumber; serverSitNum++) {
            this._players[serverSitNum].refreshStatus();
        }
    },

    /**
     * 彩池金額
     */
    cmd_pot: function (value) {
        // 直接給籌碼Layer處理
        this._chipsLayer.setPot(value);

        // 順便清掉使用者上面上一個行為資訊 (棄牌不清)
        for (var i = 0; i < DataModal.gameData.playerNumber; i++) {
            var data = DataModal.gameData.playerDataArray[i];
            if (data.status != GAME_PLAYER_STATUS.FOLD) {
                data.status = GAME_PLAYER_STATUS.UNKNOW;
                if (data.getIsExist()) {
                    this._players[i].refreshStatus(data.status);
                }
            }
        }
    },

    /**
     * 站起
     */
    cmd_stand: function (serverSitNum) {
        var player = this._players[serverSitNum];

        // 判斷是否有這個玩家
        if (!player)
            return;

        if (player.getIsSelf() || !DataModal.gameData.haveMe) {
            // 把手牌拿掉
            this._handCardSetNode.cleanData();
        }

        player.cleanData();
    },

    /**
     * 更新每個人手上的籌碼
     */
    cmd_updateChips: function () {
        for (var i = 0; i < DataModal.gameData.playerNumber; i++) {
            var data = DataModal.gameData.playerDataArray[i];
            this._players[i].updateChips(data.tableChips);
            this._players[i].money = data.tableChips;
        }
    },

    /**
     * 更新每個人上面的配件
     * updateInfo [{"name_accessory":"Dewa%20Cinta","pic":"http://qq.mwsrv.com/texas9/images/default_pic/photo_m-2.png","name_medal":"","accessory":"3027","identity":"10000","name_identity":"Hide","medal":"8101"},{},{},{},{},{},{}]
     */
    cmd_updateInfo: function (value) {
        var jsonValue = JSON.parse(value);
        for (var i = 0; i < jsonValue.length; i++) {
            var param = jsonValue[i];
            if (param.length === 0)
                continue;

            // 有東西 更新玩家的資訊
            var player = this._players[i];
            var playerData = player.getPlayerData();
            if (playerData && playerData.getIsExist()) {
                // 配戴徽章編號、名稱
                if (param.medal == "8101" || param.medal == "") {
                    playerData.medal.code = "";
                    playerData.medal.name = "";
                } else {
                    playerData.medal.code = JSCodeUtility.getStringValue(param["medal"]);
                    playerData.medal.name = JSCodeUtility.getStringValue(param["name_medal"]);
                }

                // 配戴物品編號、名稱
                if (param.accessory == "1101" || param.accessory == "") {
                    playerData.accessory.code = "";
                    playerData.accessory.name = "";
                } else {
                    playerData.accessory.code = JSCodeUtility.getStringValue(param["accessory"]);
                    playerData.accessory.name = JSCodeUtility.getStringValue(param["name_accessory"]);
                }

                // 更新畫面
                player.updateAccessory();
            }
        }
    },

    /**
     * 玩家跟注
     */
    cmd_current_playing: function (value) {
        // 把玩家跟注的錢都擺在桌上 且不要動畫 因為myPos 還是-1
        var pot = value.pot || [];
        for (var i = 0, len = pot.length; i < len; i++) {
            var money = parseInt(pot[i]);
            if (money > 0) {
                this._chipsLayer.sendChipsToPot(i, money, true);
            }
        }

        // 重現現在玩家的牌 要有first_param: 1
        var haveCard = JSCodeUtility.getIntValue(value.first_param) === 1;
        if (haveCard) {
            var phase = JSCodeUtility.getIntValue(value.phase);
            var totalCardCount;
            switch (phase) {
                case 0:
                    totalCardCount = 2;
                    break;
                case 1:
                    totalCardCount = 3;
                    break;
                case 2:
                    totalCardCount = 4;
                    break;
                default:
                    totalCardCount = 0;
                    break;
            }

            (value.playing || []).forEach((cur) => {
                var player = this._players[cur];
                // 先清掉
                player.cleanDisplayWhenOLEH();

                // 加牌
                for (var i = 0; i < totalCardCount; i++) {
                    player.addHandCard();
                }
            });
        }
    },

    /**
     * 玩家跟注 跟 加注
     */
    cmd_plcall_plraise: function (key, value) {
        var jsonArray = value.split(" ");
        var serverSitNum = JSCodeUtility.getIntValue(jsonArray[0]);
        var oldChips = this._playerPotChips[serverSitNum] || 0;             // 玩家之前下注的金額
        var chips = JSCodeUtility.getIntValue(jsonArray[1]);                // 現在下注的總金額 要扣掉之前的
        var thisChips = chips - oldChips;
        var isPlcall = (key === "plcall");
        var player = this._players[serverSitNum];

        if (DataModal.gameData.playerDataArray[serverSitNum].tableChips - thisChips > 0) {
            // 更新狀態文字
            player.refreshStatus(isPlcall ? GAME_PLAYER_STATUS.CALL : GAME_PLAYER_STATUS.RAISE);

            // 送籌碼
            this._chipsLayer.sendChipsToPot(serverSitNum, thisChips);

            // 撥放音效
            MusicUtility.playVoice(isPlcall ? "call.mp3" : "raise.mp3");
        } else {
            // 撥放Allin動畫
            player.setAllInAnimationVisible(true);

            // 更新狀態文字
            player.refreshStatus(GAME_PLAYER_STATUS.ALL_IN);

            // 送籌碼
            this._chipsLayer.sendChipsToPot(serverSitNum, DataModal.gameData.playerDataArray[serverSitNum].tableChips);

            // 撥放音效
            MusicUtility.playEffect("Music/Effect/Allin.mp3");
            MusicUtility.playVoice("allin.mp3");

            // 假如是自己的話 通知UILayer換畫面
            if (serverSitNum === DataModal.gameData.myPos)
                GS.dispatchCustomEvent("NotifyGameUISetMenuStatus", DOMINO_UILAYER_STATUS.EMPTY);
        }

        // 更新這位玩家的下注金額
        this._playerPotChips[serverSitNum] = chips;

        // 關掉倒數
        this._players[serverSitNum].playCountDown(false, 0);
    },

    /**
     * 玩家過牌
     */
    cmd_plcheck: function (value) {
        var jsonArray = value.split(" ");

        var serverPos = JSCodeUtility.getIntValue(jsonArray[0]);
        var player = this._players[serverPos];
        if (!player)
            return;

        // 更新狀態文字
        player.refreshStatus(GAME_PLAYER_STATUS.CHECK);

        // 停止倒數
        player.playCountDown(false, 0);
    },

    /**
     * 玩家棄牌
     */
    cmd_plfold: function (value) {
        var jsonArray = value.split(" ");
        var serverPos = JSCodeUtility.getIntValue(jsonArray[0]);

        var player = this._players[serverPos];
        if (!player)
            return;

        // 更新狀態文字
        player.refreshStatus(GAME_PLAYER_STATUS.FOLD);

        // 停止倒數
        player.playCountDown(false, 0);

        // 播棄牌動畫 要抓出有幾張 假如player上面沒手牌 代表是玩家本人
        var isSelf = player.getIsSelf();
        var cardCount = isSelf ? this._handCardSetNode.getCardCount() : player.getHandCardCount();
        GS.dispatchCustomEvent("NotifyGamePlayerFoldCard", {
            serverPos: serverPos,
            cardCount: cardCount
        });

        // 砍掉手牌
        if (isSelf) {
            this._handCardSetNode.cleanData();
        } else {
            player.removeHandCard();
        }
    },

    /**
     * 更新等級
     */
    cmd_update_upgrade: function (value) {
        var jsonArray = JSON.parse(value);
        var needPlayEffect = false;
        for (var i = 0, len = jsonArray.length; i < len; i++) {
            var level = JSCodeUtility.getIntValue(jsonArray[i]);
            if (level !== 0) {
                // 先判斷這使用者在不在場上
                var player = this._players[i];
                if (player && player.getIsExist()) {
                    this._playerAnimLayer.playAnimation(i, Domino_PlayerAnimNode.Type.LEVEL_UP, level);
                    needPlayEffect = true;
                }
            }
        }

        // 判斷是否要撥放音效
        needPlayEffect && MusicUtility.playEffect("Music/Effect/levelUp.mp3");
    },

    /**
     * 更新經驗值
     */
    cmd_update_getexp: function (value) {
        var jsonArray = JSON.parse(value);
        for (var i = 0, len = jsonArray.length; i < len; i++) {
            var exp = JSCodeUtility.getIntValue(jsonArray[i]);
            if (exp !== 0) {
                // 先判斷這使用者在不在場上
                var player = this._players[i];
                if (player && player.getIsExist()) {
                    this._playerAnimLayer.playAnimation(i, Domino_PlayerAnimNode.Type.EXP, exp);
                }
            }
        }
    },

    /**
     * 更新積分
     * @param {String} value socke傳回來的值
     */
    cmd_update_gameRankUpdate: function (value) {
        // {"changeClass":["","","","","","",""],"scoreUpdate":["8","0","0","0","0","-1","0"]}
        var jsonValue = JSON.parse(value);
        var changeClass = jsonValue["changeClass"];
        var scoreUpdate = jsonValue["scoreUpdate"];
        for (var i = 0, len = scoreUpdate.length; i < len; i++) {
            var score = JSCodeUtility.getIntValue(scoreUpdate[i]);
            var player = this._players[i];
            if (player && score !== 0 && player.getIsExist()) {
                // 積分有更動
                this._playerAnimLayer.playAnimation(i, Domino_PlayerAnimNode.Type.GAME_RANK_SCORE_CHANGE, score);

                // 判斷是否階級有變動 且不是自己
                var levelClass = changeClass[i];
                if (levelClass && !player.getIsSelf()) {
                    player.showChangeGameRankClassAnimation(parseInt(levelClass));
                }
            }
        }
    },

    /**
     * 結算時比牌
     * @param value socket傳回來的值
     */
    cmd_finish1: function (value) {
        // 結算 每個人的牌型 finish1 [["12","33","36","00"],"","","","",["44","01","46","11"],""]
        var jsonArray = JSON.parse(value);

        jsonArray.forEach((cur, index) => {
            if (cur.length) {
                // 抓出Player
                var player = this._players[index];
                if (player) {
                    if (player.getIsSelf()) {
                        // 自己的話 對手牌重新修正
                        this._handCardSetNode.setFinishCard(cur);
                    } else {
                        // 處理其他玩家
                        player.showFinishHandCard(cur);
                    }
                }
            }
        });

        // 把玩家的倒數 跟 All in動畫關掉
        this._players.forEach(cur => {
            cur.setAllInAnimationVisible(false);
            cur.playCountDown(false);
        });
    },

    /**
     * 結算時的分錢
     */
    cmd_showdown: function (jsonValue, totalPool) {
        // {"winList":[{"ct":0,"pos":"0","chip":740,"currchips":20340}],"poolIndex":0}
        // 把winList抓出來 然後去送籌碼 totalPool代表多少分池
        var winList = jsonValue["winList"];
        var nowPoolIndex = parseInt(jsonValue.poolIndex);
        var isLastPoolIndex = (totalPool === nowPoolIndex + 1);
        var self = this;
        var sendFunc = function (i) {
            var winListParam = winList[i];
            var serverPos = winListParam.pos;
            var money = winListParam.chip;
            var lastMoney = winListParam.currchips;
            var isLast = (i === len - 1);
            var player = self._players[serverPos];
            self._chipsLayer.sendPotChipsToPlayer(serverPos, money, isLast && isLastPoolIndex, function () {
                // 更新使用者上面最後金額
                player.updateChips(lastMoney);

                // 出現金錢動畫
                self._playerAnimLayer.playAnimation(serverPos, Domino_PlayerAnimNode.Type.GET_CHIPS, money);

                // 代表給完金錢 要出現金額
                if (isLast && isLastPoolIndex) {
                    // 通知抓取下一個CMD
                    GS.dispatchCustomEvent("NotifyEnableProcessMessage");
                }
            });

            // AppsFlyer 玩家在牌局中贏牌就算1次(累加)
            if (serverPos === DataModal.gameData.myPos) {
                GameAppsFlyerTracker.trackByGameName("win");
            }
        };
        for (var i = 0, len = winList.length; i < len; i++) {
            sendFunc(i);
        }

        // 把玩家的倒數 跟 All in動畫關掉
        this._players.forEach(function (cur) {
            cur.setAllInAnimationVisible(false);
            cur.playCountDown(false);
        });

        // 撥放贏家音效
        MusicUtility.playEffect("Music/Effect/light_ring.mp3");
    },

    /**
     * 結算 沒比牌，僅剩一家未棄牌時才會出現
     */
    cmd_noshowdown: function (value) {
        // noshowdown 5 740 0 19940
        var valueArray = value.split(" ");
        var serverPos = JSCodeUtility.getIntValue(valueArray[0]);       // 分給幾號玩家
        var money = JSCodeUtility.getIntValue(valueArray[1]);           // 分多少錢給玩家
        // var poolIndex = JSCodeUtility.getIntValue(valueArray[2]);       // 分出去的是第幾分池
        var lastMoney = JSCodeUtility.getIntValue(valueArray[3]);       // 分給玩家後玩家總共有多少錢
        var player = this._players[serverPos];

        // 送籌碼給對方
        var self = this;
        this._chipsLayer.sendPotChipsToPlayer(serverPos, money, true, function () {
            // 更新使用者上面最後金額
            player.updateChips(lastMoney);

            // 出現金錢動畫
            self._playerAnimLayer.playAnimation(serverPos, Domino_PlayerAnimNode.Type.GET_CHIPS, money);

            // 通知抓取下一個CMD
            GS.dispatchCustomEvent("NotifyEnableProcessMessage");
        });

        // 把玩家的倒數 跟 All in動畫關掉
        this._players.forEach(function (cur) {
            cur.setAllInAnimationVisible(false);
            cur.playCountDown(false);
        });

        // 撥放贏家音效
        MusicUtility.playEffect("Music/Effect/light_ring.mp3");

        // AppsFlyer 玩家在牌局中贏牌就算1次(累加)
        if (serverPos === DataModal.gameData.myPos) {
            GameAppsFlyerTracker.trackByGameName("win");
        }
    },

    /**
     * 只有一人時結束遊戲
     */
    cmd_stopGame: function () {
        if (DataModal.gameData.haveMe) {
            var player = this._players[DataModal.gameData.myPos];
            player && player.refreshStatus(GAME_PLAYER_STATUS.UNKNOW);
        }

        // 清掉其他玩家畫面
        this._players.forEach(function (cur) {
            cur.cleanDisplayWhenOLEH();
        });

        // 清掉自己手牌
        this._handCardSetNode.cleanData();

        // 清掉牌桌的金錢
        this._chipsLayer.cleanData();
    },

    /**
     * 撥放表情
     * mood y21610400@an y21610400 0 1 mood4
     */
    cmd_mood: function (value) {
        var valueArray = value.split(" ");
        var valueLen = valueArray.length;
        if (valueLen > 4) {
            var serverPos = parseInt(valueArray[valueLen - 3]);
            var moodString = valueArray[valueLen - 1];
            var player = this._players[serverPos];
            player && player.playMood(moodString);
        }
    },

    /**
     * VIP表情
     * vmood y21610400@an y21610400 0 1 mood4
     */
    cmd_vmood: function (value) {
        var valueArray = value.split(" ");
        var valueLen = valueArray.length;
        if (valueLen > 4) {
            var serverPos = parseInt(valueArray[valueLen - 3]);
            var moodString = valueArray[valueLen - 1];
            var player = this._players[serverPos];
            player.playMood("v" + moodString);
        }
    },

    /**
     * 撥放商城表情
     * store_mood j66002768@an Sam 0 1 mood11012
     */
    cmd_store_mood: function (value) {
        var valueArray = value.split(" ");
        var valueLen = valueArray.length;
        if (valueLen > 4) {
            var serverPos = parseInt(valueArray[valueLen - 3]);

            // 要把mood字串拿掉
            var moodString = valueArray[valueLen - 1];
            moodString = moodString.replace("mood", "");

            var player = this._players[serverPos];
            player.playMood(moodString);
        }
    },

    /**
     * 送禮物
     * gift_accessory 送禮人的位置 [收禮人的位置, 收禮人的位置,……] 禮物圖片編號 禮物名稱
     */
    cmd_gift_accessory: function (value) {
        var valueArray = value.split(" ");
        if (valueArray.length > 3) {
            var serverPos = parseInt(valueArray[0]);
            var toPosArray = JSON.parse(valueArray[1]);
            var itemID = valueArray[2];
            var itemName = decodeURIComponent(valueArray[3]);
            var myPos = DataModal.gameData.myPos;
            var size = cc.size(54, 54);                         // 送出去畫面的大小

            var sendFunc = (i) => {
                var toPos = parseInt(toPosArray[i]);
                var player = this._players[toPos];
                var playerData = player.getPlayerData();

                if (serverPos === myPos && serverPos === toPos) {
                    // 自己送給自己 更改自己的東西就好了
                    playerData.accessory.code = itemID;
                    playerData.accessory.name = itemName;

                    // ProfileData也要塞一份
                    DataModal.profileData.accessory.code = itemID;
                    DataModal.profileData.accessory.name = itemName;

                    // 更新手上的配件
                    player.updateAccessory();
                } else {
                    // 要跑動畫
                    var firstPosition = Domino_GameUtility.getPlayerPosition(DataModal.gameData.getDirectionByServerDirection(serverPos));
                    var endPosition = Domino_GameUtility.getPlayerPosition(DataModal.gameData.getDirectionByServerDirection(toPos));

                    var accessoryItemNode = new AccessoryItemNode(itemID, size.width, size.height, (accessoryNode) => {
                        if (this.__isDestroyed)
                            return;

                        // 當圖片下載結束或GAF產生出來 要開始移動
                        if (player.getIsExist()) {
                            // 移動過去
                            accessoryNode.runAction(cc.sequence(
                                cc.delayTime(0.2),
                                cc.moveTo(0.9, endPosition),
                                cc.delayTime(0.2),
                                cc.fadeOut(0.1),
                                cc.callFunc(() => {
                                    playerData.accessory.code = itemID;
                                    playerData.accessory.name = itemName;

                                    // 更新手上的配件
                                    player.updateAccessory();
                                }),
                                cc.removeSelf()
                            ));
                        } else {
                            // 人不見了 砍掉
                            accessoryNode.removeFromParent();
                        }
                    });
                    accessoryItemNode.setPosition(firstPosition);
                    this.addChild(accessoryItemNode, 15);
                }
            };

            for (var i = 0; i < toPosArray.length; i++) {
                sendFunc(i);
            }
        }
    },

    /**
     * 通知
     */
    // 自己手牌確定 要通知Server
    notifyConfirmCardDone: function () {
        // 把可以換牌的關掉
        this._handCardSetNode.setChangeCardEnable(false);

        // 抓取現在牌的牌序
        var jsonString = this._handCardSetNode.getCardOrder();

        // 送出
        DataProcess.sendString("confirm " + jsonString);
    },

    /**
     * 按下換牌桌
     * @param event
     */
    notifyGameUIChangePlaceClicked: function (event) {
        for (var serverSitNum = 0; serverSitNum < DataModal.gameData.playerNumber; serverSitNum++) {
            this._players[serverSitNum].playCountDown(false);
        }
    },

    // 使用者的積分階級更新
    notifyUpdateGameRankClass: function (event) {
        var levelClass = event.getUserData();
        var player = this._players[DataModal.gameData.myPos];
        player && player.showChangeGameRankClassAnimation(levelClass);
    },

    // 黑名單大頭照更新
    notifyRefreshIsForbidden: function (event) {
        if (!event)
            return;

        var blackAccount = event.getUserData();
        DataModal.gameData.playerDataArray.forEach((playerData, serverPos) => {
            if (blackAccount === playerData.account) {
                var url = DataModal.blacklistData.isAccountInList(playerData.account) ? "" : playerData.photoURL;
                this._players[serverPos].updateIsForbidden(url);
            }
        });
    }
});