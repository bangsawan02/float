/**
 * Cangkulan的遊戲Scene
 */

var Cangkulan_GameScene = PushScene.extend({
    _gameLayer: null,               //遊戲主畫面

    ctor: function () {
        this._super();

        this.setTag(GSEnum.Scene.Game);

        // 測試按鈕、log牌局重現
        if (JSDebugMode && DataModal.debugTestData.isShowGameDebug) {
            var testDebugLayer = new GameTestDebugLayer(GSEnum.Game.Cangkulan);
            this.addChild(testDebugLayer, 100000);
        }

        // 加通知
        GS.addListener("NotifyLoginStatus", this.notifyLoginStatus.bind(this), this);
        GS.addListener("NotifySessionStatusDone", this.notifySessionStatusDone.bind(this), this);

        // 回背景/背景回來通知
        GS.addListener(cc.sys.isNative ? "NotifyGameEnterBackground" : cc.game.EVENT_HIDE, this.notifyGameOnHIDE.bind(this), this);
        GS.addListener(cc.sys.isNative ? "NotifyGameEnterForeground" : cc.game.EVENT_SHOW, this.notifyGameOnShow.bind(this), this);

        // Socket連線註冊
        GS.addListener("NotifySocketResult", this.notifySocketResult.bind(this), this);
    },

    onEnter: function () {
        this._super();

        // Firebase 紀錄玩家目前在哪個scene
        cc.sys.isNative && GSFirebaseCrashlytics.setString("NowScene", "Cangkulan_GameScene");

        // 撥放背景音樂
        MusicUtility.playMusic("Music/Background/vegas_bg_music.mp3", true);

        cc.spriteFrameCache.addSpriteFrames("game/Domino/game_cangkulan.plist", "game/Domino/game_cangkulan.png");
        cc.spriteFrameCache.addSpriteFrames("game/Common/game_common.plist", "game/Common/game_common.png");
        cc.spriteFrameCache.addSpriteFrames("common/number/num_09.plist", "common/number/num_09.png");

        // 關掉WebAppInstallBanner
        WebAppInstallBanner.canShowPrompt = false;

        // 遊戲進入埋點
        EventLogToBigQuery.logEventWithCampaignId(999, 3, 1);
    },

    onExit: function () {
        cc.spriteFrameCache.removeSpriteFramesFromFile("game/Domino/game_cangkulan.plist");
        cc.spriteFrameCache.removeSpriteFramesFromFile("game/Common/game_common.plist");
        cc.spriteFrameCache.removeSpriteFramesFromFile("common/number/num_09.plist");

        // 清掉GameData的一些資料
        DataModal.gameData.cleanGameData();

        // 清掉儲值的資料
        DataModal.purchaseData.resetAllValue();

        DataModal.dailyMissionData.resetAllValue();

        // 清掉遊戲內儲的資料
        DataModal.purchaseRecommendProductData.cleanData();

        // 清除聊天記錄
        DataModal.chatData.cleanData();

        // 設定不是從LoginScene進來
        DataModal.isComeFromLoginScene = false;

        // 清掉背景音樂
        MusicUtility.stopAllMusic();

        // 判斷是否可以跳出WebAppInstallBanner
        WebAppInstallBanner.canShowPrompt = true;

        // 離開 設回預設 (怕直接踢回登入頁)
        cc.director.getScheduler().setTimeScale(1);

        // Firebase 使用
        GSAnalyticsAdapter.record["isClickQuickPlayFromLobby"] = false;
        GSAnalyticsAdapter.record["isClickQuickPlayFromRoom"] = false;

        this._super();
    },

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        if (DataModal.gameData.leaveGameStatus === Cangkulan_LeaveGameStatus.CAN_LEAVE) {
            // 直接離桌
            GS.dispatchCustomEvent("NotifyGameUIBackToLobbyClicked");
        } else {
            // 開選單
            GS.dispatchCustomEvent("NotifyShowUIOptionOpenMenu");
        }
    },

    /**
     * GameScene切換完成 開始處理cmd
     */
    onChangeSceneReady: function () {
        // 這邊正常應該要讓gameLayer處理onChangeSceneReady就好
        // 但是gameLayer裏頭很多UI會自己送cmd，只好把new gameLayer放到這裡
        // gameLayer的onChangeSceneReady也先改成onEnter
        // this._gameLayer.onChangeSceneReady && this._gameLayer.onChangeSceneReady();

        DataProcess.sendString("!EXTRA");

        // 遊戲畫面
        var clipNode = this.createClipNode();
        clipNode.setPosition(JSOriginPoint);
        this.addChild(clipNode);
        this._pushLayerArray.push(clipNode);

        this._gameLayer = new Cangkulan_GameLayer();
        clipNode.addChild(this._gameLayer);
    },

    /**
     * 通知
     */
    // 回大廳的通知
    notifyLoginStatus: function (e) {
        var status = e.getUserData();
        if (status === LoginLoadingStatus.LOBBY26_DONE) {
            // 到大廳了 要送完session_status才能回大廳
            DataProcess.sendString("session_status [1]");

            this._needToLobby = true;
        }
    },

    // 收到session_status
    notifySessionStatusDone: function () {
        // 判斷是否要回大廳
        if (this._needToLobby)
            ChangeSceneHelper.goLobbyScene();
    },

    /**
     * 到背景 到前景的通知
     */
    // 把App縮下去到背景
    notifyGameOnHIDE: function () {
        this._intoBackgroundTime = JSCodeUtility.getNowTime();

        // 離開背景 設回預設
        cc.director.getScheduler().setTimeScale(1);
    },

    // 從背景回來App
    notifyGameOnShow: function () {
        if (this._intoBackgroundTime > 0) {

            // 算出相差時間
            var time = JSCodeUtility.getNowTime() - this._intoBackgroundTime;

            // 快轉牌局
            var speedRatio = time > 30 ? 8 : 6;
            this.runAction(cc.sequence(
                cc.delayTime(time / speedRatio),            // 這邊時間不會跟著加速 所以要除加速的倍率
                cc.callFunc(() => {
                    // 把加速關掉
                    cc.director.getScheduler().setTimeScale(1);
                })
            ));
            cc.director.getScheduler().setTimeScale(speedRatio);

            // 歸0
            this._intoBackgroundTime = 0;
        }
    },

    /**
     * Socket連線通知
     */
    notifySocketResult: function (e) {
        var result = e.getUserData();
        switch (result) {
            case "disconnect":
            case "ReconnectFail":
                //斷線或斷線重連失敗

                // 遊戲斷線埋點
                EventLogToBigQuery.logEventWithCampaignId(999, 3, 2);

                // 踢回登入畫面 跳Alert
                CommonUtility.goLoginScene({
                    title: LocalizedString.Common("連線錯誤"),
                    content: LocalizedString.Common("連線中斷，請檢查網路是否連線再重新連線。")
                });
                break;
            case "StartReconnect":
                //開始斷線重連
                GSLoading.addLoadingViewByString(LocalizedString.Common("網路已中斷連線，將嘗試重新連線。"));
                break;
            case "ReconnectDone":
                //斷線重連成功了
                GSLoading.removeLoadingView();
                break;
        }
    },
});