/**
 * 5.4.0 副系統 - 激戰任務子排行Layer
 * created by Jim.Chen
 */

var FierceBattleRankLayer = cc.Layer.extend({
    ctor: function (gameType, pageParam) {
        this._super();
        this._gameType = gameType;                                  // 玩法編號
        this._pageParam = pageParam;                                // 本時段排行資料
        var rankList = this._rankList = pageParam.rankList;
        var rankListLen = rankList.length;

        this._totalCellCount = 0;
        var topNodeHeight = this._topNodeHeight = 133;              // 前三名排行榜的高度

        var tableWidth = this._tableWidth = 305;
        var tableHeight = 155;

        // 未開賽or無人上榜  顯示提示訊息
        if (rankListLen === 0) {

            var hintLabel = this._hintLabel = new cc.LabelTTF(LocalizedString.FierceBattle((pageParam.status === FierceBattleData.PeriodStatusType.COMING_SOON) ? "比賽尚未開始\n敬請期待~" : "榜上無人\n立即衝榜吧!"), JSFontName, 12, cc.size(0, 0), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
            hintLabel.setPosition(326 + JSScreenBonusHalfWidth, 116 + JSScreenBonusHalfHeight);
            this.addChild(hintLabel);

        } else {

            // 有人進榜 創列表
            var mainLayer = this._mainLayer = new cc.Layer();
            var tableView = this._tableView = new cc.TableView(this, cc.size(tableWidth, tableHeight), mainLayer);
            tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
            tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
            tableView.setTouchEnabled(rankListLen > 3);
            tableView.setDelegate(this);
            tableView.setPosition(177 + JSScreenBonusHalfWidth, 56 + JSScreenBonusHalfHeight);
            this.addChild(tableView);

            // tableView上方擋Touch
            var touchLayerY = 210 + JSScreenBonusHalfHeight;
            var dummyTouch = new DummyTouchLayer(cc.size(tableWidth, JSVisibleSize.height - touchLayerY), false);
            dummyTouch.setPosition(177 + JSScreenBonusHalfWidth, touchLayerY);
            this.addChild(dummyTouch);

            // 下方擋Touch
            dummyTouch = new DummyTouchLayer(cc.size(tableWidth, 54 + JSScreenBonusHalfHeight), false);
            dummyTouch.setPosition(177 + JSScreenBonusHalfWidth, 0);
            this.addChild(dummyTouch);

            // 全部Cell 扣掉前三名放在上面扣掉 所以是-2
            var totalCell = this._totalCellCount = (rankListLen) - 2;

            // 更新TableView
            tableView.reloadData(true);

            // 算高度 第一個是TopNode 要扣掉
            var totalHeight = (totalCell - 1) * FierceBattleRankCell.HEIGHT;

            // 加線條
            var midPosX = tableWidth / 2;
            var nowPosY = FierceBattleRankCell.HEIGHT;
            for (var i = 0; i < totalCell - 1; i++) {
                var lineSprite = new ccui.Scale9Sprite("lobby_division_line.png");
                lineSprite.setPreferredSize(cc.size(tableWidth - 4, 2));
                lineSprite.setPosition(midPosX, nowPosY);
                mainLayer.addChild(lineSprite);

                nowPosY += FierceBattleRankCell.HEIGHT;
            }

            // 加前三名的排行榜
            var topRankNode = new FierceBattleTopNode(rankList);
            topRankNode.setPosition(0, totalHeight);
            mainLayer.addChild(topRankNode);

            // 設定tableView
            tableView.setContentSize(cc.size(tableWidth, totalHeight + topNodeHeight));
            tableView.setContentOffset(cc.p(0, tableView.getViewSize().height - tableView.getContentSize().height));

            // 自己的名次
            var myRank = pageParam.myRank;
            // 下方自己名次顯示區
            {
                // 背景
                var shelfBgSp = new cc.Scale9Sprite("fierceBattle_pic_board_self.png");
                shelfBgSp.setPreferredSize(cc.size(325, 42));
                shelfBgSp.setPosition(328 + JSScreenBonusHalfWidth, 40 + JSScreenBonusHalfHeight);
                this.addChild(shelfBgSp);

                if (0 < myRank && myRank <= 3) {
                    // 前三名皇冠
                    var crownSp = new cc.Sprite(JSStringUtility.format("#crown_0%d.png", myRank));
                    crownSp.setPosition(197 + JSScreenBonusHalfWidth, 40 + JSScreenBonusHalfHeight);
                    this.addChild(crownSp);
                } else {
                    // 第四名以後的名次
                    var rankLabel = new cc.LabelTTF(myRank, JSFontName, 12);
                    rankLabel.setFontFillColor(JSColor.BLACK);
                    rankLabel.setPosition(197 + JSScreenBonusHalfWidth, 40 + JSScreenBonusHalfHeight);
                    this.addChild(rankLabel);
                }

                // 獎牌圖
                var medalSp = new cc.Sprite("#fierceBattle_pic_badge.png");
                medalSp.setPosition(369 + JSScreenBonusHalfWidth, 40 + JSScreenBonusHalfHeight);
                this.addChild(medalSp);

                // 獎牌數
                var medalLabel = new cc.LabelTTF(pageParam.myScore.toString(), JSFontName, 12);
                medalLabel.setFontFillColor(JSColor.BLACK);
                medalLabel.setAnchorPoint(0, 0.5);
                medalLabel.setPosition(380 + JSScreenBonusHalfWidth, 40 + JSScreenBonusHalfHeight);
                this.addChild(medalLabel);

                // 大頭照 裁切的node
                var stencilSprite = new cc.Sprite("#lobby_photo_clip.png");
                var clipNode = new cc.ClippingNode(stencilSprite);
                clipNode.setCascadeColorEnabled(true);
                clipNode.setAlphaThreshold(0.5);
                this.addChild(clipNode);

                // 大頭照
                var photoSprite = this._photoSprite = new PhotoSprite(DataModal.profileData.photoURL, 60, 60);
                photoSprite.setDefaultSprite(JSCodeUtility.getRandomInt(0, 1) ? "photo_male.png" : "photo_female.png");
                clipNode.setScale(30 / 60);
                clipNode.setPosition(232 + JSScreenBonusHalfWidth, 40 + JSScreenBonusHalfHeight);
                clipNode.addChild(photoSprite);

                // 暱稱
                var nicknameLabel = this._nicknameLabel = new cc.LabelTTF(JSStringUtility.cutStringReplaceByEllipsis(DataModal.profileData.nickname, 11, 110), JSFontName, 11);
                nicknameLabel.setFontFillColor(JSColor.BLACK);
                nicknameLabel.setAnchorPoint(0, 0.5);
                nicknameLabel.setPosition(251 + JSScreenBonusHalfWidth, 40 + JSScreenBonusHalfHeight);
                this.addChild(nicknameLabel);

                // 寶箱按鈕 有獎勵才顯示
                var chestImg = "";
                if (0 < myRank && myRank <= 3) {
                    chestImg = JSStringUtility.format("lobby_pic_chest_%02d.png", myRank);
                } else if (3 < myRank && myRank <= 25) {
                    chestImg = "lobby_pic_chest_04.png";
                } else if (myRank <= 50) {
                    chestImg = "lobby_pic_chest_05.png";
                }
                if (chestImg.length > 0) {
                    var chestBtn = ButtonUtility.createSimpleButton(chestImg);
                    chestBtn.addTargetWithActionForControlEvents(this, this._chestBtnClicked,
                        cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
                        cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
                        cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
                    chestBtn.setAdjustBackgroundImage(false);
                    chestBtn.setZoomOnTouchDown(false);
                    chestBtn.setPosition(454 + JSScreenBonusHalfWidth, 40 + JSScreenBonusHalfHeight);
                    chestBtn.pos = this.convertToNodeSpace(this.convertToWorldSpace(chestBtn.getPosition()));
                    var myRewards = chestBtn.rewards = rankList[myRank - 1].rewards;
                    chestBtn.setVisible(myRewards.length > 0 && pageParam.status === FierceBattleData.PeriodStatusType.END);
                    this.addChild(chestBtn);
                }

                // 馬上玩按鈕 現在場次且在大廳才有
                var playBtn = ButtonUtility.createSimpleButton("lobby_btn_03.png", cc.size(50, 20), LocalizedString.FierceBattle("馬上玩"));
                playBtn.addTouchUpInsideAction(this._playBtnClicked, this);
                playBtn.setPosition(456 + JSScreenBonusHalfWidth, 40 + JSScreenBonusHalfHeight);
                playBtn.setVisible(PushScene.isLobby && pageParam.status === FierceBattleData.PeriodStatusType.NOW);
                this.addChild(playBtn);

                // 跑馬燈
                var marqueeNode = new MarqueeNode({
                    width: 275,
                    height: 14,
                    sec: 10,
                    fontSize: 9,
                    disableBG: false,
                    bgOpacity: 204,
                    isLoop: true
                });
                marqueeNode.setPosition(282 + JSScreenBonusHalfWidth, 222 + JSScreenBonusHalfHeight);
                this.addChild(marqueeNode);

                // 跑馬燈輪播
                var marqueeList = pageParam.marqueeList;
                var marqueeLength = marqueeList.length;
                var index = 0;
                marqueeNode.runAction(cc.repeatForever(cc.sequence(
                    cc.callFunc(function () {
                        marqueeNode.push({
                            message: marqueeList[index++ % marqueeLength],
                            color: cc.color(255, 255, 255)
                        });
                    }),
                    cc.delayTime(10)   // 換訊息時間
                )));

                // 該時段已結束壓上END
                var endLogoSp = new cc.Sprite("#fierceBattle_pic_end.png");
                endLogoSp.setPosition(466 + JSScreenBonusHalfWidth, 202 + JSScreenBonusHalfHeight);
                endLogoSp.setRotation(15);
                endLogoSp.setVisible(pageParam.status === FierceBattleData.PeriodStatusType.END);
                this.addChild(endLogoSp);
            }
        }

        // 監聽
        GS.addListener("NotifyFierceBattleRankShowMessage", this.notifyFierceBattleRankShowMessage.bind(this), this);
    },

    /**
     * TableView delegate
     */
    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        if (cell == null) {
            cell = new FierceBattleRankCell();
            cell.setAnchorPoint(cc.p(0, 0));
        }

        // 下面資料從第四名開始拿
        cell.refreshCellWithParam(idx, this._rankList[idx + 2]);
        return cell;
    },

    numberOfCellsInTableView: function (table) {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function (table, idx) {
        // idx = 0 上面是放排行榜前三名的
        return cc.size(this._tableWidth, idx === 0 ? this._topNodeHeight : FierceBattleRankCell.HEIGHT);
    },

    // 按下馬上玩
    _playBtnClicked: function () {
        // 引導馬上玩
        GS.dispatchCustomEvent("NotifyGoQuickPlay", {game: this._gameType});

        // 埋點
        DataProcess.sendString("track_fierce_battle 4");
    },

    // 寶箱按鈕點擊
    _chestBtnClicked: function (sender, controlEvent) {
        if (controlEvent === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || controlEvent === cc.CONTROL_EVENT_TOUCH_DOWN) {
            var pos = sender.pos;

            var rewardParam = sender.rewards;
            if (!rewardParam)
                return;

            // 裝獎勵的容器
            var contentNode = new GSAutoLayoutNode();
            contentNode.setType(GSAutoLayout.TYPE.VERTICAL_LEFT);

            rewardParam.forEach(cur => {
                // 排版用的node
                var autoLayoutNode = new GSAutoLayoutNode();

                // 獎勵圖
                var imageUrl = JSStringUtility.format("%s%s%s", FierceBattleData.REWARD_BASE_HOST, cur.pic, ".png");
                var savePath = JSWriteablePath + "shop/" + cur.pic;
                var reward = new GSDownloadSprite("", imageUrl, savePath);
                reward.setTargetSize(cc.size(20, 20));
                autoLayoutNode.addChild(reward);

                // 加一個間距
                autoLayoutNode.addEmptyNode(cc.size(10, 10));

                // 獎勵文字
                var countLabel = new cc.LabelTTF(cur.rewardTxt, JSFontName, 9, cc.size(0, 0), cc.TEXT_ALIGNMENT_LEFT, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
                countLabel.setFontFillColor(JSColor.BLACK);
                countLabel.setAnchorPoint(0, 0.5);
                autoLayoutNode.addChild(countLabel);

                // 最後再加進去，才會有autoLayoutNode的contentSize
                contentNode.addChild(autoLayoutNode);
            });

            if (!this._messageNode) {
                var messageNode = this._messageNode = new BaseMessageNode({
                    mainNode: contentNode,
                    style: BaseMessageNode.Style.WHITE_SHADOW,
                    direct: (sender.isTopNode) ? BaseMessageNode.Direct.DOWN : BaseMessageNode.Direct.RIGHT,
                    arrowType: BaseMessageNode.ArrowType.STRAIGHT,
                    arrowPadding: (sender.isTopNode) ? -50 : contentNode.getContentSize().height / 2 - 10,
                    isFlip: false,
                });
                messageNode.show();
                this.addChild(messageNode, 10);
            }
            var messagePos = (sender.isTopNode) ? cc.p(pos.x, pos.y + 15) : cc.p(pos.x - 15, pos.y);
            this._messageNode.setPosition(messagePos);
        } else {
            this._messageNode && this._messageNode.close();
            this._messageNode = undefined;
        }
    },

    // 跳個別獎勵泡泡框
    notifyFierceBattleRankShowMessage: function (event) {
        // 只有目前顯示的RankLayer需要跳泡泡框
        if (!this.isVisible() || !event || !event.getUserData())
            return;

        var obj = event.getUserData();
        obj.pos = this.convertToNodeSpace(obj.pos);
        this._chestBtnClicked(obj, obj.controlEvent);
    }
});