/**
 *  鑽石賽 兌換商品node
 */

var DiamondExchangeNode = cc.Node.extend({
    ctor: function (nodeSize, param) {
        this._super();
        this._param = param;

        var competeString = LocalizedString.Compete;

        // 所有東西都放在裡面
        var node = new cc.Node();
        node.setPosition(nodeSize.width / 2, 0);
        this.addChild(node);

        // 背景
        var bgSp = new ccui.Scale9Sprite("bg_white_02.png");
        bgSp.setPreferredSize(nodeSize);
        node.addChild(bgSp);

        // title
        var titleLabel = new cc.LabelTTF(param.name, JSFontName, 12);
        titleLabel.setFontFillColor(JSColor.BLACK);
        titleLabel.setPositionY(nodeSize.height / 2 - 14);
        node.addChild(titleLabel);

        // 分隔線
        var lineSp = new cc.Sprite("#users_line.png");
        lineSp.setScaleX(5.5);
        lineSp.setPositionY(titleLabel.getPositionY() - 11);
        node.addChild(lineSp);

        // 鑽石
        var diamondSp = new cc.Sprite("#pic_diamond.png");
        diamondSp.setScale(0.8);
        diamondSp.setAnchorPoint(0, 0.5);
        diamondSp.setPosition(-5, 15);
        node.addChild(diamondSp);

        // 鑽石數
        var diamondNumLabel = new cc.LabelTTF(param.cost, JSFontName, 10);
        diamondNumLabel.setFontFillColor(JSColor.BLACK);
        diamondNumLabel.setAnchorPoint(0, 0.5);
        diamondNumLabel.setPosition(cc.pAdd(diamondSp.getPosition(), cc.p(diamondSp.getContentSize().width, 0)));
        node.addChild(diamondNumLabel);

        // 階級
        var classString = JSStringUtility.format("%s\n%s", competeString("鑽石階級"), param.className);
        var classLabel = new cc.LabelTTF(classString, JSFontName, 10);
        classLabel.setFontFillColor(JSColor.BLACK);
        classLabel.setAnchorPoint(0, 0.5);
        classLabel.setPosition(-5, -5);
        node.addChild(classLabel);

        // 下載圖示 loading
        var pos = cc.p(-56, -12);
        var loadingSp = new GSLoadingSprite();
        loadingSp.setScale(0.8);
        loadingSp.start();
        loadingSp.setColor(JSColor.BLACK);
        loadingSp.setPosition(pos);
        node.addChild(loadingSp);

        // 下載圖示
        var url = ShopItemBaseUrl + param.serial + ".png";
        var saveFileName = JSStringUtility.format("%sshop/%s.png", JSWriteablePath, param.serial + ".png");
        var iconSp = new GSDownloadSprite("", url, saveFileName, (isError) => {
            !(isError) && loadingSp.stop();
        });
        iconSp.setTargetSize(cc.size(60, 60));
        iconSp.setPosition(pos);
        node.addChild(iconSp);

        // 按鈕
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        node.addChild(menu);

        // 兌換按鈕
        var btnSize = cc.size(88, 26);
        var btnStrArray = [competeString("已兌換"), competeString("條件不符"), competeString("兌換")];
        var itemNodes = ButtonUtility.createArrayScale9Nodes(["lobby_btn_03.png", "lobby_btn_03.png", "lobby_btn_06.png"], btnSize);
        itemNodes.forEach((node, index) => {
            // 按鈕文字
            var label = node.label = new cc.LabelTTF(btnStrArray[param.status], JSFontName, 10);
            label.setFontFillColor(index === 2 ? JSColor.BLACK : JSColor.WHITE);
            label.setPosition(btnSize.width / 2, btnSize.height / 2);
            node.addChild(label);

            index === 2 && node.setOpacity(255);
        });
        var exchangeBtn = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._exchangeBtnClicked, this);
        exchangeBtn.setAnchorPoint(0, 0.5);
        exchangeBtn.setPosition(-5, -32);
        exchangeBtn.setEnabled(param.status >= 2);
        menu.addChild(exchangeBtn);
    },

    /**
     * 按鈕
     */
    // 點擊交換按鈕
    _exchangeBtnClicked: function () {
        // 跳詢問是否要更換
        DialogManager.addDialog(new AvatarDialog({
            content: JSStringUtility.format(LocalizedString.Compete("是否以%d顆鑽石兌換獎勵?"), this._param.cost),
            callback: (index) => {
                // 按確定要送的cmd
                if (index === 0) {
                    DataProcess.sendString("diamond_reward " + this._param.wid.toString());
                }
            }
        }));
    },
});