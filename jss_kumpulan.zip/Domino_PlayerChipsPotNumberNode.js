/**
 * 顯示彩池有多少錢的畫面
 */

var Domino_PlayerChipsPotNumberNode = cc.Node.extend({

    ctor: function () {
        this._super();

        this.setCascadeOpacityEnabled(true);
        this.setCascadeColorEnabled(true);

        this.nowMoney = 0;              // 現在的金錢 (要抓的話不要抓這個 因為有可能在跑動畫 抓最後金額請抓totalMoney)
        this.totalMoney = 0;            // 總共要跑到的金錢數字
        this._updateTime = 0.2;         // 更新數字要多久
        this._usedTime = 0;             // 現在花多久時間
        this._moneySpriteArray = [];    // 現在金錢的圖

        // 背景
        var bgSprite = new cc.Sprite("#domino_pic_pot_bg.png");
        this.addChild(bgSprite);

        // 小數點
        for (var i = 0; i < 3; i++) {
            var dotSprite = new cc.Sprite("#game_number_dot.png");
            dotSprite.setPosition(40 - (36.25 * i), 0);
            this.addChild(dotSprite);
        }

        // 數字
        var basePosX = 69;
        for (var i = 0; i < 10; i++) {
            var numberSprite = this._moneySpriteArray[i] = new cc.Sprite();
            numberSprite.setPosition(basePosX, 0);
            this.addChild(numberSprite);

            basePosX -= 10.5;

            if ((i + 1) % 3 === 0) {
                // 是小數點 要在位移
                basePosX -= 5;
            }
        }

        // 先設定是0
        this.setNowMoney(0, false);
    },

    cleanData: function () {
        this.nowMoney = 0;
        this.totalMoney = 0;
        this._updateMoney(0);
        this.unschedule(this._scheduleUpdateMoney);
    },

    /**
     * 設定現在多少錢
     */
    setNowMoney: function (nowMoney, isAnimation) {
        var len = arguments.length;
        if (len < 2)
            isAnimation = true;

        if (isAnimation) {
            this.totalMoney = nowMoney;
            this._floorNumber = this.nowMoney;
            this._usedTime = 0;

            if (this._floorNumber === this._totalMoney)
                return;

            this.unschedule(this._scheduleUpdateMoney);
            this.schedule(this._scheduleUpdateMoney);
        } else {
            this.totalMoney = nowMoney;
            this._floorNumber = this.nowMoney;
            this._scheduleUpdateMoney(999999)
        }
    },

    // 真正更新金錢的地方
    _updateMoney: function (money) {
        // 轉成string
        var moneyString = JSStringUtility.format("%010d", money);
        for (var i = 9; i >= 0; i--) {
            this._moneySpriteArray[i].setSpriteFrame(JSStringUtility.format("game_number_%s.png", moneyString[9 - i]));
        }
    },

    //運算
    _scheduleUpdateMoney: function (dt) {
        this._usedTime += dt;
        if (this._usedTime < this._updateTime)
            this.nowMoney = Math.floor(this._floorNumber + (this.totalMoney - this._floorNumber) * (this._usedTime / this._updateTime));
        else {
            this.unschedule(this.scheduleUpdateLabel);
            this.nowMoney = this.totalMoney;
        }

        this._updateMoney(this.nowMoney);
    },

    /**
     * 增加金額
     */
    addMoney: function (money) {
        this.setNowMoney(this.totalMoney + money);
    },
});