/**
 * 這邊存桌內共用的檔案列表
 */

var CommonGameFiles = [
    // Dialog相關
    "out_src/GameScene/CommonComponent/Dialog/BringMoneyDialog.js",
    "out_src/GameScene/CommonComponent/Dialog/GameBrokenRewardDialog.js",

    // 好友相關
    "out_src/GameScene/CommonComponent/Friend/FriendGameHintLayer.js",
    "out_src/GameScene/CommonComponent/Friend/InviteFriend/InviteFriendCell.js",
    "out_src/GameScene/CommonComponent/Friend/InviteFriend/InviteFriendListDialog.js",
    "out_src/GameScene/CommonComponent/Friend/InviteFriend/SitInviteNode.js",
    "out_src/GameScene/CommonComponent/Friend/InviteFriend/SitInviteNodesLayer.js",

    // 追蹤相關
    "out_src/GameScene/CommonComponent/GameFirebaseTracker.js",

    // 任務相關
    "out_src/GameScene/CommonComponent/GameMission/GapleGameGameMissionPageEventLayer.js",
    "out_src/GameScene/CommonComponent/GameMission/GapleGameMissionDialog.js",
    "out_src/GameScene/CommonComponent/GameMission/GapleGameMissionPageEventCell.js",
    "out_src/GameScene/CommonComponent/GameMission/GapleGameMissionPageEventRewardDialog.js",

    // 積分系統
    "out_src/GameScene/CommonComponent/GameRank/GameRankGameInfoDialog.js",
    "out_src/GameScene/CommonComponent/GameRank/GameRankGameLayer.js",
    "out_src/GameScene/CommonComponent/GameRank/GameRankGameNode.js",

    // 測試相關
    "out_src/GameScene/CommonComponent/GameReproduceLayer.js",
    "out_src/GameScene/CommonComponent/GameTestDebugLayer.js",

    // 語音相關
    "out_src/GameScene/CommonComponent/RealChat/RealChatIntroLayer.js",
    "out_src/GameScene/CommonComponent/RealChat/RealVideo/RealVideo_GameUtility.js",
    "out_src/GameScene/CommonComponent/RealChat/RealVideo/RealVideoGamePlayerNode.js",
    "out_src/GameScene/CommonComponent/RealChat/RealVideo/RealVideoLayer.js",
    "out_src/GameScene/CommonComponent/RealChat/RealVideo/SystemButton/RealVideoAudioButton.js",
    "out_src/GameScene/CommonComponent/RealChat/RealVideo/SystemButton/RealVideoVideoButton.js",
    "out_src/GameScene/CommonComponent/RealChat/RealVoice/RealVoiceIconNode.js",
    "out_src/GameScene/CommonComponent/RealChat/RealVoice/RealVoiceLayer.js",

    // 任務相關
    "out_src/GameScene/Texas/GameMission/Page/Texas_GameMissionPageEventCell.js",
    "out_src/GameScene/Texas/GameMission/Page/Texas_GameMissionPageEventNode.js",
    "out_src/GameScene/Texas/GameMission/Page/Texas_GameMissionPageRankCell.js",
    "out_src/GameScene/Texas/GameMission/Page/Texas_GameMissionPageRankNode.js",
    "out_src/GameScene/Texas/GameMission/Page/Texas_GameMissionPageRewardCell.js",
    "out_src/GameScene/Texas/GameMission/Page/Texas_GameMissionPageRewardNode.js",
    "out_src/GameScene/Texas/GameMission/Texas_GameMissionDialog.js",
    "out_src/GameScene/Texas/GameMission/Texas_GameMissionButton.js",
    "out_src/GameScene/Texas/GameMission/Texas_GameMissionTeachLayer.js",

    // 推廣提示
    "out_src/GameScene/Tournament/TournamentPromoteGameNode.js",
];