/**
 * 牌王地圖恭喜成為新牌王
 */

var CardKingMapCongratsDialog = BaseDialogLayer.extend({
    ctor: function (level) {
        this._super();

        this.key = "CardKingMapCongratsDialog";

        this.isLockBackKey = true;

        var aniLayer = this._animationLayer;

        // 光暈
        var lightSprite = new cc.Sprite("#lobby_bg_pink01.png");
        lightSprite.setAnchorPoint(0.5, 1);
        lightSprite.setScale(2, 2.6);
        lightSprite.setPosition(JSScreenMidPos.x, JSVisibleSize.height);
        aniLayer.addChild(lightSprite);

        // 光
        var bgLight = new cc.Sprite("#cardKing_pic_light_01.png");
        bgLight.setScale(2, 1.2);
        bgLight.setPosition(JSScreenMidPos.x, 232 + JSScreenBonusHalfHeight);
        aniLayer.addChild(bgLight, 1);

        // 背景
        var bgSprite = new ccui.Scale9Sprite("cardKing_pic_frame_02.png");
        bgSprite.setPreferredSize(cc.size(290, 148));
        bgSprite.setPosition(JSScreenMidPos.x, 127 + JSScreenBonusHalfHeight);
        aniLayer.addChild(bgSprite);

        // 皇冠
        var crownSp = new cc.Sprite("#lobby_pic_crown.png");
        crownSp.setPosition(JSScreenMidPos.x, 232 + JSScreenBonusHalfHeight);
        aniLayer.addChild(crownSp, 3);

        // 標題段帶, 彩帶
        for (var i = 0; i < 2; ++i) {
            var ribbonSp = new cc.Sprite("#lobby_pic_ribbon.png");
            ribbonSp.setPosition(182.5 + (147 * i) + JSScreenBonusHalfWidth, 182 + JSScreenBonusHalfHeight);
            ribbonSp.setFlippedX(i);
            aniLayer.addChild(ribbonSp, 4);

            var paperFlower = new cc.Sprite("#cardKing_pic_papeflower.png");
            var pos = (i === 0) ? cc.p(434 + JSScreenBonusHalfWidth, 161 + JSScreenBonusHalfHeight) : cc.p(93 + JSScreenBonusHalfWidth, 186 + JSScreenBonusHalfHeight);
            paperFlower.setFlippedX(i);
            paperFlower.setPosition(pos);
            aniLayer.addChild(paperFlower, 4);
        }

        // 標題
        var titleSp = new cc.Sprite("#cardKing_word_newRecord.png");
        titleSp.setPosition(JSScreenMidPos.x, 195 + JSScreenBonusHalfHeight);
        aniLayer.addChild(titleSp, 5);

        // 內文
        var contentLabel = new cc.LabelTTF(JSStringUtility.format(LocalizedString.CardKing("太強了!\n恭喜您成為\n牌王%d級\n蟬聯局數最高玩家"), level), JSFontName, 12);
        contentLabel.setPosition(JSScreenMidPos.x, 133 + JSScreenBonusHalfHeight);
        contentLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        aniLayer.addChild(contentLabel, 3);

        // 按鈕
        var button = ButtonUtility.createSimpleButton("lobby_btn_01.png", cc.size(76, 26), LocalizedString.CardKing("確定"), JSColor.BLACK, 14);
        button.setPosition(JSScreenMidPos.x, 81 + JSScreenBonusHalfHeight);
        button.addTouchUpInsideAction(this._closeDialogAnimation, this);
        aniLayer.addChild(button, 3);
    }
});