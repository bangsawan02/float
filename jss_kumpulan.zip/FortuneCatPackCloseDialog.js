/**
 * 5.3.7 招財貓駕到 關閉dialog
 */

var FortuneCatPackCloseDialog = BaseDialogLayer.extend({
    ctor: function (callback) {
        this._super();

        this.key = "FortuneCatPackCloseDialog";

        this._callback = callback;

        // 內容Node
        var contentNode = new cc.Node();
        contentNode.setCascadeOpacityEnabled(true);
        contentNode.setPosition(JSScreenMidPos);
        this._animationLayer.addChild(contentNode);

        var fortuneCat = LocalizedString.fortuneCat;

        // 背景
        var bg = new ccui.Scale9Sprite("pp_fortunecat_bg.png");
        bg.setPreferredSize(cc.size(300, 147));
        contentNode.addChild(bg);

        // 內文
        var contentLabel = new cc.LabelTTF(fortuneCat("遇見招財貓的機會難得\n確定要放棄加碼優惠嗎?"), JSFontName, 16);
        contentLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        contentLabel.setPosition(0, 10);
        contentNode.addChild(contentLabel, 1);

        // 左右按鈕
        var btnImages = ["pp_fortunecat_BT_02.png", "pp_fortunecat_BT_01.png"];
        var btnTitles = [fortuneCat("放棄"), fortuneCat("享優惠")];
        var btnPositionsX = [-57, 57];
        btnImages.forEach((image, idx) => {
            var btn = ButtonUtility.createSimpleButton(image, cc.size(110, 42), btnTitles[idx], JSColor.WHITE, 16);
            btn.addTouchUpInsideAction(this._buttonClicked, this);
            btn.setPosition(btnPositionsX[idx], -71);
            btn.idx = idx;
            contentNode.addChild(btn);
        });
    },

    /**
     * 按鈕
     */
    _buttonClicked: function (sender) {
        this._callback && this._callback(sender.idx);
        this._closeDialogAnimation();
    },
});