/**
 * Bonus機台 牌桌
 * 目前只有德撲有
 * Voice是用到Vegas_MusicUtility
 */
var BonusTableLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this._isFirstAnte = true;   // 是否第一次Ante

        var bonusStr = LocalizedString.Bonus;

        // 牌桌背景
        var bgSp = new cc.Sprite("vegas/bonus/bonus_table.jpg");
        bgSp.setPosition(JSScreenMidPos);
        this.addChild(bgSp);

        // Logo
        var logoSp = new cc.Sprite("#bonus_bet_logo.png");
        logoSp.setPosition(100 + JSScreenBonusHalfWidth, JSVisibleSize.height - 70 - JSScreenBonusHalfHeight);
        this.addChild(logoSp);

        // 棄牌區
        var resStr = (GS.theme === GSEnum.Theme.LEBARAN) ? "_lebaran" : "";
        var betDeckSp = new cc.Sprite(JSStringUtility.format("#bonus_bet_recover_deck%s.png", resStr));
        betDeckSp.setPosition(24 + JSScreenBonusHalfWidth, JSVisibleSize.height - 52 - JSScreenBonusHalfHeight);
        this.addChild(betDeckSp);

        // 發牌區
        betDeckSp = new cc.Sprite(JSStringUtility.format("#vegas_deck%s.png", resStr));
        betDeckSp.setPosition(JSVisibleSize.width - 24 - JSScreenBonusHalfWidth, JSVisibleSize.height - 52 - JSScreenBonusHalfHeight);
        this.addChild(betDeckSp);

        // 中間的五張牌背景
        BonusTableLayer.CARD_BG_POS_ARRAY = [];
        var posX = 174 + JSScreenBonusHalfWidth;
        var biasX = 40;
        var posY = JSVisibleSize.height - 77 - JSScreenBonusHalfHeight;
        [
            {title: "翻牌", extraBiasX: 0},
            {title: "翻牌", extraBiasX: 0},
            {title: "翻牌", extraBiasX: 0},
            {title: "轉牌", extraBiasX: 10},
            {title: "河牌", extraBiasX: 2}
        ].forEach((cur, idx) => {
            var pos = BonusTableLayer.CARD_BG_POS_ARRAY[idx] = cc.p(posX + cur.extraBiasX, posY);
            // 背景
            var bgSp = new cc.Sprite("#bonus_bet_bank_card_bg.png");
            bgSp.setPosition(pos);
            this.addChild(bgSp);
            // 文字
            var label = new cc.LabelTTF(bonusStr(cur.title), JSFontBoldName, 9);
            label.setOpacity(140);
            label.setPosition(pos);
            this.addChild(label);

            posX += (biasX + cur.extraBiasX);
        });

        // 中間的banner
        var bannerPos = cc.p(260 + JSScreenBonusHalfWidth, 178 + JSScreenBonusHalfHeight);
        var bannerSp = new cc.Sprite("#bonus_bet_table_banner.png");
        bannerSp.setScaleX(1.2);
        bannerSp.setPosition(bannerPos);
        this.addChild(bannerSp);

        // banner上的文字
        var bannerLabel = new cc.LabelTTF(bonusStr("順子以上的牌型獲勝，才可贏得底注等額獎勵"), JSFontName, 8);
        bannerLabel.setFontFillColor(cc.color(111, 189, 255));
        bannerLabel.setPosition(bannerPos);
        this.addChild(bannerLabel);

        // 提醒的文字
        var notifyNode = this._notifyNode = new cc.Node();
        notifyNode.setPosition(bannerPos);
        notifyNode.setVisible(false);
        this.addChild(notifyNode);

        var notifySp = new cc.Sprite("#bonus_bet_notice_bg.png");
        notifyNode.addChild(notifySp);

        var notifyLabel = this._notifyLabel = new cc.LabelTTF("", JSFontBoldName, 10);
        notifyNode.addChild(notifyLabel);

        // 下注的背景
        var placementNode = new cc.Node();
        placementNode.setPosition(JSScreenMidPos.x, 140 + JSScreenBonusHalfHeight);
        this.addChild(placementNode);

        var betSp = new cc.Sprite("#bonus_bet_bg.png");
        placementNode.addChild(betSp);

        // Ante, Flop, Turn, River, Bonus的放置點
        BonusTableLayer.BET_PLACEMENT_POS_ARRAY = [];
        this._placementNodes = [
            {title: "底注", pos: cc.p(8, -13)},
            {title: "翻牌", pos: cc.p(-27, 11)},
            {title: "轉牌", pos: cc.p(2, 11)},
            {title: "河牌", pos: cc.p(31, 11)},
            {isBonus: true, pos: cc.p(63, -9)}
        ].map((cur, idx) => {
            BonusTableLayer.BET_PLACEMENT_POS_ARRAY[idx] = placementNode.convertToWorldSpace(cur.pos);
            var betPlacementNode = new BonusBetPlacementNode(bonusStr(cur.title), !!cur.isBonus);
            betPlacementNode.pos = cur.pos;
            betPlacementNode.setPosition(cur.pos);
            placementNode.addChild(betPlacementNode, 1);
            return betPlacementNode;
        });

        // 放置點底下的光圈，用來表示目前到哪一個位置
        this._betLightSp = new cc.Sprite("#bonus_bet_current_light.png");
        this._betLightSp.setVisible(false);
        placementNode.addChild(this._betLightSp);
    },

    /**
     * 清空畫面
     */
    clean: function () {
        this.removeBetPlacementState();
        this.hideStateSp();
        this.dismissNotifyText();
    },

    /**
     * 隱藏下注區的光芒
     */
    hideStateSp: function () {
        this._betLightSp.setVisible(false);
    },

    /**
     * 移動下注區光芒
     */
    updateBetPlacementLightPos: function (gameState) {
        var pos;
        switch (gameState) {
            case BonusStateType.BET_ANTE:
                pos = this._placementNodes[0].pos;
                this._placementNodes[0].setIsSelected(true);
                break;
            case BonusStateType.BET_BONUS:
                this._placementNodes[0].setIsSelected(false);
                pos = this._placementNodes[4].pos;
                this._placementNodes[4].setIsSelected(true);
                break;
            case BonusStateType.FLOP_START:
                this._placementNodes[4].setIsSelected(false);
                pos = this._placementNodes[1].pos;
                this._placementNodes[1].setIsSelected(true);
                break;
            case BonusStateType.TURN_START:
                this._placementNodes[1].setIsSelected(false);
                pos = this._placementNodes[2].pos;
                this._placementNodes[2].setIsSelected(true);
                break;
            case BonusStateType.RIVER_START:
                this._placementNodes[2].setIsSelected(false);
                pos = this._placementNodes[3].pos;
                this._placementNodes[3].setIsSelected(true);
                break;
            default:
                return;
        }

        this._betLightSp.setPosition(pos);
        this._betLightSp.setVisible(true);
    },

    /**
     * 重設下注區並隱藏下注區光芒
     */
    removeBetPlacementState: function () {
        this._placementNodes.forEach(cur => cur.setIsSelected(false));
        this.hideStateSp();
    },

    /**
     * 關閉中間的提示文字
     */
    dismissNotifyText: function () {
        this._notifyNode.setVisible(false);
    },

    /**
     * 顯示中間可下注的提示
     * @param {BonusStateType} gameState
     */
    notifyCanBet: function (gameState) {
        this._showNotifyText(gameState);
        this.updateBetPlacementLightPos(gameState);
    },

    /**
     * 顯示中間的提示文字
     */
    _showNotifyText: function (gameState) {
        var bonusStr = LocalizedString.Bonus;

        switch (gameState) {
            case BonusStateType.BET_ANTE:
                if (this._isFirstAnte) {
                    Vegas_MusicUtility.playVoice("welcome.mp3");
                    this._isFirstAnte = false;
                }

                this._notifyLabel.setString(bonusStr("請選擇下注底注金額"));
                break;
            case BonusStateType.BET_BONUS:
                this._notifyLabel.setString(bonusStr("請選擇下注Bonus金額"));
                break;
            case BonusStateType.FLOP_START:
                this._notifyLabel.setString(bonusStr("請選擇是否下注翻牌"));
                break;
            case BonusStateType.TURN_START:
                this._notifyLabel.setString(bonusStr("請選擇是否下注轉牌"));
                break;
            case BonusStateType.RIVER_START:
                this._notifyLabel.setString(bonusStr("請選擇是否下注河牌"));
                break;
            default:
                break;
        }
        this._notifyNode.setVisible(true);
    }
});