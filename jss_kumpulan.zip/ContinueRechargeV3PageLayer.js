/**
 * 連續儲值 v3 - 金錢瘋暴 - Page Layer
 */
var ContinueRechargeV3PageLayer = class extends PurchaseTriggerIntegrationPageLayer_V2 {
    constructor(dialog) {
        super(dialog);

        this.key = "ContinueRechargeV3PageLayer";
        this.type = PurchaseTriggerIntegrationData.purchaseType.CONTINUE_RECHARGE_V3;

        this.loadFileArray = [
            'purchaseTriggerIntegration/continueRechargeV3.plist', 'purchaseTriggerIntegration/continueRechargeV3.png',
        ];

        /** @type {ContinueRechargeV3Data} */
        this._dataPtr = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(this.type);

        this._isFirstIn = true;

        /** @type{ContinueRechargeV3RewardNode[]} */
        this._rewardNodeArray = [];
    }

    onEnter() {
        super.onEnter();

        this._dataPtr.sendTrackingByKey("金錢瘋暴 >=8.7 進入金錢瘋暴活動頁");
    }

    loadFileDone() {
        super.loadFileDone();

        // 背景
        const bgSprite = new cc.Sprite("purchaseTriggerIntegration/continueRechargeV3_bg_01.jpg");
        bgSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y);
        this.addChild(bgSprite);

        // 標題
        const titleSprite = this._titleSprite = new cc.Sprite("#continueRechargeV3_w_logo.png");
        titleSprite.setPosition(JSScreenMidPos.x + 49, JSScreenMidPos.y + 110);
        titleSprite.setVisible(false);
        this.addChild(titleSprite);

        // 內容 node
        const contentLayer = this._contentLayer = new cc.Layer();
        contentLayer.setVisible(false);
        contentLayer.setCascadeOpacityEnabled(true);
        this.addChild(contentLayer);

        // 六個獎勵們
        this._rewardPositionArray = [
            cc.p(-83, 34),
            cc.p(48, 34),
            cc.p(180, 34),
            cc.p(180, -80),
            cc.p(48, -80),
            cc.p(-83, -80),
        ];

        // 五個箭頭
        const arrowLayer = contentLayer.arrowLayer = new cc.Layer();
        arrowLayer.arrowList = [];
        arrowLayer.setPosition(0, 0);
        arrowLayer.setCascadeOpacityEnabled(true);
        contentLayer.addChild(arrowLayer, 20);
        [
            {
                position: cc.p(-17, 29),
                rotation: 0,
            },
            {
                position: cc.p(115, 29),
                rotation: 0,
            },
            {
                position: cc.p(181, -25),
                rotation: 90,
            },
            {
                position: cc.p(115, -88),
                rotation: 180,
            },
            {
                position: cc.p(-17, -88),
                rotation: 180,
            },
        ].forEach((param) => {
            const arrowSprite = new cc.Sprite("#continueRechargeV3_pic_arrow.png");
            arrowSprite.setPosition(cc.pAdd(JSScreenMidPos, param.position));
            arrowSprite.setRotation(param.rotation);
            arrowLayer.addChild(arrowSprite);
            arrowLayer.arrowList.push(arrowSprite);
        });

        // 裝飾籌碼
        const chipsLayer = this._chipsLayer = new cc.Layer();
        chipsLayer.setPosition(0, 0);
        chipsLayer.setCascadeOpacityEnabled(true);
        chipsLayer.setVisible(false);
        this.addChild(chipsLayer, 2);
        [
            // 左側藍色籌碼
            {
                fileName: "#continueRechargeV3_pic_chip_1.png",
                position: cc.p(-167, -86),
                flippedX: true,
                rotation: -5,
                scale: 1,
            },
            // 右側上方藍色籌碼
            {
                fileName: "#continueRechargeV3_pic_chip_1.png",
                position: cc.p(282, -66),
                flippedX: true,
                rotation: 0,
                scale: 1,
            },
            // 右側下方藍色籌碼
            {
                fileName: "#continueRechargeV3_pic_chip_1.png",
                position: cc.p(253, -91),
                flippedX: false,
                rotation: 0,
                scale: 1,
            },
            // 左側紅色籌碼
            {
                fileName: "#continueRechargeV3_pic_chip_2.png",
                position: cc.p(-154, -50),
                flippedX: false,
                rotation: 5,
                scale: .8,
            },
            // 右側紅色籌碼
            {
                fileName: "#continueRechargeV3_pic_chip_2.png",
                position: cc.p(264, -18),
                flippedX: true,
                rotation: -6.4,
                scale: .8,
            },
        ].forEach((param) => {
            const sprite = new cc.Sprite(param.fileName);
            sprite.setPosition(cc.pAdd(JSScreenMidPos, param.position));
            sprite.setFlippedX(param.flippedX);
            sprite.setRotation(param.rotation);
            sprite.setScale(param.scale);
            chipsLayer.addChild(sprite);
        });

        // 倒數時間區域
        const remainTimeLabel = this._remainTimeLabel = new RemainTimeLabel(RemainTimeLabel.Style.WHITE);
        remainTimeLabel.setMultiFormat("%dd:%hh:%mm", "%hh:%mm:%ss", "%mm:%ss");
        remainTimeLabel.setPosition(160 + JSScreenBonusHalfWidth, 268 + JSScreenBonusHalfHeight);
        remainTimeLabel.setVisible(false);
        this.addChild(remainTimeLabel);

        // 說明按鈕
        const explainButton = new Texas_ExplainButton(this._explainBtnStyle);
        explainButton.setPosition(120 + JSScreenBonusHalfWidth, 268 + JSScreenBonusHalfHeight);
        explainButton.addTouchUpInsideAction(this._explainBtnClicked, this);
        this.addChild(explainButton, 1);

        // 註冊通知
        GS.addListener("NotifyContinueRechargeV3InfoDone", this.notifyContinueRechargeV3InfoDone.bind(this), this);
        GS.addListener("NotifyContinueRechargeV3StartPurchase", this.notifyContinueRechargeV3StartPurchase.bind(this), this);
        GS.addListener("NotifyContinueRechargeV3StartGetFreeReward", this.notifyContinueRechargeV3StartGetFreeReward.bind(this), this);
        GS.addListener("NotifyContinueRechargeV3ShowGuide", this.notifyContinueRechargeV3ShowGuide.bind(this), this);
        GS.addListener("NotifyContinueRechargeV3GetFreeRewardDone", this.notifyContinueRechargeV3GetFreeRewardDone.bind(this), this);
        GS.addListener("NotifyContinueRechargeV3RechargeDone", this.notifyContinueRechargeV3RechargeDone.bind(this), this);
        GS.addListener("NotifyContinueRechargeV3PageLayerShowHintLayer", this.notifyContinueRechargeV3PageLayerShowHintLayer.bind(this), this);

        // 卡loading
        this.setLoadingSprite(true, true);

        // 去要資料
        this._dataPtr.requestInfo();
    }

    _refreshView(param) {
        // 拿掉loading
        this.setLoadingSprite(false, false);

        if (!param.isSuccess) {
            this.showErrorDialog();
            return;
        }

        if (param.rewardInfoArray.length === 0) {
            this.showEventEndDialog();
            return;
        }

        // 刷新獎勵
        this._refreshRewardNodes(param.rewardInfoArray);

        // 倒數時間
        const remainTime = this._dataPtr.getRemainTime();
        this._remainTimeLabel.countdownSeconds(remainTime);
        this._remainTimeLabel.setVisible(true);

        // 紀錄每日小紅點
        this._dataPtr.recordDailyBadge();

        if (remainTime < 7200) {
            // 儲值剩餘時間剩 2hrs
            this._dataPtr.record2HrBadge();
        }

        // 首次進入才跑動畫
        if (this._isFirstIn) {
            this._isFirstIn = false;
            this._playFirstInAnimation();
        }
    }

    /**
     * 刷新獎勵
     * @param rewardInfoArray
     * @private
     */
    _refreshRewardNodes(rewardInfoArray) {
        if (rewardInfoArray.length === 0) {
            // 若沒有獎勵了，跳活動結束 dialog
            this.showEventEndDialog();
        }

        // 刷新獎勵
        for (let i = 0; i < 6; i++) {
            // 若無 rewardNode，建議一個
            const rewardNode = this._rewardNodeArray[i] = this._rewardNodeArray[i] ?? this._addNReturnRewardNode(i);
            const rewardParam = rewardInfoArray[i];

            if (rewardParam) {
                // 有資料
                rewardNode.setVisible(true);
                this._contentLayer.arrowLayer.arrowList[i - 1]?.setVisible(true);
                rewardNode.refreshView(rewardParam, i);
            } else {
                // 沒資料
                rewardNode.setVisible(false);
                this._contentLayer.arrowLayer.arrowList[i - 1]?.setVisible(false);
            }
        }
    }

    _addNReturnRewardNode(index) {
        const rewardNode = new ContinueRechargeV3RewardNode();
        rewardNode.setPosition(cc.pAdd(JSScreenMidPos, this._rewardPositionArray[index]));
        this._contentLayer.addChild(rewardNode, 19 - index);
        return rewardNode;
    }

    /**
     * 建立活動結束 dialog
     */
    _createEventEndDialog() {
        return new PurchaseTriggerIntegrationCommonDialog({
            contentArray: [
                LocalizedString.ContinueRechargeV3("已領取本期所有獎勵！感謝參與！"),
                LocalizedString.ContinueRechargeV3("(活動已完成，頁面將消失)"),
            ],
            callback: () => {
                // 活動結束
                this._dataPtr.closeEvent();
            }
        });
    }

    /**
     * 建立說明頁 dialog
     */
    _createInfoDialog() {
        return new WebViewDialog(TexasUtility.getSimpleInfoURLByKey("continue_recharge_v3"), "", null, true);
    }

    /**
     * 說明頁點擊
     */
    _explainBtnClicked() {
        this.showInfoDialog();
    }

    /**
     * 跑移動獎勵格動畫
     * @param {Object?} nextRewardParam 下一個獎勵資訊
     */
    _playRewardMovingAnimationAsync(nextRewardParam) {
        return new Promise((resolve, reject) => {
            if (this.__isDestroyed)
                return reject();

            // 箭頭淡出動畫
            this._contentLayer.arrowLayer.runAction(cc.sequence(
                cc.fadeOut(0.3),
                cc.callFunc(() => resolve())
            ));
        })
            // 開始跑移動動畫
            .then(() => {
                // 存所有一起做的動畫 promise 清單
                const animPromiseList = [];

                // 獎勵格陣列
                const rewardNodeArray = this._rewardNodeArray;

                // 座標陣列
                const positionArray = this._rewardPositionArray.map((pos) => cc.pAdd(JSScreenMidPos, pos));

                // 第一格離場動畫
                const firstNode = rewardNodeArray.shift();
                // 第二格 z-order = 18，比他低才可以被壓在下面
                firstNode.setLocalZOrder(17);

                animPromiseList.push(new Promise((resolve, reject) => {
                    if (this.__isDestroyed)
                        return reject();
                    firstNode.runAction(cc.sequence(
                        cc.scaleTo(0.3, 0),
                        cc.callFunc(() => resolve()),
                        cc.removeSelf()
                    ));
                }));

                // 其他獎勵格往前移動
                animPromiseList.push(rewardNodeArray.map((rewardNode, index) => new Promise((resolve, reject) => {
                    if (this.__isDestroyed)
                        return reject();
                    rewardNode.runAction(cc.sequence(
                        // 移動位置
                        cc.moveTo(0.3, positionArray[index]),
                        // 動畫完成
                        cc.callFunc(() => resolve())
                    ));
                })));

                // 第一個獎勵要跑解鎖鎖頭動畫
                if (rewardNodeArray[0]) {
                    animPromiseList.push(rewardNodeArray[0].playUnlockAnimAsync());
                }

                // 有資料才跑新獎勵格動畫
                if (nextRewardParam) {
                    // 建立新的獎勵格
                    const newRewardNode = this._addNReturnRewardNode(positionArray.length - 1);
                    newRewardNode.setScale(0);

                    // 塞資料
                    newRewardNode.refreshView(nextRewardParam, rewardNodeArray.length);

                    // 將新的獎勵格加入陣列
                    rewardNodeArray.push(newRewardNode);

                    // 新的獎勵格 scale in
                    animPromiseList.push(new Promise((resolve, reject) => {
                        if (this.__isDestroyed)
                            return reject();
                        newRewardNode.runAction(cc.sequence(
                            cc.scaleTo(0.3, 1),
                            cc.callFunc(() => resolve())
                        ));
                    }));
                }

                return Promise
                    // 所有動畫
                    .all(animPromiseList)
                    // 最後調整一下所有人的 z-order 與狀態
                    .then(() => {
                        if (this.__isDestroyed)
                            return Promise.reject();
                        rewardNodeArray.forEach((rewardNode, index) => {
                            rewardNode.setLocalZOrder(19 - index);

                            // 設定狀態
                            rewardNode.setAvailable(index === 0);
                            rewardNode.setLockVisible(index > 0);
                        });
                    });
            })
            // 箭頭淡入動畫
            .then(() => new Promise((resolve, reject) => {
                if (this.__isDestroyed)
                    return reject();

                const arrowLayer = this._contentLayer.arrowLayer;
                const arrowList = arrowLayer.arrowList;
                const rewardNodeArray = this._rewardNodeArray;

                // 根據 rewardNode 數量調整箭頭
                arrowList.forEach((sprite, index) => {
                    sprite.setVisible(rewardNodeArray[index + 1]?.isVisible());
                });

                arrowLayer.runAction(cc.sequence(
                    cc.fadeIn(0.3),
                    cc.callFunc(() => resolve())
                ));
            }));
    }

    /**
     * 首次進入動畫
     * @private
     */
    _playFirstInAnimation() {
        // 可視才跑動畫
        this.visibleSemaphore.acquire().then((key) => {
            if (this.__isDestroyed) {
                return;
            }

            this.visibleSemaphore.release(key);

            // 跑動畫中，鎖住不給切分頁
            this.setAllBtnEnabled(false);

            // 不給點擊
            this.setLoadingSprite(false, true);

            Promise.resolve()
                // 標題淡入與彈入
                .then(() => new Promise((resolve, reject) => {
                    if (this.__isDestroyed) {
                        return reject();
                    }

                    this._titleSprite.setScale(0);
                    this._titleSprite.setOpacity(0);
                    this._titleSprite.setVisible(true);
                    this._titleSprite.runAction(cc.spawn(
                        cc.fadeIn(0.3),
                        cc.sequence(
                            cc.scaleTo(0.2, 1.2).easing(cc.easeBackOut()),
                            // 此時即可跑下一步
                            cc.callFunc(() => resolve()),
                            cc.scaleTo(0.1, 1)
                        )
                    ));
                }))
                .then(() => Promise.all([
                    // 紅刺框放下動畫
                    ...this._rewardNodeArray.map((rewardNode) => rewardNode.playDropSaleAnimAsync()),

                    // 中央獎勵區淡入動畫
                    new Promise((resolve, reject) => {
                        if (this.__isDestroyed) {
                            return reject();
                        }

                        this._contentLayer.setVisible(true);
                        this._contentLayer.setOpacity(0);
                        this._contentLayer.runAction(cc.sequence(
                            cc.fadeIn(0.3),
                            cc.callFunc(() => resolve())
                        ));
                    })
                ]))
                // 籌碼淡入放下動畫
                .then(() => new Promise((resolve, reject) => {
                    if (this.__isDestroyed) {
                        return reject();
                    }

                    const chipsLayer = this._chipsLayer;
                    chipsLayer.setVisible(true);
                    chipsLayer.setOpacity(0);
                    chipsLayer.setPosition(0, 10);
                    chipsLayer.runAction(cc.spawn(
                        cc.fadeIn(0.3),
                        cc.sequence(
                            cc.moveTo(0.3, 0, 0),
                            cc.callFunc(() => resolve())
                        )
                    ));
                }))
                .catch((e) => console.error(e))
                .finally(() => {
                    if (this.__isDestroyed)
                        return;

                    // 動畫結束，開放切分頁
                    this.setAllBtnEnabled(true);

                    // 可以點擊
                    this.setLoadingSprite(false, false);
                });
        });
    }

    /**
     * 播放領獎成功動畫
     * @param {Object} nextRewardParam 下一個獎勵資訊
     * @private
     */
    _playCollectSuccessAnimAsync(nextRewardParam) {
        // 開始跑動畫
        // 鎖住不給點
        this.setLoadingSprite(false, true);

        // 鎖住不可切分頁
        this.setAllBtnEnabled(false);

        // 第一筆獎勵打勾
        return this._rewardNodeArray[0]?.playCollectSuccessAnimAsync()
            // 更新第二筆獎勵資訊
            .then(() => {
                const nextRewardNode = this._rewardNodeArray[1];
                nextRewardNode?.setAvailable(true);
            })
            // 獎勵格移動動畫
            .then(() => this._playRewardMovingAnimationAsync(nextRewardParam))
            .finally(() => {
                if (this.__isDestroyed)
                    return;
                // 動畫結束
                // 開放點擊
                this.setLoadingSprite(false, false);

                // 解鎖按鈕
                this.setAllBtnEnabled(true);
            });
    }

    /**
     * 通知拿到Info資訊
     */
    notifyContinueRechargeV3InfoDone(event) {
        if (event && event.getUserData()) {
            let param = event.getUserData();
            this._refreshView(param);
        }
    }

    /**
     * 通知開始儲值
     * @param event
     */
    notifyContinueRechargeV3StartPurchase(event) {
        if (event?.getUserData()) {
            this._startPurchase(event?.getUserData());
        }
    }

    /**
     * 通知開始領免費獎
     */
    notifyContinueRechargeV3StartGetFreeReward() {
        this.setLoadingSprite(true, true);
        this._dataPtr.sendGetFreeReward();
    }

    /**
     * 通知要顯示引導畫面
     */
    notifyContinueRechargeV3ShowGuide() {

    }

    /**
     * 通知拿到領獎資訊
     */
    notifyContinueRechargeV3GetFreeRewardDone(event) {
        if (event?.getUserData()?.isSuccess) {
            const param = event.getUserData();

            // 領免費獎成功
            const rewardDialog = new PurchaseTriggerIntegrationCommonDialog({
                titleStr: LocalizedString.ContinueRechargeV3("恭喜獲得"),
                contentArray: [param.rewardMsg],
                callback: () => {
                    // 移除第一筆獎勵
                    this._dataPtr.shiftRewardInfoArray();
                    // 播動畫
                    this._playCollectSuccessAnimAsync(this._dataPtr.rewardInfoArray[5])
                        .then(() => this._refreshRewardNodes(this._dataPtr.rewardInfoArray));
                },
            });
            this.showDialog(rewardDialog);
        }
    }

    /**
     * 通知儲值成功
     */
    notifyContinueRechargeV3RechargeDone(event) {
        if (event?.getUserData()?.isSuccess) {
            const param = event.getUserData();

            // 領免費獎成功
            const rewardDialog = new PurchaseTriggerIntegrationCommonDialog({
                titleStr: LocalizedString.ContinueRechargeV3("儲值成功！恭喜獲得"),
                contentArray: [param.rewardMsg],
                callback: () => {
                    // 移除第一筆獎勵
                    this._dataPtr.shiftRewardInfoArray();
                    // 播動畫
                    this._playCollectSuccessAnimAsync(this._dataPtr.rewardInfoArray[5])
                        .then(() => this._refreshRewardNodes(this._dataPtr.rewardInfoArray))
                        // 完成儲值
                        .then(() => this._finishPurchase());
                },
            });
            this.showDialog(rewardDialog);
        }
    }

    /**
     * 通知顯示提示訊息層
     */
    notifyContinueRechargeV3PageLayerShowHintLayer() {
        if (!this._hintLayer) {
            // 控制儲值整合視窗
            this.setCloseBtnVisible(false);
            this.setAllBtnEnabled(false);

            // 暫時提高自己的 z-order
            this.setLocalZOrder(22);

            // 提示訊息層需要蓋過所有東西，所以把 content layer 的 z-order 拉高
            this._contentLayer.setLocalZOrder(10);
            this._contentLayer.arrowLayer.setLocalZOrder(18);

            // 顯示第一個的訊息
            this._rewardNodeArray[0]?.setHintMessageVisible(true);

            const hintLayer = this._hintLayer = new cc.Layer();
            // 第一個獎勵格 z-order = 19、第二個獎勵格 z-order = 18、...
            this._contentLayer.addChild(hintLayer, 18);

            // 壓黑背景
            const maskLayer = new cc.LayerColor(cc.color(0, 0, 0, 220), JSVisibleSize.width, JSVisibleSize.height);
            maskLayer.setPosition(0, 0);
            hintLayer.addChild(maskLayer);

            // Touch layer，需要比所有獎勵高（z-order）
            const touchLayer = new DummyTouchLayer(JSVisibleSize);
            touchLayer.setPosition(0, 0);
            // TouchEnd 才跑，否則點在按鈕上會再次觸發此提示 layer
            touchLayer.setOnTouchEndedCallback(() => {
                // 點擊關閉
                this._rewardNodeArray[0]?.setHintMessageVisible(false);
                this._hintLayer.removeFromParent();
                this._hintLayer = null;

                // 還原 content layer z-order
                this._contentLayer.setLocalZOrder(0);
                this._contentLayer.arrowLayer.setLocalZOrder(20);

                // 清掉 touch layer
                touchLayer.removeFromParent();

                // 按鈕開回來
                this.setCloseBtnVisible(true);
                this.setAllBtnEnabled(true);

                // 還原自己的 z-order
                this.setLocalZOrder(1);
            });
            this.addChild(touchLayer, 20);
        }
    }

    createDebugTestObject() {
        return new TestMenuDebugObject("金錢瘋暴", {
            "info": () => DataProcess.sendCustomStringToSelf('continue_recharge_v3_info {"success":"1","serial":"1","timeLeft":"4","kind":"1","template":"1","img_rul":{"goods":"//d.mwsrv.com/19_60/store/iapp/download/payment/ID/","recharge":"//d.mwsrv.com/19_60/store/iapp/download/payment/ID/"},"plans":[{"price":"0","rewards":[{"name":"1,000","img":"5057"}],"pid":""},{"price":"60","rewards":[{"img":"5062","name":"62萬"},{"img":"7086","name":"10"}],"bonus":"105","productID":["texas9id_android_tmoney_1_30t_slotagain","texas9id_telkomsel_tmoney_1_25T_slotagain","texas9id_codapay_tmoney_1_30t_slotagain"],"topMsg":"Top-up Rp. 15,000 dapat 750jt chips+RP*300(Google Play)...","pic":["Google_01.png","Telkomsel_01.png","Codapay_SMS01.png"]},{"pid":"","price":"0","rewards":[{"img":"6053","name":"2"}]},{"price":"0","rewards":[{"name":"5,000","img":"5058"}],"pid":""},{"price":"0","rewards":[{"name":"8,000","img":"5058"}],"pid":""},{"rewards":[{"name":"2","img":"6058"}],"price":"0","pid":""},{"pid":"","rewards":[{"img":"7136","name":"5"}],"price":"0"},{"price":"60","rewards":[{"name":"70萬","img":"5062"},{"img":"7086","name":"10"}],"bonus":"119","pid":"bmj_android_tmoney_1_60t_null_moneycontinue_nocoupon"},{"pid":"","rewards":[{"name":"8,000","img":"5058"}],"price":"0"},{"rewards":[{"name":"3","img":"6097"}],"price":"0","pid":""},{"price":"0","rewards":[{"img":"7134","name":"3"}],"pid":""},{"price":"0","rewards":[{"img":"5060","name":"1.2萬"}],"pid":""},{"rewards":[{"name":"3","img":"6058"}],"price":"0","pid":""},{"rewards":[{"name":"80萬","img":"5062"},{"img":"7086","name":"10"}],"price":"60","pid":"bmj_android_tmoney_1_60t_null_moneycontinue_nocoupon","bonus":"135"},{"pid":"","price":"0","rewards":[{"img":"7086","name":"15"}]},{"pid":"","rewards":[{"name":"5","img":"6093"}],"price":"0"},{"pid":"","rewards":[{"name":"5","img":"6078"}],"price":"0"},{"pid":"","price":"0","rewards":[{"img":"5060","name":"3萬"}]},{"price":"0","rewards":[{"name":"10","img":"7086"}],"pid":""}]}'),
            "info 4獎": () => DataProcess.sendCustomStringToSelf('continue_recharge_v3_info {"success":"1","serial":"1","timeLeft":"94101","kind":"1","template":"1","img_rul":{"goods":"//d.mwsrv.com/19_60/store/iapp/download/payment/ID/","recharge":"//d.mwsrv.com/19_60/store/iapp/download/payment/ID/"},"plans":[{"price":"0","rewards":[{"name":"1,000","img":"5057"}],"pid":""},{"price":"60","rewards":[{"img":"5062","name":"62萬"},{"img":"7086","name":"10"}],"bonus":"105","productID":["texas9id_android_tmoney_1_30t_slotagain","texas9id_telkomsel_tmoney_1_25T_slotagain","texas9id_codapay_tmoney_1_30t_slotagain"],"topMsg":"Top-up Rp. 15,000 dapat 750jt chips+RP*300(Google Play)...","pic":["Google_01.png","Telkomsel_01.png","Codapay_SMS01.png"]},{"pid":"","price":"0","rewards":[{"img":"6053","name":"2"}]},{"price":"0","rewards":[{"name":"5,000","img":"5058"}],"pid":""}]}'),
            "info 7獎": () => DataProcess.sendCustomStringToSelf('continue_recharge_v3_info {"success":"1","serial":"1","timeLeft":"94101","kind":"1","template":"1","img_rul":{"goods":"//d.mwsrv.com/19_60/store/iapp/download/payment/ID/","recharge":"//d.mwsrv.com/19_60/store/iapp/download/payment/ID/"},"plans":[{"price":"0","rewards":[{"name":"1,000","img":"5057"}],"pid":""},{"price":"60","rewards":[{"img":"5062","name":"62萬"},{"img":"7086","name":"10"}],"bonus":"105","productID":["texas9id_android_tmoney_1_30t_slotagain","texas9id_telkomsel_tmoney_1_25T_slotagain","texas9id_codapay_tmoney_1_30t_slotagain"],"topMsg":"Top-up Rp. 15,000 dapat 750jt chips+RP*300(Google Play)...","pic":["Google_01.png","Telkomsel_01.png","Codapay_SMS01.png"]},{"pid":"","price":"0","rewards":[{"img":"6053","name":"2"}]},{"price":"0","rewards":[{"name":"5,000","img":"5058"}],"pid":""},{"price":"0","rewards":[{"name":"8,000","img":"5058"}],"pid":""},{"rewards":[{"name":"2","img":"6058"}],"price":"0","pid":""},{"pid":"","rewards":[{"img":"7136","name":"5"}],"price":"0"}]}'),
            "免費領獎": () => DataProcess.sendCustomStringToSelf('continue_recharge_v3_free {"success":"1","rewardMsg":"%E5%BE%B7%E6%92%B2%E5%B9%A3 X 1,000"}'),
            "過帳成功": () => DataProcess.sendCustomStringToSelf('continue_recharge_v3_recharge_done {"rewardMsg":"%E5%BE%B7%E6%92%B2%E5%B9%A3 X 113%E8%90%AC\\n%E5%AF%B6%E7%9F%B3 X 30","rewardList":{"-3523":"1130000","-3524":"30"},"success":"1"}'),
            "活動結束 dialog": () => this.showEventEndDialog(),
        });
    }
};