var Domino_PlayerCountDownNode = cc.Node.extend({

    ctor: function (callback) {
        this._super();

        this._callback = callback;
        this._greenColor = cc.color(0, 255, 0);

        var timer = this._timer = new Domino_PlayerProgressTimer(new cc.Sprite("#game_pic_circle.png"));
        timer.setPercentage(100);
        timer.setReverseDirection(true);
        timer.setColor(this._greenColor);
        this.addChild(timer);
    },

    start: function (sec, isSelf) {
        this.setVisible(true);
        this._timer.setColor(this._greenColor);
        this._timer.setPercentage(100);

        var _this = this;

        //progress動作
        var act = cc.progressFromTo(sec, 100, 0);
        this._timer.runAction(cc.sequence(act, cc.callFunc(function () {
            _this.stop();
        })));

        //是自己 要加倒數秒小於3秒提示音效
        if (isSelf) {
            var nowSec;
            var callFunc = cc.callFunc(function () {
                if (typeof nowSec === 'undefined')
                    nowSec = sec;

                nowSec--;

                if (nowSec < 0)
                    _this._timer.stopAction(callFunc);
                else if (nowSec < 3) {
                    MusicUtility.playEffect("Music/Effect/clockhurry.mp3");

                    // 判斷是否要震動
                    if (DataModal.settingData.domino.vibrateBefore3Sec && cc.sys.isNative) {
                        cc.Device.vibrate(0.2);
                    }
                }
            });
            this._timer.runAction(cc.repeatForever(cc.sequence(callFunc, cc.delayTime(1))));
        }
    },

    /**
     * 轉位完要重設，不然畫面會怪怪的
     */
    reset: function () {
        this.setVisible(false);
        this._timer.removeFromParent();

        var timer = this._timer = new Domino_PlayerProgressTimer(new cc.Sprite("#game_pic_circle.png"));
        timer.setPercentage(100);
        timer.setReverseDirection(true);
        timer.setColor(this._greenColor);
        this.addChild(timer);
    },

    stop: function () {
        this.setVisible(false);
        this._timer.stopAllActions();
        if (this._callback) {
            this._callback();
        }
    },
});

var Domino_PlayerProgressTimer = cc.ProgressTimer.extend({
    ctor: function (sprite) {
        this._super(sprite);

        this._colors = [
            cc.color(0, 255, 0),
            cc.color(0, 246, 81),
            cc.color(0, 255, 0),
            cc.color(194, 223, 43),
            cc.color(223, 213, 20),
            cc.color(255, 203, 1),
            cc.color(246, 171, 0),
            cc.color(239, 137, 1),
            cc.color(231, 103, 3),
            cc.color(222, 67, 1),
            cc.color(212, 35, 1),
            cc.color(203, 0, 0)
        ];
        this._unit = 100 / (this._colors.length - 1);
        this._previousColor = cc.color(0, 0, 0);
        this._len = this._colors.length;
    },


    setPercentage: function (percentage) {
        if (this._colors) {
            var index = Math.floor(percentage / this._unit);
            var color = this._colors[this._len - index - 1];
            if (!cc.colorEqual(this._previousColor, color)) {
                this._previousColor = color;
                this.setColor(color);

                this.stopActionByTag(19830617);
                var act = cc.tintTo(0.2, color.r, color.g, color.b);
                act.setTag(19830617);
                this.runAction(act);
            }
        }
        cc.ProgressTimer.prototype.setPercentage.call(this, percentage);
    },

});