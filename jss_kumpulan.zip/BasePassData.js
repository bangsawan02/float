/**
 * 通行證 - info 模板
 *
 * 使用中的系統：
 * + 農場賓果 PASS
 * + 深海 PASS
 *
 * @property {number}   errorCode
 * @property {number}   tokenCount     代幣數量
 * @property {string}   imgRootUrl     圖檔路徑
 * @property {boolean}  isPassUnlocked 是否解鎖pass獎勵
 * @property {Object}   purchaseParam  儲值資料
 * @property {object}   leaveParam     離開前提示
 * @property {object[]} rewardArray    獎勵資料
 */
var BasePassInfoData = cc.Class.extend({
    ctor: function () {
        this.errorCode = 1;
        this.tokenCount = 0;
        this.imgRootUrl = "";
        this.isPassUnlocked = false;
        this.purchaseParam = undefined;
        this.leaveParam = undefined;
        this.rewardArray = [];
    },

    isSuccess: function () {
        return this.errorCode === 0;
    },

    /**
     * 是否有可領的獎勵
     * @returns {boolean}
     */
    isObtainable: function () {
        return this.rewardArray.some(element => {
            let isFreeObtainable = element.freeReward && element.freeReward.status === BasePassRewardStatus.CAN_REWARD;
            let isPassObtainable = element.passReward && element.passReward.status === BasePassRewardStatus.CAN_REWARD;
            return isFreeObtainable || this.isPassUnlocked && isPassObtainable;
        });
    },

    parse: function (rawData) {
        let jsonValue = JSON.parse(rawData || "{}");
        this.errorCode = JSCodeUtility.getIntValue(jsonValue["error"], 1);

        if (this.errorCode === 0) {
            this.tokenCount = JSCodeUtility.getIntValue(jsonValue["stars"]);
            this.imgRootUrl = UrlUtils.normalize(jsonValue["img_url"], "//d.mwsrv.com/19_60/store/iapp/goods/");
            this.isPassUnlocked = JSCodeUtility.getBooleanValue(jsonValue["pass_unlocked"]);

            // 儲值資料
            if (jsonValue["recharge_info"]) {
                let imgUrl = UrlUtils.normalize(jsonValue["recharge_info"]["img_url"], "//d.mwsrv.com/19_60/store/iapp/download/payment/ID/");
                this.purchaseParam = {
                    valueMsg: JSCodeUtility.getStringValue(jsonValue["recharge_info"]["value_msg"]),
                    buttonMsg: JSCodeUtility.getIntValue(jsonValue["recharge_info"]["button_msg"]),
                    productParam: DataModal.purchaseData.processProviderChoosePurchase(jsonValue["recharge_info"]["product_list"], imgUrl, ["top_msg", "productID", "pic"])
                };
            }

            // 離開前提示
            if (jsonValue["leave_pop"]) {
                this.leaveParam = {
                    count: JSCodeUtility.getIntValue(jsonValue["leave_pop"]["count"]),
                    picFileName: JSCodeUtility.getStringValue(jsonValue["leave_pop"]["pic"])
                };
            }

            // 獎勵資料
            let freeRewards = jsonValue["free_rewards"] || [];
            let passRewards = jsonValue["pass_rewards"] || [];
            if (freeRewards.length > 0 || passRewards.length > 0) {
                let stepArray = freeRewards.map(element => JSCodeUtility.getIntValue(element["step"]))
                    .concat(passRewards.map(element => JSCodeUtility.getIntValue(element["step"])));
                this._startIndex = Math.min(...stepArray);
                freeRewards.forEach(element => this._parseSingleReward(element, false));
                passRewards.forEach(element => this._parseSingleReward(element, true));
            }
        }
    },

    /**
     * 解析單一獎勵
     * @param {object}  element         JSON 資料
     * @param {boolean} isPassReward    是否是通行證獎勵
     * @private
     */
    _parseSingleReward: function (element, isPassReward) {
        if (element) {
            let index = JSCodeUtility.getIntValue(element["step"]) - this._startIndex;
            let reward = {
                status: JSCodeUtility.getIntValue(element["status"]),
                picFileName: JSCodeUtility.getStringValue(element["pic"]),
                count: JSCodeUtility.getIntValue(element["count"]),
            };

            this.rewardArray[index] = this.rewardArray[index] || {
                step: JSCodeUtility.getIntValue(element["step"]),
                goal: JSCodeUtility.getIntValue(element["goal"]),
            };
            if (isPassReward) {
                this.rewardArray[index].passReward = reward;
            } else {
                this.rewardArray[index].freeReward = reward;
            }
        }
    },
});

/**
 * 通行證 reward 模板
 *
 * @property {number}       errorCode
 * @property {string[]}     msg
 * @property {object[]}     lockedRewardArray
 */
var BasePassRewardData = cc.Class.extend({
    ctor: function () {
        this.errorCode = 1;
        this.msg = [];
        this.lockedRewardArray = [];
    },

    isSuccess: function () {
        return this.errorCode === 0;
    },

    /**
     * 取得用來送 Event 的資料
     * @returns {{msgArray: string[], type: (number), rechargeRewardArray: Object[]}}
     */
    getEventParam: function () {
        return {
            type: this.lockedRewardArray.length > 0 ? BasePassDialogType.NOT_RECHARGE_GET_REWARD : BasePassDialogType.GET_REWARD,
            msgArray: this.msg,
            rechargeRewardArray: this.lockedRewardArray,
        };
    },

    parse: function (rawData) {
        let jsonValue = JSON.parse(rawData || "{}");
        this.errorCode = JSCodeUtility.getIntValue(jsonValue["error"], 1);

        if (this.errorCode === 0) {
            this.msg = (jsonValue["msg"] || []).map(element => JSCodeUtility.getStringValue(element));

            // 鎖住的獎勵
            if (jsonValue["locked_reward"]) {
                let lockedReward = jsonValue["locked_reward"];

                lockedReward["tmoney"] && this._parseSingleReward(lockedReward["tmoney"]);
                lockedReward["RP"] && this._parseSingleReward(lockedReward["RP"]);
                (lockedReward["normal_item"] || []).forEach(element => this._parseSingleReward(element));
            }
        }
    },

    /**
     * 解析單一獎勵
     * @param {object} jsonValue JSON 資料
     * @private
     */
    _parseSingleReward: function (jsonValue) {
        if (jsonValue && JSCodeUtility.getIntValue(jsonValue["count"]) > 0) {
            this.lockedRewardArray.push({
                picFileName: JSCodeUtility.getStringValue(jsonValue["pic"]),
                count: JSCodeUtility.getIntValue(jsonValue["count"]),
            });
        }
    }
});

/**
 * 儲值完成資料
 *
 * @property {number}   errorCode
 * @property {string[]} msgArray
 */
var BasePassRechargeDoneData = cc.Class.extend({
    ctor: function () {
        this.errorCode = 1;
        this.msgArray = [];
        this._isEventEnd = false;
    },

    isSuccess: function () {
        return this.errorCode === 0;
    },

    isEventEnd: function () {
        return this._isEventEnd;
    },

    parse: function (rawData) {
        let jsonValue = JSON.parse(rawData || "{}");
        this.errorCode = JSCodeUtility.getIntValue(jsonValue["error"], 1);
        if (this.errorCode === 0) {
            // recharge_reward: 儲值完後獲得德撲幣獎勵
            // event_reward:    獎勵訊息 只有剛好活動結束又剛好儲值完才會收到
            this.msgArray = (jsonValue["recharge_reward"] || [])
                .map(cur => JSCodeUtility.getStringValue(cur))
                .concat((jsonValue["event_reward"] || []).map(cur => JSCodeUtility.getStringValue(cur)));
            this._isEventEnd = !!jsonValue["event_reward"];
        }
    },
});

/**
 * 通行證資料解析器
 */
var BasePassDataParser = {
    /**
     * 解析 info 資料
     * @param {string} rawData
     * @returns {BasePassInfoData}
     */
    parseInfo: function (rawData) {
        let data = new BasePassInfoData();
        data.parse(rawData);
        return data;
    },

    /**
     * 解析領獎資料
     * @param {string} rawData
     * @returns {BasePassRewardData}
     */
    parseReward: function (rawData) {
        let data = new BasePassRewardData();
        data.parse(rawData);
        return data;
    },

    /**
     * 解析儲值資料
     * @param {string} rawData
     * @returns {BasePassRechargeDoneData}
     */
    parseRechargeDoneData: function (rawData) {
        let data = new BasePassRechargeDoneData();
        data.parse(rawData);
        return data;
    },

    /**
     * Normalize URL
     * @param {string}  rawUrl
     * @param {string?} defaultUrl
     * @returns {string}
     */
    parseUrl: function (rawUrl, defaultUrl) {
        let url = JSCodeUtility.getStringValue(rawUrl, defaultUrl);
        url = url.startsWith("//") ? GS.httpScheme + url : url;
        url = url.endsWith("/") ? url : (url + "/");
        return url;
    },
};