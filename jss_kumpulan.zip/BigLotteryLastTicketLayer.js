/**
 * 9T 幸運彩票 - 上期彩券 Layer
 */

var BigLotteryLastTicketLayer = BigLotteryHistoryBaseLayer.extend({
    ctor: function () {
        this._super();

        this._totalCellCount = 0;   // table view cell 數量

        // Domino移植設定 客製沒買彩券Node
        // 放頁面的Node
        var pageNode = this._pageNode = new cc.Node();
        this.addChild(pageNode);

        // 沒購買彩券Node
        var noTicketNode = this._noTicketNode = new cc.Node();
        noTicketNode.setVisible(false);
        this.addChild(noTicketNode);

        // 文字: 您上一期沒有購買任何彩券
        var noTicketLabel = new cc.LabelTTF(LocalizedString.BigLottery("您上一期沒有購買任何彩票"), JSFontName, 16);
        noTicketLabel.enableStroke(cc.color(190, 30, 0, 255), 2);
        noTicketLabel.setPosition(JSScreenMidPos.x, 114 + JSScreenBonusHalfHeight);
        noTicketNode.addChild(noTicketLabel);

        // 錢幣堆
        var coinSprite = new cc.Sprite("#bigLottery_pic_money.png");
        coinSprite.setPosition(464 + JSScreenBonusHalfWidth, 86);
        noTicketNode.addChild(coinSprite);

        // TableView
        var tableViewSize = cc.size(418, 210 + JSScreenBonusHeight);
        var mainLayer = this._mainLayer = new cc.Layer();
        var tableView = this._tableView = new cc.TableView(this, tableViewSize, mainLayer);
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setVisible(false);
        tableView.setPositionX(JSScreenMidPos.x - 209);
        this.addChild(tableView);

        // 這頁沒有子分頁，不需要側邊光
        this._sideSprite.setVisible(false);

        // 刷新畫面
        this._refreshView();
    },

    /**
     * 刷新畫面
     */
    _refreshView: function () {
        // 抓資料
        var historyParam = DataModal.bigLotteryData.historyParam;
        if (historyParam) {
            // 先清掉所有東西
            var mainLayer = this._mainLayer;
            mainLayer.removeAllChildren();

            // 有上期彩券資料
            if (historyParam.lastTicketList && historyParam.lastTicketList.length > 0) {

                // 把資料記起來
                var lastTicketList = this._lastTicketList = historyParam.lastTicketList;
                var totalCellCount = this._totalCellCount = lastTicketList.length + 1;   // 還有一個Top Cell 所以 + 1

                // 算top Cell高度
                var topCellPosY = (totalCellCount - 1) * BigLotteryMyTicketCell.HEIGHT;

                var topCell = new BigLotteryLastTicketTopCell();
                topCell.setPosition(0, topCellPosY);
                mainLayer.addChild(topCell);

                // 刷新table view
                this._tableView.reloadData(true);

                // 刷新畫面
                this._tableView.setVisible(true);
                // 關閉沒買彩票Node
                this._noTicketNode.setVisible(false);
            } else {
                this._totalCellCount = 0;

                // 刷新畫面
                this._tableView.setVisible(false);
                // 上期沒買彩券
                this._noTicketNode.setVisible(true);
            }
        }
    },

    /**
     * TableView delegate
     */

    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        // 創cell
        if (cell == null) {
            cell = new BigLotteryMyTicketCell();
            cell.setAnchorPoint(0, 0);
        }

        // 第一個不顯示 是top node
        cell.setVisible(idx !== 0);

        // 刷新cell
        var lastTicketList = this._lastTicketList;
        if (idx > 0 && idx <= lastTicketList.length) {
            var param = lastTicketList[idx - 1];
            cell.refreshCell(param);
        }

        return cell;
    },

    numberOfCellsInTableView: function (table) {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function (table, idx) {
        if (idx === 0)
            return cc.size(BigLotteryLastTicketTopCell.WIDTH, BigLotteryLastTicketTopCell.HEIGHT);
        else
            return cc.size(BigLotteryMyTicketCell.WIDTH, BigLotteryMyTicketCell.HEIGHT);
    }
});