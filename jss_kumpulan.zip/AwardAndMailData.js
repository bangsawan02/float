/**
 * 5.5.7大廳信件領獎整合
 * 移植自中文德撲 16.2大廳信件領獎整合
 *
 * v16.2 新增 副系統領獎
 *       修改 官方信件格式
 *
 * modified bt daniel
 */
var AwardAndMailData = cc.Class.extend({
    ctor: function () {
        // 初始化
        this.clean();

        // 註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            "award_and_mail": this.cmd_award_and_mail,
            "award_and_mail_icon": this.cmd_award_and_mail_icon,

            // 原禮物盒cmd
            "user_get_gift": this.cmd_get_gift,
            "user_get_money_gift": this.cmd_get_gift
        });
    },

    /**
     * 砍掉Data
     */
    destroyData: function () {
        DataProcess.removeSocketKeyDispatch(this);
    },

    /**
     * 清除資料
     */
    clean: function () {
        // 有沒有收到Icon cmd
        this.isGetIconData = false;

        // 放所有頁籤的小紅點數量
        this.tabBadgeCountObj = {
            awardBadgeCount: 0,     // 領獎頁籤的小紅點數量
            mailBadgeCount: 0,      // 信件頁籤的小紅點數量(未讀的數量)
            giftBadgeCount: 0       // 朋友禮物頁籤的小紅點數量
        };

        // 大廳小紅點刷新時間
        this.badgeRefreshTime = 0;

        // 大廳要顯示的小紅點數量(所有頁籤加總)
        this.totalBadgeCount = 0;

        // 全部頁籤中有無獎勵未領(要顯示有禮物)
        this.isReward = false;

        // 記錄資料的List
        this.awardList = undefined;
        this.mailList = undefined;
    },

    // 預設打開的頁籤
    getDefaultTab: function () {
        var defaultTab = AwardAndMailData.Group.OFFICIAL_MAIL;

        // 根據小紅點數量判斷
        var tabs = [{tab: AwardAndMailData.Group.SUBSYSTEM_AWARD, badgeCount: this.tabBadgeCountObj.awardBadgeCount},
            {tab: AwardAndMailData.Group.OFFICIAL_MAIL, badgeCount: this.tabBadgeCountObj.mailBadgeCount}];
        if (GS.isLuxyPoker)
            tabs.push({tab: AwardAndMailData.Group.AWARD_MESSAGE, badgeCount: this.tabBadgeCountObj.giftBadgeCount});

        // 有小紅點的話 預設小紅點頁籤排序最上者
        if (this.totalBadgeCount > 0) {
            for (let i = 0; i < tabs.length; i++) {
                if (tabs[i].badgeCount > 0) {
                    defaultTab = tabs[i].tab;
                    break;
                }
            }
        }

        return defaultTab;
    },

    // 送Icon cmd
    startGetIcon: function () {
        // 黑帳號沒有信箱功能
        if (DataModal.profileData.isBlackAccount)
            return;

        // 更新小紅點
        DataProcess.sendString("award_and_mail_icon");

        this.isGetIconData = false;
    },

    /**
     * 列表更新 傳頁籤的type, 0:action => 更新資料
     * @param type  目前只有 0:全部 1: 禮物盒 2:官方信件 5:副系統領取
     */
    sendAwardAndMailCmdToSever: function (type = AwardAndMailData.Group.OFFICIAL_MAIL) {
        // 黑帳號沒有信箱功能
        if (DataModal.profileData.isBlackAccount)
            return;

        DataProcess.sendString("award_and_mail " + JSON.stringify({
            type: type,
            action: AwardAndMailData.MailAction.UPDATE_DATA
        }));
    },

    // 領獎頁籤-更新動作
    updateAwardByParam: function (params) {
        var awardList = this.awardList;
        if (!awardList)
            return;

        var idx = awardList.indexOf(params);

        // 刪除這筆的資料
        awardList.splice(idx, 1);

        // 減少領獎的數量
        this.tabBadgeCountObj.awardBadgeCount--;
        this.totalBadgeCount--;

        // 目前 type=5 "領取" 只有領獎的動作
        DataProcess.sendString("award_and_mail " + JSON.stringify({
            type: AwardAndMailData.Group.SUBSYSTEM_AWARD,
            action: 1,
            fid: params.fid,
            rewardType: params.rewardType
        }));

        GS.dispatchCustomEvent("NotifyUpdateMailBadge");
    },

    // 信件頁籤-更新動作
    updateMailByParam: function (action, params) {
        if (!Array.isArray(params))
            params = [params];

        var mailList = this.mailList;
        if (!mailList)
            return;

        var sendParamList = [];

        params.forEach(cur => {
            var idx = mailList.indexOf(cur);
            // 列表裡有這封信
            if (idx > -1) {
                // 記下要送出的資訊 (Server:這邊送array過去 同舊版)
                sendParamList.push(cur.id);

                switch (action) {
                    case AwardAndMailData.MailAction.READ:
                        // 設成已讀
                        mailList[idx].isRead = 1;

                        // 減少未讀的數量
                        this.tabBadgeCountObj.mailBadgeCount--;
                        this.totalBadgeCount--;
                        break;
                    case AwardAndMailData.MailAction.DELETE:
                        // 如果未讀點開來直接刪除
                        if (mailList[idx].isRead === 0) {
                            // 減少未讀的數量
                            this.tabBadgeCountObj.mailBadgeCount--;
                            this.totalBadgeCount--;
                        }

                        // 刪除這筆的資料
                        mailList.splice(idx, 1);
                        break;
                    case AwardAndMailData.MailAction.GET_AWARD:
                        // 設成已領獎
                        mailList[idx].rewardState = 2;
                        break;
                }
            }

            GS.dispatchCustomEvent("NotifyUpdateMailBadge");
        });

        // type = 2 "信件"有三種動作 1:讀取 2:刪除 3:領取
        DataProcess.sendString("award_and_mail " + JSON.stringify({
            type: AwardAndMailData.Group.OFFICIAL_MAIL,
            action: action,
            id: sendParamList,
        }));
    },

    // 頁籤排序（領獎、禮物）
    // 原中文sortAward 但印尼多一個禮物所以整合一下
    sortList: function (list) {
        // 到期時間 快->慢
        list && list.sort((a, b) => {
            return a.remainTime - b.remainTime;
        });
    },

    // 信件頁籤排序
    sortMail: function () {
        // 1.isRead=0 未讀 >isRead=1 && rewardState=1 待領取 > isRead=1 已讀
        // 2.寄件時間 新 > 舊
        this.mailList && this.mailList.sort((a, b) => {
            var readValue = (a.isRead - b.isRead);
            var timeValue = (b.sendTime - a.sendTime);
            if (readValue === 0) {
                if (a.isRead === 1) {
                    // 已讀跟已讀再排
                    var aState = (a.rewardState === 1) ? 1 : 0;
                    var bState = (b.rewardState === 1) ? 1 : 0;
                    var rewardValue = bState - aState;
                    if (rewardValue === 0) {
                        return timeValue;
                    } else {
                        return rewardValue;
                    }
                } else {
                    // 未讀跟未讀再排
                    return timeValue;
                }
            } else {
                // 未讀跟已讀排
                return readValue;
            }
        });
    },

    // 移除過期的領獎
    purifyAwardArray: function () {
        // 如果 awardList 還沒初始化則不做事。
        if (!this.awardList)
            return;

        let expiredAwardArray = this.awardList.filter(cur => JSCodeUtility.getRemainTimeByParam(cur) <= 0);

        // 這邊先砍掉
        expiredAwardArray.forEach(cur => this.updateAwardByParam(cur));
    },

    // 移除過期的信件
    purifyMailArray: function () {
        // 如果 mailList 還沒初始化則不做事。
        if (!this.mailList)
            return;

        let expiredMailArray = this.mailList.filter(cur => JSCodeUtility.getRemainTimeByParam(cur) <= 0);

        // 這邊先砍掉
        expiredMailArray.forEach(cur => this.updateMailByParam(AwardAndMailData.MailAction.DELETE, cur));
    },

    refreshMailButtonStatus: function () {
        this.isReward = (this.tabBadgeCountObj.awardBadgeCount > 0) || (this.mailList && this.mailList.some(cur => cur.rewardState === 1)) || this.tabBadgeCountObj.giftBadgeCount > 0;
        GS.dispatchCustomEvent("NotifyUpdateLobbyMailButton");
    },

    refreshTotalBadgeCount: function () {
        // Lobby要顯示的小紅點數量
        this.totalBadgeCount = 0;
        Object.keys(this.tabBadgeCountObj).forEach(key => {
            this.totalBadgeCount += this.tabBadgeCountObj[key];
        });
    },

    /**
     * ===============
     * Socket Callback
     * ===============
     */
    /*
     小紅點數量 && 有無領獎 更新
     C -> S award_and_mail_icon
     S -> C award_and_mail_icon
     {
         "awardCount" : "0",
         "mailCount" : "0",
         "canReward" : "0"
     }
     */
    cmd_award_and_mail_icon: function (key, value) {
        // 擋個黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        this.isGetIconData = true;

        var jsonValue = JSON.parse(value || "{}");

        // 副系統領獎的小紅點數量
        this.tabBadgeCountObj.awardBadgeCount = JSCodeUtility.getIntValue(jsonValue["awardCount"]);

        // 信件的小紅點數量(未讀的數量)
        this.tabBadgeCountObj.mailBadgeCount = JSCodeUtility.getIntValue(jsonValue["mailCount"]);

        // 朋友禮物的小紅點數量
        this.tabBadgeCountObj.giftBadgeCount = JSCodeUtility.getIntValue(jsonValue["giftCount"]);

        // 是否有未領獎
        this.isReward = JSCodeUtility.getBooleanValue(jsonValue["canReward"]);

        // 刷新Lobby要顯示的小紅點數量
        this.refreshTotalBadgeCount();

        // 最短小紅點的刷新時間
        this.badgeRefreshTime = JSCodeUtility.getIntValue(jsonValue["refreshTime"]);

        // 小紅點有更新的話, List清空 等更新資料
        this.awardList = undefined;
        this.mailList = undefined;
        this.giftList = undefined;

        GS.dispatchCustomEvent("NotifyAwardAndMailIconDone");
        GS.dispatchCustomEvent("NotifyUpdateMailBadge");
    },

    /*
     更新頁籤的資料
     C -> S award_and_mail
     {
   	    "type" : "2 or 5",
	    "action" : "0"
     }
     領取頁的領獎
     C -> S award_and_mail
     {
   	    "type" : "5",
   	    "action" : "1",
   	    "fid" : "4271 or 4918",
   	    "rewardType" : ""
     }
     信件頁的各種動作(1讀取, 2刪除, 3領取)
     C -> S award_and_mail
     {
   	    "type"："2",
  	    "action"："1 or 2 or 3",
   	    "id" : []
     }

     回傳 type = 2 Server還會送一些這邊沒用的過來(tip count gift)就沒列在下面
     S -> C award_and_mail
     {
        "type": "2",
        "list": [
        {
          "read": "0",
          "button": {
            "button_word": "馬上前往",
            "type": "72"
          },
          "rewardList": [
            {
              "count": "9999.9億",
              "wid": "5005"
            },
            {
              "wid": "7086",
              "count": "x100"
            }
          ],
          "reward": "1",
          "subject": "【武鬥】競技場可以挑戰了!",
          "time": "1694073750",
          "mailContent": "<body bgcolor=\"white\">您累積的能量已充足！<br>快到<font color='red'>武鬥競技場挑戰對手</font>吧！<br><br>小提醒:亦可於大廳介面左滑至後方，即可看到武鬥入口 <base button=\"馬上前往\" type=\"72\"></body>",
          "id": "102274167",
          "type": "0",
          "remainTime": "261642",
          "rewardMsg": "德撲幣9999.9億\n寶石x100\n其他道具(天)"
        }
      ]
     }
     回傳 type = 5
     S -> C award_and_mail
     {
        "type" : "5",
        "list" : [
         {
          "remainTime": "5100",
          "fid": "4271",
          "rewardType": "1",
          "subject": "恭喜獲得豐收榜第1名～快來領排行獎勵！",
          "mailContent": "德撲幣100\n寶石x100",
          "title": "Kejuaraan Luxy"
        }
      ]
     }
     */
    cmd_award_and_mail: function (key, value) {
        // 擋個黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value || "{}");

        /**
         * 這邊action傳什麼過去 Server就會傳什麼回來
         * action=0 才要更新資料, action>0 都去更新紅點
         */
        var action = JSCodeUtility.getIntValue(jsonValue["action"]);
        if (action > 0) {
            this.isReward = (this.tabBadgeCountObj.awardBadgeCount > 0) || (this.mailList && this.mailList.some(cur => cur.rewardState === 1)) || this.tabBadgeCountObj.giftBadgeCount > 0;
            GS.dispatchCustomEvent("NotifyAwardAndMailIconDone");
            GS.dispatchCustomEvent("NotifyUpdateLobbyMailButton");
            return;
        }

        var listValue = jsonValue["list"] || [];

        // 目前只有 2:官方信件 5:副系統領取
        var type = JSCodeUtility.getIntValue(jsonValue["type"]);

        // 收到未定義的type要過濾掉
        var knownType = true;

        switch (type) {
            // 官方信件
            case AwardAndMailData.Group.OFFICIAL_MAIL:
                // 重新計算小紅點數量
                var badgeCount = 0;

                // 信件們的資料
                this.mailList = listValue.map(value => {
                    var param = {
                        // 目前的種類 0:官方公告, 1:好康通知 , 2:活動通知, 3:VIP專屬, 4:VVIP尊函, 5:其他玩家的信
                        // 因為新舊版共用cmd 5.5.7以上(新版)的使用category  5.5.7以下(舊版)的會使用type(這個key在server那邊有使用到)
                        type: JSCodeUtility.getIntValue(value["category"]),

                        // 主旨
                        subject: JSCodeUtility.getStringValue(value["subject"]),

                        // 寄件時間
                        sendTime: JSCodeUtility.getIntValue(value["time"]),

                        // 倒數時間
                        remainTime: JSCodeUtility.getIntValue(value["remainTime"]),

                        // 信件ID
                        id: JSCodeUtility.getStringValue(value["id"]),

                        // 信件狀態 0:未讀, 1:已讀
                        isRead: JSCodeUtility.getIntValue(value["read"]),

                        // 獎勵狀態 0:無獎勵, 1:未領獎, 2:已領獎
                        rewardState: JSCodeUtility.getIntValue(value["reward"]),

                        // 網頁內容
                        mailContent: JSCodeUtility.getStringValue(value["mailContent"]),

                        // 領獎Dialog內容
                        rewardMsg: JSCodeUtility.getStringValue(value["rewardMsg"])
                    };

                    // 用舊版本(<5.5.7)寄信，用新版本收信的話，category分不出官方信和玩家信。要另外hack
                    // 新分類是官方信&&舊分類是私人信時 改成新分類的私人信
                    if (param.type === MailCell.Type.OFFICIAL_MESSAGE &&
                        JSCodeUtility.getIntValue(value["type"]) === AwardAndMailData.Group.PRIVATE_MAIL)
                        param.type = MailCell.Type.PLAYER_MESSAGE;

                    param.socketTime = JSCodeUtility.getNowTime();

                    // 獎勵列表 至多三個
                    var rewardListValue = value["rewardList"] || [];
                    param.rewardList = rewardListValue.map(reward => {
                        return {
                            // 獎勵圖片 Domino移植設定：接字串而不是數字
                            imageId: JSCodeUtility.getStringValue(reward["wid"]),

                            // 數量文字(包含單位 x多少、多少天)
                            countString: JSCodeUtility.getStringValue(reward["count"])
                        };
                    });

                    // 其他按鈕
                    var buttonValue = value["button"] || {};
                    var button = param.button = {};
                    // 按鈕連結網址
                    button.url = JSCodeUtility.getStringValue(buttonValue["url"]);

                    // 按鈕連結Type
                    button.type = JSCodeUtility.getIntValue(buttonValue["type"]);

                    // 按鈕文字
                    button.buttonWord = JSCodeUtility.getStringValue(buttonValue["button_word"]);

                    // 剩餘時間
                    button.remainTime = JSCodeUtility.getIntValue(buttonValue["time_left"], -1);

                    // 當前時間
                    button.socketTime = param.socketTime;

                    // 重算未讀信數量
                    if (param.isRead === 0)
                        badgeCount++;

                    return param;
                });

                // 刷新信件頁籤小紅點數量
                this.tabBadgeCountObj.mailBadgeCount = badgeCount;

                break;

            // 領取訊息
            case AwardAndMailData.Group.SUBSYSTEM_AWARD:
                // 領取的資料
                this.awardList = listValue.map(value => {
                    var param = {
                        // 主旨 獎勵內文
                        subject: JSCodeUtility.getStringValue(value["subject"]),

                        // 倒數時間
                        remainTime: JSCodeUtility.getIntValue(value["remainTime"]),

                        // 點領取後的Dialog內文 => 獎勵名稱x數量 \n
                        mailContent: JSCodeUtility.getStringValue(value["mailContent"]),

                        // FID
                        fid: JSCodeUtility.getIntValue(value["fid"]),

                        // 分群
                        group: JSCodeUtility.getIntValue(value["group"]),

                        // 獎項Type (領取時回給Server用)
                        rewardType: JSCodeUtility.getIntValue(value["rewardType"]),

                        // 副系統名稱
                        title: JSCodeUtility.getStringValue(value["title"]),
                    };

                    param.socketTime = JSCodeUtility.getNowTime();

                    return param;
                });
                // 排序領獎
                this.sortList(this.awardList);

                // 刷新領取頁籤小紅點數量
                this.tabBadgeCountObj.awardBadgeCount = this.awardList.length;

                break;

            // 朋友禮物
            case AwardAndMailData.Group.AWARD_MESSAGE:
                this.giftList = listValue.map(value => {
                    var param = {
                        // 主旨 獎勵內文
                        subject: JSCodeUtility.getStringValue(value["subject"]),

                        // 倒數時間
                        remainTime: JSCodeUtility.getIntValue(value["remainTime"]),

                        // 信件id
                        id: JSCodeUtility.getStringValue(value["id"]),

                        // 寄件人
                        sender: JSCodeUtility.getStringValue(value["sender"]),

                        // 寄件時間
                        date: JSCodeUtility.getIntValue(value["time"]),

                        // 禮物
                        giftType: JSCodeUtility.getIntValue(value["gift"]),
                    };

                    param.socketTime = JSCodeUtility.getNowTime();

                    return param;
                });
                // 排序領獎
                this.sortList(this.giftList);

                // 刷新領取頁籤小紅點數量
                this.tabBadgeCountObj.giftBadgeCount = this.giftList.length;

                break;

            default:
                knownType = false;
        }

        // 通知
        knownType && GS.dispatchCustomEvent("NotifyAwardAndMailDone", type);
    },

    cmd_get_gift: function (key, value) {
        var jsonValue = JSON.parse(value || "{}");

        // 1 成功 0 失敗
        var code = JSCodeUtility.getIntValue(jsonValue["code"]);
        if (code === 1) {

            // 信件id
            var id = JSCodeUtility.getStringValue(jsonValue["mail_id"]);

            // 禮物一次只會有一個品項
            var item = JSCodeUtility.getStringValue(jsonValue["item_name"]);

            // 數量
            var count = JSCodeUtility.getIntValue(jsonValue["count"]);

            // 取得送信人的account, 用於回禮上面
            var account = "";
            this.giftList && this.giftList.forEach((param, index) => {
                if (param.id === id) {
                    account = param.sender;
                }
            });

            GS.dispatchCustomEvent("NotifyMailReceiveGift", {
                "code": code,
                "item": item,
                "count": count,
                "account": account
            });
        } else {
            // 錯誤訊息
            var message = JSCodeUtility.getStringValue(jsonValue["msg"]);
            GS.dispatchCustomEvent("NotifyMailReceiveGift", {"code": code, "message": decodeURIComponent(message)});
        }

        // 拿掉loading
        GS.dispatchCustomEvent("NotifyAwardAndMailLoading", false);
    }
});

// 信件的類型, 對應server的定義
AwardAndMailData.Group = {
    ALL_MAIL: 0,            // 拿全部信件清單
    AWARD_MESSAGE: 1,       // 領獎訊息 (Server:印尼有在用,跟5不一樣)
    OFFICIAL_MAIL: 2,       // 官方信件
    PRIVATE_MAIL: 3,        // 私人信件
    WRITE_MAIL: 4,          // 寫信
    SUBSYSTEM_AWARD: 5      // 副系統領獎
};

// 信件的操作
AwardAndMailData.MailAction = {
    UPDATE_DATA: 0,      // 更新資料
    READ: 1,             // 已讀
    DELETE: 2,           // 刪除
    GET_AWARD: 3,        // 領獎
};
