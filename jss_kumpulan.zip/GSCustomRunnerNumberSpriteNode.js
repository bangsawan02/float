/**
 * 可以自訂數字跑動的方式的numberSpriteNode
 * </br>
 * 用法:
 * ```js
 * let customRunnerNumberNode = new GSCustomRunnerNumberSpriteNode(SlotCommonNumberSpriteConfig.num_y13);
 * customRunnerNumberNode.setRunner(new GSEaseNumberRunner({easeFunction: (t) => t * t})); // 使用二次方ease函數
 * ```
 * </br>
 * created by terry.chuang 2025/7/17
 */
var GSCustomRunnerNumberSpriteNode = class extends AutoScaleStringSpriteNode {
    constructor(spriteConfig, limitedSize = cc.size(0, 0)) {
        super(spriteConfig, limitedSize);

        // 跑數字的
        let runner = this._runner = new GSNumberRunner();
        runner.setNumberChangeCallback(this._onNumberChange.bind(this));
        runner.setNumberUpdateDoneCallback(this._onNumberUpdateDone.bind(this));

        // 依據設定的去顯示數字
        this._customFormatNumberFunc = (number) => number.toString();
        this._numberUpdateDoneCallback = undefined; // 數字更新完成的回調
        this._numberChangeCallback = undefined; // 數字變化的回調
    }

    /**
     * 設定自訂的數字跑動runner
     * @param runner
     */
    setRunner(runner) {
        this._runner = runner;

        runner.setNumberChangeCallback(this._onNumberChange.bind(this));
        runner.setNumberUpdateDoneCallback(this._onNumberUpdateDone.bind(this));
    }

    /**
     * 更新數字
     * @param {number} dt 經過的秒數
     */
    scheduleUpdateNumber(dt) {
        this._runner.update(dt);
    }

    /**
     * 直接停止數字動畫,並且跳到最後的數字
     */
    stopAnimAndToTotalNumber() {
        this.unschedule(this.scheduleUpdateNumber);
        this.setNumber(this._runner.getTargetNumber());
        this._display();
    }

    /**
     * 設定數字更新完成的回調
     * @param {(number) => void} callback
     */
    setNumberUpdateDoneCallback(callback) {
        this._numberUpdateDoneCallback = callback;
    }

    /**
     * 設定數字變化的回調
     * @param {(number) => void} callback
     */
    setNumberChangeCallback(callback) {
        this._numberChangeCallback = callback;
    }

    /**
     * 設定自定義的數字格式化函數
     * @param {(number) => string} func
     */
    setCustomFormatFunc(func) {
        this._customFormatNumberFunc = func;
        this._display();
    }

    /**
     * 設定更新的時間長度
     * @param {number} updateTime 更新時間(秒)
     */
    setUpdateTime(updateTime) {
        this._runner.setUpdateTime(updateTime);
    }

    /**
     * 直接設定目前數字
     * @param number
     */
    setNumber(number) {
        this._runner.setNowNumber(number);
        this._display();
    }

    /**
     * 設定目標數字，並且開始更新
     * @param {number} toNumber 要更新到的數字
     * @param {number} duration 更新需要的時間
     */
    updateToNumber(toNumber, duration = GSNumberRunner.DefaultUpdateTime) {
        duration = JSCodeUtility.getFloatValue(duration, GSNumberRunner.DefaultUpdateTime);

        // 有倒數時間以及目標數字是不同才有動畫
        if (duration > 0 && toNumber !== this._runner.getTargetNumber()) {
            this._runner.setupRunner(toNumber, duration);
            this._display();
            this.unschedule(this.scheduleUpdateNumber);
            this.schedule(this.scheduleUpdateNumber);
        } else {
            this.setNumber(toNumber);
        }
    }

    /**
     * 取得當前顯示的數字
     * @returns {number}
     */
    getNowNumber() {
        return this._runner.getNowNumber();
    }

    /**
     * 獲取目標數字
     * @returns {number}
     */
    getNumber() {
        return this._runner.getTargetNumber();
    }

    /**
     * 去顯示目前要顯示的數字
     */
    _display() {
        this.setDisplayString(this._getNumberString(this._runner.getNowNumber()));
    }

    /**
     * 取得數字的字串表示
     * @param {number} number 要轉換的數字
     * @returns {string}
     */
    _getNumberString(number) {
        return this._customFormatNumberFunc(number);
    }

    /**
     * 數字變化的回調
     * @param {number} number 當前數字
     */
    _onNumberChange(number) {
        this._display();
        this._numberChangeCallback && this._numberChangeCallback(number);
    }

    /**
     * 數字更新完成的回調
     * @param {number} number 最終數字
     */
    _onNumberUpdateDone(number) {
        this.unschedule(this.scheduleUpdateNumber);
        this._numberUpdateDoneCallback && this._numberUpdateDoneCallback(number);
    }
}