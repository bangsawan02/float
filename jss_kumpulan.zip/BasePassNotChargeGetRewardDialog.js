/**
 * 通行證 - 無儲值獲獎 dialog
 *```
 * Sample config: {
 *     getRewardNodeSpacing: 5,                         // 獎勵之間的間距
 *     getRewardNodeScale: 0.7,                         // 獎勵縮放倍率
 *     getRewardDialogTitleFileName: "",                // 獎勵 dialog 標題圖
 *     getRewardNodeContextTitleFileName: "",           // 獎勵 dialog 內文標題圖
 *
 *     tableViewNodeClass: BasePassNormalRewardNode,    // 獎勵 node class
 *     messageDialogBgFileName: "",                     // dialog 背景
 *     messageDialogFontColor: JSColor.WHITE,           // Default font color
 *
 *     // 購買按鈕自訂文字相關設定
 *     purchaseBtnMessage: "",                          // 購買按鈕顯示的文字
 *     purchaseBtnDiscountMessage: "",                  // 購買按鈕折扣標籤文字
 *     purchaseBtnAlwaysUseDiscountMessage: false,      // 是否總是使用折扣訊息
 *     purchaseBtnDiscountFontSize: 10,                 // 折扣標籤字體大小
 *     purchaseBtnIsShowPrice: true,                    // 要不要顯示價格
 * }
 *
 * Param: {
 *     msgArray: Array,                                 // 獎勵文字
 *     rechargeRewardArray: Array,                      // 儲值獎勵
 *     productParam: Object,                            // 儲值參數
 *     skipDefaultPurchase: Boolean,                    // 是否跳過預設的儲值行為（預設 false）
 *     purchaseBtnOnClick: Function,                    // 自定義購買按鈕點擊事件
 *
 *     // 購買按鈕文字自訂參數（會覆蓋 config 中的設定）
 *     purchaseBtnMessage: String,                      // 購買按鈕顯示的文字
 *     purchaseBtnDiscountMessage: String,              // 購買按鈕折扣標籤文字
 *     purchaseBtnAlwaysUseDiscountMessage: Boolean,    // 是否總是使用折扣訊息
 *     purchaseBtnDiscountFontSize: Number,             // 折扣標籤字體大小
 *     purchaseBtnIsShowPrice: Boolean,                 // 要不要顯示價格
 * }
 * ```
 */
var BasePassNotChargeGetRewardDialog = BaseDialogLayer.extend({
    ctor: function (config, param) {
        this._super();

        this.key = "BasePassNotChargeGetRewardDialog";
        this._config = config;
        this._param = param;
        this._rewardItemNodeClass = config.tableViewNodeClass || BasePassNormalRewardNode;
        this._cellSpacing = config.getRewardNodeSpacing || 5;
        this._itemScale = config.getRewardNodeScale || 0.7;

        let bgFileName = config.messageDialogBgFileName || "luxyPass_bg_frame.png";
        let titleFileName = config.getRewardDialogTitleFileName || "luxyPass_word_title_04.png";
        let contextTitleFileName = config.getRewardNodeContextTitleFileName || "luxyPass_word_title_07.png";
        let contextBgSpriteFileName = config.getRewardNodeContextBgFileName || "luxyPass_bg_red_02.png";
        let fontColor = config.messageDialogFontColor || JSColor.WHITE;
        let msgArray = param.msgArray;
        let rewardArray = param.rechargeRewardArray;
        let purchaseParam = param.purchaseParam;

        let animationLayer = this._animationLayer;

        // 背景
        let bgSprite = new ccui.Scale9Sprite(bgFileName);
        bgSprite.setPreferredSize(cc.size(349, 238.5));
        bgSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 5);
        animationLayer.addChild(bgSprite);

        // 標題圖片
        let titleSprite = new cc.Sprite("#" + titleFileName);
        titleSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 107);
        animationLayer.addChild(titleSprite);

        // 大片的彩帶
        for (let i = 0; i < 2; i++) {
            let ribbonSprite = new cc.Sprite("#luxyPass_pic_papperflower_01.png");
            ribbonSprite.setPosition(JSScreenMidPos.x - 207.5 + 415 * i, JSScreenMidPos.y + 72);
            ribbonSprite.setFlippedX(i === 1);
            animationLayer.addChild(ribbonSprite);
        }

        // 小片的彩帶
        [cc.p(212.5, 3), cc.p(188.5, -23), cc.p(-208, -42), cc.p(-212.5, 3), cc.p(-188.5, -23), cc.p(208, -42)].forEach((cur, index) => {
            let smallRibbonSprite = new cc.Sprite("#luxyPass_pic_papperflower_0" + (index % 3 + 2) + ".png");
            smallRibbonSprite.setPosition(cc.pAdd(JSScreenMidPos, cur));
            smallRibbonSprite.setFlippedX(Math.floor(index / 3) === 1);
            animationLayer.addChild(smallRibbonSprite);
        });

        // 上面的獲得獎勵 一行一個 少於3個獎勵直接顯示，否則用加ScrollView
        if (msgArray.length < 3) {
            let messageLabel = new cc.LabelTTF(msgArray.join("\n"), JSFontName, 10, cc.size(315, 0));
            messageLabel.setColor(fontColor);
            messageLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            messageLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 56);
            animationLayer.addChild(messageLabel);
        } else {
            // 加ScrollView
            let scrollViewSize = cc.size(315, 30);
            let mainLayer = new cc.Layer();
            let scrollView = new cc.ScrollView(scrollViewSize, mainLayer);
            scrollView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
            scrollView.setPosition(JSScreenMidPos.x - scrollViewSize.width / 2, JSScreenMidPos.y + 56 - scrollViewSize.height / 2);
            animationLayer.addChild(scrollView);

            // 文字排版的node
            let layoutNode = new GSAutoLayoutNode();
            layoutNode.setType(GSAutoLayout.TYPE.VERTICAL);
            layoutNode.setAnchorPoint(0, 0);
            mainLayer.addChild(layoutNode);

            let totalHeight = 0;
            msgArray.forEach(cur => {
                let messageLabel = new cc.LabelTTF(cur, JSFontName, 10, cc.size(315, 0));
                messageLabel.setColor(fontColor);
                messageLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                layoutNode.addChild(messageLabel);

                // 算高度
                totalHeight += messageLabel.getContentSize().height;
            });

            // 設定scrollView的大小
            scrollView.setContentSize(scrollViewSize.width, totalHeight);

            // 先跑到最上面
            scrollView.setContentOffset(scrollView.minContainerOffset());
        }

        // 下面的獎勵圖背景(預設紅色底)
        let contextBgSprite = new ccui.Scale9Sprite(contextBgSpriteFileName);
        contextBgSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 11);
        contextBgSprite.setPreferredSize(cc.size(327.5, 96.5));
        animationLayer.addChild(contextBgSprite);

        // 下面的內文美術圖
        let contextSprite = new cc.Sprite("#" + contextTitleFileName);
        contextSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 26);
        animationLayer.addChild(contextSprite);

        // 下排獎勵區
        let rowLength = Math.ceil(rewardArray.length / 6);

        let rewardScrollViewSize = cc.size(328, 75);
        let rewardMainLayer = new cc.Layer();
        rewardMainLayer.setContentSize(rewardScrollViewSize.width, rowLength * 57);

        let rewardScrollView = new cc.ScrollView(rewardScrollViewSize, rewardMainLayer);
        rewardScrollView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        rewardScrollView.setPosition(JSScreenMidPos.x - rewardScrollViewSize.width / 2, JSScreenMidPos.y - 18.5 - rewardScrollViewSize.height / 2);
        rewardScrollView.setBounceable(rewardArray.length >= 7);
        animationLayer.addChild(rewardScrollView);

        let rewardAutoNode = new GSAutoLayoutNode();
        rewardAutoNode.setPosition(rewardScrollView.width / 2, rowLength * 57);
        rewardAutoNode.setAnchorPoint(0.5, 1);
        rewardAutoNode.setType(rewardArray.length < 7 ? GSAutoLayout.TYPE.VERTICAL : GSAutoLayout.TYPE.VERTICAL_LEFT);
        rewardAutoNode.setSpace(this._cellSpacing);
        rewardMainLayer.addChild(rewardAutoNode);

        // 6 個一行
        for (let i = 0; i < rowLength; i++) {
            let rowAutoNode = new GSAutoLayoutNode();
            rowAutoNode.setSpace(this._cellSpacing);
            rewardAutoNode.addChild(rowAutoNode);
            for (let j = 0; j < 6; j++) {
                let rewardParam = rewardArray[i * 6 + j];
                if (rewardParam) {
                    // 使用獎勵的 passType 來決定顯示樣式，如果沒有則預設為 LUXURY
                    let passType = rewardParam.passType || BasePassType.LUXURY;
                    let rewardItemNode = new this._rewardItemNodeClass(this._config, true, true, BasePassNormalRewardNode.Where.NOT_CHARGE_GET_REWARD_DIALOG, passType);
                    rewardItemNode.refreshPicture(rewardParam);
                    rewardItemNode.setScale(this._itemScale);
                    rewardItemNode.setProductParam(param.purchaseParam.productParam);
                    rewardItemNode.addTouchUpInsideAction(this.closeDialogAnimation, this);
                    rowAutoNode.addChild(rewardItemNode);
                }
            }
        }
        // 設定scrollView的大小
        rewardScrollView.setContentSize(rewardScrollView.width, rowLength * 57);

        // 先跑到最上面
        rewardScrollView.setContentOffset(rewardScrollView.minContainerOffset());

        // ok按鈕
        let okBtnStyle = this._config.isUseOldBtnStyle ? Texas_Button.Style.COMMON_BLUE : Texas_Button.Style.BLUE;
        let okBtn = this._okButton = new Texas_Button(okBtnStyle, cc.size(110, 38), "OK");
        okBtn.addTouchUpInsideAction(this._closeDialogAnimation, this);
        okBtn.setPosition(JSScreenMidPos.x - 61, JSScreenMidPos.y - 87);
        animationLayer.addChild(okBtn);

        // 儲值按鈕
        let purchaseButton = this._purchaseButton = new BasePassPurchaseButton({
            isUseOldBtnStyle: this._config.isUseOldBtnStyle,
            purchaseBtnIsShowTicketIcon: false,
            purchaseBtnIsShowDiscount: true,
            purchaseBtnStyle: config.purchaseBtnStyle,
            purchaseBtnMessage: param.purchaseBtnMessage || config.purchaseBtnMessage,
            purchaseBtnDiscountMessage: param.purchaseBtnDiscountMessage || config.purchaseBtnDiscountMessage,
            purchaseBtnAlwaysUseDiscountMessage: param.purchaseBtnAlwaysUseDiscountMessage !== undefined ? param.purchaseBtnAlwaysUseDiscountMessage : (config.purchaseBtnAlwaysUseDiscountMessage !== undefined ? config.purchaseBtnAlwaysUseDiscountMessage : false),
            purchaseBtnDiscountFontSize: param.purchaseBtnDiscountFontSize !== undefined ? param.purchaseBtnDiscountFontSize : config.purchaseBtnDiscountFontSize,
            purchaseBtnIsShowPrice: param.purchaseBtnIsShowPrice !== undefined ? param.purchaseBtnIsShowPrice : config.purchaseBtnIsShowPrice,
            purchaseBtnOnClick: this._purchaseClicked.bind(this)
        });
        purchaseButton.refreshView(purchaseParam, true);
        purchaseButton.setPosition(JSScreenMidPos.x + 61, JSScreenMidPos.y - 87);
        animationLayer.addChild(purchaseButton);
    },

    _purchaseClicked: function (sender) {
        this._param.purchaseBtnOnClick && this._param.purchaseBtnOnClick(sender);

        // 如果有設定 skipDefaultPurchase 為 true，則不執行預設的儲值行為
        if (!this._param.skipDefaultPurchase) {
            // 送儲值
            DataModal.purchaseData.goPurchase(this._param.purchaseParam.productParam);
        }

        this.closeDialogAnimation();
    },

    // 給外部呼叫 抓ok按鈕
    getOkBtn: function () {
        return this._okButton;
    },

    // 給外部呼叫 抓儲值按鈕
    getPurchaseBtn: function () {
        return this._purchaseButton;
    },
});