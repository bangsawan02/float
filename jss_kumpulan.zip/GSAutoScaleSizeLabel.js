/**
 * 類似GSAutoSizeLabel 不一樣在他不會變更字型大小 而是透過Scale去處理
 * 用在不切斷文字, stroke的大小也會因為變小而變小
 * 目前dimensions傳進來只會處理寬度, 所以傳進來的高度大小都是沒用的, 未來在去做處理高度
 * 用法跟LabelTTF一樣 傳進的dimesions代表能接受的最大大小, 所以可以直接把原本的cc.LabelTTF取代成GSAutoScaleSizeLabel
 * var test = new GSAutoScaleSizeLabel("Sample Test", fontName, 12, cc.size(60, 0));
 * test.showDebug();            // 可以看Dimesions的範圍大小 方便測試用 看完需拿掉此行
 * this.addChild(test);
 */

var GSAutoScaleSizeLabel = cc.Node.extend({
    ctor: function (labelStr, fontName, fontSize, dimensions = cc.size(0, 0), hAlignment, vAlignment) {
        this._super();

        this.setCascadeOpacityEnabled(true);
        this.setCascadeColorEnabled(true);

        this._dimensions = cc.size(dimensions.width, dimensions.height);

        // 主要Label 設定Anchor 0,0 就不用設定位置
        var label = this._label = new cc.LabelTTF(labelStr, fontName, fontSize, cc.size(0, 0), hAlignment, vAlignment);
        label.setAnchorPoint(0, 0);
        this.addChild(label);

        // 設定自己Anchor
        this.setAnchorPoint(0.5, 0.5);

        // 先更新一次大小
        this._refresh();
    },

    /**
     * 方便測試用 用來加入紅色框框 顯示這個畫面的範圍在哪裡 沒有給高的話 預設就是字體產生出來的高度
     */
    showDebug: function () {
        this._debugLayer && this._debugLayer.removeFromParent();
        var colorLayer = this._debugLayer = new cc.LayerColor(cc.color(255, 0, 0, 100), this._dimensions.width, this._dimensions.height || this.getContentSize().height);
        this.addChild(colorLayer, -1);

        // 重新更新位置
        this._refreshDebugPosition();
    },

    /**
     * 更新畫面大小 只針對寬來做Scale
     */
    _refresh: function () {
        // 更新自己的Size
        var label = this._label;
        var labelContentSize = label.getContentSize();
        var dim = this._dimensions;

        if (labelContentSize.width <= dim.width || dim.width === 0) {
            // 代表需要不需縮放
            label.setScale(1);
            this.setContentSize(labelContentSize);
        } else {
            // 需要縮放
            var scaleRatio = dim.width / labelContentSize.width;
            label.setScale(scaleRatio);
            this.setContentSize(cc.size(dim.width, labelContentSize.height * scaleRatio))
        }
        this._refreshDebugPosition();
    },

    // 更新Debug用的底位置 因為setContentSize完後 位置需要更動
    _refreshDebugPosition: function () {
        var layer = this._debugLayer;
        if (!layer)
            return;

        var anchor = this.getAnchorPoint();
        var selfSize = this.getContentSize();
        var dimensions = this._dimensions;
        layer.setPosition(-anchor.x * (dimensions.width - selfSize.width), -anchor.y * ((dimensions.height ? dimensions.height : selfSize.height) - selfSize.height));
    },

    /**
     * Node override
     */
    setAnchorPoint: function (point, y) {
        // 對於JSB來說, 他是去看參數數量決定如何呼叫Native的code的
        // 這樣判斷我們才能使用參數是 (cc.Point) 或是 (x, y) 這樣兩種呼叫方法
        if (y === undefined) {
            cc.Node.prototype.setAnchorPoint.call(this, point);
        } else {
            cc.Node.prototype.setAnchorPoint.call(this, point, y);
        }
        // 主要用來有更新Anchor要更新Debug的位置
        this._refreshDebugPosition();
    },

    /**
     * 以下是CCLabelTTF有的東西 把它搬過來用
     */
    getLineHeight: function () {
        return this._label.getLineHeight();
    },

    setLineHeight: function (lineHeight) {
        // Native沒有這東西
        return;
    },

    getString: function () {
        return this._label.getString();
    },

    getHorizontalAlignment: function () {
        return this._label.getHorizontalAlignment();
    },

    getVerticalAlignment: function () {
        return this._label.getVerticalAlignment();
    },

    getDimensions: function () {
        return cc.size(this._dimensions);
    },

    getFontSize: function () {
        return this._label.getFontSize();
    },

    getFontName: function () {
        return this._label.getFontName();
    },

    setTextDefinition: function (theDefinition) {
        this._label.setTextDefinition(theDefinition);
        this._refresh();
    },

    getTextDefinition: function () {
        return this._label.getTextDefinition();
    },

    enableShadow: function (a, b, c, d) {
        this._label.enableShadow(a, b, c, d);
    },

    disableShadow: function () {
        this._label.disableShadow();
    },

    enableStroke: function (strokeColor, strokeSize) {
        this._label.enableStroke(strokeColor, strokeSize);
        this._refresh();
    },

    disableStroke: function () {
        this._label.disableStroke();
        this._refresh();
    },

    setFontFillColor: function (fillColor) {
        this._label.setFontFillColor(fillColor);
    },

    setString: function (text) {
        this._label.setString(text);
        this._refresh();
    },

    setHorizontalAlignment: function (alignment) {
        this._label.setHorizontalAlignment(alignment);
        this._refresh();
    },

    setVerticalAlignment: function (verticalAlignment) {
        this._label.setVerticalAlignment(verticalAlignment);
        this._refresh();
    },

    setDimensions: function (dim, height) {
        var width;
        if (height === undefined) {
            width = dim.width;
            height = dim.height;
        } else
            width = dim;

        if (width !== this._dimensions.width || height !== this._dimensions.height) {
            this._dimensions.width = width;
            this._dimensions.height = height;
            this._refresh();
        }
    },

    setFontSize: function (fontSize) {
        this._label.setFontSize(fontSize);
        this._refresh();
    },

    setFontName: function (fontName) {
        this._label.setFontName(fontName);
        this._refresh();
    },

    getBoundingBox: function () {
        return this._label.getBoundingBox();
    },

    setLineBreak: function (val) {
        this._label.setLineBreak(val);
        this._refresh();
    },
});