/**
 * Bonus機台 玩家 Layer
 */
var BonusPlayersLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 所有玩家的位置
        this._playerPosArray = [
            // 0永遠都是玩家
            cc.p(256 + JSScreenBonusHalfWidth, 64 + JSScreenBonusHalfHeight),
            // 先把其他玩家的位置丟進去
            cc.p(152 + JSScreenBonusHalfWidth, 68 + JSScreenBonusHalfHeight),
            cc.p(360 + JSScreenBonusHalfWidth, 68 + JSScreenBonusHalfHeight),
            cc.p(48 + JSScreenBonusHalfWidth, 96 + JSScreenBonusHalfHeight),
            cc.p(464 + JSScreenBonusHalfWidth, 96 + JSScreenBonusHalfHeight)
        ];

        this._playerIdx = [0, 1, 2, 3, 4];

        this._bonusPlayers = [];

        GS.addListener("NotifyRefreshIsForbidden", this.notifyRefreshIsForbidden.bind(this), this);
    },

    /**
     * 回傳玩家數量
     * @return {number} 玩家數量
     */
    getPlayerCount: function () {
        return this._bonusPlayers.length;
    },

    /**
     * 透過index取得玩家
     * @param {Number} idx 玩家index
     * @return {BonusPlayerNode}
     */
    getPlayerByIndex: function (idx) {
        return this._bonusPlayers[idx];
    },

    /**
     * 增加玩家
     * @param {Object}  playerData  玩家資料
     */
    addPlayer: function (playerData) {
        if (this._playerPosArray.length > 0) {
            var newPlayer = new BonusPlayerNode();
            var idx = this._playerIdx.shift();
            newPlayer.setPlayerData(playerData);
            newPlayer.setPlayerMoney(playerData.money);
            newPlayer.setPlayerPosition(this._playerPosArray.shift());
            newPlayer.setPlayerIdx(idx);
            this._bonusPlayers[idx] = newPlayer;
            this.addChild(newPlayer);
        }
    },

    /**
     * 透過index刪除玩家
     * @param idx
     */
    removePlayerByIdx: function (idx) {
        var player = this._bonusPlayers[idx];
        if (player) {
            this._playerPosArray.push(player.pos);
            this._playerIdx.push(player.playerIdx);
            player.removeFromParent();
            this._bonusPlayers[idx] = null;
        }
    },

    /**
     * 透過玩家account取得PlayerNode
     * @param   {String}            account     玩家account
     * @return  {BonusPlayerNode}               玩家PlayerNode
     */
    getPlayerByAccount: function (account) {
        return this._bonusPlayers.find(cur => cur.playerData.account === account);
    },

    /**
     * 透過index播放玩家獲勝動畫
     * @param {Number} idx 玩家index
     */
    showPlayerWinAnimeByIdx: function (idx) {
        if (this._bonusPlayers[idx])
            this._bonusPlayers[idx].showWinAni();
    },

    /**
     * 取得玩家自己的playerNode
     * @return {null|BonusPlayerNode}
     */
    getUserPlayer: function () {
        if (this._bonusPlayers.length)
            return this._bonusPlayers[0];
        else
            return null;
    },

    clean: function () {
        this._bonusPlayers.forEach(cur => cur && cur.clean());
    },

    // 黑名單大頭照更新
    notifyRefreshIsForbidden: function (event) {
        if (!event)
            return;

        this._bonusPlayers.forEach(cur => cur && cur.refreshImage());
    }
});