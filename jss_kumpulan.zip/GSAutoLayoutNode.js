/**
 * 用來自動排版的Node 也可以加入類似LobbyIconNode的東西 會因為Visible來自動重新排版
 *
 var layoutNode = new GSAutoLayoutNode();
 layoutNode.addChild(new cc.Sprite("#select_01.png"));
 layoutNode.addChild(new cc.Sprite("#game_btn_pic_silverbar.png"));
 layoutNode.addChild(new cc.Sprite("#lobby_icon_fb.png"));
 layoutNode.setType(xxx);
 layoutNode.setPosition(JSScreenMidPos);
 this.addChild(layoutNode);
 */

var GSAutoLayout = {};
GSAutoLayout.TYPE = {
    HORIZONTAL: 0,          // 水平對齊
    VERTICAL: 1,            // 垂直對齊
    VERTICAL_LEFT: 2,       // 垂直靠左對齊
    VERTICAL_RIGHT: 3,      // 垂直靠右對齊
    HORIZONTAL_TOP: 4,      // 水平靠上對齊
    HORIZONTAL_BOTTOM: 5,   // 水平靠下對齊
};

GSAutoLayout.DIRECTION = {
    NORMAL: 0,              // 正常方向 (在水平就是左到右 垂直是上到下)
    REVERSE: 1,             // 反向 (在水平就是右到左 垂直是下到上)
};

/**
 * 垂直或水平, 整體的物件要在node的nodeSize怎麼排列
 * ---------    物件若是垂直排列, 整個長條狀的物件:
 * |   1   |        設定MINIMUM:會靠近(2)
 * |       |        設定MAXIMUM:會靠近(1)
 * |3     4|    物件若是水平排列, 整個橫條狀的物件:
 * |       |        設定MINIMUM:會靠近(3)
 * |   2   |        設定MAXIMUM:會靠近(4)
 * ---------    <-nodeSize
 */
GSAutoLayout.AllItemAlignmentMode = {
    UNSPECIFIED: 0,     // 未指定, (水平的話所有物件都會向右對齊, 垂直會向上對齊), 向下相容
    MINIMUM: 1,         // 向最小值靠攏, (水平向左對齊, 垂直向下對齊)
    CENTER: 2,          // 置中
    MAXIMUM: 3          // 向最大值靠攏, (水平向右對齊, 垂直向上對齊)
};

var GSAutoLayoutNode = cc.Node.extend({
    ctor: function () {
        this._super();

        this._type = GSAutoLayout.TYPE.HORIZONTAL;                                  // 排序的類型
        this._direction = GSAutoLayout.DIRECTION.NORMAL;                            // 排序的方向
        this._space = 0;                                                            // 每一個Node的間距
        this._nodeWidth = 0;                                                        // 此Node的寬
        this._nodeHeight = 0;                                                       // 此Node的高
        this._itemAlignmentMode = GSAutoLayout.AllItemAlignmentMode.UNSPECIFIED;    // 東西是不是需要排到中間(水平排的話會在相對_nodeWidth中間的位置)

        this.setCascadeColorEnabled(true);
        this.setCascadeOpacityEnabled(true);
        this.setAnchorPoint(0.5, 0.5);
    },

    /**
     * override
     */
    addChild: function () {
        this._super.apply(this, arguments);

        this._doLayout();
    },

    /**
     * 加一個空的Node 用來多隔一些空間
     * @param size
     */
    addEmptyNode: function (size) {
        var emptyNode = new cc.Node();
        emptyNode.setContentSize(size);
        this.addChild(emptyNode);
    },

    /**
     * 設定此Node的Size
     * @param width
     * @param height
     */
    setNodeSize: function (width = 0, height = 0) {
        if (this._nodeWidth !== width)
            this._nodeWidth = width;

        if (this._nodeHeight !== height)
            this._nodeHeight = height;

        this._doLayout();
    },

    /**
     * 設定排序的類型
     * @param type
     */
    setType: function (type) {
        if (this._type !== type) {
            this._type = type;
            this._doLayout();
        }
    },

    /**
     * 設定排序的方向
     * @param direction
     */
    setDirection: function (direction) {
        if (this._direction !== direction) {
            this._direction = direction;
            this._doLayout();
        }
    },

    /**
     * 設定整體物件結束排序後要向nodeSize的哪邊對齊
     * @param {GSAutoLayout.AllItemAlignmentMode} mode
     */
    setItemAlignmentMode: function (mode) {
        if (this._itemAlignmentMode !== mode) {
            this._itemAlignmentMode = mode;
            this._doLayout();
        }
    },

    /**
     * 一起設定type跟排序模式
     * @param type
     * @param mode
     */
    setTypeAndItemAlignmentMode: function (type, mode) {
        let isContextDirty = false;
        if (this._type !== type) {
            this._type = type;
            isContextDirty = true;
        }

        if (this._itemAlignmentMode !== mode) {
            this._itemAlignmentMode = mode;
            isContextDirty = true;
        }

        if (isContextDirty)
            this._doLayout();
    },

    /**
     * 設定每一個Node的間距
     * @param space
     */
    setSpace: function (space) {
        if (this._space !== space) {
            this._space = space;
            this._doLayout();
        }
    },

    /**
     * 給外部call的 強制重整畫面
     */
    refresh: function () {
        this._doLayout();
    },

    /**
     * 重新更新畫面
     */
    _doLayout: function () {
        var children = this.getChildren();
        var childrenLen = children.length;
        if (childrenLen === 0)
            return;

        var width = 0, height = 0;
        var self = this;
        switch (this._type) {
            case GSAutoLayout.TYPE.HORIZONTAL:
            case GSAutoLayout.TYPE.HORIZONTAL_TOP:
            case GSAutoLayout.TYPE.HORIZONTAL_BOTTOM:
                // 先算出寬高
                children
                    .filter(cur => cur.isVisible()) // 看不到就當做不在
                    .forEach(function (cur, index) {
                        var thisSize = cur.getBoundingBox();
                        height = Math.max(thisSize.height, height);
                        width += thisSize.width + (index > 0 ? self._space : 0);
                    });

                // 設定起始位置
                var nowPosX = 0;
                // 有超過才需要靠攏
                if (this._nodeWidth > width) {
                    switch (this._itemAlignmentMode) {
                        // 要向右靠齊
                        case GSAutoLayout.AllItemAlignmentMode.MAXIMUM:
                            nowPosX = this._nodeWidth - width;
                            break;
                        case GSAutoLayout.AllItemAlignmentMode.CENTER:
                            nowPosX = (this._nodeWidth - width) / 2;
                            break;
                        case GSAutoLayout.AllItemAlignmentMode.MINIMUM:
                        case GSAutoLayout.AllItemAlignmentMode.UNSPECIFIED:
                            nowPosX = 0;
                            break;
                    }
                }

                // 取最大值 避免自定義值過小layout會排壞
                width = Math.max(this._nodeWidth, width);
                height = Math.max(this._nodeHeight, height);

                var isTop = this._type === GSAutoLayout.TYPE.HORIZONTAL_TOP;
                var isBottom = this._type === GSAutoLayout.TYPE.HORIZONTAL_BOTTOM;
                var posY = isTop ? height : isBottom ? 0 : height / 2;
                var layoutFunc = function (child) {
                    // 看不到就當做不在
                    if (!child.isVisible())
                        return;

                    child.setAnchorPoint(0, isTop ? 1 : isBottom ? 0 : 0.5);
                    child.setPosition(nowPosX, posY);
                    nowPosX += child.getBoundingBox().width + self._space;
                };

                if (this._direction === GSAutoLayout.DIRECTION.NORMAL) {
                    // 從左到右
                    for (var i = 0; i < childrenLen; i++) {
                        layoutFunc(children[i]);
                    }
                }
                else {
                    // 從右到左
                    for (var i = childrenLen - 1; i >= 0; i--) {
                        layoutFunc(children[i]);
                    }
                }
                break;
            default:
                // 先算出寬高
                children
                    .filter(cur => cur.isVisible()) // 看不到就當做不在
                    .forEach(function (cur, index) {
                        var thisSize = cur.getBoundingBox();
                        width = Math.max(thisSize.width, width);
                        height += thisSize.height + (index > 0 ? self._space : 0);
                    });

                // 設定起始位置
                var nowPosY = height;
                // 有超過才需要靠攏
                if (this._nodeHeight > height) {
                    switch (this._itemAlignmentMode) {
                        // 要向上靠齊
                        case GSAutoLayout.AllItemAlignmentMode.MAXIMUM:
                            nowPosY = this._nodeHeight;
                            break;
                        case GSAutoLayout.AllItemAlignmentMode.CENTER:
                            nowPosY = (this._nodeHeight + height) / 2;
                            break;
                        case GSAutoLayout.AllItemAlignmentMode.MINIMUM:
                        case GSAutoLayout.AllItemAlignmentMode.UNSPECIFIED:
                            nowPosY = height;
                            break;
                    }
                }

                // 取最大值 避免自定義值過小layout會排壞
                width = Math.max(this._nodeWidth, width);
                height = Math.max(this._nodeHeight, height);

                var isLeft = this._type === GSAutoLayout.TYPE.VERTICAL_LEFT;        // 垂直靠左
                var isRight = this._type === GSAutoLayout.TYPE.VERTICAL_RIGHT;      // 垂直靠右
                var anchorPoint = cc.p(isLeft ? 0 : isRight ? 1 : 0.5, 1);
                var posX = isLeft ? 0 : isRight ? width : width / 2;
                var layoutFunc = function (child) {
                    // 看不到就當做不在
                    if (!child.isVisible())
                        return;

                    child.setAnchorPoint(anchorPoint);
                    child.setPosition(posX, nowPosY);
                    nowPosY -= child.getBoundingBox().height + self._space;
                };

                if (this._direction === GSAutoLayout.DIRECTION.NORMAL) {
                    // 從上到下
                    for (var i = 0; i < childrenLen; i++) {
                        layoutFunc(children[i]);
                    }
                }
                else {
                    // 從下到上
                    for (var i = childrenLen - 1; i >= 0; i--) {
                        layoutFunc(children[i]);
                    }
                }
        }

        // 設定此Node的Size
        this.setContentSize(cc.size(width, height));
    },
});
