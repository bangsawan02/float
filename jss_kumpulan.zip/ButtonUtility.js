var ButtonUtility = {};

ButtonUtility.createBtnLabel = function (title, fontSize, color, normalImage, highlightImage, disableImage, rect) {
    var sprite = new ccui.Scale9Sprite(normalImage);
    var label = new cc.LabelTTF(title, JSFontBoldName, fontSize);
    label.setFontFillColor(color);
    var button = new cc.ControlButton(label, sprite);
    button.setPreferredSize(cc.size(rect.width, rect.height));
    button.setZoomOnTouchDown(false);
    if (highlightImage) {
        label = new cc.LabelTTF(title, JSFontBoldName, fontSize);
        label.setFontFillColor(color);
        label.setOpacity(150);

        var sprite2 = new ccui.Scale9Sprite(highlightImage);
        sprite2.setColor(JSColor.GRAY);
        button.setBackgroundSpriteForState(sprite2, cc.CONTROL_STATE_HIGHLIGHTED);
        button.setTitleLabelForState(label, cc.CONTROL_STATE_HIGHLIGHTED);
    }

    if (disableImage) {
        label = new cc.LabelTTF(title, JSFontBoldName, fontSize);
        label.setFontFillColor(color);
        label.setOpacity(100);

        var sprite3 = new ccui.Scale9Sprite(disableImage);
        sprite3.setColor(JSColor.GRAY);
        button.setBackgroundSpriteForState(sprite3, cc.CONTROL_STATE_DISABLED);
        button.setTitleLabelForState(label, cc.CONTROL_STATE_DISABLED);
    }

    button.setPosition(rect.x, rect.y);

    return button;
};

/**
 *
 * @param normalImage
 * @param highlightImage
 * @param disableImage
 * @param rect
 * @param setGray
 * @param iconData = {image:檔名 offset: 偏移值},icon會預設在中間
 * @returns {*}
 */
ButtonUtility.createBtnNoneLabel = function (normalImage, highlightImage, disableImage, rect, setGray = true, iconData) {
    var sprite = new ccui.Scale9Sprite(normalImage);
    rect = rect || cc.rect(0, 0, sprite.getContentSize().width, sprite.getContentSize().height);

    var button = new cc.ControlButton(sprite);
    button.setPreferredSize(cc.size(rect.width, rect.height));
    button.setZoomOnTouchDown(false);

    if (highlightImage) {
        var sprite2 = new ccui.Scale9Sprite(highlightImage);
        button.setBackgroundSpriteForState(sprite2, cc.CONTROL_STATE_HIGHLIGHTED);
    }

    if (disableImage) {
        var sprite3 = new ccui.Scale9Sprite(disableImage);
        setGray && sprite3.setColor(JSColor.GRAY);
        button.setBackgroundSpriteForState(sprite3, cc.CONTROL_STATE_DISABLED);
    }

    if (iconData) {
        var iconSprite = new cc.Sprite(iconData.image);
        var offset = iconData.offset || cc.p(0, 0);

        iconSprite.setPosition(sprite.getContentSize().width / 2 + offset.x, sprite.getContentSize().height / 2 + offset.y);
        sprite.addChild(iconSprite);

        if (sprite2) {
            iconSprite = new cc.Sprite(iconData.image);
            iconSprite.setPosition(sprite2.getContentSize().width / 2 + offset.x, sprite2.getContentSize().height / 2 + offset.y - 2);
            sprite2.addChild(iconSprite);
        }

        if (sprite3) {
            iconSprite = new cc.Sprite(iconData.image);
            iconSprite.setPosition(sprite3.getContentSize().width / 2 + offset.x, sprite3.getContentSize().height / 2 + offset.y);
            sprite3.addChild(iconSprite);
        }
    }

    button.setPosition(rect.x, rect.y);

    return button;
};

/**
 * 創一個文字有底線的Node
 */
ButtonUtility.createBtnLabelWithUnderLine = function (title, fontSize, color, lineOffsetY) {
    var itemNode = [];

    for (var i = 0; i < 3; i++) {
        var node = itemNode[i] = new ccui.Scale9Sprite();
        node.setCascadeColorEnabled(true);
        node.setCascadeOpacityEnabled(true);

        // 文字
        var titleLabel = node.label = new cc.LabelTTF(title, JSFontBoldName, fontSize);
        var contentSize = titleLabel.getContentSize();
        var midPos = cc.p(contentSize.width / 2, contentSize.height / 2);
        titleLabel.setPosition(midPos);
        color && titleLabel.setFontFillColor(color);
        node.addChild(titleLabel);

        // 底線
        var line = node.line = new cc.LayerColor(color, contentSize.width, 1);
        line.setPosition(0, lineOffsetY || 0);
        node.addChild(line);

        node.setPreferredSize(contentSize);
        node.setContentSize(contentSize);

        if (i === 1)
            node.setColor(JSColor.GRAY);
        else if (i === 2)
            node.setOpacity(150);
    }

    return itemNode;
};

/**
 * 傳單一圖片 size 文字 文字大小 文字顏色 會回傳itemNode[3]
 */
ButtonUtility.createSingleScale9Nodes = function (image, size, title, fontSize, fontColor) {
    var itemNode = [];

    for (var i = 0; i < 3; i++) {
        var node = itemNode[i] = new ccui.Scale9Sprite();
        node.setCascadeColorEnabled(true);
        node.setCascadeOpacityEnabled(true);

        var bgSprite = null;
        if (image[0] === "#") {
            bgSprite = node.bg = new cc.Sprite(image);
        } else {
            bgSprite = node.bg = new ccui.Scale9Sprite(image);
        }

        if (!size) {
            size = bgSprite.getContentSize();
        } else {
            bgSprite.setPreferredSize && bgSprite.setPreferredSize(size);
        }
        bgSprite.setPosition(size.width / 2, size.height / 2);
        node.addChild(bgSprite);

        if (title) {
            var titleLabel = node.label = new cc.LabelTTF(title, JSFontBoldName, fontSize);
            fontColor && titleLabel.setFontFillColor(fontColor);
            titleLabel.setPosition(size.width / 2, size.height / 2);
            node.addChild(titleLabel);
        }

        node.setPreferredSize(size);
        node.setContentSize(size);

        if (i === 1)
            node.setColor(JSColor.GRAY);
        else if (i === 2)
            node.setOpacity(150);
    }

    return itemNode;
};

/**
 * 傳Array圖片 size 文字 文字大小 文字顏色 會回傳itemNode[3]
 * 創建按壓式的按鈕 第二張會是下壓圖 內文用offsetY控制偏移值
 */
ButtonUtility.createPressScale9Nodes = function (images, size, title, fontSize, fontColor, offsetY = 5) {
    //判斷是不是Array
    images = images || [];
    if (JSCodeUtility.checkType(images) !== JSTYPE.ARRAY)
        images = [images];

    var itemNode = [];
    for (var i = 0; i < 3; i++) {
        var node = itemNode[i] = new ccui.Scale9Sprite();
        node.setCascadeColorEnabled(true);
        node.setCascadeOpacityEnabled(true);

        var bgSprite = null;
        var image = images[i] || images[0];
        if (image[0] === "#") {
            bgSprite = node.bg = new cc.Sprite(image);
            size = size || (size = bgSprite.getContentSize());
        } else {
            bgSprite = node.bg = new ccui.Scale9Sprite(image);
            bgSprite.setPreferredSize(size);
        }
        bgSprite.setPosition(size.width / 2, size.height / 2);
        node.addChild(bgSprite);

        // i=1的字位置要略往下
        if (title) {
            if (title[0] === "#") {
                // 是圖
                var titleSprite = node.word = new cc.Sprite(title);
                titleSprite.setPosition(cc.pAdd(bgSprite.getPosition(), cc.p(0, offsetY - (i === 1 ? offsetY : 0))));
                node.addChild(titleSprite);
            } else {
                // 是字
                var titleLabel = node.word = new cc.LabelTTF(title, JSFontBoldName, fontSize);
                fontColor && titleLabel.setFontFillColor(fontColor);
                titleLabel.setPosition(cc.pAdd(bgSprite.getPosition(), cc.p(0, offsetY - (i === 1 ? offsetY : 0))));
                node.addChild(titleLabel);
            }
        }

        node.setPreferredSize(size);
        node.setContentSize(size);
    }
    itemNode[2].setColor(JSColor.GRAY);

    return itemNode;
};

/**
 * 建立文字左邊有icon的按鈕 同時有icon和文字才用這個
 * 傳單一圖片 size icon icon縮放大小 文字 文字大小 文字顏色 icon與文字間距 會回傳itemNode[3]
 */
ButtonUtility.createSingleScale9NodesWithIcon = function (image, size, icon, iconScale, title, fontSize, fontColor, offset) {
    var itemNode = ButtonUtility.createSingleScale9Nodes(image, size);

    var midPos = cc.p(size.width / 2, size.height / 2);

    itemNode.forEach(node => {
        var titleLabel;
        var iconSp;

        // 加文字
        if (title) {
            titleLabel = node.label = new cc.LabelTTF(title, JSFontBoldName, fontSize);
            titleLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            fontColor && titleLabel.setFontFillColor(fontColor);
            node.addChild(titleLabel);
        }

        // 加icon
        if (icon) {
            iconSp = node.iconSp = new cc.Sprite(icon);
            iconScale && iconSp.setScale(iconScale);
            node.addChild(iconSp);
        }

        // 排列一下icon和文字的位置
        if (iconSp && titleLabel) {
            var halfOffset = offset ? offset / 2 : 0;

            iconSp.setPosition(midPos.x - (titleLabel.getContentSize().width / 2) - halfOffset, midPos.y);
            titleLabel.setPosition(midPos.x + (iconSp.getBoundingBox().width / 2) + halfOffset, midPos.y);
        } else {
            iconSp && iconSp.setPosition(midPos);
            titleLabel && titleLabel.setPosition(midPos);
        }
    });

    return itemNode;
};

/**
 * 建立文字左邊有icon的按鈕 同時有icon和文字才用這個
 * 傳Array圖片 size icon icon縮放大小 文字 文字大小 文字顏色 icon與文字間距 會回傳itemNode[3]
 */
ButtonUtility.createArrayScale9NodesWithIcon = function (image, size, icon, iconScale, title, fontSize, fontColor, offset, isVerticalLayout) {
    var itemNode = ButtonUtility.createArrayScale9Nodes(image, size);

    var midPos = cc.p(size.width / 2, size.height / 2);

    itemNode.forEach(node => {
        var titleLabel;
        var iconSp;

        // 加文字
        if (title) {
            titleLabel = node.label = new cc.LabelTTF(title, JSFontBoldName, fontSize);
            fontColor && titleLabel.setFontFillColor(fontColor);
            node.addChild(titleLabel);
        }

        // 加icon
        if (icon) {
            iconSp = node.iconSp = new cc.Sprite(icon);
            iconScale && iconSp.setScale(iconScale);
            node.addChild(iconSp);
        }

        // 排列一下icon和文字的位置
        if (iconSp && titleLabel) {
            var halfOffset = offset ? offset / 2 : 0;

            if (isVerticalLayout) {
                // 垂直排版
                iconSp.setPosition(midPos.x, midPos.y + (titleLabel.getContentSize().height / 2) + halfOffset);
                titleLabel.setPosition(midPos.x, midPos.y - (iconSp.getBoundingBox().height / 2) - halfOffset);
            } else {
                // 水平排版
                iconSp.setPosition(midPos.x - (titleLabel.getContentSize().width / 2) - halfOffset, midPos.y);
                titleLabel.setPosition(midPos.x + (iconSp.getBoundingBox().width / 2) + halfOffset, midPos.y);
            }
        } else {
            iconSp && iconSp.setPosition(midPos);
            titleLabel && titleLabel.setPosition(midPos);
        }
    });

    return itemNode;
};

/**
 * 傳size 文字 文字大小 文字顏色 會回傳非圖片按鈕的itemNode[3] 預設文字在圖片正中間
 */
ButtonUtility.createEmptyNodes = function (size, titles, fontSize, fontColors, fontOffset = cc.p(0, 0)) {
    var itemNode = [];

    //判斷是不是Array
    titles = titles || [];
    if (JSCodeUtility.checkType(titles) !== JSTYPE.ARRAY)
        titles = [titles];

    fontColors = fontColors || [];
    if (JSCodeUtility.checkType(fontColors) !== JSTYPE.ARRAY)
        fontColors = [fontColors];

    // 文字位置
    var titlePos = cc.pAdd(cc.p(size.width / 2, size.height / 2), fontOffset);

    for (var i = 0; i < 3; i++) {
        var node = itemNode[i] = new ccui.Scale9Sprite();
        node.setCascadeColorEnabled(true);
        node.setCascadeOpacityEnabled(true);
        node.setContentSize(size);

        if (titles && titles.length) {
            var titleLabel = node.label = new cc.LabelTTF(titles[i] || titles[0], JSFontBoldName, fontSize);
            if (fontColors.length) {
                var color = fontColors[i] || fontColors[0];
                titleLabel.setFontFillColor(color);
                if (color.a)
                    titleLabel.setOpacity(color.a);
            }
            titleLabel.setPosition(titlePos);
            node.addChild(titleLabel);
        }

        if (i === 1)
            node.setColor(JSColor.GRAY);
        else if (i === 2)
            node.setOpacity(150);
    }

    return itemNode;
};

/**
 * 傳單一圖片 文字圖 會回傳itemNode[3]
 */
ButtonUtility.createImageNodes = function (images, size, wordImages, wordImagesOffset = cc.p(0, 0)) {
    var itemNode = [];

    //判斷是不是Array
    images = images || [];
    if (JSCodeUtility.checkType(images) !== JSTYPE.ARRAY)
        images = [images];

    wordImages = wordImages || [];
    if (JSCodeUtility.checkType(wordImages) !== JSTYPE.ARRAY)
        wordImages = [wordImages];

    for (var i = 0; i < 3; i++) {
        var node = itemNode[i] = new ccui.Scale9Sprite();
        node.setCascadeColorEnabled(true);
        node.setCascadeOpacityEnabled(true);

        var bgSprite = node.bg = new cc.Sprite(images[i] || images[0]);
        var wordSprite = node.word = new cc.Sprite(wordImages[i] || wordImages[0]);
        node.addChild(bgSprite);

        size = size || bgSprite.getContentSize();
        bgSprite.setPosition(size.width / 2, size.height / 2);

        if (wordSprite) {
            wordSprite.setPosition(cc.pAdd(cc.p(size.width / 2, size.height / 2), wordImagesOffset));
            node.addChild(wordSprite);
        }

        node.setPreferredSize(size);
        node.setContentSize(size);

        if (i === 1)
            node.setColor(JSColor.GRAY);
        else if (i === 2)
            node.setOpacity(150);
    }

    return itemNode;
};

/**
 * 傳Array圖片 size 文字 文字大小 文字顏色 會回傳itemNode[3]
 */
ButtonUtility.createArrayScale9Nodes = function (images, size, titles, fontSize, fontColors, fontOffsets = cc.p(0, 0)) {
    var itemNode = [];

    //判斷是不是Array
    titles = titles || [];
    if (JSCodeUtility.checkType(titles) !== JSTYPE.ARRAY)
        titles = [titles];

    fontColors = fontColors || [];
    if (JSCodeUtility.checkType(fontColors) !== JSTYPE.ARRAY)
        fontColors = [fontColors];

    if (JSCodeUtility.checkType(fontOffsets) !== JSTYPE.ARRAY)
        fontOffsets = [fontOffsets];

    for (var i = 0; i < images.length; i++) {
        var node = itemNode[i] = new ccui.Scale9Sprite();
        node.setCascadeColorEnabled(true);
        node.setCascadeOpacityEnabled(true);

        var bgSprite = null;
        if (!size) {
            bgSprite = node.bg = new cc.Sprite(images[i]);
            size = bgSprite.getContentSize();
        } else {
            if (images[i][0] === "#") {
                bgSprite = node.bg = new cc.Sprite(images[i]);
            } else {
                bgSprite = node.bg = new ccui.Scale9Sprite(images[i]);
                bgSprite.setPreferredSize(size);
            }
        }
        bgSprite.setPosition(size.width / 2, size.height / 2);
        node.addChild(bgSprite);

        if (titles && titles.length) {
            var titleLabel = node.label = new GSAutoSizeLabel(titles[i] || titles[0], JSFontBoldName, fontSize, size, cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
            if (fontColors.length) {
                var color = fontColors[i] || fontColors[0];
                titleLabel.setFontFillColor(color);
                if (color.a)
                    titleLabel.setOpacity(color.a);
            }
            titleLabel.setPosition(cc.pAdd(cc.p(size.width / 2, size.height / 2), fontOffsets[i] || fontOffsets[0]));
            node.addChild(titleLabel);
        }

        node.setPreferredSize(size);
        node.setContentSize(size);

        if (i === 1)
            node.setColor(JSColor.GRAY);
        else if (i === 2)
            node.setOpacity(150);
    }

    return itemNode;
};

/**
 * 傳Array圖片 size 文字 文字大小 文字顏色 回傳 itemNode
 */
ButtonUtility.createArrayScale9NodesWithImageArray = function (images, size, titles, fontSize, fontColors, fontOffsets = cc.p(0, 0)) {

    //判斷是不是Array
    images = images || [];
    if (JSCodeUtility.checkType(images) !== JSTYPE.ARRAY)
        images = [images, images, images];

    return ButtonUtility.createArrayScale9Nodes(images, size, titles, fontSize, fontColors, fontOffsets);
};

/**
 * 傳單一圖片 size 文字圖 會回傳itemNode[3]
 */
ButtonUtility.createSingleScale9SpriteNodes = function (images, size, wordImages, wordImagesOffset = cc.p(0, 0)) {
    var itemNode = [];

    //判斷是不是Array
    images = images || [];
    if (JSCodeUtility.checkType(images) !== JSTYPE.ARRAY)
        images = [images];

    wordImages = wordImages || [];
    if (JSCodeUtility.checkType(wordImages) !== JSTYPE.ARRAY)
        wordImages = [wordImages];

    if (JSCodeUtility.checkType(wordImagesOffset) !== JSTYPE.ARRAY)
        wordImagesOffset = [wordImagesOffset];

    for (var i = 0; i < 3; i++) {
        var node = itemNode[i] = new ccui.Scale9Sprite();
        node.setCascadeColorEnabled(true);
        node.setCascadeOpacityEnabled(true);

        var bgSprite = node.bg = new ccui.Scale9Sprite(images[i] || images[0]);
        var wordSprite = node.word = new cc.Sprite(wordImages[i] || wordImages[0]);
        node.addChild(bgSprite);

        if (!size) {
            if (bgSprite)
                size = bgSprite.getContentSize();
            else if (wordSprite)
                size = wordSprite.getContentSize();
            else
                size = cc.size(0, 0);
        } else {
            bgSprite.setPreferredSize(size);
        }
        bgSprite.setPosition(size.width / 2, size.height / 2);

        if (wordSprite) {
            wordSprite.setPosition(cc.pAdd(cc.p(size.width / 2, size.height / 2), wordImagesOffset[i] || wordImagesOffset[0]));
            node.addChild(wordSprite);
        }

        node.setPreferredSize(size);
        node.setContentSize(size);

        if (i === 1)
            node.setColor(JSColor.GRAY);
        else if (i === 2)
            node.setOpacity(150);
    }

    return itemNode;
};

/**
 * 傳圖片背景 Item圖 會回傳itemNode[3]
 * @param bgImages      背景圖片
 * @param itemImages    按鈕內的圖
 * @param itemOffset    偏移值 e.g. [cc.p(0,0), cc.p(0,0)]
 * */
ButtonUtility.createSpriteWithSpritesNodes = function (bgImages, itemImages, itemOffset) {
    var itemNode = [];

    //判斷是不是Array
    bgImages = bgImages || [];
    if (JSCodeUtility.checkType(bgImages) !== JSTYPE.ARRAY)
        bgImages = [bgImages];

    itemImages = itemImages || [];
    if (JSCodeUtility.checkType(itemImages) !== JSTYPE.ARRAY)
        itemImages = [itemImages];

    itemOffset = itemOffset || [cc.p(0, 0)];
    if (JSCodeUtility.checkType(itemOffset) !== JSTYPE.ARRAY)
        itemOffset = [itemOffset];


    for (var i = 0; i < 3; i++) {
        var node = itemNode[i] = new ccui.Scale9Sprite();
        node.setCascadeColorEnabled(true);
        node.setCascadeOpacityEnabled(true);

        var bgSprite = null;
        var itemSprite = null;
        var size = cc.size(0, 0);
        var offset = itemOffset[i] || itemOffset[0];

        // 創出背景圖
        bgSprite = node.bg = new cc.Sprite(bgImages[i] || bgImages[0]);

        // 創出要放在按鈕上的圖示
        itemSprite = node.item = new cc.Sprite(itemImages[i] || itemImages[0]);

        // 按鈕尺寸防呆
        if (bgSprite)
            size = bgSprite.getContentSize();
        else if (itemSprite)
            size = itemSprite.getContentSize();

        bgSprite.setPosition(size.width / 2, size.height / 2);
        node.addChild(bgSprite);

        // 有圖示才加addChild
        if (itemSprite) {
            itemSprite.setPosition(size.width / 2 + offset.x, size.height / 2 + offset.y);
            node.addChild(itemSprite);
        }

        node.setPreferredSize(size);
        node.setContentSize(size);

        if (i === 1)
            node.setColor(JSColor.GRAY);
        else if (i === 2)
            node.setOpacity(150);
    }
    return itemNode;
};

/**
 * 按鈕內可以排列多個圖片(水平排列:左至右 垂直排列:上至下) 回傳itemNode[3]
 * @param bg            單一背景圖片
 * @param size          按鈕尺寸
 * @param images        按鈕內要排列的圖Array
 * @param vertical      是否垂直排列(預設水平排列)
 * @param imgsOffset    偏移值 e.g. [cc.p(0,0), cc.p(0,0)]
 * @returns {Array}
 */
ButtonUtility.createSingleSpriteWithSpritesNodes = function (bg, size, images, vertical = false, imgsOffset = []) {
    var itemNode = [];

    //判斷是不是Array
    images = images || [];
    if (JSCodeUtility.checkType(images) !== JSTYPE.ARRAY)
        images = [images];

    imgsOffset = imgsOffset || [];
    if (JSCodeUtility.checkType(imgsOffset) !== JSTYPE.ARRAY)
        imgsOffset = [imgsOffset];

    for (var i = 0; i < 3; i++) {
        var node = itemNode[i] = new ccui.Scale9Sprite();
        node.setCascadeColorEnabled(true);
        node.setCascadeOpacityEnabled(true);
        node.imgs = [];

        var bgSprite = null;
        if (bg) {
            if (!size) {
                bgSprite = node.bg = new cc.Sprite(bg);
            } else {
                if (bg[0] === "#") {
                    bgSprite = node.bg = new cc.Sprite(bg);
                } else {
                    bgSprite = node.bg = new ccui.Scale9Sprite(bg);
                }
            }
            node.addChild(bgSprite);
        }

        var lenArray = [];
        if (images && images.length) {
            var eachLen = 0;
            images.forEach((cur, i) => {
                var img = node.imgs[i] = new cc.Sprite(cur);
                node.addChild(img);

                //是否為垂直排列
                if (vertical) {
                    lenArray.push(img.getContentSize().height);
                    eachLen = img.getContentSize().width > eachLen ? img.getContentSize().width : eachLen;
                } else {
                    lenArray.push(img.getContentSize().width);
                    eachLen = img.getContentSize().height > eachLen ? img.getContentSize().height : eachLen;
                }
            });
            var totalLen = lenArray.reduce((sum, val) => sum + val);
        }

        if (!size) {
            if (bg)
                size = bgSprite.getContentSize();
            else
                size = cc.size(totalLen, eachLen);
        } else {
            bg[0] !== "#" && bgSprite.setPreferredSize(size);
        }
        bgSprite.setPosition(size.width / 2, size.height / 2);

        if (lenArray.length) {
            if (vertical) {
                var baseY = size.height / 2 + (totalLen / 2);
                node.imgs.forEach((cur, x) => {
                    //是否有偏移值
                    var imgOffset = imgsOffset[x] = imgsOffset[x] || cc.p(0, 0);
                    cur.setPosition(cc.pAdd(cc.p(size.width / 2, baseY - lenArray[x] / 2), imgOffset));
                    baseY -= lenArray[x];
                });
            } else {
                var baseX = size.width / 2 - (totalLen / 2);
                node.imgs.forEach((cur, x) => {
                    //是否有偏移值
                    var imgOffset = imgsOffset[x] = imgsOffset[x] || cc.p(0, 0);
                    cur.setPosition(cc.pAdd(cc.p(baseX + lenArray[x] / 2, size.height / 2), imgOffset));
                    baseX += lenArray[x];
                });
            }
        }
        node.setPreferredSize(size);
        node.setContentSize(size);

        if (i === 1)
            node.setColor(JSColor.GRAY);
        else if (i === 2)
            node.setOpacity(150);
    }

    return itemNode;
};

/**
 * 文字環繞在圖片四方(上下左右) 回傳itemNode[3]
 * 備註: 非中英語系之語言文字位置可能偏移
 * @param bgOrBgNodeOrObj   單一圖片 或 node(node 可以為陣列[node, node, node] 或 單一個 node) 或是設定用的 obj
 * @param [title]           文字
 * @param [fontSize]        文字大小
 * @param [fontColor]       文字顏色
 * @param [titleDir]        文字方位("TOP", "BOTTOM", "LEFT", "RIGHT")
 * @param [nodeSize]        指定nodeSize
 * @param [space]           AutoLayout的裡面位移
 * @param [isBottomLine]    文字是否要加底線
 * @returns {Array}
 */
ButtonUtility.createSingleSpriteWithSideWordNodes = function (bgOrBgNodeOrObj, title, fontSize, fontColor, titleDir, nodeSize = null, space = 0, isBottomLine = false) {
    let bg;
    let lineOffsetY;
    let lineSizeNum;
    if (typeof bgOrBgNodeOrObj === "string" || bgOrBgNodeOrObj instanceof cc.Node || JSCodeUtility.isArray(bgOrBgNodeOrObj)) {
        bg = bgOrBgNodeOrObj;
    } else {
        // 是 設定用的 obj 要解開
        bg = bgOrBgNodeOrObj.bg;                        // 單一圖片
        title = bgOrBgNodeOrObj.title;                  // 文字
        fontSize = bgOrBgNodeOrObj.fontSize;            // 文字大小
        fontColor = bgOrBgNodeOrObj.fontColor;          // 文字顏色
        titleDir = bgOrBgNodeOrObj.titleDir;            // 文字方位("TOP", "BOTTOM", "LEFT", "RIGHT")
        nodeSize = bgOrBgNodeOrObj.nodeSize || null;    // 指定nodeSize
        space = bgOrBgNodeOrObj.space || 0;             // AutoLayout的裡面位移
        isBottomLine = bgOrBgNodeOrObj.isBottomLine;    // 文字是否要加底線
        lineOffsetY = bgOrBgNodeOrObj.lineOffsetY;      // 底線的Y軸偏移值
        lineSizeNum = bgOrBgNodeOrObj.lineSizeNum;      // 底線的大小
    }
    // GSAutoLayout.TYPE(水平.垂直) GSAutoLayout.DIRECTION(正向:左至右.反向:右至左)
    var type, direction;
    switch (titleDir) {
        case "LEFT":
            // 水平反向
            type = GSAutoLayout.TYPE.HORIZONTAL;
            direction = GSAutoLayout.DIRECTION.REVERSE;
            break;
        case "BOTTOM":
            // 垂直正向
            type = GSAutoLayout.TYPE.VERTICAL;
            direction = GSAutoLayout.DIRECTION.NORMAL;
            break;
        case "TOP":
            // 垂直反向
            type = GSAutoLayout.TYPE.VERTICAL;
            direction = GSAutoLayout.DIRECTION.REVERSE;
            break;
        case "RIGHT":
        default:
            // 水平正向
            type = GSAutoLayout.TYPE.HORIZONTAL;
            direction = GSAutoLayout.DIRECTION.NORMAL;
    }

    var itemNode = [];
    for (var i = 0; i < 3; i++) {
        var autoLayout = itemNode[i] = new GSAutoLayoutNode();
        autoLayout.setType(type);
        autoLayout.setDirection(direction);
        autoLayout.setSpace(space);

        if (nodeSize !== null)
            autoLayout.setNodeSize(nodeSize.width, nodeSize.height);

        // 圖 或 node
        if (typeof bg === "string") {
            autoLayout.bg = new cc.Sprite(bg);
            autoLayout.addChild(autoLayout.bg);
        } else {
            // 不是陣列先轉換成陣列
            if (!JSCodeUtility.isArray(bg))
                bg = [bg];
            // 如果是空的就直接 return itemNode
            else if (!bg[i])
                return itemNode;

            // 都沒問題就加入
            autoLayout.bg = bg[i];
            autoLayout.addChild(bg[i]);
        }

        // 文字
        if (title) {
            var titleLabel = autoLayout.label = new cc.LabelTTF(title, JSFontBoldName, fontSize || 13);
            fontColor && titleLabel.setFontFillColor(fontColor);

            // 是否要有底線
            if (isBottomLine) {
                var titleSize = titleLabel.getContentSize();

                // 創一個Node放文字跟底線
                var titleNode = new cc.Node();
                titleNode.setContentSize(titleSize);
                titleNode.setCascadeColorEnabled(true);
                titleNode.setCascadeOpacityEnabled(true);
                autoLayout.addChild(titleNode);

                // 文字的底線
                var line = autoLayout.line = new cc.LayerColor(fontColor ? fontColor : JSColor.WHITE, titleSize.width, lineSizeNum || 1);
                line.setPositionY(titleSize.height / 2 - 8 + (lineOffsetY || 0));
                titleNode.addChild(line);

                // 文字排位置
                titleLabel.setPosition(titleSize.width / 2, titleSize.height / 2);
                titleNode.addChild(titleLabel);
            } else {
                // 沒有底線 文字直接加在autoLayout
                autoLayout.addChild(titleLabel);
            }

        }
    }

    // 設定按下和Disable的Node狀態
    itemNode[1].setColor(JSColor.GRAY);
    itemNode[2].setOpacity(150);

    return itemNode;
};

/**
 * 圖示環繞在圖片四方(上下左右) 回傳itemNode[3]
 * 備註: 非中英語系之語言文字位置可能偏移
 * @param bg            單一圖片
 * @param item          圖示
 * @param itemDir       圖示方位("TOP", "BOTTOM", "LEFT", "RIGHT")
 * @param nodeSize      指定nodeSize
 * @param space         AutoLayout的裡面位移
 * @returns {Array}
 */
ButtonUtility.createSingleSpriteWithSideItemNodes = function (bg, item, itemDir, nodeSize = null, space = 0) {
    //GSAutoLayout.TYPE(水平.垂直) GSAutoLayout.DIRECTION(正向:左至右.反向:右至左)
    var type, direction;
    switch (itemDir) {
        case "RIGHT":
            //水平正向
            type = GSAutoLayout.TYPE.HORIZONTAL;
            direction = GSAutoLayout.DIRECTION.NORMAL;
            break;
        case "LEFT":
            //水平反向
            type = GSAutoLayout.TYPE.HORIZONTAL;
            direction = GSAutoLayout.DIRECTION.REVERSE;
            break;
        case "BOTTOM":
            //垂直正向
            type = GSAutoLayout.TYPE.VERTICAL;
            direction = GSAutoLayout.DIRECTION.NORMAL;
            break;
        case "TOP":
            //垂直反向
            type = GSAutoLayout.TYPE.VERTICAL;
            direction = GSAutoLayout.DIRECTION.REVERSE;
            break;
    }

    var itemNode = [];
    for (var i = 0; i < 3; i++) {
        var autoLayout = itemNode[i] = new GSAutoLayoutNode();
        autoLayout.setType(type);
        autoLayout.setDirection(direction);
        autoLayout.setSpace(space);

        if (nodeSize !== null)
            autoLayout.setNodeSize(nodeSize.width, nodeSize.height);

        //圖
        autoLayout.addChild(new cc.Sprite(bg));

        //圖示
        if (item) {
            var itemSp = itemNode[i].item = new cc.Sprite(item);
            autoLayout.addChild(itemSp);
        }
    }

    //設定按下和Disable的Node狀態
    itemNode[1].setColor(JSColor.GRAY);
    itemNode[2].setOpacity(150);

    return itemNode;
};

/**
 * 建立 一般的頁籤 (可以有高低差的背景) 回傳 itemNodes[3]
 * @param images            圖檔
 * @param size              圖檔大小
 * @param titles            標題
 * @param fontSize          標題大小
 * @param [fontColors]      標題顏色
 * @param [fontOffsets]     標題位置調整
 * @param [bgSizeOffsets]   圖檔大小調整
 * @param [bgPosOffsets]    圖檔位置調整
 * @returns {Array}
 */
ButtonUtility.createSimpleTabNodes = function (images, size, titles, fontSize, fontColors, fontOffsets = [cc.p(0, 0)], bgSizeOffsets, bgPosOffsets) {
    // 利用 bgSizeOffsets 來調整背圖大小，並且讓他貼齊邊邊
    bgSizeOffsets = bgSizeOffsets || [];
    if (JSCodeUtility.checkType(bgSizeOffsets) !== JSTYPE.ARRAY)
        bgSizeOffsets = [bgSizeOffsets];

    // 利用 bgPosOffsets 來調整背圖位置
    bgPosOffsets = bgPosOffsets || [];
    if (JSCodeUtility.checkType(bgPosOffsets) !== JSTYPE.ARRAY)
        bgPosOffsets = [bgPosOffsets];

    fontColors = fontColors || [cc.color(255, 255, 255, 160), cc.color(255, 255, 255, 255), cc.color(255, 255, 255, 255)];

    var itemNodes = ButtonUtility.createArrayScale9Nodes(images, size, titles, fontSize, fontColors, fontOffsets);

    // 調整背圖大小及位置
    (bgSizeOffsets.length || bgPosOffsets.length) && itemNodes.forEach((node, i) => {
        // 調整背圖大小
        var bgSizeOffset = bgSizeOffsets[i];
        if (bgSizeOffset) {
            node.bg.setPreferredSize(cc.size(size.width + bgSizeOffset.width, size.height + bgSizeOffset.height));
            node.bg.setPosition((size.width + bgSizeOffset.width) / 2, (size.height + bgSizeOffset.height) / 2);
        }

        // 調整背圖位置
        var bgPosOffset = bgPosOffsets[i];
        if (bgPosOffset) {
            node.bg.setPosition(cc.pAdd(node.bg.getPosition(), bgPosOffset));
        }
    });

    // 頁籤特別設定
    itemNodes[1].setColor(JSColor.WHITE);
    itemNodes[2].setOpacity(255);

    return itemNodes;
};

/**
 * 建立 一般的頁籤 (可以有高低差的背景) 回傳 itemNodes[3]
 * @param images            圖檔
 * @param size              圖檔大小
 * @param wordImages        標題
 * @param wordImagesOffset  標題位置調整
 * @param bgSizeOffsets     圖檔大小調整
 * @param bgPosOffsets      圖檔位置調整
 * @returns {Array}
 */
ButtonUtility.createWordImageTabNodes = function (images, size, wordImages, wordImagesOffset = [cc.p(0, 0)], bgSizeOffsets, bgPosOffsets) {
    // 利用 bgSizeOffsets 來調整背圖大小，並且讓他貼齊邊邊
    bgSizeOffsets = bgSizeOffsets || [];
    if (JSCodeUtility.checkType(bgSizeOffsets) !== JSTYPE.ARRAY)
        bgSizeOffsets = [bgSizeOffsets];

    // 利用 bgPosOffsets 來調整背圖位置
    bgPosOffsets = bgPosOffsets || [];
    if (JSCodeUtility.checkType(bgPosOffsets) !== JSTYPE.ARRAY)
        bgPosOffsets = [bgPosOffsets];

    var itemNodes = ButtonUtility.createSingleScale9SpriteNodes(images, size, wordImages, wordImagesOffset);

    // 調整背圖大小及位置
    (bgSizeOffsets.length || bgPosOffsets.length) && itemNodes.forEach((node, i) => {
        // 調整背圖大小
        var bgSizeOffset = bgSizeOffsets[i];
        if (bgSizeOffset) {
            node.bg.setPreferredSize(cc.size(size.width + bgSizeOffset.width, size.height + bgSizeOffset.height));
            node.bg.setPosition((size.width + bgSizeOffset.width) / 2, (size.height + bgSizeOffset.height) / 2);
        }

        // 調整背圖位置
        var bgPosOffset = bgPosOffsets[i];
        if (bgPosOffset) {
            node.bg.setPosition(cc.pAdd(node.bg.getPosition(), bgPosOffset));
        }
    });

    // 頁籤特別設定
    itemNodes[1].setColor(JSColor.WHITE);
    itemNodes[2].setOpacity(255);

    return itemNodes;
};

/**
 * 回傳Sprite組成的Array
 * @param normalSpName
 * @param selectedSpName
 * @param disableSpName
 * @returns {Array}
 */
ButtonUtility.createBtnSpriteArray = function (normalSpName, selectedSpName, disableSpName) {
    var spriteArray = [];

    if (normalSpName) {
        var sprite = new cc.Sprite(normalSpName);
        spriteArray.push(sprite);

        selectedSpName = selectedSpName !== undefined ? selectedSpName : normalSpName;
        sprite = new cc.Sprite(selectedSpName);
        sprite.setColor(JSColor.GRAY);
        spriteArray.push(sprite);

        disableSpName = disableSpName !== undefined ? disableSpName : normalSpName;
        sprite = new cc.Sprite(disableSpName);
        sprite.setOpacity(150);
        spriteArray.push(sprite);
    }

    return spriteArray;
};

/**
 * 產生check box的MenuItemSprite
 * @param images {Array} [未選取.png, 選取.png]
 * @param string check box 後面接的文字
 * @param fontSize 文字大小
 * @param fontColor 文字顏色
 * @returns {Array} 回傳MenuItemSprite
 */
ButtonUtility.createCheckBoxMenuItem = function (images, string, fontSize = 26, fontColor = JSColor.WHITE) {
    var toggleItems = [];
    for (var i = 0; i < 2; i++) {
        var itemNode = [];
        for (var j = 0; j < 2; j++) {
            var node = itemNode[j] = new cc.Node();
            node.setCascadeColorEnabled(true);
            node.setCascadeOpacityEnabled(true);

            var select = new cc.Sprite(images[i]);
            select.setAnchorPoint(0, 0.5);
            var selectSize = select.getBoundingBox();
            node.addChild(select);

            var labelSize = cc.size(0, 0);
            if (string) {
                var titleLabel = new cc.LabelTTF(string, JSFontBoldName, fontSize);
                titleLabel.setFontFillColor(fontColor);
                titleLabel.setAnchorPoint(0, 0.5);
                node.addChild(titleLabel);
                labelSize = titleLabel.getContentSize();
            }

            var btnSize = cc.size(selectSize.width + labelSize.width + 4, selectSize.height);
            node.setContentSize(btnSize);

            // 設位置
            select.setPosition(0, btnSize.height / 2);
            titleLabel && titleLabel.setPosition(selectSize.width + 8, btnSize.height / 2);

            if (j === 1)
                node.setColor(JSColor.GRAY);
        }
        toggleItems[i] = new cc.MenuItemSprite(itemNode[0], itemNode[1]);
    }
    return toggleItems;
};

/**
 * 創一個GSControlButton 傳圖片 文字
 */
ButtonUtility.createSimpleButton = function (bgImage, btnSize, title, fontColor = JSColor.WHITE, fontSize = 12) {
    // 背景圖片
    var btnBgSprite = new ccui.Scale9Sprite(bgImage);

    // 假如沒傳size 就是原本圖片的size
    btnSize = btnSize || btnBgSprite.getContentSize();

    // 創主按鈕
    var button = new GSControlButton(null, btnSize);

    // 背景圖片設定
    btnBgSprite.setPreferredSize(btnSize);
    button.addChildToContentNode(btnBgSprite);

    // 設定背景給他 方便之後換圖
    button.bg = btnBgSprite;

    if (title) {
        var btnTitle = new cc.LabelTTF(title, JSFontBoldName, fontSize);
        btnTitle.setFontFillColor(fontColor);
        button.addChildToContentNode(btnTitle);

        // 設定Label給他 方便之後換文字
        button.label = btnTitle;
    }

    return button;
};

/**
 * 創一個GSControlButton 傳兩張圖片
 */
ButtonUtility.createSimpleImageButton = function (bgImage, btnSize, wordImage) {
    // 背景圖片
    var btnBgSprite = new ccui.Scale9Sprite(bgImage);

    // 假如沒傳size 就是原本圖片的size
    btnSize = btnSize || btnBgSprite.getContentSize();

    // 創主按鈕
    var button = new GSControlButton(null, btnSize);

    // 背景圖片設定
    btnBgSprite.setPreferredSize(btnSize);
    button.addChildToContentNode(btnBgSprite);

    // 設定背景給他 方便之後換圖
    button.bg = btnBgSprite;

    if (wordImage) {
        var btnWordSprite = new cc.Sprite(wordImage);
        button.addChildToContentNode(btnWordSprite);

        // 設定回去
        button.wordImage = btnWordSprite;
    }

    return button;
};

/**
 * 創一個文字有底線的 GSControlButton
 */
ButtonUtility.createTextUnderLineButton = function (title, color = JSColor.WHITE, fontSize = 12) {
    // 文字
    var titleLabel = new cc.LabelTTF(title, JSFontBoldName, fontSize);
    titleLabel.setFontFillColor(color);
    var size = titleLabel.getContentSize();

    // 創主按鈕
    var button = new GSControlButton(null, size);

    button.addChildToContentNode(titleLabel);

    // 底線
    var line = new cc.LayerColor(color, size.width, 1);
    line.setPosition(-size.width / 2, -size.height / 2);
    button.addChildToContentNode(line);

    return button;
};
