var GSAppsFlyerWrapper = {};
var GSAPPSFLYER_RECORD_PREFIX = "GSAppsFlyerRecord_";       // 需要儲值資料在本機時，可以固定使用相同的前置調當key

(function () {
    var isNative = cc.sys.isNative;

    GSAppsFlyerWrapper.record = {};                         // GSAppsFlyerWrapper

    /**
     * 開始追蹤 第一次啟動App需要執行
     */
    GSAppsFlyerWrapper.start = function (key, customerID) {
        if (isNative)
            GSAppsFlyer.start(key, customerID);
    };

    /**
     * 追蹤Event
     */
    GSAppsFlyerWrapper.logEvent = function (event, keyArray, valueArray) {
        if (isNative) {
            keyArray = keyArray || [];
            valueArray = valueArray || [];
            GSAppsFlyer.logEvent(event, keyArray, valueArray);
        }
    };

    GSAppsFlyerWrapper.logEventByCounter = function (event) {
        if (isNative) {
            GSAppsFlyer.logEventByCounter(event);
        }
    };

    /**
     * 追蹤purchase event
     */
    GSAppsFlyerWrapper.logEventPurchase = function (jsonString) {
        if (isNative)
            GSAppsFlyer.logEventPurchase(jsonString);
    };

    /**
     * 廣告收益
     * @param country
     * @param currency
     * @param revenue
     */
    GSAppsFlyerWrapper.watchAdRevenue = function (country, currency, revenue) {
        if (!isNative) return;

        // 有可能會沒有revenue
        if (typeof revenue === 'undefined' || revenue === null) return;

        country  = country  || "";
        currency = currency || "";
        revenue  = revenue  || 0;
        var keyArray   = ["af_country", "af_currency", "af_revenue"];
        var valueArray = [country, currency, revenue];
        GSAppsFlyer.logEvent("watch_ad_revenue", keyArray, valueArray);
    };

}.call((window || module || {})));

