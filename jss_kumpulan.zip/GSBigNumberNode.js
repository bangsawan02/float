/**
 * Created by chris.chang on 2022/6/8.
 */

var GSBigNumberNode = GSNumberNode.extend({
    ctor: function (number, prefixName, numberSize, dotSize, addPlus, addComma, maxWidth = 0, numberFormat = "%02d") {
        this._super(0, prefixName, numberSize, dotSize, addPlus, addComma, maxWidth, numberFormat);

        this._totalNumber = "0";                // 最後的數字
        this._nowNumber = "0";                  // 現在Label的數字
        this._floorNumber = "0";                // 第一次要做動畫的數字
        this._deltaNumber = "0";                // 動畫要變化的數量

        number > 0 && this.setNumber(number);
    },

    // 直接設定數字, action 用來讓每個數字有要跑的action
    setNumber: function (number, actionParam) {
        this.removeAllChildren();
        this._spriteArray.length = 0;

        // 轉成字串跟確定是數字
        number = JSCodeUtility.getStringValue(number).match(/^[1-9]\d*|^0$/);
        number = number ? number[0] : "";

        if (number.length === 0) {
            cc.log("Error: GSBigNumberLabel Number is invalid");
            return;
        }

        this._nowNumber = number;
        var nowNumber = number.split("");

        var i = 0;
        this._totalDotCount = 0;

        // 加入字尾符號
        if (this._suffixMarkName.length) {

            var suffixMarkSprite = this._suffixMarkSprite = new cc.Sprite("#" + this._suffixMarkName);
            suffixMarkSprite.setScale(this._markScale);
            this.addChild(suffixMarkSprite);

            this._spriteArray.push(suffixMarkSprite);
        }

        do {
            var imageName = JSStringUtility.format("#%s_" + this._numberFormat + ".png", this._prefixName, nowNumber.pop());
            var numberSprite = new cc.Sprite(imageName);
            numberSprite.setScale(this._numberScale);
            this.addChild(numberSprite);

            i++;

            this._spriteArray.push(numberSprite);

            if (this._needAddComma && i % 3 === 0 && nowNumber.length !== 0) {
                //要加逗號
                var dotSprite = new cc.Sprite(JSStringUtility.format("#%s_%s.png", this._prefixName, ","));
                dotSprite.setPositionY(this._docOfssetY);
                dotSprite.setScale(this._numberScale);
                this.addChild(dotSprite);
                this._totalDotCount++;

                this._spriteArray.push(dotSprite);
            }
        } while (nowNumber.length > 0);

        // 加入字首符號
        if (this._prefixMarkName.length) {
            var prefixMarkSprite = this._prefixMarkSprite = new cc.Sprite("#" + this._prefixMarkName);
            prefixMarkSprite.setScale(this._markScale);
            this.addChild(prefixMarkSprite);

            this._spriteArray.push(prefixMarkSprite);
        }

        if (actionParam) {
            var action = actionParam.action;
            this._spriteArray.forEach((sprite, index, array) => {
                var actionClone = action.clone();
                if (index === array.length - 1) {
                    // 最後一個sprite執行後作callBack funtions
                    var actionCallBack = cc.callFunc(() => {
                        this._finishCallback && this._finishCallback();
                    });

                    sprite.setOpacity(0);
                    sprite.runAction(cc.sequence(cc.delayTime(actionParam.time * (array.length - index)), actionClone, actionCallBack));
                }
                else {
                    sprite.runAction(cc.sequence(cc.delayTime(actionParam.time * (array.length - index)), actionClone));
                }
            });
        }

        this.updatePosition();
    },

    /*
     * 指定動畫到特定數字，是否始用動畫
     * @param toNumber 目標數字
     * @param animation 是否用動畫
     *
     */
    setToNumber: function (toNumber, animation /* true */) {
        if (JSCodeUtility.checkType(animation) != JSTYPE.BOOLEAN)
            animation = true;

        // 轉成字串跟確定是數字
        toNumber = JSCodeUtility.getStringValue(toNumber).match(/^[1-9]\d*|^0$/);
        toNumber = toNumber ? toNumber[0] : "";

        if (toNumber.length === 0) {
            cc.log("Error: GSBigNumberLabel Number is invalid");
            return;
        }

        // 目標數字一樣不用再重設
        if (this._totalNumber === toNumber && animation === this._isAnim)
            return;

        // 停止動畫
        this.unschedule(this.scheduleUpdateNumber);
        this._isAnim = false;

        if (animation) {
            this._totalNumber = toNumber;
            this._floorNumber = this._nowNumber;
            this._usedTime = 0;

            if (this._floorNumber == this._totalNumber) {
                this.setNumber(this._totalNumber);
                return;
            } else {
                this.schedule(this.scheduleUpdateNumber);
                this._isAnim = true;
                this._deltaNumber = JSCodeUtility.bigNumberSub(this._totalNumber, this._floorNumber);
            }
        } else {
            this._totalNumber = toNumber;
            this.setNumber(toNumber);
        }
    },

    // 動畫更新數字
    scheduleUpdateNumber: function (dt) {
        if (this._usedTime + dt < this._updateTime) {
            // 時間還沒到，所以計算要增加的
            let extraNumber = JSCodeUtility.bigNumberMultiply(this._deltaNumber, JSCodeUtility.getStringValue(dt / this._updateTime)).split(".")[0];
            for (let index = 1; index < extraNumber.length; index++) {
                if (extraNumber[index] === ".") {
                    break;
                }

                extraNumber = JSCodeUtility.bigNumberSub(extraNumber, (JSCodeUtility.getRandomInt(0, 9) * Math.pow(10, extraNumber.length - index - 1)).toString());
            }

            // 算更新百分比
            let percent = JSCodeUtility.getStringValue(this._usedTime / this._updateTime);

            // 計算更新後的數字
            this._nowNumber = JSCodeUtility.bigNumberAdd(this._floorNumber, JSCodeUtility.bigNumberMultiply(this._deltaNumber, percent));
            this._nowNumber = JSCodeUtility.bigNumberAdd(this._nowNumber, extraNumber);

            var parentVisible = this.getParent().isVisible();
            if (parentVisible && this.isVisible() && this._effect) {
                if (this._usedTime > this._nowEffectIndex) {
                    this._nowEffectIndex += this._frequency;
                }
            }

            this._usedTime += dt;
        }
        else {
            this.unschedule(this.scheduleUpdateNumber);
            this._isAnim = false;
            this._nowNumber = this._totalNumber;
            this._nowEffectIndex = 0;

            if (this._finishCallback) {
                var action1 = cc.delayTime(dt);
                var action2 = cc.callFunc(() => {
                    this._finishCallback();
                });
                this.runAction(cc.sequence(action1, action2));
            }
        }
        this.setNumber(this._nowNumber);
    },
});