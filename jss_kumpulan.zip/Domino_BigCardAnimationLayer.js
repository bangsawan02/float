/**
 * 大牌動畫
 */

var Domino_BigCardAnimationLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this._cardsValue = null;            // 每一家的牌型
        this._animationName = [
            "",                             // 普通牌
            "01_qiuqiu",                    // QQ
            "02_bigcards",                  // 4張牌總分超過39分 (每個數字是單獨算的 >= 39 都算)
            "03_smallcards",                // 4張牌總分少於9 (每個數字是單獨算的 <= 9 都算)
            "04_twincards",                 // 4張牌都是對子
            "05_sixdevil",                  // 4張牌都是點數6
        ];

        // H5的話preload這些材質
        if (!cc.sys.isNative) {
            var spineArray = [];
            for (var i = 1; i < this._animationName.length; i++) {
                var fileName = this._animationName[i];
                spineArray.push("spine/BigCardAnimation/" + fileName + ".json");
                spineArray.push("spine/BigCardAnimation/" + fileName + ".atlas");
                spineArray.push("spine/BigCardAnimation/" + fileName + ".png");
            }
            cc.loader.load(spineArray, function () {
            });
        }
    },

    /**
     * 結算時比牌 先記下來就好 假如有大牌動畫在處理
     */
    cmd_finish1: function (value) {
        // 結算 每個人的牌型 finish1 [["12","33","36","00"],"","","","",["44","01","46","11"],""]
        this._cardsValue = value;
    },

    // 收到大牌動畫
    cmd_winCards: function (value) {
        // {"pos":"0","ct":0}
        var jsonValue = JSON.parse(value);
        var cardType = JSCodeUtility.getIntValue(jsonValue["ct"]);
        if (cardType === 0 || cardType > 5 || !this._cardsValue) return;

        // 算好位置
        var serverSit = JSCodeUtility.getIntValue(jsonValue["pos"]);
        var sitNum = DataModal.gameData.getDirectionByServerDirection(serverSit);
        var position;
        if (sitNum === 0 && DataModal.gameData.myPos > -1) {
            // 自己的手牌位置
            position = cc.p(256 + JSScreenBonusHalfWidth, 87 + JSScreenBonusHalfHeight);
        } else {
            // 座位人像上
            position = Domino_GameUtility.getPlayerPosition(sitNum);
        }

        // 畫面
        var mainNode = new cc.Node();
        mainNode.setCascadeOpacityEnabled(true);
        this.addChild(mainNode);

        var bgLayer = new cc.LayerColor(cc.color(0, 0, 0, 0), JSVisibleSize.width, JSVisibleSize.height);
        mainNode.addChild(bgLayer);
        bgLayer.runAction(cc.fadeTo(0.3, 150));

        // 背景閃光
        var animationPosY = JSScreenMidPos.y + 35;
        var bgSprite = new cc.Sprite("#lobby_bg_reward.png");
        bgSprite.setPosition(JSScreenMidPos.x, animationPosY);
        bgSprite.setScale(0);
        mainNode.addChild(bgSprite);
        bgSprite.runAction(cc.scaleTo(0.3, 2).easing(cc.easeBackOut()));

        // 牌
        var cardStringArray = JSON.parse(this._cardsValue);
        var cards = new Domino_CardSetNode(cardStringArray[serverSit]);
        cards.setPosition(position);
        mainNode.addChild(cards);

        // 主動畫
        var fileName = this._animationName[cardType];
        var spineArray = [
            "spine/BigCardAnimation/" + fileName + ".json",
            "spine/BigCardAnimation/" + fileName + ".atlas",
            "spine/BigCardAnimation/" + fileName + ".png",
        ];
        var spineNode = new cc.Node();
        spineNode.setCascadeOpacityEnabled(true);
        mainNode.addChild(spineNode);
        var addSpineAnimation = function () {
            var avatar = new sp.SkeletonAnimation(spineArray[0], spineArray[1], 0.25);
            avatar.setPosition(JSScreenMidPos.x, animationPosY);
            avatar.setAnimation(0, 'animation', false);
            spineNode.addChild(avatar);
        };
        if (!cc.sys.isNative) {
            // H5要先去讀
            cc.loader.load(spineArray, function (a, b) {
                addSpineAnimation();
            });
        } else {
            // 原生不用讀
            addSpineAnimation();
        }

        // 幾秒後砍掉
        mainNode.runAction(cc.sequence(
            cc.delayTime(1.5),
            cc.fadeOut(0.2),
            cc.removeSelf()
        ));
    },
});