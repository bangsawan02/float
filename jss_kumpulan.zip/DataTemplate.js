/**
 * 資料模板
 *
 * - 可用 `registerSocket(keyMap)` 註冊 cmd 至 socket
 * - 可用 `setIsBlockBlackAccount` 直接開關這一個 data 要不要擋黑帳號，處理 cmd 的 func 不需要再判斷
 * - 可用 `sendTracking` 送出含有分群的埋點
 * - 可用 `setRemainTime(jsonValue["left_time"])` 直接設定此資料的剩餘時間
 * - 可用 `getIsOpen` or `isOpen` 判斷是否開啟
 *
 * @author kai.wu
 */
class DataTemplate {
    constructor() {
        // 標記是否已完成 Socket 註冊（初始化為未註冊）
        this._didRegisterSocket = false;

        // 標記是否封鎖黑名單帳號（初始化為未封鎖）
        this._isBlockBlackAccount = false;

        // 埋點 campaign id (Texas_UserLog.CAMPAIGN_ID)
        this.CAMPAIGN_ID = undefined;

        // 初始化，清除資料
        this.clean();
    }

    /**
     * 清除資料
     */
    clean() {
        /**
         * 錯誤碼，預設為-1
         * @type {number}
         * @deprecated 改用 `isSuccessful` setter 與 `isOpen` getter
         */
        this.error = -1;

        this.remainTime = 0;    // 活動剩餘時間
        this.socketTime = 0;    // 收到當下時間
        this.group = null;      // 活動分群
    }

    /**
     * 釋放資源
     */
    dispose() {
        this.clean();

        if (this._didRegisterSocket) {
            // 砍掉socket
            DataProcess.removeSocketKeyDispatch(this);

            // 記下清掉 Socket 註冊
            this._didRegisterSocket = false;
        }
    }

    /**
     * 註冊 socket
     * @param {object} keyMap
     */
    registerSocket(keyMap) {
        for (let [cmd, func] of Object.entries(keyMap)) {
            // 附加黑帳號檢查 script 到每一個 cmd_xxx function 前
            keyMap[cmd] = (key, value) => {
                if (this._isBlockBlackAccount && DataModal.profileData.isBlackAccount) {
                    return;
                }
                func.apply(this, [key, value]);
            };
        }
        DataProcess.addSocketKeyDispatch(this, keyMap);

        // 記下完成 Socket 註冊
        this._didRegisterSocket = true;
    }

    /**
     * 設定是否要擋黑帳號
     */
    setIsBlockBlackAccount(isBlock) {
        this._isBlockBlackAccount = isBlock;
    }

    /**
     * 取得 icon 資料
     * @abstract
     */
    requestIcon() {}

    /**
     * 取得 info 資料
     * @abstract
     */
    requestInfo() {}

    /**
     * 送出埋點
     * @param {number | number[]} trackCode
     * @param {boolean} isGrouping 是否要分群，預設會分群
     */
    sendTracking(trackCode, isGrouping = true) {
        if (this.isOpen) {
            TexasUtility.sendUserAnalyticsTrack(trackCode, isGrouping ? this.group : undefined);
        }
    }

    /**
     * 送出埋點
     * @param {string | string[]} trackKey
     * @param {boolean} isGrouping 是否要分群，預設會分群
     */
    sendTrackingByKey(trackKey, isGrouping = true) {
        if (this.isOpen) {
            UserAnalyticsTrackUtils.sendTrack(trackKey, isGrouping ? this.group : undefined);
        }
    }

    /**
     * 是否開啟
     * @returns {boolean}
     * @deprecated 改用 `isOpen`
     */
    getIsOpen() {
        return this.error === 0 && this.getRemainTime() > 0;
    }

    /**
     * 是否開啟
     * @returns {boolean}
     */
    get isOpen() {
        return this.error === 0 && this.getRemainTime() > 0;
    }

    /**
     * 是否成功取得資料
     * @param value
     */
    set isSuccessful(value) {
        this.error = value ? 0 : 1;
    }

    /**
     * 是否成功取得資料
     * @return {boolean}
     */
    get isSuccessful() {
        return this.error === 0;
    }

    /**
     * 設定剩餘時間
     * @param {any} time
     */
    setRemainTime(time) {
        [this.remainTime, this.socketTime] = this.parseRemainTime(time);
    }

    /**
     * 取得剩餘時間
     * @returns {number}
     */
    getRemainTime() {
        return JSCodeUtility.getRemainTimeByParam(this);
    }

    /**
     * 解析剩餘時間
     * @param {any} time
     * @returns {[number,number]} [剩餘秒數, 當下時間]
     */
    parseRemainTime(time) {
        return [JSCodeUtility.getIntValue(time), JSCodeUtility.getNowTime()];
    }

    /**
     * 送埋點
     * @param key
     */
    sendEventLog(key) {
        if (!this.CAMPAIGN_ID) {
            cc.error("未設定 CAMPAIGN_ID");
            return;
        }

        let actionLogID, eventName = 0;

        const logDetail = this.getEventLogDetail(key);
        actionLogID = logDetail.actionLogID;
        eventName = logDetail.eventName;

        const customObj = {};
        customObj.event_name = eventName;
        if (this.group) {
            customObj.campaign_group = this.group;
        }
        EventLogToBigQuery.logEvent(this.CAMPAIGN_ID, actionLogID, customObj);
    }

    /**
     * 拿埋點資料
     * @param {string} key - 埋點 key
     * @returns {{actionLogID: number, eventName: number}} 埋點詳細資料
     */
    getEventLogDetail(key) {
        cc.error('忘記 override getLogDetail 了喔！');
    }
}
