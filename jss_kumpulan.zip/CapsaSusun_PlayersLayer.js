/**
 * CapsaSusun放人的畫面
 * @type {*|void|Object|Function}
 */

var CapsaSusun_PlayersLayer = cc.Layer.extend({

    ctor: function () {
        this._super();

        // 是否第一次坐下
        this._isFirstSitDown = true;

        // 所有玩家的大頭照內容物
        // 畫面位置自已是0，自已的左邊是1、右邊是3
        var players = this._players = [];
        var playerLen = DataModal.gameData.playerNumber;
        for (var serverSitNum = 0; serverSitNum < playerLen; serverSitNum++) {
            var player = new CapsaSusun_PlayerNode(serverSitNum);
            player.setPosition(CapsaSusun_GameUtility.getPlayerPosition(serverSitNum));
            player.setVisible(false);
            this.addChild(player);

            players.push(player);
        }

        // 注冊畫面的Players(單純為了方便找位置，別做其它事)
        DataModal.gameData.registerPlayersLayer(this._players);

        // 為了向右、向左轉 記下來前後的Player
        for (var i = 0; i < playerLen; i++) {
            var nowPlayer = players[i];
            nowPlayer.prevPlayer = players[(i - 1) < 0 ? playerLen - 1 : i - 1];
            nowPlayer.nextPlayer = players[(i + 1) % playerLen];
        }

        // 玩家的動畫, 因為要蓋在手牌上面 所以另外創一個
        this._playerAnimLayer = new CapsaSusun_PlayerAnimLayer();
        this.addChild(this._playerAnimLayer, 10);

        //註冊通知
        GS.addListener("NotifyUpdateGameRankClass", this.notifyUpdateGameRankClass.bind(this), this);
        GS.addListener("NotifyCapsaSusunDealDone", this.notifyCapsaSusunDealDone.bind(this), this);
        GS.addListener("NotifyAddPlayerHandCard", this.notifyAddPlayerHandCard.bind(this), this);
        GS.addListener("NotifyPlayerShowWinAnimation", this.notifyPlayerShowWinAnimation.bind(this), this);
        GS.addListener("NotifyUpdatePlayerMoney", this.notifyUpdatePlayerMoney.bind(this), this);
        GS.addListener("NotifyRefreshIsForbidden", this.notifyRefreshIsForbidden.bind(this), this);
    },

    /**
     * 清掉所有資料 & 畫面
     */
    cleanData: function () {
        this._lastPlayer = null;

        this._players.forEach((player, index) => {
            player.setPosition(CapsaSusun_GameUtility.getPlayerPosition(index));
            player.stopAllActions();
            player.cleanData();
            player.setSitNum(index);
            player.serverSitNum = index;
        });
    },

    /**
     * 清掉手牌
     */
    cleanAllHandCard: function () {
        this._players.forEach(player => player.cleanHandCard());
    },

    /**
     *  所有Player向左 or 向右轉多少格. ex.turnAllPlayer(-2) 順時鐘轉兩格；turnAllPlayer(3) 逆時鐘轉3格
     *  @param {value} 向左向右幾格
     *  @private
     */
    _turnAllPlayer: function (value) {
        var total = 0;
        var len = this._players.length;

        if (value !== 0) {
            for (var i = 0; i < len; i++) {
                var nowPlayer = this._players[i];
                if (value < 0) {
                    nowPlayer.sitNumTmp = nowPlayer.nextPlayer.sitNum;
                } else if (value > 0) {
                    nowPlayer.sitNumTmp = nowPlayer.prevPlayer.sitNum;
                }
            }
            for (var i = 0; i < len; i++) {
                var nowPlayer = this._players[i];
                var pos = CapsaSusun_GameUtility.getPlayerPosition(nowPlayer.sitNumTmp);
                nowPlayer.setSitNum(nowPlayer.sitNumTmp);

                nowPlayer.setPosition(pos);
                total++;
                if (total === len) {
                    this._turnAllPlayer((value > 0) ? value - 1 : value + 1);
                }
            }
        } else {
            // 代表換完位了
            for (var serverSitNum = 0; serverSitNum < DataModal.gameData.playerNumber; serverSitNum++) {
                DataModal.gameData.serverSitNum[this._players[serverSitNum].sitNum] = serverSitNum;
            }

            // 更新每個PlayerNode的位置

            // 要換 dealer & spotlight 的位置
            GS.dispatchCustomEvent("NotifyGameTurnPositionFinish");
        }
    },

    /**
     * 更新狀態
     * @param haveMe 是否有自已, 要把位子橋到正前方
     */
    updateSeat: function (haveMe) {
        // 更新每個玩家基本資訊
        var gameData = DataModal.gameData;
        for (var i = 0; i < gameData.playerNumber; i++) {
            var data = DataModal.gameData.playerDataArray[i];
            this._players[i].updateSeat(data);
        }

        // 判斷是否要換成真正對應到的位置 自己永遠在下方
        var myPos = DataModal.gameData.myPos;
        if (haveMe && myPos >= 0 && myPos < DataModal.gameData.playerNumber) {
            var sitNum = DataModal.gameData.getDirectionByServerDirection(myPos);
            if (sitNum !== 0) {
                // 代表不是在下面
                this._turnAllPlayer(sitNum);
            }

            if (this._currentPlay) {
                GS.dispatchCustomEvent("NotifyUpdateCurrentSeatDone");
                this._currentPlay = false;
            }
        }
    },

    setplayingPlayers: function (players) {
        this._players.forEach(cur => cur.transToGray(true));

        players.forEach(cur => {
            this.setPlayerToGray(cur, false);
        });
    },

    setPlayerToGray: function (sit, isGray) {
        this._players[sit].transToGray(isGray);
    },

    /**
     * 取得玩每個玩家PlayerNode
     * @returns {Array}
     */
    getPlayers: function () {
        return this._players;
    },

    // 演相公牌動畫
    showFoulhandByServerPos: function (posArray, isAnime) {
        posArray.forEach(cur => {
            if (cur !== -1) {
                var player = this._players[cur];
                if (player)
                    this._playerAnimLayer.playAnimation(cur, CapsaSusun_PlayerAnimNode.Type.FOUL_HAND, isAnime);
            }
        });
    },

    // 收到相公牌
    showFoulhandAsync: function (value) {
        return new Promise(resolve => {
            this.showFoulhandByServerPos(value, true);

            this.runAction(cc.sequence(
                cc.delayTime(2.5),
                cc.callFunc(resolve)
            ));
        });
    },

    /**
     * 下一局時，重設外觀
     */
    cmd_OLEH: function () {
        // 清掉動畫
        this._playerAnimLayer.clean();
    },

    /**
     * 積分系統入坐動畫
     */
    cmd_showPlayerClass: function (value) {
        //   {
        //        "pos":"5",   #位置
        //        "dealerSay":"Selamat datang Aries Mo para pemain hebat di meja profesional", #荷官恭迎
        //        "userClass":{"score":"0","class":"0","ranking":"1"} #此玩家階級資料
        //   }
        var serverPos = value["pos"];               // GameLayer已經轉成數字了
        var player = this._players[serverPos];

        if (player && value.userClass) {
            var levelClass = JSCodeUtility.getIntValue(value.userClass["class"]);
            player.showFirstSitGameRankAnimation(levelClass);
        }
    },

    /**
     * 站起
     * @param {serverSitNum} 完家於server的位置
     */
    cmd_stand: function (serverSitNum) {
        var player = this._players[serverSitNum];

        // 判斷是否有這個玩家
        if (!player)
            return;

        if (player.getIsSelf() || !DataModal.gameData.haveMe) {
        }

        player.cleanData();
    },

    // 牌局重現
    cmd_current_playing: function () {
        // 假如當下沒在座位上 等收到座位要轉位的時候要轉位一次
        this._currentPlay = true;
    },

    /**
     * 更新每個人手上的籌碼
     */
    cmd_updateChips: function () {
        for (var i = 0; i < DataModal.gameData.playerNumber; i++) {
            var data = DataModal.gameData.playerDataArray[i];
            this._players[i].updateChips(data.money);
            this._players[i].money = data.money;
        }
    },

    /**
     * 更新每個人上面的配件
     * updateInfo [{"name_accessory":"Dewa%20Cinta","pic":"http://qq.mwsrv.com/texas9/images/default_pic/photo_m-2.png","name_medal":"","accessory":"3027","identity":"10000","name_identity":"Hide","medal":"8101"},{},{},{},{},{},{}]
     */
    cmd_updateInfo: function (value) {
        var jsonValue = JSON.parse(value);
        for (var i = 0; i < jsonValue.length; i++) {
            var param = jsonValue[i];
            if (param.length === 0)
                continue;

            // 有東西 更新玩家的資訊
            var player = this._players[i];
            var playerData = player.getPlayerData();
            if (playerData && playerData.getIsExist()) {
                //配戴徽章編號、名稱
                if (param.medal == "8101" || param.medal == "") {
                    playerData.medal.code = "";
                    playerData.medal.name = "";
                } else {
                    playerData.medal.code = JSCodeUtility.getStringValue(param["medal"]);
                    playerData.medal.name = JSCodeUtility.getStringValue(param["name_medal"]);
                }

                //配戴物品編號、名稱
                if (param.accessory == "1101" || param.accessory == "") {
                    playerData.accessory.code = "";
                    playerData.accessory.name = "";
                } else {
                    playerData.accessory.code = JSCodeUtility.getStringValue(param["accessory"]);
                    playerData.accessory.name = JSCodeUtility.getStringValue(param["name_accessory"]);
                }

                // 更新畫面
                player.updateAccessory();
            }
        }
    },

    /**
     * 更新等級
     * @param {value} socke傳回來的值
     */
    cmd_update_upgrade: function (value) {
        var jsonArray = JSON.parse(value);
        var needPlayEffect = false;
        for (var i = 0, len = jsonArray.length; i < len; i++) {
            var level = JSCodeUtility.getIntValue(jsonArray[i]);
            if (level != 0) {
                // 先判斷這使用者在不在場上
                var player = this._players[i];
                if (player && player.getIsExist()) {
                    this._playerAnimLayer.playAnimation(i, CapsaSusun_PlayerAnimNode.Type.LEVEL_UP, level);
                    needPlayEffect = true;
                }
            }
        }

        // 判斷是否要撥放音效
        needPlayEffect && MusicUtility.playEffect("Music/Effect/levelUp.mp3");
    },

    /**
     * 更新經驗值
     * @param {value} socke傳回來的值
     */
    cmd_update_getexp: function (value) {
        var jsonArray = JSON.parse(value);
        for (var i = 0, len = jsonArray.length; i < len; i++) {
            var exp = JSCodeUtility.getIntValue(jsonArray[i]);
            if (exp != 0) {
                // 先判斷這使用者在不在場上
                var player = this._players[i];
                if (player && player.getIsExist()) {
                    this._playerAnimLayer.playAnimation(i, CapsaSusun_PlayerAnimNode.Type.EXP, exp);
                }
            }
        }
    },

    /**
     * 更新積分
     * @param {String} value socke傳回來的值
     */
    cmd_update_gameRankUpdate: function (value) {
        // {"changeClass":["","","","","","",""],"scoreUpdate":["8","0","0","0","0","-1","0"]}
        var jsonValue = JSON.parse(value);
        var changeClass = jsonValue["changeClass"];
        var scoreUpdate = jsonValue["scoreUpdate"];
        for (var i = 0, len = scoreUpdate.length; i < len; i++) {
            var score = JSCodeUtility.getIntValue(scoreUpdate[i]);
            var player = this._players[i];
            if (player && score !== 0 && player.getIsExist()) {
                // 積分有更動
                this._playerAnimLayer.playAnimation(i, CapsaSusun_PlayerAnimNode.Type.GAME_RANK_SCORE_CHANGE, score);

                // 判斷是否階級有變動 且不是自己
                var levelClasss = changeClass[i];
                if (levelClasss && !player.getIsSelf()) {
                    player.showChangeGameRankClassAnimation(parseInt(levelClasss));
                }
            }
        }
    },

    /**
     * 撥放表情
     * mood y21610400@an y21610400 0 1 mood4
     */
    cmd_mood: function (value) {
        var valueArray = value.split(" ");
        var valueLen = valueArray.length;
        if (valueLen > 4) {
            var serverPos = parseInt(valueArray[valueLen - 3]);
            var moodString = valueArray[valueLen - 1];
            var player = this._players[serverPos];
            player && player.playMood(moodString);
        }
    },

    /**
     * VIP表情
     * vmood y21610400@an y21610400 0 1 mood4
     * @param value
     */
    cmd_vmood: function (value) {
        var valueArray = value.split(" ");
        var valueLen = valueArray.length;
        if (valueLen > 4) {
            var serverPos = parseInt(valueArray[valueLen - 3]);
            var moodString = valueArray[valueLen - 1];
            var player = this._players[serverPos];
            player.playMood("v" + moodString);
        }
    },

    /**
     * 撥放商城表情
     * store_mood j66002768@an Sam 0 1 mood11012
     */
    cmd_store_mood: function (value) {
        var valueArray = value.split(" ");
        var valueLen = valueArray.length;
        if (valueLen > 4) {
            var serverPos = parseInt(valueArray[valueLen - 3]);

            // 要把mood字串拿掉
            var moodString = valueArray[valueLen - 1];
            moodString = moodString.replace("mood", "");

            var player = this._players[serverPos];
            player.playMood(moodString);
        }
    },

    /**
     * 送禮物
     * gift_accessory 送禮人的位置 [收禮人的位置, 收禮人的位置,……] 禮物圖片編號 禮物名稱
     */
    cmd_gift_accessory: function (value) {
        var valueArray = value.split(" ");
        if (valueArray.length > 3) {
            var serverPos = parseInt(valueArray[0]);
            var toPosArray = JSON.parse(valueArray[1]);
            var itemID = valueArray[2];
            var itemName = decodeURIComponent(valueArray[3]);
            var myPos = DataModal.gameData.myPos;
            var size = cc.size(54, 54);                         // 送出去畫面的大小

            var sendFunc = (i) => {
                var toPos = parseInt(toPosArray[i]);
                var player = this._players[toPos];
                var playerData = player.getPlayerData();

                if (serverPos === myPos && serverPos === toPos) {
                    // 自己送給自己 更改自己的東西就好了
                    playerData.accessory.code = itemID;
                    playerData.accessory.name = itemName;

                    // ProfileData也要塞一份
                    DataModal.profileData.accessory.code = itemID;
                    DataModal.profileData.accessory.name = itemName;

                    // 更新手上的配件
                    player.updateAccessory();
                } else {
                    // 要跑動畫
                    var firstPosition = CapsaSusun_GameUtility.getPlayerPosition(DataModal.gameData.getDirectionByServerDirection(serverPos));
                    var endPosition = CapsaSusun_GameUtility.getPlayerPosition(DataModal.gameData.getDirectionByServerDirection(toPos));

                    var accessoryItemNode = new AccessoryItemNode(itemID, size.width, size.height, (accessoryNode) => {
                        if (this.__isDestroyed)
                            return;

                        // 當圖片下載結束或GAF產生出來 要開始移動
                        if (player.getIsExist()) {
                            // 移動過去
                            accessoryNode.runAction(cc.sequence(
                                cc.delayTime(0.2),
                                cc.moveTo(0.9, endPosition),
                                cc.delayTime(0.2),
                                cc.fadeOut(0.1),
                                cc.callFunc(() => {
                                    playerData.accessory.code = itemID;
                                    playerData.accessory.name = itemName;

                                    // 更新手上的配件
                                    player.updateAccessory();
                                }),
                                cc.removeSelf()
                            ));
                        } else {
                            // 人不見了 砍掉
                            accessoryNode.removeFromParent();
                        }
                    });
                    accessoryItemNode.setPosition(firstPosition);
                    this.addChild(accessoryItemNode, 15);
                }
            };

            for (var i = 0; i < toPosArray.length; i++) {
                sendFunc(i);
            }
        }
    },

    /**
     * 通知使用者的積分階級更新
     */
    notifyUpdateGameRankClass: function (event) {
        var levelClass = event.getUserData();
        var player = this._players[DataModal.gameData.myPos];
        player && player.showChangeGameRankClassAnimation(levelClass);
    },

    /**
     * 通知家手牌
     * @param event
     */
    notifyAddPlayerHandCard: function (event) {
        if (event) {
            this._players[event.getUserData()].addHandCard();
        }
    },

    /**
     * 通知發牌完成 玩家手牌要縮小
     */
    notifyCapsaSusunDealDone: function () {
        this._players.forEach(player => player.dealDone());
    },

    // 出現贏家動畫
    notifyPlayerShowWinAnimation: function (event) {
        if (event && event.getUserData()) {
            var serverDir = event.getUserData();
            serverDir.forEach(curWin => {
                this._playerAnimLayer.playAnimation(curWin, CapsaSusun_PlayerAnimNode.Type.WIN);
            });
        }
    },

    // 更新每家的金錢
    notifyUpdatePlayerMoney: function (event) {
        this.cmd_updateChips();
    },

    // 黑名單大頭照更新
    notifyRefreshIsForbidden: function (event) {
        if (!event)
            return;

        var blackAccount = event.getUserData();
        DataModal.gameData.playerDataArray.forEach((playerData, serverPos) => {
            if (blackAccount === playerData.account) {
                var url = DataModal.blacklistData.isAccountInList(playerData.account) ? "" : playerData.photoURL;
                this._players[serverPos].updateIsForbidden(url);
            }
        });
    }
});