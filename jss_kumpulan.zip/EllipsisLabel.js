/**
 * 自動截掉過長的文字並以...結尾
 *
 * @example
 * new EllipsisLabel("Content", JSFontName, 12, 50);
 *
 * @param {string} text     內文
 * @param {string} fontName 字型
 * @param {number} fontSize 字型大小
 * @param {number} maxWidth 最大寬度
 */
var EllipsisLabel = cc.LabelTTF.extend({
    ctor: function (text, fontName, fontSize, maxWidth) {
        this._super("", fontName, fontSize);

        this._maxWidth = maxWidth;

        this.setString(text);
    },

    _refreshView: function () {
        cc.LabelTTF.prototype.setString.call(this, this._originalString);
        if (this._maxWidth && this.getContentSize().width > this._maxWidth) {
            // 拷貝字串
            let text = this._originalString.slice();

            // Binary Search
            let min = 0;
            let max = text.length;
            while (min < max) {
                let mid = Math.floor((min + max) / 2);
                let partialText = text.slice(0, mid);
                cc.LabelTTF.prototype.setString.call(this, partialText + "...");

                let width = this.getContentSize().width;
                if (width <= this._maxWidth) {
                    min = mid + 1;
                } else {
                    max = mid;
                }
            }

            cc.LabelTTF.prototype.setString.call(this, text.slice(0, max - 1) + "...");
        }
    },

    /**
     * 設定文字
     * @param {string} text
     * @override
     */
    setString: function (text) {
        this._originalString = text;
        this._refreshView();
    },

    /**
     * 設定最大寬度
     * @param {number} width
     */
    setMaxWidth: function (width) {
        this._maxWidth = width;
        this._refreshView();
    },

    /**
     * 設定寬度和高度
     * @param {cc.Size | Number}    dim
     * @param {Number}              [height]
     */
    setDimensions: function (dim, height) {
        cc.LabelTTF.prototype.setDimensions.call(this, dim, height);
        this._maxWidth = height ? dim : dim.width;
        this._refreshView();
    },

    /**
     * 設定字體大小
     * @param {Number} fontSize
     */
    setFontSize: function (fontSize) {
        this._super(fontSize);
        this._refreshView();
    },

    /**
     * 取得最大寬度
     * @returns {Number}
     */
    getMaxWidth: function () {
        return this._maxWidth || this.getContentSize().width;
    },

    /**
     * 取得原始字串
     * @returns {string}
     * @override
     */
    getString: function () {
        return this._originalString;
    },

    /**
     * 取得顯示的字串
     * @returns {String}
     */
    getDisplayedString: function () {
        return cc.LabelTTF.prototype.getString.call(this);
    },
});

/**
 * 截短文字，並加上 ...
 * @param {cc.Node} target
 * @param {string} text     內文
 * @param {string} fontName 字型
 * @param {number} fontSize 字型大小
 * @param {number} maxWidth 最大寬度
 */
EllipsisLabel.shortenString = function (target, text, fontName, fontSize, maxWidth) {
    // 此處 EllipsisLabel 僅用於截短暱稱
    let ellipsisLabel = new EllipsisLabel(text, fontName, fontSize, maxWidth);
    ellipsisLabel.setVisible(false);

    // 取得截短後的暱稱
    let nickname = ellipsisLabel.getDisplayedString();

    // 新增並移除（讓他可以正常的被 release）
    target.addChild(ellipsisLabel);
    ellipsisLabel.removeFromParent();

    return nickname;
};
