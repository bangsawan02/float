/**
 * 免費幣整合的資料
 */

// 免費幣整合項目跟server對應的編號(這邊印/越是共用的)
var FreeChipListType = {
    DAILY_MISSION: 1,                   // 每日任務
    DAILY_LOGIN: 2,                     // 每日簽到(5.5.3改為整合簽到)
    VIDEO_AD: 4,                        // 影片廣告
    // EVENT_WHEEL: 5,                  // InApp活動的轉盤 (8.5 已拔除)
    // EVENT_BINGO: 6,                  // InApp活動的賓果 (8.5 已拔除)
    QUESTIONNAIREL: 7,                  // 問卷
    GUILD_SURPRISE: 8,                  // 公會驚喜(沒公會不顯示 有公會就顯示)
    SERIAL_PRIZE: 9,                    // 輸入序號兌換獎勵
    // WEEKLY_TASK: 10,                 // 週任務 (5.4.5 已拔除)
    JOIN_GUILD: 11,                     // 加入公會獎勵
    GAME_RANK: 12,                      // 積分
    CONTINUE_SIGNIN: 13,                // 連續簽到
    MASTER_POKER: 14,                   // 猜手牌遊戲
    CALLBACK_MISSION: 15,               // 回流任務
    EVENT: 16,                          // 多種趣味活動拿獎勵
    ACHIEVEMENT: 17,                    // 成就
    DAILY_LUCKY_WHEEL: 18,              // 每日幸運輪盤
    CARD_KING: 19,                      // 牌王
    LOGIN_REWARD: 20,                   // 特定時段登入獎勵
    DICE_BO: 21,                        // 骰寶
    BLACK_JACK: 22,                     // 21點
    // SLOT_FRUIT: 23,                  // 水果拉霸 (5.5.0 已拔除)
    GROWING_MISSION: 24,                // 成長任務
    VEGAS_RACING: 25,                   // 極速競飆
    // STAR_SHINE: 26,                  // 星耀票券 (5.4.5 已拔除)
    VEGAS_NEWBIE_MISSION: 27,           // VIP機台新手任務
    NEWBIE_LEVEL_GIFT: 28,              // 等級禮包
    PLAY_GAME: 29,                      // 玩牌(不限玩法)
    GAMBLER_ROAD: 30,                   // 牌王之路(中文:賭神之路)
    // TREASURE_ISLAND: 31,             // 勇闖金銀島 (5.5.2 已拔除)
    VEGAS_COMPETE: 32,                  // VIP爭霸賽
    // HONER_MEDAL: 33,                 // VIP榮耀勳章 (5.5.8 已拔除)
    FIERCE_BATTLE: 34,                  // 激戰任務
    DRAGON_VS_LEOPARD: 35,              // 龍豹對決
    GUILD_LADDER: 36,                   // 公會天梯
    FULL_GIFT: 37,                      // 滿額贈
    VIP: 38,                            // VIP專區
    KOINLUXY: 39,                       // KL/RP商城兌換
    KOINLUXY_WHEEL: 40,                 // KL/RP Lucky Wheel
    PHONE_TO_GIFT: 41,                  // 填寫手機資料
    MULTI_BLACK_JACK: 42,               // 多人21點
    MULTI_DICE_BO: 43,                  // 百人骰寶
    MULTI_HOOHEYHOW: 44,                // 百人魚蝦蟹
    LUCKY_DICE_COLLECTION: 45,          // 幸運集集樂
    UPDATE_VERSION_BONUS: 46,           // 版更獎勵
    FACEBOOK_FAN: 47,                   // FB粉絲專頁
    RAMADAN_SUBSYSTEM_SIGN_IN: 48,      // 齋戒副系統的簽到
    VEGAS_MAP_MISSION: 49,              // 地圖式機台任務
    PULSA_EXCHANGE: 50,                 // 兌換PULSA
    TOKEN_SUBSYSTEM: 51,                // 代幣副系統
    CLAW_MACHINE: 52,                   // 夾娃娃機
    LUXY_PASS: 53,                      // luxyPass
    RAMADAN: 54,                        // 齋戒
    STONE_GAMBLING: 55,                 // 賭石大師
    COUPON_ASSEMBLE: 56,                // 優惠券背包
    MULTI_BACCARAT: 57,                 // 百人百家樂
    QUESTIONNAIRE_V2: 58,               // 問卷v2 (v5.6.3)
    MULTI_DICE_BO_CLUB: 59,             // 百人骰寶風雲會
    COMPOSITE_CHECKIN: 60,              // 新每日簽到
    PUZZLE_HOMERUN: 61,                 // 拼圖紅不讓
    TREASURE_QUEST: 62,                 // 奪寶冒險
    FARM_BINGO: 63,                     // 賓果農場
    LIMITED_GROUP_BONUS: 64,            // 限時加贈
};

var FreeChipsData = cc.Class.extend({
    ctor: function () {
        // 初始化
        this.clean();

        // 註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            "free_chip_list": this.cmd_free_chip_list,
            "logout_notice": this.cmd_logout_notice,

            // 時段登入獎勵
            "period_login_bonus_info": this.cmd_period_login_bonus_info,
            "period_login_bonus_reward": this.cmd_period_login_bonus_reward,

            // 粉絲頁按讚
            "fan_page_status": this.cmd_fan_page_status,
            "fan_page_like": this.cmd_fan_page_like,
            "fan_page_reward": this.cmd_fan_page_reward,

            // 兌換pulsa
            "free_pulsa_info": this.cmd_free_pulsa_info,

            // 問卷 v2 (v5.6.3)
            "questionnaire_v2_info": this.cmd_questionnaire_v2_info,
            "questionnaire_v2_reward": this.cmd_questionnaire_v2_reward,
        });
    },

    // 清掉資料
    clean: function () {
        this.freeChipParam = {};

        // FreeChip icon的小紅點
        this.isShowFreeChipBadge = false;

        // 存可以顯示的項目資料 (已收到相關資訊的項目才能顯示)
        this.availableList = [{type: FreeChipListType.DAILY_MISSION}];

        // 存server傳來的免費幣整合資訊(要整合進去的項目&順序)
        this._logoutOrderList = [];

        // 存可以顯示的項目資料 (已收到相關資訊的項目才能顯示)
        this.logoutList = [];
        this.logOutMaxShow = 6;
        this.logOutHintOpen = true;

        // 特定時段登入領獎
        this.loginInfo = {};

        // fb粉絲專頁按讚資料
        this.fbFanInfo = {};

        // 是否送過粉專埋點的flag(因為他是在tableView裡面的會被一直reload一直送)
        this.isSendFBTrackFlag = false;

        // pulsa兌換資料
        this.pulsaParam = undefined;

        // 問卷 v2
        this.questionnaireV2Param = undefined;

        // 是不是 pop 出來 (埋點用)
        this.isDialogPop = false;
    },

    // 抓取進大廳所需要資料
    startGetInfo: function () {
        DataProcess.sendString("free_chip_list");

        // 登出提示
        DataProcess.sendString("logout_notice");

        // 特定時段登入獎勵
        DataProcess.sendString("period_login_bonus_info");

        // 粉絲團按讚
        DataProcess.sendString("fan_page_status");

        // pulsa兌換
        DataProcess.sendString("free_pulsa_info");

        // 問卷 v2 (v5.6.3)
        DataProcess.sendString("questionnaire_v2_info");

        // 百人骰寶風雲會
        DataModal.cloudClubData.startGetIconInfo(CloudClubData.slotType.MULTI_DICEBO);
    },

    // 送粉絲團按讚給server
    sendFacebookFanLike: function () {
        GS.localStorage.setItem("FacebookFanLike", "1");

        if (this.fbFanInfo.rewardStatus === FreeChipsData.FacebookFanStatus.NOT_REWARD) {
            // 開啟網頁代表玩家有去點讚(5.4.9 PM考量到FB政策不鼓勵按讚給獎行為這邊就沒有送審跟FB拿權限)
            // 送按讚給server
            DataProcess.sendString("fan_page_like 1");
        }
    },

    // 更新可顯示項目的清單
    refreshAvailableList: function (item) {
        var param = this.freeChipParam;
        if (Object.keys(this.freeChipParam).length === 0)
            return;

        this.isShowFreeChipBadge = false;
        [param.koinLuxy, param.chips].forEach(cur => {
            if (cur) {
                ["eventList", "loginList", "playList", "vipList", "changeList", "missionList"].forEach(curList => {
                    if (cur[curList]) {
                        cur[curList].forEach(curValue => {
                            var icon = curValue.icon;

                            // 紀錄icon被點過
                            if (item && item === icon) {
                                curValue.isTouched = true;

                                switch (icon) {
                                    case FreeChipListType.FACEBOOK_FAN:
                                        // facebook按讚 記錄今天點過
                                        GS.localStorage.setItem("FacebookLikeDate_" + DataModal.profileData.account, TexasUtility.getNowTimeMillisecondString());
                                        break;
                                    case FreeChipListType.VEGAS_MAP_MISSION:
                                        // 49: 地圖式簽到任務
                                        var key = UserDefaultKey.VegasMapMissionFreeChipsRedPoint + DataModal.profileData.account;
                                        GS.localStorage.setItem(key, TexasUtility.getNowTimeMillisecondString());
                                        break;
                                    case FreeChipListType.TOKEN_SUBSYSTEM:
                                        // 51: 代幣副系統
                                        var key = UserDefaultKey.TokenSubsystemFreeChipsRedPoint + DataModal.profileData.account;
                                        GS.localStorage.setItem(key, TexasUtility.getNowTimeMillisecondString());
                                        break;
                                    case FreeChipListType.LUXY_PASS:
                                        // 53: luxyPass
                                        var key = UserDefaultKey.LuxyPassFreeChipsRedPoint + DataModal.profileData.account;
                                        GS.localStorage.setItem(key, TexasUtility.getNowTimeMillisecondString());
                                        break;
                                    case FreeChipListType.MULTI_DICE_BO_CLUB:
                                        // 59: 百人骰寶風雲會
                                        var key = UserDefaultKey.MultiDiceBoClubFreeChipsBadge + DataModal.profileData.account;
                                        GS.localStorage.setItem(key, TexasUtility.getNowTimeMillisecondString());
                                        break;
                                    case FreeChipListType.PUZZLE_HOMERUN:
                                        // 61: 拼圖紅不讓
                                        var key = UserDefaultKey.PuzzleHomerunFreeChipsBadge + DataModal.profileData.account;
                                        GS.localStorage.setItem(key, TexasUtility.getNowTimeMillisecondString());
                                        break;
                                }
                            }

                            // 選牌小遊戲 版更獎勵 pulsa兌換 奪寶冒險
                            if (icon === FreeChipListType.MASTER_POKER
                                || icon === FreeChipListType.UPDATE_VERSION_BONUS
                                || icon === FreeChipListType.PULSA_EXCHANGE
                                || icon === FreeChipListType.TREASURE_QUEST
                                || icon === FreeChipListType.FARM_BINGO) {
                                // 印尼單一版的特規處理
                                // 選牌小遊戲 小紅點規則: 當日未遊玩(顯示) 當日已遊玩(消失)
                                // 版更獎勵 小紅點規則: 可更新or可領獎(顯示) 不可更新or不可領獎(消失)
                                // pulsa兌換 小紅點規則: 可兌換(顯示)
                                // 奪寶冒險 小紅點規則: 有任務可領獎(顯示)
                                // 農場賓果 小紅點規則
                                curValue.isBadgeVisible = this._getItemBadgeVisible(icon);
                            } else {
                                // 是否顯示小紅點 (可以領獎 && 沒有點過)
                                // 小紅點規則: 點過後紅點就消失
                                curValue.isBadgeVisible = this._getItemBadgeVisible(icon) && !curValue.isTouched;
                            }
                            // 活動是否開啟
                            curValue.isOpen = this._getItemAvailable(icon);

                            // Lobby icon 小紅點
                            this.isShowFreeChipBadge = this.isShowFreeChipBadge || (curValue.isOpen && curValue.isBadgeVisible);
                        });
                    }
                });

            }
        });

        // 通知免費幣整合介面更新
        GS.dispatchCustomEvent("NotifyFreeChipAvailableListRefresh");
    },

    // 刷新時段登入獎勵的狀態
    refreshLoinRewardStatus: function () {
        // 沒有資料或沒有任務
        if (!this.loginInfo || !this.loginInfo.taskList)
            return;

        var nowTime = JSCodeUtility.getNowTime();
        this.loginInfo.taskList.forEach(cur => {
            if (nowTime >= cur.endTime && cur.status === FreeChipsData.loginStatus.CanReward) {
                // 先設成已過期 等server資料刷新
                cur.status = FreeChipsData.loginStatus.TimeOver;
            }
        });

        GS.dispatchCustomEvent("NotifyFreeChipLoginRefreshStatus");
    },

    // 更新可領獎的登出提醒
    getRefreshLogoutOrderList: function () {
        this.logoutList = [];
        this._logoutOrderList.forEach(cur => {
            if (this._getLogoutItemAvailable(cur, true)) {
                if (this._getLogoutItemBadgeVisible(cur))
                    this.logoutList.push(cur);

                // 加入公會禮有獎勵才會顯示
                if (cur === FreeChipListType.JOIN_GUILD)
                    this.logoutList.push(cur);
            }
        });

        return this.logoutList;
    },

    /**
     * 取得各項目的資訊
     */

    // 取得項目是否要顯示 (已收到相關資訊的項目才能 顯示)
    _getItemAvailable: function (type) {
        switch (type) {
            case FreeChipListType.DAILY_MISSION:
                // 1: 每日任務
                return true;

            case FreeChipListType.DAILY_LOGIN:
                // 2: 每日簽到
                return DataModal.signInData.getEventIsOpen();

            case FreeChipListType.QUESTIONNAIREL:
                // 7: 問卷
                return DataModal.lobbyActionData.questParam.status === 1;

            case FreeChipListType.GUILD_SURPRISE:
                // 8: 公會驚喜(沒公會不顯示 有公會就顯示)
                return !GS.isLuxyPoker && DataModal.guildData.haveGuild;

            case FreeChipListType.SERIAL_PRIZE:
                // 9: 輸入序號兌換獎勵
                // 判斷還有沒有時間
                var data = DataModal.serialNumberPrizeData;
                var nowTime = new Date().getTime() / 1000;
                var decreaseTime = nowTime - data.socketTime;
                return !GS.isLuxyPoker && (decreaseTime < data.remainTime);

            case FreeChipListType.JOIN_GUILD:
                // 11: 加入公會獎勵
                var info = DataModal.guildData.userInfo;
                if (!info)
                    return false;

                // 判斷真的有獎勵
                return !GS.isLuxyPoker && info.addMoney > 0;

            case FreeChipListType.GAME_RANK:
                // 12: 積分
                return DataModal.gameRankData.isOpen;

            case FreeChipListType.MASTER_POKER:
                // 14: 猜手牌遊戲(單一版)
                var masterPokerData = DataModal.masterPokerData;
                return !!masterPokerData.infoParam && (masterPokerData.canPlay || masterPokerData.infoParam.remainTime > 0);

            case FreeChipListType.CALLBACK_MISSION:
                // 15: 回流任務(單一版)
                return DataModal.returnMissionData.isOpen;

            case FreeChipListType.EVENT:
            case FreeChipListType.ACHIEVEMENT:
                // 16: 多種趣味活動拿獎勵(單一版)
                // 17: 成就(單一版)
                return true;

            case FreeChipListType.DAILY_LUCKY_WHEEL:
                // 18: 每日幸運輪盤
                return DataModal.dailyLuckyWheelData.isEventOpen;

            case FreeChipListType.CARD_KING:
                // 19: 牌王
                return DataModal.cardKingData.getIsOpen();

            case FreeChipListType.LOGIN_REWARD:
                // 20: 特定時段登入獎勵
                return this.loginInfo.isOpen;

            case FreeChipListType.VEGAS_RACING:
                // 25: 極速競飆
                return DataModal.vegasRacingData.getEventIsOpen();

            case FreeChipListType.PLAY_GAME:
                // 29: 玩牌(不限玩法)
                return true;

            case FreeChipListType.GAMBLER_ROAD:
                // 30: 牌王之路
                return DataModal.gamblerRoadData.getEventIsOpen();

            case FreeChipListType.VEGAS_COMPETE:
                // 32: VIP機台爭霸賽
                return DataModal.vegasCompeteData.getEventIsOpen();

            case FreeChipListType.FIERCE_BATTLE:
                // 34: 激戰任務
                return DataModal.fierceBattleData.getEventIsOpen();

            case FreeChipListType.DRAGON_VS_LEOPARD:
                // 35: 龍豹對決
                return DataModal.vegasDragonVsLeopardData.getEventIsOpen();

            case FreeChipListType.GUILD_LADDER:
                // 36: 公會天梯
                return DataModal.guildData.getEventLadderIsOpen();

            case FreeChipListType.FULL_GIFT:
                // 37: 滿額贈(5等以上才能看到)
                return DataModal.profileData.level >= 5;

            case FreeChipListType.VIP:
                // 38: VIP專區
                return DataModal.vipData.getIsVipOpen();

            case FreeChipListType.KOINLUXY:
            case FreeChipListType.KOINLUXY_WHEEL:
                // 39: KL/RP商城兌換
                // 40: KL/RP Lucky Wheel
                return DataModal.koinLuxyData.isOpen;

            case FreeChipListType.PHONE_TO_GIFT:
                // 41: 填寫手機資料
                return DataModal.phoneToGiftData.isOpen;

            case FreeChipListType.LUCKY_DICE_COLLECTION:
                // 45: 幸運集集樂
                return DataModal.profileData.level >= 3 && DataModal.luckyDiceCollectionData.getEventIsOpen();

            case FreeChipListType.UPDATE_VERSION_BONUS:
                // 46: 版本更新獎勵
                var settingData = DataModal.settingData;
                return !settingData.isNewestVersion || settingData.canGetUpdateBonus;

            case FreeChipListType.FACEBOOK_FAN:
                // 47: 粉絲團點讚
                return this.fbFanInfo.isOpen;

            case FreeChipListType.RAMADAN_SUBSYSTEM_SIGN_IN:
                // 48: 齋戒副系統的簽到
                return DataModal.ramadanData.signInData?.getIsOpen() &&
                    DataModal.ramadanData.signInData?.status !== RamadanData.SignInStatus.DONE;

            case FreeChipListType.VEGAS_MAP_MISSION:
                // 49: 地圖式簽到任務
                return DataModal.vegasMapMissionData.getEventIsOpen();

            case FreeChipListType.PULSA_EXCHANGE:
                // 50: 兌換PULSA
                return !!this.pulsaParam;

            case FreeChipListType.TOKEN_SUBSYSTEM:
                // 51: 代幣副系統
                return DataModal.tokenSubsystemData.getEventIsOpen();

            case FreeChipListType.CLAW_MACHINE:
                // 52: 夾娃娃機
                return DataModal.purchaseTriggerIntegrationData.getPurchaseActivityIsOpenByType(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE);

            case FreeChipListType.LUXY_PASS:
                // 53: LuxyPass
                return DataModal.luxyPassData.getEventIsOpen();

            case FreeChipListType.RAMADAN:
                // 54: 齋戒
                return DataModal.ramadanData.getIsOpen();

            case FreeChipListType.STONE_GAMBLING:
                // 55:賭石大師
                return DataModal.stoneGamblingData.getEventIsOpen();

            case FreeChipListType.QUESTIONNAIRE_V2:
                // 58: 問卷 v2 (5.6.3)
                var questionnaireV2Param = this.questionnaireV2Param;
                return questionnaireV2Param && questionnaireV2Param.url.length;

            case FreeChipListType.MULTI_DICE_BO_CLUB:
                // 59: 百人骰寶風雲會
                var cloudClubData = DataModal.cloudClubData.getDataBySlotType(CloudClubData.slotType.MULTI_DICEBO);
                return [VegasGameType.MULTI_DICEBO, VegasGameType.MULTI_DICEBO_TEST_A].some(cur => DataModal.vegasData.getVegasMachineByType(cur) && !DataModal.vegasData.getVegasMachineByType(cur).shutdown) && cloudClubData.error === 0;

            case FreeChipListType.PUZZLE_HOMERUN:
                // 61: 拼圖紅不讓
                return DataModal.puzzleHomeRunData.isOpen;

            case FreeChipListType.TREASURE_QUEST:
                // 62: 奪寶冒險
                return DataModal.treasureQuestData.isOpen;

            case FreeChipListType.FARM_BINGO:
                // 63: 農場賓果
                return DataModal.farmBingoData.getEventIsOpen();

            case FreeChipListType.LIMITED_GROUP_BONUS:
                // 64: 限時加贈
                return DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.LIMITED_GROUP_BONUS).isOpen;

            default:
                return false;
        }
    },

    // 取得項目是否要顯示小紅點
    _getItemBadgeVisible: function (type) {
        switch (type) {
            case FreeChipListType.DAILY_MISSION:
                // 1: 每日任務
                return DataModal.dailyMissionData.getActionListDialogHaveReward(DailyMissionEnum.whereType.Lobby);

            case FreeChipListType.DAILY_LOGIN:
                // 2: 每日簽到
                return DataModal.signInData.getEventCanReward();

            case FreeChipListType.QUESTIONNAIREL:
                // 7: 問卷
                return DataModal.lobbyActionData.questParam.status === 1;

            case FreeChipListType.GUILD_SURPRISE:
                // 8: 公會驚喜(沒公會不顯示 有公會就顯示)
                return DataModal.guildData.userInfo
                    && DataModal.guildData.userInfo.surpriseStatus
                    && DataModal.guildData.userInfo.surpriseStatus === GuildSurpriseStatus.REWARD;

            case FreeChipListType.MASTER_POKER:
                // 14: 猜手牌遊戲(單一版)
                return DataModal.masterPokerData.canPlay;

            case FreeChipListType.CALLBACK_MISSION:
                // 15: 回流任務(單一版)
                return DataModal.returnMissionData.haveReward;

            case FreeChipListType.EVENT:
                // 16: 多種趣味活動拿獎勵(單一版)
                return DataModal.lobbyInfo && DataModal.lobbyInfo.eventRewardCount > 0;

            case FreeChipListType.ACHIEVEMENT:
                // 17: 成就(單一版)
                return DataModal.achieveData.achieveNum > 0;

            case FreeChipListType.DAILY_LUCKY_WHEEL:
                // 18: 每日幸運輪盤
                return DataModal.dailyLuckyWheelData.getEventCanReward();

            case FreeChipListType.CARD_KING:
                // 19: 牌王
                return DataModal.cardKingData.isRedDot;

            case FreeChipListType.LOGIN_REWARD:
                // 20: 特定時段登入獎勵
                return this.loginInfo.isRedPoint;

            case FreeChipListType.VEGAS_RACING:
                // 25: 極速競飆
                return DataModal.vegasRacingData.getEventCanReward();

            case FreeChipListType.GUILD_LADDER:
                // 36: 公會天梯
                return DataModal.profileData.level >= 3 && DataModal.guildData.ladderInfo && DataModal.guildData.ladderInfo.isShowMemberRankBadge;

            case FreeChipListType.VIP:
                // 38: VIP專區
                return DataModal.vipData.getHaveDailyReward();

            case FreeChipListType.PHONE_TO_GIFT:
                // 41: 填寫手機資料
                return DataModal.phoneToGiftData.isOpen;

            case FreeChipListType.LUCKY_DICE_COLLECTION:
                // 45: 幸運集集樂
                return DataModal.luckyDiceCollectionData.getIconIsShowRedPoint();

            case FreeChipListType.UPDATE_VERSION_BONUS:
                // 46: 版本更新獎勵，有顯示就是有紅點
                return true;

            case FreeChipListType.FACEBOOK_FAN:
                // 47: 粉絲團點讚
                // 小紅點條件:
                // 每天登入時 (印尼時間6:00換天)
                // 可領獎時
                var recordDay = GS.localStorage.getItem("FacebookLikeDate_" + DataModal.profileData.account, "0");
                return this.fbFanInfo.rewardStatus === FreeChipsData.FacebookFanStatus.CAN_REWARD
                    || TexasUtility.getNowIsChangeDay(recordDay);

            case FreeChipListType.RAMADAN_SUBSYSTEM_SIGN_IN:
                // 48: 齋戒副系統的簽到
                var key = UserDefaultKey.RamadanFreeChipsSignInBadge + DataModal.profileData.account;
                return TexasUtility.getNowIsChangeDay(GS.localStorage.getItem(key, "1"));

            case FreeChipListType.VEGAS_MAP_MISSION:
                // 49: 地圖式簽到任務 每日一次
                var key = UserDefaultKey.VegasMapMissionFreeChipsRedPoint + DataModal.profileData.account;
                return TexasUtility.getNowIsChangeDay(GS.localStorage.getItem(key, "1"));

            case FreeChipListType.PULSA_EXCHANGE:
                // 50: 兌換PULSA 可兌換就是顯示小紅點
                return true;

            case FreeChipListType.TOKEN_SUBSYSTEM:
                // 51: 代幣副系統 每日一次
                var key = UserDefaultKey.TokenSubsystemFreeChipsRedPoint + DataModal.profileData.account;
                return TexasUtility.getNowIsChangeDay(GS.localStorage.getItem(key, "1"));

            case FreeChipListType.CLAW_MACHINE:
                // 52: 夾娃娃機
                // 寶箱領獎次數 有儲值資料拿儲值的
                var clawMachineInfo = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE);
                var getWheelRewardCount = (clawMachineInfo.rechargeResultParam)
                    ? clawMachineInfo.rechargeResultParam.getWheelRewardCount
                    : clawMachineInfo.getWheelRewardCount;

                // 轉盤可領獎 or 娃娃機可抓
                return getWheelRewardCount || clawMachineInfo.getRewardCount;

            case FreeChipListType.LUXY_PASS:
                // 53: luxyPass 每日一次
                var key = UserDefaultKey.LuxyPassFreeChipsRedPoint + DataModal.profileData.account;
                return TexasUtility.getNowIsChangeDay(GS.localStorage.getItem(key, "1"));

            case FreeChipListType.RAMADAN:
                // 54: 齋戒 今日尚未進入總入口
                var key = UserDefaultKey.RamadanFreeChipsRedPoint + DataModal.profileData.account;
                return TexasUtility.getNowIsChangeDay(GS.localStorage.getItem(key, "1"));

            case FreeChipListType.STONE_GAMBLING:
                // 55:賭石大師 該帳號今日尚未進入過賭石大師介面
                var key = UserDefaultKey.StoneGamblingDialogFirstIn + DataModal.profileData.account;
                return TexasUtility.getNowIsChangeDay(GS.localStorage.getItem(key, "1"));

            case FreeChipListType.MULTI_DICE_BO_CLUB:
                var key = UserDefaultKey.MultiDiceBoClubFreeChipsBadge + DataModal.profileData.account;
                return TexasUtility.getNowIsChangeDay(GS.localStorage.getItem(key, "1"));

            case FreeChipListType.PUZZLE_HOMERUN:
                // 61: 拼圖紅不讓
                var key = UserDefaultKey.PuzzleHomerunFreeChipsBadge + DataModal.profileData.account;
                return TexasUtility.getNowIsChangeDay(GS.localStorage.getItem(key, "1"));

            case FreeChipListType.TREASURE_QUEST:
                // 62: 奪寶冒險
                return DataModal.treasureQuestData.isShowRedPoint;

            case FreeChipListType.FARM_BINGO:
                // 63: 賓果農場
                return DataModal.farmBingoData.shouldShowBadge();

            case FreeChipListType.LIMITED_GROUP_BONUS:
                // 64: 限時加贈
                return DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.LIMITED_GROUP_BONUS).shouldShowBadge();

            default:
                return false;
        }
    },

    // 取得登出項目是否要顯示 (已收到相關資訊的項目才能 顯示)
    _getLogoutItemAvailable: function (type) {
        switch (type) {
            // 機台系列: 看玩家等級是否可進機台
            case FreeChipListType.DICE_BO:
                const diceBoParam = DataModal.vegasData.getVegasMachineByServerType(LobbySelectGameSetting.GameType.DiceBo);
                return !diceBoParam?.shutdown && DataModal.profileData.level >= DataModal.vegasData.lockLevel.DiceBo;

            case FreeChipListType.BLACK_JACK:
                const blackJackParam = DataModal.vegasData.getVegasMachineByServerType(LobbySelectGameSetting.GameType.Blackjack);
                return !blackJackParam?.shutdown && DataModal.profileData.level >= DataModal.vegasData.lockLevel.Blackjack;

            case FreeChipListType.MULTI_DICE_BO:
                const multiDiceBo40Param = DataModal.vegasData.getVegasMachineByServerType(LobbySelectGameSetting.GameType.MultiDiceBo_TEST_A);
                const multiDiceBo42Param = DataModal.vegasData.getVegasMachineByServerType(LobbySelectGameSetting.GameType.MultiDiceBo);
                return (!multiDiceBo40Param?.shutdown || !multiDiceBo42Param?.shutdown) &&
                    DataModal.profileData.level >= DataModal.vegasData.lockLevel.MultiDiceBo;

            case FreeChipListType.MULTI_BLACK_JACK:
                const multiBlackJackParam = DataModal.vegasData.getVegasMachineByServerType(LobbySelectGameSetting.GameType.MultiBlackjack);
                return !multiBlackJackParam?.shutdown && DataModal.profileData.level >= DataModal.vegasData.lockLevel.MULTI_BLACKJACK;

            case FreeChipListType.MULTI_HOOHEYHOW:
                const multiHooHeyHowParam = DataModal.vegasData.getVegasMachineByServerType(LobbySelectGameSetting.GameType.MultiHooHeyHow);
                return !multiHooHeyHowParam?.shutdown && DataModal.profileData.level >= DataModal.vegasData.lockLevel.MultiHooHeyHow;

            case FreeChipListType.GROWING_MISSION:
                return DataModal.growingMissionData.getEventIsOpen();

            case FreeChipListType.VEGAS_RACING:
                return DataModal.vegasRacingData.getEventIsOpen();

            case FreeChipListType.VEGAS_NEWBIE_MISSION:
                return DataModal.vegasNewbieMissionData.getEventIsOpen();

            case FreeChipListType.NEWBIE_LEVEL_GIFT:
                return DataModal.newbieData.getNewbieGiftIsOpen();

            // 其他舊的走預設
            default:
                return this._getItemAvailable(type);
        }
    },

    // 取得登出項目是否要顯示小紅點
    _getLogoutItemBadgeVisible: function (type) {
        switch (type) {
            //  機台判斷有無免費券
            case FreeChipListType.DICE_BO:
                return DataModal.vegasData.freeTicket.DiceBo > 0;
            case FreeChipListType.BLACK_JACK:
                return DataModal.vegasData.freeTicket.Blackjack > 0;
            case FreeChipListType.MULTI_DICE_BO:
                return DataModal.vegasData.freeTicket.MultiDiceBo > 0;
            // case FreeChipListType.MULTI_DICE_BO_VIP:
            //     return DataModal.vegasData.freeTicket.MultiDiceBo_VIP > 0;
            case FreeChipListType.MULTI_BLACK_JACK:
                return DataModal.vegasData.freeTicket.MultiBlackjack > 0;
            case FreeChipListType.MULTI_HOOHEYHOW:
                return DataModal.vegasData.freeTicket.MultiHooHeyHow > 0;

            case FreeChipListType.GROWING_MISSION:
                return DataModal.growingMissionData.getShowRedBadge();

            case FreeChipListType.VEGAS_RACING:
                return DataModal.vegasRacingData.getEventCanReward();

            case FreeChipListType.VEGAS_NEWBIE_MISSION:
                return DataModal.vegasNewbieMissionData.getEventCanReward();

            case FreeChipListType.NEWBIE_LEVEL_GIFT:
                return DataModal.newbieData.getNewbieGiftCanReward();

            case FreeChipListType.DAILY_LUCKY_WHEEL:
                return DataModal.dailyLuckyWheelData.getEventCanReward();

            default:
                return this._getItemBadgeVisible(type);
        }
    },

    /**
     * Socket Callback
     */

    /**
     * S -> C free_chip_list
     * {
     *   // KL/RP
     *   "koinLuxy": {
     *     // 限時活動
     *     "event": {
     *       "banner_type": ["0", "158", "186", "196", "206", "191", "214", "183", "1", "0"],
     *       "icon": ["22", "23", "24", "25", "26", "27", "28", "29", "31", "9"]
     *     },
     *     // 簽到&登入
     *     "login": {
     *       "banner_type": ["96"],
     *       "icon": ["13"]
     *     },
     *     // 玩牌
     *     "play": {
     *       "banner_type": ["0"],
     *       "icon": ["20"]
     *     },
     *     // VIP專區
     *     "vip": {
     *       "banner_type": ["106"],
     *       "icon": ["32"]
     *     },
     *     // 兌換
     *     "change": {
     *       "banner_type": ["0"],
     *       "icon": ["0"]
     *     },
     *     // 任務
     *     "mission": {
     *       "banner_type": ["46"],
     *       "icon": ["1"]
     *     }
     *   },
     *   "chips": {
     *     // 同上 ....
     *   },
     *   "pop": 0
     * }
     * @param key
     * @param value
     */
    cmd_free_chip_list: function (key, value) {
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value);

        this.freeChipParam = {};

        // 是否自動彈跳
        this.freeChipParam.isPop = JSCodeUtility.getBooleanValue(jsonValue["pop"]);

        // jsonValue的key (對照server的key)
        var keys = ["koinLuxy", "chips"];
        // jValue的key (對照server的key)
        var tabKeys = ["event", "login", "play", "vip", "change", "mission"];
        //  this.freeChipParam.koinLuxy.eventList, this.freeChipParam.chips.eventList ....
        var listKeys = ["eventList", "loginList", "playList", "vipList", "changeList", "missionList"];

        for (var j = 0, len = keys.length; j < len; j++) {
            var jsonKey = keys[j];
            var jValue = jsonValue[jsonKey];
            if (!jValue)
                continue;

            this.freeChipParam[jsonKey] = {};

            for (var i = 0, tabLen = tabKeys.length; i < tabLen; i++) {
                var value = jValue[tabKeys[i]];
                if (!value)
                    continue;

                var iconList = value["icon"] || [];
                var bannerList = value["banner_type"] || [];
                var list = iconList.map((cur, i) => {
                    return {
                        // icon編號 0:沒有編號
                        icon: JSCodeUtility.getIntValue(cur),
                        // 引導編號 0:沒有編號
                        bannerType: JSCodeUtility.getIntValue(bannerList[i]),
                        // 是否有紅點 預設false 會在refreshAvailableList刷新
                        isBadgeVisible: false,
                        // 是否點過 預設false 用於記錄紅點點過就消失
                        isTouched: false,
                        // 活動是否開啟 預設false 會在refreshAvailableList刷新
                        isOpen: false
                    };
                });

                // 排除掉0的編號(server沒有的會給0)
                this.freeChipParam[jsonKey][listKeys[i]] = list.filter(cur => cur.icon !== 0);
            }
        }

        // 更新可顯示項目的清單
        this.refreshAvailableList();
    },

    // 登出前顯示
    cmd_logout_notice: function (key, value) {
        // 黑帳號不顯示
        if (DataModal.profileData.isBlackAccount)
            return;

        // logout_notice ["1","2","3","4","5","6","7"]
        var jsonValue = JSON.parse(value) || {};

        // 顯示順序
        this._logoutOrderList = (jsonValue["showList"] || []).map(cur => JSCodeUtility.getIntValue(cur));

        // 最多顯示幾個
        this.logOutMaxShow = JSCodeUtility.getIntValue(jsonValue["maxShow"]);

        // 開關功能
        this.logOutHintOpen = JSCodeUtility.getBooleanValue(jsonValue["open"]);

        this.getRefreshLogoutOrderList();
    },

    /**
     * 5.4.3
     * 特定時段登入獎勵
     * C->S  period_login_bonus_info
     * S->C  period_login_bonus_info
     * {
     *   // 距離隔天刷新時間
     *   "left_time": "42983",
     *   // 1:開啟 0:關閉
     *   "open": "1",
     *   // 當下的時間戳
     *   "now": "1662289417",
     *   // 自動彈跳
     *   "pop": "0",
     *   "task": [
     *     {
     *       "time": [
     *         "1662260400",
     *         "1662271200"
     *       ],
     *       "time_txt": "10:00 - 13:00",
     *       "reward_txt": "1rb ~ 10rb",
     *       // 0:已領獎 1:可領獎 2:已過期 3:時間未到
     *       "status": "0"
     *     },
     *     {
     *       "reward_txt": "1rb ~ 10rb",
     *       "time_txt": "18:00 - 21:00",
     *       "time": [
     *         "1662289200",
     *         "1662300000"
     *       ],
     *       "status": "1"
     *     }
     *     // ...
     *   ]
     * }
     */
    cmd_period_login_bonus_info: function (key, value) {
        // 黑帳號不顯示
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value) || {};
        var isRedPoint = false;

        this.loginInfo = {};

        var isOpen = JSCodeUtility.getBooleanValue(jsonValue["open"]);

        if (isOpen) {
            var isPop = JSCodeUtility.getBooleanValue(jsonValue["pop"]);

            this.loginInfo = {
                // 活動是否開啟
                isOpen: isOpen,

                // 現在時間 (時間戳)
                now: JSCodeUtility.getIntValue(jsonValue["now"]),

                // 隔天的刷新時間 (剩餘的秒數)
                refreshTime: JSCodeUtility.getIntValue(jsonValue["left_time"]),

                // 三個獎勵[早上, 中午 ,下午]
                taskList: (jsonValue["task"] || []).map(cur => {
                    // 0:已領獎 1:可領獎 2:已過期 3:時間未到
                    var status = JSCodeUtility.getIntValue(cur["status"]);

                    if (status === FreeChipsData.loginStatus.CanReward)
                        isRedPoint = true;

                    // [開始時間, 結束時間] (時間戳) 會是當天的時間
                    var timeList = (cur["time"] || []).map(curTime => JSCodeUtility.getIntValue(curTime));

                    return {
                        status: status,
                        // 開始時間
                        startTime: JSCodeUtility.getIntValue(timeList[0]),
                        // 結束時間
                        endTime: JSCodeUtility.getIntValue(timeList[1]),
                        // 領獎的時間
                        timeString: JSCodeUtility.getStringValue(cur["time_txt"]),
                        // 獎勵內容
                        rewardString: JSCodeUtility.getStringValue(cur["reward_txt"])
                    };
                }),

                isRedPoint: isRedPoint
            };

            // 找最短的倒數時間(只需要倒數最短的時間)
            var taskList = this.loginInfo.taskList;
            var remainTimeArray = taskList.map(cur => {
                if (cur.status === FreeChipsData.loginStatus.CanReward) {
                    // 可領獎
                    return cur.endTime - this.loginInfo.now;
                } else if (cur.status === FreeChipsData.loginStatus.HaveTime) {
                    // 未到期
                    return cur.startTime - this.loginInfo.now;
                } else {
                    return this.loginInfo.refreshTime;
                }
            });

            // 倒數的時間(找最近的時間)
            this.loginInfo.remainTime = Math.min(...remainTimeArray);
            // 收到cmd的時間
            this.loginInfo.socketTime = JSCodeUtility.getNowTime();

            // 自動彈跳
            if (isPop && !DialogManager.isExist("FreeChipLoginRewardDialog")) {
                DialogManager.addLobbyDialog(new FreeChipLoginRewardDialog());
            }
        }

        GS.dispatchCustomEvent("NotifyFreeChipLoginInfoDone");
    },

    /**
     * 5.4.3
     * 特定時段登入獎勵領獎
     * C->S  period_login_bonus_reward 0   // 0:早上 1:中午 2:下午
     * S->C  period_login_bonus_reward
     * {
     *   // 1:成功 0:失敗
     *   "success": "1",
     *   // 獎圖位置
     *   "reward_host": "http://d.mwsrv.com/19_60/store/iapp/goods/",
     *   // 獎勵清單
     *   "reward": [
     *     {
     *       "count": "x 1rb",
     *       "wid": "5057"
     *     },
     *     {
     *       "count": "x 2",
     *       "wid": "7099"
     *     }
     *   ]
     * }
     */
    cmd_period_login_bonus_reward: function (key, value) {
        // 黑帳號不顯示
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value) || {};

        var isSuccess = JSCodeUtility.getBooleanValue(jsonValue["success"]);

        if (isSuccess) {
            var chestParam = {
                chestIndex: 1,
                list: (jsonValue["reward"] || []).map(cur => {
                    return {
                        pic: JSCodeUtility.getIntValue(cur["wid"]) + ".png",
                        txt: JSCodeUtility.getStringValue(cur["count"])
                    };
                }),
                isEnableSkipAnimation: true,
                // 埋點：5255 點擊略過動畫按鈕
                skipClickUserAnalytics: {type: 5255,},
            };

            var imageBase = JSCodeUtility.getStringValue(jsonValue["reward_host"]);
            var dataObj = {
                REWARD_BASE_HOST: imageBase,
                SAVE_SHOPITEM_PATH: JSWriteablePath + "shop/"
            };

            // 跳出寶箱顯示領獎
            var rewardDialog = new ChestRewardDialog(chestParam, null, dataObj);
            rewardDialog.setCloseCallback(() => {
                // 重送資料
                DataProcess.sendString("period_login_bonus_info");
            });
            DialogManager.addDialog(rewardDialog, false);
        } else {
            // 領獎失敗
            var localStr = LocalizedString.FreeChip;
            var obj = {
                content: localStr("領獎失敗，請稍後再領取"),
                buttons: [localStr("確認")],
                callback: () => {
                    // 關掉Dialog
                    var dialog = DialogManager.getDialogByKey("FreeChipLoginRewardDialog");
                    dialog && dialog.closeDialogAnimation();

                    // 重送資料
                    DataProcess.sendString("period_login_bonus_info");
                }
            };
            DialogManager.addDialog(new Dialog(obj), false);
        }
    },

    /**
     * FB粉絲專頁按讚引導
     * C->S fan_page_status
     * S->C fan_page_status
     * {
     *    error: 0,        // 0開啟, 1關閉
     *    time_left: 123,  // 剩餘時間
     *    reward_status: {
     *      fb: 0,       // 0不可領, 1可領獎, 2已領
     *    }
     * }
     */
    cmd_fan_page_status: function (key, value) {
        var jsonValue = JSON.parse(value) || {};
        var isSuccess = !JSCodeUtility.getBooleanValue(jsonValue["error"]);

        this.fbFanInfo = {};

        if (isSuccess) {
            this.fbFanInfo.isOpen = true;

            // 剩餘時間
            this.fbFanInfo.remainTime = JSCodeUtility.getIntValue(jsonValue["time_left"]);
            this.fbFanInfo.socketTime = JSCodeUtility.getNowTime();

            var rewardJson = jsonValue["reward_status"];
            if (rewardJson) {
                //0不可領, 1可領獎, 2已領獎
                this.fbFanInfo.rewardStatus = JSCodeUtility.getIntValue(rewardJson["fb"]);
            }
        }

        // 更新可顯示項目的清單
        this.refreshAvailableList();
    },

    /**
     * 粉絲團已讚
     * C->S fan_page_like 編號(Domino: 1, LuxyPoker: 2)
     * S->C fan_page_like
     * {
     *   error: 0, // 0 寫入成功, 1 寫入失敗
     * }
     */
    cmd_fan_page_like: function () {
        // 不管寫入成功或失敗都要去重拿粉絲團資訊
        DataProcess.sendString("fan_page_status");
    },

    /**
     * 粉絲團按讚領獎
     * C->S fan_page_reward 編號:粉絲專頁的編號
     * S->C fan_page_reward
     * {
     *   error: 0, // 0 領獎成功, 1 系統忙碌/領獎異常
     *   get_item: ['7081_rp', '1234'], // 獎勵圖檔名
     *   get_num: [10, 5], // 獲得數量
     * }
     */
    cmd_fan_page_reward: function (key, value) {
        var jsonValue = JSON.parse(value) || {};
        var isSuccess = !JSCodeUtility.getBooleanValue(jsonValue["error"]);
        this.isSendFBTrackFlag = false;

        if (isSuccess) {
            // 先把狀態轉成已領獎 避免重複領獎
            this.fbFanInfo.rewardStatus = FreeChipsData.FacebookFanStatus.REWARD_DONE;

            var imageBase = JSCodeUtility.getStringValue(jsonValue["img_url"]);
            var dataObj = {
                REWARD_BASE_HOST: GS.httpScheme + imageBase,
                SAVE_SHOPITEM_PATH: JSWriteablePath + "shop/"
            };

            // 獎勵圖檔名
            var getItem = jsonValue["get_item"] || [].map(cur => JSCodeUtility.getStringValue(cur));
            // 獲得數量
            var getNum = jsonValue["get_num"] || [].map(cur => JSCodeUtility.getIntValue(cur));

            var chestParam = {
                chestIndex: 1,
                list: getItem.map((cur, i) => {
                    return {
                        pic: cur + ".png",
                        txt: (getNum[i]) ? getNum[i] : ""
                    };
                }),
                // 換上FB領獎的標題
                titleName: "#chestReward_word_facebook.png"
            };

            // 跳出寶箱顯示領獎
            var rewardDialog = new ChestRewardDialog(chestParam, null, dataObj);
            rewardDialog.setCloseCallback(() => {
                // 領獎重要資料
                DataProcess.sendString("fan_page_status");
            });
            DialogManager.addDialog(rewardDialog, false);
        } else {
            // 領獎失敗
            var localStr = LocalizedString.FreeChip;
            var obj = {
                content: localStr("領獎失敗，請稍候再試"),
                buttons: [localStr("確認")],
                callback: () => {
                    // 關掉Dialog
                    var dialog = DialogManager.getDialogByKey("FreeChipDialog");
                    dialog && dialog.closeDialogAnimation();

                    // 重送資料
                    DataProcess.sendString("fan_page_status");
                }
            };
            DialogManager.addDialog(new Dialog(obj), false);
        }
    },

    cmd_free_pulsa_info: function (key, value) {
        var jsonValue = JSON.parse(value) || {};

        this.pulsaParam = {
            url: JSCodeUtility.getStringValue(jsonValue["url"]),
            remainTime: JSCodeUtility.getIntValue(jsonValue["leftTime"]),
            socketTime: JSCodeUtility.getNowTime()
        };

        // 更新可顯示項目的清單
        this.refreshAvailableList();
    },

    /**
     *  問卷 v2 info
     */
    cmd_questionnaire_v2_info: function (key, value) {
        var jsonValue = JSON.parse(value) || {};
        var isSuccess = JSCodeUtility.getBooleanValue(jsonValue["success"]);
        if (!isSuccess) {
            // 失敗清掉
            this.questionnaireV2Param = undefined;
        } else {
            // 有成功
            this.questionnaireV2Param = {
                sid: JSCodeUtility.getIntValue(jsonValue["sid"]),
                url: JSCodeUtility.getStringValue(jsonValue["url"]),
                remainTime: JSCodeUtility.getIntValue(jsonValue["packTimeLeft"]),
                socketTime: JSCodeUtility.getNowTime(),
            };
        }
        this.refreshAvailableList();
    },

    /**
     *  問卷 v2 獎勵
     */
    cmd_questionnaire_v2_reward: function (key, value) {
        var jsonValue = JSON.parse(value) || {};
        var isSuccess = JSCodeUtility.getBooleanValue(jsonValue["success"]);

        // 重抓問券
        DataProcess.sendString("questionnaire_v2_info");

        if (isSuccess) {
            // 成功通知領獎
            GS.dispatchCustomEvent("NotifyQuestionerQuestionnaireV2GetReward",
                {message: JSCodeUtility.getStringValue(jsonValue["msg"])}
            );
        }
    },
});

// FB按讚的領獎狀態
FreeChipsData.FacebookFanStatus = {
    NOT_REWARD: 0,    // 不可領獎
    CAN_REWARD: 1,    // 可領獎
    REWARD_DONE: 2   // 已領獎
};

// 特定時段登入獎勵的領獎狀態(對應server的編號)
FreeChipsData.loginStatus = {
    FinishReward: 0,  // 已領獎
    CanReward: 1,     // 可領獎
    TimeOver: 2,      // 已過期
    HaveTime: 3       // 時間未到
};