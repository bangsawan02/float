/**
 * 跑大整數字變動
 * created by terry.chuang 2025/7/2
 */
var GSBigIntegerRunner = GSBigNumberRunner.extend({
    setNowNumber: function (number) {
        this._super(number);
        this._nowNumber = JSCodeUtility.bigNumberRoundDown(this._nowNumber); // 當前數字取整
    },

    setTargetNumber: function (number) {
        this._super(number);
        this._targetNumber = JSCodeUtility.bigNumberRoundDown(this._targetNumber); // 目標數字取整
    }
})