/**
 * Cangkulan 自動代打的提示
 */

var Cangkulan_AutoPlayLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this._init = false;

        //加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this._onTouchBegan.bind(this),
            onTouchEnded: this._onTouchEnd.bind(this),
            onTouchCancelled: this._onTouchCancelled.bind(this)
        }, this);
    },

    /**
     * 打開
     */
    show: function () {
        this.setVisible(true);

        // 先確定有沒有產生過畫面
        if (!this._init) {
            // 沒產
            this._init = true;

            // 產生畫面
            var bgLayer = new cc.LayerColor(cc.color(0, 0, 0, 100), JSVisibleSize.width, JSVisibleSize.height);
            this.addChild(bgLayer);

            // 機器人的臉
            var robotSprite = this._robotSprite = new cc.Sprite("#game_pic_robot.png");
            robotSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 23);
            this.addChild(robotSprite);

            var scaleTime = 0.5;
            robotSprite.runAction(cc.repeatForever(cc.sequence(
                cc.scaleTo(scaleTime, 1, 0.7).easing(cc.easeBackIn()),
                cc.scaleTo(scaleTime, 1, 1).easing(cc.easeBackOut()),
                cc.scaleTo(scaleTime, 1, 0.7).easing(cc.easeBackIn()),
                cc.scaleTo(scaleTime, 1, 1).easing(cc.easeBackOut()),
                cc.delayTime(1)
            )));

            // 背景
            var bgSprite = new ccui.Scale9Sprite("game_pic_line_purple.png");
            bgSprite.setPreferredSize(cc.size(320, 42));
            bgSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 34);
            this.addChild(bgSprite);

            // 金邊
            var lightArray = [];
            for (var i = 0; i < 2; i++) {
                var vy = bgSprite.getPositionY() + 21 - i * 42;

                var lineSp = new ccui.Scale9Sprite("game_pic_line_gold.png");
                lineSp.setPreferredSize(cc.size(310, 2));
                lineSp.setPosition(JSScreenMidPos.x, vy);
                this.addChild(lineSp);

                var defaultX = JSScreenMidPos.x - 110 + 220 * i;
                var lineLightSp = lightArray[i] = new cc.Sprite("#game_pic_line_reflective.png");
                lineLightSp.setPosition(defaultX, vy);
                this.addChild(lineLightSp);
            }

            // 金邊動畫
            lightArray[0].runAction(cc.repeatForever(cc.sequence(
                cc.fadeIn(0.2),
                cc.moveBy(1.5, cc.p(220, 0)),
                cc.fadeOut(0.2),
                cc.callFunc(() => {
                    lightArray[0].setPositionX(JSScreenMidPos.x - 110);
                })
            )));

            lightArray[1].runAction(cc.repeatForever(cc.sequence(
                cc.fadeIn(0.2),
                cc.moveBy(1.5, cc.p(-220, 0)),
                cc.fadeOut(0.2),
                cc.callFunc(() => {
                    lightArray[1].setPositionX(JSScreenMidPos.x + 110);
                })
            )));

            // 文字
            var textLabel = new cc.LabelTTF(LocalizedString.Game("系統正在自動玩牌\n點擊螢幕來繼續遊"), JSFontBoldName, 13, cc.size(0, 0), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
            textLabel.setAnchorPoint(0.5, 1);
            textLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 19);
            this.addChild(textLabel);
        }

        this._robotSprite.resume();
    },

    /**
     * 關閉
     */
    close: function () {
        this.setVisible(false);

        this._robotSprite && this._robotSprite.pause();
    },

    /**
     * Touch的東西
     */
    _onTouchBegan: function (touch, event) {
        var target = event.getCurrentTarget();
        if (!target.isVisible())
            return false;
        for (var c = target.parent; c != null; c = c.parent) {
            if (!c.isVisible())
                return false;
        }

        return true;
    },

    _onTouchEnd: function (touch, event) {
        // 把自己關掉
        this.close();

        // 送出取消代打指令
        DataProcess.sendString("game_autoplay 0");
    },

    _onTouchCancelled: function (touch, event) {
        this._onTouchEnd(touch, event);
    }
});