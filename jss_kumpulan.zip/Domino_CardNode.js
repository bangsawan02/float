/**
 * numberString 要帶"12" 代表上下的數字
 */
var Domino_CardNode = cc.Node.extend({
    ctor: function (numberString) {
        this._super();

        this.setCascadeOpacityEnabled(true);
        this.setCascadeColorEnabled(true);

        this.cardNumber = null;                     // 牌的數字
        this.cardCount = 0;                         // 牌的總合
        this._cardNumberSpriteArray = [];           // 牌的數字圖片

        // 一開始都會顯示背面的牌
        // 背面的牌
        this._backSprite = new cc.Sprite("#game_card_bg_back.png");
        this.addChild(this._backSprite);

        // 前面的牌[背景, 前景(數字、花色)]
        var foreNode = this._foreNode = new cc.Node();
        foreNode.setCascadeColorEnabled(true);
        foreNode.setCascadeOpacityEnabled(true);
        this.addChild(foreNode);

        // 先加好白色底跟線
        var whiteBgSprite = new cc.Sprite("#game_card_bg_domino.png");
        foreNode.addChild(whiteBgSprite);

        this.setCardNumber(numberString);
    },

    /**
     * 設定是哪張牌
     * @param {String} numberString
     */
    setCardNumber: function (numberString) {
        // 防呆 轉成String
        if (numberString)
            numberString = numberString.toString();

        this.cardNumber = numberString;
        if (!numberString || numberString.length != 2)
            return;

        this.cardCount = (parseInt(numberString[0]) + parseInt(numberString[1])) % 10;

        // 先把之前的數字清掉
        this._cardNumberSpriteArray.forEach(function (cur) {
            cur && cur.removeFromParent();
        });
        this._cardNumberSpriteArray = [];

        var backSprite = this._backSprite;
        var foreNode = this._foreNode;

        for (var i = 0; i < 2; i++) {
            var nowNumber = numberString[i];
            if (nowNumber === "0")
                continue;

            var cardSprite = this._cardNumberSpriteArray[i] = new cc.Sprite(JSStringUtility.format("#game_card_reddot_%s.png", nowNumber));
            cardSprite.setPosition(0, (i === 0 ? 9.5 : -9.5) + 2);
            foreNode.addChild(cardSprite);
        }
    },

    /**
     * 取得牌的大小數值, 比大小時會用到
     * @returns {number}
     */
    getCardCount: function () {
        return this.cardCount;
    },

    /**
     * 取各別數字的總合
     */
    getCardNumberSum: function () {
        var cardNumberSum = 0;
        if (this.cardNumber)
            cardNumberSum = parseInt(this.cardNumber[0]) + parseInt(this.cardNumber[1]);
        return cardNumberSum;
    },

    /**
     * 取的牌是不是對子
     */
    isCoupleNumber: function () {
        return this.cardNumber && (this.cardNumber[0] === this.cardNumber[1]);
    },

    /**
     * 設定牌是在背面還是在前面
     */
    setCardIsInBack: function (value) {
        this._backSprite.setVisible(value);
        this._foreNode.setVisible(!value);
    },

    /**
     * 翻牌時的動畫
     */
    turnRiver: function (speed, scale = 1, isPlayEffect = true) {
        speed = speed || 0.15;      // 預設速度0.15

        // 先把背面顯示
        this.setCardIsInBack(true);

        // 動畫出來正確定數字
        var self = this;
        this.setVisible(true);
        this.stopAllActions();
        this.runAction(cc.sequence(
            cc.scaleTo(speed, 0, scale),
            cc.callFunc(function () {
                self.setCardIsInBack(false);
            }),
            cc.scaleTo(speed, scale)
        ));

        isPlayEffect && MusicUtility.playEffect("Music/Effect/turn_river.mp3");
    },
});