/**
 *  21點特效畫面
 */

var BlackjackEffectLayer = cc.Layer.extend({
    ctor: function () {
        this._super();
    },

    /**
     * 清除畫面
     */
    clean: function () {
        this.removeAllChildren();
    },

    /**
     * 出現下注教學提示
     */
    showTeachBetHint: function (cb) {
        // 讓下面不要被按到
        var dummyTouch = new DummyTouchLayer(JSVisibleSize);
        dummyTouch.setOnTouchCallback(() => {
            cb();
            this.clean();
        });
        this.addChild(dummyTouch);

        // 小手手
        var fingerSprite = new cc.Sprite("#lobby_pic_finger.png");
        fingerSprite.setPosition(320 + JSScreenBonusHalfWidth, 25);
        fingerSprite.setRotation(330);
        this.addChild(fingerSprite);

        // 提示訊息
        var msgLabel = new cc.LabelTTF(LocalizedString.Blackjack("左右滑動可選擇投注額哦!"), JSFontBoldName, 12);
        msgLabel.setFontFillColor(JSColor.BLACK);
        var param = {
            mainNode: msgLabel,
            style: BaseMessageNode.Style.GOLD,
            direct: BaseMessageNode.Direct.DOWN,
            arrowType: BaseMessageNode.ArrowType.SLANT,
            isFlip: true,
            arrowPadding: 0,
        };

        // 泡泡框
        var msgNode = new BaseMessageNode(param);
        msgNode.setPosition(JSScreenMidPos.x, 70);
        msgNode.show(2, true);
        this.addChild(msgNode);

        // 小手手動畫
        fingerSprite.runAction(cc.sequence(
            cc.moveTo(2, cc.p(220 + JSScreenBonusHalfWidth, 25)),
            cc.callFunc(() => {
                GS.localStorage.setItem("ShowBlackjackTeach", "1");
                this.clean();
            })
        ));
    },

    /**
     * 出現請下注的提示
     */
    showBetHint: function () {
        this.clean();

        // 讓下面不要被按到
        var dummyTouch = new DummyTouchLayer(JSVisibleSize);
        this.addChild(dummyTouch);

        // 黑底
        var bgLayer = new cc.LayerColor(cc.color(0, 0, 0, 150), JSVisibleSize.width + 2, JSVisibleSize.height + 2);
        bgLayer.setPosition(-1, -1);
        this.addChild(bgLayer);

        // 文字
        var betSprite = new cc.Sprite("#vegase_word_touchBet.png");
        betSprite.setPosition(JSScreenMidPos.x, 85);
        this.addChild(betSprite);

        betSprite.runAction(cc.repeatForever(cc.sequence(
            cc.scaleTo(0.5, 1.5, 1.5),
            cc.scaleTo(0.5, 1, 1)
        )));
    },

    /**
     * 出現結算畫面
     */
    showFinishResult: function (winString, winMoney) {
        var resultNode = new cc.Node();
        resultNode.setCascadeOpacityEnabled(true);
        this.addChild(resultNode);

        // 讓下面不要被按到
        var dummyTouch = new DummyTouchLayer(JSVisibleSize);
        resultNode.addChild(dummyTouch);

        // 黑底
        var bgLayer = new cc.LayerColor(cc.color(0, 0, 0, 150), JSVisibleSize.width + 2, JSVisibleSize.height + 2);
        bgLayer.setPosition(-1, -1);
        resultNode.addChild(bgLayer);

        var bgName, wordName;
        var wordY = JSScreenMidPos.y - 34;
        var isSpecialEffect = false;
        var isNeedReward = true;
        var idleTime = 0.1;
        var isLose = false;
        switch (winString) {
            case "lose":
            case "bust":
                // 玩家輸
                bgName = "#bj_bg_lose.png";
                wordName = "#vegase_word_lose.png";
                isNeedReward = false;
                isLose = true;
                break;
            case "push":
                // 平手
                bgName = "#bj_bg_lose.png";
                wordName = "#vegas_word_draw.png";
                isNeedReward = false;
                break;
            case "win":
            case "blackjack":
                bgName = "#bj_bg_light.png";
                wordName = "#vegase_word_win.png";
                wordY = JSScreenMidPos.y - 12;
                break;
            case "5dragon":
                wordName = "#bj_word_fiveCard.png";
                wordY = JSScreenMidPos.y - 31;
                isSpecialEffect = true;
                idleTime = 1;
                break;
            case "777":
                wordName = "#bj_word_777.png";
                wordY = JSScreenMidPos.y - 31;
                isSpecialEffect = true;
                idleTime = 1;
                break;
            case "flush_straight":
                wordName = "#bj_word_flush.png";
                wordY = JSScreenMidPos.y - 31;
                isSpecialEffect = true;
                idleTime = 1;
                break;
        }

        if (isSpecialEffect) {
            // 創外框
            var scaleX = (JSVisibleSize.width - 8) / 4;
            var scaleY = (215 + JSScreenBonusHalfHeight) / 215;
            var frameLeft = new cc.Sprite("#bj_winFrame01.png");
            frameLeft.setFlippedX(true);
            frameLeft.setAnchorPoint(0, 0);
            frameLeft.setPosition(0, 30);
            frameLeft.setScaleY(scaleY);
            resultNode.addChild(frameLeft);

            var frameRight = new cc.Sprite("#bj_winFrame01.png");
            frameRight.setAnchorPoint(1, 0);
            frameRight.setPosition(JSVisibleSize.width, 30);
            frameRight.setScaleY(scaleY);
            resultNode.addChild(frameRight);

            var frameMid = new cc.Sprite("#bj_winFrame02.png");
            frameMid.setAnchorPoint(0.5, 0);
            frameMid.setPosition(JSScreenMidPos.x, 30);
            frameMid.setScaleX(scaleX);
            frameMid.setScaleY(scaleY);
            resultNode.addChild(frameMid);

            // 創光點動畫
            resultNode.addChild(this._createLightBall(true, 1, 3));
            resultNode.addChild(this._createLightBall(false, 1, 3));
            resultNode.runAction(cc.sequence(
                cc.delayTime(1),
                cc.callFunc(function () {
                    resultNode.addChild(this._createLightBall(true, 0.75, 6));
                    resultNode.addChild(this._createLightBall(false, 0.75, 6));
                }, this),
                cc.delayTime(1),
                cc.callFunc(function () {
                    resultNode.addChild(this._createLightBall(true, 0.5, 9));
                    resultNode.addChild(this._createLightBall(false, 0.5, 9));
                }, this),
                cc.delayTime(1),
                cc.callFunc(function () {
                    resultNode.addChild(this._createLightBall(true, 0.25, 12));
                    resultNode.addChild(this._createLightBall(false, 0.25, 12));
                }, this)
            ));

            // 放金幣
            var self = this;
            resultNode.schedule(function () {
                resultNode.addChild(self._createCoinAnimation());
            }, 0.05);

            // 撥放音樂
            Vegas_MusicUtility.playEffect("Music/Effect/blackjack_bigWin.mp3");
        } else {
            var bgSprite = new cc.Sprite(bgName);
            var scaleX = JSVisibleSize.width / bgSprite.getContentSize().width;
            bgSprite.setScaleX(scaleX);
            bgSprite.setScaleY(0);
            bgSprite.setPosition(JSScreenMidPos);
            bgSprite.setOpacity(0);
            resultNode.addChild(bgSprite);

            bgSprite.runAction(cc.scaleTo(1, scaleX, 1));
            bgSprite.runAction(cc.fadeTo(2, 200).easing(cc.easeInOut(2)));

            // 21點贏牌效果
            if (winString === "blackjack") {
                var bgSprite = new cc.Sprite("#bj_word_blackjack.png");
                bgSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 80);
                bgSprite.setOpacity(0);
                bgSprite.setScale(0.8);
                resultNode.addChild(bgSprite);

                bgSprite.runAction(cc.spawn(
                    cc.scaleTo(1, 1),
                    cc.fadeTo(2, 255).easing(cc.easeInOut(2))
                ));
            }

            // 撥放音樂
            if (isLose)
                Vegas_MusicUtility.playEffect("Music/Effect/blackjack_lose.mp3");
            else if (winString === "push")
                Vegas_MusicUtility.playEffect("Music/Effect/blackjack_draw.mp3");
            else
                Vegas_MusicUtility.playEffect("Music/Effect/blackjack_win.mp3");
        }

        // 勝利撥放光條
        if (!isLose && winString !== "push") {
            var self = this;
            resultNode.schedule(function () {
                resultNode.addChild(self._createFlashLight());
            }, 0.3);
        }

        // 文字
        var wordSprite = new cc.Sprite(wordName);
        wordSprite.setAnchorPoint(0.5, 0);
        wordSprite.setPosition(JSScreenMidPos.x, wordY);
        wordSprite.setScale(0.8);
        wordSprite.setOpacity(0);
        resultNode.addChild(wordSprite, 1);

        wordSprite.runAction(cc.spawn(
            cc.scaleTo(1, 1),
            cc.fadeTo(2, 255).easing(cc.easeInOut(2))
        ));

        // 判斷是否要出現金額 平手不show
        if (winMoney > 0 && winString !== "push") {
            var moneyPosY = JSScreenMidPos.y - 26;
            if (winString !== "win" && winString !== "blackjack") {
                // 其他金錢位置要調整
                moneyPosY = JSScreenMidPos.y - 43;
            }

            var moneyNode = this._createMoneyNode(winMoney);
            moneyNode.setPosition(JSScreenMidPos.x, moneyPosY);
            moneyNode.setOpacity(0);
            moneyNode.setScale(0.8);
            resultNode.addChild(moneyNode, 1);

            // 動畫
            moneyNode.runAction(cc.scaleTo(1, 1));
            moneyNode.runAction(cc.fadeIn(2).easing(cc.easeInOut(2)));
        }

        // 有贏錢要判斷
        if (isNeedReward)
            DataProcess.sendString("slot10_reward");

        // 最後要設定關掉
        resultNode.runAction(cc.sequence(
            cc.delayTime(2 + idleTime),
            cc.fadeOut(0.3),
            cc.callFunc(function () {
                // 通知動畫做完了
                GS.dispatchCustomEvent("NotifyBlackjackResultDone");
            }),
            cc.removeSelf()
        ));

    },

    // 創金錢的數字
    _createMoneyNode: function (money) {
        // 先計算Sprite總寬度 數字高度固定為50 逗點寬26 其他寬40
        var retNode = new cc.Node();
        retNode.setCascadeOpacityEnabled(true);

        var moneyString = JSCodeUtility.getCurrencyString(money);
        var moneyLen = moneyString.length;
        var moneyPosX = 0;
        for (var i = 0; i < moneyLen; i++) {
            var moneyChar = moneyString[i];
            var isDot = (moneyChar === ",");
            var moneySprite = new cc.Sprite("#vegase_number" + moneyChar + ".png");
            moneySprite.setPosition(moneyPosX, isDot ? -15 : 0);
            moneySprite.setAnchorPoint(0, 0.5);
            retNode.addChild(moneySprite);

            moneyPosX += (isDot ? 16 : 30);
        }

        // 要重新對位
        var offsetX = moneyPosX / 2;
        retNode.getChildren().forEach(function (cur) {
            var originPos = cur.getPosition();
            cur.setPosition(originPos.x - offsetX, originPos.y);
        });


        return retNode;
    },

    // 亮光點的動畫
    _createLightBall: function (isRight, scaleSize, speed) {
        var point = isRight ? cc.p(JSVisibleSize.width - 1, 30) : cc.p(1, JSScreenMidPos.y + 99);
        var width = JSVisibleSize.width - 2;
        var height = 213 + JSScreenBonusHalfHeight;
        var pointArray = [
            cc.p(0, 0),
            cc.p(isRight ? -width : width, 0),
            cc.p(isRight ? -width : width, isRight ? height : -height),
            cc.p(0, isRight ? height : -height),
            cc.p(0, 0)
        ];

        var lightBallSprite = new cc.Sprite("#vegas_effectLight_02.png");
        lightBallSprite.setScale(scaleSize);
        lightBallSprite.setPosition(point);

        // 動畫
        lightBallSprite.runAction(cc.repeatForever(cc.cardinalSplineBy(speed, pointArray, 1)));

        lightBallSprite.runAction(cc.repeatForever(cc.rotateBy(1, 360)));

        if (scaleSize < 1) {
            lightBallSprite.runAction(cc.repeatForever(cc.sequence(
                cc.fadeTo(0.5, 40),
                cc.fadeTo(0.5, 255)
            )));
        }

        return lightBallSprite;
    },

    // 亮光條的動畫
    _createFlashLight: function () {
        var retNode = new cc.Node();
        retNode.setCascadeOpacityEnabled(true);

        for (var i = 0; i < 2; i++) {
            var lightSprite = new cc.Sprite("#bj_winSpotLight.png");
            lightSprite.setScale(2);
            lightSprite.setAnchorPoint(0.5, 0);
            lightSprite.setPosition(JSScreenMidPos.x + (i === 0 ? -154 : 154), JSScreenMidPos.y - 56);
            lightSprite.setRotation(i === 0 ? -90 : 90);
            lightSprite.setOpacity(0);
            retNode.addChild(lightSprite);

            lightSprite.runAction(cc.rotateBy(1.3, i === 0 ? 180 : -180));
            lightSprite.runAction(cc.sequence(
                cc.fadeTo(0.2, 30),
                cc.delayTime(0.8),
                cc.fadeTo(0.3, 0),
                cc.removeSelf()
            ));
        }

        return retNode;
    },

    // 金幣的動畫
    _createCoinAnimation: function () {
        var retNode = new cc.Node();
        retNode.setCascadeOpacityEnabled(true);

        var coinSprite = new cc.Sprite("#anim_chip_0.png");
        coinSprite.setOpacity(0);
        coinSprite.setPosition(JSScreenMidPos.x + JSCodeUtility.getRandomInt(-230, 230), JSScreenMidPos.y + JSCodeUtility.getRandomInt(-44, 0));
        retNode.addChild(coinSprite);

        // 一直換圖
        var aniFramesArray = [];
        for (var i = 0; i < 6; i++) {
            aniFramesArray.push(cc.spriteFrameCache.getSpriteFrame(JSStringUtility.format("anim_chip_%d.png", i)));
        }
        coinSprite.runAction(cc.repeatForever(cc.animate(new cc.Animation(aniFramesArray, 0.1))));

        // 動畫
        coinSprite.runAction(cc.sequence(
            cc.fadeIn(0.2),
            cc.delayTime(1),
            cc.fadeOut(0.2),
            cc.removeSelf()
        ));
        coinSprite.runAction(cc.jumpTo(1.4, cc.p(JSScreenMidPos.x + JSCodeUtility.getRandomInt(-230, 230), -30), 200, 1));

        return retNode;
    },
});