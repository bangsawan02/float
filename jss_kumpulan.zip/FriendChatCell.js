/**
 * 聊天訊息的Cell
 * 顯示貼圖/文字的訊息
 */

var FriendChatCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        var posY = 0;

        // 訊息整個node
        var mainNode = this._mainNode = new cc.Node();
        this.addChild(mainNode);

        // 時間
        var timeLabel = this._timeLabel = new cc.LabelTTF("", JSFontName, 8);
        timeLabel.setOpacity(178);
        timeLabel.setAnchorPoint(0, 1);
        timeLabel.setPosition(16, posY);
        mainNode.addChild(timeLabel);

        // 時鐘
        var clockSp = this._clockSp = new cc.Sprite("#lobby_pic_clock_02.png");
        clockSp.setScale(0.45);
        clockSp.setAnchorPoint(0, 1);
        clockSp.setOpacity(178);
        clockSp.setPosition(timeLabel.getPositionX() + timeLabel.getContentSize().width / 2, posY);
        mainNode.addChild(clockSp);

        // 訊息(顯示)
        var clockHeight = clockSp.getBoundingBox().height;
        var offsetY = posY - clockHeight;
        var msgLabel = this._msgLabel = new cc.LabelTTF("", JSFontName, 10);
        msgLabel.setAnchorPoint(0, 1);
        msgLabel.setPosition(9, offsetY - 5);
        msgLabel.setFontFillColor(JSColor.BLACK);
        msgLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
        msgLabel.setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP);
        msgLabel.setDimensions(cc.size(155, 48));
        mainNode.addChild(msgLabel);

        // 訊息(確認長度)
        var lenLabel = this._lenLabel = new cc.LabelTTF("", JSFontName, 10);
        lenLabel.setAnchorPoint(0, 1);
        lenLabel.setPosition(10, offsetY - 6);
        lenLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
        lenLabel.setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP);
        mainNode.addChild(lenLabel);
        lenLabel.setVisible(false);

        // 訊息的泡泡框
        var msgSize = msgLabel.getContentSize();
        var msgBg = this._msgBg = new ccui.Scale9Sprite("chat_bg_msg.png");
        msgBg.setPreferredSize(cc.size(msgSize.width + 15, msgSize.height + 5));
        msgBg.setAnchorPoint(0, 1);
        msgBg.setPosition(0, offsetY - 3);
        msgBg.setVisible(false);
        mainNode.addChild(msgBg, -1);

        // 表情貼圖
        var emoticons = this._emoticons = new cc.Sprite("#emoticons_n_07.png");
        emoticons.setAnchorPoint(0, 1);
        emoticons.setPositionY(-3);
        emoticons.setVisible(false);
        mainNode.addChild(emoticons);

        // 時間的loading
        var loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(FriendChatLayer.WIDTH - 15, posY - 5);
        loadingSprite.setScale(0.15);
        loadingSprite.stop();
        mainNode.addChild(loadingSprite);
    },

    /**
     * 確認要不要show日期
     * @param date       日期
     * @param height     高度
     * @param isShowDate 需不需要show 創建當天的日期
     * @param isShowTip  有沒有show "往下拉查看更多" 提示 用來調整訊息高度
     */
    _checkDate: function (date, height, isShowDate, isShowTip) {
        // 訊息的高度
        height = (isShowTip) ? height - 10 : height;

        // 不show日期
        if (!isShowDate) {
            // 關閉日期
            this._dateNode && this._dateNode.setVisible(false);

            // 調整訊息的位置
            this._mainNode.setPositionY(height);
            return;
        }

        // show日期

        // 分解月跟日(date = 月*100+日)
        var month = Math.floor(date / 100);
        var day = date % 100;
        var dateStr = JSStringUtility.format("%02d/%02d", day, month);

        if (!this._dateNode) {
            // 創建日期的node
            var dateNode = this._dateNode = new cc.Node();
            dateNode.setPosition(FriendChatLayer.WIDTH / 2, 0);
            this.addChild(dateNode);

            // 日期文字的背景
            var dateBg = new ccui.Scale9Sprite("bg_information1.png");
            dateBg.setPreferredSize(cc.size(40, 17));
            dateBg.setOpacity(102);
            dateNode.addChild(dateBg);

            // 日期
            var dateLabel = this._dateLabel = new cc.LabelTTF("", JSFontName, 9);
            dateLabel.setOpacity(178);
            dateNode.addChild(dateLabel);
        }

        // 調整高度
        this._dateLabel.setString(dateStr);
        this._dateNode.setPositionY(height - 10);
        this._dateNode.setVisible(true);

        // 有日期訊息的位置下移
        this._mainNode.setPositionY(height - 13);
    },

    /**
     * 刷新聊天內容
     * */
    refreshCell: function (param, isShowTip) {
        if (!param)
            return;

        // 先關掉所有內容
        this._emoticons.setVisible(false);
        this._msgBg.setVisible(false);
        this._msgLabel.setString("");

        // 文字訊息的高度
        var height = param.msgHeight;
        // cell的寬度
        var width = FriendChatLayer.WIDTH;

        // 是不是自己的訊息
        var isMe = param.isMe;

        // 確認日期
        this._checkDate(param.date, param.cellHeight, param.isShowDate, isShowTip);

        // 調整送出訊息的時間的位置
        var time = param.time;
        if (time === 0) {
            // 還沒收到時間做個loading
            this._loadingSprite && this._loadingSprite.start();
            this._timeLabel.setString("");
        } else {
            // 收到訊息關掉loading (loadingSprite 有時會直接被清掉 導致stop沒有作用 直接移除他)
            if (this._loadingSprite) {
                this._loadingSprite.removeFromParent(true);
                this._loadingSprite = undefined;
            }
            this._timeLabel.setString(time);
        }
        var timeLabelWidth = this._timeLabel.getContentSize().width;
        var posX = (isMe) ? width - timeLabelWidth - 10 : 0;
        this._timeLabel.setPositionX(posX);

        // 調整送出訊息的時鐘的位置
        posX = (isMe) ? width - 10 : timeLabelWidth;
        this._clockSp.setPositionX(posX);

        // 訊息的種類
        switch (param.type) {
            case ChatRoomData.MessageType.Label:
                // 文字
                var msg = param.message;
                this._msgLabel.setString(msg);
                this._lenLabel.setString(msg);
                var msgWidth = this._lenLabel.getContentSize().width;
                msgWidth = (msgWidth > 155 || isMe) ? 155 : msgWidth;   // 自己的固定最大
                // 設置背景大小
                this._msgBg.setPreferredSize(cc.size(msgWidth + 15, height - 15));

                //對方顯示左邊 自己顯示右邊
                if (isMe) {
                    // 我的訊息設定
                    this._msgBg.setOpacity(255);
                    this._msgBg.setPositionX(width);
                    this._msgBg.setScaleX(-1);
                    this._msgLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
                } else {
                    // 好友的訊息
                    this._msgBg.setOpacity(153);
                    this._msgBg.setPositionX(0);
                    this._msgBg.setScaleX(1);
                    this._msgLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
                }

                // 打開訊息
                this._msgBg.setVisible(true);

                break;
            case ChatRoomData.MessageType.Emoticons:
                // 貼圖
                this._emoticons.setSpriteFrame(param.message + ".png");
                // 對方顯示左邊 自己pic顯示右邊
                posX = (isMe) ? width - 63 : 0;
                this._emoticons.setPositionX(posX);
                this._emoticons.setVisible(true);

                break;
        }
    }
});
