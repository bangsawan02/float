/**
 * v5.4.7 聊天室優惠券 - 聊天室優惠券的Cell
 * created by lichieh on 2023/1/4
 */
var DiscountNotifyChatCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        var posY = 0;

        // 訊息整個node
        var mainNode = this._mainNode = new cc.Node();
        mainNode.setPositionY(DiscountNotifyChatCell.HEIGHT - 10);
        this.addChild(mainNode);

        // 訊息(顯示)
        var offsetY = posY;
        var msgLabel = this._msgLabel = new GSAutoSizeLabel("", JSFontName, 12, cc.size(78, 28), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        msgLabel.setLineBreak(true);
        msgLabel.resizeToFit(10);
        msgLabel.setPosition(115, -27);
        msgLabel.setFontFillColor(JSColor.BLACK);
        mainNode.addChild(msgLabel);

        // 訊息的泡泡框
        var msgBg = new ccui.Scale9Sprite("chat_bg_msg.png");
        msgBg.setPreferredSize(cc.size(FriendChatLayer.WIDTH - 10, 80));
        msgBg.setAnchorPoint(0, 1);
        msgBg.setOpacity(153);
        msgBg.setPosition(0, offsetY - 3);
        mainNode.addChild(msgBg, -1);

        var rewardIconSp = this._downloadSp = new GSDownloadSprite();
        rewardIconSp.setTargetSize(cc.size(70, 70));
        rewardIconSp.setPosition(38, -42);
        mainNode.addChild(rewardIconSp);

        var mainBtn = ButtonUtility.createSimpleButton("lobby_btn_01.png", cc.size(80, 32), LocalizedString.PurchaseCoupon("立即前往"), JSColor.BLACK, 11);
        mainBtn.addTouchUpInsideAction(this._mainBtnClicked, this);
        mainBtn.enableTouchCancel(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        mainBtn.setPosition(115, -62);
        mainBtn.label.setPosition(0, 6.5);
        mainNode.addChild(mainBtn);

        // 倒數背景
        var countDownBg = new ccui.Scale9Sprite("lobby_bg_list_04.png");
        countDownBg.setPreferredSize(cc.size(68, 12));
        countDownBg.setOpacity(150);
        countDownBg.setPosition(0, -6.5);
        mainBtn.addChildToContentNode(countDownBg);

        var clockSp2 = new cc.Sprite("#lobby_pic_clock_02.png");
        clockSp2.setScale(0.45);
        clockSp2.setAnchorPoint(0, 0.5);
        clockSp2.setPosition(-28, -6.5);
        mainBtn.addChildToContentNode(clockSp2);

        // 倒數文字
        var countLabel = this._countLabel = new GSTimeLabel("", JSFontName, 10);
        countLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        countLabel.setPosition(5, -6.5);
        countLabel.setMultiFormat(
            "%dd hari",
            "%hh:%mm:%ss"
        );
        mainBtn.addChildToContentNode(countLabel);

        // 創建日期的node
        var dateNode = this._dateNode = new cc.Node();
        dateNode.setVisible(false);
        dateNode.setPosition(DiscountNotifyChatLayer.WIDTH / 2, DiscountNotifyChatCell.HEIGHT - 6);
        this.addChild(dateNode);

        // 日期文字的背景
        var dateBg = new ccui.Scale9Sprite("bg_information1.png");
        dateBg.setPreferredSize(cc.size(40, 17));
        dateBg.setOpacity(102);
        dateNode.addChild(dateBg);

        // 日期
        var dateLabel = this._dateLabel = new cc.LabelTTF("", JSFontName, 9);
        dateLabel.setOpacity(178);
        dateNode.addChild(dateLabel);
    },

    /**
     * 刷新聊天內容
     * */
    refreshCell: function (param) {
        if (!param)
            return;

        this._param = param;

        // 顯示日期
        if (param.getDateString) {
            this._dateLabel.setString(param.getDateString);
            this._dateNode.setVisible(true);
        } else
            this._dateNode.setVisible(false);

        // 文字
        this._msgLabel.setString(param.message);

        // 刷新圖檔
        var image = param.wid + ".png";
        var imgURL = DataModal.chatRoomData.couponImgURL + image;
        var savePath = JSWriteablePath + "discount/" + image;
        this._downloadSp.refreshByImageUrl(imgURL, savePath);

        // 刷新時間 remainTime
        this._countLabel.countdownSeconds(JSCodeUtility.getRemainTime(param.remainTime, param.socketTime), () => {
            // 刷新清單
            GS.dispatchCustomEvent("NotifyChatRoomDiscountDone");

            // 重送優惠券
            DataModal.chatRoomData.startGetChatRoomDiscountInfo();
            // 重送背包優惠券
            DataModal.purchaseCouponData.startGetCouponAssembleInfo();
        });
    },

    /**
     * 按鈕點擊
     */
    _mainBtnClicked: function () {
        GS.dispatchCustomEvent("NotifyCloseChatRoomLayer");

        // 送埋點
        switch (this._param.bannerType) {
            case LobbyBannerMode.Purchase:
                // 2 點擊立即前往不重覆人數
                DataProcess.sendString("track_chat_room_coupon 2");
                break;

            case LobbyBannerMode.VegasCompete:
                // 4 點擊爭霸賽立即前往不重覆人數
                DataProcess.sendString("track_chat_room_coupon 4");
                break;

            case LobbyBannerMode.VegasRacing:
                // 6 點擊極速競飆立即前往不重覆人數
                DataProcess.sendString("track_chat_room_coupon 6");
                break;
        }

        // 前往引導
        PushLayerHelper.pushLayer("", this._param.bannerType);
    },
});

DiscountNotifyChatCell.HEIGHT = 95;