/**
 * v5.6.0 齋戒副系統 賓果連線時發光的格子
 * @param index{int} 格子的 index
 */
var FarmBingoGlowingGridNode = cc.Node.extend({
    ctor: function (index) {
        this._super();

        var bingoData = DataModal.farmBingoData.bingoParam;

        // 發光動畫
        GSSpine.create("spine/FarmBingo/PIC_chain-light/PIC_chain-light", 0.25, (spine) => {
            spine.setAnimation(0, index === 12 ? "ani_grid-light_01" : index === 0 || index === 4 || index === 20 || index === 24 ? "ani_grid-light_03" : "ani_grid-light_02", true);
            spine.setRotation(index === 0 ? -90 : index === 24 ? 90 : index === 20 ? 180 : 0);
            spine.setOpacity(0);
            spine.runAction(cc.fadeIn(0.2));
            this._spine = spine;
            this.addChild(spine);
        });

        var gridNode = new FarmBingoGridNode(index);
        gridNode.setIsWon(true);
        gridNode.setNumber(bingoData.cardData.numArray[index]);
        this.addChild(gridNode, 1);
    },

    getSpine: function () {
        return this._spine;
    }
});