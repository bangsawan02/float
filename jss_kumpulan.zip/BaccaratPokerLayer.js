/**
 * 百家樂放牌的畫面
 */

var BaccaratPokerLayer = cc.Layer.extend({
    LEFT: 0,
    RIGHT: 1,
    START_CARD_SCALE: 0.62,         // 一開始牌的大小
    END_CARD_SCALE: 0.596,          // 最後牌的大小
    PC_CARD_SCALE: 0.85,            // 電腦手牌的大小
    PLAYER_CARD_SCALE: 1,           // 玩家手牌的大小
    CARD_ANIMATION_TIME: 0.2,       // 牌動畫的時間

    ctor: function () {
        this._super();

        this._score = [0, 0];       // 兩邊的分數 先放左 在放右
        this._cardArray = [];       // 兩邊的牌

        // 左邊是Player 右邊是Banker 先放左 在放右
        this._numberLabels = [];
        var titleImageString = ["#bcr_word_player.png", "#bcr_word_banker.png"];
        var blueImageString = ["#bcr_doc_blue.png", "#bcr_doc_red.png"];
        for (var i = 0; i < 2; i++) {
            var ratio = i === 0 ? -1 : 1;
            // 標題
            var titleSprite = new cc.Sprite(titleImageString[i]);
            titleSprite.setPosition(JSScreenMidPos.x + (74 * ratio), JSScreenMidPos.y + 90);
            titleSprite.setOpacity(127);
            this.addChild(titleSprite);

            // 數字背景
            var labelBgSprite = new cc.Sprite(blueImageString[i]);
            labelBgSprite.setPosition(JSScreenMidPos.x + (25 * ratio), JSScreenMidPos.y + 90);
            this.addChild(labelBgSprite);

            // 數字
            var numberLabel = this._numberLabels[i] = new cc.LabelTTF("0", JSFontBoldName, 14);
            numberLabel.setPosition(JSScreenMidPos.x + (25 * ratio), JSScreenMidPos.y + 90);
            this.addChild(numberLabel);
        }

        // 中間分格線
        var midLine = new cc.Sprite("#btn_function_line.png");
        midLine.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 54);
        midLine.setScaleY(2.3);
        this.addChild(midLine);

        // 右上角的發牌圖
        var deckPos = cc.p(JSVisibleSize.width - 10 - JSScreenSafeWidth, JSVisibleSize.height - 52);
        var deckSprite = new cc.Sprite(GameTableTheme.getPokerDeckTheme());
        deckSprite.setPosition(deckPos);
        this.addChild(deckSprite);

        // 顯示目前有幾張牌
        var cardNumberLabel = this._cardNumberLabel = new cc.LabelTTF("0", JSFontBoldName, 12);
        cardNumberLabel.setPosition(deckPos.x - 20, deckPos.y - 48);
        this.addChild(cardNumberLabel);

        this._fromDeckPos = cc.p(deckPos.x - 15, deckPos.y - 15);

        // 牌的位置
        var index = [4, 0, 2, 1, 3, 5];     // 從左至右出牌牌的順序 跟C++不一樣算法 這邊是用中間去切的
        var cardPosY = this._cardPosY = JSScreenMidPos.y + 45;
        this._cardPosArray = [
            cc.p(JSScreenMidPos.x - 77, cardPosY),              // 左邊的第一張牌
            cc.p(JSScreenMidPos.x + 35, cardPosY),              // 右邊的第一張牌
            cc.p(JSScreenMidPos.x - 35, cardPosY),              // 左邊的第二張牌
            cc.p(JSScreenMidPos.x + 77, cardPosY),              // 右邊的第二張牌
            cc.p(JSScreenMidPos.x - 131, cardPosY),             // 左邊的第三張牌
            cc.p(JSScreenMidPos.x + 131, cardPosY),             // 右邊的第三張牌
        ];

        // DrawNode 先放左 在放右
        var drawNodes = this._drawNodes = [];
        for (var i = 0; i < 2; i++) {
            var node = drawNodes[i] = new cc.Node();
            node.setPosition(JSScreenMidPos.x + 130 * (i === 0 ? -1 : 1), JSScreenMidPos.y + 50);
            node.setVisible(false);
            this.addChild(node, 6);

            // 背景
            var bgSprite = new ccui.Scale9Sprite("bcr_info_bg.png");
            bgSprite.setPreferredSize(cc.size(46, 14));
            node.addChild(bgSprite);

            // 文字
            var drawLabel = new cc.LabelTTF("Draw", JSFontBoldName, 12);
            node.addChild(drawLabel);
        }
    },

    /**
     * 清掉東西
     */
    clean: function () {
        this._score = [0, 0];
        this._cardArray.forEach(card => card.removeFromParent());
        this._cardArray = [];

        this._numberLabels.forEach(label => label.setString("0"));
    },

    /**
     * 計算分數
     */
    _calcuateScore: function (number, index) {
        var arrayPos = index % 2;           // 0是左 1是右
        var nowScore = (this._score[arrayPos] + number) % 10;
        this._score[arrayPos] = nowScore;

        var numberLabel = this._numberLabels[arrayPos];
        numberLabel.runAction(cc.sequence(
            cc.scaleTo(0.14, 1.7),
            cc.callFunc(function () {
                numberLabel.setString(nowScore);
            }, this),
            cc.scaleTo(0.06, 1)
        ))
    },

    /**
     * 發牌
     */
    _sendCardAsync: function (index, cardNumber) {
        return new Promise(resolve => {
            // 先判斷是否要出現DrawNode
            var drawNode;
            if (index >= 4) {
                drawNode = this._drawNodes[index - 4];
                drawNode.setVisible(true);
            }

            var card = new BaccaratPokerCard();
            card.setScale(0.8);
            card.setRotation(118);
            card.setPosition(this._fromDeckPos);
            card.setOpacity(0);
            this.addChild(card, 1);
            this._cardArray.push(card);

            card.runAction(cc.sequence(
                cc.spawn(
                    cc.scaleTo(0.2, 1),
                    cc.fadeIn(0.2)
                ),
                cc.spawn(
                    cc.moveTo(0.35, this._cardPosArray[index]).easing(cc.easeOut(0.35)),
                    cc.rotateTo(0.35, 0).easing(cc.easeOut(0.35))
                ),
                cc.delayTime(0.4),
                cc.callFunc(function () {
                    // 翻牌
                    card.turnCard(cardNumber);

                    // 把DrawNode關掉
                    drawNode && drawNode.setVisible(false);

                    // 計算分數
                    this._calcuateScore(card.getCardNumber(), index);

                    // 結束掉
                    resolve();
                }, this),
                cc.delayTime(0.8),
                cc.callFunc(function () {

                }, this)
            ));

            // 把牌數量更新
            this.setCardCount(this._cardCount - 1);
        });
    },

    /**
     * 設定牌的數量
     */
    setCardCount: function (count) {
        this._cardCount = count;
        this._cardNumberLabel.setString(count.toString());
    },

    /**
     * 開始發前四張牌
     */
    sendFirstCardAsync: function (param) {
        return new Promise(resolve => {
            // 先把所有牌清掉
            this.clean();

            // 去發牌
            this._sendCardAsync(0, param.cards[0])
                .then(res => this._sendCardAsync(1, param.cards[1]))
                .then(res => this._sendCardAsync(2, param.cards[2]))
                .then(res => this._sendCardAsync(3, param.cards[3]))
                .then(res => resolve());
        });
    },

    /**
     * 開左右兩邊最後的牌
     */
    sendLastCardAsync: function (param) {
        return new Promise(resolve => {
            // 去發牌
            Promise.resolve()
                .then(() => {
                    if (param.cards[4])
                        return this._sendCardAsync(4, param.cards[4]);
                    else
                        return Promise.resolve();
                })
                .then(() => {
                    if (param.cards[5])
                        return this._sendCardAsync(5, param.cards[5]);
                    else
                        return Promise.resolve();
                })
                .then(() => {
                    // 這邊晚一點點在resolve
                    this.runAction(cc.sequence(
                        cc.delayTime(1.5),
                        cc.callFunc(resolve)
                    ));
                });
        });
    },

    /**
     * 把牌收起來丟掉
     */
    closeCard: function () {
        var midPos = cc.p(JSScreenMidPos.x, this._cardPosY);
        var outPos = cc.p(JSScreenMidPos.x, JSVisibleSize.height + 40);
        this._cardArray.forEach(card => {
            card.turnCardToBackAsync()
                .then(() => {
                    card.runAction(cc.sequence(
                        cc.moveTo(0.5, midPos),
                        cc.moveTo(0.7, outPos).easing(cc.easeOut(2))
                    ))
                })
        });
    },
});