/**
 * 5.5.9 移植中撲 連續儲值 - 教學
 * created by webber.chen
 */

var ContinueRechargeTeachLayer = cc.Node.extend({
    ctor: function () {
        this._super();

        // 加入檔Touch
        var dummyTouchLayer = this._dummyTouchLayer = new DummyTouchLayer(JSVisibleSize);
        this.addChild(dummyTouchLayer);

        // 黑色底遮罩區
        var blackLayer = new cc.LayerColor(cc.color(0, 0, 0, 200), JSVisibleSize.width, JSVisibleSize.height);
        var clippingNode = this._clippingNode = new cc.ClippingNode(new cc.DrawNode());
        clippingNode.addChild(blackLayer);
        clippingNode.setInverted(true);
        this.addChild(clippingNode);

        // 第一步驟（印尼刪除中撲第一步驟）
        this.createDialogTeachView(1);
        this.createDialogTeachView(2);

        DataModal.continueRechargeData.continueRechargeTeachMode = true;
    },

    onEnter: function () {
        this._super();

        // 檔Back Key
        PushScene.addBackKeyEnableLayer(this);
    },

    onExit: function () {
        PushScene.removeBackKeyEnableLayer(this);

        this._super();
    },

    createDialogTeachView: function (step) {
        this._step = step;

        switch (step) {
            case 1:
                this._step1();
                break;
            case 2:
                this._step2();
                break;
            case 3:
                this._step3();
                break;
            case 4:
                this._step4();
                break;
            case 5:
                this._step5();
                break;
            case 6:
                this._step6();
                break;
        }
    },

    getCurrentStep: function () {
        return this._step;
    },

    setFinishCallback: function (finishCallback) {
        this._finishCallback = finishCallback;
    },

    _step1: function () {
        // 設定callBack
        this._dummyTouchLayer.setOnTouchCallback(() => {
            this.createDialogTeachView(2);
        });

        // 點擊任一處繼續
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        this.addChild(menu);

        var tipNode = ButtonUtility.createBtnLabelWithUnderLine(LocalizedString.ContinueRecharge("點擊任一處繼續"), 11, JSColor.WHITE, -1.5);
        var tipBtn = this._tipBtn = new cc.MenuItemSprite(tipNode[0], tipNode[1], tipNode[2], () => {
            this._step++;
            this.createDialogTeachView(this._step);
        }, this);
        tipBtn.setPosition(JSScreenSafeWidth + 13, 13);
        tipBtn.setAnchorPoint(0, 0);
        menu.addChild(tipBtn);

        // 訊息
        var messageNode = new cc.Node();
        messageNode.setContentSize(cc.size(82, 38));

        var welcomeMessageLabel = new cc.LabelTTF(LocalizedString.ContinueRecharge("歡迎您蒞臨~\n珍品拍賣會！"), JSFontName, 12);
        welcomeMessageLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        welcomeMessageLabel.setFontFillColor(JSColor.BLACK);
        messageNode.addChild(welcomeMessageLabel);

        var messageParam = {
            mainNode: messageNode,
            style: BaseMessageNode.Style.WHITE,
            direct: BaseMessageNode.Direct.DOWN_RIGHT,
            arrowType: BaseMessageNode.ArrowType.STRAIGHT,
            arrowPadding: 38,
        };

        var welcomeMessageNode = this._welcomeMessageNode = new BaseMessageNode(messageParam);
        welcomeMessageNode.setPosition(JSScreenMidPos.x + 164, 182);
        welcomeMessageNode.show();
        this.addChild(welcomeMessageNode);
    },

    _step2: function () {
        // 紀錄已經進入過教學模式
        GS.localStorage.setItem("continueRechargePeriod" + DataModal.profileData.account, DataModal.continueRechargeData.period);

        // 歡迎的泡泡框消失
        this._welcomeMessageNode.removeFromParent();
        this._welcomeMessageNode = undefined;

        // 點擊任一處繼續拿掉
        this._tipBtn.setVisible(false);
        this._dummyTouchLayer.setOnTouchCallback(undefined);

        // 訊息
        var messageNode = new cc.Node();
        messageNode.setContentSize(cc.size(82, 38));

        var clickMessageLabel = new cc.LabelTTF(LocalizedString.ContinueRecharge("點擊領獎即可\n獲得獎勵"), JSFontName, 12);
        clickMessageLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        clickMessageLabel.setFontFillColor(JSColor.BLACK);
        messageNode.addChild(clickMessageLabel);

        var clickMessageParam = {
            mainNode: messageNode,
            style: BaseMessageNode.Style.WHITE,
            direct: BaseMessageNode.Direct.DOWN_RIGHT,
            arrowType: BaseMessageNode.ArrowType.STRAIGHT,
            arrowPadding: 38,
        };

        var clickMessageNode = this._clickMessageNode = new BaseMessageNode(clickMessageParam);
        clickMessageNode.setPosition(JSScreenMidPos.x + 188, JSScreenMidPos.y + 46);
        clickMessageNode.show();
        this.addChild(clickMessageNode);
    },

    _step3: function () {
        // 泡泡框有出現，要拿掉
        if (this._clickMessageNode) {
            this._clickMessageNode.removeFromParent();
            this._clickMessageNode = undefined;
        }
    },

    _step4: function () {
        // 遮罩消失
        this._clippingNode.setVisible(false);
    },

    _step5: function () {
        // 遮罩出現
        this._clippingNode.setVisible(true);

        // 點擊任一處繼續功能出現
        this._tipBtn.setVisible(true);
        this._dummyTouchLayer.setOnTouchCallback(() => {
            this.createDialogTeachView(6);
        });

        // 進度條遮罩
        var progressBarStencil = new cc.LayerColor(JSColor.WHITE, 274, 36);
        progressBarStencil.setPosition(JSScreenMidPos.x - progressBarStencil.width / 2 + 3, JSScreenMidPos.y - progressBarStencil.height / 2 + 68);
        this._clippingNode.setStencil(progressBarStencil);

        // 訊息
        var messageNode = new cc.Node();
        messageNode.setContentSize(cc.size(82, 35));

        var bigRewardMessageLabel = new cc.LabelTTF(LocalizedString.ContinueRecharge("超級大獎\n等著你哦！"), JSFontName, 12);
        bigRewardMessageLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        bigRewardMessageLabel.setFontFillColor(JSColor.BLACK);
        messageNode.addChild(bigRewardMessageLabel);

        var bigRewardMessageParam = {
            mainNode: messageNode,
            style: BaseMessageNode.Style.WHITE,
            direct: BaseMessageNode.Direct.LEFT,
            arrowType: BaseMessageNode.ArrowType.STRAIGHT,
            arrowPadding: 2,
        };

        // 訊息Node
        var bigRewardMessageNode = this._messageNode = new BaseMessageNode(bigRewardMessageParam);
        bigRewardMessageNode.setPosition(JSScreenMidPos.x + 138, JSScreenMidPos.y + 68);
        bigRewardMessageNode.show();
        this.addChild(bigRewardMessageNode);
    },

    _step6: function () {
        this._finishCallback && this._finishCallback();
        this.removeFromParent();
    }
});