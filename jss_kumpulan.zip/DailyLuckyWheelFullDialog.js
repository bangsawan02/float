/**
 * 每日輪盤主Dialog
 */

var DailyLuckyWheelFullDialog = BaseDialogLayer.extend({
    ctor: function (openPos) {
        this._super();

        // 先設定此Dialog的Key 之後容易砍
        this.key = "DailyLuckyWheelFullDialog";

        // 設定Dialog跳出來的位置
        this.setOpenWorldPosition(openPos || JSScreenMidPos);

        // 轉盤參數
        this._wheelSpeed = 1;                                       // 輪盤轉動初速
        this._targetRotation = 0;                                   // 輪盤目標角度

        // 是否初始化完成
        this._initDone = false;

        this.loadFileArray = ["lobby/lobby_dailyLuckyWheel.plist", "lobby/lobby_dailyLuckyWheel.png"];
    },

    onExit: function () {
        if (this._loadFileDone)
            cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[0]);

        this._super();
    },

    /**
     * 讀取素材完畢
     * @override
     */
    loadFileDone: function () {
        this._super();

        // 一開始就擋loading
        this.addLoadingLayer();

        // 讀取Plist
        cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[0], this.loadFileArray[1]);

        var aniLayer = this._animationLayer;

        // 背景
        var bgSp = new ccui.Scale9Sprite("daily_lucky_wheel_bg_blue.png");
        bgSp.setPreferredSize(JSVisibleSize);
        bgSp.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSp);

        // 光暈
        for (var i = -1; i <= 1; i += 2) {
            // 上下光暈
            var lightSp = new cc.Sprite("#daily_lucky_wheel_pic_light_blue_01.png");
            lightSp.setAnchorPoint(0.5, 1);
            lightSp.setPosition(JSScreenMidPos.x, (i === 1) ? JSVisibleSize.height : 0);
            lightSp.setScaleY(i);
            aniLayer.addChild(lightSp);

            // 左右光暈
            lightSp = new cc.Sprite("#daily_lucky_wheel_pic_light_blue_02.png");
            lightSp.setPosition(JSScreenMidPos.x + ((i === 1) ? 174 : -174), JSScreenMidPos.y);
            lightSp.setScaleX(i);
            aniLayer.addChild(lightSp);
        }

        // 標題
        var titleSp = new cc.Sprite("#daily_lucky_wheel_word_title.png");
        titleSp.setPosition(255 + JSScreenBonusHalfWidth, 256 + JSScreenBonusHalfHeight);
        aniLayer.addChild(titleSp);

        // 裝主要畫面的node
        var mainNode = this._mainNode = new cc.Node();
        aniLayer.addChild(mainNode);

        // 開始要輪盤資料
        DataProcess.sendString("lucky_wheel_info");

        // 加一個防呆server沒回的動畫
        this._addTimeOutAnimation();

        // Add Event
        GS.addListener("NotifyLuckyWheelInfoDone", this.notifyLuckyWheelInfoDone.bind(this), this);
        GS.addListener("NotifyLuckyWheelRunDone", this.notifyLuckyWheelRunDone.bind(this), this);
        GS.addListener("NotifyLuckyWheelCollectClicked", this.notifyLuckyWheelCollectClicked.bind(this), this);
        GS.addListener("NotifyLuckyWheelPushSetDone", this.notifyLuckyWheelPushSetDone.bind(this), this);               // 每日輪盤推播狀態改變
    },

    /**
     * 更新轉輪、VIP、Bonus資訊
     */
    _refreshView: function () {
        this.removeLoadingLayer();

        this.stopActionByTag(9487);

        var wheelData = DataModal.dailyLuckyWheelData;
        if (!wheelData.isInfoSuccess) {
            this._closeDialogAnimation();
            return;
        }

        var wheelString = LocalizedString.DailyLuckyWheel;
        var status = wheelData.rewardStatus;
        var vipBonusList = wheelData.vipBonusList;                          // Vip獎勵倍率陣列
        var isPushNotify = this._isPushNotify = wheelData.isPushNotify;     // 是否推播

        var mainNode = this._mainNode;
        mainNode.removeAllChildren();

        // 裝整個轉盤的Node
        var wheelContainer = this._wheelContainer = new cc.Node();
        wheelContainer.setScale(0.8);
        wheelContainer.setPosition(256 + JSScreenBonusHalfWidth, 127 + JSScreenBonusHalfHeight);
        mainNode.addChild(wheelContainer);

        // 轉盤內容(扇形區)
        var wheelNode = this._wheelNode = new cc.Node();
        wheelNode.setCascadeOpacityEnabled(true);
        wheelContainer.addChild(wheelNode);

        var sliceColorList = [  // 轉輪每一片的顏色
            cc.color(243, 202, 0), cc.color(42, 210, 42), cc.color(230, 23, 127),
            cc.color(51, 119, 255), cc.color(170, 74, 255), cc.color(255, 255, 255)
        ];
        this._wheelLabel = [];

        // 輪盤扇形區
        for (var i = 0; i < 12; i++) {
            var rotation = i * 30;
            var radius = Math.PI / 180 * rotation;

            // 每一個輪盤扇形 是由白底變色後上方疊上陰影
            var sliceItems = ButtonUtility.createSpriteWithSpritesNodes("#daily_lucky_wheel_01.png", "#daily_lucky_wheel_02.png", cc.p(0, 0));
            sliceItems[0].setColor(sliceColorList[i % 6]);
            sliceItems[0].setAnchorPoint(cc.p(0.5, 0));
            sliceItems[0].setRotation(rotation);
            wheelNode.addChild(sliceItems[0]);

            // 輪盤上數字呈現
            var wheelLabel = this._wheelLabel[i] = new GSAutoSizeLabel("", JSFontName, 13, cc.size(150, 0), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
            wheelLabel.enableStroke(JSColor.BLACK, 4);
            wheelLabel.setPosition(Math.sin(radius) * 70, Math.cos(radius) * 70);    // x用sin/y用cos 讓座標系跟扇形一致
            wheelLabel.setRotation(rotation - 90);
            wheelLabel.resizeToFit(26);
            wheelNode.addChild(wheelLabel, 1);
        }

        // 輪盤外框
        for (var i = -1; i <= 1; i += 2) {
            var wheelFrameSp = new cc.Sprite("#daily_lucky_wheel_pic_wheel_01.png");
            wheelFrameSp.setPosition((i === 1) ? cc.p(-61, 0) : cc.p(62, 0));
            wheelFrameSp.setScaleX(i);
            wheelContainer.addChild(wheelFrameSp);
        }

        // 輪盤外圍白燈泡
        for (var i = 0; i < 12; i++) {
            var rotation = i * 30;
            var radius = Math.PI / 180 * rotation;

            var lightSp = new cc.Sprite("#vip_light_02.png");
            lightSp.setPosition(Math.sin(radius) * 117, Math.cos(radius) * 117);
            wheelContainer.addChild(lightSp);
        }

        var bgArr = ["#daily_lucky_wheel_btn_start_01.png", "#daily_lucky_wheel_btn_start_02.png", "#daily_lucky_wheel_btn_start_02.png"];
        // 轉盤spin按鈕
        var itemNodes = ButtonUtility.createSpriteWithSpritesNodes(bgArr, "#daily_lucky_wheel_word_spin.png", cc.p(0, 0));
        itemNodes[1].setColor(JSColor.GRAY);
        itemNodes[2].setColor(JSColor.GRAY);
        var spinBtn = this._spinBtn = new GSControlButton(itemNodes[0]);
        spinBtn.setBackgroundSpriteForState(itemNodes[1], cc.CONTROL_STATE_HIGHLIGHTED);
        spinBtn.setBackgroundSpriteForState(itemNodes[2], cc.CONTROL_STATE_DISABLED);
        spinBtn.setEnabled(false);                                      // 先不給按，輪盤進場動畫結束再判斷點擊。
        spinBtn.addTouchUpInsideAction(this._buttonClick, this);
        wheelContainer.addChild(spinBtn);

        // spin外框
        var spinFrameSp = new cc.Sprite("#daily_lucky_wheel_pic_wheel_02.png");
        wheelContainer.addChild(spinFrameSp);

        // 轉盤上中間的箭頭
        var arrowSprite = new cc.Sprite("#daily_lucky_wheel_pic_pointer.png");
        arrowSprite.setPosition(0, 111);
        wheelContainer.addChild(arrowSprite);

        // 天數倍率顯示區
        var bonusDayNode = new DailyLuckyWheelBonusDayNode(false);
        bonusDayNode.setPosition(84 + JSScreenBonusHalfWidth, 122 + JSScreenBonusHalfHeight);
        mainNode.addChild(bonusDayNode);

        // 建立右下vip區域
        {
            var vipAreaNode = new cc.Node();
            vipAreaNode.setPosition(411 + JSScreenBonusHalfWidth, 52 + JSScreenBonusHalfHeight);
            mainNode.addChild(vipAreaNode);

            // vip 標題圖
            var vipTitleSp = new cc.Sprite("#daily_lucky_wheel_word_VIP_bonus.png");
            vipTitleSp.setPosition(0, 25);
            vipAreaNode.addChild(vipTitleSp);

            // 根據拿到目前Vip狀態改變顯示
            var nowVip = wheelData.nowVip;
            var pos, startIndex, endIndex;
            if (nowVip === 1) {
                // 第一個Vip
                startIndex = 0;
                endIndex = 1;
                pos = cc.p(-15, 0);
            } else if (nowVip === vipBonusList.length) {
                // 最後一個階級
                startIndex = -1;
                endIndex = 0;
                pos = cc.p(-15, 0);
            } else {
                // 在中間的範圍
                startIndex = -1;
                endIndex = 1;
                pos = cc.p(-35, 0);
            }
            // 產生每個VIP圖樣
            for (var i = startIndex; i <= endIndex; i++) {
                var bgImg;
                switch (i) {
                    case -1:
                        bgImg = "#vip_process_bg_1.png";
                        break;
                    case 0:
                        bgImg = "#vip_process_bg_2.png";
                        break;
                    case 1:
                        bgImg = "#vip_process_bg_3.png";
                        break;
                }
                // vip箭頭
                var vipBgSprite = new cc.Sprite(bgImg);
                vipBgSprite.setPosition(pos);
                vipAreaNode.addChild(vipBgSprite);

                // 目前vip綠框 要在最上面給他一個zOrder
                var vipBgFrameSprite = new cc.Sprite("#vip_process_bg_4.png");
                vipBgFrameSprite.setPosition(pos);
                vipBgFrameSprite.setVisible(i === 0);
                vipAreaNode.addChild(vipBgFrameSprite, 1);

                var vip = nowVip + i;
                // VIP文字內容
                var vipLabel = new cc.LabelTTF("VIP " + vip, JSFontName, 8);
                vipLabel.setFontFillColor(JSColor.BLACK);
                vipLabel.setPosition(pos.x, 5);
                vipAreaNode.addChild(vipLabel);

                // VIP獎勵倍率
                var vipBonusLabel = new cc.LabelTTF(vipBonusList[vip - 1] + "x", JSFontName, 8);
                vipBonusLabel.setFontFillColor(JSColor.BLACK);
                vipBonusLabel.setPosition(pos.x, -5);
                vipAreaNode.addChild(vipBonusLabel);

                pos = cc.p(pos.x + 35, 0);
            }
        }

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.setVisible(status !== DailyLuckyWheelData.STATUS.CAN_GET_REWARD);       // 可以領獎直接讓他領獎 不准關閉
        closeBtn.setPosition(JSVisibleSize.width - JSScreenSafeWidth - 27, JSVisibleSize.height - 24);
        closeBtn.addTouchUpInsideAction(this._closeDialogAnimation, this);
        mainNode.addChild(closeBtn);

        // 問號按鈕
        var explainBtn = this._explainBtn = new Texas_ExplainButton(Texas_ExplainButton.Style.TOTAL_BLACK_BIG);
        explainBtn.setPosition(25 + JSScreenSafeWidth, JSVisibleSize.height - 24);
        explainBtn.addTouchUpInsideAction(this._buttonClick, this);
        mainNode.addChild(explainBtn);

        // 手指
        var fingerSp = new cc.Sprite("#lobby_pic_finger.png");
        fingerSp.setPosition(256 + JSScreenBonusHalfWidth, 95 + JSScreenBonusHalfHeight);
        fingerSp.setVisible(false);
        mainNode.addChild(fingerSp);

        // 放切換開關/切換文字的Node
        {
            var switchAutoLayoutNode = new GSAutoLayoutNode();
            switchAutoLayoutNode.setType(GSAutoLayout.TYPE.VERTICAL_LEFT);
            switchAutoLayoutNode.setSpace(2);
            switchAutoLayoutNode.setPosition(46 + JSScreenBonusHalfWidth, 15);
            mainNode.addChild(switchAutoLayoutNode);

            // 輪盤推播開關
            var switchButton = this._switchButton = new SwitchControlButton((sender) => {
                // 鎖住按鈕等cmd回來
                sender.setEnabled(false);

                // 加上loading
                this.addLoadingLayer();

                // 送cmd通知Server開關
                DataProcess.sendString("lucky_wheel_push_set " + (sender.getIsOn() ? "1" : "0"));
            }, this);
            switchButton.setIsOn(isPushNotify);
            switchButton.setSwallowTouches(false);
            switchButton.setTouchDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
            switchAutoLayoutNode.addChild(switchButton);

            var switchLabel = new cc.LabelTTF(wheelString("提醒領獎"), JSFontName, 8);
            switchAutoLayoutNode.addChild(switchLabel);
        }

        // 跑馬燈初始資料列表
        var marqueeList = [
            {
                msg: JSStringUtility.format(wheelString("VIP %d 最高X %d倍唷"), vipBonusList.length, vipBonusList[vipBonusList.length - 1]),
                color: JSColor.YELLOW
            },
            {
                msg: wheelString("連續完成越多天，加倍獎勵越高"),
                color: JSColor.WHITE
            }
        ];
        if (status !== DailyLuckyWheelData.STATUS.GET_REWARD_DONE) {
            // 未達成/達成未領
            marqueeList.unshift({
                msg: wheelString("玩牌一手，SPIN拿獎勵"),
                color: JSColor.WHITE
            });
        }

        // 跑馬燈 看狀態決定文案內容
        var marquee = this._marquee = new MarqueeNode({
            width: 350,
            height: 15,
            sec: 6,
            fontSize: 11,
            isLoop: false,
            disableBG: false
        });
        marquee.setPosition(256 + JSScreenBonusHalfWidth, 13);
        mainNode.addChild(marquee);

        // 跑馬燈輪播
        var marqueeIndex = 0;
        marquee.runAction(cc.repeatForever(cc.sequence(
            cc.callFunc(function () {
                var msgParam = marqueeList[marqueeIndex++];
                marquee.push({
                    message: msgParam.msg,
                    color: msgParam.color
                });
                if (marqueeIndex >= marqueeList.length) marqueeIndex = 0;
            }),
            cc.delayTime(6)   // 換訊息時間
        )));

        // 擋touch
        var dummyTouchLayer = this._dummyTouchLayer = new DummyTouchLayer(JSVisibleSize);
        dummyTouchLayer.setVisible(false);
        mainNode.addChild(dummyTouchLayer);

        // 黑色背景
        var blackBg = this._blackBg = new cc.LayerColor(cc.color(0, 0, 0, 150), JSVisibleSize.width, JSVisibleSize.height);
        blackBg.setVisible(false);
        mainNode.addChild(blackBg);

        // 結算畫面
        var finishNode = this._finishNode = new DailyLuckyWheelFinishNode();
        mainNode.addChild(finishNode, 2);

        // 剛進場的轉盤動畫
        {
            var max = -1;
            var index = -1;
            for (var i = 0; i < 12; i++) {
                // 放上輪盤金額
                var money = wheelData.wheelAwardList[i];
                this._wheelLabel[i].setString(TexasUtility.getSimpleMoneyString(money, 0));

                // 找出最大的的數值(為了讓最大獎在箭頭下面)
                if (money > max) {
                    max = money;
                    index = i;
                }
            }

            // 轉到數字最大的(為了讓最大獎在箭頭下面)
            var rotation = index * -30;
            wheelNode.setRotation(rotation - 150);
            wheelNode.runAction(cc.sequence(
                cc.spawn(
                    cc.fadeIn(0.6),
                    cc.rotateTo(2, rotation)
                ),
                cc.callFunc(() => {
                    // 輪盤進場動畫做完後，判斷spin能不能按。否則跑領獎動畫會有問題
                    if (status !== DailyLuckyWheelData.STATUS.GET_REWARD_DONE) {
                        spinBtn.setEnabled(true);
                        fingerSp.setVisible(true);
                    }
                })
            ));
        }

        // 記下已經完成初始化
        this._initDone = true;

        // 偵測是否換天
        this.scheduleUpdate();
    },

    /**
     * 轉完輪子要做的事情
     */
    _spinWheelDone: function (needAnim = true) {
        this.unschedule("wheelSpinUpdate");

        if (!needAnim) {
            // 設置到目標角度
            this._wheelNode.setRotation(this._targetRotation);
        }

        // 跳出結果Node
        this._finishNode.updateInfo(this._param, needAnim);

        // 拿掉跳過按鈕
        if (this._skipBtn) {
            this._skipBtn.removeFromParent();
            this._skipBtn = undefined;
        }
    },

    /**
     * 偵測換天與否
     */
    update: function (delta) {
        var wheelData = DataModal.dailyLuckyWheelData;
        var wheelString = LocalizedString.DailyLuckyWheel;
        var leftTime = JSCodeUtility.getRemainTime(wheelData.leftTime, wheelData.socketTime);

        if (leftTime === 0) {
            // 跳視窗 更新cmd
            DialogManager.addDialog(new Dialog({
                content: wheelString("已逾期，即將幫您刷新畫面"),
                buttons: ["OK"],
                btnImages: ["lobby_btn_01.png"],
                closeButton: 0,
                callback: (index) => {
                    if (index === 0) {
                        // 卡loading TODO: 要改成新loading
                        GSLoading.addLoadingView();

                        DataProcess.sendString("lucky_wheel_info");
                    }
                }
            }), false, true);
            this.unscheduleUpdate();
        }
    },

    /**
     * 加一個防呆server沒回的動畫
     */
    _addTimeOutAnimation: function () {
        // 防呆15秒server沒回的話關掉畫面
        var action = cc.sequence(
            cc.delayTime(15),
            cc.callFunc(() => {
                // 拿掉loading
                this.removeLoadingLayer();

                // 砍掉說明dialog
                var dialog = DialogManager.getDialogByKey("WebViewDialog");
                if (dialog) {
                    dialog.closeDialogAnimation();
                }

                // 跳忙碌中dialog
                var dialog = new Dialog({
                    content: LocalizedString.Common("目前系統忙碌中\n請稍後再試"),
                    callback: () => {
                        this._closeDialogAnimation();
                    }
                });
                dialog.startDialogAnimation();
                this._animationLayer.addChild(dialog, 10000);
            })
        );
        action.setTag(9487);
        this.runAction(action);
    },

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        // 可以領獎不准關Dialog
        if (DataModal.dailyLuckyWheelData.rewardStatus === DailyLuckyWheelData.STATUS.CAN_GET_REWARD)
            return;

        this._closeDialogAnimation();
    },

    /**
     * 按下按鈕
     */
    _buttonClick: function (sender) {
        var wheelData = DataModal.dailyLuckyWheelData;
        var status = wheelData.rewardStatus;

        switch (sender) {
            case this._spinBtn:
                // 開始spin
                switch (status) {
                    case DailyLuckyWheelData.STATUS.NOT_COMPLETE:
                        // 未完成任務 跳Dialog
                        var wheelString = LocalizedString.DailyLuckyWheel;

                        var quickPlayGame = (GS.nowGame === GSEnum.Game.GapleFriend) ? GSEnum.Game.Gaple : GS.nowGame;
                        var btnMsg = JSStringUtility.format("%s\n(%s)", wheelString("馬上玩"), GSEnum.GameName[quickPlayGame]);

                        DialogManager.addDialog(new Dialog({
                            title: wheelString("尚未完成任務"),
                            content: wheelString("玩牌一手就可以點spin領獎!"),
                            buttons: [btnMsg],
                            callback: (index) => {
                                if (index === 0) {
                                    // 埋點
                                    DataProcess.sendString("track_lucky_wheel_type 1");

                                    // 關掉dialog
                                    this._closeDialogAnimation();

                                    // 導馬上玩
                                    GS.dispatchCustomEvent("NotifyGoQuickPlay");
                                }
                            }
                        }), false);
                        break;
                    case DailyLuckyWheelData.STATUS.CAN_GET_REWARD:
                        // 可以領獎
                        this._spinBtn.setEnabled(false);            // 設定Spin按鈕無法按

                        // 卡loading
                        this.addLoadingLayer();

                        // 取得結果資料
                        DataProcess.sendString("lucky_wheel_run");

                        // 加一個防呆server沒回的動畫
                        this._addTimeOutAnimation();
                        break;
                }
                break;
            case this._explainBtn:
                // 顯示說明頁
                DialogManager.addDialog(new WebViewDialog(TexasUtility.getSimpleInfoURLByKey("lucky_wheel")), false);
                break;
        }
    },

    // 點擊跳過按鈕
    _skipBtnClicked: function () {
        // 埋點
        DataProcess.sendString("track_lucky_wheel_type 2");

        this._spinWheelDone(false);
    },

    // 收到新資料更新畫面
    notifyLuckyWheelInfoDone: function () {
        this._refreshView();
    },

    /**
     * 取得spin後的結果資訊
     */
    notifyLuckyWheelRunDone: function (event) {
        // 還沒初始化完
        if (!this._initDone)
            return;

        // 拿掉loading
        this.removeLoadingLayer();

        this.stopActionByTag(9487);

        var param = this._param = event.getUserData();
        switch (param.error) {
            case 0:
                var index = param.targetIndex;
                this._targetRotation = 360 * 3 + (index * -30) + JSCodeUtility.getRandomInt(-10, 10);

                // 輪盤動畫 把輪盤拉高zOrder 放大
                this._wheelContainer.runAction(cc.sequence(
                    cc.callFunc(() => {
                        this._dummyTouchLayer.setVisible(true);
                        this._blackBg.setVisible(true);
                        this._wheelContainer.setLocalZOrder(1);

                        // 加一個跳過按鈕
                        if (this._skipBtn) {
                            this._skipBtn.removeFromParent();
                            this._skipBtn = undefined;
                        }
                        var skipBtn = this._skipBtn = ButtonUtility.createSimpleButton("lobby_btn_11.png", cc.size(80, 20), LocalizedString.DailyLuckyWheel("跳過"));
                        skipBtn.setPosition(JSVisibleSize.width - JSScreenSafeWidth - 50, 21 + JSScreenBonusHalfHeight);
                        skipBtn.addTouchUpInsideAction(this._skipBtnClicked, this);
                        this._animationLayer.addChild(skipBtn);
                    }),
                    cc.scaleTo(0.6, 1, 1)
                ));

                // 輪盤轉動動畫
                this.schedule((delta) => {
                    var tmpSpeed = 0;
                    var targetRotation = this._targetRotation;

                    // 最後一圈開始減速
                    if (this._wheelNode.getRotation() > (targetRotation - 360)) {
                        // 最近的rotation
                        var curRotation = this._wheelNode.getRotation();

                        // 利用rotation來控制速度
                        tmpSpeed = (targetRotation - curRotation) * delta;

                        // 防止最後轉的時候太慢
                        if (tmpSpeed < 0.07) {
                            tmpSpeed = 0.07;
                        }

                        var nowRotation = curRotation + tmpSpeed;

                        // 防呆 避免轉盤轉不停
                        if (nowRotation >= targetRotation)
                            nowRotation = targetRotation;

                        // 設置rotation
                        this._wheelNode.setRotation(nowRotation);

                        // 到達目標角度
                        if (Math.abs(nowRotation - targetRotation) < 0.1) {
                            this._spinWheelDone(true);
                        }
                    } else {
                        // 一開始的加速度
                        tmpSpeed = (this._wheelSpeed *= 1.05);

                        // 設置速度上限
                        if (tmpSpeed >= 10)
                            tmpSpeed = 10;

                        var rotation = Math.floor(this._wheelNode.getRotation()) + Math.floor(tmpSpeed);
                        this._wheelNode.setRotation(rotation);
                    }
                }, 0, cc.REPEAT_FOREVER, 1, "wheelSpinUpdate");
                break;
            case 1:
                // 發生錯誤
                var dialog = new Dialog({
                    title: LocalizedString.Common("提醒"),
                    content: LocalizedString.Common("系統忙碌中，請稍後再試！"),
                    buttons: [LocalizedString.Common("確認")],
                    closeButton: false,
                    callback: (index) => {
                        if (index === 0) {
                            // 重要資料 可能正常領獎但server回傳error 導致卡在Dialog出不去
                            this.addLoadingLayer();
                            DataProcess.sendString("lucky_wheel_info");
                        }
                    }
                });
                dialog.startDialogAnimation();
                this._animationLayer.addChild(dialog, 10000);
                break;
        }
    },

    // 用來處理領獎要做的事(噴錢動畫)
    notifyLuckyWheelCollectClicked: function (event) {
        // 是否從教學頁來的
        var isTeach = event.getUserData();

        // 金幣飛向UI動畫
        GS.dispatchCustomEvent("NotifyPlayMoneyAnimation", {
            fromPos: cc.p(JSScreenBonusHalfWidth + 400, JSScreenBonusHalfHeight + 36),
            toPos: cc.p(130, JSVisibleSize.height - 35)
        });

        // 結束關閉視窗並飛錢
        this.runAction(cc.sequence(
            cc.delayTime(1),
            cc.callFunc(() => {
                if (isTeach)
                    // 從教學頁關閉引導馬上玩
                    GS.dispatchCustomEvent("NotifyGoQuickPlay");

                this._closeDialogAnimation();
            })
        ));
    },

    // 每日輪盤推播狀態改變
    notifyLuckyWheelPushSetDone: function (event) {
        this.removeLoadingLayer();

        var param = event.getUserData();
        if (!param)
            return;

        var success = param.success;

        // 修改開關狀態
        this._isPushNotify = success ? param.isPushNotify : this._isPushNotify;
        if (this._switchButton) {
            this._switchButton.setEnabled(true);
            this._switchButton.setIsOn(this._isPushNotify);
        }

        // 顯示提示Dialog
        var dialog = new AvatarDialog({
            content: LocalizedString.Common(success ? "修改成功" : "修改錯誤，請稍候再試"),  // 內文
            buttons: ["OK"]                                                             // 按鈕的文字
        });
        dialog.startDialogAnimation();
        this._animationLayer.addChild(dialog, 10000);
    }
});
