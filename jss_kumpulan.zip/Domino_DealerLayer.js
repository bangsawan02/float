var Domino_DealerLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        this.addChild(menu);

        // 荷官按鈕
        if (GS.useSpineDealer) {
            // 預設
            var spineArray = [
                "spine/dealer_12033.json",
                "spine/dealer_12033.atlas",
                "spine/dealer_12033.png"
            ];

            // 開齋2023的主題
            if (GS.theme === GSEnum.Theme.LEBARAN2023) {
                spineArray = [
                    "spine/dealer_12051.json",
                    "spine/dealer_12051.atlas",
                    "spine/dealer_12051.png"
                ];
            }

            var avatarNode = new cc.Node();
            this.addChild(avatarNode);
            var addSpineAvatar = function () {
                var avatar = new sp.SkeletonAnimation(spineArray[0], spineArray[1], 0.25);
                avatar.setPosition(JSScreenMidPos.x, 253 + JSScreenBonusHalfHeight);
                avatar.setAnimation(0, 'animation', true);
                avatar.setScale(0.5);
                avatarNode.addChild(avatar);
            };
            if (!cc.sys.isNative) {
                // H5要先去讀
                cc.loader.load(spineArray, function (a, b) {
                    addSpineAvatar();
                });
            } else {
                // 原生不用讀
                addSpineAvatar();
            }
        } else {
            var dealerIndex = 7;
            var dealerString = Domino_GameUtility.getDealerImage(dealerIndex);
            var spriteArray = ButtonUtility.createBtnSpriteArray(dealerString, dealerString);
            var dealerMenuItem = this._dealerBtn = new cc.MenuItemSprite(spriteArray[0], spriteArray[1], this._dealerBtnClicked, this);
            dealerMenuItem.setPosition(JSScreenMidPos.x, 251 + JSScreenBonusHalfHeight);
            dealerMenuItem.setEnabled(false);           // 先關掉 之後在打開
            menu.addChild(dealerMenuItem);
        }

        //小費
        var tipsNode = this._tipsNode = new Domino_TipsNode();
        tipsNode.setPosition(JSScreenMidPos.x, 209 + JSScreenBonusHalfHeight);
        this.addChild(tipsNode);

        //重設按鈕位置
        this.resetButtonPosition();
    },

    /**
     * 按到荷官
     * @private
     */
    _dealerBtnClicked: function () {
        //TODO 加換荷官Dialog
    },

    /**
     * 重設按鈕位置
     */
    resetButtonPosition: function () {
        // 現在無此功能
        return;

        //用是否visible來判斷是否開啟此功能
        var nodeArray = [];

        //小費
        if (this._tipsNode.isVisible())
            nodeArray.push(this._tipsNode);

        //牌型預測
        if (this._cardForecastNode.isVisible())
            nodeArray.push(this._cardForecastNode);

        if (nodeArray.length == 1) {
            nodeArray[0].setPosition(JSScreenMidPos.x, 222 + JSScreenBonusHalfHeight);
        } else {
            for (var i = 0; i < nodeArray.length; i++) {
                nodeArray[i].setPosition(JSScreenMidPos.x - 26 + (i * 52), 222 + JSScreenBonusHalfHeight);
            }
        }
    },

    /**
     * 荷官的對話框
     * @param 荷官的說話內容
     */
    dealerMsg: function (message, money) {
        // 荷官右邊的訊息
        var messageLabel = new cc.LabelTTF(message, JSFontBoldName, 10, cc.size(196, 0), cc.TEXT_ALIGNMENT_LEFT, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        messageLabel.setFontFillColor(JSColor.BLACK);

        var param = {
            mainNode: messageLabel,
            style: BaseMessageNode.Style.GOLD,
            direct: BaseMessageNode.Direct.LEFT,
            arrowType: BaseMessageNode.ArrowType.SLANT,
            isFlip: false,
            arrowPadding: 0,
        };

        var msgNode = new BaseMessageNode(param);
        msgNode.setPosition(JSScreenMidPos.x + 16, 260 + JSScreenBonusHalfHeight);
        msgNode.show(2, true);
        this.addChild(msgNode);

        var self = this;
        this.runAction(cc.sequence(
            cc.delayTime(2),
            cc.callFunc(() => {
                // 這邊要先判斷是否原本就看不到
                if (this._tipsNode.getNowStatus() !== Domino_TipsBtnStatus.CLOSE) {
                    this._tipsNode.setTipsStatus(Domino_TipsBtnStatus.NORMAL);
                }
            })
        ));

        // 往上的金錢
        if (money !== undefined) {
            var chipsNode = new cc.Node();
            chipsNode.setCascadeOpacityEnabled(true);
            chipsNode.setPosition(JSScreenMidPos.x, JSScreenBonusHalfHeight + 220);
            chipsNode.setOpacity(0);
            this.addChild(chipsNode);

            var numberString = TexasUtility.getSimpleMoneyString(money);
            var numberArray = [];
            var totalWidth = 0;
            for (var i = 0, len = numberString.length; i < len; i++) {
                var numberChar = numberString[i];
                if (isNaN(numberChar)) {
                    // 不是數字 要判斷是不是小數點
                    if (numberChar === ".") {
                        var dotSprite = new cc.Sprite("#game_number_point.png");
                        dotSprite.setPosition(totalWidth - 3, 0);
                        chipsNode.addChild(dotSprite);

                        totalWidth += 4;

                        numberArray.push(dotSprite);
                    } else {
                        // 代表是最後的文字
                        var wordString = numberString.substr(i, len - i);
                        var wordSprite = new cc.Sprite(JSStringUtility.format("#game_number_%s.png", wordString));
                        wordSprite.setAnchorPoint(0, 0.5);
                        wordSprite.setPosition(totalWidth - 7, 0);
                        chipsNode.addChild(wordSprite);

                        // 要扣掉之前加的數字寬
                        totalWidth += wordSprite.getContentSize().width - 16;

                        numberArray.push(wordSprite);
                        break;
                    }
                } else {
                    // 數字 直接創
                    var numberSprite = new cc.Sprite(JSStringUtility.format("#game_number_%s.png", numberChar));
                    numberSprite.setPosition(totalWidth, 0);
                    chipsNode.addChild(numberSprite);

                    totalWidth += 10;

                    numberArray.push(numberSprite);
                }
            }

            // 重新排序
            var offsetX = totalWidth / 2;
            numberArray.forEach(function (cur) {
                cur.setPositionX(cur.getPositionX() - offsetX);
            });

            chipsNode.runAction(cc.moveBy(1, cc.p(0, 20)));
            chipsNode.runAction(cc.sequence(
                cc.fadeIn(0.2),
                cc.delayTime(0.8),
                cc.fadeOut(0.2),
                cc.removeSelf()
            ));
        }
    },

    /**
     * 檢查可不可以送小費
     */
    _checkCanTip: function () {
        var gameData = DataModal.gameData;
        var selfData = gameData.getMyPlayerData();
        if (selfData && selfData.tableChips > gameData.anteValue)
            this._tipsNode.setTipsStatus(Domino_TipsBtnStatus.NORMAL);
        else
            this._tipsNode.setTipsStatus(Domino_TipsBtnStatus.CLOSE);
    },

    /**
     * 自己坐下了
     */
    setSit: function () {
        this._tipsNode.setVisible(true);
        this._tipsNode.setTipsStatus(Domino_TipsBtnStatus.INIT);
        this.resetButtonPosition();
    },

    /**
     * 自己站起了
     */
    setStand: function () {
        // 把小費按鈕拿掉
        this._tipsNode.setVisible(false);
    },

    /**
     * 自己棄牌了
     */
    setFold: function () {
        // 判斷玩家當下身上是否有錢可以送小費
        this._checkCanTip();

        // 重設按鈕位置
        this.resetButtonPosition();
    },

    /**
     * 座位更新
     */
    cmd_updateSeat: function () {
        // 判斷玩家當下身上是否有錢可以送小費
        this._checkCanTip();
    },

    /**
     * 新局開始
     */
    cmd_OLEH: function () {
        this._tipsNode.setTipsStatus(Domino_TipsBtnStatus.INIT);
        this.resetButtonPosition();
    },

    /**
     * 玩家跟注
     * @param {value} socket傳的值
     */
    cmd_plcall: function (value) {
        var jsonArray = value.split(" ");
        var serverSitNum = JSCodeUtility.getIntValue(jsonArray[0]);
        var chips = JSCodeUtility.getIntValue(jsonArray[1]);

        // 玩家沒錢了，關閉小費按鈕
        var playerData = DataModal.gameData.playerDataArray[serverSitNum];
        if (playerData.tableChips < chips && playerData.getIsSelf()) {
            this._tipsNode.setTipsStatus(Domino_TipsBtnStatus.CLOSE);
            this.resetButtonPosition();
        }
    },

    /**
     * 玩家加注
     * @param {value} socket傳的值
     */
    cmd_plraise: function (value) {
        this.cmd_plcall(value);
    },

    /**
     * 沒比牌，僅剩一家未棄牌時才會出現
     */
    cmd_noshowdown: function (value) {
        // 如果是玩家本人贏設成分紅
        var valueArray = value.split(" ");
        var serverSitNum = JSCodeUtility.getIntValue(valueArray[0]);    //分給幾號玩家
        if (serverSitNum == DataModal.gameData.myPos)
            this._tipsNode.setTipsStatus(Domino_TipsBtnStatus.FINAL);

        this.resetButtonPosition();
    },

    /**
     * 比牌後結果
     */
    cmd_showdown: function (jsonValue) {
        // {"winList":[{"ct":0,"pos":"0","chip":740,"currchips":20340}],"poolIndex":0}
        var winLen = jsonValue.winList.length;

        //平手 小費按扭消失
        if (winLen > 1) {
            this._tipsNode.setTipsStatus(Domino_TipsBtnStatus.CLOSE);
        } else if (winLen == 1) {
            var serverSitNum = parseInt(jsonValue.winList[0].pos);
            if (serverSitNum === DataModal.gameData.myPos) {
                this._tipsNode.setTipsStatus(Domino_TipsBtnStatus.FINAL);
            }
        }

        this.resetButtonPosition();
    },

    /**
     * 比牌結果說明視窗
     */
    cmd_fianlMsg: function (value) {
        var richText = new GSRichTextNode(value, JSFontBoldName, 9);

        // 主Node
        var mainNode = new cc.Node();
        mainNode.setCascadeOpacityEnabled(true);
        mainNode.setPosition(JSScreenMidPos.x, 152 + JSScreenBonusHalfHeight);
        this.addChild(mainNode);

        // 背景
        var bgSprite = new ccui.Scale9Sprite("domino_info_bg.png");
        bgSprite.setPreferredSize(cc.size(richText.getContentSize().width + 30, 30));
        bgSprite.setOpacity(200);
        mainNode.addChild(bgSprite);

        // 文字
        mainNode.addChild(richText);

        // 動畫
        mainNode.setOpacity(0);
        mainNode.runAction(cc.sequence(
            cc.fadeIn(0.3),
            cc.delayTime(3),
            cc.fadeOut(0.3),
            cc.removeSelf()
        ));
    },

    /**
     * 判斷玩家當下身上是否有錢，如果小費按鈕是關閉的就要再打開
     */
    cmd_updateChips: function () {
        // 判斷玩家當下身上是否有錢可以送小費
        this._checkCanTip();
    },
});