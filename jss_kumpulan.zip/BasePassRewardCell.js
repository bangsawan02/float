/**
 * 通行證：獎勵畫面單一個 cell template (包含上下兩個獎項)
 *
 * Sample config: {
 *     isHaveCycleReward: false,                // 是否開啟循環獎勵功能
 * }
 */
var BasePassRewardCell = cc.TableViewCell.extend({
    ctor: function (config) {
        this._super();

        let isHaveCycleReward = this._isHaveCycleReward = config.isHaveCycleReward;

        this._normalCellNode = new BasePassNormalRewardCellNode(config);
        this.addChild(this._normalCellNode);

        if (isHaveCycleReward) {
            this._cycleCellNode = new BasePassCycleRewardCellNode(config);
            this._cycleCellNode.setVisible(false);
            this.addChild(this._cycleCellNode);
        }
    },

    /**
     * 更新 cell
     * @param {object}  stageParam          階段獎勵資料
     * @param {int}     currentTokenCount   目前擁有的代幣數量
     */
    refreshCell: function (stageParam, currentTokenCount) {
        this._normalCellNode.setVisible(true);
        this._cycleCellNode && this._cycleCellNode.setVisible(false);
        this._normalCellNode.refreshView(stageParam, currentTokenCount);
    },

    /**
     * 更新循環獎勵的 cell
     * @param {boolean} isInCycleReward         進度是否已到循環獎勵
     * @param {int}     currentCycleTokenCount  目前循環代幣數量
     * @param {int}     goalTokenCount          目標代幣數量
     */
    refreshCycleCell: function (isInCycleReward, currentCycleTokenCount, goalTokenCount) {
        if (!this._isHaveCycleReward || !this._cycleCellNode) {
            return;
        }
        this._normalCellNode.setVisible(false);
        this._cycleCellNode.setVisible(true);
        this._cycleCellNode.refreshView(isInCycleReward, currentCycleTokenCount, goalTokenCount);
    },

    /**
     * 取得普通獎勵 Cell
     * @returns {BasePassNormalRewardCellNode}
     */
    getNormalCell: function () {
        return this._normalCellNode;
    },

    /**
     * 取得循環獎勵 Cell
     * @returns {BasePassCycleRewardCellNode}
     */
    getCycleCell: function () {
        return this._cycleCellNode;
    },

    /**
     * 取得循環獎勵 Node
     * @returns {*}
     */
    getCycleRewardNode: function () {
        return this._cycleCellNode.getRewardNode();
    },

    /**
     * 是否跳過進度條動畫
     * @param {boolean} isSkipped
     */
    setSkipped: function (isSkipped) {
        this._cycleCellNode && this._cycleCellNode.setSkipped(isSkipped);
    },

    /**
     * 表演解鎖動畫
     * @param {number|number[]} [passTypes] 指定要播放解鎖動畫的通行證層級
     */
    playUnlockAnimation: function (passTypes) {
        this._normalCellNode.playUnlockAnimation(passTypes);
    },

    /**
     * 表演星星進度條
     * @param {int}         addTokenCount   增加的代幣數量
     * @param {int}         goalTokenCount  目標的代幣數量
     * @returns {Promise<void>}
     */
    playProgressAnimationAsync: function (addTokenCount, goalTokenCount) {
        return new Promise((resolve, reject) => {
            if (this.__isDestroyed) {
                return true;
            }
            if (this._cycleCellNode) {
                this._cycleCellNode.playProgressAnimationAsync(addTokenCount, goalTokenCount)
                    .then(() => resolve())
                    .catch(() => reject());
            } else {
                resolve();
            }
        });
    },
});

BasePassRewardCell.NormalRewardCellSize = cc.size(85, 170);
BasePassRewardCell.CycleRewardCellSize = cc.size(260, 178);