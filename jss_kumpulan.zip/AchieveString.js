var LocalizedString = LocalizedString || {};

(function () {
    var keyValue = {
        "每日": "Harian",
        "一般": "Reguler",
        "偉大": "Notable",
        "活動": "Misi",
        "獎勵：": "Prizes:",
        "領獎": "Ambil",
        "稱號": "Titel",
        "德撲幣": "Chips",
        "物品": "Item",
        "勳章": "Lencana",
        "表情": "Mood",
        "完成": "Selesai",
        "活動結束": "Tutup",
        "完成度": "Selesai"
    };

    LocalizedString.Achieve = function (str) {
        return USE_i18n ? (keyValue[str] || str) : str;
    };
})();
