/**
 * Friend的資料
 */

var FriendData = cc.Class.extend({
    ctor: function () {

        this.clean();

        // 註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            // 好友
            "mixFriend_get_list": this.cmd_mixFriend_get_list,
            // "get_friend_fb_list": this.cmd_get_friend_fb_list, // 5.6.2先拔除掉fb功能
            "user_get_friends_num": this.cmd_user_get_friends_num,
            "mixFriend_find_list": this.cmd_mixFriend_find_list,
            "mixFriend_find_userid": this.cmd_mixFriend_find_list,
            "user_invite_friend": this.cmd_user_invite_friend,
            "user_get_friends_verify_list": this.cmd_user_get_friends_verify_list,

            // 邀請好友
            "mixFriend_isPlaying_list": this.cmd_mixFriend_isPlaying_list,
            "area_friends_invitation": this.cmd_invitation,
            "invitation": this.cmd_invitation,
            "join_friend_room": this.cmd_join_friend_room,
            "invitation_dialog": this.cmd_invitation_result,
            "dialog": this.cmd_invitation_result,
            "all_invitation": this.cmd_all_invitation,

            // 好友桌內提示
            "online_notify": this.cmd_online_notify,
            "user_friends_invitation": this.cmd_user_friends_invitation
        });
    },

    clean: function () {
        // 好友清單
        this.friendList = [];
        // 搜尋好友清單
        this.findFriendList = [];
        // 好友申請清單
        this.applyFriendList = [];
        // 好友申請的uid清單(用來比較有沒有心的好友申請)
        this.applyUIDList = [];

        // 申請列表&好友icon是否要show小紅點
        this.redPoint = {
            icon: false,    // 大廳icon
            apply: false   // 申請列表
        };

        // 好友是否已達上限
        this.isFriendLimit = false;
        // 是否還有好友資料可以load
        this.isCanLoadFriend = false;

        this.isPlayingFriendParam = null;

        // 目前跟server要的好友頁數(1頁10筆)
        this.friendListPage = 0;
        // 好友的最大數量
        this.friendLimit = 0;
        // 目前好友數量
        this.friendCount = 0;

        // 邀請類型
        this.joinType = FriendData.joinType.None;
    },

    /**
     * 送好友申請清單
     */
    startGetInfo: function () {
        // 取得好友申請列表 這個要先送是因為要判斷大廳icon要不要show小紅點
        DataProcess.sendString("user_get_friends_verify_list");
    },

    /**
     * 送好友清單
     * @param page 頁數
     */
    sendFriendListCmd: function (page) {
        this.friendListPage = page;
        var obj = {
            page: page + 1
        };
        DataProcess.sendString("mixFriend_get_list " + JSON.stringify(obj));
        DataProcess.sendString("user_get_friends_num");
    },

    sendJoinCmd: function (type, param) {
        // 記下type收到回覆要用
        this.joinType = type;

        // 通知server
        DataProcess.sendString(JSStringUtility.format("join_friend_room %s", param));
    },

    /**
     * 根據搜尋字串，找出自己好友帳號符合的
     * @param searchStr 搜尋字串
     */
    getSearchFriendList: function (searchStr) {
        var resultList = [];

        // 忽略大小寫
        var searchStr = searchStr.toUpperCase();
        this.friendList.forEach((cur) => {
            // 找到從字首符合的結果
            if ((cur.userID).toUpperCase().indexOf(searchStr) >= 0) {
                resultList.push(cur);
            }
        });

        return resultList;
    },

    /**
     * 確認暱稱長度 超過預設字母會以...顯示
     * @param nickname  暱稱
     * @param maxCount  預設12個字母
     */
    _checkNickname: function (nickname, maxCount = 12) {
        return (nickname.length > maxCount) ? nickname.substring(0, maxCount) + "..." : nickname;
    },

    /**
     * 確認最後上線的時間
     * @param time
     */
    _checkLastOnlineTime: function (time) {
        var str = "";
        var friendStr = LocalizedString.Friend;

        if (time === -1)
            return friendStr("在線上");

        var now = new Date().getTime() / 1000;
        var lastTime = now - time;

        if (lastTime < 60)
            // 1分鐘內
            str = "離線1分鐘";
        else if (lastTime < 3600 && lastTime > 60) {
            // 1小時內
            lastTime = lastTime / 60;
            str = "離線%d分鐘";
        } else if (lastTime < 86400 && lastTime > 3600) {
            // 24小時內
            str = "離線%d小時";
            lastTime = lastTime / 3600;
        } else if (lastTime > 86400 && lastTime < 86400 * 7) {
            // 7天內
            str = "離線%d天";
            lastTime = lastTime / 86400;
        } else if (lastTime > 86400 * 7) {
            // 7天以上
            str = friendStr("離線");
        }

        return JSStringUtility.format(friendStr(str), lastTime);
    },

    /**
     * 確認需要更新的清單
     */
    _changeFriendList: function (param) {
        var userID = param.userID;
        switch (param.type) {
            case 1:
                // 推薦名單or搜尋結果 加入好友

                // 重要確認清單
                DataProcess.sendString("user_get_friends_verify_list");

                // 重要推薦名單
                DataProcess.sendString("mixFriend_find_list");

                // 刷新好友清單
                this.sendFriendListCmd(0);
                break;
            case 2:
            case 3:
                // 2: 同意申請列表加入好友
                // 3: 拒絕申請列表加入好友

                // 重要推薦名單
                DataProcess.sendString("mixFriend_find_list");

                // 更新申請好友清單
                this.applyFriendList.some((cur, index) => {
                    if (cur.userID === userID) {
                        this.applyFriendList.splice(index, 1);
                        this.applyUIDList.splice(index, 1);
                        return true;
                    }
                });

                // 沒有申請好友 關掉小紅點
                if (this.applyFriendList.length === 0)
                    this.redPoint.apply = false;

                // 同意好友需要重要好友清單
                if (param.type === 2)
                    this.sendFriendListCmd(0);

                break;
            case 5:
                // 刪除好友

                this.sendFriendListCmd(0);
                break;
        }
    },

    /**
     * C -> S mixFriend_get_list {"page":1} # page1(第1~10筆資料) 2(第11~20筆資料)
     * S -> C mixFriend_get_list            # 取得好友列表(每次給10筆)
     * [{
     *      # 在線上的玩家
     *      "nickname":"s00677925",
     *      "uid":"13559464",
     *      "userid":"s00677925@an",
     *      "isPlaying":"1",            # 0不在遊戲中 1遊戲中
     *      "last_time":"-1",           #  -1 在線上 unixtime 上次在線時間
     *      "pic":"http://d.mwsrv.com/texas9/images/default_pic/photo_m-1.png",
     *      "join":{
     *          "room_id":"A41305",
     *          "no_chips":"0",         # no_chips 1跳出沒錢dialog，0可以入桌
     *          "code":"1",
     *          "fee":"500000",
     *          "button":"1"}},         # isPlaying是1才會有=>button 1顯示按鈕，0不顯示，
     *  {
     *      # 離線的玩家
     *      "userid":"u46232252@an",
     *      "isPlaying":"0",
     *      "uid":"14278382",
     *      "nickname":"u46232252",
     *      "pic":"http://d.mwsrv.com/texas9/images/default_pic/photo_m-3.png",
     *      "last_time":"1581489724"}]
     */
    cmd_mixFriend_get_list: function (key, value) {
        var jsonValue = JSON.parse(value);

        // 重要第一頁好友要先清空列表
        if (this.friendListPage === 0)
            this.friendList = [];

        this.friendListPage++;

        jsonValue.forEach(cur => {
            var friendInfo = {};

            // nickname
            friendInfo.nickname = JSCodeUtility.getDecodeStringValue(cur["nickname"]);

            // 簡化的nickname
            friendInfo.shortenNickname = this._checkNickname(friendInfo.nickname);

            // userID
            friendInfo.userID = JSCodeUtility.getStringValue(cur["userid"]);

            // uid
            friendInfo.UID = JSCodeUtility.getStringValue(cur["uid"]);

            // 0:不在遊戲 1:在遊戲內
            friendInfo.isPlaying = JSCodeUtility.getIntValue(cur["isPlaying"]);

            // 最後上線時間 #-1 在線上 unixtime 上次在線時間
            var lastTime = JSCodeUtility.getIntValue(cur["last_time"]);
            friendInfo.lastOnline = this._checkLastOnlineTime(lastTime);

            // 是否在線上
            friendInfo.isOnline = lastTime === -1;

            // 大頭貼
            friendInfo.photo = JSCodeUtility.getStringValue(cur["pic"]);

            // join按鈕
            var jValue = cur["join"];
            if (jValue) {
                // 遊戲 Texas: 38, Gaple: 98, Domino: 99, Remi:97
                // LuxyPoker只放Texas的 Domino全放
                var gameType = JSCodeUtility.getIntValue(jValue["game"]);
                if (!GS.isLuxyPoker || (GS.isLuxyPoker && gameType === 38)) {
                    friendInfo.join = {
                        // 遊戲 Texas: 38, Gaple: 98, Domino: 99
                        game: JSCodeUtility.getIntValue(jValue["game"]),

                        // 房間ID
                        roomID: JSCodeUtility.getStringValue(jValue["room_id"]),

                        code: JSCodeUtility.getIntValue(jValue["code"]),

                        // 牌桌費用
                        fee: JSCodeUtility.getIntValue(jValue["fee"]),

                        // 底台資訊
                        feeMsg: JSCodeUtility.getStringValue(jValue["feeMsg"]),

                        // isPlaying是1才會有=>button 1顯示按鈕，0不顯示，
                        button: JSCodeUtility.getBooleanValue(jValue["button"])
                    };
                }
            }

            this.friendList.push(friendInfo);
        });

        // 有沒有資料
        var noData = jsonValue.length === 0;

        // 是否還有好友資料可以load(這一次資料是空的就代表server後面沒有資料了)
        this.isCanLoadFriend = this.friendList.length < this.friendCount && !noData;

        GS.dispatchCustomEvent("NotifyFriendListDone");
    },

    /**
     *  取得FB好友
     */
    cmd_get_friend_fb_list: function (key, value) {
        var jsonValue = JSON.parse(value);

        var success = JSCodeUtility.getIntValue(jsonValue["code"]) === 1;
        if (success)
            // 取得fb好友 重新確認新的好友列表
            this.sendFriendListCmd(0);
    },

    /**
     *  取得目前好友人數
     *  C -> S user_get_friends_num
     *  S -> C user_get_friends_num
     *  {
     *      "fb_friends_num":"0",   # 目前fb好友數量
     *      "friends_limit":"200",  # 好友上限（不包含FB好友）
     *      "friends_num":"1"       # 目前好友數量(不包含fb好友數量)
     *   }
     */
    cmd_user_get_friends_num: function (key, value) {
        var jsonValue = JSON.parse(value);

        // 目前好友數量(含fb好友數量)
        var friendCount = JSCodeUtility.getIntValue(jsonValue["friends_num"]);

        // 目前fb好友數量
        var fbFriendCount = JSCodeUtility.getIntValue(jsonValue["fb_friends_num"]);

        // 好友上限（不包含FB好友）
        var friendLimit = JSCodeUtility.getIntValue(jsonValue["friends_limit"]);

        // 好友上限（一般好友上限+FB好友）
        this.friendLimit = friendLimit + fbFriendCount;

        // 好友數量
        this.friendCount = friendCount;

        // 好友是否已達上限
        this.isFriendLimit = this.friendCount >= this.friendLimit;

        // 是否還有好友資料可以load
        this.isCanLoadFriend = this.friendList.length < this.friendCount;

        GS.dispatchCustomEvent("NotifyUpdateFriendListCount");
    },

    /**
     *  最近玩過列表 / 搜尋結果
     *  [{
     *      "nickname":"u46232252",
        "isPlaying":"1",
        "join":{"fee":"250000","code":"1","no_chips":"0","button":"1","room_id":"A65366"},
        "userid":"u46232252@an",
        "pic":"http://d.mwsrv.com/texas9/images/default_pic/photo_m-3.png",
        "uid":"14278382",
        "last_time":"-1"}]
     */
    cmd_mixFriend_find_list: function (key, value) {
        var jsonValue = JSON.parse(value);

        this.findFriendList = [];

        jsonValue.forEach(cur => {
            var friendInfo = {};

            // nickname
            friendInfo.nickname = JSCodeUtility.getDecodeStringValue(cur["nickname"]);

            // 簡化的nickname
            friendInfo.shortenNickname = this._checkNickname(friendInfo.nickname);

            // userID
            friendInfo.userID = JSCodeUtility.getStringValue(cur["userid"]);

            // uid
            friendInfo.UID = JSCodeUtility.getStringValue(cur["uid"]);

            // 0:不在遊戲 1:在遊戲內
            friendInfo.isPlaying = JSCodeUtility.getIntValue(cur["isPlaying"]);

            // 最後上線時間 #-1 在線上 unixtime 上次在線時間
            var lastTime = JSCodeUtility.getIntValue(cur["last_time"]);
            friendInfo.lastOnline = this._checkLastOnlineTime(lastTime);

            // 是否在線上
            friendInfo.isOnline = lastTime === -1;

            // 大頭貼
            friendInfo.photo = JSCodeUtility.getStringValue(cur["pic"]);

            // join按鈕
            var jValue = cur["join"];
            if (jValue) {
                // 遊戲 Texas: 38, Gaple: 98, Domino: 99, Remi:97
                // LuxyPoker只放Texas的 Domino全放
                var gameType = JSCodeUtility.getIntValue(jValue["game"]);
                if (!GS.isLuxyPoker || (GS.isLuxyPoker && gameType === 38)) {
                    friendInfo.join = {
                        game: gameType,

                        // 房間ID
                        roomID: JSCodeUtility.getStringValue(jValue["room_id"]),

                        code: JSCodeUtility.getIntValue(jValue["code"]),

                        // 牌桌費用
                        fee: JSCodeUtility.getIntValue(jValue["fee"]),

                        // 底台資訊
                        feeMsg: JSCodeUtility.getStringValue(jValue["feeMsg"]),

                        // isPlaying是1才會有=>button 1顯示按鈕，0不顯示，
                        button: JSCodeUtility.getIntValue(jValue["button"]) === 1
                    };
                }
            }

            this.findFriendList.push(friendInfo);
        });

        GS.dispatchCustomEvent("NotifyFindFriendListDone");
    },

    /**
     *  邀請/同意/拒絕/刪除好友
     *
     *  # 邀請好友
     *  C -> S user_invite_friend
     *  {
     *      "from":3,   #from 1:個人資訊 2:推薦好友 3:搜尋好友 4:桌內邀請 5:FB加入
     *      "type":1,   #type 1:邀請好友 2:同意邀請 3:拒絕 4:FB加入好友 5:刪除好友
     *      "userid":"s00677925@an"
     *  } #ex:搜尋好友邀請 from一定要帶
     *  S -> C user_invite_friend
     *  {
     *      "nickname":"s00677925",
     *      "type":"1",
     *      "userid":"s00677925@an",
     *      "code":"1"  #code:0 不成功 code:1 成功
     *  }
     *
     *  # 刪除好友
     *  C -> S user_invite_friend {"type":"5","userid":"s00677925@an"}
     *  S -> C user_invite_friend {"userid":"s00677925@an","nickname":"s00677925","code":"1","type":"5"}
     */
    cmd_user_invite_friend: function (key, value) {
        var jsonValue = JSON.parse(value);

        var param = {};
        var isSuccess = param.isSuccess = JSCodeUtility.getIntValue(jsonValue["code"]) === 1;

        param.userID = JSCodeUtility.getStringValue(jsonValue["userid"]);

        param.nickname = JSCodeUtility.getDecodeStringValue(jsonValue["nickname"]);

        param.photo = JSCodeUtility.getStringValue(jsonValue["pic"]);

        // type 1:邀請好友 2:同意邀請 3:拒絕 4:FB加入好友 5:刪除好友
        param.type = JSCodeUtility.getIntValue(jsonValue["type"]);

        if (isSuccess) {
            this._changeFriendList(param);

            // AppsFlyer 牌局中曾使用邀請好友入同一桌功能
            GameAppsFlyerTracker.trackByGameName("invite_friend_intable");

            // Firebase 埋點
            var eventName = GSAnalyticsAdapter.record.game + "遊戲行為";
            GSAnalyticsAdapter.logEventByFirebaseAll(eventName, ["大廳"], ["成功加好友次數"]);
        }

        GS.dispatchCustomEvent("NotifyFriendChangeDone", param);
    },

    /**
     *  取得申請列表
     *  [{
     *      "uid":"12771832",
        "nickname":"a96184155",
        "pic":"http://d.mwsrv.com/texas9/images/default_pic/photo_f-1.png",
        "userid":"a96184155@an",

        # 以下是印尼德撲使用的資料 這邊沒有用到
        "invite_time":"1580363329",
        "last_time":"-1"
        "level":"6",
    }]
     */
    cmd_user_get_friends_verify_list: function (key, value) {
        var jsonValue = JSON.parse(value);

        var isHaveApply = false;

        this.applyFriendList = [];

        // 只存申請清單的UID 用來處理是否有新的申請玩家
        var oldApplyUIDList = this.applyUIDList;
        this.applyUIDList = [];

        jsonValue.forEach(cur => {
            var friendInfo = {};
            isHaveApply = true;

            // nickname
            friendInfo.nickname = this._checkNickname(JSCodeUtility.getDecodeStringValue(cur["nickname"]));

            // userID
            friendInfo.userID = JSCodeUtility.getStringValue(cur["userid"]);

            // uid
            friendInfo.UID = JSCodeUtility.getStringValue(cur["uid"]);

            // 大頭貼
            friendInfo.photo = JSCodeUtility.getStringValue(cur["pic"]);

            this.applyFriendList.push(friendInfo);
            this.applyUIDList.push(friendInfo.UID);
        });

        // 新抓的好友申請是否跟之前的一樣(沒有新的好友資料就不顯示小紅點)
        if (!this.redPoint.icon) {
            var newApplyUIDList = this.applyUIDList;
            isHaveApply = oldApplyUIDList.sort().toString() !== newApplyUIDList.sort().toString();
            this.redPoint.icon = isHaveApply;
            this.redPoint.apply = isHaveApply;
        } else {
            this.redPoint.icon = false;
            this.redPoint.apply = false;
        }

        // 第一次進入
        var str = JSStringUtility.format("%s_firstFriend", DataModal.profileData.account);
        var isFirst = parseInt(GS.localStorage.getItem(str, 1));
        if (isFirst && DataModal.profileData.level >= 2)
            this.redPoint.icon = true;

        GS.dispatchCustomEvent("NotifyApplyFriendListDone");
    },

    /**
     *  邀請在線好友列表(牌桌內)
     *  C -> S mixFriend_isPlaying_list
     *  S -> C mixFriend_isPlaying_list
     *  [{"uid":"14278382",                                                     //玩家uid
     *  "pic":"http://d.mwsrv.com/texas9/images/default_pic/photo_m-3.png",     //玩家大頭貼
     *  "nickname":"u46232252"}                                                 //玩家暱稱
     *  , ...]
     *  如果沒有在線好友
     *  mixFriend_isPlaying_list {"msg":"Tidak ada teman online"}
     */
    cmd_mixFriend_isPlaying_list: function (key, value) {
        var jsonValue = JSON.parse(value);
        var param = this.isPlayingFriendParam = {};

        // 如果是Array代表有好友list
        if (Array.isArray(jsonValue)) {
            param.friendList = [];
            jsonValue.forEach(cur => {
                var friendInfo = {};
                // uid
                friendInfo.uid = JSCodeUtility.getStringValue(cur["uid"]);
                // uid
                friendInfo.userid = JSCodeUtility.getStringValue(cur["userid"]);
                // 暱稱
                friendInfo.nickname = this._checkNickname(JSCodeUtility.getDecodeStringValue(cur["nickname"]));
                // 大頭貼網址
                friendInfo.photoURL = JSCodeUtility.getStringValue(cur["pic"]);

                param.friendList.push(friendInfo);
            });
        }
        // 如果不是Array代表沒有好友，只有訊息
        else {
            param.msg = JSCodeUtility.getStringValue(jsonValue["msg"]);
        }
        GS.dispatchCustomEvent("NotifyGameInviteFriendDone");
    },

    /**
     *  好友邀請入桌/好友桌邀請
     *  C -> S invitation
     *  S -> C invitation(一般好友邀請)/area_friends_invitation(好友桌邀請)
     *  {"inviter":"a96184155@an",                                              // 邀請者ID
     *  "nick":"ariestest",                                                     // 邀請者暱稱
     *  "pic":"http://d.mwsrv.com/texas9/images/default_pic/photo_f-1.png",     // 邀請者大頭貼
     *  "need_money":"20000000",                                                // 遊戲需要的錢
     *  "playMsg":"POKER 1jt/2jt",                                              // 遊戲玩法
     *  "game":"38",                                                            // 遊戲種類
     *  "dialogType": "1",                                                      // 是哪邊送出的邀請 1:好友邀請 2:Gaple好友邀請
     *  "region":"1","styleType":"0", "msg":"ariestest undang ke meja (1jt/2jt), \n Anda ingin gabung?",
     *  "seat_fee":"100000","uid":"12771832","invitee":"e73299801@an","is_vip_room":"0",
     *  "fee":"1000000","ctime":"1581407012","roomid":"A49726"}
     */
    cmd_invitation: function (key, value) {
        var jsonValue = JSON.parse(value || {});

        // 後台傳了一堆null, 防呆一下
        if (!jsonValue)
            return;

        var param = {};
        // 邀請者ID
        param.inviterID = JSCodeUtility.getStringValue(jsonValue["inviter"]);
        // 邀請者暱稱
        param.inviterNickname = JSCodeUtility.getDecodeStringValue(jsonValue["nick"]);
        // 邀請者大頭貼
        param.inviterPhotoURL = JSCodeUtility.getStringValue(jsonValue["pic"]);
        // 遊戲玩法
        param.playMsg = JSCodeUtility.getStringValue(jsonValue["playMsg"]);
        // 遊戲需要的錢
        param.needMoney = JSCodeUtility.getIntValue(jsonValue["need_money"]);
        // 遊戲種類
        param.game = JSCodeUtility.getIntValue(jsonValue["game"]);
        // 是哪邊送出的邀請 1:好友邀請(一般狀態)  2:Gaple好友邀請
        param.inviteType = JSCodeUtility.getIntValue(jsonValue["dialogType"]) || 1;
        // 房號(gaple好友桌才會有)
        param.roomID = JSCodeUtility.getStringValue(jsonValue["roomid"]);
        // 底注
        param.fee = JSCodeUtility.getStringValue(jsonValue["fee"]);

        DialogManager.addLobbyDialog(new FriendInvitationDialog(FriendInvitationDialog.TYPE.INVITED, param));
    },

    /**
     * 好友列表跟隨入桌結果
     * C -> S join_friend_room {"userid":"XXX","room_id":"XXX","game":"XX"}
     * S -> C join_friend_room {"code":0}
     *
     * 大廳好友邀請入桌結果： 如果邀請無法入桌時會收到錯誤資訊
     * C -> S invitation_confirm
     * S -> C join_friend_room
     * join_friend_room {
     * "needMoney":"5000000",                                           //進牌局最低需要的錢
     * "fee":"250000",                                                  //牌局金額
     * "game":"38",                                                     //遊戲種類
     * "playMsg":"Poker 250rb/500rb",                                   //牌局玩法
     * "playType":"casual"                                              //牌局種類
     * "code":"1","msg":"Meja ini sudah penuh\ngabung dengan yg lain?"  //錯誤訊息
     * }
     */
    cmd_join_friend_room: function (key, value) {
        var jsonValue = JSON.parse(value);

        var param = {};

        // 邀請類型
        param.joinType = this.joinType;

        // 好友列表入桌結果 code 0:成功 1:人滿 2:不是同一間房間 3:錢不夠 4: 其他失敗
        // 大廳好友邀請入桌結果 code 0:成功 非0:失敗
        param.code = JSCodeUtility.getIntValue(jsonValue["code"]);

        // 錯誤訊息
        param.errorMsg = JSCodeUtility.getStringValue(jsonValue["msg"]);

        // 遊戲玩法
        param.playMsg = JSCodeUtility.getStringValue(jsonValue["playMsg"]);

        // 導馬上玩資訊
        param.playType = JSCodeUtility.getStringValue(jsonValue["playType"]);

        // 導去那一個遊戲
        param.game = JSCodeUtility.getIntValue(jsonValue["game"]);

        param.fee = JSCodeUtility.getStringValue(jsonValue["fee"]);

        // 遊戲需要的錢
        param.needMoney = JSCodeUtility.getIntValue(jsonValue["needMoney"]);

        GS.dispatchCustomEvent("NotifyJoinFriendRoomDone", param);

        // 清掉邀請紀錄
        this.joinType = FriendData.joinType.None;
    },

    cmd_invitation_result: function (key, value) {
        var jsonValue = JSON.parse(value);

        // 顯示訊息
        var hintString = {};

        if (key === "invitation_dialog")
            hintString = decodeURIComponent(JSCodeUtility.getStringValue(jsonValue["msg"]));
        else if (key === "dialog")
            hintString = decodeURIComponent(JSCodeUtility.getStringValue(jsonValue["text"]));

        // 如果是在大廳表示是被邀請者收到"dialog"
        if (PushScene.isLobby) {
            // 關掉要入桌的loadingview
            GSLoading.removeLoadingView();
            // 關掉原本的邀請視窗
            DialogManager.closeDialogByKey("FriendInvitationDialog");
            // 顯示錯誤訊息
            var retObj = {
                content: (hintString.length > 0) ? hintString : LocalizedString.Common("伺服器發生錯誤 請稍候再試。"),
                buttons: [LocalizedString.Common("確認")]
            };
            DialogManager.addDialog(new AvatarDialog(retObj));

        }
        // 遊戲內顯示跑馬燈
        else {
            if (hintString.length)
                GS.dispatchCustomEvent("NotifyShowTopMessage", hintString);
        }
    },

    /**
     * all_invitation 發送邀請入桌後, server告訴我們邀請了幾位玩家
     * 會傳給其它玩家 invitation
     */
    cmd_all_invitation: function (key, value) {
        if (value.length) {
            var num = JSCodeUtility.getIntValue(value);
            DialogManager.addDialog(new SimpleAlertDialog(LocalizedString.Game(JSStringUtility.format(LocalizedString.Game("已發出比賽邀請給%d位線上玩家"), num)), 0.8, SimpleAlertDialog.StyleType.RED), false, true);
        }
    },

    /**
     * S->C online_notify
     {
        "name": "XXX", # 玩家名稱
        "pic": "http://d.mwsrv.com/texas9/images/default_pic/photo_m-2.png", # 玩家圖片連結
        "msg": "已上線",
     }
     */
    cmd_online_notify: function (key, value) {
        var jsonValue = JSON.parse(value);

        var param = {
            name: JSCodeUtility.getDecodeStringValue(jsonValue["name"]),
            photo: JSCodeUtility.getStringValue(jsonValue["pic"]),
            msg: JSCodeUtility.getStringValue(jsonValue["msg"], "Online")
        };

        GS.dispatchCustomEvent("NotifyShowFriendOnlineHint", param);
    },

    /**
     * S->C user_friends_invitation
     {
        "nickname": "XXX", # 玩家名稱
        "pic": "http://d.mwsrv.com/texas9/images/default_pic/photo_m-2.png", # 玩家圖片連結
        "userid":userid,
     }
     */
    cmd_user_friends_invitation: function (key, value) {
        var jsonValue = JSON.parse(value);

        var param = {
            nickname: this._checkNickname(JSCodeUtility.getDecodeStringValue(jsonValue["nickname"])),
            userID: JSCodeUtility.getStringValue(jsonValue["userid"]),
            photo: JSCodeUtility.getStringValue(jsonValue["pic"])
        };

        GS.dispatchCustomEvent("NotifyShowFriendAddHint", param);
    }
});

// 入桌結果類型
FriendData.joinType = {
    None: 0,                    // 無
    LobbyFriendList: 1,         // 大廳好友列表
    FriendInvitation: 2,        // 好友邀請
    FriendTableInvitation: 3    // 好友桌邀請
};
