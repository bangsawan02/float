/**
 * 9T 幸運彩票 - 各畫面的base
 */

var BigLotteryBaseLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this.pageType = ""; // 紀錄是哪個頁面

        // 主頁面的node
        var mainNode = this._mainNode = new cc.Node();
        this.addChild(mainNode);

        // loading
        var loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(303 + JSScreenBonusHalfWidth, 114 + JSScreenBonusHalfHeight);
        this.addChild(loadingSprite, 999999);
    },

    /**
     * 進入頁面要做的事情
     * 給外面override用的
     */
    _enterPage: function () {

    },

    /**
     * override
     */
    setVisible: function (visible) {
        this._super(visible);

        if (visible) {
            this._enterPage();
        }
    },

    /**
     * 加上說明按鈕
     * @param target    加在哪一個目標上
     * @param pos       位置
     */
    _addInfoBtn: function (target, pos) {
        // 說明按鈕
        var itemNodes = ButtonUtility.createSingleScale9NodesWithIcon("#lobby_btn_circle_04.png", cc.size(28, 28), "#explain_icon.png");
        var infoBtn = this._infoBtn = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._infoClicked, this);
        infoBtn.setScale(0.7);
        infoBtn.setPosition(pos);
        target.addChild(infoBtn, 100000);
    },

    /**
     * 點擊說明按鈕
     * 可override
     */
    _infoClicked: function () {
        MusicUtility.playEffect("Music/Effect/e_clickButton.mp3", false);

        DialogManager.addDialog(new WebViewDialog(TexasUtility.getSimpleInfoURLByKey("big_lottery")), false);
    }
});