var FarmBingoData = cc.Class.extend({
    ctor: function () {
        this.clean();
        // 註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            "farm_bingo_icon_status": this.cmd_farm_bingo_icon_status,

            "farm_bingo_info": this.cmd_farm_bingo_info,
            "farm_bingo_get_ball": this.cmd_farm_bingo_get_ball,
            "farm_bingo_buy_extra_reward": this.cmd_farm_bingo_buy_extra_reward,

            "farm_bingo_pass_info": this.cmd_farm_bingo_pass_info,
            "farm_bingo_pass_reward": this.cmd_farm_bingo_pass_reward,
            "farm_bingo_pass_recharge_done": this.cmd_farm_bingo_pass_recharge_done,
        });
    },

    clean: function () {
        this.iconParam = null;
        this.bingoParam = null;
        this.passIconParam = null;
        this.passData = new BasePassInfoData();
        this.getTokensPlayArray = [];
        this.getTokensSill = 0;
        this.getTokensSlotArray = [];
        this.currentBingoBall = 0;
        this.limitToken = 0;
        this.accumulateFeeData = null;
        this.group = 0;
        this.needRefresh = false;
    },

    /**
     * 是否要顯示小紅點
     */
    shouldShowBadge: function () {
        let iconParam = this.iconParam;
        let bingoData = this.bingoParam;
        let passParam = this.passData;
        let passIconParam = this.passIconParam;
        let isExtraRewardObtainable = !!bingoData && (bingoData.extraRewardList || []).some(element => JSCodeUtility.getRemainTime(element.remainTime, element.socketTime) <= 0);
        let isBingoBallObtainable = bingoData ? bingoData.token >= bingoData.oneRunCost : iconParam?.bingoStatus;
        let isPassObtainable = passParam.errorCode === 0 ? passParam.isObtainable() : passIconParam ? passIconParam.isGetReward : iconParam?.bingoStatus;
        let isChangeDay = TexasUtility.getNowIsChangeDay(GS.localStorage.getItem(UserDefaultKey.FarmBingoIconRedPoint + DataModal.profileData.account, 0));

        // 1. 當日尚未進入過農場賓果介面 2. 有賓果次數可抽 3. 農場 Pass 有獎勵可領 (農場 Pass 和金蘋果可領獎時)
        return isChangeDay || isPassObtainable || isBingoBallObtainable || isExtraRewardObtainable;
    },

    /**
     * 砍掉Data
     */
    destroyData: function () {
        this.clean();
        DataProcess.removeSocketKeyDispatch(this);
    },

    /**
     * 送icon資料
     */
    startGetIconInfo: function () {
        DataProcess.sendString("farm_bingo_icon_status");
    },

    /**
     * 要info
     */
    startGetInfo: function () {
        DataProcess.sendString("farm_bingo_info");
    },

    startGetPassInfo: function () {
        DataProcess.sendString("farm_bingo_pass_info");
    },

    /**
     * 取球
     */
    startGetBingoBall: function () {
        DataProcess.sendString("farm_bingo_get_ball");
    },

    /**
     * 確認活動是否開啟
     */
    getEventIsOpen: function () {
        return this.iconParam && this.iconParam.isSuccess;
    },

    /**
     * 檢查是否是可累積代幣的機台
     */
    canThisSlotAccumulate: function (gameType) {
        // 這邊百人骰寶實驗機台額外處理
        if (gameType === VegasGameType.MULTI_DICEBO_TEST_A)
            gameType = VegasGameType.MULTI_DICEBO;

        // 可累積的機台
        return this.getTokensSlotArray.indexOf(gameType) !== -1;
    },

    /**
     * 檢查是否是可累積代幣的牌桌
     */
    canThisPlayAccumulate: function (gameType) {
        switch (gameType) {
            case LobbySelectGameSetting.GameType.Texas:
            case LobbySelectGameSetting.GameType.Texas19:
                return this.getTokensPlayArray.some((element) => [GSEnum.Game.Texas, GSEnum.Game.Texas19].indexOf(element) !== -1);
            case LobbySelectGameSetting.GameType.Gaples:
            case LobbySelectGameSetting.GameType.GaplePlus:
                return this.getTokensPlayArray.some((element) => [GSEnum.Game.Gaple, GSEnum.Game.GaplePlus].indexOf(element) !== -1);
            default:
                return false;
        }
    },

    /**
     * 用來判斷是不是在可累積的 slot 機台
     */
    isInCanGetTokenSlot: function () {
        if (PushScene.isSlot || cc.director.getRunningScene().isVegasScene) {
            return this.canThisSlotAccumulate(DataModal.vegasData.getVegasIDMapByVegasGameType(DataModal.lastVegasType));
        }
        return false;
    },

    /**
     * 確認牌桌內是否可以累積
     * @returns {boolean}
     */
    isInCanGetTokenPlay: function () {
        let gameData = DataModal.gameData;
        if (PushScene.isSlot || cc.director.getRunningScene().isVegasScene || !gameData)
            return false;

        switch (GS.nowGame) {
            case GSEnum.Game.Texas:
            case GSEnum.Game.Texas19:
                return gameData.smallBlind >= this.accumulateFeeData.minFeeTexas && gameData.smallBlind <= this.accumulateFeeData.maxFeeTexas;
            case GSEnum.Game.GaplePlus:
                return gameData.anteValue >= this.accumulateFeeData.minFeeGaplePlus && gameData.anteValue <= this.accumulateFeeData.maxFeeGaplePlus;
            default:
                return false;
        }
    },

    sendTrackingData: function (trackCode) {
        if (this.getEventIsOpen()) {
            TexasUtility.sendUserAnalyticsTrack(trackCode, this.group);
        }
    },

    /**
     * icon 資料
     */
    cmd_farm_bingo_icon_status: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        let jsonValue = JSON.parse(value || "{}");

        this.iconParam = {};

        // 0: 請求成功
        let isSuccess = this.iconParam.isSuccess = !JSCodeUtility.getBooleanValue(jsonValue["error"], 1);
        if (isSuccess) {
            // 剩餘時間
            this.iconParam.socketTime = JSCodeUtility.getNowTime();
            this.iconParam.remainTime = JSCodeUtility.getIntValue(jsonValue["left_time"]);

            this.iconParam.pop = JSCodeUtility.getBooleanValue(jsonValue["pop"]);
            this.iconParam.bingoStatus = JSCodeUtility.getBooleanValue(jsonValue["bingo_status"]);


            // 機台內每多少錢可以獲得代幣的門檻
            this.getTokensSill = JSCodeUtility.getIntValue(jsonValue["slot_sill"], 1000000);

            // 累積代幣上限
            this.limitToken = JSCodeUtility.getIntValue(jsonValue["token_limit"] || 999999999);

            // 可獲得代幣的機台
            this.getTokensSlotArray = (jsonValue["get_token_slot"] || []).map(cur => JSCodeUtility.getIntValue(cur));

            // 可獲得代幣的牌桌
            this.getTokensPlayArray = (jsonValue["get_token_play"] || []).map(cur => JSCodeUtility.getIntValue(cur));

            // 牌桌限制底台
            this.accumulateFeeData = {
                maxFeeGaplePlus: JSCodeUtility.getIntValue(jsonValue["can_accu_max_fee_gapleplus"]),
                minFeeGaplePlus: JSCodeUtility.getIntValue(jsonValue["can_accu_min_fee_gapleplus"]),
                maxFeeTexas: JSCodeUtility.getIntValue(jsonValue["can_accu_max_fee"]),
                minFeeTexas: JSCodeUtility.getIntValue(jsonValue["can_accu_min_fee"]),
            };

            // 分群
            this.group = JSCodeUtility.getIntValue(jsonValue["bingo_token_group"]);
        }

        // 通知
        GS.dispatchCustomEvent("NotifyFarmBingoIconDone");
    },

    /**
     * Bingo Data
     */
    cmd_farm_bingo_info: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value || "{}");

        let bingoParam = this.bingoParam = {};
        this.passIconParam = undefined;

        var errorCode = bingoParam.errorCode = JSCodeUtility.getIntValue(jsonValue["error"], -1);
        if (errorCode === 0) {
            // 剩餘時間
            bingoParam.remainTime = JSCodeUtility.getIntValue(jsonValue["left_time"], 0);
            bingoParam.socketTime = JSCodeUtility.getNowTime();

            var remainTime = JSCodeUtility.getRemainTime(bingoParam.remainTime, bingoParam.socketTime);

            if (remainTime > 0) {
                // 賓果數量
                this.currentBingoBall = JSCodeUtility.getIntValue(jsonValue["total_ball"]);

                // 代幣數量
                bingoParam.token = JSCodeUtility.getIntValue(jsonValue["token"], 0);

                // 玩家組別，用於賓果說明頁 parameter
                bingoParam.playGroup = JSCodeUtility.getIntValue(jsonValue["play_group"]);

                // 錢袋獎勵
                bingoParam.ballRewardPot = JSCodeUtility.isArray(jsonValue["ball_reward_pot"]) ? jsonValue["ball_reward_pot"].map((element) => {
                    return {
                        count: JSCodeUtility.getStringValue(element["count"]),
                        picFileName: JSCodeUtility.getStringValue(element["wid_pic"])
                    };
                }) : [];

                // 更新獎勵罐
                bingoParam.extraRewardList = [];
                if (jsonValue["extra_reward"] && JSCodeUtility.isArray(jsonValue["extra_reward"]["reward_list"])) {
                    bingoParam.extraRewardList = jsonValue["extra_reward"]["reward_list"].map((obj) => {
                        return {
                            remainTime: JSCodeUtility.getIntValue(obj["get_left_time"], -1),
                            socketTime: JSCodeUtility.getNowTime(),
                            cost: JSCodeUtility.getIntValue(jsonValue["extra_reward"]["need_RP"], 0),
                        };
                    });
                }

                // 獎勵罐位置
                bingoParam.extraRewardPosition = [];
                if (JSCodeUtility.isArray(jsonValue["extra_reward_pos"])) {
                    bingoParam.extraRewardPosition = jsonValue["extra_reward_pos"].map((element) => {
                        return JSCodeUtility.getIntValue(element, -1);
                    });
                }

                // 階段獎勵
                bingoParam.round = {};
                if (jsonValue["round"]) {
                    bingoParam.round.stage = JSCodeUtility.getIntValue(jsonValue["round"]["stage"], 0);
                    bingoParam.round.goal = JSCodeUtility.getIntValue(jsonValue["round"]["goal"], 0);
                    bingoParam.round.doneCardNum = JSCodeUtility.getIntValue(jsonValue["round"]["done_card_num"], 0);
                    bingoParam.round.reward = JSCodeUtility.getIntValue(jsonValue["round"]["reward"], 0);
                }

                // 領一次賓果球的代幣價
                bingoParam.oneRunCost = JSCodeUtility.getIntValue(jsonValue["one_run"], 0);

                // 賓果卡資料
                bingoParam.cardData = {
                    numArray: this._parseNumArray(jsonValue["bingo_card"]),
                    wonArray: this._parseWonArray(jsonValue["bingo_pos"])
                };

                // 儲值資料
                if (jsonValue["recharge"]) {
                    let imgUrl = UrlUtils.normalize(jsonValue["recharge"]["img_url"], "//d.mwsrv.com/19_60/store/iapp/download/payment/ID/");
                    bingoParam.recharge = DataModal.purchaseData.processProviderChoosePurchase(jsonValue["recharge"]["product_list"], imgUrl, ["top_msg", "productID", "pic"]);
                }

                // 齋戒pass icon資料
                var iconPass = jsonValue["pass_icon"];
                if (iconPass) {
                    this.passIconParam = {
                        // 齋戒pass 是否主動彈跳
                        isPop: JSCodeUtility.getBooleanValue(iconPass["pop"]),
                        // 齋戒pass 是否可領獎
                        isGetReward: JSCodeUtility.getBooleanValue(iconPass["can_reward"]),
                        // 齋戒pass 獎勵門檻
                        goalArray: (iconPass["goal"] || []).map((element) => {
                            return JSCodeUtility.getIntValue(element);
                        })
                    };
                }

                // 牌桌列表與機台列表代幣資訊
                var tokenAddData = jsonValue["add"] || {};
                this.playBtnArray = (tokenAddData["play_btn"] || []).map(cur => {
                    return {
                        lobbyType: JSCodeUtility.getIntValue(cur["lobby_type"]),    // lobby按鈕的編號
                        url: JSCodeUtility.getIntValue(cur["url"]),
                        type: JSCodeUtility.getIntValue(cur["type"]),
                        trackType: JSCodeUtility.getIntValue(cur["track_type"])     // 埋點編號
                    };
                });
                this.slotBtnArray = (tokenAddData["slot_btn"] || []).map(cur => {
                    return {
                        lobbyType: JSCodeUtility.getIntValue(cur["lobby_type"]),  // lobby按鈕的編號
                        url: JSCodeUtility.getIntValue(cur["url"]),
                        type: JSCodeUtility.getIntValue(cur["type"]),
                        trackType: JSCodeUtility.getIntValue(cur["track_type"])     // 埋點編號
                    };
                });
            }
        }

        // 通知 UI
        GS.dispatchCustomEvent("NotifyFarmBingoInfoDone");
    },

    /**
     * 齋戒副系統 賓果 更新格子號碼資料
     * @param bingoCardArray {string[]} Pass jsonValue["bingo_card"]
     * @return int[]
     */
    _parseNumArray: function (bingoCardArray) {
        if (JSCodeUtility.isArray(bingoCardArray)) {
            return bingoCardArray.map((element) => {
                return JSCodeUtility.getIntValue(element, -1);
            });
        }
        return Array(25).fill(-1);
    },

    /**
     * 齋戒副系統 賓果 更新格子中獎資料
     * @param bingoPosArray {string[]} Pass jsonValue["bingo_pos"]
     * @return boolean[]
     */
    _parseWonArray: function (bingoPosArray) {
        if (JSCodeUtility.isArray(bingoPosArray)) {
            return bingoPosArray.map((element) => {
                return JSCodeUtility.getBooleanValue(element, false);
            });
        }
        return Array(25).fill(false);
    },

    /**
     * Get a ball
     */
    cmd_farm_bingo_get_ball: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value || "{}");

        var param = this.newBallParam = this.newBallParam || {};

        // 儲存待處理的抽球事件 queue
        var taskQueue = param.taskQueue = param.taskQueue || [];

        var errorCode = param.errorCode = JSCodeUtility.getIntValue(jsonValue["error"]);
        if (errorCode === 0) {
            // 領到的賓果球與在卡片上的位置，未來可能領多顆
            jsonValue["new_balls"].forEach((element, i) => {
                taskQueue.push({
                    type: FarmBingoData.FarmBingoTaskType.GET_BALL,
                    num: JSCodeUtility.getIntValue((element), -1),
                    pos: jsonValue["new_balls_pos"] && jsonValue["new_balls_pos"][i] ? JSCodeUtility.getIntValue((jsonValue["new_balls_pos"][i]), -1) : -1,

                    // 獎勵罐
                    extraReward: !jsonValue["extra_reward"] ? {} : {
                        addExtraReward: JSCodeUtility.getBooleanValue(jsonValue["extra_reward"]["add_extra_reward"], false),
                        buyExtraRewardNow: JSCodeUtility.getBooleanValue(jsonValue["extra_reward"]["buy_extra_reward_now"], false),
                        rewardList: (jsonValue["extra_reward"]["reward_list"] || []).map((element) => {
                            return {
                                remainTime: JSCodeUtility.getIntValue(element["get_left_time"], 0),
                                socketTime: JSCodeUtility.getNowTime(),
                                cost: JSCodeUtility.getIntValue(jsonValue["extra_reward"]["need_RP"])
                            };
                        }),
                        cost: JSCodeUtility.getIntValue(jsonValue["extra_reward"]["need_RP"])
                    },

                    // 錢袋
                    ballRewardPot: JSCodeUtility.isArray(jsonValue["ball_reward_pot"]) ? jsonValue["ball_reward_pot"].map((element) => {
                        return {
                            count: JSCodeUtility.getStringValue(element["count"]),
                            picFileName: JSCodeUtility.getStringValue(element["wid_pic"])
                        };
                    }) : [],

                    token: JSCodeUtility.getIntValue(jsonValue["token"], 0),
                    currentBingoBall: JSCodeUtility.getIntValue(jsonValue["total_ball"], 0),
                    oneRunCost: JSCodeUtility.getIntValue(jsonValue["one_run"], this.bingoParam.oneRunCost),
                    cardData: {
                        numArray: this._parseNumArray(jsonValue["bingo_card"]),
                        wonArray: this._parseWonArray(jsonValue["bingo_pos"])
                    }
                });
            });

            // 連線情況
            if (jsonValue["next_card"] && jsonValue["lines_list"]) {
                taskQueue.push({
                    type: FarmBingoData.FarmBingoTaskType.LINE_UP,
                    linesList: jsonValue["lines_list"].map((element) => {
                        return JSCodeUtility.getBooleanValue(element);
                    }),
                    nextCard: {
                        extraRewardPosition: jsonValue["next_card"]["extra_reward_pos"].map((element) => {
                            return JSCodeUtility.getIntValue(element, -1);
                        }),
                        cardData: {
                            numArray: this._parseNumArray(jsonValue["next_card"]["bingo_card"]),
                            wonArray: this._parseWonArray(jsonValue["next_card"]["bingo_pos"])
                        },
                        ballRewardPot: JSCodeUtility.isArray(jsonValue["next_card"]["ball_reward_pot"]) ? jsonValue["next_card"]["ball_reward_pot"].map((element) => {
                            return {
                                count: JSCodeUtility.getStringValue(element["count"]),
                                picFileName: JSCodeUtility.getStringValue(element["wid_pic"])
                            };
                        }) : [],
                        round: {
                            goal: JSCodeUtility.getIntValue(jsonValue["next_card"]["round"]["goal"], this.bingoParam.round.goal),
                            stage: JSCodeUtility.getIntValue(jsonValue["next_card"]["round"]["stage"], this.bingoParam.round.stage),
                            doneCardNum: JSCodeUtility.getIntValue(jsonValue["next_card"]["round"]["done_card_num"], this.bingoParam.round.doneCardNum),
                            reward: JSCodeUtility.getIntValue(jsonValue["next_card"]["round"]["reward"], this.bingoParam.round.reward),
                        }
                    }
                });
            }
        }

        // 通知 UI
        GS.dispatchCustomEvent("NotifyFarmBingoGetBallDone");
    },

    /**
     * 買獎勵罐
     */
    cmd_farm_bingo_buy_extra_reward: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value || "{}");
        var param = {};

        var errorCode = param.errorCode = JSCodeUtility.getIntValue(jsonValue["error"]);
        if (errorCode === 0) {
            param.rewardMsg = JSCodeUtility.isArray(jsonValue["reward_msg"]) ? jsonValue["reward_msg"] : [];
            param.reward = JSCodeUtility.isArray(jsonValue["reward"]) ? jsonValue["reward"].map((element) => {
                return {
                    count: JSCodeUtility.getIntValue(element["count"]),
                    wid: JSCodeUtility.getStringValue(element["wid"])
                };
            }) : [];
        }

        GS.dispatchCustomEvent("NotifyFarmBingoBuyExtraRewardDone", param);
    },

    /**
     * Pass Data
     */
    cmd_farm_bingo_pass_info: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        this.passData.parse(value);

        let jsonValue = JSON.parse(value || "{}");
        if (jsonValue["total_ball"]) {
            this.currentBingoBall = JSCodeUtility.getIntValue(jsonValue["total_ball"]);
            this.passData.tokenCount = JSCodeUtility.getIntValue(jsonValue["total_ball"]);
        }

        // 通知 UI
        GS.dispatchCustomEvent("NotifyFarmPassInfoDone");
    },

    /**
     * Pass Reward
     */
    cmd_farm_bingo_pass_reward: function (key, value) {
        if (DataModal.profileData.isBlackAccount)
            return;

        let rewardData = BasePassDataParser.parseReward(value);

        if (rewardData.isSuccess()) {
            GS.dispatchCustomEvent("NotifyFarmPassShowDialog", rewardData.getEventParam());

            // 表情是否需要刷新
            let jsonValue = JSON.parse(value || "{}");
            if (JSCodeUtility.getBooleanValue(jsonValue["refresh"])) {
                DataModal.moodData.isNeedRefreshInfo = true;
                DataModal.moodData.sendMoodInfo();
            }
        } else {
            // 領獎失敗
            let obj = {
                content: LocalizedString.FarmBingo("領獎失敗，請稍候再試"),
                buttons: [LocalizedString.FarmBingo("OK")],
                callback: () => {
                    // 關掉Dialog
                    let dialog = DialogManager.getDialogByKey("FarmBingoDialog");
                    dialog && dialog.closeDialogAnimation();
                }
            };
            DialogManager.addDialog(new Dialog(obj), false);
        }
    },

    /**
     * Pass Recharge Done
     */
    cmd_farm_bingo_pass_recharge_done: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        let data = BasePassDataParser.parseRechargeDoneData(value);
        if (data.isSuccess()) {
            GS.dispatchCustomEvent("NotifyFarmPassRechargeDone", data);
        }
    },

    /**
     * 送埋點
     * @param key
     */
    sendEventLog: function (key) {
        let actionLogID, eventName = 0;
        switch (key) {
            case "農場賓果_Free Chips 頁彈跳_看見農場賓果 go 按鈕":
                actionLogID = 20;
                eventName = Texas_UserLog.EVENT_ID.FREE_CHIPS;
                break;
            case "農場賓果_Free Chips 頁彈跳_點擊農場賓果 go":
                actionLogID = 30;
                eventName = Texas_UserLog.EVENT_ID.FREE_CHIPS;
                break;
            case "農場賓果_Free Chips 頁彈跳_看見農場賓果 go 按鈕 (有小紅點)":
                actionLogID = 26;
                eventName = Texas_UserLog.EVENT_ID.FREE_CHIPS;
                break;
            case "農場賓果_Free Chips 頁彈跳_點擊農場賓果 go (有小紅點)":
                actionLogID = 36;
                eventName = Texas_UserLog.EVENT_ID.FREE_CHIPS;
                break;
            case "農場賓果_Free Chips 頁 icon_看見農場賓果 go 按鈕":
                actionLogID = 20;
                eventName = Texas_UserLog.EVENT_ID.FREE_CHIPS_ICON;
                break;
            case "農場賓果_Free Chips 頁 icon_點擊農場賓果 go":
                actionLogID = 30;
                eventName = Texas_UserLog.EVENT_ID.FREE_CHIPS_ICON;
                break;
            case "農場賓果_Free Chips 頁 icon_看見農場賓果 go 按鈕 (有小紅點)":
                actionLogID = 26;
                eventName = Texas_UserLog.EVENT_ID.FREE_CHIPS_ICON;
                break;
            case "農場賓果_Free Chips 頁 icon_點擊農場賓果 go (有小紅點)":
                actionLogID = 36;
                eventName = Texas_UserLog.EVENT_ID.FREE_CHIPS_ICON;
                break;
            default:
                cc.error("Key not found: " + key);
                return;
        }
        const customObj = {};
        customObj.event_name = eventName;
        if (this.group) {
            customObj.campaign_group = this.group;
        }
        EventLogToBigQuery.logEvent(Texas_UserLog.CAMPAIGN_ID.FARM_BINGO, actionLogID, customObj);
    },
});

// 賓果任務類型
FarmBingoData.FarmBingoTaskType = GSEnumHelper({
    GET_BALL: -1,
    LINE_UP: -1,
});