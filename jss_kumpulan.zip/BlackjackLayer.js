/**
 *  21點主畫面
 */

var BlackjackLayer = VegasGameBaseLayer.extend({
    StateType: {                    // 狀態
        INIT: 0,                    // BlackJack初始狀態
        CLEAR_CHIPS: 1,             // BlackJack清除下注
        DEALING_CARD: 2,            // 發牌中
        CAN_HIT: 3                  // 發完牌
    },

    ctor: function () {
        this._super();

        this.setCascadeOpacityEnabled(true);

        cc.spriteFrameCache.addSpriteFrames("vegas/blackjack/blackjack.plist", "vegas/blackjack/blackjack.png");

        // 初始化參數
        this._enableProcessMessage = true;          // 是否可以執行cmd
        this._isFirstHit = true;                    // 是否第一次加注 用來決定加倍按鈕要不要出現
        this._betChips = 0;
        this._isNeedDouble = false;
        this._betButtonArray = [];              // 存放下注籌碼按鈕

        var blackjackString = LocalizedString.Blackjack;

        // 設定機台是哪一個 一定要設
        this._vegasType = VegasGameType.BLACKJACK;

        // 清掉指令
        DataModal.vegasData.cleanMessageQueue(this._vegasType);

        // 背景
        var bgSprite = this._bgSprite = new cc.Sprite("vegas/blackjack/bj_bgTable2.jpg");
        bgSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 7);
        this.addChild(bgSprite, -2);

        // 背景文字
        var bgTextSprite = new cc.Sprite("#bj_table_text.png");
        bgTextSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 41);
        this.addChild(bgTextSprite, -1);

        // 新增返回按鈕
        this._backMenuItem = this._addBackButton(this._backBtnClicked, this, 40);

        // 右上方賠率按鈕
        var itemNodes = ButtonUtility.createSingleScale9SpriteNodes("btn_square_up.png", null, "#rate_table_btn.png");
        var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._openRateInfoClicked, this);
        var menu = new cc.Menu(menuItem);
        menu.setPosition(JSVisibleSize.width - 18 - JSScreenSafeWidth, JSVisibleSize.height - 18);
        this.addChild(menu, 30);

        // Blackjack標題
        var titleSprite = new cc.Sprite("#bj_word_blackjack.png");
        titleSprite.setPosition(JSScreenMidPos.x, JSVisibleSize.height - 28);
        titleSprite.setScale(0.85 + (JSScreenBonusWidth / 80 * 0.15));
        this.addChild(titleSprite);

        // 標題的閃星星
        var starPoints = [
            cc.p(JSScreenMidPos.x - 129, JSVisibleSize.height - 10),
            cc.p(JSScreenMidPos.x + 35, JSVisibleSize.height - 40),
            cc.p(JSScreenMidPos.x + 112, JSVisibleSize.height - 10)
        ];
        var starDelayTime1 = [2, 2.5, 3];
        var starDelayTime2 = [1.1, 0.6, 0.1];
        for (var i = 0; i < 3; i++) {
            var starSprite = new cc.Sprite("#vegas_effectLight_02.png");
            starSprite.setPosition(starPoints[i]);
            starSprite.setOpacity(0);
            this.addChild(starSprite);

            var action1 = cc.delayTime(starDelayTime1[i]);
            var action2 = cc.fadeIn(0.5);
            var action3 = cc.fadeOut(0.5);
            var action4 = cc.delayTime(starDelayTime2[i]);
            starSprite.runAction(cc.repeatForever(cc.sequence(
                action1,
                action2,
                action3,
                action4
            )));
            starSprite.runAction(cc.repeatForever(cc.rotateBy(2, 360)));
        }

        // 創下方發牌區的畫面
        var deckSprite = new cc.Sprite(GameTableTheme.getPokerDeckTheme());
        deckSprite.setPosition(JSScreenMidPos.x + 195, JSScreenMidPos.y + 66);
        this.addChild(deckSprite);

        // 棄牌區
        var cardPic = GS.theme === GSEnum.Theme.LEBARAN ? "#bj_poker_end_lebaran.png" : "#bj_poker_end.png";
        var cardBoxSprite2 = new cc.Sprite(cardPic);
        cardBoxSprite2.setPosition(JSScreenMidPos.x - 193, JSScreenMidPos.y + 76);
        this.addChild(cardBoxSprite2);

        // 免費券Node
        var freeTicketNode = this._freeTicketNode = new VegasFreeTicketNode(VegasGameType.BLACKJACK, null, true);
        freeTicketNode.setPosition(JSScreenMidPos.x, 52);
        freeTicketNode.setScale(1.4);
        freeTicketNode.setMinusCallback(this._onFreeTicketUsageChange.bind(this));
        freeTicketNode.setPlusCallback(this._onFreeTicketUsageChange.bind(this));
        this.addChild(freeTicketNode, 8);

        // 其他按鈕
        var mainMenu = this._mainMenu = new cc.Menu();
        mainMenu.setPosition(0, 0);
        this.addChild(mainMenu, 20);

        // 清除按鈕
        var cleanMenu = this._cleanMenu = this._createNormalMenuItem("bj_btn_red.png", cc.size(65, 30), blackjackString("清除"), this._cleanClicked, this);
        cleanMenu.setPosition(JSScreenMidPos.x - 126, 52);
        mainMenu.addChild(cleanMenu);

        // 發牌按鈕
        var playCardMenu = this._playCardMenu = this._createNormalMenuItem("bj_btn_green.png", cc.size(65, 30), blackjackString("發牌"), this._playCardClicked, this);
        playCardMenu.setPosition(JSScreenMidPos.x + 126, 52);
        mainMenu.addChild(playCardMenu);

        // 補牌按鈕
        var hitCardMenu = this._hitCardMenu = this._createNormalMenuItem("bj_btn_green.png", cc.size(65, 30), blackjackString("補牌"), this._hitCardClicked, this);
        hitCardMenu.setPosition(JSScreenMidPos.x + 126, 52);
        hitCardMenu.setVisible(false);
        mainMenu.addChild(hitCardMenu);

        // 加倍按鈕
        var doubleMenu = this._doubleMenu = this._createNormalMenuItem("bj_btn_green.png", cc.size(65, 30), blackjackString("加倍"), this._doubleClicked, this);
        doubleMenu.setPosition(JSScreenMidPos.x + 194, 52);
        doubleMenu.setVisible(false);
        mainMenu.addChild(doubleMenu);

        // 不補牌按鈕
        var standMenu = this._standMenu = this._createNormalMenuItem("bj_btn_red.png", cc.size(65, 30), blackjackString("不補牌"), this._standClicked, this);
        standMenu.setPosition(JSScreenMidPos.x - 126, 52);
        standMenu.setVisible(false);
        mainMenu.addChild(standMenu);

        // 下注金額Led
        var ledNode = this._ledNode = new BlackjackLedNode();
        ledNode.setPosition(JSScreenMidPos.x + 164, 90);
        this.addChild(ledNode);

        // 下注籌碼的node
        var chipsNode = this._chipsNode = new cc.Node();
        this.addChild(chipsNode, 15);

        // 新增下方儲值選單
        this._addPurchaseMenu(this._purchaseClicked, this, 20);

        // 新增天線
        this._addAntenna(21);

        // 新增場編
        this._addSerialNumber(10);

        // 擺放牌的畫面
        this._pokerLayer = new BlackjackPokerLayer();
        this.addChild(this._pokerLayer, 11);

        // 特效畫面
        this._effectLayer = new BlackjackEffectLayer();
        this.addChild(this._effectLayer, 30);

        // 註冊
        GS.addListener("NotifyCheckBJResume", this.notifyCheckBJResume.bind(this), this);
        GS.addListener("NotifyBlackjackEnableCMD", this.notifyBlackjackEnableCMD.bind(this), this);
        GS.addListener("NotifyBlackjackResultDone", this.notifyBlackjackResultDone.bind(this), this);
        GS.addListener("NotifyRefreshFreeTicket", this.notifyRefreshFreeTicket.bind(this), this);
        GS.addListener("NotifySlotFailCMD", this.notifySlotFailCMD.bind(this), this);
    },

    onEnter: function () {
        this._super();

        // 加Android
        PushScene.addBackKeyEnableLayer(this);
    },

    onExit: function () {
        PushScene.removeBackKeyEnableLayer(this);

        // 送出離開
        DataProcess.sendString("slot10_leave");

        cc.spriteFrameCache.removeSpriteFramesFromFile("vegas/blackjack/blackjack.plist");

        this._super();
    },

    /**
     * 進遊戲
     * @override
     */
    _enterVegasGame: function () {
        // 加Loading(等slot10_resume回來)
        GSLoading.addLoadingView();

        // 加UI(確認近GameServer才能要資料)
        {
            // 側邊欄
            this._addSideOptionLayer(40);

            // 牌王之路icon
            // 牌桌內的娛樂城返回按鈕比較大顆
            var offsetX = (PushScene.isGame) ? 14 : 0;
            this._addGamblerRoadIconNode(7, offsetX);

            // 聚寶盆icon
            var treasureBowlIcon = new TreasureBowlGameIconNode();
            treasureBowlIcon.setGameTypeAddProgressBar(VegasGameType.BLACKJACK);
            treasureBowlIcon.setScale(0.6);
            treasureBowlIcon.setPosition(JSVisibleSize.width - JSScreenSafeWidth - 105, 15);
            this.addChild(treasureBowlIcon, 21);
        }

        // 通知Server換大小桌 1小 2大 (印尼目前只有小桌 不過要加上這個server才能使用多張免費券)
        DataProcess.sendString("slot10_switch_bet 1");

        // 重要資料
        DataProcess.sendString("slot10_resume");
    },

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        // 先判斷返回是否能按
        if (!this._backMenuItem.isEnabled())
            return;

        this._backBtnClicked();
    },

    /**
     * Push Protocol
     */

    // 畫面出現動畫做完後
    viewDidAppear: function () {
        // 要註冊 Socket CMD監聽
        this._eventListener = GS.addListener(DataModal.vegasData.getCmdNotifyName(VegasGameType.BLACKJACK), this.notifyReceiveCommand.bind(this), this);

        // 直接重抓一次Socket
        this._processMessage();

        this._super();
    },

    // 畫面要結束
    viewWillDisappear: function () {
        // 要拿掉 Socket CMD監聽
        this._eventListener && cc.eventManager.removeListener(this._eventListener);
        this._eventListener = null;

        this._super();
    },

    /**
     * 創按鈕類的東西
     */
    // 創一般的按鈕
    _createNormalMenuItem: function (image, size, title, callback, target) {
        var itemNodes = [];

        for (var i = 0; i < 3; i++) {
            var node = itemNodes[i] = new cc.Node();
            node.setCascadeColorEnabled(true);
            node.setCascadeOpacityEnabled(true);

            var bgSprite = new ccui.Scale9Sprite(i === 2 ? "bj_btn_gray.png" : image);
            bgSprite.setPreferredSize(size);
            var wordSprite = new GSAutoSizeLabel(title, JSFontBoldName, 20, size, cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
            node.addChild(bgSprite);
            node.addChild(wordSprite);

            bgSprite.setPosition(size.width / 2, size.height / 2);
            wordSprite.setPosition(size.width / 2, size.height / 2);

            node.setContentSize(size);

            if (i === 1)
                node.setColor(JSColor.GRAY);
        }

        return new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], callback, target);
    },

    /**
     * 判斷現在應該要下什麼注額 (5.3.1取自中文德撲 只用到部分)
     */
    _getDefaultBetChips: function () {
        // 有免費券
        if (this._isHaveFreeTicket) {
            // 預設不使用
            this._freeTicketNode.useTicket(0);
            this._onFreeTicketUsageChange(null, 0);
            return 0;
        }

        // 前一手是免費券 但是免費券用完了，給最小注額
        if (this._isUseFreeTicket) {
            var slot10BetData = DataModal.vegasData.blackjackBetInfo;
            this._chipBetClicked(this._betButtonArray[0]);
            return slot10BetData.betArray[0];
        } else {
            // 清掉Double
            return this._betChips;
        }
    },

    /**
     * 更新下注金額
     */
    _setBetChips: function (chips) {
        this._betChips = chips;

        // 是否要使用免費券
        this._ledNode.setUseFreeTicket(this._isHaveFreeTicket);

        // 同步更新LED
        this._ledNode.setMoney(chips);
    },

    /**
     * 按鈕
     */
    // 按到儲值
    _purchaseClicked: function () {
        // 決勝排行榜埋點
        if (this._getIsVegasRankOpen())
            DataProcess.sendString("slot10_click_bill");

        // 去儲值頁
        PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
    },

    // 左右滑動箭頭
    _arrowChipClicked: function (sender) {
        var pos = this._scrollView.getContentOffset();
        var posX = Math.ceil(pos.x);

        var moveX;
        if (sender === this._chipArrowButtons[1]) {
            // 右邊箭頭
            if (posX < this._maxOffsetWidth)
                return;

            // 移動一個籌碼的位置
            var offsetX = (Math.ceil(posX / 50) - 1) * 50;
            moveX = offsetX <= this._maxOffsetWidth ? this._maxOffsetWidth : offsetX;

            this._scrollView.setContentOffsetInDuration(cc.p(moveX, 0), 0.3);
        } else {
            // 左邊箭頭
            if (posX > 0)
                return;

            // 移動一個籌碼的位置
            var offsetX = (Math.floor(posX / 50) + 1) * 50;
            moveX = offsetX >= 0 ? 0 : offsetX;
        }

        // 移動一個籌碼的位置
        this._scrollView.setContentOffsetInDuration(cc.p(moveX, 0), 0.3);

        // 關閉點擊事件
        this._chipArrowButtons[0].setEnabled(false);
        this._chipArrowButtons[1].setEnabled(false);
        this._scrollView.setTouchEnabled(false);

        // 滑動完畢開啟點擊
        this.runAction(cc.sequence(
            cc.delayTime(0.4),
            cc.callFunc(() => {
                // 滑動後確認最後的箭頭可否點擊
                var pos = this._scrollView.getContentOffset();
                var posX = Math.floor(pos.x);

                this._chipArrowButtons[0].setEnabled(posX < -1);
                this._chipArrowButtons[1].setEnabled(posX > this._maxOffsetWidth + 1);
                this._scrollView.setTouchEnabled(true);
            })
        ));
    },

    // 按到免費券+/-按鈕
    _onFreeTicketUsageChange: function (sender, usageNum) {
        var info = DataModal.vegasData.blackjackBetInfo;
        var freeBetMoney = (info && info.betArray) ? info.betArray[0] : 1000000;
        var betMoney = usageNum * freeBetMoney;

        this._cleanMenu.setEnabled(usageNum >= 1);

        // 更新下注金額
        this._setBetChips(betMoney);
        this._playCardMenu.setEnabled(usageNum >= 1);
    },

    // 按到賠率表
    _openRateInfoClicked: function () {
        DialogManager.addDialog(new VegasIntroDialog(VegasGameType.BLACKJACK));
    },

    // 下注籌碼
    _chipBetClicked: function (sender) {
        var blackjackInfo = DataModal.vegasData.blackjackBetInfo;
        var betMoneyArray = blackjackInfo.betArray;
        // 先判斷上限
        var betLimit = betMoneyArray[betMoneyArray.length - 1];
        var myMoney = DataModal.profileData.money;
        var newBetMoney = this._betChips;

        // 抓出是誰按的
        var clickedIndex = this._betButtonArray.findIndex(cur => cur === sender);
        newBetMoney += betMoneyArray[clickedIndex];

        // 是否超過上限
        var isMaxLimitMoney = false;

        // 判斷大小
        if (newBetMoney > betLimit) {
            isMaxLimitMoney = this;

            newBetMoney = betLimit;
        }

        if (myMoney >= newBetMoney || this._isHaveFreeTicket) {
            this._refreshBetBtn(sender);

            // 更新下注金額
            this._setBetChips(newBetMoney);

            // 更新畫面
            this._flagChangByState(this.StateType.INIT);

            // 撥放音樂
            if (clickedIndex % 3 === 2)
                Vegas_MusicUtility.playEffect("Music/Effect/chipwin.mp3");
            else
                Vegas_MusicUtility.playEffect("Music/Effect/chipone.mp3");

            if (isMaxLimitMoney) {
                DialogManager.addDialog(new AvatarDialog({
                    content: LocalizedString.Vegas("投注已達上限")
                }));
            }
        } else {
            this._cleanClicked();

            // 錢不夠, 詢問是否要跳儲值
            DialogManager.addDialog(new NoMoneyDialog(newBetMoney - myMoney));
        }
    },

    // 清除
    _cleanClicked: function () {
        // 清掉下注金額
        this._setBetChips(0);

        // 籌碼歸位
        this._chooseLightSp && this._chooseLightSp.setVisible(false);

        this._betButtonArray.forEach(cur => {
            // 全部可點擊 & 下沈
            cur.setEnabled(true);
            cur.setPositionY(18);
        });

        // 更新畫面
        this._flagChangByState(this.StateType.CLEAR_CHIPS);

        // 撥放音樂
        Vegas_MusicUtility.playEffect("Music/Effect/blackjack_btn1.mp3");
    },

    // 發牌
    _playCardClicked: function () {
        // 要判斷是否夠錢
        var myMoney = DataModal.profileData.money;
        if (myMoney >= this._betChips || this._isHaveFreeTicket) {
            DataProcess.sendString(JSStringUtility.format("slot_machine 10 %d", this._betChips));

            // 直接變發牌中
            this._flagChangByState(this.StateType.DEALING_CARD);

            // 更新免費券
            if (this._isHaveFreeTicket) {
                DataModal.vegasData.freeTicket.Blackjack -= this._freeTicketNode.getTicketUsage();
                var freeTicketCount = DataModal.vegasData.freeTicket.Blackjack;
                this._freeTicketNode.setFreeTicketCount(freeTicketCount);
                this._isUseFreeTicket = true;
            }

            this._freeTicketNode.setVisible(this._isHaveFreeTicket && freeTicketCount > 0);          // 判斷免費券還有嗎

            // 撥放音樂
            Vegas_MusicUtility.playEffect("Music/Effect/blackjack_btn1.mp3");

            // AppsFlyer埋點
            GSAppsFlyerWrapper.logEvent("casino");

            // 存下遊戲紀錄
            this._savePlayerRecord();

            // Firebase 埋點
            var eventName = GSAnalyticsAdapter.record.game + "娛樂城玩法";
            GSAnalyticsAdapter.logEventByFirebaseAll(eventName, ["大廳"], ["21點下注"]);
        } else {
            // 錢不夠, 詢問是否要跳儲值
            DialogManager.addDialog(new NoMoneyDialog(this._betChips - myMoney));
        }
    },

    // 補牌
    _hitCardClicked: function () {
        DataProcess.sendString("slot10_hitP");

        // 直接變發牌中
        this._flagChangByState(this.StateType.DEALING_CARD);

        // 撥放音樂
        Vegas_MusicUtility.playEffect("Music/Effect/blackjack_btn2.mp3");
    },

    // 加倍
    _doubleClicked: function () {
        // 要判斷是否夠錢
        var myMoney = DataModal.profileData.money;
        if (myMoney >= this._betChips) {
            this._isNeedDouble = true;

            DataProcess.sendString("slot10_double");

            // 直接變發牌中
            this._flagChangByState(this.StateType.DEALING_CARD);

            // 出現加倍框動畫
            this._ledNode.showDoubleEffect(this._betChips);
        } else {
            // 錢不夠, 詢問是否要跳儲值
            DialogManager.addDialog(new NoMoneyDialog(this._betChips - myMoney));
        }
    },

    // 不補牌
    _standClicked: function () {
        DataProcess.sendString("slot10_stand");

        // 直接變發牌中
        this._flagChangByState(this.StateType.DEALING_CARD);

        // 撥放音樂
        Vegas_MusicUtility.playEffect("Music/Effect/blackjack_btn1.mp3");
    },

    _refreshBetBtn: function (btn) {
        this._betButtonArray.forEach(cur => {
            if (btn === cur) {
                cur.setPositionY(25);
                if (this._chooseLightSp) {
                    this._chooseLightSp.setPositionX(cur.getPositionX());
                    this._chooseLightSp.setVisible(true);
                }
            } else {
                cur.setPositionY(18);
            }
        });
    },

    /**
     * 處理現在畫面按鈕的出現與否
     */
    _flagChangByState: function (stateType) {
        this._stateType = stateType;
        switch (stateType) {
            case this.StateType.INIT:                   // 一開始的狀態
                // 初始狀態 有免費券的話要把後面小注籌碼拿掉
                this._chipsNode.setVisible(!this._isHaveFreeTicket);

                this._isFirstHit = true;
                this._isUseFreeTicket = false;  // 是否使用免費券
                this._isNeedDouble = false;

                // 把提示畫面提上去
                this._effectLayer.setLocalZOrder(30);
                this._mainMenu.setLocalZOrder(20);

                // 清掉畫面
                this._effectLayer.clean();
                this._pokerLayer.clean();

                // 把按鈕設哪些可以按
                this._backMenuItem.setEnabled(true);
                this._chipsDummyTouch && this._chipsDummyTouch.setVisible(false);

                // 把按鈕設哪些可以看到
                this._cleanMenu.setVisible(true);
                this._playCardMenu.setVisible(true);
                this._hitCardMenu.setVisible(false);
                this._doubleMenu.setVisible(false);
                this._standMenu.setVisible(false);

                // 判斷是否有免費券 有的話 只有使用一張才要把清除設成不能按
                this._cleanMenu.setEnabled(!this._isHaveFreeTicket || (this._freeTicketNode.getTicketUsage() > 1));

                // 判斷是否有免費券 有的話 沒有使用任何一張的話要把發牌設成不能按
                this._playCardMenu.setEnabled(!this._isHaveFreeTicket || (this._freeTicketNode.getTicketUsage() > 0));

                // 打開免費券按鈕(+/-) 裡面會判斷是否使用多張
                this._freeTicketNode.setButtonEnabled(true);

                // 顯示下注的教學
                this._showBetTeach();
                break;

            case this.StateType.CLEAR_CHIPS:            // 清除下注金額
                if (this._freeTicketNode.isVisible()) {
                    // 有免費券需要刷新使用數量
                    this._freeTicketNode.useTicket(0);
                    this._setBetChips(0);
                    this._onFreeTicketUsageChange(null, 0);
                    this._cleanMenu.setEnabled(false);
                } else {
                    // 清掉下注金額
                    this._setBetChips(0);

                    // 把提示畫面縮下去
                    this._effectLayer.setLocalZOrder(14);

                    this._mainMenu.setLocalZOrder(13);

                    // 出現提示
                    this._effectLayer.showBetHint();
                }

                break;

            case this.StateType.DEALING_CARD:           // 發牌中
                // 把按鈕設哪些不能按
                this._backMenuItem.setEnabled(false);
                this._chipsDummyTouch && this._chipsDummyTouch.setVisible(true);
                this._freeTicketNode.setButtonEnabled(false);

                this._hitCardMenu.setEnabled(false);
                this._standMenu.setEnabled(false);

                // 把按鈕設哪些可以看到
                this._cleanMenu.setVisible(false);
                this._playCardMenu.setVisible(false);
                this._hitCardMenu.setVisible(true);
                this._doubleMenu.setVisible(false);
                this._standMenu.setVisible(true);

                break;

            case this.StateType.CAN_HIT:
                // 把按鈕設哪些不能按
                this._backMenuItem.setEnabled(false);
                this._chipsDummyTouch && this._chipsDummyTouch.setVisible(true);
                this._hitCardMenu.setEnabled(true);
                this._standMenu.setEnabled(true);

                // 把按鈕設哪些可以看到
                this._cleanMenu.setVisible(false);
                this._playCardMenu.setVisible(false);
                this._hitCardMenu.setVisible(true);
                this._doubleMenu.setVisible(this._isFirstHit && !this._isUseFreeTicket);
                this._standMenu.setVisible(true);

                this._isFirstHit = false;

                break;
            default:
                break;
        }
    },

    /**
     * 顯示下注的教學
     */
    _showBetTeach: function () {
        // 顯示下注的教學
        var haveShowHint = parseInt(GS.localStorage.getItem("ShowBlackjackTeach", "0")) === 1;
        if (!haveShowHint && !this._isHaveFreeTicket && this._scrollView) {
            var touchFunc = () => {
                // 停止scroll的滑動
                var posX = this._scrollView.getContentOffset().x;
                this._scrollView.setContentOffsetInDuration(cc.p(posX, 0), 0);

                // 已完成教學
                GS.localStorage.setItem("ShowBlackjackTeach", "1");
            };

            // 顯示教學提示
            this._effectLayer.showTeachBetHint(touchFunc);
            this._scrollView.setContentOffsetInDuration(cc.p(this._maxOffsetWidth, 0), 2);
        }
    },

    /**
     * 處理Socket CMD
     */
    _processMessage: function () {
        var newMessageCommand = DataModal.vegasData.popQueuedMessage(VegasGameType.BLACKJACK);
        if (newMessageCommand) {
            switch (newMessageCommand.key) {
                case "slot10_double":
                    // 判斷金額移到按鈕按下時就做了
                    this._processMessage();
                    break;
                case "slot10_playP":
                    // 設定可以出牌
                    this._flagChangByState(this.StateType.CAN_HIT);

                    this._processMessage();
                    break;
                case "slot10_hitP":
                    // ["22",["2K","22"],["12","0"],"0"]
                    // [此張牌, [牌組], [點數1, 點數2], 0:發牌 1:翻牌(只有電腦才有翻牌)]
                    this._enableProcessMessage = false;

                    var jsonValue = JSON.parse(newMessageCommand.value);

                    var cardNumber = JSCodeUtility.getStringValue(jsonValue[0]);
                    if (cardNumber.length) {
                        var cardArray = jsonValue[1];
                        var pointArray = jsonValue[2];

                        if (cardArray && pointArray) {
                            this._pokerLayer.dealCard(true, cardNumber, cardArray.length - 1, pointArray);
                        }
                    }

                    // 設定發牌中
                    this._flagChangByState(this.StateType.DEALING_CARD);

                    break;
                case "slot10_hitD":
                    // ["22",["2K","22"],["12","0"],"0"]
                    // [此張牌, [牌組], [點數1, 點數2], 0:發牌 1:翻牌(只有電腦才有翻牌)]
                    // [] 代表是要蓋牌的
                    this._enableProcessMessage = false;

                    var jsonValue = JSON.parse(newMessageCommand.value);

                    var cardNumber = JSCodeUtility.getStringValue(jsonValue[0]);
                    if (cardNumber.length) {
                        var cardArray = jsonValue[1];
                        var pointArray = jsonValue[2];

                        if (cardArray && pointArray) {
                            this._pokerLayer.dealCard(false, cardNumber, cardArray.length - 1, pointArray);
                        }
                    } else {
                        // 要蓋牌的
                        this._pokerLayer.dealCard(false, cardNumber, 1);
                    }

                    // 設定發牌中
                    this._flagChangByState(this.StateType.DEALING_CARD);

                    break;
                case "slot10_finish":
                    //slot10_finish X Y    Y=玩家可拿回的tmoney; X可以是:{ lose:輸 bust:爆 push:平手 win:贏牌 blackjack:BJ 5dragon:五龍 777:777 flush_straight:同花順
                    this._enableProcessMessage = false;

                    var valueArray = newMessageCommand.value.split(" ");
                    if (valueArray.length > 1) {
                        var winString = valueArray[0];
                        var winMoney = parseInt(valueArray[1]);

                        switch (winString) {
                            case "lose":
                                // 玩家輸
                                this._pokerLayer.setScoreLose(true);
                                break;
                            case "win":
                            case "blackjack":
                            case "5dragon":
                            case "777":
                            case "flush_straight":
                                // 電腦輸
                                this._pokerLayer.setScoreLose(false);
                                break;
                        }

                        // 先delay一下在show
                        this.runAction(cc.sequence(
                            cc.delayTime(0.5),
                            cc.callFunc(function () {
                                this._effectLayer.showFinishResult(winString, winMoney);
                            }, this)
                        ));

                        // 重新抓免費券
                        DataProcess.sendString("slot10_free");
                    }

                    break;
                case "slot10_reward":
                    // 回來初始畫面
                    this._flagChangByState(this.StateType.INIT);
                    break;
                default:
                    this._processMessage();
                    break;
            }
        }

        return !!newMessageCommand;
    },

    // 滑動結束
    scrollViewDidEndScroll: function () {
        var posX = this._scrollView.getContentOffset().x;

        this._chipArrowButtons[0].setEnabled(posX < -1);
        this._chipArrowButtons[1].setEnabled(posX > this._maxOffsetWidth + 1);
    },

    /**
     * 通知
     */
    // 收到SocketCMD
    notifyReceiveCommand: function () {
        // 先判斷現在是否可以處理CMD
        if (this._enableProcessMessage)
            this._processMessage();
    },

    // 發完牌 要把處理訊息設定好
    notifyBlackjackEnableCMD: function () {
        this._enableProcessMessage = true;
        this._processMessage();
    },

    // 結算好了
    notifyBlackjackResultDone: function () {
        var freeTicketCount = DataModal.vegasData.freeTicket.Blackjack;
        this._isHaveFreeTicket = freeTicketCount > 0;

        // 更新免費券
        this._freeTicketNode.setVisible(this._isHaveFreeTicket);
        this._freeTicketNode.setFreeTicketCount(freeTicketCount);

        this._chipsNode.setVisible(!this._isHaveFreeTicket);

        // 如果有double要用double的錢去算
        var bet = (this._isNeedDouble) ? this._betChips * 2 : this._betChips;
        // 更新聚寶盆 透過網址
        DataModal.treasureBowlData.treasureBowlParam && DataModal.treasureBowlData.updateDataBy(bet);

        // 把下注金額重置
        this._setBetChips(this._getDefaultBetChips());

        // 把畫面設成初始
        this._flagChangByState(this.StateType.INIT);

        // 把Socket CMD接收打開
        this._enableProcessMessage = true;
        this._processMessage();

        // 通知外面動畫結束，檢查有沒有事情要做
        this.notifyVegasGameFinished();
    },

    // 更新免費券
    notifyRefreshFreeTicket: function () {
        var freeTicketCount = DataModal.vegasData.freeTicket.Blackjack;
        this._isHaveFreeTicket = freeTicketCount > 0;

        // 是初始狀態再更新
        if (this._stateType === this.StateType.INIT) {
            // 更新免費券
            this._freeTicketNode.setVisible(this._isHaveFreeTicket);
            this._freeTicketNode.setFreeTicketCount(freeTicketCount);

            this._chipsNode.setVisible(!this._isHaveFreeTicket);

            // 把下注金額重置
            this._setBetChips(this._getDefaultBetChips());
        }
    },

    // 下注失敗
    notifySlotFailCMD: function (event) {
        if (event && event.getUserData()) {
            // 把按鈕打開
            this._flagChangByState(this.StateType.INIT);
        }

        // 更新免費券
        DataProcess.sendString("slot10_free");
    },

    // 斷線重連牌局
    notifyCheckBJResume: function (event) {
        var userData = event.getUserData();
        if (userData) {
            var jsonValue = JSON.parse(userData);

            // 先拿掉Loading
            GSLoading.removeLoadingView();

            // 先算出現在預設是要大注還是小注
            var slot10BetData = DataModal.vegasData.blackjackBetInfo;
            var freeTicketCount = DataModal.vegasData.freeTicket.Blackjack;
            var defaultIndex = (freeTicketCount === 0) ? slot10BetData.defaultIndex : 0;

            var chipsNode = this._chipsNode;
            chipsNode.removeAllChildren();

            // scrollView
            var scrollLayer = new cc.Layer();
            var scrollSize = cc.size(150, 50);
            var scrollView = this._scrollView = new cc.ScrollView(scrollSize, scrollLayer);
            scrollView.setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
            scrollView.setDelegate(this);
            scrollView.setBounceable(false);
            scrollView.setPosition(180 + JSScreenBonusHalfWidth, 27);
            chipsNode.addChild(scrollView);

            var chipsString = slot10BetData.betArray;
            var chipsLen = chipsString.length;

            var maxWidth = 50 * chipsLen;
            this._maxOffsetWidth = scrollSize.width - maxWidth;
            scrollView.setContentSize(cc.size(maxWidth, 50));

            var chosePos = cc.p(25, 25);
            this._betButtonArray = [];
            var defaultBetChip;
            chipsString.forEach((curChip, index) => {
                var chipNode = new ccui.Scale9Sprite();
                chipNode.setCascadeColorEnabled(true);
                chipNode.setCascadeOpacityEnabled(true);
                chipNode.setPreferredSize(cc.size(50, 50));

                var chipRes;
                if (curChip <= 1000000) {
                    // 紅籌碼
                    chipRes = "#vegas_cycle_chip_red.png";
                } else if (curChip > 1000000 && curChip <= 10000000) {
                    // 藍色
                    chipRes = "#vegas_cycle_chip_blue.png";
                } else if (curChip > 10000000 && curChip <= 100000000) {
                    // 綠色
                    chipRes = "#vegas_cycle_chip_green.png";
                } else if (curChip > 100000000 && curChip <= 500000000) {
                    // 橘色
                    chipRes = "#vegas_cycle_chip_orange.png";
                } else if (curChip > 500000000) {
                    // 紅黑色
                    chipRes = "#vegas_cycle_chip_red_gray.png";
                }

                if (!chipRes)
                    return;

                // 籌碼圖
                var chipSprite = new cc.Sprite(chipRes);
                chipSprite.setPosition(25, 25);
                chipNode.addChild(chipSprite);

                // 上面的數字(number, prefixName, numberSize, dotSize, unitSize, dotLength = 2, maxWidth = 0, numberFormat)
                var numberNode = new NumberSimpleNode(curChip, "vegas_chip_num", cc.size(10, 12), cc.size(10, 10), [cc.size(9, 10), cc.size(9, 10), cc.size(25, 10)], 2, 50, "%d");
                numberNode.setPosition(25, 25);
                chipNode.addChild(numberNode);

                var chipButton = new GSControlButton(chipNode);
                chipButton.setPosition(25 + 50 * index, (index === defaultIndex) ? 25 : 18);
                chipButton.addTouchUpInsideAction(this._chipBetClicked, this);
                chipButton.enableTouchCancel(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
                scrollLayer.addChild(chipButton);

                if (index === defaultIndex) {
                    chosePos = cc.p(25 + 50 * index, 25);
                    defaultBetChip = chipButton;
                }

                this._betButtonArray.push(chipButton);
            });

            // 選取的燈光
            var chooseLightSp = this._chooseLightSp = new cc.Sprite("#vegas_chip_light.png");
            chooseLightSp.setPosition(chosePos);
            scrollLayer.addChild(chooseLightSp);

            // 左右按鈕
            this._chipArrowButtons = [];
            for (var i = 0; i < 2; i++) {
                // 擋touch
                var dummyTouch = new DummyTouchLayer(cc.size(182 + JSScreenBonusHalfWidth, 50));
                dummyTouch.setPosition(-2 + (333 + JSScreenBonusHalfWidth) * i, 25);
                chipsNode.addChild(dummyTouch);

                var chipNode = new ccui.Scale9Sprite();
                chipNode.setCascadeColorEnabled(true);
                chipNode.setCascadeOpacityEnabled(true);
                chipNode.setPreferredSize(cc.size(18, 26));

                var arrowSprite = new cc.Sprite("#vegas_arrow_01.png");
                arrowSprite.setFlippedX(!!i);
                arrowSprite.setPosition(9, 13);
                chipNode.addChild(arrowSprite);

                var chipNodeGray = new ccui.Scale9Sprite();
                chipNodeGray.setCascadeColorEnabled(true);
                chipNodeGray.setCascadeOpacityEnabled(true);
                chipNodeGray.setPreferredSize(cc.size(18, 26));

                var arrowGraySprite = new cc.Sprite("#vegas_arrow_02.png");
                arrowGraySprite.setFlippedX(!!i);
                arrowGraySprite.setPosition(9, 13);
                chipNodeGray.addChild(arrowGraySprite);

                var arrowButton = new GSControlButton(chipNode);
                arrowButton.setPosition(172 + (168 * i) + JSScreenBonusHalfWidth, 48);
                arrowButton.setBackgroundSpriteForState(chipNodeGray, cc.CONTROL_STATE_DISABLED);
                arrowButton.addTouchUpInsideAction(this._arrowChipClicked, this);
                chipsNode.addChild(arrowButton);

                this._chipArrowButtons.push(arrowButton);
            }

            // 擋籌碼不能點擊
            var chipsDummyTouch = this._chipsDummyTouch = new DummyTouchLayer(cc.size(185, 50));
            chipsDummyTouch.setPosition(163 + JSScreenBonusHalfWidth, 25);
            chipsDummyTouch.setVisible(false);
            this.addChild(chipsDummyTouch, 40);

            // 先判斷是否使用免費券
            this.notifyRefreshFreeTicket();

            // 最後 重置畫面
            this._flagChangByState(this.StateType.INIT);

            // 是否有牌局重現
            var isReconnect = JSCodeUtility.getBooleanValue(jsonValue["resume"]);

            // 預設下注金額
            if (defaultBetChip) {
                // 滑動到預設的地方
                this._scrollView.setContentOffsetInDuration(cc.p(-chosePos.x + 25, 0), 0);

                // 預設點擊的籌碼
                if (isReconnect)
                    this._refreshBetBtn(defaultBetChip);
                else
                    this._chipBetClicked(defaultBetChip);

                // 把下注金額重置
                this._setBetChips(this._getDefaultBetChips());
            }

            // 牌局重現
            if (isReconnect) {
                // 關掉說明
                GS.dispatchCustomEvent("NotifyCloseBlackjackInfo");

                // 先送場編給自己
                GS.dispatchCustomEvent("NotifyRefreshVegasSerialNumber", jsonValue["gid"]);

                // 斷線重連的提醒視窗
                var dialogNode = new cc.Node();
                this.addChild(dialogNode, 20);

                var dialogBG = new ccui.Scale9Sprite("bj_rule_bg01.png");
                dialogBG.setPreferredSize(cc.size(250, 100));
                dialogBG.setPosition(JSScreenMidPos);
                dialogNode.addChild(dialogBG);

                var dialogText = LocalizedString.Blackjack("恢復未完成牌局中");
                var dialogLabel = new cc.LabelTTF(dialogText, JSFontBoldName, 16);
                dialogLabel.setPosition(JSScreenMidPos);
                dialogNode.addChild(dialogLabel);

                var textIndex = 0;
                var dotString = [".", "..", "...", ""];
                dialogLabel.runAction(cc.repeatForever(cc.sequence(
                    cc.delayTime(0.5),
                    cc.callFunc(function () {
                        textIndex %= 4;
                        dialogLabel.setString(dialogText + dotString[textIndex]);
                        textIndex++;
                    })
                )));

                // 加檔touch
                var dummyTouch = new DummyTouchLayer(JSVisibleSize);
                dialogNode.addChild(dummyTouch);

                // 下注金額
                var betChips = JSCodeUtility.getIntValue(jsonValue["cost"]);
                this._setBetChips(betChips);

                // 判斷加倍按鈕是否可以按
                this._isFirstHit = JSCodeUtility.getIntValue(jsonValue["double"]) === 1;

                // 玩家跟Dealer的牌
                var playerJson = jsonValue["player"];
                var playerCards = playerJson["cardlist"];
                var playerScores = playerJson["score"];
                var dealerJson = jsonValue["dealer"];
                var dealerCards = dealerJson["cardlist"];
                var dealerScores = dealerJson["score"];
                var index = 0;
                do {
                    // 玩家發牌
                    if (playerCards.length)
                        this._pokerLayer.dealCard(true, playerCards.shift(), index, playerScores);
                    else
                        break;

                    if (dealerCards.length)
                        this._pokerLayer.dealCard(false, dealerCards.shift(), index, dealerScores);
                    else if (index === 1) {
                        // 要補一張蓋著的牌
                        this._pokerLayer.dealCard(false, "", 1);
                    }

                    index++;
                } while (index < 2);

                // 發完兩張後 要發之後的
                for (var i = 0, len = playerCards.length; i < len; i++) {
                    this._pokerLayer.dealCard(true, playerCards.shift(), index, playerScores);
                }
                for (var i = 0, len = dealerCards.length; i < len; i++) {
                    this._pokerLayer.dealCard(false, dealerCards.shift(), index, dealerScores);
                }

                // 切換狀態
                this._flagChangByState(this.StateType.DEALING_CARD);

                // 判斷是否有用免費券
                var freeTicketCount = DataModal.vegasData.freeTicket.Blackjack;
                this._isUseFreeTicket = JSCodeUtility.getIntValue(jsonValue["freeplay"]) === 1;
                if (this._isUseFreeTicket) {
                    this._freeTicketNode.setFreeTicketCount(freeTicketCount);
                }
                this._freeTicketNode.setVisible(this._isUseFreeTicket && freeTicketCount > 0);
                this._chipsNode.setVisible(!this._isUseFreeTicket);

                // 設定監聽發完牌
                var self = this;
                var listener = GS.addListener("NotifyBlackjackEnableCMD", function () {
                    // 把Dialog拿掉
                    dialogNode.removeFromParent();

                    // 切換狀態
                    self._flagChangByState(self.StateType.CAN_HIT);

                    // 把監聽拿掉
                    cc.eventManager.removeListener(listener);
                }, this);
            } else {
                // 要判斷是否要加說明頁
                if (DataModal.vegasData.showBlackjackInfo) {
                    DataModal.vegasData.showBlackjackInfo = false;
                    this.addChild(new BlackjackInfoLayer(), 100);
                }
            }
        }
    }
});
