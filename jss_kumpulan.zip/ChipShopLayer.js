/**
 * v5.4.5 商城 - 大廳德撲幣商城
 * created by lichieh on 2022/10/25
 */
var ChipShopLayer = cc.Layer.extend({
    // 商品一個cell有幾個
    PRODUCT_CELL_COUNT: 3,

    ctor: function () {
        this._super();

        this._param = [];
        this._totalCellCount = 0;

        var defaultTab = DataModal.shopData.shopOpenTag || ShopProductType.LOVE;

        var tabTitles = [
            {
                title: "富豪",
                icon: "#shop_pic_icon_rich.png",
                tabType: ChipShopLayer.TabeType.RICH,
                productType: ShopProductType.RICH
            },
            {
                title: "風水",
                icon: "#shop_pic_icon_fengshui.png",
                tabType: ChipShopLayer.TabeType.FENGSHUI,
                productType: ShopProductType.FENGSHUI
            },
            {
                title: "求愛",
                icon: "#shop_pic_icon_love.png",
                tabType: ChipShopLayer.TabeType.LOVE,
                productType: ShopProductType.LOVE
            },
            {
                title: "話題",
                icon: "#shop_pic_icon_talk.png",
                tabType: ChipShopLayer.TabeType.TALK,
                productType: ShopProductType.TALK
            },
            {
                title: "美食",
                icon: "#shop_pic_icon_food.png",
                tabType: ChipShopLayer.TabeType.FOOD,
                productType: ShopProductType.FOOD
            },
            {
                title: "禮包",
                icon: "#shop_pic_icon_gift.png",
                tabType: ChipShopLayer.TabeType.GIFT,
                productType: ShopProductType.GIFT
            }
        ];

        // 按鈕旁邊的線
        var lineSprite = new cc.Sprite("#btn_function_line.png");
        lineSprite.setScaleY(5.5);
        lineSprite.setPosition(98 + JSScreenSafeWidth, 125 + JSScreenBonusHeight);
        this.addChild(lineSprite);

        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        this.addChild(menu);

        var defaultBtn;
        this._tabItems = [];
        var btnSize = cc.size(95, 38);
        for (var i = 0, len = tabTitles.length; i < len; i++) {
            var tab = tabTitles[i];
            var btnImages = ["lobby_bg_gradual.png", "lobby_btn_down_gold.png", "lobby_btn_down_gold.png"];
            var itemNodes = ButtonUtility.createArrayScale9NodesWithIcon(btnImages, btnSize, tab.icon, 1, LocalizedString.Shop(tab.title), 12, cc.color(JSColor.WHITE), 5, false);
            itemNodes.forEach((cur, idx) => {
                if (idx > 0) {
                    cur.bg.setPreferredSize(cc.size(107, 38));
                    cur.bg.setPositionX(53);
                }
                cur.label.setAnchorPoint(0, 0.5);
                cur.label.setPosition(38, 20);
                cur.iconSp.setPosition(22, 20);
            });
            itemNodes[2].setOpacity(255);

            var tabItem = this._tabItems[tab.tabType] = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._tabClicked, this);
            tabItem.productType = tab.productType;
            tabItem.setAnchorPoint(0, 1);
            tabItem.setPosition(JSScreenSafeWidth, JSVisibleSize.height - TITLE_BG_HEIGHT - (i * btnSize.height));
            menu.addChild(tabItem);

            if (tab.productType === defaultTab)
                defaultBtn = tabItem;
        }

        // 列表
        var mainLayer = this._mainLayer = new cc.Layer();
        mainLayer.setCascadeOpacityEnabled(true);
        var tableView = this._tableView = new cc.TableView(this, cc.size(340, JSVisibleSize.height - TITLE_BG_HEIGHT - 35), mainLayer);
        tableView.setCascadeOpacityEnabled(true);
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setPosition(135 + JSScreenBonusHalfWidth, 1);
        this.addChild(tableView);

        // 錢
        var chipNode = new TitleChipsNode(true);
        chipNode.setPurchaseButtonVisible(true);
        chipNode.setPosition(118 + JSScreenBonusHalfWidth, 239 + JSScreenBonusHeight);
        this.addChild(chipNode);

        // 背包按鈕
        var backpackBtn = this._backpackBtn = ButtonUtility.createSimpleButton("lobby_btn_01.png", cc.size(50, 20), LocalizedString.Shop("背包"), JSColor.BLACK, 12);
        backpackBtn.setPosition(479 + JSScreenBonusHalfWidth, 239 + JSScreenBonusHeight);
        backpackBtn.addTouchUpInsideAction(() => {
            // 埋點 # 15: 點德撲幣商城背包
            DataProcess.sendString("track_koin_luxy 15");

            DialogManager.addDialog(new BackpackDialog(), false);
        }, this);
        this.addChild(backpackBtn);

        // 點擊預設頁籤
        var choseBtn = defaultBtn || this._tabItems[ChipShopLayer.TabeType.RICH];
        this._tabClicked(choseBtn);
        this._setBadgeVisible(choseBtn, true);

        // 加上Loading
        this._startLoading();

        if (DataModal.shopData.getShopItemDone)
            this._refreshView();
        else
            DataModal.shopData.startGetInfo();

        //註冊
        GS.addListener("NotifyShopDataDone", this.notifyShopDataDone.bind(this), this);
    },

    /**
     * get購買按鈕的相關資訊用於引導使用
     */
    getBackpackIntro: function () {
        return {
            // 按鈕尺寸
            contentSize: this._backpackBtn.getContentSize(),
            // 按鈕的位置(這邊get到AnchorPointcc.p(0.5, 0.5) 但是引導挖空的AnchorPoint是在cc.p(0, 0) 所以要再扣掉尺寸一半
            pos: cc.pAdd(this._backpackBtn.getPosition(), cc.p(-25, -10))
        };
    },

    _refreshView: function () {
        this._stopLoading();

        var param = DataModal.shopData.getShopProductByType(this._curProductType);

        // 商品一個cell有3個
        this._param = [];
        var totalCount = Math.ceil(param.length / this.PRODUCT_CELL_COUNT);
        this._totalCellCount = totalCount;
        for (var i = 0; i < totalCount; i++) {
            this._param[i] = [];
            for (var j = 0; j < this.PRODUCT_CELL_COUNT; j++) {
                var productParam = param[i * this.PRODUCT_CELL_COUNT + j];
                productParam && this._param[i].push(productParam);
            }
        }

        this._tableView.reloadData(true);
    },

    _setBadgeVisible: function (tabBtn, isVisible) {
        if (!isVisible && !tabBtn.badgeNode)
            return;

        if (!tabBtn.badgeNode) {
            var contentSize = tabBtn.getContentSize();
            var badge = tabBtn.badgeNode = new BadgeNode();
            badge.setPosition(contentSize.width, contentSize.height - 2);
            badge.useDefaultStyle();
            tabBtn.addChild(badge);
        }
        tabBtn.badgeNode.setVisible(isVisible);
    },

    // 加loading
    _startLoading: function () {
        this._stopLoading();

        var loadingSp = this._loadingSp = new GSLoadingSprite();
        loadingSp.setPosition(JSScreenMidPos);
        this.addChild(loadingSp);

        loadingSp.start();
    },

    // 停止loading
    _stopLoading: function () {
        if (this._loadingSp) {
            this._loadingSp.removeFromParent();
            this._loadingSp = undefined;
        }
    },

    /**
     * tab點擊
     */
    _tabClicked: function (sender) {
        this._tabItems.forEach(cur => cur.setEnabled(true));
        sender.setEnabled(false);

        this._curProductType = sender.productType;

        this._refreshView();

        this._setBadgeVisible(sender, false);
    },

    /**
     * 通知
     */
    notifyShopDataDone: function () {
        this._refreshView();
    },

    /**
     * TableView delegate
     */
    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        if (cell == null) {
            cell = new ChipShopProductCell();
            cell.setAnchorPoint(cc.p(0, 0));
        }

        cell.refreshCell(this._param[idx]);

        return cell;
    },

    numberOfCellsInTableView: function () {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function () {
        return cc.size(340, 120);
    }
});

ChipShopLayer.TabeType = {
    RICH: 0,            // 富豪
    FENGSHUI: 1,        // 風水
    LOVE: 2,            // 愛情
    TALK: 3,            // 話題
    FOOD: 4,            // 美食
    GIFT: 5             // 禮包
};