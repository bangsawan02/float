/**
 *Domino每日輪盤獎勵顯示Node
 */
var DailyLuckyWheelFinishNode = cc.Node.extend({
    ctor: function () {
        this._super();

        this.setPositionY(-350);
        this._isFinish = false;

        // 背景黑色漸層
        var gradientLayer = new cc.LayerGradient(cc.color(0, 0, 0, 255), cc.color(0, 0, 0, 200), cc.p(0, -1));
        gradientLayer.setContentSize(cc.size(440, 115));
        gradientLayer.setPosition(34 + JSScreenBonusHalfWidth, 1);
        this.addChild(gradientLayer);

        // 金框
        var goldFrameSp = new ccui.Scale9Sprite("lobby_recommend.png");
        goldFrameSp.setPreferredSize(cc.size(445, 120));
        goldFrameSp.setPosition(256 + JSScreenBonusHalfWidth, 61);
        this.addChild(goldFrameSp);

        var titleArr = ["#daily_lucky_wheel_word_reward.png", "#daily_lucky_wheel_word_addition.png", "#daily_lucky_wheel_word_VIP_bonus.png"];
        var titleScaleArr = [1, 1, 0.9];
        var posArr = [cc.p(114, 98), cc.p(256, 98), cc.p(398, 98)];
        this._rewardLabel = [];
        for (var i = 0; i < 3; i++) {
            // 創三個獎勵標題+下方框框
            var pos = cc.p(posArr[i].x + JSScreenBonusHalfWidth, posArr[i].y);
            var titleSp = new cc.Sprite(titleArr[i]);
            titleSp.setScale(titleScaleArr[i]);
            titleSp.setPosition(pos);
            this.addChild(titleSp);

            var rewardBgSp = new ccui.Scale9Sprite("daily_lucky_wheel_pic_bar.png");
            rewardBgSp.setPreferredSize(cc.size(100, 25));
            rewardBgSp.setPosition(pos.x, pos.y - 23);
            this.addChild(rewardBgSp);

            //文字內容
            var rewardLabel = this._rewardLabel[i] = new cc.LabelTTF("", JSFontName, 16);
            rewardLabel.enableStroke(JSColor.BLACK, 2);
            rewardLabel.setPosition(rewardBgSp.getPosition());
            this.addChild(rewardLabel);
        }

        // 兩個X
        for (var i = 0; i < 2; i++) {
            var xSp = new cc.Sprite("#num_11_x.png");
            xSp.setPosition(185 + i * 142 + JSScreenBonusHalfWidth, 77);
            this.addChild(xSp);
        }

        // 金幣圖案
        var chipSp = new cc.Sprite("#chip_pic.png");
        chipSp.setPosition(76 + JSScreenBonusHalfWidth, 36);
        chipSp.setScale(2);
        this.addChild(chipSp);

        // 得獎金錢數量
        var totalMoneyNode = this._totalMoneyNode = new GSSpriteNumberNode({
            number: 0,
            numStr: "#number_07_",
            dotStr: ",",
            addDot: true,
            spW: 17,
            spH: 32,
            dotW: 7,
            isDotHeightAsNum: true,
        });
        totalMoneyNode.setPosition(96 + JSScreenBonusHalfWidth, 36);
        totalMoneyNode.setAnchorPoint(0, 0.5);
        this.addChild(totalMoneyNode);

        // 領取按鈕
        var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", cc.size(100, 32), "Ambil", 16, JSColor.BLACK);
        var collectBtn = this._collectBtn = new GSControlButton(itemNodes[0]);
        collectBtn.addTouchUpInsideAction(this._collectClicked, this);
        collectBtn.setEnabled(false);
        collectBtn.setPosition(JSScreenBonusHalfWidth + 400, 36);
        this.addChild(collectBtn);
    },

    /**
     * 按下COLLECT按鈕
     * @private
     */
    _collectClicked: function () {
        if (this._isFinish) {
            this._collectBtn.setEnabled(false);
            // 首次跳出教學頁
            if (parseInt(GS.localStorage.getItem("dailyLuckyWheelTeachDone", "0")) === 0) {
                var teachLayer = new DailyLuckyWheelTeachLayer();
                this.addChild(teachLayer, 10);
                teachLayer.showTeach();
            } else {
                GS.dispatchCustomEvent("NotifyLuckyWheelCollectClicked", false);
            }
        }
    },

    /**
     * 更新資訊
     * @param param     server給的值
     * @param isAnim    第一次按會跑動畫(true)，跑動畫時在按一次COLLECT會把直接把資訊顯示出來(false)
     */
    updateInfo: function (param, isAnim) {
        if (!param || !param.originalMoney || !param.bouns)
            return;

        var originalMoney = param.originalMoney;   // 原始金額
        var dayBonus = param.bouns.day;       // 天數加成
        var vipBonus = param.bouns.vip;       // VIP加成


        //開始更新資訊
        var infors = [
            originalMoney,    // 原始金額
            dayBonus,        // 天數加成
            vipBonus,        // VIP加成
        ];

        // Lucky wheel的數字要千分位
        infors[0] = JSCodeUtility.getCurrencyString(infors[0]);

        this._rewardLabel.forEach((cur, i) => {
            if (isAnim) {
                cur.setScale(0);
                cur.runAction(cc.sequence(
                    cc.delayTime(i * 0.4 + 0.5),
                    cc.scaleTo(0.2, 2).easing(cc.easeBackOut()),
                    cc.callFunc(function () {
                        cur.setString(infors[i]);
                    }, this),
                    cc.scaleTo(0.2, 1)
                ));
            } else {
                cur.setScale(1);
                cur.stopAllActions();
                cur.setString(infors[i]);
            }
        });

        // 開始彈出來
        var money = originalMoney * dayBonus * vipBonus;
        if (isAnim) {
            this.stopAllActions();
            this.runAction(cc.sequence(
                cc.moveTo(0.4, this.getPositionX(), 0).easing(cc.easeBackOut(0.1)),
                cc.delayTime(2),
                cc.callFunc(() => {
                    this._totalMoneyNode.setToNumber(money, true);
                }),
                cc.delayTime(0.5),
                cc.callFunc(() => {
                    this._isFinish = true;
                    this._collectBtn.setEnabled(true);
                })
            ));
        } else {
            this._isFinish = true;
            this._totalMoneyNode.unschedule(this._totalMoneyNode.scheduleUpdateNumber);
            this._totalMoneyNode.setToNumber(money, false);
            this._collectBtn.setEnabled(true);
            this.setPositionY(0);
        }
    }
});