/**
 *  v5.4.5 背包 - 背包的碎片node
 */
var BackpackShardNode = cc.Node.extend({
    ctor: function (imgBaseHost, param) {
        this._super();

        var bgSize = cc.size(90, 105);

        // 背景
        var bgSprite = this._bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(bgSize);
        bgSprite.setAnchorPoint(0, 0);
        this.addChild(bgSprite);

        // 碎片
        var imageName = param.serial + ".png";
        var imageUrl = imgBaseHost + imageName;
        var savePath = JSWriteablePath + "shop/" + imageName;
        var shardSp = new GSDownloadSprite("", imageUrl, savePath, function (e) {
            if (e !== "Error")
                this.setVisible(true);
        }.bind(this));
        shardSp.setTargetSize(cc.size(57, 57));
        shardSp.setPosition(bgSize.width / 2, 65);
        this.addChild(shardSp);

        // 碎片名字
        var shardLabel = new cc.LabelTTF(param.name, JSFontBoldName, 12, cc.size(75, 0), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        shardLabel.setLineBreak(true);
        shardLabel.setPosition(bgSize.width / 2, 21);
        this.addChild(shardLabel);

        // 碎片名字文字大小
        var fontSize = 12;
        while (shardLabel.getContentSize().height > 30) {
            shardLabel.setFontSize(--fontSize);
        }

        // 說明
        var explainLabel = new cc.LabelTTF(param.desc, JSFontBoldName, 10, cc.size(155, 0), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        explainLabel.setPosition(170, 72);
        this.addChild(explainLabel);

        // 調整說明文字大小
        fontSize = 10;
        while (explainLabel.getContentSize().height > 50) {
            explainLabel.setFontSize(--fontSize);
        }

        // 進度條底圖
        var barPos = cc.p(173, 29);
        var progressBgSprite = new ccui.Scale9Sprite("lobby_bar_bg_02.png");
        progressBgSprite.setPreferredSize(cc.size(135, 16));
        progressBgSprite.setPosition(barPos);
        this.addChild(progressBgSprite);

        // 進度條
        var progressBar = new cc.ProgressTimer(new cc.Sprite("#lobby_bar_04.png"));
        progressBar.setPosition(barPos);
        progressBar.setBarChangeRate(cc.p(1, 0));
        progressBar.setMidpoint(cc.p(0, 0));
        progressBar.setType(cc.ProgressTimer.TYPE_BAR);
        progressBar.setPercentage(0);
        this.addChild(progressBar);

        // 刷新進度條
        progressBar.setPercentage(param.shardNum / param.limit * 100);

        // 進度條文字 xxx / xxx
        var str = JSStringUtility.format("#!FAFA50!#%d#!FFFFFF!#/%d", param.shardNum, param.limit);
        var progressLabel = new GSRichTextNode(str, JSFontBoldName, 12);
        progressLabel.setPosition(barPos.x, 13);
        this.addChild(progressLabel);
    }
});

BackpackShardNode.HEIGHT = 105;