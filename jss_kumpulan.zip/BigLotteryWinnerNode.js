/**
 * Created by terry on 2020/12/18.
 * 9T 大樂彩 - 中獎名單 Layer
 * Domino 移植設定 客製畫面/調整位移
 */

var BigLotteryWinnerNode = cc.Node.extend({
    ctor: function () {
        this._super();

        this._totalCellCount = 0;   // table view cell 數量

        // 期號
        var periodLabel = this._periodLabel = new cc.LabelTTF("", JSFontName, 14);
        periodLabel.enableStroke(cc.color(190, 30, 0, 255), 2);
        periodLabel.setPosition(JSScreenMidPos.x + 16, JSVisibleSize.height - 83);
        this.addChild(periodLabel);

        // TableView
        var tableViewSize = cc.size(380, 195 + JSScreenBonusHeight);
        var mainLayer = this._mainLayer = new cc.Layer();
        var tableView = this._tableView = new cc.TableView(this, tableViewSize, mainLayer);
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setPositionX(JSScreenMidPos.x - 174);
        this.addChild(tableView);

        // 刷新畫面
        this._refreshView();

        // 通知
        GS.addListener("NotifyBigLotteryHistoryDetailShow", this.notifyBigLotteryHistoryDetailShow.bind(this), this);
    },

    /**
     * 刷新畫面
     */
    _refreshView: function () {
        // 抓資料
        var historyParam = DataModal.bigLotteryData.historyParam;
        if (historyParam && historyParam.winnerList && historyParam.winnerList.length) {
            // 把資料記起來
            var winnerList = this._winnerList = historyParam.winnerList;

            // 刷新期數
            this._periodLabel.setString(JSStringUtility.format("%s", historyParam.lastPeriod));

            // 刷新table view
            this._totalCellCount = winnerList.length;
            this._tableView.reloadData(true);
        }
    },

    /**
     * TableView delegate
     */

    tableCellTouched: function (table, cell) {
        var param = cell.param;
        if (param && !param.isTitle && param.userID) {
            // 跳Dialog
            DialogManager.addDialog(new ProfileDialog(param.userID), false);
        }

        cell.setIsHighlight(false);
    },

    tableCellHighlight: function (table, cell) {
        cell.setIsHighlight(true);
    },

    tableCellUnhighlight: function (table, cell) {
        cell.setIsHighlight(false);
    },

    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        // 創cell
        if (cell == null) {
            cell = new BigLotteryWinnerListCell();
            cell.setAnchorPoint(0, 0);
        }

        // 刷新cell
        var winnerList = this._winnerList;
        if (winnerList && idx < winnerList.length) {
            var param = winnerList[idx];
            cell.refreshCell(param);
        }

        return cell;
    },

    numberOfCellsInTableView: function (table) {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function (table, idx) {
        var winnerList = this._winnerList;
        var cellSize = cc.size(BigLotteryWinnerListCell.WIDTH, BigLotteryWinnerListCell.HEIGHT);

        if (winnerList && idx < winnerList.length) {
            if (winnerList[idx].isTitle)
                cellSize.height = BigLotteryWinnerListCell.TITLE_HEIGHT;
        }

        return cellSize;
    },

    /**
     * 通知
     */

    // 顯示寶箱的獎勵
    notifyBigLotteryHistoryDetailShow: function (event) {
        if (event && event.getUserData()) {
            var param = event.getUserData();

            var detail = new BigLotteryWinnerListDetailLayer();
            this.addChild(detail, 10);

            // 要轉換世界座標 所以等加到畫面以後再來設定獎勵
            detail.showRewardDetail(param.rewardIndex, param.worldPos);
        }
    }
});