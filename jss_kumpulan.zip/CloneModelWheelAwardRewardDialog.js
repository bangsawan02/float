/**
 * v5.6.1 分身模組 - 轉盤獎勵領獎畫面 移植中撲 16.7
 */

var CloneModelWheelAwardRewardDialog = BaseDialogLayer.extend({
    ctor: function (reward) {
        this._super();

        this.key = "CloneModelWheelAwardRewardDialog";

        var animationLayer = this._animationLayer;

        let touchLayer = new DummyTouchLayer(JSVisibleSize);
        animationLayer.addChild(touchLayer);
        touchLayer.setOnTouchCallback(() => {
            this.closeDialogAnimation();
        });

        // 背景光
        let backgroundLight = new cc.Sprite("#cloneModel_bg_light_03.png");
        backgroundLight.setScale(2.5);
        backgroundLight.setPosition(JSScreenMidPos);
        animationLayer.addChild(backgroundLight);

        backgroundLight.runAction(
            cc.sequence(
                cc.scaleTo(2, 4).easing(cc.easeSineInOut()),
                cc.scaleTo(2, 2.5).easing(cc.easeSineInOut())
            ).repeatForever()
        );

        // 標題
        let titleSprite = new cc.Sprite("#cloneModel_word_grandtitle.png");
        titleSprite.setPosition(JSScreenMidPos.x, 234 + JSScreenBonusHalfHeight);
        animationLayer.addChild(titleSprite);

        // 獎品
        var imageUrl = TexasUtility.getItemImageUrl(reward.pic);
        var savePath = JSWriteablePath + "shop/" + reward.pic + ".png";
        var rewardSprite = this._otherRewardSprite = new GSDownloadSprite("", imageUrl, savePath);
        rewardSprite.setPosition(JSScreenMidPos);
        rewardSprite.setTargetSize(cc.size(58, 58));
        animationLayer.addChild(rewardSprite);

        // 數量
        var rewardName = new cc.LabelTTF(reward.count, JSFontBoldName, 19);
        rewardName.enableStroke(cc.color(37, 0, 77), 3);
        rewardName.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        rewardName.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 30);
        animationLayer.addChild(rewardName);

        // 點擊任意處領取獎勵
        var hintLabel = new cc.LabelTTF(LocalizedString.Purchase("點擊任意處領取獎勵"), JSFontBoldName, 12);
        hintLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 100);
        animationLayer.addChild(hintLabel);
    },
});