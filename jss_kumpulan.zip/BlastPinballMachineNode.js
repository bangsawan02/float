/**
 * v5.7.0 激爆彈珠台彈珠台 - 參考自中撲
 */

var BlastPinballMachineNode = cc.Node.extend({
    ctor: function (onShootBtnTouchDown, onShootStart, onShootEnd, purchaseBtnClicked) {
        this._super();

        this._fps = 60;

        // 彈珠台資料 reference
        // @type {BlastPinballData}
        this._dataRef = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.BLAST_PINBALL);

        // 開始發射
        this._onShootStart = onShootStart;

        // 彈珠停下
        this._onShootEnd = onShootEnd;

        // 開始蓄力
        this._onShootBtnTouchDown = onShootBtnTouchDown;

        // 是否需要購買才能玩 (免費模式 且 沒球)
        let needPurchase = this._needPurchase = this._dataRef.ballCount === 0;

        // 彈珠台 底圖
        let bgSprite = new cc.Sprite("#blastPinball_bg_pinball.png");
        this.addChild(bgSprite, -1);

        // 儲值相關
        let purchaseLayer = this._purchaseLayer = new cc.Layer();
        purchaseLayer.setCascadeOpacityEnabled(true);
        purchaseLayer.setPosition(-1, -13);
        purchaseLayer.setOpacity(0);
        this.addChild(purchaseLayer, 3);

        // 儲值的彈珠台底圖
        let purchaseBgSprite = new cc.Sprite("#blastPinball_bg_pinball.png");
        purchaseBgSprite.setPosition(cc.pSub(cc.p(0, 0), purchaseLayer.getPosition()));
        purchaseBgSprite.setColor(JSColor.GRAY);
        purchaseBgSprite.setOpacity(200);
        purchaseLayer.addChild(purchaseBgSprite, -1);

        // 散射光
        let lightSprite = new cc.Sprite("#lobby_bg_win_02.png");
        lightSprite.setScale(1.2);
        purchaseLayer.addChild(lightSprite);

        // 儲值按鈕
        let purchaseBt = new Texas_Button(Texas_Button.Style.GREEN, cc.size(125, 50), LocalizedString.BlastPinballString("獲得彈珠"));
        purchaseBt.addTouchUpInsideAction(purchaseBtnClicked, this);
        purchaseLayer.addChild(purchaseBt);

        // 獎勵格旗幟
        let flagLayer = this._flagLayer = new cc.Layer();
        flagLayer.setPosition(0, -80);
        flagLayer.spriteList = [];
        flagLayer.spineList = [];
        this.addChild(flagLayer, 1);

        this._getFlagList().forEach((flagType, i) => {
            let pos = cc.p(i * 27 - 82, 0);
            let flagSprite = new cc.Sprite("#blastPinball_pic_lightgird" + flagType + ".png");
            flagSprite.setPosition(pos);
            flagSprite.setScale(0.88);
            flagLayer.addChild(flagSprite);
            flagLayer.spriteList.push(flagSprite);

            GSSpine.create("spine/BlastPinball/PurchasePack_BlastPinball_ani_award", 0.25, (spine) => {
                // 金外框動畫
                spine.setVisible(false);
                spine.setPosition(pos);
                spine.setScale(0.88);
                flagLayer.addChild(spine);
                flagLayer.spineList.push(spine);
            });
        });

        // 三個箭頭 layer
        let arrowLayer = this._arrowLayer = new cc.Layer();
        this.addChild(arrowLayer);

        // 三個箭頭
        [255, 178, 127].forEach((opacity, i) => {
            let arrowSprite = new cc.Sprite("#blastPinball_pic_arrow.png");
            arrowSprite.setPosition(82, -4 - i * 13);
            arrowSprite.setOpacity(opacity);
            arrowSprite.setScale(0.88);
            arrowLayer.addChild(arrowSprite);
        });

        // 機台外拉桿上的彈簧
        let springSprite = new cc.Sprite("#blastPinball_pic_bar-3.png");
        springSprite.setPosition(82, -91);
        this.addChild(springSprite, 3);

        // 發射按鈕
        let shotButton = this.shotButton = new GSControlButton(new cc.Sprite("#blastPinball_pic_bar-4.png"));
        shotButton.setPosition(82, -116);
        shotButton.setEnabled(!needPurchase);
        shotButton.addTargetWithActionForControlEvents(this, this.shotBtnPressed,
            cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL | cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        this.addChild(shotButton, 3);

        let messageLabel = new cc.LabelTTF(LocalizedString.BlastPinballString("長壓！"), JSFontName, 10);
        messageLabel.setFontFillColor(JSColor.BLACK);

        // 去建立碰撞相關的東西
        this._addCollision();

        // 右方力度條背景
        let barBgPos = cc.p(124, -65);
        let barBg = new cc.Sprite("#blastPinball_pic_bar-1.png");
        barBg.setPosition(barBgPos);
        this.addChild(barBg);

        // 右方力度條
        let progressBar = this._progressBar = new cc.ProgressTimer(new cc.Sprite("#blastPinball_pic_bar-2.png"));
        progressBar.setType(cc.ProgressTimer.TYPE_BAR);
        progressBar.setBarChangeRate(cc.p(0, 1));
        progressBar.setMidpoint(cc.p(0.5, 0));
        progressBar.setPosition(barBgPos);
        this.addChild(progressBar, 4);

        // 長壓提示圖片
        let messagePopup = this._messagePopup = new BaseMessageNode({
            mainNode: messageLabel,
            style: BaseMessageNode.Style.WHITE,
            direct: BaseMessageNode.Direct.LEFT,
            autoFixed: true,
        });
        messagePopup.setPosition(90, -116);
        messagePopup.show();
        this.addChild(messagePopup, 5);
    },

    onEnter: function () {
        this._super();

        // 可以玩的時候，才執行動畫
        this._needPurchase || this.shotButton.runAction(cc.sequence(
            cc.sequence(
                cc.scaleTo(0.7, 0.9).easing(cc.easeSineIn()),
                cc.scaleTo(0.3, 1).easing(cc.easeBackOut())
            ),
            cc.delayTime(1)
        ).repeatForever());
    },

    refreshView: function () {
        this._flagLayer.stopAllActions();
        this.hideFlagSpine();
        this.updateFlagSprite();
        this._arrowLayer.setVisible(true);

        if (this._ballObj) {
            // 清掉獎勵區的球
            this._ballObj.sprite.removeFromParent();
            this._space.removeShape(this._ballObj.shape);
            this._space.removeBody(this._ballObj.body);
            this._ballObj = undefined;
        }

        let mainSpring = this._mainSpring;
        let fakeBallSp = this._fakeBallSprite;

        // 彈簧復原
        mainSpring.stopAllActions();
        mainSpring.runAction(cc.scaleTo(0.05, mainSpring.originalScale, mainSpring.originalScale));

        // 假球復原
        fakeBallSp.stopAllActions();
        fakeBallSp.runAction(cc.moveTo(0.05, fakeBallSp.originPos));

        // 蓄力條復原
        this._progressBar.stopAllActions();
        this._progressBar.setPercentage(0);
    },

    /**
     * 取得獎勵格類型列表
     * @returns {number[]}
     * @private
     */
    _getFlagList: function () {
        this._prizeOrder = this._prizeOrder || this._generateFlagList();
        return this._prizeOrder;
    },

    /**
     * 產生獎勵格類型列表
     * @returns {number[]}
     * @private
     */
    _generateFlagList: function () {
        this._prizeOrder = [1, 2, 3, 3, 4, 4].sort(() => Math.random() - 0.5);
        return this._prizeOrder;
    },

    /**
     * 碰撞相關的東西
     */
    _addCollision: function () {
        // 建立物理空間
        let space = this._space = new cp.Space();
        let staticBody = space.staticBody;

        // 重力
        space.gravity = cp.v(0, -400);

        // 機台邊框
        // 下，左，外右，內右
        [
            { pos: cc.p(-15, -98), size: cc.size(176, 7) },
            { pos: cc.p(-98, -30), size: cc.size(7, 140) },
            { pos: cc.p(98, -30), size: cc.size(7, 140) },
            { pos: cc.p(67, -35), size: cc.size(4, 130) }
        ].forEach((attr, i) => {
            let pos = attr.pos, size = attr.size;

            let body = cp.StaticBody();
            body.setPos(cc.pAdd(pos, JSScreenMidPos));

            let shape = new cp.BoxShape(body, size.width, size.height);

            // 彈性系數
            shape.setElasticity(1);
            // 摩擦系數
            shape.setFriction(1);
            space.addStaticShape(shape);
        });

        // 上橢圓弧：中心點 -> cc.p(0, 25)、角度 -> 0 ~ 180
        let centralPoint = cc.p(0, 25);
        let sampleCount = 200;
        let options = { startDegree: 0, endDegree: 180 };
        let pointList = PointGenerators.genEllipsePoints(197, 144, sampleCount, options);
        pointList.forEach((p, i) => {
            let point = cc.pAdd(centralPoint, cc.pAdd(p, JSScreenMidPos));
            let shape = new cp.SegmentShape(staticBody, point, cp.v(point.x - 0.5, point.y - 0.5), 5);
            shape.setElasticity(0.00001);
            space.addStaticShape(shape);
        });

        // 內橢圓弧 中心點 -> cc.p(144, 45)、角度 -> 0 ~ 80
        centralPoint = cc.p(44, 22);
        options = { startDegree: 0, endDegree: 80 };
        pointList = PointGenerators.genEllipsePoints(48, 60, sampleCount, options);
        pointList.forEach((p, i) => {
            let point = cc.pAdd(centralPoint, cc.pAdd(p, JSScreenMidPos));
            let shape = new cp.SegmentShape(staticBody, point, cp.v(point.x - 0.5, point.y - 0.5), 3);
            shape.setElasticity(1);
            space.addStaticShape(shape);
        });

        // 機台內的圓形障礙
        let startPos = [
            cc.p(-56, 38),
            cc.p(-68, 7),
            cc.p(-82, -31),
            cc.p(-68, -60)
        ];
        [4, 5, 6, 5].forEach((obstacleNum, j) => {
            for (let i = 0; i < obstacleNum; ++i) {
                let pos = cc.pAdd(startPos[j], cc.pAdd(cc.p(i * 26.5, 0), JSScreenMidPos));

                // 碰撞區 (要自己對應回中心點)
                let shape = new cp.CircleShape(staticBody, 5, pos);
                shape.setElasticity(1); // 彈性系數
                shape.setFriction(1);   // 摩擦系數
                space.addStaticShape(shape);
            }
        });

        // 三角平台 (左上，左，右) (用五邊形做)
        let shapeVertList = [
            [-16, 1, -7, 13, 12, -3, 12, -6, 8, -9],
            [-9, -7, -9, 7, 12, 4, 13, 0, 12, -3],
            [-12, -3, -13, 0, -12, 4, 10, 7, 10, -7]
        ];
        let trianglePosList = [cc.p(-75, 49), cc.p(-85, -18), cc.p(53, -18)];
        trianglePosList.forEach((pos, i) => {
            // 碰撞區 (要自己對應回中心點)
            let shape = new cp.PolyShape(staticBody, shapeVertList[i], cc.pAdd(pos, JSScreenMidPos));
            shape.setElasticity(1);
            shape.setFriction(1);
            space.addStaticShape(shape);
        });

        // 下方隔板 (同時儲存 posX 給後續判斷使用)
        this._bottomObstaclePosXList = [];
        for (let i = 0; i < 5; ++i) {
            let pos = cc.p(i * 26.5 - 68, -84);

            let body = cp.StaticBody();
            body.setPos(cc.pAdd(pos, JSScreenMidPos));

            let shape = new cp.BoxShape(body, 2, 28);
            shape.setElasticity(1);
            shape.setFriction(1);
            space.addStaticShape(shape);

            // 存起來
            this._bottomObstaclePosXList.push(pos.x);
        }

        // 假球
        let fakeBallSprite = this._fakeBallSprite = new cc.Sprite("#blastPinball_pic_pinball" + (this._dataRef.isFree ? 2 : 1) + ".png");
        fakeBallSprite.originPos = cc.p(82, -45);
        fakeBallSprite.setPosition(fakeBallSprite.originPos);
        fakeBallSprite.setScale(0.88);
        this.addChild(fakeBallSprite, 2);

        // 彈簧
        let mainSpring = this._mainSpring = new cc.Sprite("#blastPinball_pic_bar3-2.png");
        mainSpring.originalScale = 0.88;
        mainSpring.setPosition(82, -80);
        mainSpring.setScale(mainSpring.originalScale);
        mainSpring.setAnchorPoint(0.5, 0);
        this.addChild(mainSpring, 2);

        // 拉桿平台 (給一個 V，讓球看起來是落在彈簧內)
        let body = cp.StaticBody();
        body.setPos(cc.pAdd(cc.p(82, -56), JSScreenMidPos));

        // 用兩個四邊形做 V
        [
            [-12, 5, -5, 5, 0, 0, -12, 0],
            [0, 0, 5, 5, 12, 5, 12, 0]
        ].forEach(vert => {
            let shape = new cp.PolyShape(body, vert, cc.p(0, 0));
            shape.setElasticity(1);
            shape.setFriction(1);
            space.addStaticShape(shape);
        });

        // 放個平臺做保險
        let platformShape = new cp.BoxShape(body, 20, 6);
        platformShape.setElasticity(1); // 彈性系數
        platformShape.setFriction(1);   // 摩擦系數
        space.addStaticShape(platformShape);

        // 定期去跑schedule 要設定優先權 這樣跑起來比較正常
        this._totalDeltaTime = 0;
        this.scheduleUpdateWithPriority(0);

        // 先跑一次物理
        this._space.step(1 / this._fps);
    },

    /**
     * 發射球
     * Native 的路徑跟 H5 不同，AN 跟 iOS 也不相同，所以發射前先算好可以到目標的參數，最後真正發射時再套用
     *
     * @param {number} targetType 中獎類型
     * @private
     */
    _shotBall: function (targetType = 1) {
        let percentage = this._progressBar.getPercentage();

        // 取得目前是要停在哪格
        let targetLocList = []; // 可能有兩格可以挑，所以要全部跑一次
        this._getFlagList().forEach((cur, i) => {
            cur === targetType && targetLocList.push(i);
        });

        // 拿到 targetLoc (範圍在 1~6)
        let targetLoc = targetLocList.length === 1 ? targetLocList[0]
            : targetLocList[JSCodeUtility.getRandomInt(0, targetLocList.length - 1)];

        // 設定初始速度，蓄力沒過 40% 初始速度最大為 300，超過會射出去。因為是百分比，所以最大值是 1000。
        let notShot = percentage <= 40;
        let baseVelocity = Math.round(cc.clampf(10 * percentage, 0, notShot ? 300 : 1000));
        let initialVelocity = baseVelocity;

        // Brute Force 預測落點，最多嘗試 1e4 次
        for (let i = 0; i < 1e4; i++) {
            let ballObj = this._createBallObject();
            let sprite = ballObj.sprite;

            // 設定初始位置
            sprite.setPosition(cc.pAdd(cc.p(82, -43), JSScreenMidPos));

            // 設定初始速度。
            initialVelocity = baseVelocity + i;
            ballObj.body.setVel(cp.v(0, initialVelocity));

            // 跑 update 預測落點
            this.update(10);

            let stopLocation = this._checkStopPos(sprite.getPosFromMidPos());
            if (notShot && stopLocation === -1 || stopLocation === targetLoc) {
                // <Debug> 顯示落點
                JSDebugMode && this.debugLocationDrawNode &&
                    this.debugLocationDrawNode.drawDot(sprite.getPosFromMidPos(), 2, cc.color(255, 0, 0));

                // 已經確定位置，沒射出去或命中
                break;
            }
        }

        // 正式開始跑此路徑
        let ballObj = this._createBallObject();

        // 設定初始位置
        ballObj.sprite.setPosition(cc.pAdd(cc.p(82, -43), JSScreenMidPos));

        // 設定初始速度。
        ballObj.body.setVel(cp.v(0, initialVelocity));
    },

    /**
     * 建立球的物理
     * @returns {object}
     * @private
     */
    _createBallObject: function () {
        let data = this._dataRef;
        let ballObj = this._ballObj;
        let space = this._space;
        let spriteRadius = 7.5;   // 半徑
        let spriteOffset = cp.v(0, 0);  // 偏移值

        if (ballObj) {
            // 清掉獎勵區的球
            ballObj.sprite.removeFromParent();
            space.removeShape(ballObj.shape);
            space.removeBody(ballObj.body);
        } else {
            ballObj = this._ballObj = {};
        }

        // 碰撞體
        let body = ballObj.body = new cp.Body(1, cp.momentForCircle(1, 0, spriteRadius, spriteOffset));
        space.addBody(body);

        // 碰撞體形狀
        let shape = ballObj.shape = new cp.CircleShape(body, spriteRadius, spriteOffset);
        shape.setElasticity(0.5);
        shape.setFriction(0.5);
        space.addShape(shape);

        // 多用一個 Node 去轉換後續 PhysicsSprite 的位置 (為保持其他地方的中心對位)
        let ballTranNode = this._ballTranNode;
        if (!ballTranNode) {
            ballTranNode = this._ballTranNode = new cc.Node();
            ballTranNode.setPosition(-JSScreenMidPos.x, -JSScreenMidPos.y);
            this.addChild(ballTranNode, 1);
        }

        // PhysicsSprite
        let sprite = ballObj.sprite = new cc.PhysicsSprite("#blastPinball_pic_pinball" + (data.isFree ? 2 : 1) + ".png");
        sprite.setBody(body);
        sprite.setScale(0.88);
        sprite.getPosFromMidPos = function () {
            return cc.pSub(this.getPosition(), JSScreenMidPos);
        };
        ballTranNode.addChild(sprite);
        return ballObj;
    },

    /**
     * 確認球的位置 並做對應事情
     */
    _checkStopPos: function (pos) {
        if (pos.y < -90 || (pos.x > 67 && pos.y < -30)) {
            // 球莫名其妙跑出去了(防呆) 或者 滯留在發射口
            return -1;
        } else if (pos.y < -70) {
            // 由左至右
            let posXList = this._bottomObstaclePosXList;
            for (let i = 0; i < posXList.length; i++) {
                if (pos.x < posXList[i]) {
                    return i;
                }
            }
            return posXList.length;
        }

        // 還在跑，不做事
        return -2;
    },

    /**
     * 取得球停下的獎勵類型
     * @returns {number}
     */
    getBallStopType: function () {
        return this._getFlagList()[this._ballStopLoc];
    },

    /**
     * 每一個frame更新
     */
    update: function (dt) {
        // 要把它轉成固定時間
        this._totalDeltaTime += dt;
        let count = Math.floor(this._totalDeltaTime * this._fps);
        for (let i = 0; i < count; i++) {
            // 物理更新
            this._space.step(1 / this._fps);
        }

        // 減掉
        this._totalDeltaTime -= count / this._fps;
    },

    /**
     * 更新獎格位置
     */
    updateFlagSprite: function () {
        this._getFlagList().forEach((type, i) => {
            this._flagLayer.spriteList[i].setSpriteFrame("blastPinball_pic_lightgird" + type + ".png");
        });
    },

    /**
     * 讓中獎的獎格亮起
     */
    playFlagSpine: function () {
        let spine = this._flagLayer.spineList[this._ballStopLoc];
        spine.clearTracks();
        spine.setToSetupPose();
        spine.setAnimation(0, 'ani_01', true);
        spine.setVisible(true);
    },

    /**
     * 隱藏全部獎格 spine
     */
    hideFlagSpine: function () {
        this._flagLayer.spineList.forEach(spine => {
            if (spine.isVisible()) {
                spine.clearTracks();
                spine.setVisible(false);
            }
        });
    },

    // 準備下一顆球 讓玩家可遊玩
    prepareNextBall: function () {
        this.refreshView();

        // 顯示假球
        let fakeBallSp = this._fakeBallSprite;
        fakeBallSp.setSpriteFrame("blastPinball_pic_pinball" + (this._dataRef.isFree ? 2 : 1) + ".png");
        fakeBallSp.setVisible(true);
        fakeBallSp.setOpacity(0);
        fakeBallSp.runAction(cc.fadeIn(0.2));

        // 去恢復按鈕，讓他可以重新再蓄力
        let shotButton = this.shotButton;
        shotButton.setEnabled(true);
        shotButton.stopAllActions();
        shotButton.runAction(cc.sequence(
            cc.sequence(
                cc.scaleTo(0.7, 0.9).easing(cc.easeSineIn()),
                cc.scaleTo(0.3, 1).easing(cc.easeBackOut())
            ),
            cc.delayTime(1)
        ).repeatForever());

        // 顯示提示訊息
        this._messagePopup.show();
    },

    _showPurchaseLayer: function () {
        this._purchaseLayer.stopAllActions();
        this._purchaseLayer.runAction(cc.sequence(
            cc.callFunc(() => {
                this._purchaseLayer.setVisible(true);
            }),
            cc.fadeIn(0.5)
        ));
    },

    /**
     * 隱藏儲值相關內容
     */
    hidePurchaseLayer: function () {
        this._purchaseLayer.stopAllActions();
        this._purchaseLayer.runAction(cc.sequence(
            cc.fadeOut(0.5),
            cc.callFunc(() => {
                this._purchaseLayer.setVisible(false);
            })
        ));
    },

    // 顯示購買按鈕
    showPurchaseButton: function () {
        // 把購買按鈕相關的東西給顯示
        this._showPurchaseLayer();

        // 發射的按鈕先鎖住
        this.shotButton.setEnabled(false);
        this.shotButton.stopAllActions();

        // 隱藏提示訊息
        this._messagePopup.hide();

        // 讓獎格內的五角形做隨機變色動畫
        this._flagLayer.spineList.forEach((spine) => {
            spine.setAnimation(0, 'ani_01', true);
            spine.setVisible(true);
        });

        this._flagLayer.stopAllActions();
        this._flagLayer.runAction(cc.sequence(
            cc.delayTime(3),
            cc.callFunc(() => {
                // 隨機產生
                this._generateFlagList();

                // 更新獎格圖片
                this.updateFlagSprite();
            })
        ).repeatForever());
    },

    // 按下蓄力按鈕
    shotBtnPressed: function (sender, event) {
        let fakeBallSp = this._fakeBallSprite;
        let mainSpring = this._mainSpring;
        let progressBar = this._progressBar;

        sender.setEnabled(false);

        switch (event) {
            case cc.CONTROL_EVENT_TOUCH_DOWN:
                this._onShootBtnTouchDown && this._onShootBtnTouchDown(sender);
                // 先停下按鈕動畫
                sender.stopAllActions();

                // 隱藏提示訊息
                this._messagePopup.hide();

                // 隱藏三個紅色箭頭
                this._arrowLayer.setVisible(false);

                // 取樣點列表，蓄力條做簡諧運動
                let pointList = PointGenerators.simpleHarmonic(2, {
                    amplitude: 100,
                    period: 4,
                    phase: 0,
                });
                progressBar.setPercentage(0);
                progressBar.runAction(cc.sequence(
                    pointList.map((p) => cc.progressTo(1 / this._fps, p))
                ).repeatForever());

                // 彈簧跟隨蓄力條做伸縮
                let initialScale = mainSpring.originalScale;
                pointList = PointGenerators.simpleHarmonic(2, {
                    amplitude: initialScale - 0.5,
                    period: 4,
                    phase: Math.PI,
                });
                mainSpring.runAction(cc.sequence(
                    pointList.map((p) => cc.scaleTo(1 / this._fps, initialScale, initialScale + p))
                ).repeatForever());

                // 假球跟隨蓄力條做位移
                let amplitude = mainSpring.getContentSize().height * (mainSpring.originalScale - 0.5);
                pointList = PointGenerators.simpleHarmonic(2, {
                    amplitude: amplitude,
                    period: 4,
                    phase: Math.PI,
                });
                fakeBallSp.runAction(cc.sequence(
                    pointList.map((p) => cc.moveTo(1 / this._fps, fakeBallSp.originPos.x, fakeBallSp.originPos.y + p))
                ).repeatForever());

                break;

            default:
                // 停下力度條 & 彈簧 & 假球
                progressBar.stopAllActions();
                mainSpring.stopAllActions();
                fakeBallSp.stopAllActions();

                // 顯示三個紅色箭頭
                this._arrowLayer.setVisible(true);

                if (this._dataRef.ballCount <= 0) {
                    // 沒球要去跳 錯誤 dialog
                    return GS.dispatchCustomEvent("NotifyBlastPinballShowErrorDialog");
                }

                // 發射球
                if (progressBar.getPercentage() >= 40)
                    this._dataRef.requestShoot();
                else
                    this.realShotPinballAnimation();

                break;
        }
    },

    /**
     * 按下按鈕就代表
     * @param {object} playData blast_pinball_play 回傳的資料
     */
    realShotPinballAnimation: function (playData = {}) {
        let mainSpring = this._mainSpring;
        let fakeBallSp = this._fakeBallSprite;

        // 彈簧 & 假球復原
        mainSpring.runAction(cc.scaleTo(0.05, mainSpring.originalScale, mainSpring.originalScale));
        fakeBallSp.setPosition(fakeBallSp.originPos);

        // 隱藏假球
        fakeBallSp.setVisible(false);

        this._shotBall(playData.prize);

        this._onShootStart && this._onShootStart();

        if (this._ballObj) {
            let ballSprite = this._ballObj.sprite;
            let ballBody = ballSprite.getBody();

            // 每秒檢查一次球是否停下，最多檢查 30 次 (通常 10 內完結，設置長一點避免判斷不到較長時間的路徑)
            this.runAction(cc.sequence(cc.delayTime(1), cc.callFunc(() => {
                let velocity = ballBody.getVel();

                // 水平速率
                let speedX = Math.abs(velocity.x);
                // 垂直速率
                let speedY = Math.abs(velocity.y);
                // 角速率
                let angularVelocity = Math.abs(ballBody.getAngVel());
                // 速度 < 2 且角速度 < 2 代表球停下來了
                if (speedX < 2 &&speedY < 2 && angularVelocity < 2) {
                    // 確認球停在哪個位置
                    let pos = ballSprite.getPosFromMidPos();
                    let stopLoc = this._checkStopPos(pos);
                    if (stopLoc === -2) {
                        // 還在跑，不做事
                        return;
                    }

                    // 另外存下停下的位置
                    this._ballStopLoc = stopLoc;

                    // 停下檢查
                    this.stopAllActions();

                    // 沒有發射出去，快速淡出
                    stopLoc < 0 && ballSprite.runAction(cc.fadeOut(0.2));

                    // 通知停下了
                    this._onShootEnd(stopLoc < 0, playData);
                }
            })).repeat(30));
        }
    },
});