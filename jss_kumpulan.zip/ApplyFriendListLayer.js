/**
 * 好友申請列表
 */
var ApplyFriendListLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 申請清單
        this._applyFriendList = [];

        // 列表
        var tableWidth = this._tableWidth = FriendLayer.WIDTH;
        var tableHeight = JSVisibleSize.height - TITLE_BG_HEIGHT - 26;
        var mainLayer = this._mainLayer = new cc.Layer();
        var tableView = this._tableView = new cc.TableView(this, cc.size(tableWidth, tableHeight), mainLayer);
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setPosition(115 + JSScreenBonusHalfWidth, 0);
        this.addChild(tableView);

        // 擋tableView 上方的touch
        var dummyTouch = new DummyTouchLayer(cc.size(tableWidth, 50));
        dummyTouch.setPosition(115 + JSScreenBonusHalfWidth, tableHeight);
        this.addChild(dummyTouch);

        // 標題
        var titleLabel = new cc.LabelTTF(LocalizedString.Friend("申請好友"), JSFontBoldName, 12);
        titleLabel.setPosition(315 + JSScreenBonusHalfWidth, JSVisibleSize.height - TITLE_BG_HEIGHT - 13);
        this.addChild(titleLabel);

        // 提示訊息
        var msgLabel = this._msgLabel = new cc.LabelTTF(LocalizedString.Friend("目前沒有好友申請哦"), JSFontBoldName, 12);
        msgLabel.setPosition(315 + JSScreenBonusHalfWidth, 122 + JSScreenBonusHalfHeight);
        msgLabel.setVisible(false);
        this.addChild(msgLabel);

        // 加一個Loading
        var loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(cc.pAdd(tableView.getPosition(), cc.p(tableWidth / 2, tableHeight / 2)));
        loadingSprite.start();
        this.addChild(loadingSprite);

        // 取得好友申請列表
        DataProcess.sendString("user_get_friends_verify_list");

        GS.addListener("NotifyApplyFriendListDone", this.notifyApplyFriendListDone.bind(this), this);
        GS.addListener("NotifyFriendChangeDone", this.notifyFriendChangeDone.bind(this), this);
        GS.addListener("NotifyUpdateFriendListCount", this.notifyApplyFriendListDone.bind(this), this);
    },

    /**
     * 更新畫面
     */
    _refreshView: function () {
        // 把Loading拿掉
        this._loadingSprite.stop();
        GSLoading.removeLoadingView();

        var data = DataModal.friendData;

        if (!data)
            return;

        data.redPoint.icon = false;
        var FindFriendList = this._applyFriendList = data.applyFriendList;

        // 好友申請數量
        var friendListLen = this._totalCellCount = FindFriendList.length;

        var isHaveFriend = friendListLen > 0;

        this._tableView.reloadData(true);

        if (data.isFriendLimit)
            // 好友滿了顯示訊息
            this._showFullFriend();
        else {
            this._tipNode && this._tipNode.setVisible(false);

            // 沒有申請時要顯示提示
            this._msgLabel.setVisible(!isHaveFriend);
        }
    },

    /**
     * show 好友已滿的提示
     */
    _showFullFriend: function () {
        if (this._tipNode) {
            this._tipNode.setVisible(true);
            return;
        }

        var tipNode = this._tipNode = new cc.Node();
        this.addChild(tipNode, 100);

        // 背景色
        var mask = new cc.LayerColor(cc.color(0, 0, 0, 150), 383, 252);
        mask.setPosition(118 + JSScreenBonusHalfWidth, 0);
        tipNode.addChild(mask);

        // 加一層UI檔Touch
        var dummyTouch = new DummyTouchLayer(cc.size(383, 251));
        dummyTouch.setPosition(mask.getPosition());
        tipNode.addChild(dummyTouch);

        // 提示背景
        var hintBgSprite = new ccui.Scale9Sprite("lobby_bg_hint.png");
        hintBgSprite.setPreferredSize(cc.size(383, 60));
        hintBgSprite.setAnchorPoint(0, 0.5);
        hintBgSprite.setPosition(118 + JSScreenBonusHalfWidth, 120 + JSScreenBonusHeight);
        tipNode.addChild(hintBgSprite);

        // 提示文字
        var hintLabel = new cc.LabelTTF(LocalizedString.Friend("你的好友數已滿\n目前沒有空位再加好友了哦"), JSFontBoldName, 12);
        hintLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        hintLabel.setPosition(315 + JSScreenBonusHalfWidth, 120 + JSScreenBonusHeight);
        tipNode.addChild(hintLabel);
    },

    _showHintMsg: function (msg) {
        if (!this._hintMsgNode) {
            var hintMsgNode = this._hintMsgNode = new FriendHintNode();
            hintMsgNode.setPosition(JSScreenMidPos);
            this.addChild(hintMsgNode, 100);
        }
        this._hintMsgNode.showHint(msg);
    },

    /**
     * TableView delegate
     */
    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        if (cell == null) {
            cell = new ApplyFriendListCell();
            cell.setAnchorPoint(cc.p(0, 0));
        }
        cell.refreshCell(this._applyFriendList[idx]);

        return cell;
    },

    numberOfCellsInTableView: function (table) {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function (table, idx) {
        return cc.size(this._tableWidth, FriendListCell.HEIGHT);
    },

    /**
     * 通知刷新介面
     */
    notifyApplyFriendListDone: function () {
        this._refreshView();
    },

    /**
     * 通知加入好友
     */
    notifyFriendChangeDone: function (event) {
        // show 訊息
        if (event && event.getUserData()) {
            var param = event.getUserData();
            if (param.code === 2)
                this._showHintMsg(LocalizedString.Friend("對方好友已滿，目前沒有空位再加好友囉"));
        }
        this._refreshView();
    }
});