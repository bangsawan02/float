/**
 * 牌王地圖
 */

var CardKingMapNode = cc.Node.extend({
    MINIMUM_CELL_COUNT: 10,  // 最低會有幾個cell, 一個cell含兩個節點, 最少16個節點
    SELF_NODE_ZORDER: 0x7fffffff,  // int最大的數, 額外node就加在最上面

    ctor: function () {
        this._super();

        // 選到的等級
        this._selectedLevel = 1;

        // 倒數要資料
        this._remainTime = 0;
        this._socketTime = 0;

        // 有沒有去要過資料了
        this._hasBeenAsk = {};

        // 自己資料要過沒
        this._selfDataHasBeenAsk = {};

        // 跑馬燈用的array
        this._marqueeArray = [];

        // 用來表演的最高玩家
        this._topPlayerNode = undefined;

        var contentNode = this._contentNode = new cc.Node();
        this.addChild(contentNode);

        // tableView
        var layer = this._containerLayer = new cc.Layer();

        var tableViewSize = cc.size(402 + JSScreenBonusWidth - JSScreenSafeWidth, 210 + JSScreenBonusHeight);
        var tableView = this._tableView = new cc.TableView(this, tableViewSize, layer);
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setPosition(110 + JSScreenSafeWidth, 0);
        contentNode.addChild(tableView, 0);

        // 自己的node
        var selfNode = this._selfNode = new CardKingMapRouteNode(0, CardKingMapPlayerNode.Type.SELF);
        layer.addChild(selfNode, this.SELF_NODE_ZORDER);

        // 跑馬燈
        var param = {
            width: 280,
            height: 16,
            sec: 15,
            nextDelayTime: 2,
            fontSize: 14
        };
        var marqueeNode = this._marqueeNode = new MarqueeNode(param);
        marqueeNode.setPosition(312 + JSScreenBonusHalfWidth, 222 + JSScreenBonusHalfHeight);
        // 全部做完重播
        marqueeNode.setAllMarqueeFinished(() => {
            for (var i = 0; i < this._marqueeArray.length; ++i) {
                marqueeNode.push(this._marqueeArray[i]);
            }
        });
        contentNode.addChild(marqueeNode, 1);

        // 只准按tableView裡的東西
        var dummyTouchLayer = new DummyTouchLayer(tableViewSize, false, true);
        dummyTouchLayer.setPosition(110 + JSScreenBonusHalfWidth, 0);
        contentNode.addChild(dummyTouchLayer, 2);

        // 轉圈圈
        var loadingSp = this._loadingSp = new GSLoadingSprite();
        loadingSp.setPosition(311 + JSScreenBonusHalfWidth, 100 + JSScreenBonusHalfHeight);
        loadingSp.setVisible(false);
        this.addChild(loadingSp);

        GS.addListener("NotifyCardKingMapInfoDone", this.notifyCardKingMapInfoDone.bind(this), this);
        GS.addListener("NotifyCardKingMapShowPlayerBubble", this.notifyCardKingMapShowPlayerBubble.bind(this), this);
        GS.addListener("NotifyCardKingMapCloseBubble", this.notifyCardKingMapCloseBubble.bind(this), this);
    },

    refresh: function (isResettingSelfNode = true, isRelocateTableView = false, needToAskSelfInfo = false) {
        this._loadingSp.stop();
        this._contentNode.setVisible(true);

        // 避免已經要刷新了還在跑動畫, 畫面會歪掉
        this._containerLayer.stopAllActions();

        this._tableView.reloadData(isRelocateTableView);

        var tableViewContentSize = this._tableView.getContentSize();

        // 固定減掉多的2.6個, 有可能剛好最後一個節點有人, 要是減掉多加的3個, 最後那個節點會被切一半
        this._tableView.setContentSize(tableViewContentSize.width - CardKingMapRouteCell.getCellSizeByIndex().width * 2.6, 210 + JSScreenBonusHeight);

        var mapInfo = DataModal.cardKingData.getMapInfoByLevel(this._selectedLevel);

        // 地圖資訊
        if (mapInfo) {
            // 跑馬燈
            this._marqueeNode.clearAndStop();
            this._marqueeArray = mapInfo.marqueeArray.map(cur => {
                var param = {
                    message: cur,
                    color: JSColor.WHITE,
                };

                // 也塞給跑馬燈
                this._marqueeNode.push(param);

                return param;
            });

            // 更新時間
            this._remainTime = mapInfo.remainTime;
            this._socketTime = mapInfo.socketTime;

            this.unschedule(this._scheduleCountdown);

            // 地圖資料過期
            if (JSCodeUtility.getRemainTime(this._remainTime, this._socketTime) <= 0) {
                if (!this._hasBeenAsk[this._selectedLevel]) {
                    DataModal.cardKingData.startGetMapInfoByLevel(this._selectedLevel);
                    this._hasBeenAsk[this._selectedLevel] = true;
                    this._loadingSp.start();
                    // 直接return,  一整包重要
                    return;
                }
            } else {
                this.schedule(this._scheduleCountdown, 0.5, cc.REPEAT_FOREVER);
            }
        }

        // 自己的資料
        var selfInfo = DataModal.cardKingData.selfMapInfo[this._selectedLevel];

        // 要是不要心資料就用舊資料刷新自己
        if (!isResettingSelfNode)
            selfInfo = DataModal.cardKingData.oldSelfInfo[this._selectedLevel];

        this.setSelfNodeBubbleOpen(true);

        if (selfInfo) {
            var index = DataModal.cardKingData.getIndexBySearchCurrentDetail(this._selectedLevel, selfInfo.round);

            // 有位移才不會貼在左邊
            this.moveToIdx(index - 2);

            this.setSelfNodePosByRound(selfInfo.round, index);

            var selfCell = this._tableView.cellAtIndex(index);
            if (selfCell) {
                // 確定泡泡匡的方向, 要不要讓他可以按之類的
                this._selfNode.setBubbleDirection(selfCell.getBubbleDirectionByRound(selfInfo.round));

                // 在起點不可以按
                if (selfInfo.round === 0)
                    this._selfNode.setBubbleEnabled(false);
                else
                    this._selfNode.setBubbleEnabled(selfCell.getRoundIsOnSteadyNode(selfInfo.round));

                selfCell.checkSteadyNodeNeedToHide(selfInfo.round);
            }

            this._selfNode.refresh(selfInfo.round, selfInfo, this._selectedLevel);
        }

        //  判斷要不要要玩家資料
        if (needToAskSelfInfo) {
            if (!this._selfDataHasBeenAsk[this._selectedLevel]) {
                DataModal.cardKingData.startGetSelfInfo(this._selectedLevel);
                this._selfDataHasBeenAsk[this._selectedLevel] = true;
                this._loadingSp.start();
            }
        }
    },

    // 顯示其他等級的地圖
    changeLevel: function (level) {
        this._selectedLevel = level;

        // 先關一次, 換頁都需要先把上一個人的排程牌掉
        this.unschedule(this._scheduleCountdown);

        // 沒資料要去要資料
        if (!DataModal.cardKingData.getMapInfoByLevel(level)) {
            this._contentNode.setVisible(false);
            this._loadingSp.start();
            if (!this._hasBeenAsk[this._selectedLevel]) {
                DataModal.cardKingData.startGetMapInfoByLevel(this._selectedLevel);
                this._hasBeenAsk[this._selectedLevel] = true;
            }
        } else {
            // 需不需要刷新玩家資料
            var needToRefreshPlayerData = DataModal.cardKingData.mapRedDot[this._selectedLevel];
            this.refresh(false, true, needToRefreshPlayerData);
        }
    },

    // 打開/關閉 泡泡匡
    setSelfNodeBubbleOpen: function (open, doneCallback) {
        this._selfNode.setBubbleOpen(open, doneCallback);
    },

    // 設定自己的node
    setSelfNodePosByRound: function (round, idx) {
        var cell = this._tableView.cellAtIndex(idx);
        if (cell) {
            this._selfNode.setPosition(this._containerLayer.convertToNodeSpace(cell.getPosByRound(round)));

            this._selfNode.setBubbleEnabled(cell.getRoundIsOnSteadyNode(round));
        }
    },

    // 設定自己要跑到什麼數字
    setSelfNodeRoundWithDuration: function (round, time) {
        this._selfNode.setRoundWithDuration(round, time);
    },

    // 設定自己的node是最強, 跑動畫時用的到
    setSelfNodeIsTop: function (isTop) {
        this._selfNode.setBubbleIsTop(isTop);
    },

    // 要是自己節點停在特定cell的其中一個固定節點, 原本的要先隱藏, 然後自己的node要可以按
    checkPlayerNodeNeedToHide: function (round, idx) {
        var cell = this._tableView.cellAtIndex(idx);
        if (cell) {
            cell.checkSteadyNodeNeedToHide(round);
            this._selfNode.setBubbleEnabled(cell.getRoundIsOnSteadyNode(round));
        }
    },

    // 開始跑動畫
    runningRouteAnimationAsync: function (cellIdx, oldRound, newRound, resolve, reject) {
        return new Promise(() => {
            if (this.__isDestroyed)
                return reject();
            // 先移動到那裡
            this._tableView.setContentOffset(this._calculateTableCellOffsetByCellIdx(cellIdx - 3), true);

            var cell = this._tableView.cellAtIndex(cellIdx);

            if (cell) {
                this._selfNode.stopAllActions();

                var seq = cc.sequence(cell.getAnimationByRound(oldRound, newRound, this._containerLayer, this._selfNode), cc.callFunc(() => {
                    return resolve();
                }));

                this._selfNode.runAction(seq);
            } else
                return reject();
        });
    },

    // tableView移動到特定idx
    moveToIdx: function (idx) {
        this._tableView.setContentOffset(this._calculateTableCellOffsetByCellIdx(idx));
    },

    // 要不要額外貼一個最強的node, 演動畫時用的到
    setTopPlayerShow: function (isShow) {
        if (this._topPlayerNode) {
            this._topPlayerNode.setOpen(false, () => {
                this._topPlayerNode.removeFromParent();
                this._topPlayerNode = null;
            });
        }

        if (isShow) {
            var data = DataModal.cardKingData.getMapInfoByLevel(this._selectedLevel);
            if (data) {
                var topPlayerData = data.topPlayer;

                var index = DataModal.cardKingData.getIndexBySearchCurrentDetail(this._selectedLevel, topPlayerData.roundOnCell);

                // 移到那
                this.moveToIdx(index);

                var cell = this._tableView.cellAtIndex(index);

                if (cell) {
                    var topPlayerNode = this._topPlayerNode = new CardKingMapPlayerNode();
                    topPlayerNode.refresh(topPlayerData, this._selectedLevel);
                    topPlayerNode.setPosition(this._containerLayer.convertToNodeSpace(cell.getPosByRound(topPlayerData.roundOnCell)));
                    topPlayerNode.changeArrowDirection(cell.getBubbleDirectionByRound(topPlayerData.roundOnCell));
                    this._containerLayer.addChild(topPlayerNode, this.SELF_NODE_ZORDER);
                }
            }
        }
    },

    // 計算到特定cell的offset
    _calculateTableCellOffsetByCellIdx: function (targetCellIndex) {
        var offsetX = 0;

        for (var i = 0; i <= targetCellIndex; ++i)
            offsetX -= CardKingMapRouteCell.getCellSizeByIndex(i).width

        offsetX = Math.max(offsetX, this._tableView.minContainerOffset().x);
        offsetX = Math.min(offsetX, this._tableView.maxContainerOffset().x);
        return cc.p(offsetX, 0);
    },

    // 倒數更新資料
    _scheduleCountdown: function () {
        var leftTime = JSCodeUtility.getRemainTime(this._remainTime, this._socketTime);

        // 時間到了要重要資料
        if (this._remainTime != 0 && leftTime <= 0) {
            this.unschedule(this._scheduleCountdown);
            if (!this._hasBeenAsk[this._selectedLevel]) {
                DataModal.cardKingData.startGetMapInfoByLevel(this._selectedLevel);
                this._hasBeenAsk[this._selectedLevel] = true;
                this._loadingSp.start();
            }
        }
    },

    // 關掉節點上玩家的詳細榜單泡泡匡
    _closePlayerDetailBubble: function () {
        if (this._playerDetailBubble) {
            this._playerDetailBubble.close();
            this._playerDetailBubble = null;
        }
    },

    /**
     * TableView delegate
     */

    scrollViewDidScroll: function () {
        this._closePlayerDetailBubble();
    },

    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        var data = DataModal.cardKingData.getMapInfoByLevel(this._selectedLevel);

        if (!cell) {
            cell = new CardKingMapRouteCell();
        }
        cell.refresh(idx, data.mapRouteList[idx], this._selectedLevel);

        if (this._selfNode)
            cell.checkSteadyNodeNeedToHide(this._selfNode.round);

        // idx比較大的需要壓在上面, 所以這裡設定zorder
        cell.setLocalZOrder(idx);

        return cell;
    },

    numberOfCellsInTableView: function (table) {
        var data = DataModal.cardKingData.getMapInfoByLevel(this._selectedLevel);

        var count = data && data.mapRouteList.length;

        if (count !== undefined) {
            // 要是是最少節點少就補到最少節點
            if (count < this.MINIMUM_CELL_COUNT)
                count = this.MINIMUM_CELL_COUNT;

            // 多3個cell最後才不會空空的
            count += 3;

            return count;
        }
        return 0;
    },

    tableCellSizeForIndex: function (table, idx) {
        return CardKingMapRouteCell.getCellSizeByIndex(idx);
    },

    /**
     * 通知
     */
    // 地圖資料好了
    notifyCardKingMapInfoDone: function (event) {
        if (event && event.getUserData() !== undefined) {
            var level = event.getUserData();
            this._hasBeenAsk[level] = false;

            if (this._selectedLevel === Number(level)) {
                this.refresh(false, true, true);
            }
        }
    },

    // 自己玩家資料好了
    notifyCardKingMapPlayerInfoDone: function (event) {
        if (event && event.getUserData() !== undefined) {
            var level = event.getUserData();
            this._selfDataHasBeenAsk[level] = false;

            if (this._selectedLevel === Number(level)) {
                this.refresh(false, true);
            }
        }
    },

    // 跳泡泡匡
    notifyCardKingMapShowPlayerBubble: function (event) {
        if (event && event.getUserData() !== undefined) {
            var param = event.getUserData();

            var node = new CardKingMapPlayerBubbleNode(param.level, param.round);

            this._closePlayerDetailBubble();

            // 先轉成這裡的座標等等算有沒有超過螢幕才會準
            var nodePos = this.convertToNodeSpace(param.pos);

            // 判斷泡泡匡會不會超出銀幕
            // 上下開的泡泡匡的只要算一半的寬度就好, 7 跟14是泡泡匡額外的寬度
            var offset = JSVisibleSize.width - (node.getContentSize().width / 2 + 7 + nodePos.x);

            if (param.direct === BaseMessageNode.Direct.LEFT)
                offset = JSVisibleSize.width - (node.getContentSize().width + 14 + nodePos.x);

            var messageParam = {};
            messageParam.mainNode = node;
            messageParam.style = BaseMessageNode.Style.WHITE_SHADOW;
            messageParam.direct = param.direct;

            // 會超出銀幕
            if (offset < 0) {
                // 出現在右邊就直接換一邊跳出
                if (param.direct === BaseMessageNode.Direct.LEFT) {
                    messageParam.direct = BaseMessageNode.Direct.RIGHT;
                } else {
                    messageParam.arrowPadding = offset;
                }
            }

            var bubbleNode = this._playerDetailBubble = new BaseMessageNode(messageParam);

            bubbleNode.setPosition(this._containerLayer.convertToNodeSpace(param.pos));
            bubbleNode.show();
            this._containerLayer.addChild(bubbleNode, this.SELF_NODE_ZORDER);
        }
    },

    // 關泡泡匡
    notifyCardKingMapCloseBubble: function () {
        this._closePlayerDetailBubble();
    }
});