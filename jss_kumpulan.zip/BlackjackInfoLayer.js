/**
 * 21點一進去的說明頁
 */
var BlackjackInfoLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this.setCascadeOpacityEnabled(true);

        // 背景黑底
        var bgColorLayer = new cc.LayerColor(cc.color(0, 0, 0, 150), JSVisibleSize.width, JSVisibleSize.height);
        this.addChild(bgColorLayer, -10000);

        // 背景底
        var bgSize = cc.size(380, 146);
        var bgSprite = this._bgSprite = new ccui.Scale9Sprite("bj_rule_bg01.png");
        bgSprite.setPreferredSize(bgSize);
        bgSprite.setPosition(JSScreenMidPos);
        this.addChild(bgSprite);

        // 關閉按鈕
        var sprite1 = new cc.Sprite("#btn_close_on.png");
        var sprite2 = new cc.Sprite("#btn_close_on.png");
        sprite2.setColor(JSColor.GRAY);
        var menuItem = new cc.MenuItemSprite(sprite1, sprite2, this._closeClicked, this);
        var menu = new cc.Menu(menuItem);
        menu.setPosition(JSScreenMidPos.x + bgSize.width / 2 - 18, JSScreenMidPos.y + bgSize.height / 2 - 18);
        this.addChild(menu);

        // 說明文字
        var bjString = LocalizedString.Blackjack;
        var infoString = [
            bjString("五　龍：持牌達五張"),
            bjString("→　1 賠 3"),
            bjString("７７７：持牌達三張７"),
            bjString("→　1 賠 10"),
            bjString("同花順：持牌同花６７８"),
            bjString("→　1 賠 15"),
        ];

        for (var i = 0; i < 3; i++) {
            var title1 = new cc.LabelTTF(infoString[i * 2], JSFontBoldName, 16);
            title1.setAnchorPoint(0, 0.5);
            title1.setPosition(JSScreenMidPos.x - 170, JSScreenMidPos.y + 35 - (i * 35));
            this.addChild(title1);

            var title2 = new cc.LabelTTF(infoString[i * 2 + 1], JSFontBoldName, 16);
            title2.setAnchorPoint(0, 0.5);
            title2.setPosition(JSScreenMidPos.x + 100, JSScreenMidPos.y + 35 - (i * 35));
            this.addChild(title2);
        }

        // 幾秒後關掉畫面
        this.runAction(cc.sequence(
            cc.delayTime(10),
            cc.callFunc(this._closeClicked, this)
        ));

        // 加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this.onTouchBegan.bind(this)
        }, this);

        // 註冊Event
        var self = this;
        GS.addListener("NotifyCloseBlackjackInfo", function () {
            self._closeClicked();
        }, this);
    },

    /**
     * 關閉
     */
    _closeClicked: function () {
        if (this._isClosed)
            return;

        this._isClosed = true;

        // 關掉畫面
        this.runAction(cc.sequence(
            cc.fadeOut(0.5),
            cc.removeSelf()
        ));
    },

    /**
     * Touch
     */
    onTouchBegan: function (touch, event) {
        var target = event.getCurrentTarget();
        if (!target.isVisible())
            return false;
        for (var c = target.parent; c != null; c = c.parent) {
            if (!c.isVisible())
                return false;
        }

        var boundBox = this._bgSprite.getBoundingBox();
        var touchPos = this.convertToNodeSpace(touch.getLocation());

        if (!cc.rectContainsPoint(boundBox, touchPos)) {
            // 關掉畫面
            this._closeClicked();
        }

        return this.isVisible();
    }
});