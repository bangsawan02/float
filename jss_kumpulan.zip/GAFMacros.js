var gaf = gaf || {};

(function () {
    // Native 下載GAF的時後是否要用GSHttpDownloader去處理 false的話會改用jsb.Downloader
    gaf.DOWNLOAD_FILE_USE_HTTP = true;

    // Native要把gaf.Asset轉成Native的GAFAsset
    if (cc.sys.isNative)
        gaf.Asset = GAFAsset;

    /**
     * Preload GAF Native下會開新的thread來創GAF, 可以讓圖片跟GAFAsset先載入好放到cache裡
     * preload完後還是要自行使用gaf.create去創GAF
     * @param {string} gafFilePath 檔名
     * @param {function} callback
     */
    gaf.preloadAsync = function (gafFilePath, callback) {
        if (GAFCustomAssetManager.preloadAsync) {
            GAFCustomAssetManager.preloadAsync(gafFilePath, callback);
        } else {
            // Native還沒更新這東西 直接callback
            callback && callback();
        }
    };

    /**
     * Preload GAF Native下會開新的thread來創GAF, 可以讓圖片跟GAFAsset先載入好放到cache裡
     * preload完後還是要自行使用gaf.createWithBundle去創GAF
     * @param {string} zipFilePath 檔名
     * @param {string} entryFile 進入點
     * @param {function} callback
     */
    gaf.preloadBundleAsync = function (zipFilePath, entryFile, callback) {
        if (GAFCustomAssetManager.preloadBundleAsync) {
            GAFCustomAssetManager.preloadBundleAsync(zipFilePath, entryFile, callback);
        } else {
            // Native還沒更新這東西 直接callback
            callback && callback();
        }
    };

    /**
     * @description 創GAF用的東西 (非zip檔)
     * @param {string} gafFilePath 檔名
     * @param {cc.Node} baseNode
     * @param {boolean} fromCache 是否從Cache
     * @param {function} callback
     * @param {function} errorCallback
     */
    gaf.create = function (gafFilePath, baseNode, fromCache, callback, errorCallback) {
        var gafAsset;
        if (fromCache)
            gafAsset = GAFCustomAssetManager.createAsset(gafFilePath, null, baseNode);
        else
            gafAsset = gaf.Asset.create(gafFilePath, null, baseNode);
        if (gafAsset && gafAsset.addEventListener) {
            //Html 自己多轉一層把Asset帶進去
            var onLoad = function () {
                callback && callback(gafAsset);

                gafAsset.removeEventListener("loadError", onError);
            };
            var onError = function () {
                errorCallback && errorCallback();

                //砍掉GAFAsset Ref
                GAFCustomAssetManager.removeAsset(gafFilePath);

                gafAsset.removeEventListener("load", onLoad);
            };
            gafAsset.addEventListener("load", onLoad);
            gafAsset.addEventListener("loadError", onError);
        } else {
            //原生 (有Asset或沒有ErrorCallback都這這條)
            if (gafAsset || !errorCallback)
                callback && callback(gafAsset);
            else
                errorCallback && errorCallback();
        }

        return gafAsset;
    };

    /**
     * 創GAF用的東西 (zip檔)
     * @description 創GAF用的東西 (zip檔)
     * @param {string} zipFilePath 檔名
     * @param {string} entryFile 進入點
     * @param {cc.Node} baseNode
     * @param {boolean} fromCache 是否從Cache
     * @param {function} callback
     */
    gaf.createWithBundle = function (zipFilePath, entryFile, baseNode, fromCache, callback, errorCallback) {
        var gafAsset;
        if (fromCache)
            gafAsset = GAFCustomAssetManager.createAssetWithBundle(zipFilePath, entryFile, null, baseNode);
        else
            gafAsset = gaf.Asset.createWithBundle(zipFilePath, entryFile, null, baseNode);
        if (!gafAsset)
            cc.log(zipFilePath);
        if (gafAsset && gafAsset.addEventListener) {
            //Html 自己多轉一層把Asset帶進去
            var onLoad = function () {
                callback(gafAsset);

                gafAsset.removeEventListener("loadError", onError);
            };
            var onError = function () {
                errorCallback && errorCallback();

                //砍掉GAFAsset Ref
                GAFCustomAssetManager.removeAsset(zipFilePath);

                gafAsset.removeEventListener("load", onLoad);
            };
            gafAsset.addEventListener("load", onLoad);
            gafAsset.addEventListener("loadError", onError);
        } else {
            //原生 (有Asset或沒有ErrorCallback都這這條)
            if (gafAsset || !errorCallback)
                callback(gafAsset);
            else
                errorCallback();
        }

        return gafAsset;
    };


    /**
     * 創GAF用的東西 且在原上下可以下載 (zip檔)
     * @description 創GAF用的東西 且在原上下可以下載 (zip檔)
     * @param {url} url
     * @param {檔名} zipFilePath
     * @param {進入點} entryFile
     * @param {Node} baseNode
     * @param {Func} callback
     * @param {Func} errorCallback
     */
    gaf.createAndDownloadWithBundle = function (url, zipFilePath, entryFile, baseNode, callback, errorCallback) {
        if (cc.sys.isNative && zipFilePath) {
            if (jsb.fileUtils.isFileExist(zipFilePath)) {
                // 代表檔案已經在了
                return gaf.createWithBundle(zipFilePath, entryFile, baseNode, true, callback, errorCallback);
            }
            else {
                // 判斷是否在包在App裡
                var fileName = zipFilePath.replace(JSWriteablePath, "");
                var isInApp = jsb.fileUtils.isFileExist(fileName);
                if (isInApp) {
                    // 代表檔案包在App裡
                    if (cc.sys.os === cc.sys.OS_IOS)
                        return gaf.createWithBundle(fileName, entryFile, baseNode, true, callback, errorCallback);
                    else {
                        // Android要把ZIP檔copy到可以寫的地方才行
                        var gafData = jsb.fileUtils.getDataFromFile(fileName);

                        // 要先判斷savePath是否需要創資料夾
                        var targetArr = zipFilePath.split("/");
                        var filename = targetArr.pop();
                        var directoryPath = targetArr.join("/");
                        if (!jsb.fileUtils.isDirectoryExist(directoryPath)) {
                            //沒有資料夾就幫他新增
                            jsb.fileUtils.createDirectory(directoryPath);
                        }

                        // 寫入檔案
                        var success = jsb.fileUtils.writeDataToFile(gafData, zipFilePath);
                        if (success)
                            return gaf.createWithBundle(zipFilePath, entryFile, baseNode, true, callback, errorCallback);
                    }
                }

                // 不存在 要去下載
                var downloaderCallback = new GSDownloaderCallback(this);
                downloaderCallback.onTaskSuccess = function () {
                    // 下載成功 去創
                    gaf.createWithBundle(zipFilePath, entryFile, baseNode, true, callback, errorCallback);
                };
                downloaderCallback.onTaskError = function (task, errorCode, errorCodeInternal, errorStr) {
                    // 下載失敗 把檔案也清掉
                    jsb.fileUtils.removeFile(zipFilePath);

                    // 直接error callback
                    if (errorCallback)
                        errorCallback();
                    else
                        callback(null);
                };

                // 開始下載
                GSDownloaderManager.addDownloader(url, zipFilePath, null, downloaderCallback, gaf.DOWNLOAD_FILE_USE_HTTP);
            }
        }
        else {
            return gaf.createWithBundle(url, entryFile, baseNode, true, callback, errorCallback)
        }
    };

    /**
     * 創GAF用的東西 且在原上下可以用多網域下載 (zip檔)
     * @description 創GAF用的東西 且在原上下可以下載 (zip檔)
     * @param {Array} domainList
     * @param {url} url
     * @param {檔名} zipFilePath
     * @param {進入點} entryFile
     * @param {Node} baseNode
     * @param {Func} callback
     * @param {Func} errorCallback
     */
    gaf.createAndMultiDomainDownloadWithBundle = function (domainList, url, zipFilePath, entryFile, baseNode, callback, errorCallback) {
        if (cc.sys.isNative && zipFilePath) {
            if (jsb.fileUtils.isFileExist(zipFilePath)) {
                // 代表檔案已經在了
                return gaf.createWithBundle(zipFilePath, entryFile, baseNode, true, callback, errorCallback);
            }
            else {
                // 判斷是否在包在App裡
                var fileName = zipFilePath.replace(JSWriteablePath, "");
                var isInApp = jsb.fileUtils.isFileExist(fileName);
                if (isInApp) {
                    // 代表檔案包在App裡
                    if (cc.sys.os === cc.sys.OS_IOS)
                        return gaf.createWithBundle(fileName, entryFile, baseNode, true, callback, errorCallback);
                    else {
                        // Android要把ZIP檔copy到可以寫的地方才行
                        var gafData = jsb.fileUtils.getDataFromFile(fileName);

                        // 要先判斷savePath是否需要創資料夾
                        var targetArr = zipFilePath.split("/");
                        var filename = targetArr.pop();
                        var directoryPath = targetArr.join("/");
                        if (!jsb.fileUtils.isDirectoryExist(directoryPath)) {
                            //沒有資料夾就幫他新增
                            jsb.fileUtils.createDirectory(directoryPath);
                        }

                        // 寫入檔案
                        var success = jsb.fileUtils.writeDataToFile(gafData, zipFilePath);
                        if (success)
                            return gaf.createWithBundle(zipFilePath, entryFile, baseNode, true, callback, errorCallback);
                    }
                }

                // 下載的設定
                var downloaderCallback = new GSDownloaderCallback(this);
                downloaderCallback.onTaskSuccess = (task) => {
                    // 下載成功 去創
                    gaf.createWithBundle(zipFilePath, entryFile, baseNode, true, callback, errorCallback);
                };
                downloaderCallback.onTaskError = (task, errorCode, errorCodeInternal, errorStr) => {
                    // 下載失敗 把檔案也清掉
                    jsb.fileUtils.removeFile(zipFilePath);

                    // 直接error callback
                    if (errorCallback)
                        errorCallback();
                    else
                        callback(null);
                };

                // 用多個網域嘗試下載
                GSDownloaderManager.downloadWithMultiDomain(domainList, url, zipFilePath, downloaderCallback);
            }
        }
        else {
            // h5直接載
            return gaf.createWithBundle(GS.httpScheme + "//" + domainList[0] + url, entryFile, baseNode, true, callback, errorCallback)
        }
    };

    /**
     * retain所有GAF Asset
     */
    gaf.retainAllAsset = function () {
        cc.sys.isNative || GAFCustomAssetManager.retainAllAsset();
    };

    /**
     * release所有GAF Asset
     */
    gaf.releaseAllAsset = function () {
        cc.sys.isNative || GAFCustomAssetManager.releaseAllAsset();
    };

}.call((window || module || {})));
