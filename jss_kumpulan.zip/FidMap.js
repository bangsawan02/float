/**
 * 副系統的 FID 對照表
 */
var FidMap = {
    GAMBLER_ROAD: 5648,             // 牌王之路
    TOKEN_SUBSYSTEM: 5928,          // 代幣副系統
    VEGAS_COMPETE: 3818,            // VIP爭霸賽
    SPEED_RACING: 3935,             // 極速競飆
    VEGAS_MAP_MISSION: 5748,        // 地圖式任務
    LUCKY_LOTTERY: 6796,            // 新儲值中心抽獎活動
    STONE_GAMBLING: 6766,           // 賭石大師
    LIMITED_GROUP_BONUS: 7233,      // 限時加贈
    VEGAS_DRAGON_VS_LEOPARD: 4412,  // 龍豹對決
    VEGAS_TEBAKQQ: 7830,            // TebakQQ機台
    CARD_KING: 8060,                // 牌王系統
    CARD_RANK_DOUBLE: 8048,         // 大底台Poker積分加倍
};