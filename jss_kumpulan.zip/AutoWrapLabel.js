/**
 * 超過寬度切割「單字」自動換行的 Label，目前只對英文有效
 *
 * @example
 * new AutoWrapLabel("Content", JSFontName, 12, 50);
 *
 * @param {string} text     內文
 * @param {string} fontName 字型
 * @param {number} fontSize 字型大小
 * @param {number} maxWidth 最大寬度
 *
 * @author tony.cheng
 */
var AutoWrapLabel = cc.LabelTTF.extend({
    ctor: function (text, fontName, fontSize, maxWidth) {
        this._super("", fontName, fontSize);
        this._maxWidth = maxWidth;
        this.setString(text);
    },

    _refreshView: function () {
        // 切字
        let words = this._originalString.split(" ");
        let wrappedText = "";
        let currentLine = "";

        // 走訪所有的單字
        words.forEach((word) => {
            // 試著將單字加入當前行
            let testLine = currentLine + word + " ";
            // 先暫時設定行內容，並測量寬度
            cc.LabelTTF.prototype.setString.call(this, testLine.trim());

            // 如果目前行的寬度超過最大寬度，將當前行結束並換行
            if (this.getContentSize().width > this._maxWidth) {
                wrappedText += currentLine.trim() + "\n";
                // 開始新的一行
                currentLine = word + " ";
            } else {
                // 如果不超過寬度，繼續將單字加入當前行
                currentLine = testLine;
            }
        });

        // 將最後一行加入到 wrappedText
        wrappedText += currentLine.trim();

        // 設定最終的行內容
        cc.LabelTTF.prototype.setString.call(this, wrappedText);
    },

    /**
     * 設定文字
     * @param {string} text 文字
     */
    setString: function (text) {
        cc.LabelTTF.prototype.setString.call(this, text);
        this._originalString = text;
        this._refreshView();
    },

    /**
     * 設定最大寬度
     * @param {number} width 最大寬度
     */
    setMaxWidth: function (width) {
        this._maxWidth = width;
        this._refreshView();
    },

    /**
     * 設定寬度與高度
     * @param {cc.Size} dim 寬度與高度
     * @param {number} height 高度
     */
    setDimensions: function (dim, height) {
        cc.LabelTTF.prototype.setDimensions.call(this, dim, height);
        this._maxWidth = height ? dim : dim.width;
        this._refreshView();
    },

    /**
     * 設定字型大小
     * @param {number} fontSize 字型大小
     */
    setFontSize: function (fontSize) {
        this._super(fontSize);
        this._refreshView();
    },

    /**
     * 取得原始文字
     * @returns {string} 原始文字
     */
    getString: function () {
        return this._originalString;
    }
});
