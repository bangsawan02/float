/**
 * v5.4.5 背包 - 背包物品 Dialog (目前只給比賽卷用)
 */

var BackpackItemDialog = BaseDialogLayer.extend({
    /**
     * param = {
     *     name : 物品名稱
     *     info : 物品資訊
     *     serial : 物品編號 (載入圖片用)
     *     button : 按鈕功能 (套用lobbyBannerMode前往別頁)
     * }
     */
    ctor: function (param) {
        this._super();

        this.key = "BackpackItemDialog";

        var aniLayer = this._animationLayer;

        // 背景
        var bgSize = cc.size(330, 220);
        var bgSp = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSp.setPreferredSize(bgSize);
        bgSp.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSp);

        // 商品標題
        var titleLabel = new cc.LabelTTF(param.name, JSFontName, 15);
        titleLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + bgSize.height / 2 - 30);
        aniLayer.addChild(titleLabel);

        // 說明背景
        var whiteBgSize = cc.size(260, 110);
        var whiteBg = new ccui.Scale9Sprite("bg_white_02.png");
        whiteBg.setPreferredSize(whiteBgSize);
        whiteBg.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 5);
        aniLayer.addChild(whiteBg);

        // 說明
        var descLabelFontSize = 11;
        var descLabel = new cc.LabelTTF(param.info, JSFontName, descLabelFontSize, cc.size(140, 0));
        descLabel.setPosition(172, whiteBgSize.height / 2);
        descLabel.setFontFillColor(JSColor.BLACK);
        whiteBg.addChild(descLabel);
        while (descLabel.getContentSize().height > 100) {
            descLabelFontSize -= 0.5;
            descLabel.setFontSize(descLabelFontSize);
        }

        // 圖片
        var imageNode = new AccessoryItemNode(param.serial, 45, 45);
        imageNode.setPosition(50, whiteBgSize.height / 2);
        if (param.type === ShopType.OTHER)
            imageNode.setScale(1.7);
        whiteBg.addChild(imageNode);

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.addTouchUpInsideAction(this._closeDialogAnimation, this);
        closeBtn.setPosition(JSScreenMidPos.x + bgSize.width / 2 - 5, JSScreenMidPos.y + bgSize.height / 2 - 5);
        aniLayer.addChild(closeBtn);

        if (PushScene.isLobby) {
            // 按鈕
            var btnString = LocalizedString.Lobby("馬上玩");
            if (param.button === LobbyBannerMode.GameListType0 || param.button === LobbyBannerMode.GameListType1) {
                btnString += JSStringUtility.format("\n(%s)", GSEnum.GameName[param.url || GSEnum.Game.Texas19]);
            }
            var button = ButtonUtility.createSimpleButton("lobby_btn_01.png", cc.size(100, 35), btnString, JSColor.BLACK, 14);
            button.label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            button.setPosition(JSScreenMidPos.x, 67 + JSScreenBonusHalfHeight);
            button.addTouchUpInsideAction(() => {
                // 關掉自己
                this._closeDialogAnimation();

                // 關掉所有畫面
                DialogManager.cleanAllDialog(true);

                // 推到頁面
                PushLayerHelper.pushLayer(param.buttonUrl, param.button);
            }, this);
            aniLayer.addChild(button);
        }
    }
});