/**
 * 大樂彩中獎通知banner   印尼目前沒用到
 * Created by yuki.huang on 2021/9/14.
 * 5.4.2 移植自中文德撲 by Jim.chen
 */
var BigLotteryNotifyBannerDialog = BaseDialogLayer.extend({
    ctor: function (param) {
        this._super();

        // 先設定此Dialog的Key 之後容易砍
        this.key = "BigLotteryNotifyBannerDialog.js";

        // 需要讀取的素材
        this.loadFileArray = ["lobby/bigLottery/bigLottery.plist", "lobby/bigLottery/bigLottery.png",
            "lobby/lotteryShop/lotteryShop.plist", "lobby/lotteryShop/lotteryShop.png"];

        this._param = param;
    },

    // 清掉不用的東西
    onExit: function () {
        if (this._loadFileDone) {
            cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[0]);
            cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[3]);
        }

        this._super();
    },

    /**
     * 讀取素材完畢
     */
    loadFileDone: function () {
        this._super();

        cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[0], this.loadFileArray[1]);
        cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[2], this.loadFileArray[3]);

        var param = this._param;
        var aniLayer = this._animationLayer;

        // 標題
        gaf.create("gaf/bigLottery/bigLotteryTitle.gaf", this, true, (gafAsset) => {
            var gafObject = gafAsset.createObjectAndRun(true);
            gafObject.setPosition(JSScreenMidPos.x, 235 + JSScreenBonusHalfHeight);
            aniLayer.addChild(gafObject, 2);
        });

        // 左邊背景
        var bgLSprite = new cc.Sprite("#bigLottery_banner_bg_giftpackage_01.png");
        bgLSprite.setPosition(JSScreenMidPos.x + 2, 117 + JSScreenBonusHalfHeight);
        bgLSprite.setScale(1.2);
        bgLSprite.setAnchorPoint(1, 0.5);
        aniLayer.addChild(bgLSprite);

        // 右邊背景
        var bgRSprite = new cc.Sprite("#bigLottery_banner_bg_giftpackage_01.png");
        bgRSprite.setPosition(JSScreenMidPos.x - 2, 117 + JSScreenBonusHalfHeight);
        bgRSprite.setFlippedX(true);
        bgRSprite.setScale(1.2);
        bgRSprite.setAnchorPoint(0, 0.5);
        aniLayer.addChild(bgRSprite);

        // 左邊背景光
        var bgLRedSprite = new cc.Sprite("#bigLottery_banner_bg_red.png");
        bgLRedSprite.setPosition(JSScreenMidPos.x + 1, 117 + JSScreenBonusHalfHeight);
        bgLRedSprite.setAnchorPoint(1, 0.5);
        aniLayer.addChild(bgLRedSprite);

        // 右邊背景光
        var bgRRedSprite = new cc.Sprite("#bigLottery_banner_bg_red.png");
        bgRRedSprite.setPosition(JSScreenMidPos.x - 1, 117 + JSScreenBonusHalfHeight);
        bgRRedSprite.setFlippedX(true);
        bgRRedSprite.setAnchorPoint(0, 0.5);
        aniLayer.addChild(bgRRedSprite);

        // 左邊金幣
        var coinLSprite = new cc.Sprite("#bigLottery_pic_coin.png");
        coinLSprite.setFlippedX(true);
        coinLSprite.setPosition(JSScreenMidPos.x - 116, 224 + JSScreenBonusHalfHeight);
        aniLayer.addChild(coinLSprite);

        // 右邊金幣
        var coinRSprite = new cc.Sprite("#bigLottery_pic_coin.png");
        coinRSprite.setPosition(JSScreenMidPos.x + 116, 224 + JSScreenBonusHalfHeight);
        aniLayer.addChild(coinRSprite);

        // 財神
        var godSprite = new cc.Sprite("#lotteryShop_pic_god.png");
        godSprite.setPosition(JSScreenMidPos.x + 147, 70 + JSScreenBonusHalfHeight);
        aniLayer.addChild(godSprite);

        // avatar 太大了 要加Clip
        var drawNode = new cc.DrawNode();
        drawNode.drawRect(cc.p(JSScreenMidPos.x - 172, 30 + JSScreenBonusHalfHeight), cc.p(JSScreenMidPos.x - 50, 200 + JSScreenBonusHalfHeight), JSColor.BLACK);

        var clipNode = new cc.ClippingNode(drawNode);
        aniLayer.addChild(clipNode);

        // avatar
        var avatar = new cc.Sprite("common/bg_avatar_12027.png");
        avatar.setPosition(JSScreenMidPos.x - 136, 130 + JSScreenBonusHalfHeight);
        clipNode.addChild(avatar);

        // 按鈕
        var btn = ButtonUtility.createSimpleButton("button_pink.png", cc.size(104, 40), "太棒了", JSColor.WHITE, 14);
        btn.addTouchUpInsideAction(this._closeDialogAnimation, this);
        btn.setPosition(JSScreenMidPos.x, 62 + JSScreenBonusHalfHeight);
        aniLayer.addChild(btn);

        var topString = JSStringUtility.format("恭喜您於%s期中了\n#!FFFF00!#%s", param.period, param.prizeName);
        var topLabel = new GSRichLabelNode(topString, JSFontBoldName, 10, cc.size(190, 0));
        topLabel.setPosition(JSScreenMidPos.x, 148 + JSScreenBonusHalfHeight);
        topLabel.setAnchorPoint(.5, 0);
        aniLayer.addChild(topLabel);

        var rewardString = "";
        if (param.money)
            rewardString = JSStringUtility.format("彩金：%s", JSCodeUtility.getCurrencyString(param.money));

        if (param.rewardList.length > 0) {
            rewardString += rewardString == "" ? "道具：" : "\n道具：";
            for (var i = 0; i < param.rewardList.length; i++) {
                rewardString += JSStringUtility.format("%s*%s", param.rewardList[i].name, param.rewardList[i].count);
                if (i < param.rewardList.length - 1) rewardString += "\n";
            }
        }

        // 獎品
        var scrollViewSize = cc.size(190, 50);
        var container = new cc.Layer();
        var scrollView = new cc.ScrollView(scrollViewSize, container);
        scrollView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        scrollView.setPosition(JSScreenMidPos.x - scrollViewSize.width / 2, 120 + JSScreenBonusHalfHeight - scrollViewSize.height / 2);
        aniLayer.addChild(scrollView);

        var rewardLabel = new GSRichLabelNode(rewardString, JSFontBoldName, 10, cc.size(scrollViewSize.width, 0));
        rewardLabel.setPosition(scrollViewSize.width / 2, 0);
        rewardLabel.setAnchorPoint(.5, 0);
        container.addChild(rewardLabel);

        container.setContentSize(rewardLabel.getContentSize());

        // 文字未超過scrollViewSize 不給滑動
        if (rewardLabel.getContentSize().height < scrollViewSize.height) {
            scrollView.setTouchEnabled(false);
            rewardLabel.setPositionY(scrollViewSize.height / 2);
            rewardLabel.setAnchorPoint(.5, .5);
        } else {
            // 滑到最上面
            scrollView.setContentOffset(cc.p(0, -(rewardLabel.getContentSize().height - scrollViewSize.height)));
        }

        var tipLabel = new cc.LabelTTF("*已自動發放獎勵", JSFontBoldName, 8);
        tipLabel.setPosition(JSScreenMidPos.x, 90 + JSScreenBonusHalfHeight);
        aniLayer.addChild(tipLabel);
    }
});
