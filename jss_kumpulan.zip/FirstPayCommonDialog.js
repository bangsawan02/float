/**
 * v5.3.8 移植 中文德撲
 * Created by yuki.huang on 2021/11/24.
 * 首儲禮包 通用dialog
 * param = {
 * title: title,        // 標題
 * content: content,    // 內文
 * callback: callback   // 關閉後的callback
 * }
 */
var FirstPayCommonDialog = BaseDialogLayer.extend({
    ctor: function (param) {
        this._super();

        this._param = param || {};

        this.key = "FirstPayCommonDialog";
    },

    loadFileDone: function () {
        this._super();

        var aniLayer = this._animationLayer;
        var param = this._param;

        var contentNode = new cc.Node();
        contentNode.setPosition(JSScreenMidPos);
        aniLayer.addChild(contentNode);

        var bg = new ccui.Scale9Sprite("lobby_bg_window.png");
        bg.setPreferredSize(cc.size(269, 166));
        contentNode.addChild(bg);

        // 標題
        var titleLabel = new cc.LabelTTF(param.title, JSFontBoldName, 12);
        titleLabel.setPositionY(63);
        contentNode.addChild(titleLabel);

        // 內文
        var contentLabel = new cc.LabelTTF(param.content, JSFontBoldName, 12);
        contentLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        contentLabel.setVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        contentLabel.setFontFillColor(cc.color(255, 240, 54));
        contentLabel.setPositionY(18);
        contentLabel.setDimensions(cc.size(230, 77));
        contentNode.addChild(contentLabel);

        // 左紙片
        var chip = new cc.Sprite("#firstPay_pic_paperflower.png");
        chip.setPosition(-132, 48);
        chip.setRotation(-25);
        contentNode.addChild(chip);

        // 右紙片
        var chip = new cc.Sprite("#firstPay_pic_paperflower.png");
        chip.setPosition(135, 8);
        chip.setRotation(-25);
        chip.setFlippedX(true);
        contentNode.addChild(chip, -1);

        // 確認按鈕
        var confirmBtn = ButtonUtility.createSimpleButton("lobby_btn_01.png", cc.size(96, 30), "OK", JSColor.BLACK, 14);
        confirmBtn.addTouchUpInsideAction(this._confirmBtnClicked, this);
        confirmBtn.setPositionY(-57);
        contentNode.addChild(confirmBtn, 2);

        // 跳Dialog
        this._startDialogAnimation();
    },

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        this._confirmBtnClicked();
    },

    // 點擊確認按鈕
    _confirmBtnClicked: function () {
        this._closeDialogAnimation();

        this._param.callback && this._param.callback();
    },
});