/**
 * 單一版桌列表 鑽石賽房間按鈕
 */
var Diamond_RoomNode = cc.Node.extend({
    ctor: function (game, type, param, callback) {
        this._super();

        this._callback = callback;

        var bgSize = cc.size(Diamond_RoomNode.NodeWidth, 212);
        var isOrange = param.gameType === TexasGameData.Game.ORANGE_DIAMOND;
        var competeString = LocalizedString.Compete;

        // 底色
        var bgSprite = new ccui.Scale9Sprite(isOrange ? "lobby_btn_tournament_04.png" : "lobby_btn_tournament_03.png");
        bgSprite.setPreferredSize(bgSize);
        this.addChild(bgSprite);

        // 標題
        var posY = bgSize.height / 2 + 2;
        {
            // 標題背景
            var titleBgSprite = new cc.Sprite("#lobby_pic_tab_01.png");
            titleBgSprite.setScaleX(2.5);
            titleBgSprite.setAnchorPoint(0.5, 1);
            titleBgSprite.setPositionY(posY);
            this.addChild(titleBgSprite);

            posY = bgSize.height / 2 - 12;

            // 背景光
            var lightSprite = new cc.Sprite("#bg_simple_alert.png");
            lightSprite.setScale(0.3);
            lightSprite.setPosition(-30, posY);
            lightSprite.runAction(cc.rotateBy(2, 180).repeatForever());
            this.addChild(lightSprite, 1);

            // 鑽石
            var diamondSprite = new cc.Sprite(isOrange ? "#pic_diamond_orange.png" : "#pic_diamond_red.png");
            diamondSprite.setScale(isOrange ? 0.35 : 0.32);
            diamondSprite.setPosition(lightSprite.getPosition());
            this.addChild(diamondSprite, 2);

            // 名稱
            var title = isOrange ? LocalizedString.Compete("orange") : LocalizedString.Compete("red");
            var titleLabel = new cc.LabelTTF(title, JSFontName, 14);
            titleLabel.setPosition(5, posY);
            this.addChild(titleLabel, 3);
        }

        if (isOrange) {
            for (var i = 0; i < 3; i++) {
                posY = bgSize.height / 2 - 37 - i * 27;

                // 名次美術字
                var rankSprite = new cc.Sprite("#lobby_word_tournament_01.png");
                rankSprite.setPosition(-50, posY);
                this.addChild(rankSprite);

                // 獎牌
                var awardSprite = new cc.Sprite("#lobby_badge_01.png");
                awardSprite.setPosition(cc.pAdd(rankSprite.getPosition(), cc.p(30, 0)));
                this.addChild(awardSprite);

                // 名次
                var rankLabel = new cc.LabelTTF(i + 1, JSFontName, 12);
                rankLabel.setFontFillColor(JSColor.PURPLE_DARK);
                rankLabel.setPosition(awardSprite.getPosition());
                this.addChild(rankLabel, 3);

                // 獎勵
                {
                    // 裝獎勵的node
                    var autoLayoutNode = new GSAutoLayoutNode();
                    autoLayoutNode.setAnchorPoint(1, 0.5);
                    autoLayoutNode.setPosition(74, posY);
                    this.addChild(autoLayoutNode);

                    // 獎金
                    var awardString = JSStringUtility.format("%s + ", TexasUtility.getSimpleMoneyString(param.rewardInfo[i].chips));
                    var moneyLabel = new cc.LabelTTF(awardString, JSFontName, 10);
                    moneyLabel.setFontFillColor(JSColor.YELLOW);
                    autoLayoutNode.addChild(moneyLabel);

                    // 鑽石圖
                    var diamondSprite = new cc.Sprite("#pic_diamond.png");
                    diamondSprite.setScale(0.8);
                    autoLayoutNode.addChild(diamondSprite);

                    // 鑽石數量
                    var diamondLabel = new cc.LabelTTF(param.rewardInfo[i].diamonds, JSFontName, 10);
                    diamondLabel.setFontFillColor(JSColor.YELLOW);
                    autoLayoutNode.addChild(diamondLabel);
                }
            }
        } else {
            posY = bgSize.height / 2 - 37;

            // 名次美術字
            var rankSprite = new cc.Sprite("#lobby_word_tournament_01.png");
            rankSprite.setPosition(-15, posY);
            this.addChild(rankSprite);

            // 獎牌
            var awardSprite = new cc.Sprite("#lobby_badge_01.png");
            awardSprite.setPosition(cc.pAdd(rankSprite.getPosition(), cc.p(30, 0)));
            this.addChild(awardSprite);

            // 名次
            var rankLabel = new cc.LabelTTF(1, JSFontName, 12);
            rankLabel.setFontFillColor(JSColor.PURPLE_DARK);
            rankLabel.setPosition(awardSprite.getPosition());
            this.addChild(rankLabel, 3);

            // 遊戲幣背景
            var chipBgSprite = new cc.Sprite("#lobby_pic_light_02.png");
            chipBgSprite.setPositionY(posY - 30);
            this.addChild(chipBgSprite);

            // 遊戲幣
            var chipSprite = new cc.Sprite("#lobby_pic_chip_02.png");
            chipSprite.setPositionY(chipBgSprite.getPositionY());
            this.addChild(chipSprite);

            // 排版用的node
            autoLayoutNode = new GSAutoLayoutNode();
            autoLayoutNode.setPositionY(posY - 60);
            this.addChild(autoLayoutNode);

            // 獎金
            var awardString = JSStringUtility.format("%s + ", TexasUtility.getSimpleMoneyString(param.rewardInfo[0].chips));
            var moneyLabel = new cc.LabelTTF(awardString, JSFontName, 10);
            moneyLabel.setFontFillColor(JSColor.YELLOW);
            autoLayoutNode.addChild(moneyLabel);

            // 鑽石圖
            var diamondSprite = new cc.Sprite("#pic_diamond.png");
            diamondSprite.setScale(0.8);
            autoLayoutNode.addChild(diamondSprite);

            // 鑽石數量
            var diamondLabel = new cc.LabelTTF(param.rewardInfo[0].diamonds, JSFontName, 10);
            diamondLabel.setFontFillColor(JSColor.YELLOW);
            autoLayoutNode.addChild(diamondLabel);
        }

        // 時間
        var messageLabel = new GSRichTextNode(param.competeTime, JSFontBoldName, 10, cc.size(bgSize.width - 10, 0));
        messageLabel.setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        messageLabel.setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        messageLabel.setPositionY(bgSize.height / 2 - 110);
        this.addChild(messageLabel);

        // 分隔線
        var lineLayer = new cc.LayerColor(JSColor.GRAY, 154, 1);
        lineLayer.setPosition(-77, bgSize.height / 2 - 120);
        this.addChild(lineLayer, 2);

        // 費用相關
        {
            // 標題
            var titleLabel = new cc.LabelTTF(competeString("成本"), JSFontName, 10);
            titleLabel.setFontFillColor(JSColor.YELLOW);
            titleLabel.setPositionY(-25);
            this.addChild(titleLabel);

            // 參賽費
            var fee = JSStringUtility.format("%s %s", competeString("參賽費:"), TexasUtility.getSimpleMoneyString(param.bringIn));
            var feeLabel = new cc.LabelTTF(fee, JSFontName, 10);
            feeLabel.setPositionY(-39);
            this.addChild(feeLabel);

            // 手續費排版的node
            var autoLayoutNode = new GSAutoLayoutNode();
            autoLayoutNode.setPositionY(-53);
            this.addChild(autoLayoutNode);

            // 手續費
            var charge = JSStringUtility.format("%s %s", competeString("手續費:"), TexasUtility.getSimpleMoneyString(param.seatFee));
            var chargeLabel = new cc.LabelTTF(charge, JSFontName, 10);
            autoLayoutNode.addChild(chargeLabel);

            // 需要鑽石
            if (param.needDiamond) {
                // +
                var plusLabel = new cc.LabelTTF(" + ", JSFontName, 10);
                autoLayoutNode.addChild(plusLabel);

                // 鑽石圖
                var diamondSprite = new cc.Sprite("#pic_diamond.png");
                diamondSprite.setScale(0.8);
                autoLayoutNode.addChild(diamondSprite);

                // 數量
                var amountLabel = new cc.LabelTTF(param.needDiamond, JSFontName, 10);
                autoLayoutNode.addChild(amountLabel);
            }
        }

        // 刷新按鈕
        this.refreshCompeteBtn(param);
    },

    refreshCompeteBtn: function (param) {
        // 清掉原本的按鈕
        this._goCompeteBtn && this._goCompeteBtn.removeFromParent();

        var competeString = LocalizedString.Compete;
        var competeStatus = DataModal.regionsData.competeStatus;

        // 參賽按鈕相關狀態
        var btnStr;
        var leftTime = 0;
        var isBtnEnable = false;

        if (param.canJoin === -1) {
            btnStr = competeString("目前非比賽時間");

            if (competeStatus.countdownTimeObject && competeStatus.countdownTimeObject[param.gameType]) {
                btnStr = "\n" + competeString("倒數開戰");

                var countdownTimeObject = competeStatus.countdownTimeObject[param.gameType];
                leftTime = (countdownTimeObject.remainTime - (JSCodeUtility.getNowTime() - countdownTimeObject.socketTime));
            }
        } else {
            if (competeStatus.closeTimeObject && competeStatus.closeTimeObject[param.gameType]) {
                var closeTimeObject = competeStatus.closeTimeObject[param.gameType];
                leftTime = (closeTimeObject.remainTime - (JSCodeUtility.getNowTime() - closeTimeObject.socketTime));
            }

            if (param.requireCheck & RegionsData.DiamondCheck.diamondClass) {
                btnStr = competeString("階級不足");
            } else {
                btnStr = competeString("馬上參賽");

                isBtnEnable = true;
            }
        }

        // 參賽按鈕
        var btnSize = cc.size(124, 36);
        var btnNode = new cc.Node();
        var goCompeteBtn = this._goCompeteBtn = new GSControlButton(btnNode, btnSize);
        goCompeteBtn.setPositionY(-80);
        goCompeteBtn.setChangeColorWhenDisabled(false);
        goCompeteBtn.addTouchUpInsideAction(this._buttonClicked, this);
        goCompeteBtn.setEnabled(isBtnEnable);
        goCompeteBtn.param = param;
        goCompeteBtn.roomType = "Compete";
        this.addChild(goCompeteBtn);

        // 參賽按鈕背景
        var bgImg = isBtnEnable ? "bt_tournament_01.png" : "bt_tournament_02.png";
        var bgSp = new ccui.Scale9Sprite(bgImg);
        bgSp.setPreferredSize(btnSize);
        btnNode.addChild(bgSp);

        // 狀態大字
        var label = new cc.LabelTTF(btnStr, JSFontName, 13);
        label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        label.setFontFillColor(JSColor.BLACK);
        btnNode.addChild(label);

        // 倒數時間
        if (leftTime > 0) {
            var timeLabel = new GSTimeLabel("", JSFontName, 13);
            timeLabel.setFormat("%mm:%ss");
            timeLabel.setFontFillColor(JSColor.RED);
            timeLabel.setPositionY(8);
            timeLabel.setVisible(!isBtnEnable && param.canJoin === -1);
            timeLabel.countdownSeconds(leftTime, () => {
                // 隱藏文字
                label.setVisible(false);
                timeLabel.setVisible(false);

                // 加上loading
                var loadingSprite = new GSLoadingSprite();
                loadingSprite.setScale(0.7);
                loadingSprite.start();
                btnNode.addChild(loadingSprite);

                // 通知重設鑽石賽
                GS.dispatchCustomEvent("NotifyDiamondReload");
            });
            btnNode.addChild(timeLabel);
        }
    },

    // 點擊按鈕
    _buttonClicked: function (sender) {
        this._callback && this._callback(sender);
    }
});

Diamond_RoomNode.NodeWidth = 170;