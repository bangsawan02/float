var Domino_UIOptionLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this._isOpen = false;
        this._isClickStandUpButton = false;
        var localString = LocalizedString.Game;

        // 選單本身
        var layer = this._container = new cc.Layer();
        layer.setVisible(false);
        layer.setScale(0);
        layer.setAnchorPoint(cc.p(0, 1));
        layer.setPosition(JSScreenSafeWidth, 0);
        this.addChild(layer, 10);

        // 背景
        var bg = new ccui.Scale9Sprite("lobby_bottom_bg.png");
        bg.setPreferredSize(cc.size(150, JSVisibleSize.height + 2));
        bg.setAnchorPoint(cc.p(0, 1));
        bg.setPosition(cc.p(0, JSVisibleSize.height + 1));
        layer.addChild(bg);

        //白色箭頭
        var arrowSprite = new cc.Sprite("#domino_pic_arrow.png");
        arrowSprite.setScaleX(-1);
        arrowSprite.setPosition(27.5, JSVisibleSize.height - 27.5);
        layer.addChild(arrowSprite);

        // 加入選單按鈕
        var btnSize = cc.size(100, 36);
        var titles = [
            localString("關閉選單"),
            localString("站起觀戰"),
            localString("更換牌桌"),
            localString("牌型"),
            localString("比牌說明"),
            localString("返回大廳"),
        ];
        this._items = [];

        var menu = this.menu = new cc.Menu();
        menu.setPosition(0, 0);
        layer.addChild(menu, 1);

        var titleLen = titles.length;
        for (var i = 0; i < titleLen; i++) {
            var itemNodes = ButtonUtility.createEmptyNodes(btnSize, titles[i], 14, JSColor.WHITE);
            var menuItem = this._items[i] = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._menuClicked, this);
            menuItem.setPosition(75, JSVisibleSize.height - 30 - 40 * i);
            menu.addChild(menuItem);

            var lineSprite = new cc.Sprite("#lobby_pic_function_line.png");
            lineSprite.setRotation(90);
            lineSprite.setScaleY(bg.getContentSize().width / lineSprite.getContentSize().height);
            lineSprite.setPosition(75, JSVisibleSize.height - 50 - 40 * i);
            layer.addChild(lineSprite);
        }

        // 比牌說明沒看過要有紅點
        var needShowBadge = parseInt(GS.localStorage.getItem("HaveSeeCardInfo", 0)) === 0;
        if (needShowBadge) {
            var badge = new BadgeNode();
            badge.useDefaultStyle();
            badge.setPosition(btnSize.width + 14, btnSize.height - 6);
            badge.setName("badge");
            badge.setScale(0.8);
            this._items[4].addChild(badge);
        }

        // 打開選單按鈕
        var openMenu = new cc.Menu();
        openMenu.setPosition(0, 0);
        this.addChild(openMenu);

        var opneNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_07.png", null, "#game_btn_back.png");
        var openItem = this.openItem = new cc.MenuItemSprite(opneNodes[0], opneNodes[1], opneNodes[2], this._menuOpen, this);
        openItem.setPosition(18 + JSScreenSafeWidth, JSVisibleSize.height - 18);
        openMenu.addChild(openItem);

        // 每日任務
        var missionBtn = new DailyMissionGameButton();
        missionBtn.addTouchUpInsideAction(this._missionClicked, this);
        missionBtn.setVisible(!DataModal.profileData.isBlackAccount);
        missionBtn.setPosition(openItem.getPositionX() + 36, JSVisibleSize.height - 18);
        this.addChild(missionBtn);

        // 自動排版
        var autoLayoutNode = new GSAutoLayoutNode();
        autoLayoutNode.setType(GSAutoLayout.TYPE.HORIZONTAL);
        autoLayoutNode.setAnchorPoint(0, 0.5);
        autoLayoutNode.setPosition(missionBtn.getPositionX() + 22, JSVisibleSize.height - 17);

        // 副系統任務icon
        var missionButton = new Texas_GameMissionButton(true);
        autoLayoutNode.addChild(missionButton);

        autoLayoutNode.addEmptyNode(cc.size(20, 0));

        // 牌王之路(有排行榜, 所以zOrder要高些)
        var gamblerRoadNode = new GamblerRoadIconNode(GamblerRoadIconNode.Type.GAME);
        autoLayoutNode.addChild(gamblerRoadNode, 1);

        this.addChild(autoLayoutNode);

        //加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this._onTouchBegan.bind(this)
        }, this);

        //通知
        GS.addListener("NotifyGameUIStandUpClicked", this.notifyGameUIStandUpClicked.bind(this), this);
        GS.addListener("NotifyGameUICancelReplaceRoom", this.notifyGameUICancelReplaceRoom.bind(this), this);
        GS.addListener("NotifyGameUICancelStandUp", this.notifyGameUICancelStandUp.bind(this), this);
    },

    /**
     *  設定/取得是否點了按站起按鈕
     */
    getIsClickStandUpButton: function () {
        return this._isClickStandUpButton;
    },

    setIsClickStandUpButton: function (value) {
        this._isClickStandUpButton = value;
    },

    /**
     * 暫停換桌、站起
     */
    tmpStopReplaceRoom: function () {
        var _this = this;
        this._items[1].setEnabled(false);
        this._items[2].setEnabled(false);
        this.stopAllActions();
        this.runAction(cc.sequence(
            cc.delayTime(6),
            cc.callFunc(function () {
                _this._items[1].setEnabled(true);
                _this._items[2].setEnabled(true);
            })
        ));
    },

    /**
     * 設定站起觀戰按鈕的enabled
     * @param value
     */
    setStandUpButtonEnabled: function (value) {
        this._items[1].setEnabled(value);
    },

    /**
     * @private
     */
    _menuOpen: function (sender) {
        this._open();
    },

    /**
     * 按到每日任務
     */
    _missionClicked: function () {
        DialogManager.addDialog(new ActionListDialog(0, DailyMissionEnum.whereType.Game, GSEnum.Game.Domino), true, true);

        // 撥放音效
        MusicUtility.playEffect("Music/Effect/button_click.mp3");

        // 關掉泡泡框
        if (this._msgNode) {
            this._msgNode.close();
            this._msgNode = undefined;
        }

        // 埋點
        DataProcess.sendString("track_daily_mission 7");
    },

    /**
     * 按下按鈕們
     * @private
     */
    _menuClicked: function (sender) {
        // 如果有Loading就不給點擊
        if (GSLoading.isLoading())
            return;

        switch (sender) {
            case this._items[1]:
                // 站起觀戰
                this._isClickStandUpButton = true;
                if (DataModal.gameData.checkLeaveGameNeedBlock()) {
                    // 需要加Dialog
                    var dialog = new AvatarDialog(DialogHelper("StandUpButBet"));
                    DialogManager.addDialog(dialog);
                } else {
                    //send "stand"
                    this.notifyGameUIStandUpClicked();
                }
                break;
            case this._items[2]:
                // 更換牌桌
                if (DataModal.gameData.checkLeaveGameNeedBlock()) {
                    // 需要加Dialog
                    var dialog = new AvatarDialog(DialogHelper("ChangeRoomButBet"));
                    DialogManager.addDialog(dialog);
                } else {
                    GS.dispatchCustomEvent("NotifyGameUIChangePlaceClicked", {isReplaceRoomByClickedUIButton: true});
                }
                break;
            case this._items[3]:
                // 牌型提醒
                GS.dispatchCustomEvent("NotifyGameUIShowCardRankLayer");
                break;
            case this._items[4]:
                // 比牌說明
                var webDialog = new WebViewDialog(GS.domain + "/domino/web/patternsDescription.html", LocalizedString.Game("同分比牌規則"));
                webDialog.key = "GameCardInfoDialog";
                DialogManager.addDialog(webDialog, true, true);

                // 檢查有沒有紅點 有的話要拿掉
                var badge = sender.getChildByName("badge");
                badge && badge.removeFromParent();

                // 記下來有看過
                GS.localStorage.setItem("HaveSeeCardInfo", "1");

                break;
            case this._items[5]:
                // 返回大廳
                if (DataModal.gameData.checkLeaveGameNeedBlock()) {
                    // 需要加Dialog
                    var dialog = new AvatarDialog(DialogHelper("LeaveGameButBet"));
                    DialogManager.addDialog(dialog, true, true);
                } else {
                    GS.dispatchCustomEvent("NotifyGameUIBackToLobbyClicked");
                }
                break;
        }

        // 關閉選單
        this._close();
    },

    /**
     * 打開選單
     * @private
     */
    _open: function () {
        if (this._isOpen) {
            return;
        }
        this._isOpen = true;

        this.openItem.setEnabled(false);
        this.openItem.stopAllActions();
        this.openItem.runAction(cc.sequence(cc.scaleTo(0.15, 0).easing(cc.easeBackIn()), cc.hide()));
        this._container.stopAllActions();
        this._container.runAction(cc.sequence(cc.delayTime(0.15), cc.show(), cc.scaleTo(0.25, 1).easing(cc.easeBackOut())));
    },

    /**
     * 關開選單
     * @private
     */
    _close: function () {
        if (!this._isOpen) {
            return;
        }
        this._isOpen = false;

        this._container.stopAllActions();
        this._container.runAction(cc.sequence(cc.scaleTo(0.25, 0).easing(cc.easeBackIn()), cc.hide()));
        this.openItem.setEnabled(true);
        this.openItem.stopAllActions();
        this.openItem.runAction(cc.sequence(cc.delayTime(0.25), cc.show(), cc.scaleTo(0.15, 1).easing(cc.easeBackOut())));
    },

    /**
     * Touch相關
     * @private
     */
    _onTouchBegan: function (touch, event) {
        var boundBox = cc.rect(0, DOMINO_UILAYER_BUTTON_HEIGHT, 150, JSVisibleSize.height - DOMINO_UILAYER_BUTTON_HEIGHT);
        var touchPos = this.convertToNodeSpace(touch.getLocation());
        if (!cc.rectContainsPoint(boundBox, touchPos)) {
            this._close();
            return false;
        }

        return this._isOpen;
    },

    /**
     * 按"站起觀戰"按鈕
     * @private
     */
    notifyGameUIStandUpClicked: function () {
        DataProcess.sendString("stand");
    },

    /**
     * 取消換房 / 站起
     */
    notifyGameUICancelReplaceRoom: function () {
        this.stopAllActions();
        this._items[2].setEnabled(true);
    },

    notifyGameUICancelStandUp: function () {
        this.stopAllActions();
        this._items[1].setEnabled(true);
    },
});