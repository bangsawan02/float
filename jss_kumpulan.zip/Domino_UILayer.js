/**
 * UI的畫面 設定在UILayerSetting裡面
 */

var Domino_UILayer = cc.Layer.extend({
    GAP_WIDTH: 4,                           // 按鈕間隔多寬

    ctor: function () {
        this._super();

        this._nowStatus = -1;               // 現在的狀態
        this._menuItems = [];               // 記下下方 7狀態的五按鈕
        this._callMoney = 0;                // 別人加注的金額
        this._myBringMoney = 0;             // 玩家攜入到牌桌上的金額
        this._minRaiseMoney = 0;            // 最小加注金額（大盲)
        this._tableMoney = 0;               // 先前已經下注到桌上的金額
        this._latestSelectItem = null;      // 最後點選到的Toggle物件


        // 先算出右下方五個按鈕的大小
        var faceButtonWidth = 68;           // 左邊擺放表情的按鈕寬
        // var totalWidth = JSVisibleSize.width - JSScreenSafeWidth * 2 - faceButtonWidth;
        var buttonSize = this._buttonSize = cc.size(145, DOMINO_UILAYER_BUTTON_HEIGHT);
        var menuBasePosX = faceButtonWidth + JSScreenBonusHalfWidth;

        // 創按鈕
        this._menuArray = [];
        for (var i = 0; i < 7; i++) {
            var menu = this._menuArray[i] = this._createUIMenu(i, buttonSize);
            menu.setPosition(menuBasePosX, DOMINO_UILAYER_BUTTON_Y);
            // menu.setVisible(false);
            this.addChild(menu);
        }

        // 表情 & 對話 按鈕
        var emoticonMenu = this._emoticonMenu = new cc.Menu();
        emoticonMenu.setPosition(0, 0);
        // emoticonMenu.setVisible(false);         // 預設先不出現表情與對話 會在updateSeat裡面更新
        this.addChild(emoticonMenu);

        // 表情
        var emoticonMenuWidth = 28;
        this._emoticonPos = cc.p(17 + JSScreenSafeWidth, 14);
        var itemNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_07.png", cc.size(emoticonMenuWidth, 28), "#game_pic_emoticons.png");
        var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._emoticonMenuClicked, this);
        menuItem.setPosition(this._emoticonPos);
        emoticonMenu.addChild(menuItem);

        // 聊天按鈕
        var itemNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_07.png", cc.size(28, 28), "#game_btn_chat.png");
        var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._chatMenuClicked, this);
        menuItem.setPosition(17 + emoticonMenuWidth + 3 + JSScreenSafeWidth, 14);
        emoticonMenu.addChild(menuItem);

        // 加注遊戲介面
        var raiseNode = this._uiRaiseNode = new Domino_UIRaiseNode(buttonSize);
        raiseNode.setVisible(false);
        this.addChild(raiseNode, 1);

        // 桌內koinLuxy (黑帳號 不顯示)
        if (!DataModal.profileData.isBlackAccount) {
            var koinLuxyNode = this._koinLuxyNode = new KoinLuxyGameNode();
            koinLuxyNode.setPosition(2 + JSScreenSafeWidth, 214 + JSScreenBonusHeight);
            this.addChild(koinLuxyNode);
        }

        // 桌內好友提示(加好友/好友上線)
        var friendGameHintLayer = new FriendGameHintLayer();
        this.addChild(friendGameHintLayer);

        //加入事件
        GS.addListener("NotifyGameUISetMenuStatus", this.notifyGameUISetMenuStatus.bind(this), this);
        GS.addListener("NotifyGameUIRaiseMenuClicked", this.notifyGameUIRaiseMenuClicked.bind(this), this);
        GS.addListener("NotifyGamePlayerCountDownFinish", this.notifyGamePlayerCountDownFinish.bind(this), this);
        GS.addListener("NotifyGameUIRaiseOKClicked", this.notifyGameUIRaiseOKClicked.bind(this), this);
        GS.addListener("NotifyGameTableFunctionHint", this.notifyGameTableFunctionHint.bind(this), this);
    },

    cleanData: function () {
        this._nowStatus = -1;
        this._callMoney = 0;                // 別人加注的金額
        this._myBringMoney = 0;             // 玩家攜入到牌桌上的金額
        this._minRaiseMoney = 0;            // 最小加注金額（大盲)
        this._tableMoney = 0;               // 先前已經下注到桌上的金額

        // 清掉最後選擇
        this._latestSelectItem = null;

        // 把下方5按鈕狀態全部清掉
        this._menuItems.forEach(function (curArray) {
            curArray.forEach(function (cur) {
                if (cur.isToggle) {
                    // Toggle才需要把狀態清掉
                    cur.setSelectedIndex(0);
                }
            });
        });

        // 設定現在狀態
        this.setMenuStatus(-1, 0);
    },

    /**
     * 切換狀態
     * @param status 現在的狀態
     * @param callMoney 需要跟注的錢
     */
    setMenuStatus: function (status, callMoney) {
        callMoney = callMoney || 0;

        // 設定按鈕目前的狀態
        if (status != this._nowStatus) {
            // 先把其他所有按鈕關掉
            this._menuArray.forEach(function (cur) {
                cur.setVisible(false);
            });

            // 把這狀態的按鈕打開
            if (status >= 0 && status < 7) {
                this._menuArray[status].setVisible(true);

                // 要顯示跟多少錢在"跟 xxx"的按鈕上面
                if (callMoney > 0) {
                    // 先判斷身上的錢是否能跟注
                    var myData = DataModal.gameData.getMyPlayerData();
                    if (myData && callMoney > myData.tableChips) {
                        callMoney = myData.tableChips;
                    }

                    var callMoneyString = LocalizedString.Game("跟注") + " " + TexasUtility.getSimpleMoneyString(callMoney);
                    if (status === DOMINO_UILAYER_STATUS.HAS_RAISE) {
                        this._updateMenuItemLabel(this._menuItems[status][1], callMoneyString);
                    } else if (status === DOMINO_UILAYER_STATUS.MY_RAISE) {
                        this._updateMenuItemLabel(this._menuItems[status][1], callMoneyString);
                    } else if (status === DOMINO_UILAYER_STATUS.ALL_IN_RAISE) {
                        this._updateMenuItemLabel(this._menuItems[status][1], callMoneyString);
                    }
                }
            }

            // 記下現在的狀態
            this._nowStatus = status;
        }

        // 特殊判斷
        if (status == DOMINO_UILAYER_STATUS.HAS_RAISE) {
            // 若玩家預設選「棄牌/過牌」，有人加注 幫玩家勾「棄牌」
            var needChange = this._menuItems[DOMINO_UILAYER_STATUS.NO_RAISE][0].getSelectedIndex() === 1;
            if (needChange) {
                // 要手動把他打勾
                this._menuItems[DOMINO_UILAYER_STATUS.HAS_RAISE][0].setSelectedIndex(1);

                this._latestSelectItem = {
                    status: DOMINO_UILAYER_STATUS.HAS_RAISE,
                    index: DOMINO_UILAYER_BUTTON_TYPE.FOLD
                };
            }
        }
    },

    /**
     * 更新按鈕上的文字
     */
    _updateMenuItemLabel: function (menuItem, text) {
        var self = this;
        var updateMenuLabel = function (item) {
            var allImages = [item.getNormalImage(), item.getSelectedImage(), item.getDisabledImage()];
            allImages.forEach(function (cur) {
                if (!cur)
                    return;

                var itemLabel = cur.label;
                itemLabel.setString(text);
                if (cur.checkBox) {
                    // 是checkBox的話 要位移
                    cur.checkBox.setPosition(10, itemLabel.getPositionY());
                } else {
                    // 不是的話 不用動
                }
            });
        };

        // 分兩種 一種Toggle的按鈕 一種Normal的按鈕
        if (menuItem.isToggle) {
            var subItems = menuItem.subItems;
            subItems.forEach(function (cur) {
                updateMenuLabel(cur);
            });
        } else {
            updateMenuLabel(menuItem);
        }
    },

    /**
     * 會依checkBoxTitles與normalBoxTitles的長度來製作MenuItemSprite
     * checkBoxTitles主要是產生CheckBox、normalBoxTitles則產生一般按鈕
     */
    _createUIMenu: function (status, buttonSize) {
        var retMenu = new cc.Menu();

        var gameString = LocalizedString.Game;

        // 把按鈕Array設定好
        this._menuItems[status] = [];

        // 抓出這個狀態的設定
        var params = DOMINO_UILAYER_BUTTON_SETTING[status];

        // 3個按鈕的顏色 對應到檔案的號碼
        var colors = [2, 1, 1];
        var fontSize = 16;
        for (var i = 0; i < 3; i++) {
            // 抓出現在的對應Param
            var thisParam = params[i];
            var imgColor = JSStringUtility.format("lobby_btn_0%d.png", colors[i]);
            var imageStrings = [imgColor, imgColor, imgColor];
            var fontColors = [(colors[i] === 1 ? JSColor.BLACK : JSColor.WHITE), JSColor.GRAY, JSColor.GRAY];
            var items = [];
            var runTimes = (thisParam.checkBox ? 2 : 1);
            for (var x = 0; x < runTimes; x++) {
                var itemNodes = ButtonUtility.createArrayScale9Nodes(imageStrings, buttonSize, gameString(thisParam.name), fontSize, fontColors);

                //add checkBox image to itemNode & reset position
                if (thisParam.checkBox) {
                    itemNodes.forEach(function (cur) {
                        var image = (x === 0 ? "#game_pic_check_0.png" : "#game_pic_check_1.png");
                        var checkSprite = new cc.Sprite(image);
                        var itemLabel = cur.label;
                        cur.checkBox = checkSprite;
                        checkSprite.setPosition(10, itemLabel.getPositionY());
                        cur.addChild(checkSprite);
                    });
                }
                itemNodes[2].setColor(JSColor.GRAY);
                itemNodes[2].setOpacity(255);

                //create MenuItemSprite
                var itemMenu = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2]);
                itemMenu.isCheckBox = true;
                itemMenu.isChoice = (x === 1);
                items.push(itemMenu);
            }

            var menuItem;
            if (thisParam.checkBox) {
                // 是屬於Toggle的
                menuItem = new cc.MenuItemToggle(items[0], items[1], this._decisionMenuClicked, this);

                // 把他的MenuItems記下來 因為getSubItems在Native沒有JSB
                menuItem.subItems = items;
            } else {
                // 是屬於一般按鈕
                menuItem = items[0];
                menuItem.setCallback(this._decisionMenuClicked, this);
            }
            menuItem.setAnchorPoint(0, 0.5);
            menuItem.setPosition((buttonSize.width + this.GAP_WIDTH) * i, 0);
            // menuItem.setEnabled(thisParam.enabled);
            retMenu.addChild(menuItem);

            // 其他按鈕的設定
            menuItem.isToggle = thisParam.checkBox;     // 用來判斷按鈕是否可以更換selectedIndex
            menuItem.index = thisParam.type;            // 用來判斷按下哪一個
            menuItem.status = status;                   // 用來之後按下知道哪一個status用
            menuItem.setEnabled(thisParam.type !== DOMINO_UILAYER_BUTTON_TYPE.ENABLED);

            // 把按鈕記下來
            this._menuItems[status].push(menuItem);
        }

        return retMenu;
    },

    /**
     * 設定現在加注的資訊
     * @param param
     */
    _setRaiseInfo: function (param) {

        if (DataModal.gameData.myPos == -1) {
            return;
        } else {
            var myData = DataModal.gameData.getMyPlayerData();
            if (myData != null && myData.tableChips == 0) {
                this.setMenuStatus(DOMINO_UILAYER_STATUS.EMPTY);
                return;
            }
            if (myData.status == GAME_PLAYER_STATUS.FOLD || myData.status == GAME_PLAYER_STATUS.ALL_IN) {
                return;
            }
        }

        this._myBringMoney = param.myBringMoney;
        this._minRaiseMoney = param.minRaiseMoney;
        this._callMoney = param.callMoney;
        this._tableMoney = param.tableMoney;                     //tableMoney 沒用到，先寫著

        if (!param.isPlayerCheck && param.isMeFlag) {
            //輪到玩家自己,玩家沒有預選任何checkBox
            if (param.callMoney > 0) {
                //all in
                if (param.myBringMoney <= param.minRaiseMoney && param.myBringMoney <= param.callMoney) {
                    this._callMoney = param.myBringMoney;
                    this.setMenuStatus(DOMINO_UILAYER_STATUS.ALL_IN_RAISE2, param.callMoney);
                } else if (param.myBringMoney <= param.callMoney) {
                    this._callMoney = param.myBringMoney;
                    this.setMenuStatus(DOMINO_UILAYER_STATUS.ALL_IN_RAISE, this._callMoney);
                } else {
                    this._callMoney = param.callMoney;
                    this.setMenuStatus(DOMINO_UILAYER_STATUS.MY_RAISE, this._callMoney);
                }
            } else {
                //all in
                if (param.myBringMoney <= param.minRaiseMoney) {
                    this._callMoney = param.myBringMoney;
                    this.setMenuStatus(DOMINO_UILAYER_STATUS.ALL_IN_NO_RAISE, this._callMoney);
                } else {
                    this._callMoney = param.minRaiseMoney;
                    this.setMenuStatus(DOMINO_UILAYER_STATUS.MY_NO_RAISE, this._callMoney);
                }
            }
        } else {
            //如果有人加注
            if (param.callMoney > 0) {
                this.setMenuStatus(DOMINO_UILAYER_STATUS.HAS_RAISE, this._callMoney);
            } else {
                this.setMenuStatus(DOMINO_UILAYER_STATUS.NO_RAISE, this._callMoney);
            }
        }
    },

    /**
     * 按到下方5個按鈕
     */
    _decisionMenuClicked: function (sender) {
        var status = sender.status;
        // 判斷現在的status是不是現在的status 不是的話不要理會
        if (this._nowStatus != status) {
            // 把toggle設回來
            if (sender.isToggle) {
                sender.setSelectedIndex((sender.getSelectedIndex() + 1) % 2);
            }
            return;
        }

        // 把最後點選到的清掉
        this._latestSelectItem = null;

        // 判斷是否點到Toggle
        if (sender.isToggle) {
            // 按到Toggle切換 要把當下那一列的Toggle取消掉
            if (sender.getSelectedIndex() === 1) {
                // 要取消
                this._menuItems[status].forEach(function (cur) {
                    if (cur.isToggle && cur !== sender) {
                        cur.setSelectedIndex(0);
                    }
                });

                // 記下現在Toggle選到的東西
                this._latestSelectItem = {
                    status: status,
                    index: sender.index
                };

                // 假如是跟任何注 兩邊都要設定 status是0 & 1 都會有跟任何注
                if (sender.index === DOMINO_UILAYER_BUTTON_TYPE.CALL && (status === DOMINO_UILAYER_STATUS.HAS_RAISE || status === DOMINO_UILAYER_STATUS.NO_RAISE)) {
                    // 把另一個也設一下
                    var nextStatus = (status + 1) % 2;
                    this._menuItems[nextStatus].forEach(function (cur) {
                        if (cur.isToggle && cur !== sender) {
                            cur.setSelectedIndex(0);
                        }
                    });

                    this._menuItems[nextStatus][2].setSelectedIndex(1);
                }
            }

            // 是Toggle的話 下面就不做事了
            return;
        }

        switch (sender.index) {
            case DOMINO_UILAYER_BUTTON_TYPE.FOLD:
                // 都是棄牌
                DataProcess.sendString("fold");
                GameAppsFlyerTracker.trackFirstClickType(GameAppsFlyerTrackerEnum.FOLD);

                // Firebase 埋點
                var eventName = GSAnalyticsAdapter.record.game + "遊戲行為";
                GSAnalyticsAdapter.logEventByFirebaseAll(eventName, ["牌桌"], ["QiuQiu桌點擊棄牌按鈕"]);
                break;
            case DOMINO_UILAYER_BUTTON_TYPE.FOLD_PASS:
                // 棄牌過牌 只有Toggle有
                break;
            case DOMINO_UILAYER_BUTTON_TYPE.PASS:
                // 過牌
                DataProcess.sendString("check");
                GameAppsFlyerTracker.trackFirstClickType(GameAppsFlyerTrackerEnum.CHECK);
                break;
            case DOMINO_UILAYER_BUTTON_TYPE.CALL:
                // 跟注
                DataProcess.sendString("call");
                GameAppsFlyerTracker.trackFirstClickType(GameAppsFlyerTrackerEnum.CALL_ALLIN);

                // Firebase 埋點
                var eventName = GSAnalyticsAdapter.record.game + "遊戲行為";
                GSAnalyticsAdapter.logEventByFirebaseAll(eventName, ["牌桌"], ["QiuQiu桌點擊跟注按鈕"]);
                break;
            case DOMINO_UILAYER_BUTTON_TYPE.RAISE:
                // 加注 or Allin
                if (status < 4) {
                    // 要開啟加注選單
                    GS.dispatchCustomEvent("NotifyGameUIRaiseMenuClicked");
                } else {
                    // 要Allin
                    DataProcess.sendString("allin");
                    GameAppsFlyerTracker.trackFirstClickType(GameAppsFlyerTrackerEnum.CALL_ALLIN);
                }
                break;
            default:
                break;
        }
    },

    /**
     * 按到表情
     */
    _emoticonMenuClicked: function () {
        // 因為遊戲內可能會關掉Dialog 透過代參數讓Manager管理
        DialogManager.addDialog(new EmoticonsDialog(this._emoticonPos), true, true);

        // 撥放音效
        MusicUtility.playEffect("Music/Effect/button_click.mp3");

        // 拿掉泡泡框
        if (this._msgNode) {
            this._msgNode.close();
            this._msgNode = undefined;
        }
    },

    /**
     * 按到聊天對話
     */
    _chatMenuClicked: function () {
        GS.dispatchCustomEvent("NotifyShowGameChat");

        // 撥放音效
        MusicUtility.playEffect("Music/Effect/button_click.mp3");

        // 拿掉泡泡框
        if (this._msgNode) {
            this._msgNode.close();
            this._msgNode = undefined;
        }
    },

    /**
     * 表情按鈕跳提示泡泡框
     */
    _showEmoticonHintMsg: function (msg, time = 2) {
        if (msg && msg.length) {
            if (this._msgNode) {
                this._msgNode = undefined;
            }

            // 泡泡框
            var msgLabel = new GSRichTextNode("#!000000!#" + msg, JSFontName, 12);
            var msgLabelHalfWidth = msgLabel.getContentSize().width / 2;
            var param = {
                mainNode: msgLabel,
                style: BaseMessageNode.Style.WHITE,
                direct: BaseMessageNode.Direct.DOWN,
                arrowType: BaseMessageNode.ArrowType.STRAIGHT,
                arrowPadding: (msgLabelHalfWidth < 15) ? 0 : msgLabelHalfWidth - 15,
                closeCallback: () => {
                    // 拿掉泡泡框
                    if (this._msgNode) {
                        this._msgNode = undefined;
                    }
                }
            };
            var targetPos = this._emoticonPos;
            var msgNode = this._msgNode = new BaseMessageNode(param);
            msgNode.setPosition(targetPos.x, targetPos.y + 16);
            msgNode.show(time);
            this.addChild(msgNode, 2);
        }
    },

    /**
     * 下一局時，重設外觀
     */
    cmd_OLEH: function () {
        // 把上一局資訊清掉
        this.cleanData();

        if (DataModal.gameData.myPos == -1) {
            this.setMenuStatus(DOMINO_UILAYER_STATUS.PLEASE_SIT);
        } else {
            this.setMenuStatus(DOMINO_UILAYER_STATUS.WAIT_NEXT_GAME);
        }

    },

    /**
     * 修改下面的介面、設定Raise
     */
    cmd_play: function (param) {
        //輪到別人
        //狀況一 自己不再桌內（站起or未入局）＞保持原樣直到玩家其他動作
        //狀況二 自己在桌內輪別人

        param.isPlayerCheck = true;
        if (param.isMeFlag == 0) {
            //狀況二 輪到別人，顯示預選Menu
            var status = this._nowStatus;

            if (status != DOMINO_UILAYER_STATUS.EMPTY && status != DOMINO_UILAYER_STATUS.WAIT_NEXT_GAME &&
                status != DOMINO_UILAYER_STATUS.WAIT_NEXT_GAME2 && status != DOMINO_UILAYER_STATUS.PLEASE_SIT) {
                this._setRaiseInfo(param);
            }
        } else if (param.isMeFlag == 1) {
            // 輪到自己，看有沒有之前勾選的checkbox
            var info = this._latestSelectItem;
            var index = (info ? info.index : -1);
            var status = (info ? info.status : -1);
            var isCallAny = false;
            switch (index) {
                case -1:
                    // 沒有勾選任何checkbox,開啟選單給玩家選擇
                    param.isPlayerCheck = false;
                    break;
                case DOMINO_UILAYER_BUTTON_TYPE.FOLD:
                    // (棄牌)CheckBox
                    DataProcess.sendString("fold");
                    GameAppsFlyerTracker.trackFirstClickType(GameAppsFlyerTrackerEnum.FOLD);

                    // 把勾勾取消掉
                    this._menuItems[status][0].setSelectedIndex(0);
                    break;
                case DOMINO_UILAYER_BUTTON_TYPE.FOLD_PASS:
                    // (棄牌過牌)CheckBox
                    if (param.callMoney > 0) {
                        DataProcess.sendString("fold");
                        GameAppsFlyerTracker.trackFirstClickType(GameAppsFlyerTrackerEnum.FOLD);
                    } else {
                        DataProcess.sendString("check");
                        GameAppsFlyerTracker.trackFirstClickType(GameAppsFlyerTrackerEnum.CHECK);
                    }
                    // 把勾勾取消掉
                    this._menuItems[status][0].setSelectedIndex(0);
                    break;
                case DOMINO_UILAYER_BUTTON_TYPE.PASS:
                    if (status == DOMINO_UILAYER_STATUS.NO_RAISE) {
                        // (過牌)CheckBox
                        DataProcess.sendString("check");
                        GameAppsFlyerTracker.trackFirstClickType(GameAppsFlyerTrackerEnum.CHECK);
                    } else if (status == DOMINO_UILAYER_STATUS.HAS_RAISE) {
                        //(跟$)CheckBox
                        isCallAny = true;
                    }

                    // 把勾勾取消掉
                    this._menuItems[status][1].setSelectedIndex(0);
                    break;
                case DOMINO_UILAYER_BUTTON_TYPE.CALL:
                    // (跟任何注)CheckBox
                    isCallAny = true;

                    // 把勾勾取消掉 這邊有分兩種call any 所以都要取消
                    this._menuItems[status][2].setSelectedIndex(0);
                    this._menuItems[(status + 1) % 2][2].setSelectedIndex(0);
                    break;
            }

            if (isCallAny) {
                if (param.callMoney == 0) {
                    //要自動all iin
                    if (param.myBringMoney + param.tableMoney <= param.minRaiseMoney)
                        DataProcess.sendString("allin");
                    else
                        DataProcess.sendString("call");
                } else {
                    //要自動all iin
                    if (param.myBringMoney + param.tableMoney <= param.callMoney)
                        DataProcess.sendString("allin");
                    else
                        DataProcess.sendString("call");
                }

                GameAppsFlyerTracker.trackFirstClickType(GameAppsFlyerTrackerEnum.CALL_ALLIN);
            }

            this._setRaiseInfo(param);

            // 清掉最後選擇
            this._latestSelectItem = null;
        }
    },

    /**
     * 加注設定
     */
    cmd_raiseList: function (value) {
        var tableChips = 0;
        if (DataModal.gameData.getMyPlayerData()) {
            tableChips = DataModal.gameData.getMyPlayerData().tableChips;
        }
        var param = {
            max: tableChips,
            min: this._minRaiseMoney,
            bet: JSON.parse(value),
            callMoney: this._callMoney,
            bringMoney: this.bringMoney,
            minRaiseMoney: this._minRaiseMoney
        };
        this._uiRaiseNode.refresh(param);
    },

    /**
     * 更新座位
     */
    cmd_updateSeat: function () {
        // 這邊要判斷表情與對話按鈕要不要出現
        var haveMe = DataModal.gameData.haveMe;
        this._emoticonMenu.setVisible(haveMe);
    },

    /**
     * 自己跟注
     */
    cmd_call: function (value) {
        var numberValue = JSCodeUtility.getIntValue(value);
        //玩家本人跟牌
        if (numberValue === 0 && this._nowStatus != DOMINO_UILAYER_STATUS.EMPTY) {
            DataModal.gameData.isMeBet = true;

            this.setMenuStatus(DOMINO_UILAYER_STATUS.NO_RAISE);
        }
    },

    /**
     * 自己棄牌 外部已經判斷好是否為0了
     */
    cmd_fold: function () {
        DataModal.gameData.isMeFold = true;

        if (this._nowStatus != DOMINO_UILAYER_STATUS.PLEASE_SIT) {
            this.setMenuStatus(DOMINO_UILAYER_STATUS.EMPTY);
        }
    },

    /**
     * 自己過牌
     */
    cmd_check: function (value) {
        var numberValue = JSCodeUtility.getIntValue(value);
        //玩家本人過牌
        if (numberValue === 0 && this._nowStatus != DOMINO_UILAYER_STATUS.EMPTY) {
            this.setMenuStatus(DOMINO_UILAYER_STATUS.NO_RAISE);
        }
    },

    /**
     * 自己加注
     */
    cmd_raise: function (value) {
        var numberValue = JSCodeUtility.getIntValue(value);
        if (numberValue === 0 && this._nowStatus != DOMINO_UILAYER_STATUS.EMPTY) {
            DataModal.gameData.isMeBet = true;

            this.setMenuStatus(DOMINO_UILAYER_STATUS.NO_RAISE);
        }
    },

    /**
     * 有玩家加注
     */
    cmd_plraise: function () {
        // 有人加注時,把checkbox 過牌跟牌的狀態清除
        if (this._latestSelectItem && this._latestSelectItem.index === 1) {
            // 有兩個狀態 全部設掉
            this._menuItems[0][1].setSelectedIndex(0);
            this._menuItems[1][1].setSelectedIndex(0);
            this._latestSelectItem = null;
        }
    },

    /**
     * 更新koinLuxy
     * @param {String} value socke傳回來的值
     */
    cmd_koin_luxy_room_status: function (value) {
        var jsonValue = JSON.parse(value);
        this._koinLuxyNode && this._koinLuxyNode.refreshKoinStatus(jsonValue);
    },

    /**
     * 通知
     */

    /**
     * 事件通知:更改按鈕狀態
     * @param {event.getUserData} 按鈕狀態
     * @private
     */
    notifyGameUISetMenuStatus: function (event) {
        if (event) {
            var status = event.getUserData();
            this.setMenuStatus(status);
        }
    },

    /**
     * 事件通知:按到加注按鈕
     * @private
     */
    notifyGameUIRaiseMenuClicked: function (event) {
        this._uiRaiseNode.setVisible(true);

        // Firebase 埋點
        var eventName = GSAnalyticsAdapter.record.game + "遊戲行為";
        GSAnalyticsAdapter.logEventByFirebaseAll(eventName, ["牌桌"], ["QiuQiu桌點擊加注按鈕"]);
    },

    /**
     * 遊戲倒數計時結束
     * @private
     */
    notifyGamePlayerCountDownFinish: function (event) {
        this._uiRaiseNode.setVisible(false);
    },

    /**
     * 按下Raise ok
     * @param {event.getUserData} 加注多少錢
     * @private
     */
    notifyGameUIRaiseOKClicked: function (event) {
        if (event) {
            var money = JSCodeUtility.getIntValue(event.getUserData());
            if (money >= this._myBringMoney) {
                if (this._nowStatus !== DOMINO_UILAYER_STATUS.PLEASE_SIT) {
                    DataProcess.sendString("allin");
                    GameAppsFlyerTracker.trackFirstClickType(GameAppsFlyerTrackerEnum.CALL_ALLIN);
                }
            } else {
                DataProcess.sendString(JSStringUtility.format("raise %d", money));
            }
        }
        this._uiRaiseNode.setVisible(false);
    },

    // 牌桌內功能提示
    notifyGameTableFunctionHint: function (event) {
        var hintType = event.getUserData();
        if (hintType === NewbieData.GameTableFunctionHintType.EMOTICON && this._emoticonMenu.isVisible()) {
            // 泡泡框
            this._showEmoticonHintMsg(LocalizedString.Game("與牌友互動一下吧!"), 3);

            // 紀錄已經跳過
            DataModal.newbieData.saveGameTableFunctionShowed(hintType);
        }
    }
});