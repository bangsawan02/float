/**
 *  百家樂點主畫面
 */

var BaccaratWashCardLayer = cc.Layer.extend({
    MAX_CARD_COUNT: 156,

    ctor: function () {
        this._super();
    },

    /**
     * 開始洗牌
     */
    startWashCardAsync: function () {
        return new Promise(resolve => {
            this.removeAllChildren();
            this.unscheduleAllCallbacks();

            this._nowCardCount = 0;
            this._cardArray = [];

            // 加一個檔Touch的
            var dummyTouch = new DummyTouchLayer(JSVisibleSize);
            this.addChild(dummyTouch);

            var fadeNode = new cc.Node();
            fadeNode.setCascadeOpacityEnabled(true);
            fadeNode.setOpacity(0);
            fadeNode.runAction(cc.fadeIn(0.4));
            this.addChild(fadeNode);

            // 背景
            var bgLayer = new cc.LayerColor(cc.color(0, 0, 0, 150), JSVisibleSize.width, JSVisibleSize.height);
            bgLayer.runAction(cc.fadeTo(0.4, 150));
            fadeNode.addChild(bgLayer);

            var moveTime = 0.15;
            this.schedule(function () {
                if (this._nowCardCount < this.MAX_CARD_COUNT) {
                    // 先疊牌
                    for (var i = 0; i < 2; i++) {
                        var cardSprite = new cc.Sprite(GameTableTheme.getPokerTheme());
                        cardSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + this._nowCardCount * 0.3);
                        cardSprite.setRotation(90);
                        cardSprite.setSkewY(14);
                        cardSprite.setScale(0.6, 0.8);
                        fadeNode.addChild(cardSprite, this._nowCardCount);

                        this._nowCardCount++;
                        this._cardArray.push(cardSprite);
                    }

                    if (this._nowCardCount === 30) {
                        // 撥放音效
                        Vegas_MusicUtility.playEffect("Music/Effect/e_washCard.mp3");
                    }
                } else {
                    // 停掉
                    this.unscheduleAllCallbacks();

                    // 要把牌洗一洗
                    fadeNode.runAction(cc.sequence(
                        cc.sequence(
                            cc.callFunc(function () {
                                // 先把牌排序一次 因為之前可能有洗過
                                this._cardArray.sort(function (a, b) {
                                    return a.getLocalZOrder() - b.getLocalZOrder();
                                });

                                // 把牌抽出來
                                var allLength = this._cardArray.length;
                                var bottomCardNumber = JSCodeUtility.getRandomInt(0, 24);
                                var getCards = JSCodeUtility.getRandomInt(30, 84);
                                var cardLength = bottomCardNumber + getCards;
                                var moveOffsetY = (this.MAX_CARD_COUNT - cardLength) * 0.3;

                                // 這邊跑要把牌抽出來的動畫
                                var runFunc = (index) => {
                                    var cardSprite = this._cardArray[index];
                                    cardSprite.runAction(cc.sequence(
                                        cc.moveBy(moveTime, cc.p(80, 0)),
                                        cc.callFunc(function () {
                                            // reorder Z
                                            cardSprite.setLocalZOrder(allLength - cardLength + index);
                                        }, this),
                                        cc.moveBy(moveTime * 0.1, cc.p(0, moveOffsetY)),
                                        cc.moveBy(moveTime, cc.p(-80, 0))
                                    ));
                                };
                                for (var i = bottomCardNumber; i < cardLength; i++) {
                                    if (i >= allLength)
                                        break;
                                    runFunc(i);
                                }

                                // 這邊跑上面牌要下去的動畫
                                var downOffsetY = -getCards * 0.3;
                                var downFunc = (index) => {
                                    var cardSprite = this._cardArray[index];
                                    cardSprite.runAction(cc.sequence(
                                        cc.delayTime(moveTime * 0.5),
                                        cc.callFunc(function () {
                                            // reorder Z
                                            cardSprite.setLocalZOrder(index - getCards);
                                        }, this),
                                        cc.moveBy(moveTime * 0.5, cc.p(0, downOffsetY))
                                    ));
                                };
                                for (var i = cardLength; i < allLength; i++) {
                                    downFunc(i);
                                }
                            }, this),
                            cc.delayTime(moveTime * 3)
                        ).repeat(3),
                        cc.fadeOut(0.4),
                        cc.callFunc(function () {
                            this.removeAllChildren();

                            // 洗完了
                            resolve();
                        }, this)
                    ))
                }
            }, 0.01);
        });
    },
});