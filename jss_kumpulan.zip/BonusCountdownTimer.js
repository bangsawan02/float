/**
 * 9T 遊戲內玩家倒數計時的ProgressTimer
 */
var BonusCountdownTimer = cc.ProgressTimer.extend({
    COLOR_TAG: 19830618,

    ctor: function (sprite) {
        this._super(sprite);

        this._colors = BonusCountdownTimer.AllColors;

        // 每多少百分比要換色
        this._unit = 100 / (this._colors.length - 1);

        // 前一個顏色
        this._previousColor = cc.color(0, 0, 0);

        // 總長度
        this._len = this._colors.length;

        // tint變色的秒數
        this._tintTime = 0.4;
    },

    /**
     * 設定倒數多久時間, 用來判斷每一次tint的秒數
     */
    setTime: function (time) {
        this._tintTime = time / this._len;
    },

    /**
     * 設定百分比 override
     */
    setPercentage: function (percentage) {
        // 因為一開始初始化的時後他會先跑一次 這時後還沒有Sprite & colors 所以先判斷一次
        if (this._colors) {
            if (percentage === 100) {
                this._previousColor = this._colors[0];
                this.setColor(this._previousColor);

                var nextColor = this._colors[1];
                var tintAction = cc.tintTo(this._tintTime, nextColor.r, nextColor.g, nextColor.b);
                tintAction.setTag(this.COLOR_TAG);
                this.runAction(tintAction);
            } else {
                var index = Math.floor(percentage / this._unit);
                var nowSelectIndex = this._len - index - 2;
                if (nowSelectIndex < 0)
                    nowSelectIndex = 0;
                var nowColor = this._colors[nowSelectIndex];
                if (!cc.colorEqual(this._previousColor, nowColor)) {
                    this.setColor(nowColor);

                    // 先停掉原本的
                    this.stopActionByTag(this.COLOR_TAG);

                    // 在創新的
                    var nextSelectIndex = nowSelectIndex + 1;
                    if (nextSelectIndex >= this._len)
                        nextSelectIndex = this._len - 1;
                    var nextColor = this._colors[nextSelectIndex];
                    var tintAction = cc.tintTo(this._tintTime, nextColor.r, nextColor.g, nextColor.b);
                    tintAction.setTag(this.COLOR_TAG);
                    this.runAction(tintAction);

                    // 設定回去
                    this._previousColor = nowColor;
                }
            }
        }

        // 給ProgressTimer設定現在百分比
        cc.ProgressTimer.prototype.setPercentage.call(this, percentage);
    }
});

// 變色的顏色
BonusCountdownTimer.AllColors = [
    cc.color(0, 255, 0),
    cc.color(0, 246, 81),
    cc.color(0, 255, 0),
    cc.color(194, 223, 43),
    cc.color(223, 213, 20),
    cc.color(255, 203, 1),
    cc.color(246, 171, 0),
    cc.color(239, 137, 1),
    cc.color(231, 103, 3),
    cc.color(222, 67, 1),
    cc.color(212, 35, 1),
    cc.color(203, 0, 0)
];