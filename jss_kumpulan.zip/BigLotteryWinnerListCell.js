/**
 * 9T 幸運彩票 - 中獎名單 Cell
 */

var BigLotteryWinnerListCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        var cellWidth = BigLotteryWinnerListCell.WIDTH;
        var cellHeight = BigLotteryWinnerListCell.HEIGHT;
        var midPosX = cellWidth / 2;
        var midPosY = cellHeight / 2;

        // 標題
        {
            // 裝標題的node
            var titleNode = this._titleNode = new cc.Node();
            titleNode.setPosition(midPosX, BigLotteryWinnerListCell.TITLE_HEIGHT / 2);
            this.addChild(titleNode);

            // 背景
            var bgSprite = new ccui.Scale9Sprite("bigLottery_bg_redLine02.png");
            bgSprite.setPreferredSize(cc.size(340, 20));
            titleNode.addChild(bgSprite);

            // Domino移植設定 調整描邊
            // 標題字
            var titleLabel = this._titleLabel = new cc.LabelTTF("", JSFontName, 14);
            titleLabel.enableStroke(cc.color(190, 30, 0, 255), 2);
            titleNode.addChild(titleLabel);
        }

        // 玩家
        {
            // 裝玩家資料的node
            var playerNode = this._playerNode = new cc.Node();
            playerNode.setCascadeOpacityEnabled(true);
            playerNode.setPosition(midPosX, midPosY);
            this.addChild(playerNode);

            // 大頭照
            {
                // 玩家大頭照
                var stencilSprite = new cc.Sprite("#lobby_photo_clip.png");
                var clipNode = new cc.ClippingNode(stencilSprite);
                clipNode.setCascadeOpacityEnabled(true);
                clipNode.setAlphaThreshold(0.5);
                clipNode.setPositionX(-122);
                playerNode.addChild(clipNode);

                var photoSprite = this._photoSprite = new PhotoSprite("", 56, 56);
                clipNode.addChild(photoSprite);

                // 大頭照縮小
                clipNode.setScale((GameRankRankCell.HEIGHT - 2) / 56);
            }

            // Domino移植設定 調整描邊
            // 玩家暱稱
            var nicknameLabel = this._nicknameLabel = new GSAutoSizeLabel("帳號", JSFontBoldName, 12, cc.size(110, cellHeight), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
            nicknameLabel.enableStroke(cc.color(190, 30, 0, 255), 2);
            playerNode.addChild(nicknameLabel);

            //  獎勵寶箱
            var chestSp = this._chestSprite = new cc.Sprite("#bigLottery_pic_reward01.png");
            var button = this._chestButton = new GSControlButton(chestSp);
            button.setCascadeOpacityEnabled(true);
            button.addTouchUpInsideAction(this._chestClicked, this);
            button.setPositionX(140);
            playerNode.addChild(button);

            // 線條
            var lineSprite = this._lineSprite = new ccui.Scale9Sprite("bigLottery_pic_line.png");
            lineSprite.setPreferredSize(cc.size(cellWidth * 0.8, 4));
            lineSprite.setPositionY(-cellHeight / 2);
            playerNode.addChild(lineSprite);
        }
    },

    /**
     * 刷新cell
     */
    refreshCell: function (param) {
        // 記下param
        this.param = param;

        if (param.isTitle) {
            // 顯示標題的node
            this._titleNode.setVisible(true);
            this._playerNode.setVisible(false);

            // 刷新標題文字
            this._titleLabel.setString(param.title);
        } else {
            // 顯示玩家的node
            this._titleNode.setVisible(false);
            this._playerNode.setVisible(true);

            // 刷新玩家暱稱
            this._nicknameLabel.setString(param.nickName);
            this._nicknameLabel.setFontFillColor(param.fontColor);

            if (param.userID) {
                // 刷新玩家大頭照
                this._photoSprite.setVisible(true);
                this._photoSprite.setPhotoUrlString(param.photoUrl);

                // 更新獎勵寶箱圖
                if (param.rewardType > 0) {
                    // 換寶箱圖 目前只有五種圖 防呆一下
                    var rewardIndex = Math.min(param.rewardType, 5);
                    var image = JSStringUtility.format("bigLottery_pic_reward%02d.png", rewardIndex);
                    this._chestSprite.setSpriteFrame(image);

                    this._chestButton.setVisible(true);
                }
            } else {
                // 我是槓龜，不顯示大頭照和寶箱
                this._photoSprite.setVisible(false);
                this._chestButton.setVisible(false);
            }
        }

        // 刷新線條
        this._lineSprite.setVisible(!param.isLast);
    },

    // 取得寶箱的世界座標
    getChestWorldPosition: function () {
        return this._playerNode.convertToWorldSpace(this._chestButton.getPosition());
    },

    // 點到cell 高亮
    setIsHighlight: function (isSelect) {
        var param = this.param;
        if (param && !param.isTitle && param.userID)
            this._playerNode.setOpacity(isSelect ? 150 : 255);
    },

    /**
     * 按鈕
     */

    /**
     * 點擊寶箱按鈕
     */
    _chestClicked: function (sender, event) {
        GS.dispatchCustomEvent("NotifyBigLotteryHistoryDetailShow", {
            rewardIndex: this.param.rewardType,
            worldPos: this.getChestWorldPosition()
        });
    }
});

// Cell寬
BigLotteryWinnerListCell.WIDTH = 380;

// Cell高
BigLotteryWinnerListCell.HEIGHT = 40;

// 標題Cell高
BigLotteryWinnerListCell.TITLE_HEIGHT = 25;
