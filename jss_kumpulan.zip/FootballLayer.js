/**
 * 足球機台
 */

var FootballLayer = VegasGameBaseLayer.extend({
    ctor: function () {
        this._super();

        cc.spriteFrameCache.addSpriteFrames("vegas/football/football.plist", "vegas/football/football.png");

        var footballString = LocalizedString.Football;

        // 設定檔
        this.MIN_BET = 1000000;         // 最小下注
        this.MAX_BET = 50000000;        // 下注上限

        // 現在下注的金額
        this._nowBet = this.MIN_BET;

        // 設定機台是哪一個 一定要設
        this._vegasType = VegasGameType.FOOTBALL;

        // 新增返回按鈕
        this._backMenuItem = this._addBackButton(this._backBtnClicked, this, 7);

        // 新增下方儲值選單
        this._addPurchaseMenu(this._purchaseClicked, this, 9, "NotifyFootballUpdateMoney");

        // 背景，美術拆成一半，要對稱的拼回去
        for (var i = 0; i < 2; i++) {
            // 觀眾與草地
            var bgSprite = new cc.Sprite("vegas/football/football_bg.jpg");
            bgSprite.setAnchorPoint(i === 0 ? 1 : 0, 0.5);
            bgSprite.setPosition(JSScreenMidPos.x + (i === 0 ? 0.3 : -0.3), JSScreenMidPos.y);
            i === 1 && bgSprite.setFlippedX(true);
            this.addChild(bgSprite);

            // 贊助商布條 luxypoker的模糊LOGO
            for (var x = 0; x < 2; x++) {
                var sponsorSprite = new cc.Sprite("#football_word_sponsor.png");
                sponsorSprite.setAnchorPoint(i === 0 ? 1 : 0, 0.5);
                sponsorSprite.setPosition(JSScreenMidPos.x + 191 * x * (i === 0 ? -1 : 1), JSScreenMidPos.y + 24);
                this.addChild(sponsorSprite);
            }

            // 球門
            var doorSprite = new cc.Sprite("#football_bg_gate.png");
            doorSprite.setAnchorPoint(i === 0 ? 1 : 0, 0.5);
            doorSprite.setPosition(JSScreenMidPos.x + (i === 0 ? 0.3 : -0.3), JSScreenMidPos.y + 44);
            i === 1 && doorSprite.setFlippedX(true);
            this.addChild(doorSprite);
        }

        // Logo
        var logoSprite = new cc.Sprite("#football_word_SuperShotFootball_logo.png");
        logoSprite.setPosition(JSScreenMidPos.x - 10, JSVisibleSize.height - 25);
        this.addChild(logoSprite);

        // 開球後會消失的畫面
        var bgNode = this._bgNode = new cc.Node();
        this.addChild(bgNode);

        // 背景守門員
        var goalKeeperSprite = new cc.Sprite("#football_pic_goalkeeper.png");
        goalKeeperSprite.setScale(1.25);
        goalKeeperSprite.setPosition(JSScreenMidPos.x - 50, JSScreenMidPos.y + 25);
        bgNode.addChild(goalKeeperSprite);

        // 背景足球的影子
        var shadowSprite = new cc.Sprite("#football_pic_shadow.png");
        shadowSprite.setScale(0.7);
        shadowSprite.setPosition(JSScreenMidPos.x, 55);
        bgNode.addChild(shadowSprite);

        // 背景足球
        var ballSprite = new cc.Sprite("#football_pic_football.png");
        ballSprite.setPosition(JSScreenMidPos.x, 76);
        bgNode.addChild(ballSprite);

        // 上方的黑底提示
        var hintPos = cc.p(JSScreenMidPos.x, JSVisibleSize.height - 59);
        var hintBgSprite = new ccui.Scale9Sprite("marquee_bg.png");
        hintBgSprite.setPreferredSize(cc.size(130, 19));
        // hintBgSprite.setOpacity(150);
        hintBgSprite.setPosition(hintPos);
        bgNode.addChild(hintBgSprite);

        // 文字(完成/未完成)
        var hintLabel = new cc.LabelTTF("Prize", JSFontBoldName, 12);
        hintLabel.setPosition(hintPos);
        bgNode.addChild(hintLabel);

        // 記錄的畫面
        this._recordLayer = new FootballRecordLayer();
        this.addChild(this._recordLayer);

        // 下注的畫面 把背景需要藏起來的丟進去給他
        {
            var betLayer = this._betLayer = new cc.Layer();
            this.addChild(betLayer);

            // 五個下注方向按鈕 因為要跟Server的方向一樣 1在上 23在最下面的 45是中間
            var directionNode = this._directionNode = new cc.Node();
            betLayer.addChild(directionNode);

            this._directionBtnArray = [];
            this._nowDirection = 0;
            var directionArray = [FootballLayer.Direction.UP,
                FootballLayer.Direction.DOWN_LEFT, FootballLayer.Direction.DOWN_RIGHT,
                FootballLayer.Direction.UP_LEFT, FootballLayer.Direction.UP_RIGHT
            ];
            var btnPosArray = [
                cc.p(0, 8),
                cc.p(-80, -60), cc.p(80, -60),
                cc.p(-50, -25), cc.p(50, -25)];
            var arrowPosArray = [
                cc.p(0, 28),
                cc.p(-100, -30), cc.p(100, -30),
                cc.p(-70, 15), cc.p(70, 15)];
            var btnMultipleArray = [4, 2, 2, 10, 10];
            for (var i = 0; i < 5; i++) {
                var imageNumber = Math.floor((i + 1) / 2) + 1;
                var imageFlippedX = i % 2;

                // 箭頭
                var arrowSprite = new cc.Sprite(JSStringUtility.format("#football_pic_arrow_0%d.png", imageNumber));
                imageFlippedX && arrowSprite.setFlippedX(true);
                arrowSprite.setPosition(cc.pAdd(arrowPosArray[i], JSScreenMidPos));
                directionNode.addChild(arrowSprite);

                // 按鈕
                var button = this._directionBtnArray[i] = new FootballBetButton(btnMultipleArray[i]);
                button.addTouchUpInsideAction(this._betDirectionClicked, this);
                button.setPosition(cc.pAdd(btnPosArray[i], JSScreenMidPos));
                button.direction = directionArray[i];
                button.setBetMoney(this._nowBet);
                directionNode.addChild(button, 1);
            }

            // 下方的壓注選單
            // 灰底
            var bgSprite = new ccui.Scale9Sprite("football_bg_menu.png");
            bgSprite.setPreferredSize(cc.size(JSVisibleSize.width + 2, 42));
            bgSprite.setOpacity(150);
            bgSprite.setPosition(JSScreenMidPos.x, 46);
            betLayer.addChild(bgSprite);

            // 現在押注的金額LED
            var ledNode = this._betLedNode = new FootballLedNode();
            ledNode.setPosition(93 + JSScreenBonusHalfWidth, 44);
            ledNode.setMoney(this._nowBet, false);
            betLayer.addChild(ledNode);

            // 清除按鈕
            var clearButton = this._clearButton = ButtonUtility.createSimpleButton("football_btn_gray.png");
            var clearWordSprite = new cc.Sprite("#football_word_clear.png");
            clearWordSprite.setPosition(0, 8);
            clearButton.addChildToContentNode(clearWordSprite);
            clearButton.setPosition(204 + JSScreenBonusHalfWidth, 45);
            clearButton.addTouchUpInsideAction(this._clearClicked, this);
            betLayer.addChild(clearButton);

            // 籌碼按鈕 要在上面一點
            var btnColors = ["red", "blue", "green"];
            var btnChips = ["1jt", "10jt", "50jt"];
            var moneys = [1000000, 10000000, 50000000];
            this._betBtnArray = [];
            for (var i = 0; i < 3; i++) {
                var bgImage = JSStringUtility.format("vegas_cycle_chip_%s.png", btnColors[i]);
                var wordImage = JSStringUtility.format("#vegas_chip_word_%s.png", btnChips[i]);
                var button = this._betBtnArray[i] = ButtonUtility.createSimpleImageButton(bgImage, undefined, wordImage);
                button.addTouchUpInsideAction(this._betClicked, this);
                button.setPosition(JSScreenMidPos.x + 12 + 48 * i, 50);
                button.money = moneys[i];
                button.index = i;
                betLayer.addChild(button, 5);
            }

            // 開始的按鈕
            var startButton = this._startButton = ButtonUtility.createSimpleButton("football_btn_red.png");
            var startWordSprite = new cc.Sprite("#football_word_kick.png");
            startWordSprite.setPosition(0, 7);
            startButton.addChildToContentNode(startWordSprite);
            startButton.setPosition(440 + JSScreenBonusHalfWidth, 45);
            startButton.addTouchUpInsideAction(this._startClicked, this);
            betLayer.addChild(startButton);
        }

        // 送出的Loading
        var loading = this._loadingSprite = new GSLoadingSprite();
        loading.setPosition(JSScreenMidPos);
        loading.setVisible(false);
        this.addChild(loading);

        // 踢球動畫的畫面 要在畫面上面
        var animationLayer = this._animationLayer = new FootballAnimationLayer();
        this.addChild(animationLayer, 12);

        var btnSize = cc.size(44, 36);
        // 右上方賠率按鈕
        {
            var btnNode = new cc.Node();
            var bgSprite = new ccui.Scale9Sprite("vegas_bt_record.png");
            bgSprite.setPreferredSize(btnSize);
            btnNode.addChild(bgSprite);

            var wordSprite = new cc.Sprite("#vegas_record_explain.png");
            wordSprite.setPosition(0, 4);
            btnNode.addChild(wordSprite);

            // 文字
            var wordLabel = new cc.LabelTTF(footballString("教學"), JSFontBoldName, 8);
            wordLabel.setPosition(0, -8);
            btnNode.addChild(wordLabel);

            var button = new GSControlButton(btnNode, btnSize);
            button.addTouchUpInsideAction(this._openRateInfoClicked, this);
            button.setPosition(JSVisibleSize.width - 23 - JSScreenSafeWidth, JSVisibleSize.height - 18);
            this.addChild(button, 5);
        }

        // 右上方記錄畫面按鈕
        {
            var btnNode = new cc.Node();

            var bgSprite = new ccui.Scale9Sprite("vegas_bt_record.png");
            bgSprite.setPreferredSize(btnSize);
            btnNode.addChild(bgSprite);

            var wordSprite = new cc.Sprite("#vegas_record_word.png");
            wordSprite.setPosition(0, 4);
            btnNode.addChild(wordSprite);

            // 文字
            var wordLabel = new cc.LabelTTF(footballString("紀錄"), JSFontBoldName, 8);
            wordLabel.setPosition(0, -8);
            btnNode.addChild(wordLabel);
            var button = new GSControlButton(btnNode, btnSize);
            button.addTouchUpInsideAction(this._recordListClicked, this);
            button.setPosition(JSVisibleSize.width - 70 - JSScreenSafeWidth, JSVisibleSize.height - 18);
            this.addChild(button, 5);
        }

        // 註冊
        GS.addListener("NotifySlot22Begin", this.notifySlot22Begin.bind(this), this);
    },

    onEnter: function () {
        this._super();

        // 加Android BackKey
        PushScene.addBackKeyEnableLayer(this);
    },

    onExit: function () {
        cc.spriteFrameCache.removeSpriteFramesFromFile("vegas/football/football.plist");

        PushScene.removeBackKeyEnableLayer(this);

        this._super();
    },

    /**
     * 進遊戲
     * @override
     */
    _enterVegasGame: function () {
        // 加UI(確認近GameServer才能要資料)
        {
            // 牌王之路icon
            this._addGamblerRoadIconNode(7, 0, -2);

            // 新增聚寶盆icon
            var treasureBowlIcon = new TreasureBowlGameIconNode();
            treasureBowlIcon.setGameTypeAddProgressBar(VegasGameType.FOOTBALL);
            treasureBowlIcon.setScale(0.6);
            treasureBowlIcon.setPosition(JSVisibleSize.width - JSScreenSafeWidth - 85, 15);
            this.addChild(treasureBowlIcon, 11);

            // 新增側邊欄
            this._addSideOptionLayer(7);
        }

        // 教學畫面
        if (parseInt(GS.localStorage.getItem("FirstEnterFootball", 1))) {
            // 要跳教學 把上面的按鈕丟進去給他
            var teachLayer = new FootballTeachLayer(this._directionNode, this._betBtnArray, this._startButton);
            this.addChild(teachLayer, 20);
        }
    },

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        this._super();
    },

    /**
     * 按鈕
     */
    // 按到儲值
    _purchaseClicked: function () {
        // 要去儲值頁
        PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
    },

    /**
     * 按到返回按鈕
     * @override
     */
    _backBtnClicked: function () {
        // 正在演動畫
        if (this._playing)
            return;

        if (!cc.director.getRunningScene().isVegasScene) {
            PushScene.popLayer(1, false);
        } else {
            // 回大廳
            this._toLobby();
        }
    },

    // 按到說明
    _openRateInfoClicked: function () {
        DialogManager.addDialog(new VegasIntroDialog(VegasGameType.FOOTBALL));
    },

    // 按到出現記錄
    _recordListClicked: function () {
        this._recordLayer.showOrClose();
    },

    // 按到所選到的方向
    _betDirectionClicked: function (sender) {
        // 先把所有方向按鈕設定成可以按
        this._directionBtnArray.forEach(cur => cur.setEnabled(true));

        // 把現在按下去的設定不能按
        sender.setEnabled(false);

        // 設定選到的方向
        this._nowDirection = sender.direction;
    },

    // 按到下注籌碼
    _betClicked: function (sender) {
        var nextBet = this._nowBet + sender.money;

        // 判斷身上的錢夠不夠
        if (nextBet > DataModal.profileData.money) {
            var lessMoney = nextBet - DataModal.profileData.money;
            DialogManager.addDialog(new NoMoneyDialog(lessMoney));
            return;
        }

        // 判斷是否下注金額上限超過
        if (this._nowBet >= this.MAX_BET) {
            // 下注區金額超過上限 要跳Dialog
            var diceBoString = LocalizedString.DiceBo;
            var maxString = JSCodeUtility.getCurrencyString(this.MAX_BET);
            var dialog = new AvatarDialog({
                title: diceBoString("超過上限"),
                content: diceBoString("本區下注金額上限為") + "\n#!E6AA00!#" + maxString + "#!FFFFFF!#"
            });
            DialogManager.addDialog(dialog);
            return;
        }

        this._nowBet += sender.money;
        if (this._nowBet > this.MAX_BET)
            this._nowBet = this.MAX_BET;
        this._betLedNode.setMoney(this._nowBet, true);

        // 修改方向的文字
        this._directionBtnArray.forEach(cur => cur.setBetMoney(this._nowBet));

        // 清掉下注提示畫面
        if (this._betHintLayer) {
            this._betHintLayer.removeFromParent();
            this._betHintLayer = undefined;
        }

        // 撥放音效
        if (sender.index % 3 === 2)
            Vegas_MusicUtility.playEffect("Music/Effect/chipwin.mp3");
        else
            Vegas_MusicUtility.playEffect("Music/Effect/chipone.mp3");
    },

    // 按到清除下注
    _clearClicked: function () {
        this._nowBet = 0;
        this._betLedNode.setMoney(0, false);

        // 清掉方向
        this._directionBtnArray.forEach(cur => cur.setEnabled(true));
        this._nowDirection = 0;

        // 顯示按此下注的畫面
        {
            var betHintLayer = this._betHintLayer = new cc.LayerColor(cc.color(0, 0, 0, 150), JSVisibleSize.width, JSVisibleSize.height);
            this._betLayer.addChild(betHintLayer, 2);

            // 加一個檔Touch的
            var dummyTouch = new DummyTouchLayer(JSVisibleSize);
            betHintLayer.addChild(dummyTouch);

            // 抓出中間籌碼的位置
            var midChipPos = this._betBtnArray[1].getPosition();

            // 文字
            var hintLabel = new cc.LabelTTF(LocalizedString.Football("請下注"), JSFontBoldName, 14);
            hintLabel.setPosition(midChipPos.x, midChipPos.y + 50);
            betHintLayer.addChild(hintLabel);

            // 箭頭
            var arrowSprite = new cc.Sprite("#football_pic_arrow_04.png");
            arrowSprite.setPosition(midChipPos.x, midChipPos.y + 29);
            betHintLayer.addChild(arrowSprite);
            arrowSprite.runAction(cc.sequence(
                cc.moveBy(0.25, cc.p(0, 4)),
                cc.moveBy(0.25, cc.p(0, -4))
            ).repeatForever());
        }
    },

    // 按到開始射門
    _startClicked: function () {
        // 判斷是否有選方向了
        if (this._nowDirection === 0) {
            var footballString = LocalizedString.Football;
            DialogManager.addDialog(new AvatarDialog({
                title: footballString("提醒"),
                content: footballString("請先選擇射門方向再下注哦"),
                buttons: [footballString("下注")]
            }));
            return;
        }

        // 判斷身上的錢夠不夠
        if (this._nowBet > DataModal.profileData.money) {
            var lessMoney = this._nowBet - DataModal.profileData.money;
            DialogManager.addDialog(new NoMoneyDialog(lessMoney));

            return;
        }

        // 送出
        DataProcess.sendString(JSStringUtility.format("slot_machine 22 %d %d", this._nowDirection, this._nowBet));

        // 把背景隱藏
        this._bgNode.setVisible(false);

        // 把下注畫藏起來
        this._betLayer.setVisible(false);

        // 打開Loading
        this._loadingSprite.start();

        // AppsFlyer埋點
        GSAppsFlyerWrapper.logEvent("casino");

        // Firebase 埋點
        var eventName = GSAnalyticsAdapter.record.game + "娛樂城玩法";
        GSAnalyticsAdapter.logEventByFirebaseAll(eventName, ["大廳"], ["super shot football下注"]);
    },

    /**
     * 通知
     */
    notifySlot22Begin: function (event) {
        var param = event.getUserData();

        // 關掉Loading
        this._loadingSprite.stop();

        // 把背景隱藏
        this._bgNode.setVisible(false);

        // 把下注畫藏起來
        this._betLayer.setVisible(false);

        // 設定正在演動畫
        this._playing = true;

        // 把自己射門的方向加上去
        param.ballDirection = this._nowDirection;

        // 去撥放動畫
        this._animationLayer.playResultAsync(param)
            .then(() => {
                if (this.__isDestroyed)
                    return;

                // 撥放動畫了 把該出現的畫面打開
                this._bgNode.setVisible(true);
                this._betLayer.setVisible(true);

                // 更新記錄
                this._recordLayer.refreshRecord();

                // 通知外面動畫結束，檢查有沒有事情要做
                this.notifyVegasGameFinished();

                // 設定動畫結束
                this._playing = false;
            });

        // 更新聚寶盆
        DataModal.treasureBowlData.treasureBowlParam && DataModal.treasureBowlData.updateDataBy(this._nowBet);


        // 存下遊戲紀錄
        this._savePlayerRecord();
    }
});

// 踢球的方向
FootballLayer.Direction = {
    UP: 1,
    DOWN_LEFT: 2,
    DOWN_RIGHT: 3,
    UP_LEFT: 4,
    UP_RIGHT: 5
};