/**
 * 尋找好友的Cell
 */

var FindFriendCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        // 2:推薦好友 3:搜尋好友 用來送給server的type
        this._from = 2;

        var midPosY = FindFriendCell.HEIGHT / 2 + 3;

        // 放要變色的東西
        var mainNode = this._mainNode = new cc.Node();
        mainNode.setCascadeColorEnabled(true);
        this.addChild(mainNode);

        // 大頭照
        var photoNode = this._photoSprite = new LobbyCircleProfileNode();
        photoNode.setPosition(30, midPosY);
        photoNode.setScale(0.7);
        mainNode.addChild(photoNode);

        // 暱稱
        var nicknameLabel = this._nicknameLabel = new GSAutoSizeLabel("", JSFontBoldName, 12, cc.size(90, GameRankRankCell.HEIGHT), cc.TEXT_ALIGNMENT_LEFT, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        nicknameLabel.setAnchorPoint(0, 0.5);
        nicknameLabel.setPosition(53, midPosY);
        mainNode.addChild(nicknameLabel);

        // 個人資訊的按鈕(點大頭照&暱稱會跳出個人資訊頁)
        var profileBtn = new GSControlButton("", cc.size(147, FindFriendCell.HEIGHT));
        profileBtn.setCascadeOpacityEnabled(true);
        profileBtn.addTargetWithActionForControlEvents(this, this._profileBtnClicked,
            cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
            cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
            cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
        profileBtn.setPosition(0, 0);
        profileBtn.setAnchorPoint(0, 0);
        profileBtn.enableTouchCancel(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        this.addChild(profileBtn);

        // 加入按鈕
        var joinNode = this._joinNode = new FriendJoinNode();
        joinNode.setPosition(147, 8);
        this.addChild(joinNode);

        // 加入好友
        var itemNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_circle_04.png", null, "#lobby_icon_add_friend.png");
        itemNodes.forEach(item => {
            item.bg.setScale(1.1);
            item.word.setScale(0.75);
        });
        var addBtn = new cc.ControlButton(itemNodes[0]);
        addBtn.setBackgroundSpriteForState(itemNodes[1], cc.CONTROL_STATE_HIGHLIGHTED);
        addBtn.setAdjustBackgroundImage(false);
        addBtn.setZoomOnTouchDown(false);
        addBtn.setSwallowTouches(false);
        addBtn.setTouchDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        addBtn.addTargetWithActionForControlEvents(this, this._addFriendClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        addBtn.setPosition(290, midPosY);
        this.addChild(addBtn);

        // 最近上線時間
        var lastOnlineLabel = this._lastOnlineLabel = new cc.LabelTTF("Online", JSFontBoldName, 10);
        lastOnlineLabel.setAnchorPoint(1, 0.5);
        lastOnlineLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_RIGHT);
        lastOnlineLabel.setPosition(365, midPosY);
        this.addChild(lastOnlineLabel);

        // 是否在線上的亮燈
        var onlineSp = this._onlineSp = new cc.Sprite("#lobby_prompt_bg4.png");
        onlineSp.setScale(0.5);
        onlineSp.setPosition(370, midPosY);
        this.addChild(onlineSp);

        // cell分隔線
        var lineSp = new ccui.Scale9Sprite("lobby_brown_line.png");
        lineSp.setPreferredSize(cc.size(357, 2));
        lineSp.setPosition(197, 4);
        this.addChild(lineSp);

        // 監聽封鎖其他玩家事件
        GS.addListener("NotifyRefreshIsForbidden", this.notifyRefreshIsForbidden.bind(this), this);
    },

    /**
     * 刷新Cell
     * @param param : DataModal.friendData.findFriendList
     * @param isSearch : 是否為搜尋結果
     */
    refreshCell: function (param, isSearch) {
        if (!param)
            return;

        // 送給server的type 2:推薦好友 3:搜尋好友
        this._from = (isSearch) ? 2 : 3;

        this._userID = param.userID;
        this._photo = param.photo;

        // 暱稱
        this._nicknameLabel.setString(JSStringUtility.cutStringReplaceByEllipsis(param.nickname, 12, 136));

        // 刷新大頭貼
        this._photoSprite.setPhotoUrl(param.photo, param.userID);

        // 刷新加入桌的資料
        if (param.join) {
            this._joinNode.setVisible(true);
            this._joinNode.refreshInfo(param.join, param.userID);
        } else {
            this._joinNode.setVisible(false);
        }

        // 刷新最後上線時間
        var onlineRes = (param.isOnline) ? "lobby_prompt_bg3.png" : "lobby_prompt_bg4.png";
        this._onlineSp.setSpriteFrame(onlineRes);
        this._lastOnlineLabel.setString(param.lastOnline);
    },

    /**
     * 加好友點擊
     */
    _addFriendClicked: function () {
        if (!this._userID)
            return;

        // 加loading
        GSLoading.addLoadingView();

        // 加入好友
        var obj = {
            userid: this._userID,
            type: 1,
            from: this._from
        };
        DataProcess.sendString("user_invite_friend " + JSON.stringify(obj));

        // AppsFlyer
        GSAppsFlyerWrapper.logEvent("add_friends");
    },

    /**
     *  個人資訊頁點擊
     */
    _profileBtnClicked: function (sender, type) {
        var isTouched = (type === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || type === cc.CONTROL_EVENT_TOUCH_DOWN);
        this._mainNode.setColor(isTouched ? JSColor.GRAY : JSColor.WHITE);

        if (type === cc.CONTROL_EVENT_TOUCH_UP_INSIDE) {
            if (!this._userID)
                return;

            DialogManager.addDialog(new ProfileDialog(this._userID));
        }
    },

    notifyRefreshIsForbidden: function (event) {
        if (event.getUserData() === this._userID) {
            this._photoSprite.setPhotoUrl(this._photo, this._userID);
        }
    },
});

// Cell高度
FindFriendCell.HEIGHT = 50;