/**
 * 5.3.7 優惠券背包 - 主畫面
 * Created by Jimmy.Wen 2022/3/8
 *
 * 5.5.1 增加推薦方案
 */
var BonusBackpackNode = PurchasePackBaseNode.extend({
    /**
     * @param param                 禮包資訊
     * @param closeDialogCallBack   按下關閉或成功畫面的確定要執行的callBack
     */
    ctor: function (param, closeDialogCallBack) {
        this._super(param, closeDialogCallBack);

        this._totalCellCount = 0;
        this._couponList = [];

        // 背景紅光
        var redLightSprite = new cc.Sprite("#bonusBackpack_bg_light.png");
        redLightSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 5);
        redLightSprite.setScale(21, 11.5);
        this.addChild(redLightSprite);

        // 兩側黃光點
        for (let i = 0; i < 2; i++) {
            var spotSprite = new cc.Sprite("#bonusBackpack_bg_spot.png");
            spotSprite.setPosition(JSScreenMidPos.x + 167 * Math.pow(-1, i), JSScreenMidPos.y - 34.5);
            spotSprite.setScaleX(Math.pow(-1, i));
            this.addChild(spotSprite);
        }

        // 背景的箱子
        for (var i = 0; i < 2; i++) {
            // 箱子上半部
            var boxTopSprite = new ccui.Scale9Sprite("bonusBackpack_bg_box_01.png");
            boxTopSprite.setCapInsets(cc.rect(40, 0, 10, 120));
            boxTopSprite.setContentSize(cc.size(198, 120));
            boxTopSprite.setAnchorPoint(cc.p(1 - i, 0.5));
            boxTopSprite.setPosition(JSScreenMidPos.x - (i - 0.5) * 4, JSScreenMidPos.y + 42);
            boxTopSprite.setFlippedX(i === 1);
            this.addChild(boxTopSprite);

            // 箱子下半部
            var boxBottomSprite = new ccui.Scale9Sprite("bonusBackpack_bg_box_02.png");
            boxBottomSprite.setCapInsets(cc.rect(40, 0, 10, 80));
            boxBottomSprite.setContentSize(cc.size(198, 120));
            boxBottomSprite.setAnchorPoint(cc.p(1 - i, 0.5));
            boxBottomSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 64.7);
            boxBottomSprite.setFlippedX(i === 1);
            this.addChild(boxBottomSprite);
        }

        // 上方的緞帶
        for (var i = 0; i < 2; i++) {
            // 上方緞帶
            var ribbonSprite = new cc.Sprite("#bonusBackpack_pic_ribbon.png");
            ribbonSprite.setAnchorPoint(cc.p(1 - i, 0.5));
            ribbonSprite.setPosition(JSScreenMidPos.x - 0.5 * i, JSScreenMidPos.y + 107);
            ribbonSprite.setFlippedX(i === 1);
            this.addChild(ribbonSprite);
        }

        // 背景白紙
        var bgSprite = new ccui.Scale9Sprite("bonusBackpack_bg_01.png");
        bgSprite.setContentSize(cc.size(355, 165));
        bgSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 1);
        this.addChild(bgSprite);

        // 跑馬燈背景
        var lineSprite = new ccui.Scale9Sprite("bonusBackpack_bg_line.png");
        lineSprite.setContentSize(cc.size(263, 19));
        lineSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 65);
        this.addChild(lineSprite);

        // 跑馬燈
        var marqueeText = [LocalizedString.Purchase("不容錯過的限時優惠"),
            LocalizedString.Purchase("優惠券可以到商城購買喔"),
            LocalizedString.Purchase("心動不如馬上行動！")];
        var marqueeNode = this._marquee = new MarqueeNode({
            width: 263,
            height: 15,
            sec: 10,
            fontSize: 12,
            isLoop: false,
            disableBG: true
        });
        marqueeNode.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 65);
        this.addChild(marqueeNode);

        // 跑馬燈輪播
        var index = 0;
        marqueeNode.runAction(cc.repeatForever(cc.sequence(
            cc.callFunc(function () {
                marqueeNode.push({
                    message: marqueeText[index % marqueeText.length],
                    color: cc.color(255, 255, 255)
                });
                // 隨機+0或+1 來符合隨機同一句，或下一句
                index += Math.floor(Math.random() * 2);
            }),
            cc.delayTime(12)   // 換訊息時間
        )));

        // 裝推薦方案的node
        var recommendNode = this._recommendNode = new cc.Node();
        this.addChild(recommendNode);

        // 空背包中間文字
        if (this._totalCellCount === 0) {
            var messageLabel = this._messageLabel = new cc.LabelTTF(LocalizedString.Purchase("目前沒有優惠券喔"), JSFontName, 14.5);
            messageLabel.setFontFillColor(cc.color.BLACK);
            messageLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y);
            messageLabel.setVisible(false);
            messageLabel.setAnchorPoint(0.5, 0.5);
            this.addChild(messageLabel);
        }

        // loading時不可點擊後面
        var dummy = this._dummy = new DummyTouchLayer(cc.size(350, 135));
        dummy.setPosition(JSScreenMidPos.x - 175, JSScreenMidPos.y - 82);
        dummy.setVisible(false);
        this.addChild(dummy, 5);

        // loading畫面
        var loadingSp = this._loadingSp = new GSLoadingSprite();
        loadingSp.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 12);
        loadingSp.setColor(cc.color(240, 240, 240));
        loadingSp.start();
        this.addChild(loadingSp, 10);

        // 下方陰影
        var shadowSprite = new ccui.Scale9Sprite("bonusBackpack_bg_shadow_03.png");
        shadowSprite.setContentSize(cc.size(346, 20));
        shadowSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 71.5);
        shadowSprite.setOpacity(10);
        this.addChild(shadowSprite);

        // 兩側壓印
        for (let i = 0; i < 2; i++) {
            var patternSprite = new cc.Sprite("#bonusBackpack_bg_pattern.png");
            patternSprite.setPosition(JSScreenMidPos.x - 153 * Math.pow(-1, i), JSScreenMidPos.y + 65);
            patternSprite.setScaleX(Math.pow(-1, i));
            patternSprite.setOpacity(51.2);
            this.addChild(patternSprite);
        }

        // 標題
        var titleSprite = new cc.Sprite("#bonusBackpack_word_title.png");
        titleSprite.setPosition(JSScreenMidPos.x - 0.75, JSScreenMidPos.y + 110);
        this.addChild(titleSprite);

        // 左上說明按鈕
        var infoBtn = ButtonUtility.createSimpleImageButton("lobby_btn_circle_03.png", null, "#lobby_btn_pic_window_?.png");
        infoBtn.addTouchUpInsideAction(this._infoClicked, this);
        infoBtn.setPosition(JSScreenMidPos.x - 153, JSScreenMidPos.y + 65);
        infoBtn.setScale(0.8);
        this.addChild(infoBtn);

        // 右上關閉按鈕
        var closeBtn = this._closeBtn = ButtonUtility.createSimpleImageButton("lobby_btn_circle_04.png", null, "#lobby_btn_pic_window_x.png");
        closeBtn.addTouchUpInsideAction(this.closePurchasePackDialog, this);
        closeBtn.setPosition(430 + JSScreenBonusHalfWidth, 251 + JSScreenBonusHalfHeight);
        this.addChild(closeBtn);

        // 下方使用按鈕
        var btnUse = this._btnUse = ButtonUtility.createSimpleButton("lobby_btn_01.png", cc.size(160, 28), ProfileData.getKoinLuxyRes("去KL商城看好康", ""), JSColor.BLACK, 13);
        btnUse.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 115);
        btnUse.addTouchUpInsideAction(this._btnUseClicked, this);
        this.addChild(btnUse);

        // 監聽 收到資料、收到領獎
        GS.addListener("NotifyCouponAssembleDone", this.notifyCouponAssembleDone.bind(this), this);
        GS.addListener("NotifyUpdateCouponAssemble", this.notifyUpdateCouponAssemble.bind(this), this);
        GS.addListener("NotifyBonusBackpackIapRechargeReward", this.notifyBonusBackpackIapRechargeReward.bind(this), this);
        GS.addListener("NotifyBonusBackpackLoadingStart", this.notifyBonusBackpackLoadingStart.bind(this), this);
        GS.addListener("NotifySetBillOptionsDone", this._refreshView.bind(this), this);                 // 收到儲值中心資料要刷新畫面(看有沒有推薦方案)
        GS.addListener("NotifyPurchaseSuccess", this.notifyBonusBackpackLoadingStart.bind(this), this); // 儲值完要壓loading 等儲值中心資料送回來
    },

    onEnter: function () {
        this._super();

        // 刷新畫面
        this._refreshView();
    },

    keyBackPressed: function () {
        if (this._isLockBackKey)
            return;

        // 直接關掉了
        this.closePurchasePackDialog();
    },

    /**
     * 刷新畫面
     */
    _refreshView: function () {
        // 關閉loading畫面
        this._loadingSp.stop();
        this._dummy.setVisible(false);

        // 清掉推薦Node內容
        this._recommendNode.removeAllChildren();

        // 取得有效時間內的優惠券
        this._couponList = DataModal.purchaseCouponData.couponAssemble.filter(cur => {
            return JSCodeUtility.getRemainTime(cur.remainTime, cur.socketTime);
        });

        this._totalCellCount = this._couponList.length;                         // 重取cell數量
        var haveCoupon = this._totalCellCount !== 0;                            // 是否有優惠券
        var haveAvailableCoupon = this._couponList.some(cur => cur.isUsing);    // 有使用中的券
        var recommendParam = this._recommendParam = DataModal.purchaseData.getRecommendProduct();  // 取得推薦方案的param
        var purchaseString = LocalizedString.Purchase;
        var isShowRecommend = haveAvailableCoupon && recommendParam;

        // 優惠券tableView
        this._tableView && this._tableView.removeFromParent(true);
        var tableView = this._tableView = new cc.TableView(this, cc.size(336, isShowRecommend ? 78 : 131), this._mainLayer);
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setAnchorPoint(0, 0);
        tableView.setDelegate(this);
        tableView.setPosition(85 + JSScreenBonusHalfWidth, 63 + JSScreenBonusHalfHeight);
        this.addChild(tableView);

        // 如果有推薦方案
        if (isShowRecommend) {
            var size = cc.size(323.5, 51.5);
            var midPoint = cc.p(size.width / 2, size.height / 2);

            // 背景&整個node
            var mainNode = new ccui.Scale9Sprite("bonusBackpack_bg_frame.png");
            mainNode.setContentSize(size);

            // 整個推薦方案的按鈕
            var button = new GSControlButton(mainNode, size);
            button.setCascadeOpacityEnabled(true);
            button.setChangeColorWhenDisabled(false);
            button.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 24);
            button.addTouchUpInsideAction(this._recommendButtonClicked, this);
            this._recommendNode.addChild(button);

            if (recommendParam.percent > 0) {
                // 爆炸狀的標籤&數字圖
                var recommendSprite = new cc.Sprite("#lobby_pic_empty_label.png");
                recommendSprite.setPosition(cc.pAdd(midPoint, cc.p(-129, 0)));
                mainNode.addChild(recommendSprite);

                var countdownSprite = new GSSpriteNumberNode({
                    number: recommendParam.percent,
                    numStr: "#num_03_",
                    spW: 9,
                    symbolName: "#num_03_%.png",
                    symbolLoc: GSSpriteNumberNode.SymbolLoc.BACK
                });
                countdownSprite.setPosition(cc.pAdd(midPoint, cc.p(-129, 0)));
                countdownSprite.setRotation(-15);
                mainNode.addChild(countdownSprite);
            }

            // 推薦方案的文字
            var recommendTotalChips = JSCodeUtility.getCurrencyString(recommendParam.chips);
            if (recommendParam.vipPercent > 0)
                recommendTotalChips += "\n" + JSStringUtility.format(purchaseString("(含VIP %d%%)"), recommendParam.vipPercent);
            var recommendLabel = new cc.LabelTTF(recommendTotalChips, JSFontName, 13);
            recommendLabel.setPosition(cc.pAdd(midPoint, cc.p(-18.5, 0)));
            recommendLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            mainNode.addChild(recommendLabel);

            // 推薦方案的假按鈕
            var priceText = JSStringUtility.format("Rp. %s", JSCodeUtility.getCurrencyString(recommendParam.price));
            var recommendButtonSprite = new ccui.Scale9Sprite("lobby_btn_03.png");
            recommendButtonSprite.setCascadeColorEnabled(true);
            recommendButtonSprite.setContentSize(cc.size(83.5, 28.5));
            recommendButtonSprite.setPosition(cc.pAdd(midPoint, cc.p(110.5, 0)));
            mainNode.addChild(recommendButtonSprite);
            recommendButtonSprite.runAction(cc.repeatForever(
                cc.sequence(
                    cc.scaleTo(0.5, 1.1),
                    cc.scaleTo(0.5, 1)
                ))
            );

            var recommendButtonLabel = new cc.LabelTTF(priceText, JSFontName, 11.25);
            recommendButtonLabel.setPosition(42, 14);
            recommendButtonSprite.addChild(recommendButtonLabel);
        }

        // 刷新tableView內容
        this._tableView.reloadData(true);

        // 沒有優惠券才顯示文字
        this._messageLabel.setVisible(!haveCoupon);

        /*
        大廳的儲值中心
	        有券：OK
	        沒券：去%s商城看好康
        牌桌或slot機台的儲值中心
	        有券：OK
	        沒券：OK
        vip中心
	        有券：馬上使用
	        沒券：去%s商城看好康
         */

        // 桌內儲值
        if (PushScene.isGame || PushScene.isSlot) {
            this._btnUse.label.setString(purchaseString("確定"));
        } else {
            // VIP中心
            if (PushScene.checkNowLayer(VipLayer)) {
                if (haveCoupon)
                    this._btnUse.label.setString(purchaseString("馬上使用"));
                else {
                    this._btnUse.label.setString(ProfileData.getKoinLuxyRes("去KL商城看好康", ""));
                }
            }
            // 大廳儲值
            else {
                if (haveCoupon)
                    this._btnUse.label.setString(purchaseString("確定"));
                else {
                    this._btnUse.label.setString(ProfileData.getKoinLuxyRes("去KL商城看好康", ""));
                }
            }
        }

        // 在儲值中心且有優惠券 or 在桌內儲值時，隱藏Ｘ按鈕
        var closeBtnVisible = !((PushScene.checkNowLayer(PurchaseLayer) && this._totalCellCount !== 0) || PushScene.isGame);
        this._closeBtn.setVisible(closeBtnVisible);

        // 倒數計時
        if (this._timerNode) {
            this._timerNode.removeFromParent();
            this._timerNode = undefined;
        }
        var couponTime = DataModal.purchaseCouponData.couponAssembleTime;
        var leftTime = JSCodeUtility.getRemainTime(couponTime.remainTime, couponTime.socketTime);
        if (leftTime > 0) {
            var timeNode = this._timerNode = new GSTimerNode();
            timeNode.countdownSeconds(leftTime, () => {
                // 時間到重新要優惠券資料(coupon_assemble)
                DataModal.purchaseCouponData.startGetCouponAssembleInfo();

                // 優惠券背包壓loading
                GS.dispatchCustomEvent("NotifyBonusBackpackLoadingStart");

                // 刪掉倒數計時
                this._timerNode.removeFromParent();
                this._timerNode = undefined;
            });
            this.addChild(timeNode);
        }

        // 先砍掉手指動畫
        if (this._fingerSprite) {
            this._fingerSprite.removeFromParent();
            this._fingerSprite = undefined;
        }

        // 無優惠券時才有手指動畫
        if (!haveCoupon) {
            // 手指
            var fingerSprite = this._fingerSprite = new cc.Sprite("#lobby_pic_finger.png");
            fingerSprite.setRotation(-22);
            fingerSprite.setScale(0.7);
            fingerSprite.setPosition(JSScreenMidPos.x + 90, JSScreenMidPos.y - 127);
            this.addChild(fingerSprite);

            // 手指動畫
            fingerSprite.runAction(cc.repeatForever(cc.sequence(
                cc.scaleTo(0.1, 1, 0.8),
                cc.scaleTo(0.1, 1, 1),
                cc.scaleTo(0.1, 1, 0.8),
                cc.scaleTo(0.1, 1, 1),
                cc.delayTime(0.8)
            )));
        }
    },

    /**
     * 說明點擊
     */
    _infoClicked: function () {
        var url = TexasUtility.getSimpleInfoURLByKey("coupon_assemble");
        DialogManager.addDialog(new WebViewDialog(url, "", undefined, false, GSEnum.DialogSize.MIDDLE), false);
    },

    /**
     * 使用點擊
     */
    _btnUseClicked: function () {
        // 桌內儲值點按鈕關閉視窗
        if (PushScene.isGame || PushScene.isSlot) {
            // 埋點：點擊馬上使用(OK)
            DataProcess.sendString('track_coupon_assemble 4');
        } else {
            if (this._totalCellCount === 0) {
                // 導PR商城HOT頁籤
                PushLayerHelper.pushLayer("", LobbyBannerMode.GemStore);

                // 埋點：點擊去xx商城看好康
                DataProcess.sendString('track_coupon_assemble 5');
            } else {
                // 不是已經在的話 導儲值中心
                if (PushScene.checkNowLayer(PurchaseLayer))
                    this.closePurchasePackDialog();
                else
                    PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);

                // 埋點：點擊馬上使用(OK)
                DataProcess.sendString('track_coupon_assemble 4');
            }
        }
        this.closePurchasePackDialog();
    },

    _recommendButtonClicked: function () {
        var param = this._recommendParam;
        // 要去儲值
        var purchaseParam = [param.serverID];

        // 這邊會依照有特別的活動ID的話 需把活動ID加到JSON裡
        if (param.verifyID && param.verifyID.length)
            purchaseParam.push(param.verifyID);

        DataModal.purchaseData.sendPurchaseByServerID(purchaseParam);

        // 埋點：點擊儲值按鈕不重複人數
        DataProcess.sendString('track_coupon_assemble 13');
    },

    /**
     * TableView delegate
     */
    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        // 創cell
        if (cell == null) {
            cell = new BonusBackpackCouponCell();
            cell.setAnchorPoint(0, 0);
        }

        // 刷新cell
        var couponList = this._couponList;
        if (couponList && idx < this._totalCellCount) {
            cell.refreshCell(couponList[idx], idx === this._totalCellCount - 1);
        }

        return cell;
    },

    numberOfCellsInTableView: function () {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function () {
        return cc.size(BonusBackpackCouponCell.WIDTH, BonusBackpackCouponCell.HEIGHT);
    },

    /**
     * 通知事件
     */
    // 通知收到優惠券資訊
    notifyCouponAssembleDone: function () {
        // 刷新內容
        this._refreshView();
    },

    /**
     * 通知領獎
     */
    notifyBonusBackpackIapRechargeReward: function (event) {
        // 取得領獎資訊
        var rewardData = event.getUserData();
        var dialogContent;

        if (rewardData.isSuccess) {
            // 轉換獎品內容的文字
            var rewardMsgText = "";
            for (var i = 0; i < rewardData.reward.length; i++) {
                rewardMsgText += rewardData.reward[i].toString();
                if (i !== rewardData.reward.length - 1)
                    rewardMsgText += "\n";
            }
            dialogContent = LocalizedString.Purchase("恭喜獲得") + "\n" + rewardMsgText;
        } else {
            dialogContent = LocalizedString.Purchase("發生錯誤");
        }

        // 顯示獲獎的Dialog
        DialogManager.addDialog(new Dialog({
            content: dialogContent,
            buttons: [LocalizedString.Purchase("確定")],
            callback: () => {
                // 已經砍掉了不做事
                if (this.__isDestroyed)
                    return;

                // 重新要資料
                DataModal.purchaseCouponData.startGetCouponAssembleInfo();
                this._dummy.setVisible(true);
                this._loadingSp.start();
            }
        }), false);
    },

    /**
     * 通知出現loading
     */
    notifyBonusBackpackLoadingStart: function () {
        this._dummy.setVisible(true);
        this._loadingSp.start();
    },

    /**
     * 通知刷新有效時間的優惠券清單
     */
    notifyUpdateCouponAssemble: function () {
        // 取得有效優惠券的清單
        this._couponList = DataModal.purchaseCouponData.couponAssemble.filter(cur => {
            return JSCodeUtility.getRemainTime(cur.remainTime, cur.socketTime);
        });

        // 重取cell數量
        this._totalCellCount = this._couponList.length;

        // 刷新tableView內容
        this._tableView.reloadData(true);
    }
});