/**
 * 通行證 - 循環獎勵 Node
 * Sample config: {
 *     tokenIconFileName: "",                                   // 代幣圖
 *     cycleRewardBgFileName: "",                               // 背景圖
 *     cycleRewardSize: cc.size(0, 0),                          // Node Size
 *     cycleRewardTitleBgFileName: "",                          // 上方標題背景圖
 *     cycleRewardTitleBgSize: cc.size(0, 0),                   // 上方標題背景圖尺寸
 *     cycleRewardTitleFileName: "",                            // 上方標題字圖
 *     cycleRewardBgFileName: "",                               // 進度條背景圖
 *     cycleRewardBarFileName: "",                              // 進度條 bar 圖
 *     cycleRewardTagFileName: "",                              // 可領次數標籤圖
 * }
 */
var BasePassCycleRewardNode = cc.Node.extend({
    ctor: function (config) {
        this._super();
        let bgFileName = config.cycleRewardBgFileName || "luxyPass_pic_frame_06.png";
        let size = this._size = config.cycleRewardSize || cc.size(245, 144);
        this._midPos = cc.p(size.width / 2, size.height / 2);

        let titleBgFileName = config.cycleRewardTitleBgFileName || "luxyPass_pic_title_bg.png";
        let titleBgSize = config.cycleRewardTitleBgSize || cc.size(127, 23);

        let titleWordFileName = config.cycleRewardTitleFileName || "luxyPass_word_title_05.png";

        this._config = config;
        this._tokenCountInProgress = 0;    // 記錄進度條顯示的星星數

        // 內容整個是一個大按鈕
        let contentButton = ButtonUtility.createSimpleButton(bgFileName, size);
        contentButton.addTouchUpInsideAction(this.onClick, this);
        contentButton.enableTouchCancel(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
        this.addChild(contentButton);

        // 上方標題背景
        let topBgSprite = new ccui.Scale9Sprite(titleBgFileName);
        topBgSprite.setPreferredSize(titleBgSize);
        topBgSprite.setPosition(0, size.height / 2 + 8);
        contentButton.addChildToContentNode(topBgSprite);

        // 上方標題文字圖
        let titleSprite = new cc.Sprite("#" + titleWordFileName);
        titleSprite.setPosition(topBgSprite.getPosition().x, topBgSprite.getPosition().y - 3);
        contentButton.addChildToContentNode(titleSprite);

        // 文字圖
        let textSprite = this._textSprite = new cc.Sprite("#" + this._getWordSpriteFileName(false, false));
        contentButton.addChild(textSprite);

        // 金庫圖
        let treasurySprite = this._treasurySprite = new cc.Sprite("#luxyPass_pic_treasury.png");
        treasurySprite.setScale(0.7);
        contentButton.addChild(treasurySprite);

        // 進度條
        let progressBar = this._progressBar = new BasePassCycleProgressBarBtn(this._config);
        progressBar.setVisible(false);
        progressBar.setPosition(0, -42);
        progressBar.addTouchUpInsideAction(this.progressBtnClicked, this);
        this.addChild(progressBar);

        // 右上角領獎次數
        let tagNode = this._tagNode = new BasePassCycleRewardTag(this._config);
        tagNode.setVisible(false);
        tagNode.setPosition(111, 62);
        this.addChild(tagNode);

        let lockSpine = this._lockSpine = new BasePassRewardLock();
        lockSpine.setPosition(-110, 57);
        this.addChild(lockSpine);
    },

    /**
     * 更新文字圖
     * @param {boolean} isInCycleReward 是否在循環獎勵中
     * @param {boolean} isHavePass      有無購買 pass
     */
    refreshTextSprite: function (isInCycleReward, isHavePass) {
        this._textSprite.setSpriteFrame(this._getWordSpriteFileName(isInCycleReward, isHavePass));
        this._textSprite.setPosition(cc.pAdd(this._midPos, isInCycleReward ? cc.p(-40, 16) : cc.p(-41, 0)));
    },

    /**
     * 更新金庫圖
     * @param {boolean} isInCycleReward 是否在循環獎勵中
     */
    refreshTreasurySprite: function (isInCycleReward) {
        this._treasurySprite.setPosition(cc.pAdd(this._midPos, cc.p(78, isInCycleReward ? 11 : 0)));
    },

    /**
     * 設定可領獎次數
     * @param {int} rewardCount
     */
    refreshRewardCount: function (rewardCount) {
        this._rewardCount = rewardCount;
        this._tagNode.setTimes(rewardCount);
        this._tagNode.setVisible(this._isInCycleReward && rewardCount > 0);
    },

    /**
     * 更新進度條
     * @param {Number} currentCycleTokenCount   目前循環代幣數量
     * @param {Number} goalTokenCount           目標代幣數量
     */
    refreshProgressBar: function (currentCycleTokenCount, goalTokenCount) {
        this._progressBar.setVisible(this._isInCycleReward);
        this._progressBar.refreshView(currentCycleTokenCount, goalTokenCount);
    },

    /**
     * 更新鎖頭
     * @param {boolean} isHavePass 是否已購買通行證
     */
    refreshLock: function (isHavePass) {
        this._lockSpine && this._lockSpine.setVisible(!isHavePass);
    },

    /**
     * 取得代幣 icon 世界位置
     * @returns {cc.Point}
     */
    getTokenIconPosition: function () {
        return this._progressBar.getTokenIconPosition();
    },

    /**
     * 設定是否在循環獎勵中
     * @param {boolean} isInCycleReward
     */
    setInCycleReward: function (isInCycleReward) {
        this._isInCycleReward = isInCycleReward;
    },

    /**
     * 是否跳過動畫
     * @param {boolean} isSkipped
     */
    setSkipped: function (isSkipped) {
        this._progressBar.setSkipped(isSkipped);
    },

    /**
     * 播放跑代幣增加動畫
     * @param {int} addTokenCount   代幣數量變化量
     * @param {int} goalTokenCount  目標代幣數量
     * @returns {Promise<void>}
     */
    playProgressAnimationAsync: function (addTokenCount, goalTokenCount) {
        return new Promise((resolve, reject) => {
            if (this.__isDestroyed) {
                return;
            }

            if (!this._progressBar || this._isSkipped) {
                this._isSkipped = false;
                return resolve();
            }

            this._progressBar.onProgressFull(() => {
                this._rewardCount++;
                this._tagNode.setVisible(true);
                this._tagNode.setTimes(this._rewardCount);
                this._tagNode.playLabelAnime();
            });

            this._progressBar.playAnimeAsync(addTokenCount, goalTokenCount)
                .then(() => resolve())
                .catch(() => reject());
        });
    },

    /**
     * 計算使用以下的哪張圖
     * luxyPass_word_final_stage_02.png - 非循環獎勵 無通行證
     * luxyPass_word_final_stage_03.png - 非循環獎勵 有通行證
     * luxyPass_word_final_stage_04.png - 是循環獎勵 無通行證
     * luxyPass_word_final_stage_05.png - 是循環獎勵 有通行證
     *
     * @param {boolean} isCycleReward   是否為循環獎勵
     * @param {boolean} isHavePass      是否已購買通行證
     * @param {string}  pattern         檔名 pattern
     * @param {int}     offset          從幾號開始
     * @protected
     */
    _getWordSpriteFileName: function (isCycleReward, isHavePass, pattern = "luxyPass_word_final_stage_0%d.png", offset = 2) {
        let number = (isCycleReward << 1) + isHavePass + offset;
        return JSStringUtility.format(pattern, number);
    },

    /**
     * 整個循環獎勵點擊
     * @param {object} sender
     * @abstract
     */
    onClick: function (sender) {
        cc.error("忘記 override onClick");
    },

    /**
     * 進度條點擊
     * @param sender
     * @abstract
     */
    progressBtnClicked: function (sender) {
        cc.error("忘記 override progressBtnClicked");
    }
});
 