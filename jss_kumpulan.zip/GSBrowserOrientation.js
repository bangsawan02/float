/**
 * 用來設定Browser的轉向相關功能
 */

var GSBrowserOrientation = {
    PORTRAIT_MAX_SIZE: undefined,       // 直向的最大大小
    PORTRAIT_MIN_SIZE: undefined,       // 直向的最小大小
    LANDSCAPE_MAX_SIZE: undefined,      // 橫向的最大大小
    LANDSCAPE_MIN_SIZE: undefined,      // 橫向的最小大小
    HINT_VIEW_CLASS: undefined,         // 要出現提示畫面的class 預設是走GSBrowserOrientationHintView
    HINT_VIEW_TAG: 51279,               // 提示畫面在場景中的tag 用來之後移除用

    /**
     * 檢查現在的大小
     */
    startCheckSize: function (isPortrait, callback) {
        // 先判斷是否要轉向
        let screenWidth = window.innerWidth;
        let screenHeight = window.innerHeight;

        let nowIsPortrait = screenWidth < screenHeight;
        if (nowIsPortrait !== isPortrait) {
            // 要跳出轉畫面的東西
            let notificationNode = cc.director.getNotificationNode();
            if (!notificationNode) {
                notificationNode = new cc.Node();
                notificationNode.setPosition(JSOriginPoint);
                cc.director.setNotificationNode(notificationNode);
            }
            let oldHintView = notificationNode.getChildByTag(this.HINT_VIEW_TAG);
            if (oldHintView)
                oldHintView.removeFromParent();

            let hintViewClass = this.HINT_VIEW_CLASS || GSBrowserOrientationHintView;
            let hintView = new hintViewClass(isPortrait);

            notificationNode.addChild(hintView, 5000, this.HINT_VIEW_TAG);

            // 監聽轉畫面
            cc.view.setResizeCallback(() => {
                this._checkSize(isPortrait, callback);
            });
        } else {
            // 直接轉
            this._checkSize(isPortrait, callback);
        }
    },

    /**
     * 主要變更的地方
     */
    _checkSize: function (isPortrait, callback) {
        let screenWidth = window.innerWidth;
        let screenHeight = window.innerHeight;

        let nowIsPortrait = screenWidth < screenHeight;
        if (nowIsPortrait !== isPortrait) {
            // 代表現在的方向跟要的方向不一樣
            cc.view.setResizeCallback(() => {
                this._checkSize(isPortrait, callback);
            });
        } else {
            // 設定現在的轉向
            cc.view.setOrientation(isPortrait ? cc.ORIENTATION_PORTRAIT : cc.ORIENTATION_LANDSCAPE);

            if (isPortrait) {
                // 直向
                let width = this.PORTRAIT_MIN_SIZE.width;
                let height = screenHeight / (screenWidth / width);
                if (height > this.PORTRAIT_MAX_SIZE.height)
                    height = this.PORTRAIT_MAX_SIZE.height;
                else if (height < this.PORTRAIT_MIN_SIZE.height)
                    height = this.PORTRAIT_MIN_SIZE.height;
                cc.view.setDesignResolutionSize(width, height, cc.ResolutionPolicy.SHOW_ALL);
            } else {
                // 橫向
                let height = this.LANDSCAPE_MIN_SIZE.height;
                let width = screenWidth / (screenHeight / height);
                if (width > this.LANDSCAPE_MAX_SIZE.width)
                    width = this.LANDSCAPE_MAX_SIZE.width;
                else if (width < this.LANDSCAPE_MIN_SIZE.width)
                    width = this.LANDSCAPE_MIN_SIZE.width;
                cc.view.setDesignResolutionSize(width, height, cc.ResolutionPolicy.SHOW_ALL);
            }

            // 砍掉提示畫面
            let notificationNode = cc.director.getNotificationNode();
            if (notificationNode) {
                let hintView = notificationNode.getChildByTag(this.HINT_VIEW_TAG);
                if (hintView)
                    hintView.removeFromParent();
            }

            // 清掉callback
            cc.view.setResizeCallback(undefined);

            // 重新設定多出來的寬高
            JSConfigReset();

            // callback
            callback && callback();
        }
    },
};

/**
 * 轉向提示畫面
 */
var GSBrowserOrientationHintView = class extends cc.Layer {
    /**
     * @param {boolean} isToPortrait 帶是否要轉向直向
     */
    constructor(isToPortrait) {
        super();

        // 現在遊戲的content scale
        let resolutionSize = cc.view.getDesignResolutionSize();
        let baseCSF = (resolutionSize.width > 1000 || resolutionSize.height > 1000) ? 2 : 1;

        // 背景色
        let bgColor = new cc.LayerColor(cc.color(0, 0, 0, 180), cc.winSize.width, cc.winSize.height);
        this.addChild(bgColor);

        // 加一個檔Touch的
        let dummyTouch = new DummyTouchLayer(cc.winSize);
        this.addChild(dummyTouch);

        // 容器 因為轉向要顯示的畫面還需要看原始的畫面 透過此容器來多做一層旋轉
        let container = new cc.Layer();
        this.addChild(container);
        let nowIsPortrait = cc.view.getOrientation() === cc.ORIENTATION_PORTRAIT;
        if (nowIsPortrait === isToPortrait)
            container.setRotation(-90);

        // Spine動畫
        let basePath = GS.relocatePath || window.location.href.substring(0, window.location.href.lastIndexOf("/"));
        let spineFile = basePath + "/res/html/ani_phone_turn";
        GS.loadSpine(spineFile, () => {
            if (this.__isDestroyed)
                return;

            var aniSpine = new sp.SkeletonAnimation(spineFile + ".json", spineFile + ".atlas", 0.25);
            aniSpine.setPosition(JSScreenMidPos);
            aniSpine.setAnimation(0, isToPortrait ? "ani_01" : "ani_02", false);
            container.addChild(aniSpine);

            aniSpine.setCompleteListener(() => {
                aniSpine.runAction(cc.sequence(
                    cc.delayTime(0.9),
                    cc.callFunc(() => aniSpine.setAnimation(0, isToPortrait ? "ani_01" : "ani_02", false))
                ));
            });
        });

        // 文字
        let osHint = cc.sys.os === cc.sys.OS_ANDROID ? "小提醒：請記得開啟自動旋轉功能" : "小提醒：請記得解鎖螢幕旋轉功能";
        let label = new cc.LabelTTF(JSStringUtility.format("將您的畫面旋轉為%s，才能進入遊玩\n%s", isToPortrait ? "直向" : "橫向", osHint), JSFontBoldName, 16 * baseCSF, cc.size(0, 0), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        if (isToPortrait)
            label.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 110 * baseCSF);
        else
            label.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 120 * baseCSF);
        label.setRotation(isToPortrait ? 0 : 0);
        container.addChild(label);
    }

    onEnter() {
        super.onEnter();

        // 關掉Loading的Timeout
        GS.dispatchCustomEvent("NotifyLoadingViewNeedTimeout", false);
    }

    onExit() {
        super.onExit();

        // 開啟Loading的Timeout
        GS.dispatchCustomEvent("NotifyLoadingViewNeedTimeout", true);
    }
}