/**
 * 用在抓圖存在相簿裡 對應到原生的 GSCaptureToAlbum
 * callback = function (isSuccess, errorType)
 * isSuccess 是否成功
 * errorType 錯誤類型 GSCaptureToAlbumErrorType
 */

var GSCaptureToAlbumWrapper = {};

var GSCaptureToAlbumErrorType = {
    NONE: 0,            // 無
    PERMISSION: 1,      // 權限不足
    WRITE: 2,           // 寫入失敗
};

(function () {
    var isNative = cc.sys.isNative;

    /**
     * 抓取是否有權限
     */
    GSCaptureToAlbumWrapper.havePermission = function () {
        return isNative && GSCaptureToAlbum.havePermission();
    };

    /**
     * 去要求權限
     * @param callback      就Callback
     */
    GSCaptureToAlbumWrapper.requestPermission = function (callback) {
        isNative && GSCaptureToAlbum.requestPermission(callback);
    };

    /**
     * 抓現在遊戲的畫面存在相簿
     * @param callback      就Callback
     */
    GSCaptureToAlbumWrapper.captureScreen = function (callback) {
        isNative && GSCaptureToAlbum.captureScreen(callback);
    };

    /**
     * 把圖片檔案存在相簿
     * @param filename      圖片檔名
     * @param callback      就Callback
     * @param removeFile    存完後是否要砍掉檔案
     */
    GSCaptureToAlbumWrapper.saveToAlbum = function (filename, callback, removeFile = false) {
        isNative && GSCaptureToAlbum.saveToAlbum(filename, callback, removeFile);
    };
}.call((window || module || {})));