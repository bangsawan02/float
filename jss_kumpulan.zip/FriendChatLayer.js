/**
 *  聊天頁面
 *  輸入聊天內容 & 查看聊天記錄
 */

var FriendChatLayer = cc.Layer.extend({
    ctor: function (isGameGaple) {
        this._super();

        var width = ChatRoomLayer.WIDTH;

        this._isGameGaple = isGameGaple;

        cc.spriteFrameCache.addSpriteFrames("game/emoticons.plist", "game/emoticons.png");

        // 聊天視窗大小
        var chatSize = this._chatSize = cc.size(FriendChatLayer.WIDTH, 220 + JSScreenBonusHeight);
        var posY = 275 + JSScreenBonusHeight;
        var tipLabelPos = cc.p(94, 18);
        var tableViewPos = cc.p(7, 35);
        var tipLabelFontSize = 11;

        if (isGameGaple) {
            chatSize = this._chatSize = cc.size(FriendChatLayer.GAPLE_WIDTH, ChatRoomLayer.GAPLE_HEIGHT - 55);
            posY = ChatRoomLayer.GAPLE_HEIGHT + 20;

            var bgSprite = new ccui.Scale9Sprite("gaple_bg_black.png");
            bgSprite.setPreferredSize(cc.size(186, 162));
            bgSprite.setPosition(101, 126);
            bgSprite.setOpacity(127);
            this.addChild(bgSprite);

            // Menu
            var menu = new cc.Menu();
            menu.setPosition(0, 0);
            this.addChild(menu, 3);

            // 左上返回按鈕
            var backNodes = ButtonUtility.createSingleScale9SpriteNodes("gaple_pic_back.png");
            var backItem = new cc.MenuItemSprite(backNodes[0], backNodes[1], null, this._backItemClicked, this);
            backItem.setScaleX(1.2);
            backItem.setPosition(17, posY - 3);
            menu.addChild(backItem);

            // 標題
            var titleLabel = this._titleLabel = new GSAutoSizeLabel("", JSFontBoldName, 12, cc.size(145, 40), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
            titleLabel.setPosition(width / 2 + 17, posY - 2);
            titleLabel.resizeToFit(5);
            this.addChild(titleLabel);

            tipLabelPos = cc.p(95, 55);
            tableViewPos = cc.p(15, 60);
            tipLabelFontSize = 9;
        } else {
            // 加一條線
            var lineSprite = new cc.Sprite("#lobby_white_line.png");
            lineSprite.setScaleY(0.8);
            lineSprite.setPosition(32, posY - 2);
            this.addChild(lineSprite);

            // Menu
            var menu = new cc.Menu();
            menu.setPosition(0, 0);
            this.addChild(menu, 3);

            // 左上返回按鈕
            var backNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_pic_arrow.png");
            var backItem = new cc.MenuItemSprite(backNodes[0], backNodes[1], null, this._backItemClicked, this);
            backItem.setScaleX(1.3);
            backItem.setPosition(17, posY);
            menu.addChild(backItem);

            // 標題
            var titleLabel = this._titleLabel = new GSAutoSizeLabel("", JSFontBoldName, 12, cc.size(145, 40), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
            titleLabel.setPosition(width / 2 + 17, posY);
            titleLabel.resizeToFit(5);
            this.addChild(titleLabel);
        }

        // 聊天視窗
        this._totalCellCount = 0;
        this._tableViewHeight = chatSize.height;
        this._insertHeight = chatSize.height * 2;
        var tableView = this._tableView = new cc.TableView(this, cc.size(chatSize.width, chatSize.height));
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setPosition(tableViewPos);
        this.addChild(tableView);

        if (PushScene.isLobby) {
            // 輸入聊天訊息
            var editBoxSize = cc.size(123, 26);
            var editboxSprite1 = new ccui.Scale9Sprite("select_03.png");
            var editboxSprite2 = new ccui.Scale9Sprite("select_03.png");
            editboxSprite2.setColor(JSColor.GRAY);
            var inputEditBox = this._inputEditBox = new cc.EditBox(editBoxSize, editboxSprite1, editboxSprite2);
            inputEditBox.setAnchorPoint(1, 0.5);
            inputEditBox.setPosition(155, 18);
            inputEditBox.setFontColor(JSColor.BLACK);
            inputEditBox.setFontName(JSFontName);
            inputEditBox.setPlaceholderFontName(JSFontName);
            inputEditBox.setPlaceHolder(LocalizedString.Friend("說些什麼吧"));
            inputEditBox.setReturnType(cc.KEYBOARD_RETURNTYPE_DONE);
            inputEditBox.setInputFlag(cc.EDITBOX_INPUT_FLAG_SENSITIVE);
            inputEditBox.setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE);
            inputEditBox.setCascadeOpacityEnabled(true);
            this.addChild(inputEditBox);

            // 貼圖按鈕
            var itemNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_07.png", cc.size(27, 27), "#chat_btn_icon_emoticons.png");
            var emoticonsItem = this._emoticonsItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._emoticonsItemClicked, this);
            emoticonsItem.setPosition(18, 18);
            menu.addChild(emoticonsItem);

            // 傳送訊息
            var itemNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_01.png", cc.size(27, 27), "#chat_btn_icon_send.png");
            var sendItem = this._sendItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._sendItemClicked, this);
            sendItem.setPosition(170, 18);
            menu.addChild(sendItem);
        } else {
            // 遊戲中不能聊天
            var tipLabel = new cc.LabelTTF(LocalizedString.Friend("牌局中不可聊天哦"), JSFontName, tipLabelFontSize);
            tipLabel.setPosition(tipLabelPos);
            this.addChild(tipLabel);
        }

        // 提示
        var loadChatLabel = this._loadChatLabel = new cc.LabelTTF(LocalizedString.Friend("往下拉看更多"), JSFontName, 11);
        loadChatLabel.setAnchorPoint(0.5, 1);
        loadChatLabel.setPosition(87, 0);
        loadChatLabel.setVisible(false);
        loadChatLabel.setOpacity(178);
        this._tableView.addChild(loadChatLabel);

        // 初始化聊天室的參數
        this._clean();

        // 加loading
        this.showLoading(true);

        // 刷新頁面
        this.refreshView();

        GS.addListener("NotifyUpdateFriendChatList", this.notifyUpdateFriendChatList.bind(this), this);
    },

    // AndroidBack
    keyBackPressed: function () {
        // 送離開聊天室
        DataModal.chatRoomData.sendHaveReadCmd(0);
    },

    onExit: function () {
        // 送離開聊天室
        DataModal.chatRoomData.sendHaveReadCmd(0);

        this._super();
    },

    /**
     * 刷新聊天室
     */
    refreshView: function () {
        var data = DataModal.chatRoomData;
        // 取出玩家的聊天記錄
        var UID = this._UID = data.friendChatUID;
        var chatParam = this._charParam = data.friendChatParam[UID];

        if (!chatParam)
            return;

        // 聊天記錄清單
        this._chatList = chatParam.chatList;

        // 好友的暱稱
        this._titleLabel.setString(data.friendChatNickname);

        // 訊息數量
        this._totalCellCount = this._chatList.length;

        // 目前load出最舊的訊息編號
        if (this._totalCellCount > 0)
            this._chatHistoryNum = this._chatList[0].serialNum;

        // 更新是否還能load歷史紀錄
        this._isCanLoadHistory = this._charParam.isCanLoadHistory;

        if (this._isMoveBottom) {
            // 滑到最下面
            this._tableView.reloadData(true);
            // 記錄滑動到哪邊要更新訊息的位置
            this._offsetY = this._tableView.getContentOffset().y - 30;
            this._scrollTableView(0);
        } else {
            // load歷史紀錄 滑到之前的位置上
            var beforeOffsetY = this._offsetY + 30;
            this._tableView.reloadData(true);
            // 記錄滑動到哪邊要更新訊息的位置
            this._offsetY = this._tableView.getContentOffset().y - 30;
            this._scrollTableView(beforeOffsetY);
        }

        // 往下滑可以load更多提示
        this._loadChatLabel.setVisible(this._isCanLoadHistory);
        if (this._isCanLoadHistory)
            this._loadChatLabel.setPositionY(this._tableView.getContainer().height);

        // 滑到最下面
        this._isMoveBottom = true;
        // 打開可以滑動
        this._isCanScroll = true;

        // 關loading
        this.showLoading(false);
    },

    /**
     * 清除關於聊天頁面的設定
     * @private
     */
    _clean: function () {
        // 可不可以滑動
        this._isCanScroll = true;

        // 要不要滑到最下面
        this._isMoveBottom = true;

        // 這次load出的訊息最舊的
        this._chatHistoryNum = 0;

        // 是否還可以load歷史訊息
        this._isCanLoadHistory = false;

        // 存放聊天訊息
        this._chatList = [];

        // 清除輸入訊息(遊戲內沒有輸入框)
        if (this._inputEditBox)
            this._inputEditBox.setString("");
    },


    /**
     * 更新聊天訊息（從最後新增新的訊息 or 更新某一筆的訊息)
     * @param updateIndex 要更新的最後一個index
     */
    _updateTableView: function (updateIndex) {
        // 好友聊天記錄
        var friendChatParam = DataModal.chatRoomData.friendChatParam[this._UID];
        if (!friendChatParam)
            return;

        // 更新前的cell數量
        var num = this._totalCellCount;

        // 更新聊天資料
        this._chatList = friendChatParam.chatList;

        // 更新cell數量
        this._totalCellCount = this._chatList.length;

        // 需要新增幾個cell
        var addCellCount = (num === this._totalCellCount) ? 0 : this._totalCellCount - updateIndex;

        // 因為會滑到最後 先設定不可滑
        this._isCanScroll = false;

        if (addCellCount > 0) {
            this._tableView.reloadData(false);
            this._offsetY = this._tableView.getContentOffset().y - 30;

            // 更新了tableView的尺寸 要調整"往下拉看更多"文字的位置
            if (this._isCanLoadHistory)
                this._loadChatLabel.setPositionY(this._tableView.getContainer().height);
        } else {
            // 只更新單筆訊息
            this._tableView.updateCellAtIndex(updateIndex);
        }

        // 滑到最後
        this._scrollTableView(0);

        // 開啟可滑動
        this._isCanScroll = true;
    },

    /**
     * 滑動的位置
     * @param offsetY 滑動到哪邊
     * @private
     */
    _scrollTableView: function (offsetY) {
        if (this._tableViewHeight < this._tableView.getContainer().height)
            this._tableView.setContentOffset(cc.p(0, offsetY));
    },

    /**
     * show loading 遮住聊天頁面
     * 10秒內沒有回應loading會自動消失
     */
    showLoading: function (isShow) {
        if (this._loadingNode) {
            if (isShow) {
                this._loadingSprite.start();
                this._loadingNode.setVisible(true);
                // 10秒沒回應關閉loading
                this._loadingNode.runAction(cc.sequence(
                    cc.delayTime(10),
                    cc.callFunc(() => {
                        this._loadingNode.setVisible(false);
                    })
                ));
            } else {
                this._loadingNode.stopAllActions();
                this._loadingNode.setVisible(false);
            }
            return;
        }

        if (!isShow)
            return;

        var loadingNode = this._loadingNode = new cc.Node();
        this.addChild(loadingNode, 100);

        var height = JSVisibleSize.height + 5;
        var width = ChatRoomLayer.WIDTH + 2;
        var pos = cc.p(0, 0);

        if (this._isGameGaple) {
            height = ChatRoomLayer.GAPLE_HEIGHT - 10;
            width = ChatRoomLayer.GAPLE_WIDTH - 6;
            pos = cc.p(0, 39);
        }

        // 背景色
        var mask = new cc.LayerColor(cc.color(0, 0, 0, 150), width, height);
        mask.setPosition(pos);
        loadingNode.addChild(mask);

        // 加一層UI檔Touch
        var dummyTouch = new DummyTouchLayer(cc.size(width, height));
        dummyTouch.setPosition(mask.getPosition());
        loadingNode.addChild(dummyTouch);

        // 加一個Loading
        var loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(width / 2 + pos.x, height / 2 + pos.y);
        loadingSprite.start();
        loadingNode.addChild(loadingSprite);

        // 10秒沒回應關閉loading
        this._loadingNode.runAction(cc.sequence(
            cc.delayTime(10),
            cc.callFunc(() => {
                this._loadingNode.setVisible(false);
            })
        ));
    },

    /**
     * tableview
     */
    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        if (cell == null) {
            cell = new FriendChatCell();
            cell.setAnchorPoint(0, 0);
        }
        cell.refreshCell(this._chatList[idx], idx === 0 && this._isCanLoadHistory);

        return cell;
    },

    numberOfCellsInTableView: function (table) {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function (table, idx) {
        var cellHeight = (this._chatList[idx]) ? this._chatList[idx].cellHeight : 0;
        return cc.size(this._chatSize.width, cellHeight);
    },

    /**
     * 滑動時會呼叫
     * @param view
     */
    scrollViewDidScroll: function (view) {
        // 往上滑要load聊天的歷史紀錄
        if (!this._isCanScroll || !this._isCanLoadHistory)
            return;

        if (this._offsetY > view.getContentOffset().y) {
            // 取回之前的歷史紀錄
            DataModal.chatRoomData.sendFriendChatListCmd(this._chatHistoryNum, true);
            this.showLoading(true);
            this._isMoveBottom = false;
            this._isCanScroll = false;
        }
    },

    /**
     * 點擊貼圖按鈕
     */
    _emoticonsItemClicked: function () {
        if (this._emoticonsLayer)
            this._emoticonsLayer.setVisible(true);
        else {
            this._emoticonsLayer = new ChatRoomEmoticonsLayer();
            this.addChild(this._emoticonsLayer, 10);
        }
        this._isMoveBottom = true;
    },

    /**
     * 點擊送出按鈕
     */
    _sendItemClicked: function () {
        // 送出訊息
        var inputStr = this._inputEditBox.getString();
        var len = inputStr.length;
        if (len <= 0)
            return;

        if (len > 50)
            inputStr = inputStr.substr(0, 50);

        // 送出訊息
        DataModal.chatRoomData.sendFriendChatMessageCmd(ChatRoomData.MessageType.Label, inputStr);

        // 清空
        this._inputEditBox.setString("");
        this._isMoveBottom = true;
        this._isCanScroll = false;
    },

    /**
     * 返回按鈕點擊
     */
    _backItemClicked: function () {
        // 送已讀
        DataModal.chatRoomData.sendHaveReadCmd(0);

        // 清除聊天頁面的資料設定
        DataModal.chatRoomData.cleanChatUser();

        // 清除UI的設定
        this._clean();

        // 離開聊天畫面時回到清單確認清單的小紅點
        DataModal.chatRoomData.sendFriendChatRoomListCmd();

        var obj = {
            type: ChatRoomPageType.ROOM_LIST
        };
        GS.dispatchCustomEvent("NotifyShowChatRoomLayerByPageType", obj);
    },

    /**
     * 通知更新聊天的資料
     */
    notifyUpdateFriendChatList: function (event) {
        if (event) {
            var updateIndex = event.getUserData();

            // 可視範圍的cell數量不夠多用insert插入會造成cell排序混亂所以用reload去處理
            // 所以這邊判斷目前有的cell數量夠不夠多
            if (updateIndex < 0 || this._tableView.getContainer().height < this._insertHeight) {
                // 刷新整個tableView
                this.refreshView();
            } else {
                // 將cell插入最後面
                this._updateTableView(updateIndex);
            }
        }
    }
});

FriendChatLayer.WIDTH = 173;

// Gaple系列牌桌用
FriendChatLayer.GAPLE_WIDTH = 173;