/**
 * 通行證 - 離開前提示 dialog
 * ```
 * config: {
 *     messageDialogBgFileName: "",                     // dialog 背景圖
 * },
 * param: {
 *     dialogSize: cc.size(0, 0),                       // dialog size
 *     title: [] || "",                                 // 標題設定，可直接收字串或陣列（陣列請參照：BasePassRichTextNode）
 *     titleColor: cc.color(0, 0, 0),                   // 標題顏色
 *     contentBgFileName: "",                           // 獎勵背景圖
 *     contentOpacity: 255,                             // 獎勵背景圖透明度
 *     contentTitleText: undefined,                     // 獎勵標題文字
 *
 *     leaveParam: {                                    // 離開前提示資料
 *         count: 0,                                    // chip count
 *         picFileName: 5057,                           // 獎勵圖
 *     },
 *     chipCount: 0,                                    // chip count
 *     picFileName: 5057,                               // 獎勵圖
 *
 *     purchaseParam: {                                 // 儲值資料
 *         buttonMsg: "",
 *         tipMsg: "",
 *         productParam: "",
 *     },
 * }
 * ```
 */
var BasePassLeaveNoticeDialog = BaseDialogLayer.extend({
    ctor: function (config, param) {
        this._super();

        this.key = "BasePassLeaveNoticeDialog";
        this._config = config;
        this._param = param;

        let bgFileName = config.messageDialogBgFileName || "luxyPass_bg_frame.png";
        let dialogSize = param.dialogSize || cc.size(365, 240);

        let aniLayer = this._animationLayer;

        // 背景
        let bgSprite = new ccui.Scale9Sprite(bgFileName);
        bgSprite.setPreferredSize(dialogSize);
        bgSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 7);
        aniLayer.addChild(bgSprite);

        this._createTitle();
        this._createContentBg();
        this._createContentTitle();
        this._createContentView();
        this._createPurchaseButton();

        // 關閉按鈕
        let closeButton = this._closeButton = new Texas_CloseButton();
        closeButton.addTouchUpInsideAction(this.keyBackPressed, this);
        closeButton.setPosition(JSScreenMidPos.x + dialogSize.width / 2 - 12, JSScreenMidPos.y + dialogSize.height / 2 - 18);
        aniLayer.addChild(closeButton, 12);
    },

    /**
     * 建立標題
     * 你可以自行繼承以建立自己的標題
     * @protected
     */
    _createTitle: function () {
        let titleConfig = this._param.title;
        let titleColor = this._param.titleColor || JSColor.WHITE;
        let titleConfigType = JSCodeUtility.checkType(titleConfig);
        let titlePosition = cc.p(JSScreenMidPos.x, JSScreenMidPos.y + 79);
        switch (titleConfigType) {
            case JSTYPE.STRING:
                titleConfig = [[{
                    type: BasePassRichTextNode.Type.TEXT,
                    text: titleConfig,
                    fontSize: 16,
                    fontColor: titleColor,
                }]];
                break;
            case JSTYPE.ARRAY:
                titleConfig.forEach(row => row.forEach(e => {
                    if (e.type === BasePassRichTextNode.Type.TEXT) {
                        e.fontSize = e.fontSize || 16;
                        e.fontColor = e.fontColor || titleColor;
                    }
                }));
                break;
        }

        let richTextNode = new BasePassRichTextNode(titleConfig);
        richTextNode.setPosition(titlePosition);
        this._animationLayer.addChild(richTextNode);
    },

    /**
     * 建立內容背景
     * 你可以自行繼承以建立自己的內容背景
     * @protected
     */
    _createContentBg: function () {
        let contentBgFileName = this._param.contentBgFileName || "luxyPass_pic_frame_07.png";
        let contentBgOpacity = this._param.contentOpacity || 127;
        let contentBgSprite = new ccui.Scale9Sprite(contentBgFileName);
        contentBgSprite.setPreferredSize(cc.size(310, 122));
        contentBgSprite.setOpacity(contentBgOpacity);
        contentBgSprite.setPosition(JSScreenMidPos.x, 144 + JSScreenBonusHalfHeight);
        this._animationLayer.addChild(contentBgSprite);
    },

    /**
     * 建立內容標題
     * 你可以自行繼承以建立自己的內容標題
     * @protected
     */
    _createContentTitle: function () {
        let contentTitleText = this._param.contentTitleText;
        let contentTitleFontSize = this._param.contentTitleFontSize || 16;
        let contentTitle = new GSRichTextNode(contentTitleText, JSFontName, contentTitleFontSize);
        contentTitle.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 43);
        this._animationLayer.addChild(contentTitle);
    },

    _createContentView: function () {
        let leaveParam = this._param.leaveParam || {
            count: this._param.chipCount || 0,
            picFileName: this._param.picFileName || 5057,
        };
        // 數字圖
        let moneyNumberNode = new GSSpriteNumberNode({
            number: leaveParam.count,
            numStr: "#luxyPass_num_",
            spW: 20,
            addDot: true,
            dotW: 8,
            dotH: 10,
            dotStr: ",",
            symbolName: "#luxyPass_pic_coin.png",
            symbolLoc: GSSpriteNumberNode.SymbolLoc.FRONT,
            symbolScale: 0.6,
        });
        moneyNumberNode.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 12);
        this._animationLayer.addChild(moneyNumberNode);

        // 加號
        let addSprite = new cc.Sprite("#luxyPass_num_+.png");
        addSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 19);
        this._animationLayer.addChild(addSprite);

        let autoLayout = new GSAutoLayoutNode();
        autoLayout.setSpace(4);
        autoLayout.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 42);
        this._animationLayer.addChild(autoLayout);

        // 下面的內文
        let contentLabel2 = new cc.LabelTTF(LocalizedString.BasePass("豐富獎勵"), JSFontName, 12);
        autoLayout.addChild(contentLabel2);

        let rewardNode = new cc.Node();
        rewardNode.setContentSize(cc.size(52, 38));

        // 獎勵圖片 印尼：加入 KL / RP 圖、越南：只有寶石圖
        let picArray = [ProfileData.getIsKoinLuxy() ? 7098 : 7097];
        picArray.unshift(leaveParam.picFileName);
        let picPosArray = [cc.p(16, 21.5), cc.p(35, 17)];
        for (let i = 0; i < 2; i++) {
            let imageName = picArray[i] + ".png";
            let baseUrl = "https://g.mwsrv.com/19_60/store/iapp/goods/" + imageName;
            let savePath = JSWriteablePath + "basePass/" + imageName;
            let itemNode = new GSDownloadSprite("", baseUrl, savePath);
            itemNode.setTargetSize(cc.size(32, 32));
            itemNode.setPosition(picPosArray[i]);
            rewardNode.addChild(itemNode);
        }

        autoLayout.addChild(rewardNode);
    },

    /**
     * 建立購買按鈕
     * 你可以自行繼承以建立自己的購買按鈕
     * @protected
     */
    _createPurchaseButton: function () {
        let purchaseButton = this._purchaseButton = new BasePassPurchaseButton({
            ticketIconFileName: this._config.ticketIconFileName,
            isUseOldBtnStyle: this._config.isUseOldBtnStyle,
            purchaseBtnIsShowTicketIcon: true,
            purchaseBtnIsShowDiscount: true,
            purchaseBtnStyle: this._config.purchaseBtnStyle,
            purchaseBtnOnClick: this._purchaseClicked.bind(this)
        });
        purchaseButton.setPosition(JSScreenMidPos.x, 57 + JSScreenBonusHalfHeight);
        purchaseButton.refreshView(this._param.purchaseParam);
        purchaseButton.playAnimation();
        this._animationLayer.addChild(purchaseButton);
    },

    _purchaseClicked: function (sender) {
        this._param.purchaseBtnOnClick && this._param.purchaseBtnOnClick(sender);

        // 送儲值
        DataModal.purchaseData.goPurchase(sender.productParam);

        // 關閉視窗
        this._closeDialogAnimation();
    },

    // An返回
    keyBackPressed: function () {
        // 送通知關閉通行證畫面
        GS.dispatchCustomEvent("NotifyBasePassCloseDialog");
    },

    getPurchaseBtn: function () {
        return this._purchaseButton;
    }
});
BasePassLeaveNoticeDialog.TitleType = GSEnumHelper({
    TEXT: -1,
    NUMBER_SPRITE: -1,
    WORD_SPRITE: -1,
});