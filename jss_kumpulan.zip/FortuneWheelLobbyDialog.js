/**
 * 9T 衝動儲值_加碼輪盤_儲值後簽到dialog
 *
 * param 簽到資訊
 */

var FortuneWheelLobbyDialog = BaseDialogLayer.extend({
    ctor: function (param) {
        this._super();

        this.key = "FortuneWheelLobbyDialog";

        this._param = param;

        this.loadFileArray = ["lobby/fortuneWheelDialog.plist", "lobby/fortuneWheelDialog.png"];
    },

    onExit: function () {
        this._loadFileDone && cc.spriteFrameCache.removeSpriteFramesFromFile("lobby/fortuneWheelDialog.plist");

        this._super();
    },

    /**
     * 讀取素材完畢
     * @override
     */
    loadFileDone: function () {
        this._super();

        cc.spriteFrameCache.addSpriteFrames("lobby/fortuneWheelDialog.plist", "lobby/fortuneWheelDialog.png");

        var param = this._param;

        var animationLayer = this._animationLayer;

        // 底背景
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(cc.size(420, 230));
        bgSprite.setPosition(JSScreenMidPos);
        animationLayer.addChild(bgSprite);

        // 左邊金幣
        var coinSprite = new cc.Sprite("#fortune_wheel_dialog_coin.png");
        coinSprite.setPosition(JSScreenMidPos.x - 135, JSScreenMidPos.y + 88);
        animationLayer.addChild(coinSprite);

        // 右邊金幣
        coinSprite = new cc.Sprite("#fortune_wheel_dialog_coin.png");
        coinSprite.setPosition(JSScreenMidPos.x + 135, JSScreenMidPos.y + 88);
        coinSprite.setFlippedX(true);
        animationLayer.addChild(coinSprite);

        // 美術字 - 歡迎回來
        var titleSprite = new cc.Sprite("#fortune_wheel_dialog_word_welcomeback.png");
        titleSprite.setScale(1.2);
        titleSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 88);
        animationLayer.addChild(titleSprite);

        // 兩側星光
        for (var i = -1; i < 2; i += 2) {
            var lightSprite = new cc.Sprite("#lobby_pic_star.png");
            lightSprite.setPosition(JSScreenMidPos.x + i * 108, JSScreenMidPos.y + 100);
            lightSprite.setScale(2);
            animationLayer.addChild(lightSprite);
        }

        // 左邊輪盤
        var wheelSprite = new cc.Sprite("#fortune_wheel_dialog_pic_01.png");
        wheelSprite.setPosition(JSScreenMidPos.x - 80, JSScreenMidPos.y + 42);
        animationLayer.addChild(wheelSprite);

        // 訊息內容
        var contentLabel = new GSRichTextNode(param.content, JSFontName, 14);
        contentLabel.setPosition(JSScreenMidPos.x + 30, JSScreenMidPos.y + 42);
        contentLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
        animationLayer.addChild(contentLabel);

        // 箭頭
        var imageText = "";
        var arrowPosX = 0;                                                      // 箭頭圖片偏移的位置
        var rewardArraySize = param.rewardArray.length;                         // 簽到狀態總數量
        var firstArrowPosX = JSScreenMidPos.x - rewardArraySize / 2 * 33;       // 起始箭頭位置
        var margin = 38;                                                        // 箭頭和小空隙

        param.rewardArray.forEach((status, index) => {
            if (index === 0) {
                imageText = "#koinLuxy_pic_process_02.png";
                arrowPosX = firstArrowPosX;
            } else {
                imageText = "#koinLuxy_pic_process_02.png";
                arrowPosX = firstArrowPosX + (index * margin);
            }

            // 箭頭圖
            var arrowSprite = new cc.Sprite(imageText);
            arrowSprite.setPosition(arrowPosX, JSScreenMidPos.y);
            animationLayer.addChild(arrowSprite);

            // 天數
            var dayLabel = new cc.LabelTTF(JSStringUtility.format("Hari ke %d", index + 1), JSFontName, 8);
            dayLabel.setPosition(arrowPosX, JSScreenMidPos.y - 18);
            animationLayer.addChild(dayLabel, 2);

            if (status === 0) {
                arrowSprite.setSpriteFrame("koinLuxy_pic_process_01.png");
                dayLabel.setOpacity(128);
            } else {
                var signSprite = new cc.Sprite(status === 1 ? "#lobby_pic_check_02.png" : "#koinLuxy_pic_red_x.png");
                signSprite.setScale(0.8);
                signSprite.setPosition(arrowPosX, JSScreenMidPos.y);
                animationLayer.addChild(signSprite);
            }
        });

        // 下方光暈
        var bgLightDownSprite = this._bgLightDownSprite = new cc.Sprite("#lobby_pic_light_gold.png");
        bgLightDownSprite.setAnchorPoint(0.5, 0);
        bgLightDownSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 50);
        bgLightDownSprite.setScale(1.1);
        bgLightDownSprite.setFlippedY(true);
        animationLayer.addChild(bgLightDownSprite);

        // 倒數時間
        if (param.countDownTime) {
            var timeLabel = new GSTimeLabel("", JSFontName, 14);
            timeLabel.setFormat("Hitungan mundur pengambilan selanjutnya：\n%hh:%mm:%ss");
            timeLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 48);
            timeLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            timeLabel.countdownSeconds(param.countDownTime, () => {
                this._closeDialogAnimation();
            });
            animationLayer.addChild(timeLabel);
        }

        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        animationLayer.addChild(menu);

        // 關閉按鈕
        var closeBtnNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_circle_04.png", null, "#lobby_btn_pic_window_x.png");
        var closeBtn = new cc.MenuItemSprite(closeBtnNodes[0], closeBtnNodes[1], this._closeDialogAnimation, this);
        closeBtn.setPosition(JSScreenMidPos.x + 205, JSScreenMidPos.y + 110);
        menu.addChild(closeBtn);

        // 馬上玩
        var quickBtnNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", cc.size(120, 30), param.btnText, 16, JSColor.BLACK);
        var quickBtn = new cc.MenuItemSprite(quickBtnNodes[0], quickBtnNodes[1], () => {
            this._closeDialogAnimation();

            // 去馬上玩
            GS.dispatchCustomEvent("NotifyGoQuickPlay");
        }, this);
        quickBtn.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 84);
        menu.addChild(quickBtn);
    },
});