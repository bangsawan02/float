/**
 * v5.5.2 偵測大小變化的label
 * 移植自中文德撲 v15.8 偵測大小變化的label
 * created by Lichieh.
 */

var BaseDetectSizeChangeLabelNode = cc.Node.extend({
    ANIMATION_TAG: 23453,
    ctor: function (title, fontName, fontSize, size) {
        this._super();

        this.setContentSize(size);
        // 整個範圍大小, 也是clipping大小, 先記起來
        this._size = size;

        var clipNode = this._clipNode = this._generateClipContainer(size);
        clipNode.setCascadeColorEnabled(true);
        clipNode.setCascadeOpacityEnabled(true);
        this.addChild(clipNode);

        // 內文本體
        var label = this._label = new cc.LabelTTF(title, fontName, fontSize);
        clipNode.addChild(label);

        // 有字就給他更新一下
        if (title)
            this.onSizeChange();
    },

    /**
     * 取得label
     */
    getLabel: function () {
        return this._label;
    },

    /**
     * 建立label會放的地方, 複寫之後也可以是scrollView
     */
    _generateClipContainer: function (size) {
        // 用上面的大小創個clipping
        var stencil = new cc.LayerColor(cc.color(255, 255, 255, 255), size.width, size.height);
        stencil.setPosition(-size.width / 2, -size.height / 2);

        return new cc.ClippingNode(stencil);
    },

    /**
     * 設定文字
     * @param {String} str
     */
    setString: function (str) {
        this._label.setString(str);
        this.onSizeChange();
    },

    onSizeChange: function () {
        /*override*/
    }
});