/**
 * 測試資料
 */

var DebugTestData = cc.Class.extend({
    ctor: function () {
        // 是否強制白帳號
        this.isForceWhiteAccount = false;

        // 牌桌是否顯示Debug功能
        this.isShowGameDebug = false;

        // 是否開啟無限轉功能
        this.isEnableSpinInfinity = false;

        // 是否顯示測試資訊
        this.isShowTestInfo = JSDebugMode;

        // 測試區時間
        this.serverTime = 0;

        // 目前是否顯示獎圖編號，預設是關閉
        this._isShowSymbolValue = GS.localStorage.getItem("DebugAutoTestShowSymbolValue", "0", true) !== "0";

        // 目前是否顯示黑幕，預設是開啟
        this._isShowBlackMask = GS.localStorage.getItem("DebugAutoTestShowBlackMask", "1", true) !== "0";

        // 註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            "sync_time": this.cmd_sync_time,
        });
    },

    /**
     * 砍掉Data
     */
    destroyData: function () {
        DataProcess.removeSocketKeyDispatch(this);
    },

    // 清掉資料
    clean: function () {
        // server傳來的測試區時間
        this.serverTime = 0;

        // 收到 server傳來的測試區時間cmd 的時間
        this.serverTimeSocketTime = 0;
    },

    // 抓取測試區時間
    getServerTime: function () {
        if (!this.serverTime)
            return 0;

        return this.serverTime + (JSCodeUtility.getNowTime() - this.serverTimeSocketTime);
    },

    /**
     * 抓取是否是否在測試區
     */
    isTestArea: function () {
        // 有設定測試區 且 是native或是JSDebugMode
        return GS.testPeople && (cc.sys.isNative || JSDebugMode);
    },

    /**
     * 獎圖編號
     */

    // 設定是否顯示獎圖編號
    setIsShowSymbolValue: function (showString) {
        GS.localStorage.setItem("DebugAutoTestShowSymbolValue", showString, true);
        this._isShowSymbolValue = showString !== "0";
    },

    // 獲取是否顯示獎圖編號
    getIsShowSymbolValue: function () {
        return this._isShowSymbolValue;
    },

    /**
     * 黑幕
     */

    // 設定是否顯示黑幕
    setIsBlackMask: function (showString) {
        GS.localStorage.setItem("DebugAutoTestShowBlackMask", showString, true);
        this._isShowBlackMask = showString !== "0";
    },

    // 獲取是否關閉黑幕
    getIsBlackMask: function () {
        return this._isShowBlackMask;
    },

    /**
     * Socket
     */

    /**
     * 收到 測試區時間 資訊
     * S -> C sync_time {"time":"1725604306"}
     */
    cmd_sync_time: function (key, value) {
        var jsonValue = JSON.parse(value);

        // 測試區時間
        this.serverTime = JSCodeUtility.getIntValue(jsonValue["time"]);

        // 收到測試區時間的時間
        this.serverTimeSocketTime = JSCodeUtility.getNowTime();
    },
});