/**
 *  百家樂的開獎紀錄
 */

var BaccaratRecordLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 用來移動的Node
        var mainNode = this._mainNode = new cc.Node();
        mainNode.setPosition(JSScreenMidPos.x, JSVisibleSize.height + 96);
        this.addChild(mainNode);

        // 背景
        var recordSize = cc.size(JSVisibleSize.width, 96);
        var recodeMidPos = cc.p(recordSize.width / 2, recordSize.height / 2);
        var bgSprite = new ccui.Scale9Sprite("bcr_record_bg.png");
        bgSprite.setPreferredSize(recordSize);
        mainNode.addChild(bgSprite);

        // 點的大小
        var pointSize = this._pointSize = cc.size(15, 13);

        // 左邊的ScrollView
        var scrollLayerL = new cc.Layer();
        var scrollSizeL = cc.size(342 + JSScreenBonusWidth, recordSize.height);
        var scrollPosL = cc.p(-recodeMidPos.x + 11, -recodeMidPos.y + 10);
        var scrollViewL = this._scrollViewL = new cc.ScrollView(scrollSizeL, scrollLayerL);
        scrollViewL.setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
        scrollViewL.setPosition(scrollPosL);
        mainNode.addChild(scrollViewL);

        var contentWidthL = 0;
        for (var i = 0; i < 78; i++) {
            for (var y = 0; y < 6; y++) {
                var bgSprite = this._bgSprite = new cc.Sprite("#bcr_point0.png");
                bgSprite.setPosition(this._getPointPosition(i, y));
                bgSprite.setOpacity(50);
                scrollLayerL.addChild(bgSprite);
            }

            contentWidthL += pointSize.width;
        }
        scrollViewL.setContentSize(cc.size(contentWidthL, scrollSizeL.height));
        scrollViewL.setContentOffset(cc.p(0, 0));

        // 創一個之後放點數用的Node
        var pointNodeL = this._pointNodeL = new cc.Node();
        scrollLayerL.addChild(pointNodeL);


        // 右邊的
        var scrollLayerR = new cc.Layer();
        var scrollSizeR = cc.size(142, recordSize.height);
        var scrollPosR = cc.p(scrollPosL.x + scrollSizeL.width + 5, scrollPosL.y);
        var scrollViewR = this._scrollViewR = new cc.ScrollView(scrollSizeR, scrollLayerR);
        scrollViewR.setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
        scrollViewR.setPosition(scrollPosR);
        mainNode.addChild(scrollViewR);

        var contentWidthR = 0;
        for (var i = 0; i < 78; i++) {
            for (var y = 0; y < 6; y++) {
                var bgSprite = this._bgSprite = new cc.Sprite("#bcr_point0.png");
                bgSprite.setPosition(this._getPointPosition(i, y));
                bgSprite.setOpacity(50);
                scrollLayerR.addChild(bgSprite);
            }

            contentWidthR += pointSize.width;
        }
        scrollViewR.setContentSize(cc.size(contentWidthR, scrollSizeR.height));
        scrollViewR.setContentOffset(cc.p(0, 0));

        // 創一個之後放點數用的Node
        var pointNodeR = this._pointNodeR = new cc.Node();
        scrollLayerR.addChild(pointNodeR);

        // 中間的線
        var lineSprite = new cc.Sprite("#bcr_record_line.png");
        lineSprite.setPosition(scrollPosL.x + scrollSizeL.width, 0);
        mainNode.addChild(lineSprite);

        // 先清掉畫面
        this.clear();
    },

    /**
     * 算左邊點的位置
     */
    _getPointPosition: function (x, y) {
        return cc.p(x * this._pointSize.width + 6, 71 - y * this._pointSize.height)
    },

    /**
     * 清掉
     */
    clear: function () {
        this._pointNodeL.removeAllChildren();
        this._pointNodeR.removeAllChildren();

        this._pointLeftParam = {
            x: 0,
            y: 0,
            winType: BaccaratWinType.NONE
        };
        this._pointRightParam = {
            x: 0,
            y: 0,
        };
    },

    /**
     * 出現紀錄
     */
    open: function () {
        this._mainNode.stopAllActions();
        this._mainNode.runAction(cc.moveTo(0.5, cc.p(JSScreenMidPos.x, JSScreenMidPos.y + 58)).easing(cc.easeBackOut()));
    },

    /**
     * 關掉紀錄
     */
    close: function () {
        this._mainNode.stopAllActions();
        this._mainNode.runAction(cc.moveTo(0.5, cc.p(JSScreenMidPos.x, JSVisibleSize.height + 96)).easing(cc.easeBackIn()));
    },

    /**
     * 更新紀錄
     */
    updateRecord: function (param) {
        // 出現畫面
        this.open();

        // 先判斷是否要重新洗牌
        if (param.needShuffle) {
            this.clear();
            return;
        }

        // 對左邊的做更新
        var leftParam = this._pointLeftParam;
        var bigRoad = param.bigRoad;
        var pointNodeL = new BaccaratRecordPointNode();
        var winType = pointNodeL.showBigRoad(bigRoad);
        this._pointNodeL.addChild(pointNodeL);

        // 要判斷是否不同Type 或超過Y
        if (leftParam.winType !== winType && leftParam.winType !== BaccaratWinType.NONE) {
            // 不同Type要換行
            leftParam.x++;
            leftParam.y = 0;
        } else if (leftParam.y >= 6) {
            // 超過了 也要換行
            leftParam.x++;
            leftParam.y = 0;
        }

        // 放上去
        pointNodeL.setPosition(this._getPointPosition(leftParam.x, leftParam.y));
        leftParam.y++;

        leftParam.winType = winType;

        // 對右邊的做更新
        var rightParam = this._pointRightParam;
        var beadRoad = param.beadRoad;
        var pointNodeR = new BaccaratRecordPointNode();
        pointNodeR.showBeadRoad(beadRoad);
        this._pointNodeR.addChild(pointNodeR);

        // 要判斷是否超過Y
        if (rightParam.y >= 6) {
            // 超過了 也要換行
            rightParam.x++;
            rightParam.y = 0;
        }

        // 放上去
        pointNodeR.setPosition(this._getPointPosition(rightParam.x, rightParam.y));
        rightParam.y++;
    },
});