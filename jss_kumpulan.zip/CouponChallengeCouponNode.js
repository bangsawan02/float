/**
 * 優惠券挑戰 - 優惠券 node
 *
 * @author tony.cheng
 */
var CouponChallengeCouponNode = cc.Node.extend({
    /**
     * @param style {CouponChallengeCouponNode.Style}
     * @param style.ticketBg {string} 優惠券背景
     * @param style.textColor {cc.Color} 優惠券字顏色
     * @param style.isTopLight {boolean} 優惠券上閃光
     * @param style.isBottomLight {boolean} 優惠券下閃光
     */
    ctor: function (style) {
        this._super();
        this._style = style;

        // 底部信
        const mailBgSp = new cc.Sprite("#couponChallenge_pic_mail.png");
        this.addChild(mailBgSp);

        // 優惠券圖
        const ticketBgSP = new cc.Sprite(style.ticketBg);
        ticketBgSP.setPosition(0, 45);
        ticketBgSP.setRotation(-7);
        this.addChild(ticketBgSP);

        // 優惠券上閃光
        if (style.isTopLight) {
            const topLightSp = new cc.Sprite("#couponChallenge_pic_ticket_light.png");
            topLightSp.setPosition(0, 45);
            topLightSp.setRotation(-7);
            this.addChild(topLightSp);
        }

        // 優惠券下閃光
        if (style.isBottomLight) {
            const bottomLightSp = new cc.Sprite("#couponChallenge_pic_ticket_light.png");
            bottomLightSp.setPosition(0, 47);
            bottomLightSp.setFlippedX(true);
            bottomLightSp.setFlippedY(true);
            bottomLightSp.setRotation(-7);
            this.addChild(bottomLightSp);
        }

        this._refreshNode = new cc.Node();
        this.addChild(this._refreshNode);
    },

    refreshView: function (item) {
        const node = this._refreshNode;
        node.removeAllChildren();

        if (item.status === CouponChallengeData.TicketStatus.AVAILABLE
            || item.status === CouponChallengeData.TicketStatus.UNAVAILABLE) {
            // 數字 + AutoLayout
            const moneyNumberNode = new GSSpriteNumberNode({
                number: item.bonus,
                numStr: "#num_28_",
                spW: 16,
                spH: 10,
            });
            const plusSp = new cc.Sprite("#num_28_+.png");
            const percentSp = new cc.Sprite("#num_28_%.png");
            const autoLayoutNode = new GSAutoLayoutNode();
            autoLayoutNode.addChild(plusSp);
            autoLayoutNode.addChild(moneyNumberNode);
            autoLayoutNode.addChild(percentSp);
            autoLayoutNode.setRotation(-7);
            autoLayoutNode.setScale(0.9);
            autoLayoutNode.setPosition(-5, 56);
            node.addChild(autoLayoutNode);

            // chips 字
            const chipsSp = new cc.Sprite("#couponChallenge_num_chips.png");
            chipsSp.setPosition(0, 35);
            chipsSp.setScale(0.9);
            chipsSp.setRotation(-7);
            node.addChild(chipsSp);

            // 底部提示
            let limitStr = LocalizedString.CouponChallengeString("所有方案可使用");
            if (item.limit > 0) {
                limitStr = JSStringUtility.format(LocalizedString.CouponChallengeString("限 %s 以上"), TexasUtility.getCurrencyPriceString(item.limit));
            }
            const limitLabel = new cc.LabelTTF(limitStr, JSFontName, 10);
            limitLabel.setPosition(0, -10);
            limitLabel.setFontFillColor(cc.color(92, 52, 0));
            node.addChild(limitLabel);
        }

        if (item.status === CouponChallengeData.TicketStatus.UNAVAILABLE) {
            // 壓黑
            const unavailableSp = new cc.Sprite("#couponChallenge_pic_ticket_blk.png");
            unavailableSp.setPosition(0, 45);
            unavailableSp.setRotation(-7);
            unavailableSp.setOpacity(144);
            node.addChild(unavailableSp);

            // 鎖頭
            const lockSp = new cc.Sprite("#couponChallenge_pic_lock.png");
            lockSp.setPosition(40, 78);
            node.addChild(lockSp);
        }

        if (item.status === CouponChallengeData.TicketStatus.USED) {
            // 字
            const usedLabel = new cc.LabelTTF(LocalizedString.CouponChallengeString("已使用"), JSFontName, 16);
            usedLabel.setPosition(0, 45);
            usedLabel.setFontFillColor(this._style.textColor);
            usedLabel.setRotation(-7);
            node.addChild(usedLabel);

            // 印章
            const usedSp = new cc.Sprite("#couponChallenge_pic_finish.png");
            usedSp.setPosition(40, 23);
            node.addChild(usedSp);
        }
    },
});

CouponChallengeCouponNode.Style = {
    BLUE: {
        ticketBg: "#couponChallenge_pic_ticket_b.png",
        textColor: cc.color(5, 78, 181),
        isTopLight: true,
        isBottomLight: false,
    },
    PURPLE: {
        ticketBg: "#couponChallenge_pic_ticket_r.png",
        textColor: cc.color(160, 23, 176),
        isTopLight: true,
        isBottomLight: false,
    },
    GOLD: {
        ticketBg: "#couponChallenge_pic_ticket_y.png",
        textColor: cc.color(150, 80, 0),
        isTopLight: true,
        isBottomLight: true,
    },
};
