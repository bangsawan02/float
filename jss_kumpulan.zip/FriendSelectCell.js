/**
 * 好友列表的Cell
 */

var FriendSelectCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        var midPosY = FriendSelectCell.HEIGHT / 2 + 3;

        // 用來變色用
        var node = this._container = new cc.Node();
        node.setCascadeColorEnabled(true);
        this.addChild(node);

        // 大頭貼
        var photoNode = this._photoSprite = new LobbyCircleProfileNode();
        photoNode.setPosition(30, midPosY);
        photoNode.setScale(0.7);
        node.addChild(photoNode);

        // 帳號
        var accountLabel = this._accountLabel = new GSAutoSizeLabel("", JSFontBoldName, 12, cc.size(110, GameRankRankCell.HEIGHT), cc.TEXT_ALIGNMENT_LEFT, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        accountLabel.setAnchorPoint(0, 0.5);
        accountLabel.setPosition(54, midPosY + 8);
        node.addChild(accountLabel);

        // 暱稱
        var nicknameLabel = this._nicknameLabel = new GSAutoSizeLabel("", JSFontBoldName, 12, cc.size(110, GameRankRankCell.HEIGHT), cc.TEXT_ALIGNMENT_LEFT, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        nicknameLabel.setAnchorPoint(0, 0.5);
        nicknameLabel.setPosition(54, midPosY - 8);
        node.addChild(nicknameLabel);

        // 箭頭
        var arrowSp = new cc.Sprite("#lobby_pic_arrow.png");
        arrowSp.setFlippedX(true);
        arrowSp.setPosition(185, midPosY);
        node.addChild(arrowSp);

        // cell分隔線
        var lineSp = new ccui.Scale9Sprite("lobby_brown_line.png");
        lineSp.setPreferredSize(cc.size(200, 2));
        lineSp.setPosition(100, 4);
        this.addChild(lineSp);
    },

    /**
     * 刷新cell
     * @param param : DataModal.friendData.friendList
     */
    refreshCell: function (param) {
        if (!param)
            return;

        // 記下userID
        this.userID = param.userID;

        // 帳號
        this._accountLabel.setString(param.userID);

        // 暱稱
        this._nicknameLabel.setString(param.shortenNickname);

        // 刷新大頭貼
        this._photoSprite.setPhotoUrl(param.photo, param.userID);
    },

    // 按下cell會變色
    setIsHighlight: function (value) {
        this._container.setColor(value ? JSColor.GRAY : JSColor.WHITE);
    }
});

// Cell高度
FriendSelectCell.HEIGHT = 50;