/**
 * 通行證 - 循環獎勵進度條（是一個大按鈕）
 * config: {
 *     tokenIconFileName: "",                                   // 代幣圖示
 *     cycleRewardProgressBarSize: cc.size(0, 0),               // 進度條尺寸
 *     cycleRewardProgressBarStrokeColor: cc.color(0, 0, 0),    // 進度條文字邊框顏色
 * },
 * param: {
 *     currentCycleTokenCount: 0,                               // 目前循環代幣數量
 *     goalTokenCount: 1,                                       // 目標代幣數量
 * }
 */
var BasePassCycleProgressBarBtn = GSControlButton.extend({
    ctor: function (config, param = {}) {
        let size = config.cycleRewardProgressBarSize || cc.size(190, 18);
        let tokenIconFileName = config.tokenIconFileName || "luxyPass_pic_star.png";
        let progressBarBgFileName = config.cycleRewardProgressBarBgFileName || "luxyPass_pic_bar_02.png";
        let progressBarBarFileName = config.cycleRewardProgressBarBarFileName || "luxyPass_pic_bar_01.png";
        let progressBarStrokeColor = config.cycleRewardProgressBarStrokeColor || cc.color(102, 51, 41);

        let currentCycleTokenCount = param.currentCycleTokenCount || 0;
        let goalTokenCount = param.goalTokenCount || 1;

        let contentNode = new cc.Node();

        // 進度條
        let progressBar = this._progressBar = new GSProgressTimer(progressBarBgFileName, progressBarBarFileName, size, cc.size(size.width - 3, size.height - 3));
        contentNode.addChild(progressBar);

        // 代幣圖示
        let tokenSprite = this._tokenSprite = new cc.Sprite("#" + tokenIconFileName);
        tokenSprite.setPosition(-88, 0);
        contentNode.addChild(tokenSprite);

        // + 按鈕
        let plusButton = this._plusButton = new BasePassPlusButton(config);
        plusButton.setPosition(88, 0);
        plusButton.setChangeColorWhenDisabled(false);
        plusButton.setChangeOpacityWhenDisabled(false);
        contentNode.addChild(plusButton);

        // 進度條文字 xxx,xxx / xxx,xxx
        let progressLabel = this._progresslabel = new cc.LabelTTF("- / -", JSFontName, 10);
        progressLabel.enableStroke(progressBarStrokeColor, 1.5);
        contentNode.addChild(progressLabel);

        this.refreshView(currentCycleTokenCount, goalTokenCount);

        this._super(contentNode, size);
        this.setCascadeOpacityEnabled(true);
        this._config = config;
        this._param = param;
        this._isSkipped = false;
    },

    /**
     * 取得代幣 icon 世界位置
     * @returns {cc.Point}
     */
    getTokenIconPosition: function () {
        return this._tokenSprite.getWorldPosition();
    },

    /**
     * 是否跳過動畫
     * @param {boolean} isSkipped
     */
    setSkipped: function (isSkipped) {
        this._isSkipped = isSkipped;
    },

    /**
     * 設定目前和目標數量
     * @param {Number} currentCycleTokenCount   目前循環代幣數量
     * @param {Number} goalTokenCount           目標代幣數量
     */
    refreshView: function (currentCycleTokenCount, goalTokenCount) {
        this._isSkipped = false;

        // 進度條
        let tokenCountInProgress = this._tokenCountInProgress = currentCycleTokenCount % goalTokenCount;
        let percent = cc.clampf(tokenCountInProgress / goalTokenCount * 100, 0, 100);
        this._progressBar.setPercentage(percent, false);

        // 進度條上文字
        let progressString = JSStringUtility.format("%d / %d", tokenCountInProgress, goalTokenCount);
        this._progresslabel.setString(progressString);
    },

    addTouchUpInsideAction: function (func, target) {
        this._super(func, target);
        this._plusButton.addTouchUpInsideAction(func, target);
    },

    /**
     * 跑進度條動畫
     * @param {int} deltaTokenCount 代幣數量變化量
     * @param {int} goalTokenCount  目標代幣數量
     * @return {Promise<void>}
     */
    playAnimeAsync: function (deltaTokenCount, goalTokenCount) {
        return new Promise((resolve, reject) => {
            if (this.__isDestroyed) {
                return;
            }

            if (this._isSkipped || deltaTokenCount <= 0) {
                this._isSkipped = false;
                return resolve();
            }

            let totalTokenCount = this._tokenCountInProgress + deltaTokenCount;
            let currentTokenCount = cc.clampf(totalTokenCount, 0, goalTokenCount);
            let percent = cc.clampf(currentTokenCount / goalTokenCount * 100, 0, 100);

            this._progresslabel.setString(JSCodeUtility.getCurrencyString(currentTokenCount) + " / " + JSCodeUtility.getCurrencyString(goalTokenCount));
            this._progressBar.setPercentage(percent, true);
            this._progressBar.setFinishProgressCallback(() => {
                this._progressBar.setFinishProgressCallback(undefined);

                let isFull = totalTokenCount >= goalTokenCount;
                this._tokenCountInProgress = isFull ? 0 : currentTokenCount;

                if (isFull) {
                    this._onProgressFullCallback && this._onProgressFullCallback();

                    // 跑滿之後，要先歸0
                    this._progressBar.setPercentage(0, false);
                }

                // Recursively call.
                this.playAnimeAsync(totalTokenCount - currentTokenCount, goalTokenCount)
                    .then(() => resolve())
                    .catch(() => reject());
            });
        });
    },

    /**
     * 進度條滿時的 callback
     * @param {function} callback
     */
    onProgressFull: function (callback) {
        this._onProgressFullCallback = callback;
    },
});