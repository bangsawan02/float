/**
 * 聊天的資料
 */

var ChatData = cc.Class.extend({
    ctor: function () {
        this.cleanData();

        // 註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            "say": this.cmd_say
        });
    },

    /**
     * 清掉資料
     */
    cleanData: function () {
        this.chatArray = [];           // 聊天的資料存放地方
        this.blockedListObject = {};   // 被禁言的人
    },

    /**
     * 是否為被禁言的帳號
     * @param account
     */
    isBlockedAccount: function (account) {
        return DataModal.blacklistData.isAccountInList(account);
    },

    /**
     * Socket Callback
     */
    // 聊天室的資料
    cmd_say: function (key, value) {
        // say a68284460@ap a68284460 8 1 Saya tertidur... photoUrl
        var array = value.split(" ");

        if (array.length > 1) {
            // 帳號
            var account = array[0];

            // 判斷是否被禁言
            if (this.isBlockedAccount(account))
                return;

            // 暱稱
            var nickname = decodeURIComponent(array[1]);

            // 位置
            var pos = parseInt(array[2]);

            var photoURL;
            var chatText = "";
            if (GS.nowGame === GSEnum.Game.Vegas || GS.nowGame === GSEnum.Game.TebakQQ) {
                // 照片Url
                photoURL = JSCodeUtility.getStringValue(array[4]);

                // 文字
                var totalLen = 0;
                for (var i = 0; i < 5; i++) {
                    totalLen += array[i].length + 1;
                }
                chatText = value.substring(totalLen);
            } else {
                // 一般桌內要坐下才能聊天，所以可以自己去抓updateSeat的資料來用
                // 照片Url 從當下GameData那邊抓出來
                var gameData = DataModal.gameData;
                if (!gameData)
                    return;

                gameData.playerDataArray.some(playerData => {
                    if (!playerData)
                        return false;

                    if (playerData.nickname === nickname) {
                        photoURL = playerData.photoURL;
                        return true;
                    }
                });
                // 文字
                var totalLen = 0;
                for (var i = 0; i < 4; i++) {
                    totalLen += array[i].length + 1;
                }
                chatText = value.substring(totalLen);
            }

            // 是否為自己
            var isMe = (account === DataModal.profileData.account);

            // 百人機台額外判斷是自己的話把位置設成0
            if (GS.nowGame === GSEnum.Game.Vegas &&
                (GS.nowVegas === VegasGameType.MULTI_DICEBO ||
                    GS.nowVegas === VegasGameType.MULTI_SHOOTGATE ||
                    GS.nowVegas === VegasGameType.MULTI_HOOHEYHOW ||
                    GS.nowVegas === VegasGameType.MULTI_BACCARAT ||
                    GS.nowVegas === VegasGameType.MULTI_QQ)
                && isMe) {
                pos = 0;
            }

            // 組成Param
            var param = {
                account: account,
                nickname: nickname,
                photoURL: photoURL,
                pos: pos,
                isMe: isMe,
                chatText: chatText
            };
            this.chatArray.push(param);

            // 通知
            GS.dispatchCustomEvent("NotifyUpdateChatData", param);
        }
    }
});