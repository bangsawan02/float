/**
 * 共用的遊戲資料 這邊負責資料的傳遞
 * 現在流程改成收到資料不處理 --> 通知UI --> UI決定是否要抓取資料或等動畫演完 --> 跟GameData抓取資料時, GameData同時處理資料 且回傳給UI --> 之後給UI決定要幹麻
 */

var BaseGameData = cc.Class.extend({
    ctor: function () {
        this.clean();
    },

    clean: function () {
        this._cmdQueue = [];            // Command的Queue
        this._canProcessCMD = true;     // 是否可以處理CMD, 繼承的人可以去設定要true or false (大多數用在要離開遊戲畫面 然後收到CMD也不理他了)
    },

    /**
     * 抓取CMD Queue 通常用在牌局重現用
     */
    getCmdQueue: function () {
        return this._cmdQueue;
    },

    /**
     * 回傳已經接收到的指令
     */
    popQueuedMessage: function () {
        if (!this._canProcessCMD)
            return null;

        var param = this._cmdQueue.length ? this._cmdQueue.shift() : null;

        // 先丟給自己處理到需要給UI才停下來
        while (!this._processGameCommand(param)) {
            param = this._cmdQueue.length ? this._cmdQueue.shift() : null;
        }

        return param;
    },

    /**
     * 處理牌局重現的指令
     */
    processReconnectState: function (key, value) {
        var socketParam = {
            key: key,                   // Socket CMD Key
            value: value,               // Socket CMD Value
        };

        // 把他加在第一個 不用通知UI 因為UI馬上就開始抓了
        this._cmdQueue.splice(0, 0, socketParam);
    },

    /**
     * 清掉所有Socket CMD
     */
    clearSocketQueue: function () {
        this._cmdQueue.length = 0;
    },

    /**
     * 收到Socket資料統一在這邊先弄
     */
    _receiveSocketCMD: function (key, value) {
        this._cmdQueue.push({
            key: key,                   // Socket CMD Key
            value: value,               // Socket CMD Value
            parse: undefined,           // GameData Parse完自創的Value (可以自行決定在GameData弄完還是UI在Parse) 先給空值
        });

        // 通知UI
        GS.dispatchCustomEvent("NotifyGameProcessCMD");
    },

    /**
     * 給外面的人override掉 需要回傳是否要給UI處理 true or false
     */
    _processGameCommand: function (socketParam) {
    },
});