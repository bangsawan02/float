/**
 * 9T 幸運彩票 - 歷史紀錄 Layer
 */

var BigLotteryHistoryRecordLayer = BigLotteryHistoryBaseLayer.extend({
    ctor: function () {
        this._super();

        // 標題
        var titleSprite = new cc.Sprite("#bigLottery_word_history.png");
        titleSprite.setPosition(JSScreenMidPos.x, JSVisibleSize.height - 83);
        this.addChild(titleSprite);

        // Domino移植設定 調整描邊/位移
        // 文字: 僅保留近半年紀錄
        var hintLabel = new cc.LabelTTF(LocalizedString.BigLottery("僅保留近半年紀錄"), JSFontName, 10);
        hintLabel.setAnchorPoint(1, 0.5);
        hintLabel.enableStroke(cc.color(190, 30, 0, 255), 2);
        hintLabel.setPosition(JSVisibleSize.width - 6, JSVisibleSize.height - 68);
        this.addChild(hintLabel);

        // 側邊按鈕
        this._tabBtns = [];
        // 頁面
        this._pageLayers = [];

        // 按鈕
        var menu = this._menu = new cc.Menu();
        menu.setPosition(0, 0);
        this.addChild(menu, 2);

        // 放頁面的Node
        var pageNode = this._pageNode = new cc.Node();
        this.addChild(pageNode);

        // Domino移植設定 新增錢幣
        // 錢幣堆
        var coinSprite = this._coinSprite = new cc.Sprite("#bigLottery_pic_money.png");
        coinSprite.setPosition(464 + JSScreenBonusHalfWidth, 86);
        this.addChild(coinSprite);

        this._refreshView();
    },

    /**
     * 刷新畫面
     */
    _refreshView: function () {
        this._menu.removeAllChildren();
        this._tabBtns = [];
        this._pageNode.removeAllChildren();
        this._pageLayers = [];

        var historyParam = DataModal.bigLotteryData.historyParam;

        // Domino移植設定，改語言
        var tabStringArray = ["幸運彩票", "大紅包", "幸運數字"].map(string => LocalizedString.BigLottery(string));
        var tabVisibleArray = [true, false, false];

        // 有紅包
        if (historyParam.envelopeHistoryList && historyParam.envelopeHistoryList.length > 0) {
            tabVisibleArray[1] = true;
        }

        // 幸運數字
        if (historyParam.luckyHistoryList && historyParam.luckyHistoryList.length > 0) {
            tabVisibleArray[2] = true;
        }

        if (tabStringArray.length > 0) {

            this._coinSprite.setVisible(false);

            // 創側邊選單
            {
                var index = 0;
                tabStringArray.forEach((curr, i) => {
                    var itemNodes = this._createTabBtn(curr, true);
                    var tab = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._tabClicked, this);
                    tab.setVisible(tabVisibleArray[i]);
                    tab.setPosition(49 + JSScreenBonusHalfWidth, 182 - index * 36 + JSScreenBonusHalfHeight);
                    if (tabVisibleArray[i]) index++;
                    this._menu.addChild(tab);
                    this._tabBtns.push(tab);
                });
            }

            // 預設點擊大樂彩
            this._tabClicked(this._tabBtns[0]);
        } else {
            this._coinSprite.setVisible(true);

            var winnerNode = this._pageLayers[0] = new BigLotteryHistoryRecordNode();
            this._pageNode.addChild(winnerNode);
        }
    },

    /**
     * 創側邊選單按鈕
     * @param btnString     按鈕文字
     * @param isEnabled     按鈕是否可以點擊
     */
    _createTabBtn: function (btnString, isEnabled) {
        var itemNode = [];

        if (isEnabled) {
            var enableBgSize = cc.size(80, 32);
            var disableBgSize = cc.size(80, 32);
            for (var i = 0; i < 3; i++) {
                var bgSize = (i === 2) ? disableBgSize : enableBgSize;
                var btnImg = (i === 2) ? "lobby_btn_01.png" : "lobby_btn_purchase_01.png";

                var node = itemNode[i] = new cc.Node();
                node.setContentSize(bgSize);
                node.setCascadeColorEnabled(true);
                node.setCascadeOpacityEnabled(true);

                var bgSprite = new ccui.Scale9Sprite(btnImg);
                bgSprite.setPreferredSize(bgSize);
                bgSprite.setPosition(bgSize.width / 2, bgSize.height / 2);
                node.addChild(bgSprite);

                var btnLabel = new cc.LabelTTF(btnString, JSFontName, 12);
                btnLabel.enableStroke(cc.color(90, 65, 0, 255), 2);
                btnLabel.setPosition(enableBgSize.width / 2, enableBgSize.height / 2);
                node.addChild(btnLabel);
            }
            itemNode[1].setColor(JSColor.GRAY);
        } else {
            itemNode = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", cc.size(65, 32), btnString, 12);
            itemNode.forEach(cur => {
                cur.label.enableStroke(cc.color(45, 45, 45, 255), 2);
            });
            itemNode[1].setColor(JSColor.WHITE);
            itemNode[2].setOpacity(255);
        }

        return itemNode;
    },

    /**
     * 按鈕
     */
    _tabClicked: function (sender) {
        // 找出現在按的是哪一個按鈕
        var clickedIndex = 0;
        this._tabBtns.forEach((curr, i) => {
            if (curr === sender) {
                clickedIndex = i;
                curr.setEnabled(false);
            } else {
                curr.setEnabled(true);
            }
        });

        // 先把頁面都關掉
        this._pageLayers.forEach(curr => curr.setVisible(false));

        var page = this._pageLayers[clickedIndex];

        if (!page) {
            switch (clickedIndex) {
                case BigLotteryHistoryRecordLayer.pageType.BIG_LOTTERY:
                    page = this._pageLayers[clickedIndex] = new BigLotteryHistoryRecordNode();
                    break;
                case BigLotteryHistoryRecordLayer.pageType.RED_ENVELOPE:
                    page = this._pageLayers[clickedIndex] = new BigLotteryRecordRedEnvelopeNode(clickedIndex);
                    break;
                case BigLotteryHistoryRecordLayer.pageType.LUCKY_NUMBER:
                    page = this._pageLayers[clickedIndex] = new BigLotteryRecordRedEnvelopeNode(clickedIndex);
                    break;
                default:
                    break;
            }
            this._pageNode.addChild(page);
        }

        page.setVisible(true);
    }
});

// 中獎名單頁面type
BigLotteryHistoryRecordLayer.pageType = {
    BIG_LOTTERY: 0,     // 大樂彩
    RED_ENVELOPE: 1,    // 紅包
    LUCKY_NUMBER: 2     // 幸運數字
};