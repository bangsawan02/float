/**
 * 單一版桌列表比賽教學
 * teachType : 教學類型
 * btn : 鑽石兌換頁的按鈕
 */
var CompeteTeachLayer = cc.Layer.extend({
    ctor: function (teachType, btn) {
        this._super();

        this._step = 0;                 // 紀錄第幾步驟
        this._teachType = teachType;    // 教學類型
        this._btn = btn;                // 鑽石兌換頁的按鈕

        // 擋touch
        var dummyTouchLayer = new DummyTouchLayer(JSVisibleSize);
        dummyTouchLayer.setOnTouchCallback(() => this._touchCallback());
        this.addChild(dummyTouchLayer);

        // 遮罩的node
        var clippingNode = this._clippingNode = new cc.ClippingNode();
        clippingNode.setInverted(true);
        this.addChild(clippingNode);

        // 黑背景
        var blackLayer = new cc.LayerColor(cc.color(0, 0, 0, 180), JSVisibleSize.width, JSVisibleSize.height);
        clippingNode.addChild(blackLayer);

        // 裝東西的node
        var mainNode = this._mainNode = new cc.Node();
        this.addChild(mainNode);

        // 點擊螢幕繼續
        var label = new cc.LabelTTF(LocalizedString.NewbieTeach("點擊螢幕繼續>>"), JSFontName, 10);
        label.setAnchorPoint(1, 0);
        label.setPosition(JSVisibleSize.width - 10 - JSScreenSafeWidth, 6);
        this.addChild(label);

        this._runStep();
    },

    _runStep: function () {
        this._mainNode.removeAllChildren();

        var step = ++this._step;
        var teachType = this._teachType;

        var messageParam = {};
        var clippingParam = {};
        switch (this._teachType) {
            case CompeteTeachLayer.TeachType.SNG:
                messageParam.msg = "依據參賽費、盲注大小分為三組\n參賽費越高，獎金越高\n可依據資產來進行選擇";
                messageParam.direct = BaseMessageNode.Direct.DOWN;
                messageParam.posX = 315 + JSScreenSafeWidth;
                messageParam.posY = 90;

                clippingParam.posX = 130 + JSScreenSafeWidth;
                clippingParam.posY = 55;
                clippingParam.width = 370;
                clippingParam.height = 30;

                break;

            case CompeteTeachLayer.TeachType.Diamond:
                switch (step) {
                    case 1:
                        messageParam.msg = "比賽分為『紅鑽』、『橙鑽』\n紅鑽：參賽費低，適合新手小試身手\n橙鑽：參賽費高，且需鑽石方可入桌，適合牌技高手";
                        messageParam.direct = BaseMessageNode.Direct.UP;
                        messageParam.arrowPadding = -90;
                        messageParam.posX = 380 + JSScreenSafeWidth;
                        messageParam.posY = 200;

                        clippingParam.posX = 130 + JSScreenSafeWidth;
                        clippingParam.posY = 55;
                        clippingParam.width = 370;
                        clippingParam.height = 170;

                        break;

                    case 2:
                        messageParam.msg = "比賽開放時\n可點選按鈕參加比賽";
                        messageParam.direct = BaseMessageNode.Direct.DOWN;
                        messageParam.posX = 400 + JSScreenSafeWidth;
                        messageParam.posY = 54;

                        clippingParam.posX = 130 + JSScreenSafeWidth;
                        clippingParam.posY = 22;
                        clippingParam.width = 370;
                        clippingParam.height = 36;

                        break;

                    case 3:
                        messageParam.msg = "取得第一名可獲得鑽石\n鑽石可兌換獎勵或參加橙鑽比賽";
                        messageParam.direct = BaseMessageNode.Direct.UP;
                        messageParam.arrowPadding = -50;
                        messageParam.posX = 380 + JSScreenSafeWidth;
                        messageParam.posY = 100;

                        clippingParam.posX = 130 + JSScreenSafeWidth;
                        clippingParam.posY = 108;
                        clippingParam.width = 370;
                        clippingParam.height = 92;

                        break;

                    case 4:
                        var btnPos = this._btn.getPosition();

                        messageParam.msg = "點擊這裡看兌換獎勵內容";
                        messageParam.direct = BaseMessageNode.Direct.UP;
                        messageParam.arrowPadding = -100;
                        messageParam.posX = btnPos.x;
                        messageParam.posY = btnPos.y - 15 - JSScreenBonusHalfHeight;

                        clippingParam.posX = btnPos.x - 15;
                        clippingParam.posY = btnPos.y - 15 - JSScreenBonusHalfHeight;
                        clippingParam.width = 30;
                        clippingParam.height = 30;

                        break;
                }

                break;

            case CompeteTeachLayer.TeachType.Diamond_Exchange:
                clippingParam.posX = 48 + JSScreenBonusHalfWidth;
                clippingParam.posY = 40 + (JSVisibleSize.height - 100) / 2 + 5 - JSScreenBonusHalfHeight;
                clippingParam.width = 204;
                clippingParam.height = (JSVisibleSize.height - 100) / 2 + 5;

                messageParam.direct = BaseMessageNode.Direct.UP;
                messageParam.posX = 204 + JSScreenBonusHalfWidth;
                messageParam.posY = 140;

                if (step === 1) {
                    messageParam.msg = "此處獎勵只可使用比賽得名取得的鑽石兌換";
                } else {
                    messageParam.msg = "當數量足夠時，按鈕將變藍色可兌換";
                }


                break;
        }

        this._createClipping(clippingParam);

        if (teachType === CompeteTeachLayer.TeachType.Diamond && step === 1) {
            var stencilSp = new cc.LayerColor(cc.color(0, 0, 0, 180), 370, 102);
            stencilSp.setPosition(130 + JSScreenSafeWidth, 100 + JSScreenBonusHalfHeight);
            this._mainNode.addChild(stencilSp);
        }

        this._createMessage(messageParam);
    },

    _createClipping: function (param) {
        // 遮罩
        var stencilSp = new cc.LayerColor(cc.color(0, 0, 0, 180), param.width, param.height);
        stencilSp.setPosition(param.posX, param.posY + JSScreenBonusHalfHeight);
        this._clippingNode.setStencil(stencilSp);
    },

    _createMessage: function (param) {
        // 訊息
        var msgLabel = new cc.LabelTTF(LocalizedString.NewbieTeach(param.msg), JSFontBoldName, 12);
        msgLabel.setFontFillColor(JSColor.BLACK);

        // 加入泡泡框
        var msgParam = {
            mainNode: msgLabel,
            style: BaseMessageNode.Style.WHITE_SHADOW,
            direct: param.direct,
            arrowType: BaseMessageNode.ArrowType.STRAIGHT,
            arrowPadding: param.arrowPadding || 0,
        };
        var msgNode = new BaseMessageNode(msgParam);
        msgNode.setPosition(param.posX, param.posY + JSScreenBonusHalfHeight);
        msgNode.show();
        this._mainNode.addChild(msgNode, 1);
    },

    _touchCallback: function () {
        var step = this._step;
        var teachType = this._teachType;
        if (teachType === CompeteTeachLayer.TeachType.SNG) {
            // 拿掉畫面
            this._closeLayer();
        } else {
            if ((teachType === CompeteTeachLayer.TeachType.Diamond && step === 4) || (teachType === CompeteTeachLayer.TeachType.Diamond_Exchange && step === 2)) {
                // 拿掉畫面
                this._closeLayer();
            } else {
                this._runStep();
            }
        }
    },

    _closeLayer: function () {
        // 避免點擊馬上透下去 用runAction砍掉
        this.stopAllActions();
        this.runAction(cc.removeSelf());
    },
});

// 教學類型
CompeteTeachLayer.TeachType = {
    SNG: 0,                 // SNG頁面
    Diamond: 1,             // 鑽石頁面
    Diamond_Exchange: 2,    // 鑽石交換頁面
};