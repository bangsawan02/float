/**
 * 互動道具選單
 */

var ActMoodsScrollLayer = cc.Layer.extend({
    ctor: function (isGameGaple) {
        this._super();

        this.setCascadeOpacityEnabled(true);

        this._isGameGaple = isGameGaple;

        var pageSize = cc.size(205, 175);
        var pageViewPos = cc.p(5, 35);
        var indicatorPosX = 0;
        var shopPos = cc.p(10, 160);
        if (isGameGaple) {
            pageSize = cc.size(162, 145);
            pageViewPos = cc.p(39, 43);
            indicatorPosX = 5;
            shopPos = cc.p(10, 135);
        }

        this._pageSize = pageSize;
        this._shopPos = shopPos;

        var pageView = this._pageView = new ccui.PageView();
        pageView.setPosition(pageViewPos);
        pageView.setDirection(ccui.ScrollView.DIR_HORIZONTAL);
        pageView.setContentSize(pageSize);
        pageView.setBounceEnabled(true);
        pageView.setIndicatorEnabled(true);
        pageView.setIndicatorSpaceBetweenIndexNodes(10);
        pageView.setIndicatorIndexNodesTexture("lobby_page_point_0.png", ccui.Widget.PLIST_TEXTURE);
        pageView.setIndicatorSelectedIndexColor(cc.color(255, 255, 255));
        pageView.setIndicatorPosition(cc.p(pageSize.width / 2, indicatorPosX));
        this.addChild(pageView);

        // 判斷是否有東西
        this._loadingSprite = undefined;
        if (DataModal.moodData.actMoodArray.length) {
            // 直接重整畫面
            this._refreshPageView();
        } else {
            // 去更新一次
            DataProcess.sendString("act_moods_backpack");       // 抓互動道具

            // 加Loading
            var loadingSprite = this._loadingSprite = new GSLoadingSprite();
            loadingSprite.setPosition(pageSize.width / 2, pageSize.height / 2 + 35);
            loadingSprite.start();
            this.addChild(loadingSprite);
        }

        // 註冊
        GS.addListener("NotifyGetActMoodList", this.notifyGetActMoodList.bind(this), this);
    },

    _getPosition: function (index) {
        if (this._isGameGaple)
            return cc.p(20 + 40 * (index % 4), 102 - 35 * (Math.floor(index / 4)));
        else
            return cc.p(20 + 50 * (index % 4), 132 - 44 * (Math.floor(index / 4)));
    },

    // 創頁面的東西
    _refreshPageView: function () {
        // 先清掉畫面
        this._loadingSprite && this._loadingSprite.stop();
        var pageView = this._pageView;
        pageView.removeAllPages();

        // 重建畫面
        var gameString = LocalizedString.Game;
        var actMoodArray = DataModal.moodData.actMoodArray;
        var actMoodLen = actMoodArray.length;
        if (actMoodLen === 0) {
            // 沒有互動道具 提示
            var page = new ccui.Layout();
            page.setContentSize(this._pageSize);
            pageView.addPage(page);

            var hintLabel = new cc.LabelTTF(gameString("您目前沒有互動道具"), JSFontBoldName, 12);
            hintLabel.setFontFillColor(JSColor.WHITE);
            hintLabel.setPosition(this._pageSize.width / 2, this._pageSize.height / 2);
            page.addChild(hintLabel);

            // 要加商店的按鈕
            var moreLabel = new cc.LabelTTF(gameString("想擁有更多?"), JSFontBoldName, 7);
            moreLabel.setAnchorPoint(0, 0.5);
            moreLabel.setFontFillColor(JSColor.WHITE);
            moreLabel.setPosition(this._shopPos);
            page.addChild(moreLabel);

            var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", cc.size(35, 17), gameString("前往商城"), 7, JSColor.WHITE);
            itemNodes.forEach(cur => cur.label.enableStroke(cc.color(153, 71, 30), 1));
            var button = new cc.ControlButton(itemNodes[0]);
            button.setBackgroundSpriteForState(itemNodes[1], cc.CONTROL_STATE_HIGHLIGHTED);
            button.addTargetWithActionForControlEvents(this, this._goShopClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
            button.setAdjustBackgroundImage(false);
            button.setZoomOnTouchDown(false);
            button.setSwallowTouches(false);
            button.setTouchDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
            button.setPosition(moreLabel.getPosition().x + moreLabel.getContentSize().width + 20, moreLabel.getPosition().y);
            page.addChild(button);
        } else {
            var totalPage = Math.floor((actMoodLen - 1) / 12) + 1;

            // 第一頁為常用頁
            totalPage++;

            var lastActMoods = DataModal.moodData.getLastUsedActMoods();

            for (var p = 0; p < totalPage; p++) {
                var page = new ccui.Layout();
                page.setContentSize(this._pageSize);
                pageView.addPage(page);

                if (p === 0) {
                    // 常用頁
                    // 常用的表情
                    var infoLabel = new cc.LabelTTF(gameString("常用互動道具"), JSFontBoldName, 8);
                    infoLabel.setAnchorPoint(0, 0.5);
                    infoLabel.setFontFillColor(JSColor.WHITE);
                    infoLabel.setPosition(this._shopPos);
                    page.addChild(infoLabel);

                    // 抓出常用的資訊
                    var index = 0;
                    var needRemoveSerialArray = [];
                    lastActMoods.forEach(cur => {
                        // 找出對應的ActMood
                        var actObject = null;
                        for (var i = 0; i < actMoodArray.length; i++) {
                            if (actMoodArray[i].serial === cur.serial) {
                                // 找到
                                actObject = actMoodArray[i];
                                break;
                            }
                        }

                        if (actObject) {
                            var actMoodButton = new ActMoodButton(actObject);
                            actMoodButton.setPosition(this._getPosition(index));
                            actMoodButton.setScale(0.6);
                            actMoodButton.addTargetWithActionForControlEvents(this, this._actMoodClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
                            page.addChild(actMoodButton);

                            index++;
                        } else {
                            // 需要重新更新一次常用的 代表有互動道具沒了 要把他砍掉
                            needRemoveSerialArray.push(cur.serial);
                        }
                    });

                    if (needRemoveSerialArray.length) {
                        // 要砍掉
                        DataModal.moodData.removeLastUsedActMoods(needRemoveSerialArray);
                    }
                } else {
                    for (var i = 0; i < 12; i++) {
                        // 因為p第一頁是常用頁 所以要減1
                        var index = i + (p - 1) * 12;
                        if (index >= actMoodLen)
                            break;

                        var actMoodButton = new ActMoodButton(actMoodArray[index]);
                        actMoodButton.setPosition(this._getPosition(i));
                        actMoodButton.setScale(0.6);
                        actMoodButton.addTargetWithActionForControlEvents(this, this._actMoodClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
                        page.addChild(actMoodButton);
                    }

                    // 要加商店的按鈕
                    var moreLabel = new cc.LabelTTF(gameString("想擁有更多?"), JSFontBoldName, 7);
                    moreLabel.setAnchorPoint(0, 0.5);
                    moreLabel.setFontFillColor(JSColor.WHITE);
                    moreLabel.setPosition(this._shopPos);
                    page.addChild(moreLabel);

                    var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", cc.size(35, 17), gameString("前往商城"), 7, JSColor.WHITE);
                    itemNodes.forEach(cur => cur.label.enableStroke(cc.color(153, 71, 30), 1));
                    var button = new cc.ControlButton(itemNodes[0]);
                    button.setBackgroundSpriteForState(itemNodes[1], cc.CONTROL_STATE_HIGHLIGHTED);
                    button.addTargetWithActionForControlEvents(this, this._goShopClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
                    button.setAdjustBackgroundImage(false);
                    button.setZoomOnTouchDown(false);
                    button.setSwallowTouches(false);
                    button.setTouchDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
                    button.setPosition(moreLabel.getPosition().x + moreLabel.getContentSize().width + 20, moreLabel.getPosition().y);
                    page.addChild(button);
                }
            }

            // 如果在第0頁 且常用表情是空的話 指到第一頁
            var startPageIndex = (lastActMoods.length === 0 ? 1 : 0);
            this._pageView.setCurrentPageIndex(startPageIndex);
        }
    },

    /**
     * 按鈕
     */
    //按到表情
    _actMoodClicked: function (sender) {
        // 關掉Dialog
        GS.dispatchCustomEvent("NotifyCloseEmoticons");

        // 出現選擇畫面
        GS.dispatchCustomEvent("NotifyShowActMoodAim", sender.actMoodParam.serial);
    },

    //按到前往商城
    _goShopClicked: function () {
        if (PushScene.isGame) {
            // 因為遊戲內可能會關掉Dialog 透過代參數讓Manager管理
            DialogManager.addDialog(new ChipShopDialog(ChipShopDialog.Type.GAME_SELF, DataModal.profileData.account, ShopProductType.GIFT), true, true);
        } else {
            // 此Dialog不要給Manager控管
            DialogManager.addDialog(new ChipShopDialog(ChipShopDialog.Type.GAME_SELF, DataModal.profileData.account, ShopProductType.GIFT), false);
        }

        // 關掉Dialog
        GS.dispatchCustomEvent("NotifyCloseEmoticons");
    },

    /**
     * 通知
     */
    // 更新畫面
    notifyGetActMoodList: function () {
        this._refreshPageView();
    },
});