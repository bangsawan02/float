/**
 * 牌王地圖上的線路
 */

var CardKingMapRouteCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        this._type = CardKingMapRouteCell.RouteType.NONE;

        // tableView的改idx會發生在tableViewCellAtIndex之後, 那樣太慢了, 所以refresh的時候先記起來
        this._nodeIdx = 0;

        // 中間位置, 只有高度向中間對齊, x軸是不變的
        var midPos = this._midPos = cc.p(CardKingMapRouteCell.getCellSizeByIndex().width / 2, CardKingMapRouteCell.getCellSizeByIndex().height / 2);

        // 路線背景圖
        this._routeBgSp = new cc.Sprite();
        this._routeBgSp.setPosition(38, midPos.y);
        this.addChild(this._routeBgSp, 0);

        // 路線上的圖
        this._routeSp = new cc.Sprite();
        this._routeSp.setPosition(38, midPos.y);
        this.addChild(this._routeSp, 1);

        // 路線上兩個固定的node
        this._steadyNode = [];
        for (let i = 0; i < 2; ++i) {
            var mapNode = new CardKingMapRouteNode();
            this.addChild(mapNode, 2);
            this._steadyNode.push(mapNode);
        }

        // 彎曲部分的control point, 上下兩個
        this._controlPointArray = [[], []];
    },

    refresh: function (idx, data, level) {
        this._nodeIdx = idx;

        // 更新這個人的type
        if (idx === 0)
            this._type = CardKingMapRouteCell.RouteType.FIRST;
        else
            // 單數的是part1, 扣掉第一個人 part1 -> part2 ->part1輪替
            this._type = (idx % 2) ? CardKingMapRouteCell.RouteType.PART1 : CardKingMapRouteCell.RouteType.PART2;

        // 中間位置
        var midPos = this._midPos = cc.p(CardKingMapRouteCell.getCellSizeByIndex(idx).width / 2, CardKingMapRouteCell.getCellSizeByIndex(idx).height / 2);

        // 路線圖的位置
        var routePos = cc.p(38, midPos.y);
        // 固定node的位置
        var nodePos = [cc.p(0, 0), cc.p(38, midPos.y)];

        // 先更新數字
        for (var i = 0; i < 2; ++i) {
            var round = 0;

            if (data)
                round = data[i].round;
            else
                round = DataModal.cardKingData.getMapNodeRoundByIndex(idx)[i];

            this._steadyNode[i].refresh(round, data && data[i], level);
        }

        // 再更新方向不然%數會不正確
        for (var i = 0; i < 2; ++i) {
            this._steadyNode[i].setBubbleDirection(this.getBubbleDirectionByRound(this._steadyNode[i].round));
        }

        if (idx === 0) {
            // 第一個跟大家不一樣要處理一下
            this._routeBgSp.setSpriteFrame("cardKing_pic_partPath01.png");
            this._routeSp.setSpriteFrame("cardKing_pic_partPath02.png");
            routePos = cc.p(72, midPos.y + 3);
            nodePos[0] = cc.p(61, midPos.y - 82);
            nodePos[1] = cc.p(61, midPos.y + 3);
            this._controlPointArray = [[], this.getArcBezierByAngle(90, 36, cc.p(98, midPos.y + 49), true, 90)];
        } else {
            // this._controlPointArray : 這裡先把曲線路徑算出來
            // nodePos : 固定節點的位置
            this._routeBgSp.setSpriteFrame("cardKing_pic_fullPath01.png");
            this._routeSp.setSpriteFrame("cardKing_pic_fullPath02.png");

            if (this._type === CardKingMapRouteCell.RouteType.PART1) {
                this._controlPointArray = [
                    this.getArcBezierByAngle(90, 36, cc.p(2, midPos.y + 49), true),
                    this.getArcBezierByAngle(90, 36, cc.p(74, midPos.y - 49), false, 180)
                ];
                nodePos[0] = cc.p(1, midPos.y + 85);
            } else {
                nodePos[1] = cc.p(38, midPos.y);
                nodePos[0] = cc.p(-1, midPos.y - 85);
                this._controlPointArray = [
                    this.getArcBezierByAngle(90, 36, cc.p(2, midPos.y - 49), false, 270),
                    this.getArcBezierByAngle(90, 36, cc.p(74, midPos.y + 49), true, 90)
                ];
            }
        }

        // part1要左右顛倒
        this._routeBgSp.setFlippedX(this._type === CardKingMapRouteCell.RouteType.PART1);
        this._routeSp.setFlippedX(this._type === CardKingMapRouteCell.RouteType.PART1);

        this._routeBgSp.setPosition(routePos);
        this._routeSp.setPosition(routePos);

        var routeColor = JSColor.WHITE;

        // 這條線顏色跟中間節點一樣
        switch (this._steadyNode[1].getColorType()) {
            // 藍色
            case CardKingData.MapRouteColorType.BLUE:
                routeColor = cc.color(51, 255, 255, 255);
                break;
            // 綠色
            case CardKingData.MapRouteColorType.GREEN:
                routeColor = cc.color(51, 255, 102, 255);
                break;
            // 紫色
            case CardKingData.MapRouteColorType.PURPLE:
                routeColor = cc.color(204, 102, 255, 255);
                break;
            // 桃紅
            case CardKingData.MapRouteColorType.PEACH_PINK:
                routeColor = cc.color(255, 102, 204, 255);
                break;
        }
        this._routeBgSp.setColor(routeColor);

        // 固定節點位置
        this._steadyNode[0].setPosition(nodePos[0]);
        this._steadyNode[1].setPosition(nodePos[1]);
    },

    // 拿到固定局數在這node長度上的百分之幾
    _getPercentageByRound: function (round) {
        var min = this._steadyNode[0].round;
        var mid = this._steadyNode[1].round;
        var max = DataModal.cardKingData.getMapNodeRoundByIndex(this._nodeIdx + 1)[0];

        // 先判斷一些簡單的
        if (round > max)
            return 1;
        else if (round < min)
            return 0;
        else if (round === mid)
            return 0.5;

        // 上下限的數值有可能不是等差, 所以拆成上半跟下半處理
        if (round > mid) {
            return 0.5 + (0.5 * ((round - mid) / (max - mid)));
        } else {
            return (0.5 * ((round - min) / (mid - min)));
        }
    },

    // 獲取特定局數在node上的位置
    __getPos: function (round) {
        // 如果剛好就是自己的節點有的就不用算了, 直接return
        if (round === this._steadyNode[0].round)
            return this._steadyNode[0].getPosition();
        else if (round === this._steadyNode[1].round)
            return this._steadyNode[1].getPosition();

        var percentage = this._getPercentageByRound(round);

        return this.__getPosByPercent(percentage);
    },

    // 獲取特定%數在node上的位置
    __getPosByPercent: function (percent) {
        // 如果剛好就是自己的節點有的就不用算了, 直接return
        if (percent === 0) {
            return this._steadyNode[0].getPosition();
        } else if (percent === 0.5) {
            return this._steadyNode[1].getPosition();
        }

        var midPos = this._midPos;

        // 只有固定四個位置0%, (25% - 50%), (50% - 75%), 100%
        if (percent < 0.5) {
            switch (this._type) {
                case CardKingMapRouteCell.RouteType.FIRST:
                    return cc.p(61, midPos.y - 40);
                case CardKingMapRouteCell.RouteType.PART1:
                    return cc.p(38, midPos.y + 49);
                case CardKingMapRouteCell.RouteType.PART2:
                    return cc.p(38, midPos.y - 49);
            }
        } else if (percent > 0.5 && percent < 1) {
            switch (this._type) {
                case CardKingMapRouteCell.RouteType.FIRST:
                    return cc.p(61, midPos.y + 49);
                case CardKingMapRouteCell.RouteType.PART1:
                    return cc.p(38, midPos.y - 49);
                case CardKingMapRouteCell.RouteType.PART2:
                    return cc.p(38, midPos.y + 49);
            }
        } else if (percent === 1) {
            if (this._type === CardKingMapRouteCell.RouteType.PART1)
                return cc.p(73, midPos.y - 85);
            else
                return cc.p(midPos.x + 1, midPos.y + 85);
        }
    },

    // 從x軸逆時鐘方向畫出一個弧
    getArcBezierByAngle: function (angle, radius, point, isClockwise = false, rotateAngle = 0) {
        angle = angle / 180 * Math.PI;
        // 旋轉是逆時針轉, 所以把角度反過來
        rotateAngle = -rotateAngle / 180 * Math.PI;

        var posArray = [];

        var cosAngle = Math.cos(angle);
        var sinAngle = Math.sin(angle);

        // 用來近似於圓弧的factor
        var factor = 4 * (1 - Math.cos(angle / 2)) / Math.sin(angle / 2) / 3;

        posArray.push(cc.p(radius, 0));
        posArray.push(cc.p(radius, factor * radius));
        posArray.push(cc.p(
            radius * (cosAngle + factor * sinAngle),
            radius * (sinAngle - factor * cosAngle)
        ));
        posArray.push(cc.p(
            radius * cosAngle,
            radius * sinAngle
        ));

        // 旋轉矩陣, 先旋轉一定角度再移到座標圓心上
        var rotateMatrix = [[Math.cos(rotateAngle), Math.sin(rotateAngle)], [-Math.sin(rotateAngle), Math.cos(rotateAngle)]];

        for (var i = 0; i < 4; ++i) {
            var oriPos = cc.p(posArray[i].x, posArray[i].y);

            posArray[i].x = oriPos.x * rotateMatrix[0][0] + oriPos.y * rotateMatrix[0][1] + point.x;
            posArray[i].y = oriPos.x * rotateMatrix[1][0] + oriPos.y * rotateMatrix[1][1] + point.y;
        }
        return isClockwise ? posArray.reverse() : posArray;
    },

    // 要傳給外部使用, 所以傳世界座標
    getPosByRound: function (round) {
        return this.convertToWorldSpace(this.__getPos(round));
    },

    // 要傳給外部使用, 所以傳世界座標
    getPosByPercent: function (percent) {
        return this.convertToWorldSpace(this.__getPosByPercent(percent));
    },

    // 獲取特定%數要把泡泡匡擺在哪裡
    getBubbleDirectionByPercent: function (percent) {
        if (this._type === CardKingMapRouteCell.RouteType.FIRST) {
            if (percent === 1)
                return BaseMessageNode.Direct.UP;
            if (percent <= 0.5)
                return BaseMessageNode.Direct.LEFT;
            else
                return BaseMessageNode.Direct.RIGHT;
        }

        if (this._type === CardKingMapRouteCell.RouteType.PART1) {
            if (percent === 0)
                return BaseMessageNode.Direct.UP;

            if (percent <= 0.5)
                return BaseMessageNode.Direct.LEFT;
            else if (percent < 1)
                return BaseMessageNode.Direct.RIGHT;
            else
                return BaseMessageNode.Direct.DOWN;
        }

        if (this._type === CardKingMapRouteCell.RouteType.PART2) {
            if (percent === 0)
                return BaseMessageNode.Direct.DOWN;

            if (percent <= 0.5)
                return BaseMessageNode.Direct.LEFT;
            else if (percent < 1)
                return BaseMessageNode.Direct.RIGHT;
            else
                return BaseMessageNode.Direct.UP;
        }
    },

    // 同上, 只是傳入的參數是局數
    getBubbleDirectionByRound: function (round) {
        return this.getBubbleDirectionByPercent(this._getPercentageByRound(round));
    },

    // 給定新舊分數, 來這個cell要跑的位置
    // 這裡把這條路線分成四份, 分別為 第一轉彎部分, 第一直線, 第二直線, 第二轉彎
    getAnimationByRound: function (oldRound, newRound, coordinateConvertObj, runningObj) {
        var oldPercent = this._getPercentageByRound(oldRound);
        var newPercent = this._getPercentageByRound(newRound);

        // 轉換位置的一些function
        var convertPosFunc = coordinateConvertObj.convertToNodeSpace.bind(coordinateConvertObj);
        var convertToWorldFunc = this.convertToWorldSpace.bind(this);

        // 節點在跑的時候要做的事情
        var changColorFunc = function () {
        };
        var changeDirFunc = function () {
        };

        // 用來換顏色的
        if (runningObj.setColorType)
            changColorFunc = runningObj.setColorType.bind(runningObj);

        // 用來換方向
        if (runningObj.setBubbleDirection)
            changeDirFunc = runningObj.setBubbleDirection.bind(runningObj);

        // 曲線的controlPoint不需要第一個 => 因為用的是By
        var worldPosControlPoints = this._controlPointArray.map(cur => {
            return cur.map(innerCur => convertPosFunc(convertToWorldFunc(innerCur))).slice(1);
        });

        // 要近sequence的東西
        var actionArray = [];

        // 位置不一樣才需要跑
        if (!cc.pointEqualToPoint(this.__getPos(oldRound), this.__getPos(newRound))) {
            if (oldPercent === 0) {
                changColorFunc(this._steadyNode[0].getColorType());

                changeDirFunc(this.getBubbleDirectionByPercent(0));

                if (this._type === CardKingMapRouteCell.RouteType.FIRST) {
                    actionArray.push(cc.moveTo(CardKingMapRouteCell.AnimationTime.LINEAR / 3, convertPosFunc(this.getPosByPercent(0.25))));
                } else {
                    actionArray.push((cc.bezierTo(CardKingMapRouteCell.AnimationTime.CURVE / 2, worldPosControlPoints[0])));
                }

                if (newPercent < 0.5) {
                    actionArray.push(cc.callFunc(() => changeDirFunc(this.getBubbleDirectionByPercent(0.25))));
                    return cc.sequence(actionArray);
                }
            }

            // 要是需要跑第一直線部分
            if (newPercent >= 0.5 && oldPercent < 0.5) {
                var timeFactor = 2;
                if (this._type === CardKingMapRouteCell.RouteType.FIRST)
                    timeFactor = 3;

                actionArray.push(cc.moveTo(CardKingMapRouteCell.AnimationTime.LINEAR / timeFactor, convertPosFunc(this.getPosByPercent(0.5))));

                actionArray.push(cc.callFunc(() => changColorFunc(this._steadyNode[1].getColorType())));

                actionArray.push(cc.callFunc(() => changeDirFunc(this.getBubbleDirectionByPercent(0.5))));

                if (newPercent === 0.5)
                    return cc.sequence(actionArray);
            }

            // 要是需要跑第二直線部分
            if (newPercent > 0.5 && oldPercent <= 0.5) {
                var timeFactor = 2;
                if (this._type === CardKingMapRouteCell.RouteType.FIRST)
                    timeFactor = 3;

                actionArray.push(cc.moveTo(CardKingMapRouteCell.AnimationTime.LINEAR / timeFactor, convertPosFunc(this.getPosByPercent(0.75))));

                if (newPercent !== 1) {
                    actionArray.push(cc.callFunc(() => changeDirFunc(this.getBubbleDirectionByPercent(0.75))));
                    return cc.sequence(actionArray);
                }
            }

            // 跑第二轉彎部分
            if (newPercent === 1) {
                actionArray.push(cc.callFunc(() => changeDirFunc(this.getBubbleDirectionByPercent(1))));

                actionArray.push((cc.bezierTo(CardKingMapRouteCell.AnimationTime.CURVE / 2, worldPosControlPoints[1])));
            }
        }

        // 收尾
        if (actionArray.length)
            return cc.sequence(actionArray);

        // 防呆
        return cc.callFunc(() => {
        });
    },

    // 特定round有沒有停在固定節點上
    getRoundIsOnSteadyNode: function (round) {
        return (this._steadyNode[0].round === round) || (this._steadyNode[1].round === round);
    },

    // 確認是否要藏steadyNode
    checkSteadyNodeNeedToHide: function (round) {
        this._steadyNode[0].setBubbleVisible(this._steadyNode[0].round !== round);
        this._steadyNode[1].setBubbleVisible(this._steadyNode[1].round !== round);
    }
});

// 此cell的資訊
CardKingMapRouteCell.getCellSizeByIndex = function (idx) {
    // 第一個人要比較胖
    if (idx === 0) {
        return cc.size(96, 210 + JSScreenBonusHeight);
    }
    return cc.size(72, 210 + JSScreenBonusHeight);
};

// 路線的類別
CardKingMapRouteCell.RouteType = {
    NONE: -1,
    FIRST: 0,       // 第一個
    PART1: 1,       // 左邊(需要左右翻轉)
    PART2: 2        // 右邊
};

// 做動畫需要的時間
CardKingMapRouteCell.AnimationTime = {
    CURVE: 0.4,     // 曲線
    LINEAR: 0.6,    // 直線
};