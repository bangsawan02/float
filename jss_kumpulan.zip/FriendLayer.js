/**
 * 好友 主頁面
 */
var FriendLayer = cc.Layer.extend({
    ctor: function (tabNum) {
        this._super();

        this._pageArray = [];           // 設定頁的下方頁面
        this._titleTabItems = [];

        // 加一個Loading
        var loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(JSScreenMidPos);
        loadingSprite.start();
        this.addChild(loadingSprite);

        var resources = ["friend/friend.plist", "friend/friend.png"];

        // 加Icon的Function
        var addIconFun = (tabNum) => {
            // 讀取Plist
            cc.spriteFrameCache.addSpriteFrames(resources[0], resources[1]);

            this.removeAllChildren();

            // 背景
            var bgSprite = new cc.Sprite(SelectGameManager.getNowGameFile("lobby_background.jpg"));
            // 背景給他變黑一點
            bgSprite.setColor(cc.color(150, 150, 150));
            bgSprite.setPosition(JSScreenMidPos);
            this.addChild(bgSprite);

            // 上方文字底
            var titleNode = new TitleBackgroundNode("#friend_word_title.png");
            titleNode.setPosition(JSScreenMidPos.x, JSVisibleSize.height - TITLE_BG_HEIGHT / 2);
            titleNode.setTitlePosition(0, 2);
            this.addChild(titleNode, 10);

            // 列表的背景
            var tableBgSp = new ccui.Scale9Sprite("lobby_bg_window.png");
            tableBgSp.setPreferredSize(cc.size(FriendLayer.WIDTH, JSVisibleSize.height - TITLE_BG_HEIGHT));
            tableBgSp.setAnchorPoint(0, 0);
            tableBgSp.setPosition(115 + JSScreenBonusHalfWidth, -10);
            tableBgSp.setOpacity(127);
            this.addChild(tableBgSp);

            // 列表標題的背景
            var topBgSp = new ccui.Scale9Sprite("friend_top_bg.png");
            topBgSp.setPreferredSize(cc.size(384, 26));
            topBgSp.setPosition(310 + JSScreenBonusHalfWidth, JSVisibleSize.height - TITLE_BG_HEIGHT - 13);
            this.addChild(topBgSp);

            var menu = new cc.Menu();
            menu.setPosition(0, 0);
            this.addChild(menu);

            var titles = ["好友清單", "找好友", "申請列表"];
            var btnImages = ["lobby_btn_purchase_01.png", "lobby_btn_purchase_01.png", "lobby_btn_01.png"];
            var iconImages = ["#lobby_icon_friend.png", "#lobby_icon_add_friend.png", "#friend_btn_ application.png"];
            var btnSize = cc.size(108, 32);
            var btnMidPosY = btnSize.height / 2;
            var posY = JSVisibleSize.height - TITLE_BG_HEIGHT;
            for (var i = 0; i < titles.length; i++) {
                var itemNodes = [];
                for (var j = 0; j < 3; j++) {
                    var itemNode = itemNodes[j] = new ccui.Scale9Sprite(btnImages[j]);
                    itemNode.setPreferredSize(btnSize);

                    var iconSp = new cc.Sprite(iconImages[i]);
                    iconSp.setPosition(19, btnMidPosY);
                    itemNode.addChild(iconSp);

                    var titleLabel = new cc.LabelTTF(LocalizedString.Friend(titles[i]), JSFontBoldName, 10);
                    titleLabel.setAnchorPoint(0, 0.5);
                    titleLabel.setPosition(39, btnMidPosY);
                    itemNode.addChild(titleLabel);
                }

                var menuItem = this._titleTabItems[i] = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._titleTabClicked, this);
                menuItem.setAnchorPoint(0, 1);
                menuItem.setPosition(5 + JSScreenBonusHalfWidth, posY);
                menu.addChild(menuItem);

                posY -= 34;
            }

            this.notifyUpdateFriendBadge();

            var choseTab = (tabNum) ? tabNum : 0;
            this._titleTabClicked(this._titleTabItems[choseTab]);

            // 第一次進入
            var str = JSStringUtility.format("%s_firstFriend", DataModal.profileData.account);
            var isFirst = parseInt(GS.localStorage.getItem(str, 1));
            if (isFirst && DataModal.profileData.level >= 2) {
                DataModal.friendData.redPoint.icon = false;
                GS.localStorage.setItem(str, "0");
                GS.dispatchCustomEvent("NotifyApplyFriendListDone");
            }
        };

        if (cc.sys.isNative || cc.textureCache.getTextureForKey(resources[1])) {
            addIconFun(tabNum);
        } else {
            // H5要先Loader
            cc.loader.load(resources, function () {
                addIconFun(tabNum);
            });
        }

        // 監聽
        GS.addListener("NotifyShowFindFriendTab", this.notifyShowFindFriendTab.bind(this), this);
        GS.addListener("NotifyShowFriendChat", this.notifyShowFriendChat.bind(this), this);
        GS.addListener("NotifyFriendLayerShowHintNode", this.notifyFriendLayerShowHintNode.bind(this), this);
        // 小紅點的監聽
        GS.addListener("NotifyApplyFriendListDone", this.notifyUpdateFriendBadge.bind(this), this);
        GS.addListener("NotifyFriendChangeDone", this.notifyUpdateFriendBadge.bind(this), this);
    },

    onEnter: function () {
        this._super();

        // 需要更新任務 55.進好友頁面
        DataProcess.sendString("growMission_update 55");

        // 埋點 1:進好友介面
        DataProcess.sendString("track_mixFriend 1");
    },

    onExit: function () {
        // 更新大廳熱門看板
        DataModal.hotBoardData.startGetInfo();

        this._super();
    },

    /**
     * 頁籤上show 小紅點
     * @param type   哪個頁籤
     * @param isShow 要不要show小紅點
     * @private
     */
    _showBadge: function (type, isShow) {
        this._badgeNodeMap = this._badgeNodeMap ?? {};

        if (!this._badgeNodeMap[type]) {
            let badge = this._badgeNodeMap[type] = new BadgeNode();
            badge.useDefaultStyle();
            badge.setPosition(cc.pAdd(this._titleTabItems[type].getPosition(), cc.p(5 - JSScreenSafeWidth, -5)));
            this.addChild(badge);
        }

        this._badgeNodeMap[type].setVisible(isShow);
    },

    /**
     * 按到上方Title Tab
     */
    _titleTabClicked: function (sender) {
        var clickedPos = 0;
        for (var i = 0; i < this._titleTabItems.length; i++) {
            if (sender === this._titleTabItems[i]) {
                clickedPos = i;
            }
            this._titleTabItems[i].setEnabled(true);

            // 把其他頁面關掉
            var page = this._pageArray[i];
            page && page.setVisible(false);
        }
        sender.setEnabled(false);

        //埋點 3:點進好友清單 4:點進找好友 5:點進申請列表
        var obj = {type: 3 + clickedPos};
        DataProcess.sendString("mixFriend_icon_log " + JSON.stringify(obj));

        var thisPage = this._pageArray[clickedPos];
        if (thisPage) {
            thisPage.setVisible(true);
        } else {
            switch (clickedPos) {
                case 0:
                    // 好友清單
                    thisPage = this._pageArray[clickedPos] = new FriendListLayer();
                    this.addChild(thisPage);
                    break;
                case 1:
                    // 找好友
                    thisPage = this._pageArray[clickedPos] = new FindFriendLayer();
                    this.addChild(thisPage);
                    break;
                case 2:
                    // 申請列表
                    thisPage = this._pageArray[clickedPos] = new ApplyFriendListLayer();
                    this.addChild(thisPage);
                    break;
            }
        }
    },

    /**
     *  通知點選找好友的頁籤
     */
    notifyShowFindFriendTab: function () {
        this._titleTabClicked(this._titleTabItems[1]);
    },

    /**
     *  通知打開好友聊天界面
     */
    notifyShowFriendChat: function (event) {
        if (!event || !event.getUserData())
            return;

        var param = event.getUserData();
        // 設定聊天室的資料
        DataModal.chatRoomData.checkHaveChatList(param.UID, param.userID, param.nickname);

        if (this._chatLayer) {
            // 打開聊天頁面
            this._chatLayer.openChatPage();
            return;
        }

        var from = ChatRoomFromType.FRIEND_LIST;
        var page = ChatRoomPageType.CHAT;
        var chatLayer = this._chatLayer = new ChatRoomLayer(from, page);
        this.addChild(chatLayer, 100);
    },

    /**
     * 浮現黑底的提示
     */
    notifyFriendLayerShowHintNode: function (event) {
        var param = event.getUserData();
        if (!param)
            return;

        if (!this._hintMsgNode) {
            var hintMsgNode = this._hintMsgNode = new FriendHintNode();
            hintMsgNode.setPosition(JSScreenMidPos);
            this.addChild(hintMsgNode, 1000);
        }
        this._hintMsgNode.showHint(param.msg);
    },

    /**
     *  通知刷新小紅點
     */
    notifyUpdateFriendBadge: function () {
        // 申請列表的小紅點
        var isShowBadge = DataModal.friendData.redPoint.apply;
        this._showBadge(2, isShowBadge);
    }
});

FriendLayer.WIDTH = 390;