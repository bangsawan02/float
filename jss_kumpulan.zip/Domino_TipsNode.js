var Domino_TipsBtnStatus = {
    CLOSE: 0,       // 關閉都看不到
    INIT: 1,        // 初始化
    NORMAL: 2,      // 一般狀態
    FINAL: 3,       // 分紅
};

var Domino_TipsNode = cc.Node.extend({
    ctor: function () {
        this._super();

        this._menuItemArray = [];       // 0:普通小費案紐 1:分紅按鈕

        var btnSize = cc.size(52, 18);
        var color = [JSColor.WHITE, JSColor.WHITE, JSColor.WHITE];

        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        this.addChild(menu);

        // 普通小費案紐
        var itemNodes = ButtonUtility.createArrayScale9Nodes(["lobby_btn_03.png", "lobby_btn_03.png", "lobby_btn_03.png"], btnSize, LocalizedString.Game("送小費"), 9, color);
        itemNodes[2].setOpacity(255);
        itemNodes[2].setColor(JSColor.GRAY);
        var itemMenu = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._sendTipsClicked, this);
        menu.addChild(itemMenu);
        this._menuItemArray.push(itemMenu);

        // 分紅按鈕
        var itemNodes2 = ButtonUtility.createArrayScale9Nodes(["lobby_btn_02.png", "lobby_btn_02.png", "lobby_btn_02.png"], btnSize, LocalizedString.Game("分紅"), 9, color);
        itemNodes2[2].setOpacity(255);
        itemNodes2[2].setColor(JSColor.GRAY);
        var itemMenu2 = new cc.MenuItemSprite(itemNodes2[0], itemNodes2[1], itemNodes2[2], this._sendTipsClicked, this);
        itemMenu2.setVisible(false);
        menu.addChild(itemMenu2);
        this._menuItemArray.push(itemMenu2);
    },

    /**
     * 送出小費
     * @private
     */
    _sendTipsClicked: function (sender) {
        // 先把按下的按鈕關掉
        sender.setEnabled(false);

        // 送出小費cmd
        if (this._nowStatus > 0) {
            DataProcess.sendString('moneymonster ' + DataModal.gameData.myPos + ' ' + (this._nowStatus - 1));

            // 就算Server沒有送結束Cmd也要自己一段時間後打開
            var actionTag = 2571;
            var action = cc.sequence(
                cc.delayTime(5),
                cc.callFunc(function () {
                    sender.setEnabled(true);
                })
            );
            action.setTag(actionTag);
            this.stopActionByTag(actionTag);
            this.runAction(action);
        }
    },

    /**
     * 抓現在的狀態
     */
    getNowStatus: function () {
        return this._nowStatus;
    },

    /**
     * 設定狀態
     * @param status
     */
    setTipsStatus: function (status) {
        // 先不加分紅
        if (status === Domino_TipsBtnStatus.FINAL) {
            status = Domino_TipsBtnStatus.NORMAL;
        }

        // 設定現在狀態
        this._nowStatus = status;

        // visible false表示沒開啟這功能 不做事
        if (!this.isVisible())
            return;

        switch (status) {
            // 關閉都看不到
            case Domino_TipsBtnStatus.CLOSE:
                this._menuItemArray.forEach(cur => cur.setVisible(false));
                break;

            // 初始化
            case Domino_TipsBtnStatus.INIT:
                if (DataModal.gameData.myPos !== -1) {
                    // 代表在位置上 當做他是送小費
                    this.setTipsStatus(Domino_TipsBtnStatus.NORMAL);
                } else {
                    // 不在位置上
                    return;
                }
                break;

            // 一般狀態 要出現送小費
            case Domino_TipsBtnStatus.NORMAL:
                this._menuItemArray.forEach(function (cur, index) {
                    cur.setVisible(index === 0);
                    cur.setEnabled(index === 0);
                });

                // 砍掉之前delay的Action
                this.stopActionByTag(2571);
                break;

            // 分紅
            case Domino_TipsBtnStatus.FINAL:
                this._menuItemArray.forEach(function (cur, index) {
                    cur.setVisible(index === 1);
                    cur.setEnabled(index === 1);
                });
                break;
        }
    },
});