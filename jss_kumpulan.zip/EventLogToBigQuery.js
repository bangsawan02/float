var EventLogToBigQuery = {};

(function () {
    // 要打哪一個URL 例如https://log2.gamesofa.com/_mktapi2/ 此系統會自動加上"?"
    var _baseURL = "https://log2.gamesofa.com/_mktapi2/";
    // 哪一個BigQuery的Table
    var _table = "";

    // 使用者帳號
    var _userid = "";
    // 機碼
    var _machineID = GSDeviceWrapper.getUUID();
    // 國家
    var _country = GSDeviceWrapper.getCountry();
    // 語言
    var _language_of_device = GSDeviceWrapper.getLanguage();
    // 原生遊戲版本
    var _native_app_version = cc.sys.isNative ? GSDeviceInfo.getGameVersion() : "";
    // 系統名稱 AndroidPhone、AndroidPad、iPhone
    var _os_name = "";
    // 系統版本
    var _os_version = GSDeviceWrapper.getDeviceVersion();
    // 遊戲版本
    var _core_version = "";
    // 手機型號
    var _phone_model = GSDeviceWrapper.getDeviceManufacturerAndModel();
    // Bundle ID
    var _bundle_id = "";
    // 原生 Bundle ID 沒有的話會帶 _bundle_id
    var _native_bundle_id = cc.sys.isNative ? GSDeviceInfo.getBundleID() : "";
    // 設定遊戲Type
    var _game_type = 0;

    /**
     * 設定要連線的 BigQuery 的 URL
     */
    EventLogToBigQuery.setBaseURL = function (baseURL) {
        _baseURL = baseURL;
    };

    /**
     * 設定要打的 BigQuery 的 Table
     */
    EventLogToBigQuery.setTable = function (table) {
        _table = table;
    };

    /**
     * 設定參數UserID
     */
    EventLogToBigQuery.setUserID = function (userID) {
        _userid = userID;
    };

    /**
     * 設定系統名稱 AndroidPhone、AndroidPad、iPhone
     */
    EventLogToBigQuery.setOSName = function (osName) {
        _os_name = osName;
    };

    /**
     * 設定遊戲版本
     */
    EventLogToBigQuery.setGameVersion = function (coreVersion) {
        _core_version = coreVersion;
    };

    /**
     * 設定遊戲Type 2, 3, 5, 7, 8, 13, 20, 60, 62, 38, 99
     */
    EventLogToBigQuery.setGameType = function (gameType) {
        _game_type = gameType;
    };

    /**
     * 更新基本參數 有些沒有的要自行跑set來更新
     */
    EventLogToBigQuery.updateParamValue = function () {
        _os_name = GS.platform;
        _core_version = GS.gameVersion;
        _game_type = GS.isLuxyPoker ? "38" : "99";
        _bundle_id = GS.bundleID || GS.nativeBundleID;

        // Table name
        _table = "event_log_" + _game_type;
    };

    /**
     * 記錄一筆事件到 BigQuery
     */
    EventLogToBigQuery.logEvent = function (campaign_id, action_log_id, customObj = {}) {
        EventLogToBigQuery.logEventWithTable(campaign_id, _table, action_log_id, customObj);
    };

    /**
     * 記錄一筆事件到 BigQuery
     */
    EventLogToBigQuery.logEventWithCampaignId = function (campaign_id, eventName, action_log_id, customObj = {}) {
        customObj.event_name = eventName;
        EventLogToBigQuery.logEventWithTable(campaign_id, _table, action_log_id, customObj);
    };

    EventLogToBigQuery.logEventWithTable = function (campaign_id, table, action_log_id, customObj = {}) {
        if (!_baseURL || SlotTestMode)
            return;

        const mergedObj = Object.assign({}, {
            table: table,
            campaign_id: campaign_id,
            action_log_id: action_log_id,
            action_log_value: 0,
            game_type: _game_type,

            userid: _userid,
            machineID: _machineID,
            country: _country,
            language_of_device: _language_of_device,
            native_app_version: _native_app_version,
            os_name: _os_name,
            os_version: _os_version,
            ctime: Math.floor(new Date().getTime() / 1000),
            core_version: _core_version,
            phone_model: _phone_model,
            bundle_id: _bundle_id,
            native_bundle_id: _native_bundle_id || _bundle_id,
        }, customObj);
        const urlParam = Object.keys(mergedObj)
            .map(key => {
                const objValue = mergedObj[key];
                if (typeof objValue === "object" && objValue !== null) {
                    const pairs = Object.entries(objValue)
                        .map(([subKey, subVal]) => encodeURIComponent(subKey) + ":" + encodeURIComponent(subVal ?? null));
                    return encodeURIComponent(key) + "={" + pairs.join(",") + "}";
                }
                return encodeURIComponent(key) + "=" + encodeURIComponent(objValue ?? null);
            })
            .join("&");
        const url = _baseURL + "?" + urlParam;

        // Log
        cc.log("[GSEventLogToBigQuery] Logging: " + JSStringUtility.format("%s %s %s %s", campaign_id, customObj.event_name, action_log_id, url));

        axios.get(url)
            .then(_ => {
                // cc.log("[GSEventLogToBigQuery] Event logged successfully:", mergedObj);
            })
            .catch(error => {
                cc.error("[GSEventLogToBigQuery] Error logging event:", error);
            });
    };
})();