/**
 * v5.4.4 FreeChip - Cell
 * created by lichieh on 2022/9/23
 */
var FreeChipCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        // 下載使用
        this._hotFixHelper = undefined;

        // icon
        var midY = 23;
        var iconSp = this._iconSp = new cc.Sprite();
        iconSp.setPosition(24, midY);
        this.addChild(iconSp);

        // 額外顯示的node
        var bonusShowNode = this._bonusShowNode = new cc.Node();
        bonusShowNode.setPosition(24, midY);
        this.addChild(bonusShowNode);

        // 分隔線
        var lineSprite = new ccui.Scale9Sprite("lobby_division_line.png");
        lineSprite.setPreferredSize(cc.size(330, 2));
        lineSprite.setPosition(182, 3);
        this.addChild(lineSprite);

        // 標題
        var title = this._title = new cc.LabelTTF("", JSFontBoldName, 12);
        title.setFontFillColor(JSColor.YELLOW2);
        title.setAnchorPoint(0, 0.5);
        title.setPosition(50, 38);
        this.addChild(title);

        // 說明
        var desc = this._desc = new cc.LabelTTF("", JSFontBoldName, 10);
        desc.setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
        desc.setAnchorPoint(0, 0.5);
        desc.setPosition(50, 20);
        this.addChild(desc);

        // go按鈕
        var goBtn = this._goBtn = ButtonUtility.createSimpleButton("lobby_btn_03.png", cc.size(45, 24), "GO", JSColor.WHITE, 10);
        goBtn.addTouchUpInsideAction(this._goBtnClicked, this);
        goBtn.setPosition(335, midY + 3);
        this.addChild(goBtn);
    },

    onExit: function () {
        // 刪除下載的素材
        if (this._hotFixHelper) {
            this._hotFixHelper.removeLoadFileArray();
            this._hotFixHelper.destroy();
        }

        this._super();
    },

    refreshCell: function (param, curPage, isChip) {
        this._param = param;
        this._curPage = curPage;
        this._isChip = isChip;

        this.setVisible(false);

        if (!param)
            return;

        // 檢查要不要熱更
        if (!this._checkIsNeedHotFix(param.icon)) {
            // 不用熱更 直接刷新
            this._refreshView();
        }
    },

    /**
     * 刷新畫面
     */
    _refreshView: function () {
        var param = this._param;
        var curPage = this._curPage;
        var isChip = this._isChip;

        var iconParam = this._getIconParam(param);
        if (!iconParam || !iconParam.image)
            return;

        // 小紅點是否顯示
        this._setBadgeVisible(param.isBadgeVisible);

        // icon的圖片
        var iconSp = this._iconSp;
        iconSp.setSpriteFrame(iconParam.image);
        iconSp.setVisible(true);

        // 先清掉額外顯示
        this._bonusShowNode.removeAllChildren();

        this._countDownNode && this._countDownNode.setVisible(false);

        var isCanGetReward = false;
        switch (param.icon) {
            case FreeChipListType.CALLBACK_MISSION:
                // 回流任務需要顯示剩餘時間
                // 抓資料
                var returnMissionData = DataModal.returnMissionData;
                var remainTime = returnMissionData.countdownTime - (JSCodeUtility.getNowTime() - returnMissionData.socketTime);
                if (remainTime > 0) {
                    if (!this._countDownNode) {
                        // 倒數時間的node
                        var countDownNode = this._countDownNode = new cc.Node();
                        countDownNode.setCascadeColorEnabled(true);
                        countDownNode.setPosition(24, 23);
                        this.addChild(countDownNode);

                        // 倒數時間背景
                        var countDownBgSprite = new ccui.Scale9Sprite("lobby_icon_textBg.png");
                        countDownBgSprite.setPreferredSize(cc.size(38, 13));
                        countDownNode.addChild(countDownBgSprite);

                        // 倒數時間
                        var countDownLabel = this._countDownLabel = new GSTimeLabel("", JSFontBoldName, 8);
                        countDownLabel.setMultiFormat("%dd:%hh:%mm", "%hh:%mm:%ss");
                        countDownNode.addChild(countDownLabel);
                    }
                    this._countDownNode.setVisible(true);
                    this._countDownLabel.countdownSeconds(remainTime, () => {
                        // 隱藏倒數
                        this._countDownNode.setVisible(false);

                        // 重要資料
                        DataModal.returnMissionData.startGetInfo();
                    });
                }
                break;

            case FreeChipListType.LUCKY_DICE_COLLECTION:
                // 幸運集集樂大廳沒Icon更新活動時間，這邊要自己倒數更新
                // 抓資料
                var luckyDiceIconParam = DataModal.luckyDiceCollectionData.iconParam;
                var remainTime = JSCodeUtility.getRemainTime(luckyDiceIconParam.remainTime, luckyDiceIconParam.socketTime);
                if (remainTime > 0) {
                    if (!this._countDownNode) {
                        // 倒數時間的node(不顯示)
                        var countDownNode = this._countDownNode = new cc.Node();
                        countDownNode.setCascadeColorEnabled(true);
                        countDownNode.setPosition(24, 23);
                        this.addChild(countDownNode);

                        // 倒數時間
                        var countDownLabel = this._countDownLabel = new GSTimeLabel("", JSFontBoldName, 8);
                        countDownLabel.setMultiFormat("%dd:%hh:%mm", "%hh:%mm:%ss");
                        countDownNode.addChild(countDownLabel);
                    }
                    this._countDownNode.setVisible(false);
                    this._countDownLabel.countdownSeconds(remainTime, () => {
                        // 重拿Icon資料
                        DataModal.luckyDiceCollectionData.startGetIconInfo();
                    });
                }
                break;

            case FreeChipListType.UPDATE_VERSION_BONUS:
                // 版本更新獎勵
                isCanGetReward = DataModal.settingData.canGetUpdateBonus;
                break;

            case FreeChipListType.FACEBOOK_FAN:
                // 粉絲團按讚
                var fbFanInfo = DataModal.freeChipsData.fbFanInfo;

                if (!this._timeNode) {
                    var timeNode = this._timeNode = new GSTimerNode();
                    this.addChild(timeNode);
                }

                var remainTime = JSCodeUtility.getRemainTime(fbFanInfo.remainTime, fbFanInfo.socketTime);
                this._timeNode.countdownSeconds(remainTime, () => {
                    // fid時間到先把UI關掉
                    fbFanInfo.isOpen = false;
                    DataModal.freeChipsData.refreshAvailableList();

                    // 重要FB粉絲專頁資料
                    DataProcess.sendString("fan_page_status");
                });

                isCanGetReward = fbFanInfo.rewardStatus === FreeChipsData.FacebookFanStatus.CAN_REWARD;
                break;
        }

        // icon上的額外顯示
        switch (param.icon) {
            case FreeChipListType.TOKEN_SUBSYSTEM:
                // 有使用中的加速器的話要有動畫
                var speederTime = DataModal.tokenSubsystemData.getSpeederUsingRemainTime();
                if (speederTime) {
                    // Spine檔案
                    var spineArray = [
                        "spine/TokenSubsystem/speeder/skeleton-1.json",
                        "spine/TokenSubsystem/speeder/skeleton-1.atlas",
                        "spine/TokenSubsystem/speeder/skeleton-1.png",
                        "spine/TokenSubsystem/speeder/skeleton-2.json",
                        "spine/TokenSubsystem/speeder/skeleton-2.atlas",
                        "spine/TokenSubsystem/speeder/skeleton-2.png",
                    ];

                    // 顯示加速中動畫
                    var addSpineAnimation = () => {
                        // 外圍閃電
                        var spineAnim = new sp.SkeletonAnimation(spineArray[0], spineArray[1], 0.25);
                        spineAnim.setAnimation(0, "animation", true);
                        spineAnim.setPositionY(2);
                        this._bonusShowNode.addChild(spineAnim);

                        // 中間閃光
                        spineAnim = new sp.SkeletonAnimation(spineArray[3], spineArray[4], 0.25);
                        spineAnim.setAnimation(0, "animation", true);
                        spineAnim.setPositionY(2);
                        this._bonusShowNode.addChild(spineAnim);

                        // 時間到砍掉動畫
                        var timerNode = new GSTimerNode();
                        timerNode.countdownSeconds(speederTime, () => {
                            this._bonusShowNode.removeAllChildren();
                        });
                        this.addChild(timerNode);
                    };

                    if (!cc.sys.isNative) {
                        // H5要先去讀
                        cc.loader.load(spineArray, () => {
                            addSpineAnimation();
                        });
                    } else {
                        // 原生不用讀
                        addSpineAnimation();
                    }
                }
                break;
        }

        // 刷新按鈕樣式
        var btnSize = cc.size(45, 24);
        if (isCanGetReward) {
            this._goBtn.bg.setSpriteFrame("lobby_btn_01.png");
            this._goBtn.label.setString(LocalizedString.Purchase("領獎"));
            this._goBtn.label.setFontFillColor(JSColor.BLACK);
        } else {
            this._goBtn.bg.setSpriteFrame("lobby_btn_03.png");
            this._goBtn.label.setString("GO");
            this._goBtn.label.setFontFillColor(JSColor.WHITE);
        }
        this._goBtn.bg.setPreferredSize(btnSize);

        // 標題
        this._title.setString(iconParam.title);

        // 說明
        var tabValue;
        switch (curPage) {
            case FreeChipDialog.Page.PLAY:
                // 頁籤玩牌
                tabValue = iconParam.tabPlay;
                break;

            case FreeChipDialog.Page.LOGIN:
                // 頁籤簽到&登入
                tabValue = iconParam.tabLogin;
                break;

            case FreeChipDialog.Page.MISSION:
                // 頁籤任務
                tabValue = iconParam.tabMission;
                break;

            case FreeChipDialog.Page.EVENT:
                // 頁籤限時任務
                tabValue = iconParam.tabEvent;
                break;

            case FreeChipDialog.Page.VIP:
                // 頁簽VIP
                tabValue = iconParam.tabVip;
                break;

            case FreeChipDialog.Page.CHANGE:
                // 頁簽兌換
                tabValue = iconParam.tabChange;
                break;
        }
        // 說明
        var descString = tabValue && tabValue[(isChip) ? "chipDesc" : "currencyDesc"];
        this._desc.setString(descString || "");

        this.setVisible(true);
    },

    /**
     * 設定要不要顯示小紅點
     */
    _setBadgeVisible: function (isVisible) {
        var badge = this._badge;

        // 需要顯示但是還沒加過小紅點 先加小紅點
        if (isVisible && !badge) {
            badge = this._badge = new BadgeNode();
            badge.useDefaultStyle();
            badge.setPosition(356, 35.5);
            this.addChild(badge, 1);
        }
        badge && badge.setVisible(isVisible);
    },

    /**
     * 檢查要不要熱更
     * @param type {FreeChipListType} 免費幣類型
     * @return {boolean} 是否為熱更
     */
    _checkIsNeedHotFix: function (type) {
        // 設定參數
        var bundleName, bundleType, loadFileArray;
        switch (type) {
            case FreeChipListType.VEGAS_MAP_MISSION:
                // 49: 地圖式機台任務
                bundleName = "VegasMapMission";
                bundleType = HotfixTool.BundleType.SUBSYSTEM;
                loadFileArray = ["download/subSystem/VegasMapMission/vegasMapMission_download.plist", "download/subSystem/VegasMapMission/vegasMapMission_download.png"];
                break;
            default:
                break;
        }

        // 確保每一次下載，都是指定到目前的cell
        if (this._hotFixHelper) {
            this._hotFixHelper.destroy();
            this._hotFixHelper = undefined;
        }

        if (bundleName && bundleName.length) {
            this._hotFixHelper = new HotFixHelper({
                bundleName: bundleName,
                bundleType: bundleType,
                loadFileArray: loadFileArray,
                onSynchronizeSuccess: this._refreshView.bind(this),
                onSynchronizeFail: null // 下載失敗不需處理，原來就不會看到icon
            });

            // 有下載會去下載
            //    > 下載成功會載入素材後執行onSynchronizeSuccess
            //    > 下載失敗因為畫面原本就看不到，所以不做事
            // 不需下載會接著執行onSynchronizeSuccess
            this._hotFixHelper.start();

            return true;
        }
        return false;
    },

    /**
     * 取得icon各項目的參數
     * {
     *    title: 標題
     *    image: icon圖尺寸有統一 有新icon要住一下icon尺寸(160*160)
     *    tabPlay:{           #頁籤玩牌
     *        chipDesc:       我要chip的說明
     *        currencyDesc:   我要KL/RP的說明
     *    }
     *
     *    #目前有的tab
     *    tabPlay     #頁籤玩牌
     *    tabLogin    #頁籤簽到&登入
     *    tabMission  #頁籤任務
     *    tabEvent    #頁籤限時任務
     *    tabVip      #頁籤vip專區
     *    tabChange   #頁籤兌換
     * }
     */
    _getIconParam: function (param) {
        var localStr = LocalizedString.FreeChip;
        var type = param.icon;
        switch (type) {
            case FreeChipListType.DAILY_MISSION:
                // 1: 每日任務
                return {
                    title: localStr("每日任務"),
                    image: "lobby_icon_daily_mission.png",
                    tabMission: {
                        chipDesc: localStr("完成任務獲得大量chips"),
                        currencyDesc: localStr("解任務拿豐富獎勵")
                    }
                };

            case FreeChipListType.DAILY_LOGIN:
                // 2: 每日簽到
                return {
                    title: localStr("每日簽到"),
                    image: "lobby_icon_daily_login.png",
                    tabLogin: {
                        chipDesc: localStr("每日登入拿")
                    }
                };

            case FreeChipListType.QUESTIONNAIREL:
                // 7: 問卷
                return {
                    title: localStr("意見回饋"),
                    image: "lobby_icon_questionnairel.png",
                    tabMission: {
                        chipDesc: localStr("完成即可拿到德撲幣")
                    }
                };

            case FreeChipListType.GUILD_SURPRISE:
                // 8: 公會驚喜(沒公會不顯示 有公會就顯示)
                return {
                    title: localStr("公會驚喜"),
                    image: "lobby_icon_guild_surprise.png",
                    tabMission: {
                        chipDesc: localStr("進公會每日拿")
                    }
                };

            case FreeChipListType.SERIAL_PRIZE:
                // 9: 輸入序號兌換獎勵
                return {
                    title: localStr("序號兌換"),
                    image: "lobby_icon_serialCode.png",
                    tabEvent: {
                        chipDesc: localStr("輸入序號兌換獎勵"),
                        currencyDesc: localStr("輸入序號兌換獎勵")
                    }
                };

            case FreeChipListType.JOIN_GUILD:
                // 11: 加入公會獎勵
                return {
                    title: localStr("加入公會"),
                    image: "lobby_icon_joinGuild.png",
                    tabMission: {
                        chipDesc: localStr("成功入會拿獎勵")
                    }
                };

            case FreeChipListType.GAME_RANK:
                // 12: 積分
                return {
                    title: localStr("Rank"),
                    image: "lobby_icon_gameRank.png",
                    tabMission: {
                        chipDesc: localStr("升階和每周排名結算可獲得chips")
                    }
                };

            case FreeChipListType.MASTER_POKER:
                // 14: 選牌小遊戲(單一版)
                return {
                    title: localStr("Master Poker"),
                    image: "lobby_icon_masterPoker.png",
                    tabLogin: {
                        chipDesc: localStr("選擇最好的牌組，獲得大量德撲幣")
                    }
                };

            case FreeChipListType.CALLBACK_MISSION:
                // 15: 回流任務(單一版)
                return {
                    title: localStr("回流任務"),
                    image: "lobby_icon_returnMission.png",
                    tabEvent: {
                        chipDesc: localStr("專屬於你，顯示拿獎")
                    }
                };

            case FreeChipListType.EVENT:
                // 16: 活動(單一版)
                return {
                    title: localStr("活動"),
                    image: "lobby_icon_event.png",
                    tabEvent: {
                        chipDesc: localStr("參加活動拿豐富獎勵！")
                    }
                };

            case FreeChipListType.ACHIEVEMENT:
                // 17: 成就(單一版)
                return {
                    title: localStr("成就"),
                    image: "lobby_icon_achievement.png",
                    tabMission: {
                        chipDesc: localStr("達成成就獲得獎勵")
                    }
                };

            case FreeChipListType.DAILY_LUCKY_WHEEL:
                // 18: 每日幸運輪盤
                return {
                    title: localStr("每日轉盤"),
                    image: "lobby_icon_daily_lucky_wheel.png",
                    tabLogin: {
                        chipDesc: localStr("連續完成越多天，獎勵越高")
                    }
                };

            case FreeChipListType.CARD_KING:
                // 19: 牌王
                return {
                    title: localStr("牌王系統"),
                    image: "lobby_icon_cardKing.png",
                    tabMission: {
                        chipDesc: localStr("每周結算可獲得chips")
                    }
                };

            case FreeChipListType.LOGIN_REWARD:
                // 20: 特定時段登入獎勵
                return {
                    title: localStr("特定時段登入獎勵"),
                    image: "lobby_icon_login.png",
                    tabLogin: {
                        chipDesc: localStr("每天三個時段登入即領!")
                    }
                };

            case FreeChipListType.VEGAS_RACING:
                // 25: 極速競飆
                return {
                    title: localStr("極速競飆"),
                    image: "lobby_icon_racing.png",
                    tabEvent: {
                        chipDesc: localStr("玩機台拿豐富豪禮"),
                        currencyDesc: localStr("玩機台拿豐富豪禮")
                    }
                };

            case FreeChipListType.PLAY_GAME:
                // 29: 玩牌(不限玩法)
                return {
                    title: localStr("玩牌"),
                    image: "lobby_icon_play.png",
                    tabPlay: {
                        currencyDesc: ProfileData.getKoinLuxyRes("越高底台KL點越多", localStr("越高底台KL點越多"))
                    }
                };

            case FreeChipListType.GAMBLER_ROAD:
                // 30: 牌王之路
                return {
                    title: localStr("牌王之路"),
                    image: "lobby_icon_gamblerRoad.png",
                    tabEvent: {
                        chipDesc: localStr("挑戰任務爭奪排名!"),
                        currencyDesc: localStr("挑戰任務爭奪排名!")
                    }
                };

            case FreeChipListType.VEGAS_COMPETE:
                // 32: VIP機台爭霸賽
                return {
                    title: localStr("VIP爭霸賽"),
                    image: "lobby_icon_vegasCompete.png",
                    tabEvent: {
                        chipDesc: localStr("您就是VIP機台之王"),
                        currencyDesc: localStr("您就是VIP機台之王")
                    }
                };

            case FreeChipListType.FIERCE_BATTLE:
                // 34: 激戰任務
                return {
                    title: localStr("激戰任務"),
                    image: "lobby_icon_fierceBattle.png",
                    tabEvent: {
                        chipDesc: localStr("限時時段比拚牌技"),
                        currencyDesc: localStr("限時時段比拚牌技")
                    }
                };

            case FreeChipListType.DRAGON_VS_LEOPARD:
                // 35: 龍豹對決
                return {
                    title: localStr("龍豹對決"),
                    image: "lobby_icon_dragonVsLeopard.png",
                    tabEvent: {
                        chipDesc: localStr("機台比拚~神隊友是你!"),
                        currencyDesc: localStr("機台比拚~神隊友是你!")
                    }
                };

            case FreeChipListType.GUILD_LADDER:
                // 36: 公會天梯
                return {
                    title: localStr("公會天梯"),
                    image: "lobby_icon_guildLadder.png",
                    tabEvent: {
                        chipDesc: localStr("公會競賽團結拿獎勵!")
                    }
                };

            case FreeChipListType.FULL_GIFT:
                // 37: 滿額贈
                return {
                    title: localStr("滿額贈"),
                    image: "lobby_icon_sale.png",
                    tabEvent: {
                        currencyDesc: ProfileData.getKoinLuxyRes("SALE! 不定期買就送KL!", localStr("SALE! 不定期買就送KL!"))
                    }
                };

            case FreeChipListType.VIP:
                // 38: VIP專區
                return {
                    title: localStr("VIP專區"),
                    image: "lobby_icon_vip.png",
                    tabVip: {
                        chipDesc: localStr("每周日VIP7以上可直接領高額德撲幣"),
                        currencyDesc: ProfileData.getKoinLuxyRes("每周三VIP9以上可直接領大量KL", localStr("每周三VIP9以上可直接領大量KL"))
                    }
                };

            case FreeChipListType.KOINLUXY:
                // 39: KL/RP商城兌換
                return {
                    title: ProfileData.getKoinLuxyRes("KL商城兌換", localStr("KL商城兌換")),
                    image: ProfileData.getKoinLuxyRes("lobby_icon_koinLuxy"),
                    tabChange: {
                        chipDesc: ProfileData.getKoinLuxyRes("使用KL兌換德撲幣禮包", localStr("使用KL兌換德撲幣禮包"))
                    }
                };

            case FreeChipListType.KOINLUXY_WHEEL:
                // 40: KL/RP Lucky Wheel
                return {
                    title: ProfileData.getKoinLuxyRes("KL Lucky Wheel", localStr("KL Lucky Wheel")),
                    image: ProfileData.getKoinLuxyRes("lobby_icon_luckyWheel"),
                    tabChange: {
                        chipDesc: ProfileData.getKoinLuxyRes("使用KL抽高額德撲幣", localStr("使用KL抽高額德撲幣"))
                    }
                };

            case FreeChipListType.PHONE_TO_GIFT:
                // 41: 填寫手機資料
                return {
                    title: localStr("填資料拿好禮"),
                    image: "lobby_icon_phoneToGift.png",
                    tabEvent: {
                        chipDesc: localStr("留下手機號碼獲得豐富獎勵")
                    }
                };

            case FreeChipListType.LUCKY_DICE_COLLECTION:
                // 45: 幸運集集樂
                return {
                    title: localStr("幸運集集樂"),
                    image: "lobby_icon_luckyDiceCollection.png",
                    tabEvent: {
                        chipDesc: localStr("下注累積幸運數字")
                    }
                };

            case FreeChipListType.UPDATE_VERSION_BONUS:
                // 46: 版本更新獎勵
                return {
                    title: localStr("版本更新"),
                    image: "lobby_icon_updateVersion.png",
                    tabMission: {
                        chipDesc: localStr("更新版本拿獎勵")
                    }
                };

            case FreeChipListType.FACEBOOK_FAN:
                // 47: FB粉絲專頁
                var status = DataModal.freeChipsData.fbFanInfo.rewardStatus;
                switch (status) {
                    case FreeChipsData.FacebookFanStatus.NOT_REWARD:
                    case FreeChipsData.FacebookFanStatus.CAN_REWARD:
                        // 0: 不可領獎
                        // 1: 可以領獎

                        if (status === FreeChipsData.FacebookFanStatus.NOT_REWARD && !DataModal.freeChipsData.isSendFBTrackFlag) {
                            // 避免reload tableView一直送
                            DataModal.freeChipsData.isSendFBTrackFlag = true;
                            // 埋點 2: 顯示Free chips 臉書點讚_GO按鈕人數
                            DataProcess.sendString("track_fan_page_click 2");
                        }

                        return {
                            title: localStr("臉書點讚"),
                            image: "lobby_icon_fb.png",
                            tabMission: {
                                currencyDesc: localStr("按讚粉專拿好禮")
                            }
                        };

                    case FreeChipsData.FacebookFanStatus.REWARD_DONE:
                        // 2: 已領獎

                        if (!DataModal.freeChipsData.isSendFBTrackFlag) {
                            // 避免reload tableView一直送
                            DataModal.freeChipsData.isSendFBTrackFlag = true;
                            // 埋點 6: 顯示臉書看好康_人數
                            DataProcess.sendString("track_fan_page_click 6");
                        }

                        return {
                            title: localStr("臉書看好康"),
                            image: "lobby_icon_fb.png",
                            tabMission: {
                                currencyDesc: localStr("不定時好康優惠")
                            }
                        };
                }
                break;

            case FreeChipListType.RAMADAN_SUBSYSTEM_SIGN_IN:
                // 48: 齋戒簽到
                return {
                    title: localStr("齋戒簽到"),
                    image: "lobby_icon_ramadan.png",
                    tabEvent: {
                        chipDesc: localStr("累積簽到獲得抽獎資格!")
                    }
                };

            case FreeChipListType.VEGAS_MAP_MISSION:
                // 49: 地圖式機台任務
                return {
                    title: DataModal.vegasMapMissionData.eventName,
                    image: "vegasMapMission_icon_01.png",
                    tabEvent: {
                        chipDesc: localStr("玩機台拿豐富豪禮"),
                        currencyDesc: localStr("玩機台拿豐富豪禮"),
                    }
                };

            case FreeChipListType.PULSA_EXCHANGE:
                // 50: PULSA兌換
                return {
                    title: localStr("兌換Pulsa"),
                    image: "lobby_icon_pulsa.png",
                    tabChange: {
                        chipDesc: localStr("把握期限! 馬上兌換!")
                    }
                };

            case FreeChipListType.TOKEN_SUBSYSTEM:
                // 51: 代幣副系統
                return {
                    title: localStr("拼圖轉盤"),
                    image: "lobby_icon_tokenSubsystem_01.png",
                    tabEvent: {
                        chipDesc: localStr("旋轉轉盤拿豪禮"),
                        currencyDesc: localStr("旋轉轉盤拿豪禮")
                    }
                };

            case FreeChipListType.LUXY_PASS:
                // 53: LuxyPass
                return {
                    title: localStr("Luxy Pass"),
                    image: "lobby_icon_luxyPass.png",
                    tabEvent: {
                        chipDesc: localStr("累積星星拿豪禮"),
                        currencyDesc: localStr("累積星星拿豪禮")
                    }
                };

            case FreeChipListType.RAMADAN:
                // 54: 齋戒
                return {
                    title: localStr("齋戒簽到"),
                    image: "lobby_icon_ramadan.png",
                    tabEvent: {
                        chipDesc: localStr("累積簽到獲得抽獎資格!")
                    }
                };

            case FreeChipListType.STONE_GAMBLING:
                // 55: 賭石大師
                return {
                    title: localStr("賭石大師"),
                    image: "lobby_icon_stone_gambling.png",
                    tabEvent: {
                        chipDesc: localStr("切開石頭拿好禮"),
                        currencyDesc: localStr("切開石頭拿好禮"),
                    }
                };

            case FreeChipListType.QUESTIONNAIRE_V2:
                // 58: 問卷 v2 (v5.6.3)
                return {
                    title: localStr("填問卷拿好禮"),
                    image: "lobby_icon_questionnairel_v2.png",
                    tabMission: {
                        chipDesc: localStr("只需要幾秒獎勵到手")
                    }
                };

            case FreeChipListType.MULTI_DICE_BO_CLUB:
                // 59: 百人骰寶風雲會
                return {
                    title: localStr("百人骰寶風雲會"),
                    image: "lobby_icon_multi_dice_bo_club_" + SelectGameManager.getGameName() + ".png",
                    tabEvent: {
                        chipDesc: localStr("升等拿好禮!"),
                        currencyDesc: localStr("升等拿好禮!"),
                    }
                };
            case FreeChipListType.PUZZLE_HOMERUN:
                // 61: 拼圖紅不讓
                return {
                    title: localStr("拼圖紅不讓"),
                    image: "lobby_icon_puzzleHomeRun.png",
                    tabEvent: {
                        chipDesc: localStr("解任務領連線豪禮!"),
                        currencyDesc: localStr("解任務領連線豪禮!"),
                    }
                };
            case FreeChipListType.TREASURE_QUEST:
                // 62: 奪寶冒險
                return {
                    title: localStr("奪寶冒險"),
                    image: "lobby_icon_treasureQuest.png",
                    tabEvent: {
                        chipDesc: localStr("破任務奪寶箱"),
                        currencyDesc: localStr("破任務奪寶箱"),
                    }
                };
            case FreeChipListType.FARM_BINGO:
                // 埋點
                if (DataModal.freeChipsData.isDialogPop) {
                    if (param.isBadgeVisible) {
                        DataModal.farmBingoData.sendEventLog("農場賓果_Free Chips 頁彈跳_看見農場賓果 go 按鈕 (有小紅點)");
                    } else {
                        DataModal.farmBingoData.sendEventLog("農場賓果_Free Chips 頁彈跳_看見農場賓果 go 按鈕");
                    }
                } else {
                    if (param.isBadgeVisible) {
                        DataModal.farmBingoData.sendEventLog("農場賓果_Free Chips 頁 icon_看見農場賓果 go 按鈕 (有小紅點)");
                    } else {
                        DataModal.farmBingoData.sendEventLog("農場賓果_Free Chips 頁 icon_看見農場賓果 go 按鈕");
                    }
                }
                // 63: 賓果農場
                return {
                    title: localStr("賓果農場"),
                    image: "lobby_icon_farm_pass.png",
                    tabEvent: {
                        chipDesc: localStr("玩賓果領取獎勵!"),
                        currencyDesc: localStr("玩賓果領取獎勵!"),
                    }
                };

            case FreeChipListType.LIMITED_GROUP_BONUS:
                // 埋點
                const limitedGroupBonusData = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.LIMITED_GROUP_BONUS);
                if (DataModal.freeChipsData.isDialogPop) {
                    if (param.isBadgeVisible) {
                        limitedGroupBonusData.sendEventLog("限時加贈_Free Chips 頁彈跳_看見限時加贈 go 按鈕 (有小紅點)");
                    } else {
                        limitedGroupBonusData.sendEventLog("限時加贈_Free Chips 頁彈跳_看見限時加贈 go 按鈕");
                    }
                } else {
                    if (param.isBadgeVisible) {
                        limitedGroupBonusData.sendEventLog("限時加贈_Free Chips 頁 icon_看見限時加贈 go 按鈕 (有小紅點)");
                    } else {
                        limitedGroupBonusData.sendEventLog("限時加贈_Free Chips 頁 icon_看見限時加贈 go 按鈕");
                    }
                }
                // 64: 限時加贈
                return {
                    title: localStr("限時加贈"),
                    image: "lobby_icon_bonus.png",
                    tabEvent: {
                        chipDesc: localStr("限時加贈大量德撲幣!"),
                    }
                };

            default:
                return {};
        }
    },

    /**
     * GO點擊引導
     */
    _goBtnClicked: function () {
        var param = this._param;
        var iconType = param.icon;
        var bannerType = param.bannerType;
        var isNeedClose = true;

        // 額外埋點
        switch (iconType) {
            case FreeChipListType.DAILY_MISSION:
                // 埋點
                DataProcess.sendString("track_daily_mission 2");
                break;

            case FreeChipListType.CARD_KING:
                // 埋點
                DataProcess.sendString('track_crown_king {"type":"2"}');
                break;

            case FreeChipListType.LOGIN_REWARD:
                // 埋點 1:點擊大廳Free chip 中icon
                DataProcess.sendString("track_period_login_bonus 1");
                break;

            case FreeChipListType.TOKEN_SUBSYSTEM:
                // 埋點: 代幣副系統 點擊夏日慶典GO
                DataProcess.sendString("user_analytics_track " + JSON.stringify([{type: 40}]));
                break;

            case FreeChipListType.LUXY_PASS:
                // 埋點: Luxy Pass點GO
                DataProcess.sendString("user_analytics_track " + JSON.stringify([{type: this._isChip ? 733 : 1324}]));
                break;
            case FreeChipListType.VEGAS_MAP_MISSION:
                // 埋點：地圖式機台任務點 GO
                TexasUtility.sendUserAnalyticsTrack(this._isChip ? 3880 : 3881);
                break;
            case FreeChipListType.STONE_GAMBLING:
                // 埋點：點擊賭石大師 GO 按鈕
                TexasUtility.sendUserAnalyticsTrack(3615, DataModal.stoneGamblingData.group);
                break;
            case FreeChipListType.MULTI_DICE_BO_CLUB:
                // 埋點：點擊風雲會 GO 按鈕
                TexasUtility.sendUserAnalyticsTrack(4758);
                break;
            case FreeChipListType.TREASURE_QUEST:
                // 埋點 奪寶冒險
                UserAnalyticsTrackUtils.sendTrack("奪寶冒險 >=8.8 點擊 FREE CHIPS 限時活動頁籤裡 ICON");
                if (DataModal.treasureQuestData.isCanReward) {
                    UserAnalyticsTrackUtils.sendTrack("奪寶冒險 >=8.8 點擊 FREE CHIPS 限時活動頁籤裡 ICON (可領獎時)人數");
                } else {
                    UserAnalyticsTrackUtils.sendTrack("奪寶冒險 >=8.8 點擊 FREE CHIPS 限時活動頁籤裡 ICON (不可領獎時)人數");
                }
                break;
            case FreeChipListType.FARM_BINGO:
                // 埋點
                if (DataModal.freeChipsData.isDialogPop) {
                    if (param.isBadgeVisible) {
                        DataModal.farmBingoData.sendEventLog("農場賓果_Free Chips 頁彈跳_點擊農場賓果 go (有小紅點)");
                    } else {
                        DataModal.farmBingoData.sendEventLog("農場賓果_Free Chips 頁彈跳_點擊農場賓果 go");
                    }
                } else {
                    if (param.isBadgeVisible) {
                        DataModal.farmBingoData.sendEventLog("農場賓果_Free Chips 頁 icon_點擊農場賓果 go (有小紅點)");
                    } else {
                        DataModal.farmBingoData.sendEventLog("農場賓果_Free Chips 頁 icon_點擊農場賓果 go");
                    }
                }
                break;
            case FreeChipListType.LIMITED_GROUP_BONUS:
                // 埋點
                const limitedGroupBonusData = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.LIMITED_GROUP_BONUS);
                if (DataModal.freeChipsData.isDialogPop) {
                    if (param.isBadgeVisible) {
                        limitedGroupBonusData.sendEventLog("限時加贈_Free Chips 頁彈跳_點擊限時加贈 go (有小紅點)");
                    } else {
                        limitedGroupBonusData.sendEventLog("限時加贈_Free Chips 頁彈跳_點擊限時加贈 go");
                    }
                } else {
                    if (param.isBadgeVisible) {
                        limitedGroupBonusData.sendEventLog("限時加贈_Free Chips 頁 icon_點擊限時加贈 go (有小紅點)");
                    } else {
                        limitedGroupBonusData.sendEventLog("限時加贈_Free Chips 頁 icon_點擊限時加贈 go");
                    }
                }
                break;
            default:
                break;
        }

        // 記錄點過 (紅點點過後紅點就消失)
        if (this._badge && this._badge.isVisible())
            DataModal.freeChipsData.refreshAvailableList(iconType);

        // 埋點
        DataProcess.sendString("track_new_free_chip 4");

        // 關掉畫面
        var dialog = DialogManager.getDialogByKey("FreeChipDialog");
        if (isNeedClose && dialog) {
            dialog.closeDialogAnimation();
        }

        if (bannerType !== 0) {
            // 走server送來的bannerType
            PushLayerHelper.pushLayer("", bannerType);
        } else {
            // 沒有bannerType的編號走這邊
            switch (iconType) {
                case FreeChipListType.DAILY_LOGIN:
                    // 2: 開每日簽到dialog
                    DialogManager.addDialog(new SignInDialog());
                    break;

                case FreeChipListType.QUESTIONNAIREL:
                    // 7: 開啟問卷
                    var questParam = DataModal.lobbyActionData.questParam;
                    var questName = questParam.name || "";
                    var questUrl = questParam.url;

                    // url如果沒值就不做事
                    if (!questUrl)
                        break;

                    var title = questName.replace("\n", " ");
                    var nextLayer = new LobbyWebViewLayer(title, GS.transferDomain(questUrl));
                    nextLayer.viewDidDisappear = function () {
                        // 要送拿reward的指令
                        DataProcess.sendString("questionnairel_getReward");
                    };
                    PushScene.pushLayer(nextLayer);
                    break;

                case FreeChipListType.SERIAL_PRIZE:
                    // 9: 序號兌換
                    DialogManager.addDialog(new SerialNumberPrizeDialog());
                    break;

                case FreeChipListType.CALLBACK_MISSION:
                    // 15: 回流任務
                    GS.dispatchCustomEvent("NotifyShowReturnMission");
                    break;

                case FreeChipListType.DAILY_LUCKY_WHEEL:
                    // 18: 按到每日輪盤 因為視窗要從特定位置跳 所以丟Notify出去
                    // 紀錄今日點過了
                    GS.localStorage.setItem(DataModal.dailyLuckyWheelData.getIconClickKey(), "1");
                    GS.dispatchCustomEvent("NotifyShowDailyLuckyWheelDialog");
                    break;

                case FreeChipListType.GAMBLER_ROAD:
                    // 30: 牌王之路
                    GS.dispatchCustomEvent("NotifyOpenGamblerRoadDialog");
                    break;

                case FreeChipListType.GUILD_LADDER:
                    // 36: 公會天梯
                    PushScene.pushLayer(new GuildLayer());
                    break;

                case FreeChipListType.PHONE_TO_GIFT:
                    // 41: 填寫手機資料
                    DialogManager.addDialog(new PhoneToGiftDialog());

                    // 埋點：點擊手機填寫的GO按鈕人數
                    DataProcess.sendString("track_new_free_chip 13");
                    break;

                case FreeChipListType.UPDATE_VERSION_BONUS:
                    // 46: 版本更新獎勵

                    // 埋點 14: 點擊版更獎勵
                    DataProcess.sendString("track_new_free_chip 14");

                    // 可以領獎就送領獎cmd，引導版本更新網頁
                    if (DataModal.settingData.canGetUpdateBonus) {
                        isNeedClose = false;
                        DataProcess.sendString("update_version_bonus_reward");
                    } else
                        cc.sys.openURL(GS.nativeAppURL);
                    break;

                case FreeChipListType.FACEBOOK_FAN:
                    // 47: 粉絲團按讚
                    var status = DataModal.freeChipsData.fbFanInfo.rewardStatus;
                    switch (status) {
                        case FreeChipsData.FacebookFanStatus.NOT_REWARD:
                        case FreeChipsData.FacebookFanStatus.REWARD_DONE:
                            // 0: 不可領獎
                            // 2: 已領獎

                            // 送按讚給server
                            DataModal.freeChipsData.sendFacebookFanLike();

                            if (status === FreeChipsData.FacebookFanStatus.NOT_REWARD)
                                // 埋點 3: 點擊Free chips 臉書點讚_GO按鈕
                                DataProcess.sendString("track_fan_page_click 3");
                            else if (status === FreeChipsData.FacebookFanStatus.REWARD_DONE)
                                // 埋點 7: 點擊臉書看好康_GO按鈕
                                DataProcess.sendString("track_fan_page_click 7");

                            // 不能用app開的話用網頁去開
                            var callback = (isSuccess) => {
                                if (!isSuccess) {
                                    // 變成開網頁
                                    if (GS.isLuxyPoker)
                                        cc.sys.openURL("https://www.facebook.com/Luxy-Poker-Indonesia-Texas-Holdem-1451171718501572");
                                    else
                                        cc.sys.openURL("https://www.facebook.com/Luxy-Domino-QiuQiu-99-429934474084857/");
                                }
                            };

                            // 去開粉絲團
                            var url;
                            if (cc.sys.os === cc.sys.OS_ANDROID) {
                                // 代表可以開啟Facebook APP
                                url = GS.isLuxyPoker ? "fb://page/1451171718501572" : "fb://page/429934474084857";
                                cc.sys.openURL(url, callback);
                            } else if (cc.sys.os === cc.sys.OS_IOS) {
                                // 代表可以開啟Facebook APP
                                url = GS.isLuxyPoker ? "fb://page?id=1451171718501572" : "fb://page?id=429934474084857";
                                cc.sys.openURL(url, callback);
                            }

                            // 更新Lobby下方小紅點
                            GS.dispatchCustomEvent("NotifyUpdateFBFanPage");
                            break;

                        case FreeChipsData.FacebookFanStatus.CAN_REWARD:
                            // 1: 可以領獎
                            // 送領獎給server
                            DataProcess.sendString("fan_page_reward 1");
                            break;
                    }
                    break;

                case FreeChipListType.PULSA_EXCHANGE:
                    // 50: PULSA兌換

                    var pulsaParam = DataModal.freeChipsData.pulsaParam;
                    if (pulsaParam && pulsaParam.url.length) {
                        // 顯示pulsa兌換網站 因有時server抓不到koin_luxy_display_type 由client這邊接 未來還有接到其他網址需要注意
                        var pulsaUrl = JSStringUtility.format("%s/%s&koin_luxy_display_type=%s", GS.domain, pulsaParam.url, DataModal.profileData.koinLuxyDisplayType);
                        var purchasePulsaDialog = new WebViewDialog(pulsaUrl, "");
                        purchasePulsaDialog.key = "PurchasePulsaDialog";
                        purchasePulsaDialog.isFromFreeChip = true;
                        DialogManager.addDialog(purchasePulsaDialog, true, true);
                    }

                    // 埋點: 點擊兌換pusla的go按鈕
                    DataProcess.sendString("track_free_pulsa 2");
                    break;

                case FreeChipListType.STONE_GAMBLING:
                    // 55: 賭石大師
                    PushScene.pushLayer(new StoneGamblingDialog());
                    break;

                case FreeChipListType.QUESTIONNAIRE_V2:
                    // 58: 問卷 v2 (v5.6.3)
                    var questParam = DataModal.freeChipsData.questionnaireV2Param;
                    if (!questParam || !questParam.url) break;

                    // 埋點
                    DataProcess.sendString('questionnaire_v2_click ' + JSON.stringify({
                        sid: questParam.sid,
                    }));
                    TexasUtility.sendUserAnalyticsTrack(3893);

                    // 標題
                    var questTitle = LocalizedString.FreeChip("填問卷拿好禮");

                    // 問卷 url
                    var questUrl = questParam.url;

                    // 產生問卷 Layer
                    var questLayer = new LobbyWebViewLayer(questTitle, GS.transferDomain(questUrl));
                    PushScene.pushLayer(questLayer);
                    break;

                case FreeChipListType.FARM_BINGO:
                    // 63: 賓果農場
                    DialogManager.addLobbyDialog(new FarmBingoDialog(), true, true);
                    break;

                case FreeChipListType.LIMITED_GROUP_BONUS:
                    // 64: 限時加贈
                    DialogManager.addDialog(new PurchaseTriggerIntegrationDialog(PurchaseTriggerIntegrationData.purchaseType.LIMITED_GROUP_BONUS), true, true);
                    break;

                default:
                    break;
            }
        }
    }
});

FreeChipCell.HEIGHT = 46;