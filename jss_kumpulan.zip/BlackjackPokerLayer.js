/**
 * 21點放牌的畫面
 */

var BlackjackPokerLayer = cc.Layer.extend({
    START_CARD_SCALE: 0.62,         // 一開始牌的大小
    END_CARD_SCALE: 0.596,          // 最後牌的大小
    PC_CARD_SCALE: 0.85,            // 電腦手牌的大小
    PLAYER_CARD_SCALE: 1,           // 玩家手牌的大小
    CARD_ANIMATION_TIME: 0.2,       // 牌動畫的時間

    ctor: function () {
        this._super();

        this._computerCardArray = [];
        this._playerCardArray = [];
        this._dealCardQueue = [];
        this._isDealingCard = false;

        // 左邊的牌比數 0是電腦 1是玩家
        this._scoreNodeArray = [];
        for (var i = 0; i < 2; i++) {
            var score = new BlackjackScoreNode();
            score.setPosition(JSScreenMidPos.x - 128, JSScreenMidPos.y + 56 - (i * 55));
            score.setScore("0");
            this.addChild(score);

            this._scoreNodeArray[i] = score;
        }

        // 牌專門放的Layer
        this._pokerLayer = new cc.Layer();
        this.addChild(this._pokerLayer);
    },

    /**
     * 清除畫面
     */
    clean: function () {
        this._pokerLayer.removeAllChildren();

        // 初始化
        this._computerCardArray = [];
        this._playerCardArray = [];
        this._dealCardQueue = [];
        this._isDealingCard = false;
        this._selfMaxScore = 0;

        this._scoreNodeArray.forEach(function (cur) {
            cur.setHintType(BlackjackScoreType.NONE);
            cur.setScore("0");
        });
    },

    /**
     * 更新分數
     */
    _updateCardScore: function (isPlayer, scoreArray) {
        var scoreNode = this._scoreNodeArray[isPlayer ? 1 : 0];

        if (!scoreArray) {
            scoreNode.setScore("0");
            scoreNode.setHintType(BlackjackScoreType.NONE);
            return;
        }

        var scoreNumber = [
            parseInt(scoreArray[0]),
            parseInt(scoreArray[1])
        ];

        var scoreString = scoreArray[0];
        if (scoreNumber[1] > 0)
            scoreString += " / " + scoreArray[1];

        var hintType = BlackjackScoreType.NONE;
        if (scoreNumber[0] > 21) {
            // 爆掉了
            hintType = BlackjackScoreType.BUST;
        } else {
            // 判斷是否為Blackjack
            var pokerArray = isPlayer ? this._playerCardArray : this._computerCardArray;
            if (pokerArray.length === 2 && (scoreNumber[0] === 21 || scoreNumber[1] === 21))
                hintType = BlackjackScoreType.BLACKJACK;
        }

        scoreNode.setScore(scoreString);
        scoreNode.setHintType(hintType);

        // 把自己的最大分數記下來
        if (isPlayer)
            this._selfMaxScore = scoreArray[0];
    },

    /**
     * 當發牌發到有A的時後 會出現類似 19/9的文字 換電腦的時後 就要把這數字顯示最大的數字
     */
    _showPlayerMaxScore: function () {
        this._scoreNodeArray[1].setScore(this._selfMaxScore);
    },

    /**
     * 更新輸贏
     */
    setScoreLose: function (isPlayer) {
        var scoreNode = this._scoreNodeArray[isPlayer ? 1 : 0];

        // 如果不是爆掉 要改成輸
        if (scoreNode.hintType !== BlackjackScoreType.BUST)
            scoreNode.setHintType(BlackjackScoreType.LOSE);
    },

    /**
     * 發牌
     * @param isPlayer 是否為玩家
     * @param cardNumber 哪一張牌
     * @param cardIndex 第幾張牌
     * @param scoreArray 點數
     */
    // 發牌
    dealCard: function (isPlayer, cardNumber, cardIndex, scoreArray) {
        if (this._isDealingCard) {
            // 加到Queue裡
            this._dealCardQueue.push({
                isPlayer: isPlayer,
                cardNumber: cardNumber,
                cardIndex: cardIndex,
                scoreArray: scoreArray
            });
        } else {
            // 直接發牌
            this._dealCard(isPlayer, cardNumber, cardIndex, scoreArray);
        }
    },

    _dealCard: function (isPlayer, cardNumber, cardIndex, scoreArray) {
        this._isDealingCard = true;

        var pokerArray = isPlayer ? this._playerCardArray : this._computerCardArray;
        var pokerLength = pokerArray.length;

        // 假如換電腦發了 要把自己的牌顯示最大分數 例如有A的時後 就要顯示最大分
        if (!isPlayer) {
            this._showPlayerMaxScore();
        }

        // 用來判斷幾張 超過幾張發牌要變慢
        var self = this;
        var dealCardDoneWrapper = function () {
            if (pokerLength < 2) {
                self._dealCardDone();

                // 因為處理過了 直接回傳沒做事的function
                return function () {}
            } else {
                // 回傳待會要處理的function
                return self._dealCardDone.bind(self);
            }
        };

        var pokerCard = pokerArray[cardIndex];
        if (pokerCard) {
            // 已經有那張牌 要翻牌而已
            if (cardNumber && cardNumber.length) {
                pokerCard.turnCard(cardNumber, dealCardDoneWrapper());

                // 更新點數
                this._updateCardScore(isPlayer, scoreArray)
            }
        } else {
            // 沒有那張牌 要發牌 先設到發牌的位置
            pokerCard = new BlackjackPoker();
            pokerCard.setScale(this.START_CARD_SCALE);
            pokerCard.setPosition(JSScreenMidPos.x + 182, JSScreenMidPos.y + 58);
            pokerCard.setRotation(-76);
            this._pokerLayer.addChild(pokerCard);

            // 加到Array裡
            pokerArray.push(pokerCard);

            // 設定
            var aniTime = this.CARD_ANIMATION_TIME;
            var endScaleSize = isPlayer ? this.PLAYER_CARD_SCALE : this.PC_CARD_SCALE;
            var endPosition = isPlayer ?
                cc.p(JSScreenMidPos.x - 10 + (20 * cardIndex), JSScreenMidPos.y - 31) :
                cc.p(JSScreenMidPos.x - 12 + (25.5 * cardIndex), JSScreenMidPos.y + 50);

            // 旋轉回來
            pokerCard.runAction(cc.rotateBy(aniTime, 76));

            // 變大小
            pokerCard.runAction(cc.scaleTo(aniTime, endScaleSize));

            // 移動
            pokerCard.runAction(cc.sequence(
                cc.moveTo(aniTime, endPosition).easing(cc.easeInOut(2)),
                cc.callFunc(function () {
                    // 要把牌翻過來
                    if (cardNumber && cardNumber.length) {
                        pokerCard.turnCard(cardNumber, dealCardDoneWrapper());

                        // 更新點數
                        this._updateCardScore(isPlayer, scoreArray)
                    } else {
                        // 沒有點數 不用翻牌
                        this._dealCardDone();
                    }
                }, this)
            ));
        }
    },

    // 發牌完成
    _dealCardDone: function () {
        // 要檢查還有沒有東西需要發 沒有的話送Notify出去
        this._isDealingCard = false;

        if (this._dealCardQueue.length === 0) {
            // 沒了
            GS.dispatchCustomEvent("NotifyBlackjackEnableCMD");
        } else {
            // 還有
            var dealParam = this._dealCardQueue.shift();
            this._dealCard(dealParam.isPlayer, dealParam.cardNumber, dealParam.cardIndex, dealParam.scoreArray);
        }
    },

});