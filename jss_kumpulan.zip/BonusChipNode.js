/**
 * Bonus機台 籌碼 Node
 */
var BonusChipNode = cc.Node.extend({
    ctor: function () {
        this._super();

        this.chipValue = 0;

        var chipBgSize = cc.size(50, 14);
        var chipLabelPos = cc.p(0, -14);

        // 籌碼圖示
        var chipSp = this._chipSp = new cc.Sprite("#vegas_chip_white.png");
        this.addChild(chipSp);

        // 籌碼金額
        var chipLabel = this._chipLabel = new GSNumberLabel("", JSFontName, 8, chipBgSize, cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        chipLabel.setUseCurrencyString(true);
        chipLabel.resizeToFit(6);
        chipLabel.setPosition(chipLabelPos);
        this.addChild(chipLabel);

        // 籌碼金額背景框
        var bgSp = new ccui.Scale9Sprite("bonus_money_box_bg.png");
        bgSp.setPreferredSize(chipBgSize);
        bgSp.setPosition(chipLabelPos);
        this.addChild(bgSp, -1);
    },

    /**
     * 設定籌碼金額
     * @param {Number} value 籌碼金額
     */
    setChipValue: function (value) {
        this.chipValue = value;
        this._chipLabel.setString(JSCodeUtility.getCurrencyString(value));
    },

    /**
     * 將籌碼圖示改為bonus的
     */
    changeToBonus: function () {
        this._chipSp.setSpriteFrame("bonus_bet_bonus_chips.png");
    }
});