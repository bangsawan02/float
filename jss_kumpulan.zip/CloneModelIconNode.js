/**
 * v5.5.2 分身模組 - Icon
 *
 * v5.6.1新增轉盤
 * v5.6.7調整儲值中心內的icon
 *
 * created by Jim.chen
 * edit by Jimmy.wen
 */
var CloneModelIconNode = LobbyTimeIconNode.extend({
    ctor: function (whereType) {
        this._super(whereType !== CloneModelIconNode.WhereType.LOBBY ? cc.size(130, 46) : undefined);

        this.key = "CloneModelIconNode";

        // 是哪邊的icon
        this._whereType = whereType;

        // 記下當前icon上的代幣數量(儲值中心內才有用到)
        this._coinsCount = 0;

        // 註冊
        GS.addListener("NotifyPlanReplacementIconUpdateRedPoint", this._updateRedPoint.bind(this), this);
        GS.addListener("NotifyPlanReplacementIconDone", this.notifyPlanReplacementIconDone.bind(this), this);
        GS.addListener("NotifyPlanReplacementRechargeDone", this.notifyPlanReplacementRechargeDone.bind(this), this);
        GS.addListener("NotifyPlanReplacementPlayAddCoinAnimate", this.notifyPlanReplacementPlayAddCoinAnimate.bind(this), this);

        // 去要資料 type 0:大廳 1:大廳儲值中心 2:遊戲內儲值中心
        DataModal.cloneModelData.startGetIconInfo(this._whereType);
    },

    // 刷新畫面
    _refreshView: function () {
        // 先清掉所有東西
        let mainNode = this._mainNode;
        mainNode.removeAllChildren();
        this._badgeNode = undefined;
        this._coinsArray = [];

        let cloneModelData = DataModal.cloneModelData;
        if (!cloneModelData.isEventOpen()) {
            // 活動沒開
            this.setVisible(false);
            return;
        }

        // 設定看的到
        this.setVisible(true);

        let iconParam = cloneModelData.iconParam;

        // 埋點：4910 >=5.6.7獲得分身模組且進入儲值中心
        this._whereType !== CloneModelIconNode.WhereType.LOBBY && TexasUtility.sendUserAnalyticsTrack(4910, iconParam.cluster);

        // icon
        let iconSprite = this._iconSprite = new cc.Sprite(JSStringUtility.format("#lobby_icon_cloneModel_0%s.png", this._whereType === CloneModelIconNode.WhereType.LOBBY ? "1" : "3"));
        mainNode.addChild(iconSprite);

        // 活動倒數時間
        let endCallback = () => {
            // 有顯示的Icon才要重要資料
            if (this.isVisibleRecursive()) {
                cloneModelData.cleanData();
                cloneModelData.startGetIconInfo(this._whereType);

                // 清掉儲值中心副系統顯示
                DataModal.purchaseData.cleanSubSystemDataByName(PurchaseData.SubSystemName.CLONE_MODEL);
            }

            // 隱藏icon
            this.setVisible(false);
        };

        let tickCallback = (seconds) => {
            // 剩餘3小時會有小紅點
            if (!cloneModelData.iconRedPointObj.threeHoursObj.isShowed && seconds <= 10800) {
                // 讓Data更新小紅點資料
                cloneModelData.updateRedPointStatus();
            }
        };

        if (this._whereType === CloneModelIconNode.WhereType.LOBBY) {
            // 主大廳創倒數計時
            this.createTimeLabelWithBackground(cloneModelData.getRemainTime(), endCallback, tickCallback);
        } else {
            // 儲值中心不顯示倒數
            var timerNode = new GSTimerNode();
            timerNode.countdownSeconds(cloneModelData.getRemainTime(), endCallback, tickCallback);
            mainNode.addChild(timerNode);

            // 顯示金額
            let text = JSStringUtility.format("%s %s", LocalizedString.Purchase("最大"), TexasUtility.getSimpleMoneyString(iconParam.title, 1));
            let chipLabel = new cc.LabelTTF(text, JSFontBoldName, 10);
            chipLabel.setPosition(12.5, 13);
            chipLabel.setFontFillColor(cc.color(255, 238, 51));
            mainNode.addChild(chipLabel);

            // 是不是儲值成功打開的
            let rechargeParam = DataModal.cloneModelData.rechargeParam;
            let isFromPurchaseSuccess = rechargeParam !== undefined && rechargeParam.isSuccess;

            // 顯示代幣數(來自儲值的話要少顯示一個)
            this._coinsCount = isFromPurchaseSuccess ? (rechargeParam.nextCoinProgress + 2) % 3 : (iconParam.coinsCount || 0);
            var coinPosList = [cc.p(-12.25, -7), cc.p(12.5, -7)];
            for (let i = 0; i < 2; i++) {
                let coinSp = this._coinsArray[i] = new cc.Sprite("#lobby_icon_cloneModel_02.png");
                coinSp.setPosition(coinPosList[i]);
                coinSp.setVisible(this._coinsCount > i);
                coinSp.setScale(0.5);
                mainNode.addChild(coinSp, 2);
            }
        }

        // 更新小紅點
        this._updateRedPoint();

        // 判斷要不要跳儲值動畫
        this.notifyPlanReplacementRechargeDone();

        // server告知主動跳出
        if (iconParam.isPop && this._whereType === CloneModelIconNode.WhereType.LOBBY && this.isVisibleRecursive()) {
            this._iconClicked();
        }
    },

    /**
     * 更新icon小紅點
     */
    _updateRedPoint: function () {
        let iconRedPointObj = DataModal.cloneModelData.iconRedPointObj;

        // 小紅點
        if (!this._badgeNode && iconRedPointObj.isShowIconRedPoint) {
            var pos = this._whereType === CloneModelIconNode.WhereType.LOBBY ? cc.p(18, 10) : cc.p(60, 17.5);
            let badgeNode = this._badgeNode = new BadgeNode();
            badgeNode.useDefaultStyle();
            badgeNode.setPosition(pos);
            badgeNode.setScale(this._whereType === CloneModelIconNode.WhereType.LOBBY ? 1 : 0.8);
            this._mainNode.addChild(badgeNode);
        } else
            this._badgeNode && this._badgeNode.setVisible(iconRedPointObj.isShowIconRedPoint);
    },

    // 跑完代幣動畫完後重刷資料
    _updateIconData: function () {
        // 更新數量
        this._coinsCount = (this._coinsCount + 1) % 3;
        if (DataModal.cloneModelData.iconParam) {
            DataModal.cloneModelData.iconParam.coinsCount = this._coinsCount;
        }

        var size = this._iconSprite.getContentSize();
        var dummyTouch = new DummyTouchLayer(size);
        dummyTouch.setPosition(-size.width / 2, -size.height / 2);
        this._mainNode.addChild(dummyTouch, 999);

        var loadingSprite = new GSLoadingSprite();
        loadingSprite.setScale(0.5);
        loadingSprite.start();
        this._mainNode.addChild(loadingSprite, 999);

        // 重要資料
        DataModal.cloneModelData.startGetIconInfo(this._whereType);
    },

    /**
     * icon按下
     */
    _iconClicked: function (sender = undefined) {
        // 按鈕點擊埋點 2:點擊大廳icon 3:點擊儲值中心icon
        if (sender) {
            DataProcess.sendString(JSStringUtility.format("track_plan_replacement %d", (this._whereType === CloneModelIconNode.WhereType.LOBBY) ? 2 : 3));

            // 埋點：4911 >=5.6.7 在儲值中心內點擊ICON
            (this._whereType !== CloneModelIconNode.WhereType.LOBBY) && TexasUtility.sendUserAnalyticsTrack(4911, DataModal.cloneModelData.iconParam.cluster);
        }

        // 紀錄已經點過小紅點了
        if (this._badgeNode && this._badgeNode.isVisible()) {
            this._badgeNode.setVisible(false);

            // 更新小紅點紀錄
            DataModal.cloneModelData.setRedPointRecord();
        }

        // 在lobby要加到lobbyDialog
        if (this._whereType === CloneModelIconNode.WhereType.LOBBY) {
            if (!DialogManager.isExist("CloneModelMainDialog")) {
                DialogManager.addLobbyDialog(new CloneModelMainDialog(this._whereType));
            }
        } else {
            DialogManager.addDialog(new CloneModelMainDialog(this._whereType));
        }
    },

    /**
     * 通知 收到icon資料
     */
    notifyPlanReplacementIconDone: function () {
        this._refreshView();
    },

    /**
     * 儲值成功
     * 橫式儲值中心:成功會直接跳動畫
     * 直式儲值中心:等回大廳再判斷跳動畫
     */
    notifyPlanReplacementRechargeDone: function () {
        // 活動沒開放不做事
        if (DataModal.cloneModelData.getRemainTime() <= 0)
            return;

        // 在桌內不做事
        if (PushScene.isGame && !cc.director.getRunningScene().isVegasScene)
            return;

        // 例外清單：在裡面的不跳動畫
        let excludedVegasList = [].concat(ALL_MULTI_DICEBO_VEGAS_GAME_TYPE_ARRAY);
        if (excludedVegasList.indexOf(GS.nowVegas) !== -1)
            return;

        let rechargeParam = DataModal.cloneModelData.rechargeParam;
        if (rechargeParam) {
            // 跳領獎視窗
            if (!DialogManager.isExist("CloneModelRewardDialog")) {
                let rewardDialog = new CloneModelRewardDialog(rechargeParam.rewardMsg);
                rewardDialog.setCloseCallback(() => {
                    // 關閉後，跳出輪盤 Dialog 演動畫
                    DialogManager.addDialog(new CloneModelWheelAwardDialog(this._whereType), true, true);
                });
                DialogManager.addDialog(rewardDialog, true, true);
            }
        }
    },

    /**
     * 通知演增加代幣動畫
     */
    notifyPlanReplacementPlayAddCoinAnimate: function () {
        // 在儲值中心才做事
        if (this._whereType !== CloneModelIconNode.WhereType.LOBBY) {
            // 不到2個才跑動畫
            if (this._coinsCount < 2 && this._coinsArray && this._coinsArray[this._coinsCount]) {
                this._coinsArray[this._coinsCount].setVisible(true);
                this._coinsArray[this._coinsCount].runAction(cc.sequence(
                    cc.scaleTo(0, 1.2),
                    cc.delayTime(0.1),
                    cc.scaleTo(0.2, 0.92),
                    cc.callFunc(() => {
                        // 發光動畫
                        GSSpine.create("spine/cloneModel/clone_model_ani_light_circle", 0.25, (spine) => {
                            spine.setAnimation(0, "ani_1", false);
                            spine.setPosition(this._coinsArray[this._coinsCount].getPosition());
                            this._mainNode.addChild(spine);
                        });
                    }),
                    cc.scaleTo(0.3, 0.5),
                    cc.scaleTo(0.2, 0.55),
                    cc.scaleTo(0.2, 0.5),
                    cc.callFunc(() => this._updateIconData())
                ));
            } else {
                // 已經2個就改成都看不到
                this._coinsArray.forEach(cur => cur.setVisible(false));

                // 重要資料
                this._updateIconData();
            }
        }
    }
});

// Icon所在的地點
CloneModelIconNode.WhereType = {
    LOBBY: 0,                       // 大廳
    PURCHASE_LAYER_IN_LOBBY: 1,     // 大廳進儲值頁面
    PURCHASE_LAYER_IN_GAME: 2,      // 遊戲進儲值頁面
};