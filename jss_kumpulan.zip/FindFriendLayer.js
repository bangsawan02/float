/**
 * 尋找/推薦好友
 */
var FindFriendLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 尋找的好友清單
        this._findFriendList = [];

        // 是不是搜尋結果
        this._isSearch = false;

        // 是不是推薦的好友
        this._isRecommend = true;

        // 列表
        var tableWidth = this._tableWidth = FriendLayer.WIDTH;
        var tableHeight = JSVisibleSize.height - TITLE_BG_HEIGHT - 26;
        var mainLayer = this._mainLayer = new cc.Layer();
        var tableView = this._tableView = new cc.TableView(this, cc.size(tableWidth, tableHeight), mainLayer);
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setPosition(115 + JSScreenBonusHalfWidth, 0);
        this.addChild(tableView);

        // 擋tableView 上方的touch
        var dummyTouch = new DummyTouchLayer(cc.size(tableWidth, 50));
        dummyTouch.setPosition(115 + JSScreenBonusHalfWidth, tableHeight);
        this.addChild(dummyTouch);

        // 標題 尋找後的數量
        var findCount = this._findCount = new cc.LabelTTF("", JSFontBoldName, 12);
        findCount.setAnchorPoint(0, 0.5);
        findCount.setPosition(128 + JSScreenBonusHalfWidth, JSVisibleSize.height - TITLE_BG_HEIGHT - 13);
        this.addChild(findCount);

        // 輸入搜尋帳號的EditBox
        var editBoxSize = cc.size(120, 20);
        var editBoxSprite1 = new ccui.Scale9Sprite("select_03.png");
        var editBoxSprite2 = new ccui.Scale9Sprite("select_03.png");
        editBoxSprite2.setColor(JSColor.GRAY);
        var inputEditBox = this._inputEditBox = new cc.EditBox(editBoxSize, editBoxSprite1, editBoxSprite2);
        inputEditBox.setAnchorPoint(1, 0.5);
        inputEditBox.setPosition(473 + JSScreenBonusHalfWidth, 236.5 + JSScreenBonusHeight);
        inputEditBox.setFontColor(JSColor.BLACK);
        inputEditBox.setFontName(JSFontName);
        inputEditBox.setPlaceHolder(LocalizedString.Friend("輸入ID搜尋好友"));
        inputEditBox.setPlaceholderFontName(JSFontName);
        inputEditBox.setPlaceholderFontSize(9);
        inputEditBox.setReturnType(cc.KEYBOARD_RETURNTYPE_DONE);
        inputEditBox.setInputFlag(cc.EDITBOX_INPUT_FLAG_SENSITIVE);
        inputEditBox.setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE);
        inputEditBox.setCascadeOpacityEnabled(true);
        inputEditBox.setDelegate(this);
        this.addChild(inputEditBox);

        // 搜尋框清除按鈕
        var searchBoxClearBtn = this._searchBoxClearBtn = ButtonUtility.createSimpleImageButton("friend_btn_ x_01.png", undefined);
        searchBoxClearBtn.setVisible(false);
        searchBoxClearBtn.addTouchUpInsideAction(this._searchBoxClearBtnClicked, this);
        searchBoxClearBtn.setPosition(463 + JSScreenBonusHalfWidth, JSVisibleSize.height - TITLE_BG_HEIGHT - 14);
        this.addChild(searchBoxClearBtn);

        // 搜尋按鈕
        var searchBtn = this._searchBtn = ButtonUtility.createSimpleImageButton("lobby_btn_07.png", cc.size(20, 20), "#lobby_icon_search.png");
        searchBtn.wordImage.setScale(0.75);
        searchBtn.addTouchUpInsideAction(this._searchBtnClicked, this);
        searchBtn.setPosition(485 + JSScreenBonusHalfWidth, JSVisibleSize.height - TITLE_BG_HEIGHT - 14);
        this.addChild(searchBtn);

        // 提示訊息
        var msgLabel = this._msgLabel = new cc.LabelTTF("", JSFontBoldName, 12);
        msgLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        msgLabel.setPosition(315 + JSScreenBonusHalfWidth, 122 + JSScreenBonusHalfHeight);
        this.addChild(msgLabel);

        // 加一個Loading
        var loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(cc.pAdd(tableView.getPosition(), cc.p(tableWidth / 2, tableHeight / 2)));
        loadingSprite.start();
        this.addChild(loadingSprite);

        // 取得好友推薦清單
        DataProcess.sendString("mixFriend_find_list");

        // 監聽
        GS.addListener("NotifyFindFriendListDone", this.notifyFindFriendListDone.bind(this), this);
        GS.addListener("NotifyFriendChangeDone", this.notifyFriendChangeDone.bind(this), this);
        GS.addListener("NotifyUpdateFriendListCount", this.notifyFindFriendListDone.bind(this), this);
    },

    /**
     * 更新畫面
     */
    _refreshView: function () {
        // 把Loading拿掉
        this._loadingSprite.stop();
        GSLoading.removeLoadingView();

        // 最近玩過的列表/搜尋到的好友列表
        var data = DataModal.friendData;

        if (!data)
            return;

        var FriendString = LocalizedString.Friend;

        var FindFriendList = this._findFriendList = data.findFriendList;

        // 清單的數量
        var listLen = this._totalCellCount = FindFriendList.length;

        // 訊息
        var msg = "";
        if (listLen === 0) {
            if (data.isFriendLimit)
                msg = FriendString("你的好友數已滿\n目前沒有空位再加好友了哦");
            else {
                msg = (this._isSearch) ? FriendString("查無結果，請重新搜尋")
                    : FriendString("目前沒有一起玩過的人哦\n快去牌桌玩遊戲\n認識新朋友吧");
            }
            this._msgLabel.setString(msg);
            this._msgLabel.setVisible(true);
        } else
            this._msgLabel.setVisible(false);

        this._findCount.setString(JSStringUtility.format(FriendString("最近一起玩過的人(%d)"), listLen));

        this._tableView.reloadData(true);

        if (data.isFriendLimit)
            // 好友滿了顯示訊息
            this._showFullFriend();
        else
            this._tipNode && this._tipNode.setVisible(false);

        this._isSearch = false;
    },

    /**
     * show 好友已滿的提示
     */
    _showFullFriend: function () {
        if (this._tipNode) {
            this._tipNode.setVisible(true);
            return;
        }

        var tipNode = this._tipNode = new cc.Node();
        this.addChild(tipNode, 100);

        // 背景色
        var mask = new cc.LayerColor(cc.color(0, 0, 0, 150), 383, 252);
        mask.setPosition(118 + JSScreenBonusHalfWidth, 0);
        tipNode.addChild(mask);

        // 加一層UI檔Touch
        var dummyTouch = new DummyTouchLayer(cc.size(383, 251));
        dummyTouch.setPosition(mask.getPosition());
        tipNode.addChild(dummyTouch);

        // 提示背景
        var hintBgSprite = new ccui.Scale9Sprite("lobby_bg_hint.png");
        hintBgSprite.setPreferredSize(cc.size(383, 60));
        hintBgSprite.setAnchorPoint(0, 0.5);
        hintBgSprite.setPosition(118 + JSScreenBonusHalfWidth, 120 + JSScreenBonusHeight);
        tipNode.addChild(hintBgSprite);

        // 提示文字
        var hintLabel = new cc.LabelTTF(LocalizedString.Friend("你的好友數已滿\n目前沒有空位再加好友了哦"), JSFontBoldName, 12);
        hintLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        hintLabel.setPosition(315 + JSScreenBonusHalfWidth, 120 + JSScreenBonusHeight);
        tipNode.addChild(hintLabel);
    },

    /**
     * TableView delegate
     */
    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        if (cell == null) {
            cell = new FindFriendCell();
            cell.setAnchorPoint(cc.p(0, 0));
        }
        cell.refreshCell(this._findFriendList[idx]);

        return cell;
    },

    numberOfCellsInTableView: function (table) {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function (table, idx) {
        return cc.size(this._tableWidth, FindFriendCell.HEIGHT);
    },

    /**
     * EditBox Delegate
     */
    editBoxEditingDidBegin: function (sender) {
        // 輸入中 先把清除鈕關掉
        this._searchBoxClearBtn.setVisible(false);

        // 擋一層touch 因為ios開鍵盤比較慢 在開完之前用來擋不能點擊其他按鈕
        if (!this._dummyTouchLayer) {
            var dummyTouchLayer = this._dummyTouchLayer = new DummyTouchLayer(JSVisibleSize);
            this.addChild(dummyTouchLayer, 10);

            // 放個提示給ios模擬器使用者
            if (JSDebugMode && cc.sys.os === cc.sys.OS_IOS) {
                var hintLabel = new cc.LabelTTF("這裡有一層dummyTouch擋著\n使用ios模擬器需要把模擬器小鍵盤打開", JSFontBoldName, 12);
                hintLabel.setFontFillColor(JSColor.RED);
                hintLabel.setPosition(JSScreenMidPos.x, JSVisibleSize.height - 100);
                dummyTouchLayer.addChild(hintLabel);

                var blackLayer = new cc.LayerColor(cc.color(0, 0, 0, 255), hintLabel.getContentSize().width + 6, 40);
                blackLayer.setPosition(JSScreenMidPos.x - hintLabel.getContentSize().width / 2 - 3, JSVisibleSize.height - 120);
                dummyTouchLayer.addChild(blackLayer, -1);
            }
        }
        this._dummyTouchLayer.setVisible(true);
    },

    editBoxEditingDidEnd: function (sender) {
        // 搜尋框有文字，顯示清除鈕
        this._searchBoxClearBtn.setVisible(this._inputEditBox.getString().length > 0);
        this._dummyTouchLayer && this._dummyTouchLayer.setVisible(false);
    },

    editBoxTextChanged: function (sender, text) {
        this._dummyTouchLayer && this._dummyTouchLayer.setVisible(false);
    },

    /**
     *  點擊搜尋
     */
    _searchBtnClicked: function (sender) {
        if (this._inputEditBox.isFocused())
            this._inputEditBox.closeKeyboard();

        var inputStr = this._inputEditBox.getString();

        // 搜尋文字要2個以上
        if (inputStr.length < 2) {
            // 跳提示-請輸入兩個字以上
            GS.dispatchCustomEvent("NotifyFriendLayerShowHintNode", {msg: LocalizedString.Friend("請輸入兩個字以上")});
            return;
        }

        // 按鈕的透明度
        var btnOpacity = this._searchBtn.getOpacity();

        if (btnOpacity === 127) {
            // 已經搜尋過囉
            var friendString = LocalizedString.Friend;
            var param = {
                title: friendString("提醒"),
                msg: friendString("您剛剛已經搜尋過了哦\n稍等再試試看吧"),
                button: [friendString("確定")]
            };
            DialogManager.addDialog(new FriendDialog(param));
        } else if (btnOpacity === 255) {
            // 點下去搜尋

            // 加loading
            GSLoading.addLoadingView();

            this._isSearch = true;

            this._isRecommend = false;

            // 搜尋按鈕進入15秒CD時間
            sender.runAction(cc.sequence(
                cc.delayTime(15),
                cc.callFunc(() => {
                    this._searchBtn.setOpacity(255);
                })
            ));
            // 按鈕變成已搜尋
            this._searchBtn.setOpacity(127);

            //送出搜尋
            var obj = {
                userid: encodeURIComponent(inputStr)
            };
            DataProcess.sendString("mixFriend_find_userid " + JSON.stringify(obj));
        }
    },

    /**
     *  點擊清除搜尋框
     */
    _searchBoxClearBtnClicked: function (sender) {
        sender.setVisible(false);

        if (this._inputEditBox.isFocused())
            this._inputEditBox.closeKeyboard();

        // 清空搜尋框
        this._inputEditBox.setString("");
    },

    /**
     * 通知刷新介面
     */
    notifyFindFriendListDone: function () {
        this._refreshView();
    },

    /**
     * 通知加入好友
     */
    notifyFriendChangeDone: function () {
        // show 訊息

        // 埋點 2:從一起玩過的朋友送出好友申請
        if (this._isRecommend) {
            var obj = {type: 2};
            DataProcess.sendString("mixFriend_icon_log " + JSON.stringify(obj));
        }

        // 到主頁面跳提示
        GS.dispatchCustomEvent("NotifyFriendLayerShowHintNode", {msg: LocalizedString.Friend("已將好友申請送出")});
        this._refreshView();
    }
});