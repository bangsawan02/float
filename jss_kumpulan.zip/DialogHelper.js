/**
 * 此Dialog用來整理共用的Dialog文字設定 之後可以擴充傳參數進來組成有顏色的文字
 *
 * @param key       用來辨識
 * @param msg       用在content內需要的地方
 * @param param     額外資料
 */

var DialogHelper = function (key, msg, param = null) {
    var retObj = null;
    var colorY = "#!E6AA00!#";
    var gameString = LocalizedString.Game;
    var lobbyString = LocalizedString.Lobby;
    switch (key) {
        /* 訪客要求轉正式會員 */
        case "H5CanNotUseToApp":
            // H5訪客不能玩某些功能 要他去轉正的Dialog
            retObj = {
                title: "升級帳號",
                content: "升級#!FFFF00!#正式帳號#!FFFFFF!#好處多!\n1.開啟所有遊戲功能\n2.帳號安全不遺失",
                buttons: ["登舊帳號", "馬上升級"],
                callback: function (index) {
                    if (index === 0) {
                        // 登舊帳號 踢回登入頁面
                        DataModal.loginData.logout();
                    } else if (index === 1) {
                        // 轉正
                        PushScene.pushLayer(new RegisterConvertLayer());
                    }
                },
                contentLeft: 1
            };
            break;

        case "TrailNeedConvert":
            retObj = {
                title: "升級帳號",
                content: "為了維護帳號資產安全，請馬上升級正式帳號,以保障權益,並享有完善功能",
                buttons: ["馬上升級"],
                callback: function (index) {
                    if (index === 0) {
                        // 轉正
                        PushScene.pushLayer(new RegisterConvertLayer());
                    } else {
                        // 清掉GA判斷用的東西
                        DataModal.loginData.transferAccountType = 0;
                    }
                },
                contentLeft: 1
            };
            break;

        // v5.6.8改介面 用不到了
        // case "VegasNoMoney":
        //     // 配桌沒錢
        //     retObj = {
        //         title: gameString("金額不足"),
        //         content: lobbyString("您的籌碼不足") + "\n" + colorY + msg + "#!FFFFFF!#\n\n" + lobbyString("立刻儲值進行遊戲吧！"),
        //         buttons: [lobbyString("立刻儲值")],
        //         callback: function (index) {
        //             if (index === 0) {
        //                 // 進入儲值頁
        //                 PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
        //             } else if (index === -1) {
        //                 // 關閉Dialog才去要儲值方案(時來運轉) Domino才去要
        //                 !GS.isLuxyPoker && DataModal.purchaseCouponData.sendVegasBrokenInfo();
        //             }
        //             // 如果是被NoMoneyDialog打開的要一起關掉
        //             GS.dispatchCustomEvent("NotifyCloseNoMoneyDialog");
        //         }
        //     };
        //     break;

        case "VegasServerIsBusy":
            // 機台不能玩
            retObj = {
                content: msg || LocalizedString.Vegas("伺服器忙碌中, 請稍候再試"),
                callback: () => {
                    // 在vegasScene 通知機台回大廳
                    if (cc.director.getRunningScene().isVegasScene) {
                        GS.dispatchCustomEvent("NotifyVegasGameToLobby");
                    }
                    // 在桌內 通知遊戲中關掉機台
                    else {
                        GS.dispatchCustomEvent("NotifyCloseGameVegas");
                    }

                    // 重要icon狀態
                    DataProcess.sendString("lobby_icon_settings");
                }
            };
            break;

        case "VegasBonusShutdown":
            retObj = {
                title: LocalizedString.Common("請稍後再試"),
                content: LocalizedString.Vegas("伺服器忙碌中, 請稍候再試"),
                buttons: [LocalizedString.Common("確定")],
                callback: () => {
                    // 在vegasScene 通知機台回大廳
                    if (cc.director.getRunningScene().isVegasScene) {
                        GS.dispatchCustomEvent("NotifyVegasGameToLobby");
                    }
                    // 在桌內 通知遊戲中關掉機台
                    else {
                        GS.dispatchCustomEvent("NotifyCloseGameVegas");
                    }
                }
            };
            break;

        case "NoLevel":
        case "NoLevel_Domino":
        case "NoLevel_Texas":
        case "NoLevel_Remi":
        case "NoLevel_Gaple":
        case "NoLevel_Cangkulan":
        case "NoLevel_CapsaSusun":
            // 等級不足 導馬上玩 先判斷要導哪一個馬上玩
            var gameName;
            switch (key) {
                case "NoLevel_Domino":
                    gameName = "(QiuQiu)";
                    break;
                case "NoLevel_Texas":
                    gameName = "(Poker)";
                    break;
                case "NoLevel_Gaple":
                    gameName = "(Gaple)";
                    break;
                case "NoLevel_Remi":
                    gameName = "(Remi)";
                    break;
                case "NoLevel_Cangkulan":
                    gameName = "(Cangkulan)";
                    break;
                case "NoLevel_CapsaSusun":
                    gameName = "(Capsa Susun)";
                    break;
                default:
                    // 如果是gaple好友桌 把它轉成gaple
                    if (GS.nowGame === GSEnum.Game.GapleFriend)
                        GS.nowGame = GSEnum.Game.Gaple;

                    gameName = "(" + GSEnum.GameName[GS.nowGame] + ")";
                    break;
            }
            retObj = {
                title: lobbyString("等級不足"),
                content: lobbyString("進入此區需要") + colorY + msg + "#!FFFFFF!#" + " " + lobbyString("級以上") + "\n" + lobbyString("先嘗試小局累積等級吧！"),
                contentLeft: 1,
                buttons: [lobbyString("馬上玩")],
                buttonHints: [gameName],
                callback: function (index) {
                    if (index === 0) {
                        // 馬上玩
                        var game;
                        switch (key) {
                            case "NoLevel_Domino":
                                game = GSEnum.Game.Domino;
                                break;
                            case "NoLevel_Texas":
                                game = GSEnum.Game.Texas;
                                break;
                            case "NoLevel_Gaple":
                                game = GSEnum.Game.Gaple;
                                break;
                            case "NoLevel_GapleChat":
                                game = GSEnum.Game.GapleChat;
                                break;
                            case "NoLevel_GaplePlus":
                                game = GSEnum.Game.GaplePlus;
                                break;
                            case "NoLevel_GapleVideo":
                                game = GSEnum.Game.GapleVideo;
                                break;
                            case "NoLevel_Remi":
                                game = GSEnum.Game.Remi;
                                break;
                            case "NoLevel_Cangkulan":
                                game = GSEnum.Game.Cangkulan;
                                break;
                            case "NoLevel_CapsaSusun":
                                game = GSEnum.Game.CapsaSusun;
                                break;
                            default:
                                game = GS.nowGame;
                                break;
                        }
                        // 馬上玩
                        GS.dispatchCustomEvent("NotifyGoQuickPlay", {game: game});
                    }
                }
            };
            break;

        case "VegasNoLevel":
            retObj = {
                title: lobbyString("等級不足"),
                content: lobbyString("進入此區需要") + colorY + msg + "#!FFFFFF!#" + " " + lobbyString("級以上") + "\n" + lobbyString("先嘗試小局累積等級吧！"),
                contentLeft: 1,
                buttons: [lobbyString("馬上玩")],
                callback: function (index) {
                    if (index === 0) {
                        // 馬上玩
                        GS.dispatchCustomEvent("NotifyGoQuickPlay");
                    }
                }
            };
            break;

        case "RoomNoMoney": // 配桌沒錢
            retObj = {
                title: JSColor.colorToRichColor(JSColor.YELLOW2) + gameString("金額不足"),
                content: lobbyString("您的籌碼不足") + "\n" + JSColor.colorToRichColor(JSColor.YELLOW2) + msg + "#!FFFFFF!#\n" + lobbyString("因此無法入桌\n \n立刻儲值進行遊戲吧！"),
                buttons: [lobbyString("立刻儲值")],
                callback: function (index) {
                    // 好友桌埋點
                    if (GS.nowGame === GSEnum.Game.GapleFriend)
                        DataProcess.sendString("track_gaple_friend_click 4");

                    if (index === 0) {
                        //進入儲值頁
                        PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
                    }
                    // 如果是被NoMoneyDialog打開的要一起關掉
                    GS.dispatchCustomEvent("NotifyCloseNoMoneyDialog");
                }
            };
            break;
        case "RoomNoMoneyWithTournament": // 比賽入桌沒錢
            retObj = {
                title: JSColor.colorToRichColor(JSColor.YELLOW2) + gameString("金額不足"),
                content: lobbyString("您的籌碼不足") + "\n" + JSColor.colorToRichColor(JSColor.YELLOW2) + msg.money + "#!FFFFFF!#\n" + lobbyString("因此無法入桌\n \n立刻儲值進行遊戲吧！"),
                buttons: [lobbyString("看更多"), lobbyString("立刻儲值")],
                callback: function (index) {
                    if (index === 0) {
                        //進入儲值頁
                        PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
                    } else if (index === 1) {
                        // 導IAP
                        DataModal.purchaseData.sendPurchaseByServerID(msg.purchase);
                    }
                }
            };
            break;
        // SNG比賽入桌沒錢
        case "RoomNoMoneyWithSNG":
            var chipStr = (cc.sys.os === cc.sys.OS_IOS) ? "5,000" : "5,500";
            retObj = {
                title: LocalizedString.Common("資產不足"),
                content: JSStringUtility.format("#!FFFFFF!#%s#!E6AA00!#%s#!FFFFFF!#%s%s",
                    LocalizedString.Compete("尚缺"),
                    msg.money,
                    LocalizedString.Compete("德撲幣就能參加比賽"),
                    LocalizedString.Compete("SNG立刻儲值") + chipStr
                ),
                buttons: [lobbyString("看更多"), lobbyString("立刻儲值")],
                callback: function (index) {
                    if (index === 0) {
                        //進入儲值頁
                        PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
                    } else if (index === 1) {
                        // 導IAP
                        DataModal.purchaseData.sendPurchaseByServerID(msg.purchase);

                        // 埋點
                        DataProcess.sendString("sng_dialog 0 1");
                    }
                }
            };
            break;
        // 鑽石賽入桌沒錢
        case "RoomNoMoneyWithCompete":
            var chipStr = (cc.sys.os === cc.sys.OS_IOS) ? "29,000" : "30,000";
            retObj = {
                title: LocalizedString.Compete("金額不足"),
                content: JSStringUtility.format("#!FFFFFF!#%s#!E6AA00!#%s#!FFFFFF!#%s%s",
                    LocalizedString.Compete("尚缺"),
                    msg.money,
                    LocalizedString.Compete("德撲幣就能參加比賽"),
                    LocalizedString.Compete("鑽石賽立刻儲值") + chipStr
                ),
                buttons: [lobbyString("看更多"), lobbyString("立刻儲值")],
                callback: function (index) {
                    if (index === 0) {
                        // 進入儲值頁
                        PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
                    } else if (index === 1) {
                        // 導IAP
                        DataModal.purchaseData.sendPurchaseByServerID(msg.purchase);

                        // 埋點
                        msg.index && DataProcess.sendString(JSStringUtility.format("compete_dialog %d 0 1", msg.index));
                    }
                }
            };
            break;
        // 配桌沒錢＋看廣告按鈕
        case "RoomNoMoneyWithAD":
            var videoADData = DataModal.videoADData;
            retObj = {
                title: JSColor.colorToRichColor(JSColor.YELLOW2) + gameString("金額不足"),
                content: lobbyString("您的籌碼不足") + " " + JSColor.colorToRichColor(JSColor.YELLOW2) + msg + "#!FFFFFF!#\n" + lobbyString("因此無法入桌\n \n立刻儲值進行遊戲吧！"),
                buttons: [lobbyString("立刻儲值")],
                callback: function (index) {
                    if (index === 0) {
                        // 進入儲值頁
                        PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
                    } else if (index === 1) {
                        // 播放廣告
                        videoADData.showVideoAD({type: VideoADData.Type.RoomNoMoney});
                    }
                }
            };

            // 如果有廣告可以看的話要加上看廣告拿Chips按鈕
            if (videoADData.checkADIsReady(VideoADData.Type.RoomNoMoney)) {
                retObj.buttons.push(lobbyString("拿Chips"));
                retObj.btnFontColors = [JSColor.WHITE, JSColor.BLACK];
                retObj.btnImages = ["lobby_btn_03.png", "lobby_btn_01.png"];
                retObj.btnIcons = [null, "#lobby_vad_icon.png"];
                retObj.btnIconScales = [null, 0.8];
                retObj.tip = LocalizedString.VideoAD("提醒: 非Wi-Fi的情況，觀看廣告將會消耗流量哦");
                retObj.tipBackground = true;
                retObj.loadFileArray = ["lobby/lobby_video_ad.plist", "lobby/lobby_video_ad.png"];

                // 廣告 server 埋點 玩家破產跳出訊息且可看廣告
                DataProcess.sendString("track_show_ad_exper 11 99");
            }
            break;
        case "StandUpButBet":
            retObj = {
                title: gameString("站起觀戰"),
                content: gameString("牌局進行中，若中途站起\n已下注的金額不會歸還\n \n確定要站起嗎？"),
                contentLeft: 1,
                buttons: [gameString("站起"), gameString("繼續遊戲")],
                callback: function (index) {
                    if (index === 0) {
                        GS.dispatchCustomEvent("NotifyGameUIStandUpClicked");
                    } else if (index === -1) {
                        GS.dispatchCustomEvent("NotifyGameUICancelStandUp");
                    }
                }
            };
            break;
        case "ChangeRoomButBet":
            retObj = {
                title: gameString("更換牌桌"),
                content: gameString("牌局進行中，若中途換桌\n已下注的金額不會歸還\n \n確定要更換嗎？"),
                contentLeft: 1,
                buttons: [gameString("更換牌桌"), gameString("繼續遊戲")],
                callback: function (index) {
                    if (index === 0) {
                        GS.dispatchCustomEvent("NotifyGameUIChangePlaceClicked", {isReplaceRoomByClickedUIButton: true});
                    } else if (index === -1) {
                        GS.dispatchCustomEvent("NotifyGameUICancelReplaceRoom");
                    }
                }
            };
            break;
        case "LeaveGameButBet":
            retObj = {
                title: gameString("離開遊戲"),
                content: gameString("牌局進行中，若中途離開\n已下注的金額不會歸還\n \n確定要離開嗎？"),
                contentLeft: 1,
                buttons: [gameString("離開遊戲"), gameString("繼續遊戲")],
                callback: function (index) {
                    if (index === 0) {
                        GS.dispatchCustomEvent("NotifyGameUIBackToLobbyClicked");
                    }
                }
            };
            break;
        case "StandUpWithKingOfCard":
            if (param) {  // {isBet:true //是否下注 , kingCount:5 //牌王蟬聯局數}
                var contentStr = gameString((param.isBet) ? "牌局進行中，已下注金額不會歸還\n蟬聯#!FFFF00!#%d#!FFFFFF!#局的牌王紀錄\n也將清空重新計算\n確定要站起嗎?" : "您為蟬聯#!FFFF00!#%d#!FFFFFF!#局的牌王\n離開將清空紀錄重新計算\n確定要站起嗎?");
                retObj = {
                    title: gameString("站起觀戰"),
                    content: JSStringUtility.format(contentStr, param.kingCount),
                    contentLeft: 1,
                    buttons: [gameString("站起"), gameString("繼續玩")],
                    callback: function (index) {
                        if (index === 0) {
                            GS.dispatchCustomEvent("NotifyGameUIStandUpClicked");
                            // 埋點
                            DataProcess.sendString(JSStringUtility.format('track_crown_king {"type":"%d"}', (param.isBet) ? 30 : 27));
                        } else if (index === 1 || index === -1) {
                            // 繼續玩
                            // 埋點
                            DataProcess.sendString(JSStringUtility.format('track_crown_king {"type":"%d"}', (param.isBet) ? 31 : 28));
                        }
                    }
                };
                // 埋點
                DataProcess.sendString(JSStringUtility.format('track_crown_king {"type":"%d"}', (param.isBet) ? 29 : 26));
            }
            break;
        case "ChangeRoomWithKingOfCard":
            // 德撲牌王換桌 有無下注文案不同
            if (param) {  // {isBet:true //是否下注 , kingCount:5 //牌王蟬聯局數}
                var contentStr = gameString((param.isBet) ? "牌局進行中，已下注金額不會歸還\n蟬聯#!FFFF00!#%d#!FFFFFF!#局的牌王紀錄\n也將清空重新計算\n確定要離開嗎?" : "您為蟬聯#!FFFF00!#%d#!FFFFFF!#局的牌王\n離開將清空紀錄重新計算\n確定要離開嗎?");
                retObj = {
                    title: gameString("更換牌桌"),
                    content: JSStringUtility.format(contentStr, param.kingCount),
                    contentLeft: 0,
                    buttons: [gameString("更換牌桌"), gameString("繼續玩")],
                    callback: function (index) {
                        if (index === 0) {
                            // 換桌
                            GS.dispatchCustomEvent("NotifyGameUIChangePlaceClicked", {isReplaceRoomByClickedUIButton: true});

                            // 埋點
                            DataProcess.sendString(JSStringUtility.format('track_crown_king {"type":"%d"}', (param.isBet) ? 30 : 27));
                        } else if (index === 1 || index === -1) {
                            // 繼續玩
                            // 埋點
                            DataProcess.sendString(JSStringUtility.format('track_crown_king {"type":"%d"}', (param.isBet) ? 31 : 28));

                            if (index === -1) {
                                // X按鈕
                                GS.dispatchCustomEvent("NotifyGameUICancelReplaceRoom");
                            }
                        }
                    }
                };

                // 埋點
                DataProcess.sendString(JSStringUtility.format('track_crown_king {"type":"%d"}', (param.isBet) ? 29 : 26));
            }
            break;
        case "LeaveGameWithKingOfCard":
            // 德撲牌王離桌 有無下注文案不同
            if (param) {  // {isBet:true //是否下注 , kingCount:5 //牌王蟬聯局數}
                var contentStr = gameString((param.isBet) ? "牌局進行中，已下注金額不會歸還\n蟬聯#!FFFF00!#%d#!FFFFFF!#局的牌王紀錄\n也將清空重新計算\n確定要離開嗎?" : "您為蟬聯#!FFFF00!#%d#!FFFFFF!#局的牌王\n離開將清空紀錄重新計算\n確定要離開嗎?");
                retObj = {
                    title: gameString("離開遊戲"),
                    content: JSStringUtility.format(contentStr, param.kingCount),
                    contentLeft: 0,
                    closeButton: 0,
                    buttons: [gameString("離開遊戲"), gameString("繼續玩")],
                    callback: function (index) {
                        if (index === 0) {
                            // 回大廳
                            GS.dispatchCustomEvent("NotifyGameUIBackToLobbyClicked");

                            // 埋點
                            DataProcess.sendString(JSStringUtility.format('track_crown_king {"type":"%d"}', (param.isBet) ? 30 : 27));
                        } else if (index === 1) {
                            // 繼續玩
                            // 埋點
                            DataProcess.sendString(JSStringUtility.format('track_crown_king {"type":"%d"}', (param.isBet) ? 31 : 28));
                        }
                    }
                };

                // 埋點
                DataProcess.sendString(JSStringUtility.format('track_crown_king {"type":"%d"}', (param.isBet) ? 29 : 26));
            }
            break;
        // 等太久問要返回大廳or換桌
        case "GameWaitToLong":
            var contentStr, isKingOfCard = false;
            if (param && param.isKing && param.kingCount > 0) {
                isKingOfCard = true;

                // 蟬聯牌王中
                contentStr = JSStringUtility.format(gameString("您很久沒有動作了\n需要幫您換桌嗎?\n\n離開會將蟬聯#!FFFF00!#%d#!FFFFFF!#局的牌王 \n記錄清空重新計算"), param.kingCount);

                // 埋點
                DataProcess.sendString(JSStringUtility.format('track_crown_king {"type":"32"}'));
            } else {
                // 一般狀況
                contentStr = gameString("由於您太久沒有動作\n是否想另配一桌好風水呢？");
            }
            retObj = {
                title: gameString("貼心提醒"),
                content: contentStr,
                linePoxY: 199,
                buttons: [gameString("返回大廳"), gameString("更換牌桌")],
                callback: function callback(index) {
                    if (index === 0) {
                        // 回大廳
                        GS.dispatchCustomEvent("NotifyGameUIBackToLobbyClicked");

                        // 埋點
                        if (isKingOfCard)
                            DataProcess.sendString(JSStringUtility.format('track_crown_king {"type":"33"}'));
                    } else if (index === 1) {
                        // 換桌
                        GS.dispatchCustomEvent("NotifyGameUIChangePlaceClicked", {isReplaceRoomByClickedUIButton: false});

                        // 埋點
                        if (isKingOfCard)
                            DataProcess.sendString(JSStringUtility.format('track_crown_king {"type":"34"}'));
                    }
                }
            };
            break;
        // 商城不夠錢
        case "ShopNoMoney":
            retObj = {
                title: gameString("金額不足"),
                content: lobbyString("您的德撲幣不足\n商品須") + colorY + msg + " chips#!FFFFFF!#\n" + lobbyString("立即儲值即可購買這個物品!"),
                buttons: [lobbyString("立刻儲值")],
                callback: function (index) {
                    if (index === 0) {
                        // 先關掉商城
                        GS.dispatchCustomEvent("NotifyShopBuyClose", true);

                        // 進入儲值頁
                        PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
                    }
                }
            };
            break;
        // 桌內一般沒錢的Dialog
        case "GameNoMoney_SitFail":
            retObj = {
                title: "#lobby_word_dialog_remind.png",
                content: gameString("遊戲幣不足以入桌"),
                buttons: [gameString("返回大廳")],
                callback: () => {
                    GS.dispatchCustomEvent("NotifyGameUIBackToLobbyClicked");
                }
            };
            break;
        // 影片廣告 沒有廣告可以看的dialog
        case "VideoAD_NoAD":
            retObj = {
                title: JSColor.colorToRichColor(JSColor.YELLOW2) + LocalizedString.Common("提醒"),
                content: LocalizedString.VideoAD("目前沒有廣告可看哦\n等一下再來看看吧！"),
                buttons: [LocalizedString.Common("確認")]
            };
            break;
        // 玩家非vip2以上的大廳提醒dialog
        case "NotVIPInLobby":
            retObj = {
                title: LocalizedString.FreeChip("提醒您"),
                content: LocalizedString.FreeChip("你目前非VIP2以上\n無法領取獎勵唷!"),
                buttons: [LocalizedString.FreeChip("去儲值")],
                callback: function (index) {
                    if (index === 0) {
                        // 先關掉每日好禮頁面
                        GS.dispatchCustomEvent("NotifyCloseActionListDialog");

                        // 進入儲值頁
                        PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
                    }
                }
            };
            break;
        // 玩家非vip2以上的桌內提醒dialog
        case "NotVIPInGame":
            retObj = {
                title: LocalizedString.FreeChip("提醒您"),
                content: LocalizedString.FreeChip("你目前非VIP2以上\n無法領取獎勵唷!，可至儲值中心儲值唷!"),
                buttons: [LocalizedString.Common("確認")]
            };
            break;
        // 桌列表玩家非vip
        case "NotVIPInRoom":
            retObj = {
                title: LocalizedString.Common("成為VIP"),
                content: msg,
                buttons: [LocalizedString.Lobby("立刻儲值")],
                callback: (index) => {
                    if (index === 0) {
                        // 進入儲值頁
                        PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
                    }
                }
            };
            break;
        case "CompeteNoDiamond":
            retObj = {
                title: LocalizedString.Compete("鑽石不足"),
                content: msg,
                buttons: [LocalizedString.Compete("馬上參賽")],
                callback: (index) => {
                    if (index === 0) {
                        // 導紅鑽賽
                        var param = DataModal.regionsData.tournament.normalRegions[0];
                        if (param && param.canJoin) {
                            // 加Loading
                            GSLoading.addLoadingView();

                            // 送入桌cmd
                            DataProcess.sendString("joinCompeteP " + param.joinKey);

                            // 先設定開哪一頁
                            DataModal.lobbyInfo.toLobbyOpenPage = LobbyOpenPage.ROOM;
                            DataModal.lobbyInfo.lastGameMode = "Compete";
                        }
                    }
                }
            };
            break;
        case "MoneyNotEnoughGoPurchase":
            retObj = {
                title: LocalizedString.Common("資產不足"),
                content: JSStringUtility.format(LocalizedString.Common("還差#!FFFF00!#%s#!FFFFFF!#遊戲幣才可入坐唷\n牌局進行中，確定前往儲值中心增加資產"), JSCodeUtility.getCurrencyString(msg)),
                buttons: [LocalizedString.Common("去儲值")],
                callback: (index) => {
                    if (index === 0) {
                        // 進入儲值頁
                        PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
                    }
                }
            };
            break;
        case "MasterPokerDisconnect":
            retObj = {
                content: LocalizedString.MasterPoker("您已中斷“Master Poker”明天再繼續回來玩~您的累積天數&秒數會增加唷!"),
                buttons: [LocalizedString.MasterPoker("確定")]
            };
            break;

        // server忙碌中踢回上一頁
        case "ServerBusy":
            retObj = {
                content: msg,
                buttons: [LocalizedString.MasterPoker("確定")],
                callback: () => {
                    PushScene.popLayer();
                }
            };
            break;
        default:
            break;
    }

    if (retObj != null)
        retObj.key = key;

    return retObj;
};

/**
 * 用在檢查等級
 * @param limitLevel    等級限制
 */
var checkLevelByLimitLevel = function (limitLevel = 1) {
    var myLv = DataModal.profileData.level;
    if (myLv < limitLevel) {
        var result = limitLevel - myLv;

        // 跳Dialog
        DialogManager.addDialog(new AvatarDialog(DialogHelper("NoLevel", result.toString())));

        return false;
    }
    return true;
};
