/**
 * 玩家的Node 很多東西都放在這 圖片盡量放在zOrder 0  Label放在 1
 */

var Domino_PlayerNode = cc.Node.extend({
    ctor: function (serverSitNum) {
        this._super();

        this.setCascadeColorEnabled(true);
        this.setCascadeOpacityEnabled(true);

        this._playerData = null;
        this.money = 0;                         //身上的籌碼

        //用來移動位子(public)
        this.sitNum = serverSitNum;             //畫面上看到的位置(自已是0，往左+1)
        this.serverSitNum = serverSitNum;       //server的位置
        this.sitNumTmp = 0;                     //暫時記錄目標位置的值
        this.prevPlayer = null;                 //前一個PlayerNode
        this.nextPlayer = null;                 //後一個PlayerNode
        this._allInGAFNode = null;              // All in的動畫

        // 先創一個Node 用來縮放大頭照相關的大小 因為只有自己是Scale 1 其他人是 0.6
        var mainNode = this._mainNode = new cc.Node();
        mainNode.setScale(0.6);
        mainNode.setCascadeOpacityEnabled(true);
        this.addChild(mainNode);

        //倒數計時
        var self = this;
        var timerNode = this._timerNode = new Domino_PlayerCountDownNode(function () {
            if (self.getIsSelf())
                GS.dispatchCustomEvent("NotifyGamePlayerCountDownFinish");
        });
        timerNode.setVisible(false);
        mainNode.addChild(timerNode);

        // 玩家大頭照
        var photoSprite = this._photoSprite = new GamePlayerPhotoButton();
        photoSprite.addTouchUpInsideAction(this._showDetailClicked, this);
        mainNode.addChild(photoSprite);

        // 頭像匡
        var identifyNode = this._identifyNode = new PlayerIdentityNode();
        identifyNode.setScale(1.45);
        identifyNode.setPosition(-0.5, 1);
        mainNode.addChild(identifyNode);

        // 禮物按鈕
        var giftButton = this._giftButton = new PlayerAccessoryNode();
        giftButton.setScale(0.9);
        giftButton.setPosition(-31, -12);
        giftButton.addTargetWithActionForControlEvents(this, this._sendGiftClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        giftButton.setEnabled(true);
        mainNode.addChild(giftButton);

        // 積分Icon
        var rankIconNode = this._rankIconNode = new GameRankIconNode();
        rankIconNode.setScale(0.3);
        var rankIconBtn = this._rankIconBtn = new GSControlButton(rankIconNode, rankIconNode.getBoundingBox());
        rankIconBtn.setChangeColorWhenDisabled(false);
        rankIconBtn.addTouchUpInsideAction(() => {
            DialogManager.addDialog(new GameRankGameInfoDialog());
        }, this);
        rankIconBtn.setEnabled(false);
        rankIconBtn.setPosition(31, -12);
        mainNode.addChild(rankIconBtn);

        // 玩家的表情
        var moodNode = this._moodNode = new cc.Node();
        this.addChild(moodNode);

        // 玩家的決策
        var confirmNode = this._confirmNode = new Domino_PlayerConfirmNode();
        confirmNode.setVisible(false);
        this.addChild(this._confirmNode);

        // 下方的資訊框
        var infoNode = this._infoNode = new cc.Node();
        infoNode.setCascadeOpacityEnabled(true);
        this.addChild(infoNode);

        // 金錢背景底
        var moneyBgSprite = new ccui.Scale9Sprite("lobby_pic_square_black.png");
        moneyBgSprite.setPreferredSize(cc.size(56, 12));
        moneyBgSprite.setPosition(0, -24);
        moneyBgSprite.setOpacity(100);
        infoNode.addChild(moneyBgSprite);

        // 金錢圖片
        var moneySprite = new cc.Sprite("#lobby_pic_chips_big_01.png");
        moneySprite.setPosition(-26, -24);
        infoNode.addChild(moneySprite);

        // 右邊的加號按鈕
        var moneyMenu = new cc.Menu();
        moneyMenu.setPosition(32, -24);
        infoNode.addChild(moneyMenu, 5);

        var itemNodes = ButtonUtility.createSingleSpriteWithSpritesNodes("lobby_btn_01.png", cc.size(13, 13), "#lobby_pic_plus.png", false, [cc.p(0, 0.5)]);
        for (var i = 0; i < 3; i++) {
            // 微調裡面的圖片
            itemNodes[i].imgs[0].setColor(cc.color(50, 50, 50));
            itemNodes[i].imgs[0].setScale(0.7);
        }
        var plusMenuItem = this._plusMenuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._plusMenuItemClicked, this);
        plusMenuItem.setVisible(false);
        moneyMenu.addChild(plusMenuItem);

        // 金錢
        var moneyLabel = this._moneyLabel = new GSAutoSizeLabel("", JSFontName, 9, cc.size(48, 12), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        moneyLabel.setPosition(3, -24);
        moneyLabel.resizeToFit(7);              // 設定最小的Size
        infoNode.addChild(moneyLabel, 1);

        // 名字與決策
        var nameLabel = this._nameLabel = new GSAutoSizeLabel("", JSFontName, 9, cc.size(70, 12), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        nameLabel.setPosition(0, -37);
        nameLabel.setFontFillColor(JSColor.YELLOW);
        nameLabel.resizeToFit(9);              // 設定最小的Size
        nameLabel.enableShadow(JSColor.BLACK, cc.size(1, -1), 0);
        infoNode.addChild(nameLabel, 1);

        // 手牌
        var handCardNode = this._handCardNode = new Domino_PlayerHandCardNode();
        handCardNode.setCascadeOpacityEnabled(true);
        handCardNode.setPosition(40, -4);
        this.addChild(handCardNode, 5);

        // 玩家最後的結算的手牌 放在最上面
        var finishHandCard = this._finishHandCard = new Domino_CardSetNode();
        finishHandCard.setVisible(false);
        this.addChild(finishHandCard, 10);

        // 如果是0 把這個設成自己
        if (serverSitNum == 0)
            this.setPlayerIsSelf(true);

        // 最後設定一下SitNum 調一下UI位置
        this.setSitNum(serverSitNum);
    },

    /**
     * 重置所有資訊 / 外觀
     */
    cleanData: function () {
        this.setVisible(false);

        this._playerData = null;
        this._handCardNode.cleanData();
        this._photoSprite.setPhotoUrlString("");
        this._nameLabel.setString("");
        this._moneyLabel.setString("0");
        this._timerNode.stop();

        this._firstSitRankAnimation = false;        // 是否在撥第一次坐下的積分動畫, 是的話updateSeat來的積分先不顯示

        // 關掉決策的圖片
        this._confirmNode.setVisible(false);

        // 關掉All in動畫
        this.setAllInAnimationVisible(false);

        this.refreshStatus(GAME_PLAYER_STATUS.UNKNOW);
    },

    /**
     * 設定此Player是否為玩家本人
     */
    setPlayerIsSelf: function (isSelf) {
        // 把人像變大
        this._mainNode.setScale(isSelf ? 1 : 0.6);

        // 表情要同步放大
        this._moodNode.setScale(isSelf ? 1 : 0.6);

        // 把資訊往下往左
        this._infoNode.setPosition(isSelf ? cc.p(-6, -13) : cc.p(0, 0));

        // 假如是自己 要把名字置中 所以把infoNode的位移扣回來
        this._nameLabel.setPositionX(isSelf ? 6 : 0);

        // 按鈕是否要出現
        this._plusMenuItem.setVisible(isSelf);

        // 手牌是否要出現
        this._handCardNode.setVisible(!isSelf);

        // 決策圖片要調整位置
        this._confirmNode.setPosition(isSelf ? cc.p(-30, 4) : cc.p(-13, 13));
    },

    /**
     * 抓此玩家的PlayerData
     */
    getPlayerData: function () {
        return this._playerData;
    },

    /**
     * 這個玩家目前是否存在
     * @returns {boolean}
     */
    getIsExist: function () {
        return !!this._playerData;
    },

    /**
     * 判斷這玩家是否是自己
     * @returns {boolean}
     */
    getIsSelf: function () {
        return this._playerData && this._playerData.getIsSelf();
    },

    /**
     * 對這玩家加手牌
     */
    addHandCard: function () {
        this._handCardNode.addCard();
    },

    /**
     * 抓此玩家的手牌數量
     */
    getHandCardCount: function () {
        return this._handCardNode.getCardCount();
    },

    /**
     * 把此玩家上的手牌砍掉
     */
    removeHandCard: function () {
        this._handCardNode.cleanData();
    },

    /**
     * 設定此玩家的決策
     */
    setConfirmStatus: function (status) {
        this._confirmNode.setStatus(status);
    },

    /**
     * 設定All in 動畫顯示
     */
    setAllInAnimationVisible: function (isVisible) {
        if (isVisible) {
            if (!this._allInGAFNode) {
                // 沒有All in gaf在重創
                var self = this;
                gaf.create("gaf/game/game_allin.gaf", this, true, function (asset) {
                    if (self._allInGAFNode) {
                        // 非同步 已經有加過了
                        return;
                    }

                    var gafObject = self._allInGAFNode = asset.createObjectAndRun(true);
                    self._mainNode.addChild(gafObject, 1);
                });
            }
        } else {
            // 要砍掉
            if (this._allInGAFNode) {
                this._allInGAFNode.removeFromParent();
                this._allInGAFNode = null;
            }
        }
    },

    /**
     * 出現結算的牌組
     * @param value 牌的Array ["12","33","36","00"] JSON Object
     */
    showFinishHandCard: function (value) {
        if (!this.getIsSelf()) {
            // 不是自己在做
            this._finishHandCard.setVisible(true);
            for (var i = 0; i < 4; i++) {
                // 最後一張牌在更新分數就好了 省一點
                this._finishHandCard.addCard(value[i], false, i === 3);
            }
        }
    },

    /**
     * 撥放表情
     */
    playMood: function (moodString) {
        // 撥放GAF
        var self = this;
        var url = MOOD_DOWNLOAD_URL + moodString + ".zip";
        var entryFile = moodString + "/" + moodString + ".gaf";
        var saveFileName = JSStringUtility.format("%smood/%s.zip", JSWriteablePath, moodString);
        gaf.createAndDownloadWithBundle(url, saveFileName, entryFile, this, function (gafAsset) {
            var moodNode = new cc.Node();
            moodNode.setCascadeOpacityEnabled(true);
            moodNode.setOpacity(0);
            self._moodNode.addChild(moodNode, 10);

            var bgSprite = new cc.Sprite("#lobby_photo_clip.png");
            bgSprite.setColor(JSColor.BLACK);
            bgSprite.setOpacity(100);
            moodNode.addChild(bgSprite);

            var gafObject = gafAsset.createObjectAndRun(true);
            gafObject.setScale(0.6);
            moodNode.addChild(gafObject);

            // 設定撥放完要砍掉
            moodNode.runAction(cc.sequence(
                cc.fadeIn(0.1),
                cc.delayTime(2),
                cc.fadeOut(0.4),
                cc.removeSelf()
            ));

            // 撥放音效
            MusicUtility.playEffect("Music/Effect/mood/mood_" + moodString + ".mp3");
        }, function () {
            // 失敗
            cc.log("表情 加失敗 URL=" + url);
        });
    },

    /**
     * 按鈕
     */
    // 按到加金錢按鈕
    _plusMenuItemClicked: function () {
        var gameData = DataModal.gameData;

        // 先判斷是否身上的金錢比小攜還多
        if (DataModal.profileData.money >= gameData.minBringIn) {
            var param = {
                min: gameData.minBringIn,
                max: gameData.maxBringIn,
                money: DataModal.profileData.money,
                type: BringMoneyDialog.Type.USER_CLICKED
            };

            var dialog = new BringMoneyDialog(param);
            DialogManager.addDialog(dialog, true, true);
        } else {
            // 比較少 要跳Dialog
            var gameString = LocalizedString.Game;
            var dialog = new AvatarDialog({
                title: gameString("金額不足"),
                content: gameString("您的籌碼低於此桌最小攜入,因此無法再攜入籌碼"),
                buttons: [gameString("確定")]
            });
            DialogManager.addDialog(dialog);
        }
    },


    // 秀該玩家詳細資料
    _showDetailClicked: function () {
        if (this._playerData) {
            var profileDialog = new ProfileDialog(this._playerData.account);
            DialogManager.addDialog(profileDialog, true, true);
        }
    },

    // 按到送禮物
    _sendGiftClicked: function () {
        if (!this._playerData)
            return;

        var type = this.getIsSelf() ? ChipShopDialog.Type.GAME_SELF : ChipShopDialog.Type.GAME_FRIEND;
        DialogManager.addDialog(new ChipShopDialog(type, this._playerData.account));
    },

    /**
     * 下一局時，重設外觀
     */
    cleanDisplayWhenOLEH: function () {
        // 清掉手牌
        this._handCardNode.cleanData();

        // 清掉牌型確認
        this._confirmNode.setStatus(DOMINO_PLAYER_CONFIRM_STATUS.NONE);

        // 把結算手牌拿掉
        this._finishHandCard.cleanData();
        this._finishHandCard.setVisible(false);

        // 關掉All in動畫
        this.setAllInAnimationVisible(false);
    },

    /**
     * 注意:只有第一次坐下 & 站起又坐下時才會處理
     */
    processLastCmd: function () {
        var playerData = DataModal.gameData.playerDataArray[this.serverSitNum];
        if (playerData.last_cmd && playerData.last_cmd.length) {
            switch (playerData.last_cmd[0]) {
                case "plnext":
                    //第待下一局
                    this.refreshStatus(GAME_PLAYER_STATUS.UNKNOW);
                    break;
                case "ante":
                    // 下底注
                    break;
                case "plwait":
                    //等待下注
                    this.refreshStatus(GAME_PLAYER_STATUS.UNKNOW);
                    break;
                case "smallblind":
                    //小盲
                    this.refreshStatus(GAME_PLAYER_STATUS.SMALL_BLIND);
                    break;
                case "bigblind":
                    //大盲
                    this.refreshStatus(GAME_PLAYER_STATUS.BIG_BLIND);
                    break;
                case "plallin":
                    //All In
                    this.refreshStatus(GAME_PLAYER_STATUS.ALL_IN);
                    break;
                case "plcall":
                    this.refreshStatus(GAME_PLAYER_STATUS.CALL);
                    //跟注
                    break;
                case "plfold":
                    //棄牌
                    this.refreshStatus(GAME_PLAYER_STATUS.FOLD);
                    break;
                case "plraise":
                    //加注
                    this.refreshStatus(GAME_PLAYER_STATUS.RAISE);
                    break;
                case "plcheck":
                    //過牌
                    this.refreshStatus(GAME_PLAYER_STATUS.CHECK);
                    break;
                default:
                    break;
            }
        }
    },

    /**
     * 設定目前出牌狀態
     */
    refreshStatus: function (value) {
        var playerData = this._playerData;
        if (!(playerData && playerData.getIsExist())) {
            return;
        }

        var gameString = LocalizedString.Game;
        var label = this._nameLabel;
        var status = GAME_PLAYER_STATUS.UNKNOW;

        if (JSCodeUtility.checkIsdefined(value)) {
            playerData.status = status = value;
        } else {
            status = playerData.status;
        }

        switch (status) {
            case GAME_PLAYER_STATUS.UNKNOW:
                label.setString(this._playerData.nickname);
                label.setFontFillColor(JSColor.WHITE);
                break;
            case GAME_PLAYER_STATUS.FOLD:
                label.setString(gameString("棄牌"));
                label.setFontFillColor(cc.color(153, 153, 153));
                break;
            case GAME_PLAYER_STATUS.CHECK:
                label.setString(gameString("過牌"));
                label.setFontFillColor(cc.color(153, 255, 0));
                break;
            case GAME_PLAYER_STATUS.CALL:
                label.setString(gameString("跟注"));
                label.setFontFillColor(cc.color(51, 255, 0));
                break;
            case GAME_PLAYER_STATUS.RAISE:
                label.setString(gameString("加注"));
                label.setFontFillColor(cc.color(255, 153, 204));
                break;
            case GAME_PLAYER_STATUS.ALL_IN:
                label.setString(gameString("All in"));
                label.setFontFillColor(cc.color(255, 204, 0));
                break;
            case GAME_PLAYER_STATUS.BIG_BLIND:
                label.setString("大盲注");
                label.setFontFillColor(cc.color(255, 204, 0));
                break;
            case GAME_PLAYER_STATUS.SMALL_BLIND:
                label.setString("小盲注");
                label.setFontFillColor(cc.color(255, 204, 0));
                break;
            case GAME_PLAYER_STATUS.BET:
                //原來的顯示，但玩原來的沒有看到這個字串 (last_cmd)
                //label.setString("選位下注");
                //label.setColor(cc.color(255, 204, 0));
                label.setString(this._playerData.nickname);
                label.setFontFillColor(JSColor.WHITE);
                break;
            default:
                label.setString(this._playerData.nickname);
                label.setFontFillColor(JSColor.WHITE);
                break;
        }

        // TODO 這邊要修改 是不是要加灰色的Shader
        if (status == GAME_PLAYER_STATUS.FOLD) {
            this.transToGray(true);
            this.runAction(cc.fadeTo(0.5, 120));
        } else {
            this.transToGray(false);
            this.runAction(cc.fadeTo(0.5, 255));
        }
    },

    /**
     * 更新玩家金錢
     */
    updateChips: function (value) {
        this._moneyLabel.setString(TexasUtility.getSimpleMoneyString(value));
        //noshowdown與showdown分錢後無法更新tableChips，更新是為了比賽時可以正確算自已的名次
        if (this._playerData) {
            this._playerData.tableChips = value;
        }
    },

    /**
     * 更新玩家資料
     */
    updateSeat: function (data) {
        if (data) {
            this.setVisible(data.getIsExist());

            // 判斷是否是自己
            this.setPlayerIsSelf(data.getIsSelf());

            // 大頭照
            this._photoSprite.setDefaultSprite(data.isMale ? "photo_male.png" : "photo_female.png");

            // 判斷是否有被禁言
            var photoURL = data.photoURL;
            if (DataModal.blacklistData.isAccountInList(data.account))
                photoURL = "";
            this._photoSprite.setPhotoUrlString(photoURL);

            // 金錢
            this._moneyLabel.setString(TexasUtility.getSimpleMoneyString(data.tableChips));

            this._identifyNode && this._identifyNode.setIdentity(data.identity);

            // 更新配件
            this._giftButton.refresh(data);

            // 更新積分階級圖片 多一層防呆判斷保險點
            if (GameRankClass.isValid(data.userClass) && !this._firstSitRankAnimation) {
                this._rankIconBtn.setVisible(true);
                this._rankIconNode.setLevelClass(data.userClass);
            } else {
                this._rankIconBtn.setVisible(false);
            }
            // 是自己才可以點
            this._rankIconBtn.setEnabled(data.getIsSelf());

            // 更新資訊
            this.refreshStatus();
        } else
            this.setVisible(false);

        this._playerData = data;
    },

    /**
     * 換位置後，要換SitNum，改變外觀位置
     * @param {sitNum} 畫面上的位置
     */
    setSitNum: function (sitNum) {
        this.sitNum = sitNum;

        // 判段畫面要在左右
        var isReverse = (sitNum > 4);
        this._handCardNode.setPositionX(isReverse ? -40 : 40);          // 手牌

        // this._giftButton.setPositionX(isReverse ? 31 : -31);            // 禮物盒按鈕 v1.3.4 改成固定右邊放積分Icon
    },

    /**
     * 設定大頭照是否為灰色
     * @param {value} 是否變色
     */
    transToGray: function (value) {
        this._photoSprite.setColor(value ? JSColor.GRAY : JSColor.WHITE);
    },

    /**
     * 是否倒數計時
     * @param {isPlay} 是否開始
     */
    playCountDown: function (isPlay, delay) {
        if (!this._playerData)
            return;

        delay = delay || 0;
        if (isPlay) {
            this._timerNode.start(parseInt(delay), this._playerData.getIsSelf());

            // 當開始撥放 代表要把狀態顯示成匿稱
            this.refreshStatus(GAME_PLAYER_STATUS.UNKNOW);
        } else {
            this._timerNode.stop();
        }
    },

    /**
     * 轉位完要重設，不然畫面會怪怪的
     */
    resetCountDown: function () {
        this._timerNode.reset();
    },

    /**
     * 更新身上的配件
     */
    updateAccessory: function () {
        // 更新配件
        this._giftButton.refresh(this._playerData);
    },

    /**
     * 更新黑名單將大頭照設置成預設
     */
    updateIsForbidden: function (photoUrl) {
        this._photoSprite.setPhotoUrlString(photoUrl);
    },

    /**
     * 坐下後出現階級的動畫
     * 閃個兩次後 跑到積分Icon那位置去
     * @param {GameRankClass} levelClass 階級
     */
    showFirstSitGameRankAnimation: function (levelClass) {
        // 先判斷這個階級是不是合法支援
        if (!GameRankClass.isValid(levelClass))
            return;

        this._firstSitRankAnimation = true;

        // 先創一個新的Icon圖放在頭像上
        var newRankIcon = new GameRankIconNode(levelClass);
        newRankIcon.setScale(0.7);
        this._mainNode.addChild(newRankIcon, 8);

        // 把原本的圖先顯示看不到
        var rankIconNode = this._rankIconNode;
        var rankIconBtn = this._rankIconBtn;
        rankIconBtn.setVisible(false);

        // 閃個兩下後跑去右下角
        newRankIcon.showShineAnimationAsync(2)
            .then(res => {
                // 跑去右下角
                var aniTime = 0.4;
                newRankIcon.runAction(cc.sequence(
                    cc.spawn(
                        cc.scaleTo(aniTime, rankIconNode.getScale()),
                        cc.moveTo(aniTime, rankIconBtn.getPosition())
                    ),
                    cc.callFunc(function () {
                        // 把原本圖示顯示出來
                        rankIconNode.setLevelClass(levelClass);
                        rankIconBtn.setVisible(true);

                        this._firstSitRankAnimation = false;
                    }, this),
                    cc.removeSelf()
                ));
            });
    },

    /**
     * 更改階級的動畫
     * 選轉兩次後 跑到積分Icon那位置去
     * @param {GameRankClass} levelClass 階級
     */
    showChangeGameRankClassAnimation: function (levelClass) {
        // 先判斷這個階級是不是合法支援
        if (!GameRankClass.isValid(levelClass))
            return;

        // 先創一個新的Icon圖放在頭像上
        var newRankIcon = new GameRankIconNode(levelClass);
        newRankIcon.setScale(0.7);
        this._mainNode.addChild(newRankIcon, 8);

        // 把原本的圖先顯示看不到
        var rankIconNode = this._rankIconNode;
        var rankIconBtn = this._rankIconBtn;
        rankIconBtn.setVisible(false);

        // 閃個兩下後跑去右下角
        newRankIcon.showTurnAnimationAsync()
            .then(res => {
                // 跑去右下角
                var aniTime = 0.4;
                newRankIcon.runAction(cc.sequence(
                    cc.spawn(
                        cc.scaleTo(aniTime, rankIconNode.getScale()),
                        cc.moveTo(aniTime, rankIconBtn.getPosition())
                    ),
                    cc.callFunc(function () {
                        // 把原本圖示顯示出來
                        rankIconNode.setLevelClass(levelClass);
                        rankIconBtn.setVisible(true);
                    }, this),
                    cc.removeSelf()
                ));
            });
    }
});
