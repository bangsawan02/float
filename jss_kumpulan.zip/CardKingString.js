var LocalizedString = LocalizedString || {};

(function () {
    var keyValue = {
        "牌王": "Raja Poker",
        "%d年第%d季蟬聯紀錄": "Rekor Juara Bertahan Tahun %d Season ke %d",
        "賽季倒數": "Season Countdown",
        "重置倒數": "Countdown hingga reset",
        "開放倒數": "Sisa Waktu",
        "局": "Ronde",
        "牌王%d級": "Peringkat Poker\nLevel %d",
        "盲注桌": "Meja Bet Poker",
        "VIP桌": "Meja VIP",
        "本季最高蟬聯數": "Juara Bertahan Season ini",
        "歷史最高蟬聯數": "Sejarah Juara Bertahan",
        "結算獎勵": "Penghitungan\nHadiah",
        "前往牌桌": "Ke Meja\n(Poker)",
        "牌王徽章": "Lencana",
        "說明": "Penjelasan",
        "5階級全達成額外送 %s 稱號 * %d": "Capai semua 5 level untuk dapatkan titel %s*%d",
        "點擊觀看不同階級": "Klik untuk lihat level lainnya",
        "牌王地圖": "Peta",
        "地圖每10分鐘更新一次": "Peta akan di refresh setiap 10 menit",

        "邀請好手": "Undang Pemain",
        "牌王戰帖": "Pemberitahuan Raja Poker",
        "委婉拒絕": "Tolak",
        "馬上前往": "Pergi ke Meja",
        "#!FFEE00!#[%s]\n#!FFFFFF!#正在%s/%s牌桌等您\n是否入桌挑戰他，勇奪牌王地位?": "#!FFEE00!#[%s]\n#!FFFFFF!#Sedang menunggu Anda di Meja bet %s/%s\nApakah Anda ingin terima tantangan ?",
        "已發出戰帖給 %d 位線上玩家": "Telah mengirimkan undangan ke %d untuk main bersama",

        "本季": "Season ini",
        "歷史\n蟬聯": "History Juara\nBertahan",
        "前往頁面": "Ke Raja Poker",
        "%d級": "Level %d",

        "資料統計中...": "Sedang dihitung....",
        "牌王系統結算中": "Raja Poker sedang dalam masa penghitungan",
        "牌王系統結算中...": "Raja Poker sedang dalam\nmasa penghitungan...",
        "牌王系統結算中\n（04:00~06:00 結算）": "Raja Poker sedang dalam masa penghitungan\n(Pkl. 04:00 WIB ~ Pkl. 06:00 WIB)",

        "太強了!\n恭喜您成為\n牌王%d級\n蟬聯局數最高玩家": "Hebat Sekali!\nSelamat Anda telah berhasil jadi\nRaja Poker Level %d\nPemain hebat dengan Juara Bertahan tertinggi",
        "確認": "OK",
        "略過動畫": "Lewati Animasi",
        "共%s人": "Total %s orang",

        "確定": "OK",
        "天": " hari",
        "時": " jm",
        "分": " mnt",
        "秒": " dtk",

        "本季已結束": "Season selesai",
    };

    LocalizedString.CardKing = function (str) {
        return USE_i18n ? (keyValue[str] || str) : str;
    };
})();
