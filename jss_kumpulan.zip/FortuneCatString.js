var LocalizedString = LocalizedString || {};

(function () {
    var keyValue = {
        "%d%%\n優惠": "Diskon\n%d%%",
        "使用%d%%加贈券獲得": "Gunakan %d%% kupon bonus\nuntuk dapat",
        "%dd天%hh時": "%dd Hari %hh Jm",
        "%hh時%mm分": "%hh Jm %mm Mnt",
        "%mm分%ss秒": "%mm Mnt %ss Dtk",
        "遇見招財貓的機會難得\n確定要放棄加碼優惠嗎?": "Lucky Cat sangat jarang muncul\nYakin ingin tinggalkan promo ini ?",
        "放棄": "Tutup",
        "享優惠": "Lihat lagi",
        "獲得%s德撲幣\n現賺%d%%優惠": "Mendapatkan %s Chips\nDiskon untung %d%%"
    };

    LocalizedString.fortuneCat = function (str) {
        return USE_i18n ? (keyValue[str] || str) : str;
    };
})();