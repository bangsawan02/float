var LocalizedString = LocalizedString || {};

(function () {
    var keyValue = {
        "領取(頁籤)": "Hadiah",
        "信件": "Surat",
        "朋友禮物": "Hadiah\nTeman",
        "您目前沒有獎勵呦!": "Tidak ada hadiah",
        "您目前沒有信件呦!": "Inbox kosong",
        "您目前沒有禮物呦!": "Tidak ada hadiah saat ini!",
        "%s 送禮給您": "%s  mengirimkan hadiah untuk Anda",
        "官方公告": "Pengumuman",
        "好康通知": "Benefit",
        "活動通知": "Event",
        "VIP專屬": "Spesial VIP",
        "VVIP尊函": "Spesial VVIP",
        "其他玩家的信": "Surat Teman",
        "信件有效期限14天，到期將自動刪除": "Surat otomatis dihapus setelah 14 hari",
        "寄件時間：": "Waktu kirim: ",
        "剩餘保存時間：%dd天%hh時": "Sisa waktu: %ddD%hhH",
        "剩餘保存時間：%hh時%mm分": "Sisa waktu: %hhH%mmM",
        "剩餘保存時間：%mm分%ss秒": "Sisa waktu: %mmM%ssS",
        "領取": "Ambil",
        "刪除信件": "Hapus",
        "馬上前往": "Lihat",
        "恭喜您": "Selamat",
        "提醒您": "Perhatian",
        "此信件已到期，\n將爲您自動刪除": "Surat sudah expired,\notomatis dihapus",
        "確定": "OK",
        "回禮": "Balas Hadiah"
    };

    LocalizedString.AwardAndMail = function (str) {
        return USE_i18n ? (keyValue[str] || str) : str;
    };
})();
