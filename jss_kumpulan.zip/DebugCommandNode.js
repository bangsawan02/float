/**
 * Created by yuki.huang on 2021/11/25.
 * 可傳cmd給自己
 * 要傳的cmd 在proj.web/SendCommandToSelfServer.js
 * createCommand function 裡面的參數改成想要傳的command
 */

var DebugCommandNode = cc.Node.extend({
    ctor: function () {
        this._super();

        this._checkURL = "http://localhost:9169/";

        if (cc.sys.os === cc.sys.OS_IOS) {
            // 先抓取App的路徑
            var path = this._filePath = jsb.fileUtils.fullPathForFilename("Info.plist");

            // 判斷是否為模擬器
            this._isSimulator = path.indexOf("CoreSimulator") > -1;

            this._checkURL = "http://localhost:9169/";

        }
        else if (cc.sys.os === cc.sys.OS_ANDROID) {
            // 先強制用true 之後再來寫 判斷是不是模擬器
            this._isSimulator = true;
            // android模擬器(Bluestack/夜神/android模擬器(as)) 連接localhost的ip=10.0.2.2
            this._checkURL = "http://10.0.2.2:9169/";
        }

        if (!this._isSimulator)
            return;


        // 每一段時間判斷是否要熱更新一次 (這裡用 runAction 才不會在切換遊戲時 SelectGameManager._changeGame -> unscheduleAll 被停掉)
        this.runAction(cc.sequence(cc.callFunc(() => this._checkHasCommand()), cc.delayTime(5)).repeatForever());
    },

    onEnter: function () {
        this._super();

        // 假如不是模擬器 把他砍掉
        if (!this._isSimulator)
            this.runAction(cc.removeSelf());
    },

    /**
     * 判斷是否有Command
     */
    _checkHasCommand: function () {
        // 定期去跟對方拿東西
        var postValue = JSON.stringify({
            OS: cc.sys.os
        });
        axios.post(this._checkURL, postValue)
            .then(res => {
                // 有資料才判斷
                if (res.data) {
                    DataProcess.sendCustomStringToSelf(res.data);
                }
            })
            .catch(error => {
            });
    },
});
