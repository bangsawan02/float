/**
 * 5.4.0 副系統 - 激戰任務翻譯
 * created by Jim.Chen
 */

var LocalizedString = LocalizedString || {};

(function () {
    var keyValue = {
        // 活動視窗
        "馬上玩": "Mulai",
        "名次": "Rank",
        "名字": "Username",
        "獎牌數": "Jumlah Medal",
        "獎勵": "Hadiah",
        "缺示": "Kosong",
        "未上榜": "Belum masuk\nranking",
        "比賽尚未開始\n敬請期待~": "Kompetisi belum dimulai\nMohon bersabar~",
        "榜上無人\n立即衝榜吧!": "Rank kosong\nSegera bersaing di Rank!",
        "活動已結束": "Event telah berakhir",

        // 推播提醒
        "取消提醒功能": "Fitur notifikasi telah dibatalkan",
        "已開啟鈴鐺，下一場比賽開賽10分鐘前提醒我": "Fitur notifikasi aktif akan mendapatkan pemberitahuan 10 menit sebelum kompetisi dimulai",
        "您剛剛已經刷新過了喔\n稍等再試試看吧": "Baru direfresh\nMohon tunggu sebentar lagi",
        "激戰任務即將開始，趕快回來參加唷": "Battle Mission telah dimulai,\nAyo segera ikutan",

        // icon訊息
        "名次-": "RANK-",
        "已結束": "Berakhir",
        "結算中": "Perhitungan",


    };

    LocalizedString.FierceBattle = function (str) {
        return USE_i18n ? (keyValue[str] || str) : str;
    };
})();
