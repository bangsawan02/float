/**
 * 每日寶箱標題的主題
 * DailyMissionDialog
 */
var DailyMissionThemeNode = cc.Node.extend({
    ctor: function () {
        this._super();

        switch (GS.theme) {
            case GSEnum.Theme.LEBARAN:
            //開齋月背景

            // v5.2.5版本 開齋主題不加東西 直接吃預設
            // var posY = 257 + JSScreenBonusHalfHeight;
            //
            // //標題
            // var titles = ["#lobby_pic_title_bg.png", "#lobby_word_title_reward.png"];
            // titles.forEach(cur => {
            //     var title = new cc.Sprite(cur);
            //     title.setPosition(JSScreenMidPos.x, posY);
            //     this.addChild(title);
            // });
            //
            // // 月亮裝飾
            // var themeSp = new cc.Sprite("#lebaran_pic_04.png");
            // themeSp.setPosition(161 + JSScreenBonusHalfWidth, posY);
            // this.addChild(themeSp);
            //
            // // 燈裝飾
            // var themeSp1 = new cc.Sprite("#lebaran_pic_03.png");
            // themeSp1.setPosition(353 + JSScreenBonusHalfWidth, posY);
            // this.addChild(themeSp1);
            //
            // break;
            default:
                //預設標題
                var titles = ["#lobby_pic_title_bg.png", "#lobby_word_title_reward.png"];
                titles.forEach(cur => {
                    var title = new cc.Sprite(cur);
                    title.setPosition(JSScreenMidPos.x, 257 + JSScreenBonusHalfHeight);
                    this.addChild(title, 1);
                });
                break;
        }
    }
});