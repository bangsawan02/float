/**
 * 寶箱獎勵畫面
 */

var ChestRewardDialog = BaseDialogLayer.extend({
    /**
     * @param param 獎勵的參數
     * param = {
     *     chestIndex: 1,                            // 預設寶箱的樣式 1 (目前只有6種寶箱 1~6)
     *     list: [
     *         { pic: "", txt: "" },                 // 一般獎品
     *         { pic: "", num: [99, 95, 6, 0] }      // 碎片  [目標數量, 目前擁有數量, 這次取得數量, 可合成幾片]
     *     ],
     *     titleName: "xxxx.png",                    // 客製化標題圖片
     *     isEnableSkipAnimation: false,             // 是否可以跳過動畫 (default: false)
     *     skipClickUserAnalytics: {                 // 點擊跳過按鈕的埋點
     *          type: n or [n, m],                   // 埋點
     *          kind: n,                             // 分群
     *     },
     * },
     * @param closeCallback
     * @param pathObj
     * pathObj = {
     *     PIECE_BASE_HOST: "URL",                          // 碎片圖檔的位置 沒有碎片可不傳
     *     REWARD_BASE_HOST: "URL",                         // 獎圖的位置 ex. GS.httpScheme + d.mwsrv.com/19_60/store/iapp/goods/
     *     SAVE_SHOPITEM_PATH: JSWriteablePath + "shop/"    // 圖片儲存的位置
     * }
     * @param needLoadFileArray 額外需要讀入的圖檔
     *
     * 使用範例:
     * [沒有碎片 & 用下載的圖檔]
     * let param = { chestIndex: "1", list: [{ pic: "5003.png", txt: "X1000000" }, { pic: "7018.png", txt: "X5" }] };
     * let callBack = () => {};
     * let pathObj = { REWARD_BASE_HOST: GS.httpScheme + "d.mwsrv.com/19_60/store/iapp/goods/", SAVE_SHOPITEM_PATH: JSWriteablePath + "shop/" };
     *
     * [用一般圖檔]
     * let param = { chestIndex: "1", list: [{ pic: "#XXXXX.png", txt: "X1000000" }, { pic: "#XXXXX.png", txt: "X5" }] };
     * 不用傳pathObj
     *
     * let chestDialog = new ChestRewardDialog(param, callBack, pathObj);
     * DialogManager.addDialog(chestDialog, false);
     */
    ctor: function (param, closeCallback, pathObj, needLoadFileArray = []) {
        this._super();

        this.key = "ChestRewardDialog";
        this.openNeedAnimation = false;

        this.setCascadeOpacityEnabled(true);

        // 記下param
        this._param = param;

        if (pathObj)
            this._pathObj = pathObj;

        // 關閉的時候的callback
        closeCallback && this.setCloseCallback(closeCallback);

        // 加Resources的Function
        this.loadFileArray = ["chestReward/chestReward.plist", "chestReward/chestReward.png"].concat(needLoadFileArray);

        // 動畫被跳過
        this._animationsSkipped = false;
    },

    loadFileDone: function () {
        this._super();

        let loadFileArray = this.loadFileArray;

        // 讀圖
        for (let i = 0, length = loadFileArray.length; i < length; i += 2) {
            cc.spriteFrameCache.addSpriteFrames(loadFileArray[i], loadFileArray[i + 1]);
        }

        // 讓背景淡入用的layer (不能取名this._animationLayer 因為BaseDialogLayer會用到)
        let aniLayer = this._rewardAnimationLayer = new cc.Layer();
        aniLayer.setCascadeOpacityEnabled(true);
        aniLayer.setContentSize(JSVisibleSize);
        aniLayer.setOpacity(0);
        this.addChild(aniLayer);

        // 背景
        let bgSprite = this.bgSprite = new cc.Sprite("background/chestReward_bg.jpg");
        let bgContentSize = bgSprite.getContentSize();
        bgSprite.setScale(JSVisibleSize.width / bgContentSize.width, JSVisibleSize.height / bgContentSize.height);
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite, -1);

        // 背景光芒
        let lightSprite = new cc.Sprite("#lobby_bg_reward.png");
        lightSprite.setScale(3.2);
        lightSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(lightSprite, -1);

        // 背景光芒二號
        lightSprite = new cc.Sprite("#lobby_pic_light_03.png");
        lightSprite.setScale(4.5);
        lightSprite.setOpacity(150);
        lightSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(lightSprite, -1);

        // 裝標題＆王冠的node 用來做跳出動畫
        let titleNode = this._titleNode = new cc.Node();
        titleNode.setCascadeOpacityEnabled(true);
        titleNode.setPosition(JSScreenMidPos.x, 154.5 + JSScreenBonusHeight);
        titleNode.setScale(0.6);
        titleNode.setVisible(false);
        aniLayer.addChild(titleNode);

        // 王冠動畫
        gaf.create("gaf/chestReward/chestReward_title.gaf", this, true, function (gafAsset) {
            let gafObject = gafAsset.createObjectAndRun(true);
            gafObject.setPosition(0, 53);
            titleNode.addChild(gafObject, -1);
        });

        // 標題背景
        let titleBgPosX = [-73.9, 73.9];
        titleBgPosX.forEach((curPosX, index) => {
            let bgSp = new cc.Sprite("#lobby_pic_ribbon.png");
            bgSp.setFlippedX(!!index);
            bgSp.setPosition(curPosX, 0);
            titleNode.addChild(bgSp);
        });

        // 畫面上的星星
        let lightPos = [
            cc.p(139, 76),
            cc.p(144, 135),
            cc.p(113, 218),
            cc.p(354, 82),
            cc.p(384, 258),
            cc.p(133, 242),
            cc.p(392, 118)];
        let lightScale = [1.5, 1.3, 1.5, 1.3, 1.7, 1.5, 1.7];
        lightPos.forEach((pos, index) => {
            let lightSprite = new cc.Sprite("#chestReward_pic_star_01.png");
            lightSprite.setScale(lightScale[index]);
            lightSprite.setOpacity(0);
            lightSprite.setPosition(pos.x + JSScreenBonusHalfWidth, pos.y + JSScreenBonusHalfHeight);
            aniLayer.addChild(lightSprite, 5);

            lightSprite.runAction(cc.repeatForever(cc.sequence(
                cc.delayTime(index * 0.3),
                cc.fadeIn(0.4),
                cc.delayTime(0.8),
                cc.fadeOut(0.4),
                cc.delayTime(JSCodeUtility.getRandomFloat(0.2, 0.9))
            )));
        });

        // 建立獎項
        this._createRewardNode();

        let menu = new cc.Menu();
        menu.setPosition(0, 0);
        this.addChild(menu, 10);

        // 確認按鈕
        let btnSize = cc.size(100, 35);
        let btnNodes = ButtonUtility.createArrayScale9Nodes(
            ["lobby_btn_01.png", "lobby_btn_01.png", "lobby_btn_06.png"], btnSize, LocalizedString.Common("確認"), 15,
            JSColor.BLACK);
        let button = this._button = new cc.MenuItemSprite(btnNodes[0], btnNodes[1], btnNodes[2],
            this._buttonClicked, this);
        button.setPosition(JSScreenMidPos.x, 30);
        button.setVisible(false);
        menu.addChild(button);

        // 跳過按鈕
        let skipButton = this._skipButton = ButtonUtility.createTextUnderLineButton(LocalizedString.Common("跳過"), JSColor.WHITE, 16);
        skipButton.setPosition(JSScreenBonusHalfWidth + 512 - 40, 30);
        skipButton.addTouchUpInsideAction(this._skipAnimeButtonClicked, this);
        skipButton.setVisible(false);
        aniLayer.addChild(skipButton);
        //  隔 0.5 秒再顯示，以免寶箱還沒放大
        if (this._param.skipClickUserAnalytics) {
            skipButton.runAction(cc.sequence(
                cc.delayTime(0.5),
                cc.show()
            ));
        }

        // 跳動畫表演
        this._playStartAnim(this._param.chestIndex);
    },

    onExit: function () {
        // 讓dialog繼續跳出
        DialogManager.resumeShowDialog();

        // 砍掉圖檔
        if (this._loadFileDone) {
            let loadFileArray = this.loadFileArray;
            for (let i = 0, length = loadFileArray.length; i < length; i += 2) {
                cc.spriteFrameCache.removeSpriteFramesFromFile(loadFileArray[i]);
            }
        }

        this._super();
    },

    _dialogOpenAnimationDone: function () {
        this._super();

        // 開啟期間不希望有人打開dialog
        DialogManager.pauseShowDialog();
    },

    /**
     * 創標題
     * 可以透過 param.titleName 換圖
     * 如果是特殊標題可以自行override
     * @override
     */
    _createTitleUI: function () {
        let param = this._param;
        let defaultTitleName = param.titleName ? param.titleName : "#chestReward_word_selamat.png";
        // 標題
        let titleSp = new cc.Sprite(defaultTitleName);
        titleSp.setPosition(0, 16);
        this._titleNode.addChild(titleSp);
    },

    /**
     * 表演開始動畫
     */
    _playStartAnim: function (chestIndex = 1) {
        if (this._animationsSkipped || this.__isDestroyed) return;
        let chestStartWorldPos = JSScreenMidPos;

        // 目前只有六種寶箱 防呆一下
        chestIndex = (chestIndex > 0) ? Math.min(chestIndex, 6) : 6;

        //GAF動畫
        let startPos = cc.pAdd(this.convertToNodeSpace(chestStartWorldPos), cc.p(2.5, 3));
        let endPos = this._chestPos = cc.p(JSScreenMidPos.x, 78 + JSScreenBonusHalfHeight);
        let chestAnimName = JSStringUtility.format("gaf/chestReward/chestReward_%02d.gaf", chestIndex);
        gaf.create(chestAnimName, this, true, (gafAsset) => {
            let gafObject = this._gafObject = gafAsset.createObjectAndRun(false);
            gafObject.setPosition(JSScreenMidPos);
            gafObject.setScale(0.33);
            this.addChild(gafObject, 1);

            // 寶箱移動到指定位置動畫
            this._moveChestAnim(startPos, endPos);
        });
    },

    /**
     * 建立獎項
     */
    _createRewardNode: function () {
        if (this._param && this._param.list) {
            // 放獎項的node
            let rewardNode = this._rewardNode = new GSAutoLayoutNode();
            rewardNode.setCascadeOpacityEnabled(true);
            rewardNode.setType(GSAutoLayout.TYPE.HORIZONTAL);
            rewardNode.setPosition(JSScreenMidPos.x, 167.5 + (JSScreenBonusHeight * 2 / 3));
            this._rewardAnimationLayer.addChild(rewardNode, 1);

            // 根據reward的數量決定獎項間距
            let rewardList = this._param.list;
            let rewardListLength = rewardList.length;
            let rewardOffsetX = [0, 0, 80, 40, 30, 25, 20];
            rewardNode.setSpace(rewardOffsetX[rewardList.length] || 0);

            // 建立獎勵項目
            let itemSize = cc.size(70, 64);
            let midPos = cc.p(itemSize.width / 2, itemSize.height / 2);
            let rewardItemList = this._rewardItemList = [];
            rewardList.forEach((currRewardObj, index) => {
                // 獎勵項目的node
                let itemNode = new cc.Node();
                itemNode.setCascadeOpacityEnabled(true);
                itemNode.setContentSize(itemSize);
                itemNode.setOpacity(0);
                // 讓後面的node ZOrder比前一個低，避免後面的壓到前一個的labelBg
                rewardNode.addChild(itemNode, rewardListLength - index);

                // 獎勵項目底圖
                let itemBg = new ccui.Scale9Sprite("chestReward_pic_info.png");
                itemBg.setPreferredSize(itemSize);
                itemBg.setPosition(midPos);
                itemNode.addChild(itemBg);

                // 做縮放用的node
                let animNode = itemNode.animNode = new cc.Node();
                animNode.setCascadeOpacityEnabled(true);
                animNode.setOpacity(0);
                animNode.setScale(0);
                animNode.setPosition(midPos);
                itemNode.addChild(animNode);

                // 獎勵的圖
                let imageName = currRewardObj.pic;
                // 防呆 沒png幫他加
                if (imageName.lastIndexOf(".png") < 0)
                    imageName = imageName + ".png";

                let isPiece = false;
                if (this._pathObj) {
                    isPiece = animNode.isPiece = JSCodeUtility.checkIsdefined(currRewardObj.num);  // 如果num不是undefined帶表示是碎片
                    let imageUrl = (isPiece ? this._pathObj.PIECE_BASE_HOST : this._pathObj.REWARD_BASE_HOST) + imageName;
                    let savePath = this._pathObj.SAVE_SHOPITEM_PATH + imageName;
                    let iconSp = new GSDownloadSprite("", imageUrl, savePath);
                    iconSp.setTargetSize(cc.size(50, 50));
                    animNode.addChild(iconSp);
                } else {
                    let iconSp = new cc.Sprite(imageName);
                    let spSize = iconSp.getContentSize();
                    let scale = (spSize.height > spSize.width) ? 50 / spSize.height : 50 / spSize.width;
                    iconSp.setScale(scale);
                    animNode.addChild(iconSp);
                }

                // 增加的數量Node
                let rewardLabelNode = new cc.Node();
                rewardLabelNode.setCascadeOpacityEnabled(true);
                animNode.addChild(rewardLabelNode);

                // 增加的數量文字
                let label = new cc.LabelTTF(currRewardObj.txt, JSFontBoldName, 13);
                label.setFontFillColor(JSColor.BLACK);
                rewardLabelNode.addChild(label, 2);

                // 抓文字的size
                let labelSize = label.getContentSize();

                // 增加的數量背景
                let labelBg = new ccui.Scale9Sprite("chestReward_pic_item.png");
                labelBg.setPreferredSize(cc.size(labelSize.width + 20, labelSize.height + 5));  // 加一點寬度
                rewardLabelNode.addChild(labelBg);

                // 額外調整文字位置
                let rewardLabelNodePos;
                // 碎片
                if (isPiece) {
                    let objLen = currRewardObj.num.length;
                    if (objLen >= 3) {
                        // 進度條數值
                        let goalShard = animNode.goalShard = JSCodeUtility.getIntValue(currRewardObj.num[0]);
                        let currentShard = JSCodeUtility.getIntValue(currRewardObj.num[1]);
                        let getShard = animNode.getShard = JSCodeUtility.getIntValue(currRewardObj.num[2]);
                        let composeAmount;
                        // 可合成的碎片數量
                        if (objLen === 4)
                            composeAmount = JSCodeUtility.getIntValue(currRewardObj.num[3]);
                        else
                            composeAmount = Math.floor((currentShard + getShard) / goalShard);
                        if (composeAmount === 0) {
                            rewardLabelNode.setVisible(false);
                        } else {
                            label.setString(JSStringUtility.format("+%d", composeAmount));
                            labelSize = label.getContentSize();
                            labelBg.setPreferredSize(cc.size(labelSize.width + 20, labelSize.height + 5));  // 加一點寬度
                        }

                        // 是否達到合成動畫
                        animNode.isNeedPieceAni = currentShard < getShard;
                        // 如果需要達到合成動畫代表實際要表演的片數等於 目標 - 拿到 + 目前有的
                        // ex [20, 1, 2] => 要從19(20 - 2 + 1) 演到 1
                        let baseShard = animNode.isNeedPieceAni
                            ? goalShard - (getShard % goalShard) + currentShard
                            : currentShard - getShard;
                        if (animNode.isNeedPieceAni) {
                            currentShard += goalShard;
                            // 紀錄是否演過動畫
                            animNode.isShowPieceAni = false;
                        }

                        animNode.currentShard = currentShard;

                        // 設定進度label的位置
                        let labelPos = cc.p(0, (-itemSize.height / 2) + 5);

                        // 任務進度
                        let progressLabel = animNode.progressLabel = new GSNumberLabel(baseShard, JSFontBoldName, 10);
                        progressLabel.setAnchorPoint(JSAnchorPoint.M_RIGHT);
                        progressLabel.setFontFillColor(JSColor.WHITE);
                        progressLabel.setPosition(labelPos);
                        progressLabel.setToNumber(baseShard, false);
                        progressLabel.setNumberUpdateCallback(this._updateProgressBar.bind(animNode));
                        animNode.addChild(progressLabel, 1);

                        // 任務目標
                        let goalStr = JSStringUtility.format("/%d", goalShard);
                        let goalLabel = new cc.LabelTTF(goalStr, JSFontBoldName, 10);
                        goalLabel.setAnchorPoint(JSAnchorPoint.M_LEFT);
                        goalLabel.setPosition(labelPos);
                        animNode.addChild(goalLabel, 1);

                        // 放進度條背景跟進度條統一縮放，看起來才會是準的
                        let barNode = new cc.Node();
                        barNode.setCascadeOpacityEnabled(true);
                        barNode.setScale(0.5, 1);
                        barNode.setPosition(labelPos);
                        animNode.addChild(barNode);

                        // 進度條背景
                        let progressBgSprite = new ccui.Scale9Sprite("lobby_bar_bg_02.png");
                        progressBgSprite.setPreferredSize(cc.size(137, 16));
                        barNode.addChild(progressBgSprite);

                        // 進度條
                        let progressBarSp = animNode.progressBarSp = new cc.ProgressTimer(new cc.Sprite("#lobby_bar_04.png"));
                        progressBarSp.setBarChangeRate(cc.p(1, 0));
                        progressBarSp.setMidpoint(cc.p(0, 0));
                        progressBarSp.setType(cc.ProgressTimer.TYPE_BAR);
                        progressBarSp.setPercentage(baseShard / goalShard * 100);
                        barNode.addChild(progressBarSp);

                        // 增加的碎片數
                        let pieceProgressLabel = new cc.LabelTTF(currRewardObj.txt, JSFontBoldName, 12);
                        pieceProgressLabel.setFontFillColor(JSColor.BLACK);
                        pieceProgressLabel.setAnchorPoint(JSAnchorPoint.M_LEFT);
                        pieceProgressLabel.setPosition(labelPos.x + 35, labelPos.y);
                        animNode.addChild(pieceProgressLabel);

                        // 設定增加的數量label及labelBg的位置
                        rewardLabelNodePos = cc.p(itemSize.width / 2 - 5, itemSize.height / 2 - 5);
                    }
                }
                // 一般獎勵
                else {
                    // 設定增加的數量label及背景的位置
                    rewardLabelNodePos = cc.p(0, (-itemSize.height / 2) + 5);
                }

                // 調整增加的數量label及背景的位置位置
                rewardLabelNode.setPosition(rewardLabelNodePos);

                // 存起來 之後要做動畫
                rewardItemList.push(itemNode);
            });
        } else
            this._closeDialogAnimation();
    },

    // 播放寶箱動畫
    _playChestAnimAsync: function (animName, rewardItem) {
        // 播放動畫
        return new Promise((resolve, reject) => {
            if (this.__isDestroyed || this._animationsSkipped) {
                return reject();
            }

            // 如果有傳獎勵項目進來 代表要表演獎勵跳出
            if (rewardItem)
                this._playRewardJumpAnim(rewardItem);

            let gafObject = this._gafObject;
            gafObject.playSequence(animName, false);
            gafObject.setSequenceDelegate(() => {
                // 監聽動畫播完
                resolve();
            });
        });
    },

    /**
     * 播放獎勵跳出動畫
     */
    _rewardShowAsync: function (rewardItem) {
        if (this._animationsSkipped || this.__isDestroyed) return Promise.resolve();
        // 獎勵項目背景淡入 內容縮放表演
        return new Promise(resolve => {
            if (this.__isDestroyed)
                return;

            rewardItem.runAction(cc.sequence(
                cc.fadeIn(0.2),
                cc.callFunc(resolve))
            );

            rewardItem.animNode.runAction(cc.sequence(
                cc.spawn(
                    cc.scaleTo(0.3, 1.4),
                    cc.fadeIn(0.3)
                ),
                cc.scaleTo(0.3, 1).easing(cc.easeBackOut()),
                cc.callFunc(
                    function () {
                        if (rewardItem.animNode.isPiece) {
                            let node = rewardItem.animNode;
                            node.progressLabel && node.progressLabel.setToNumber(node.currentShard);
                        }
                    }
                )
            ));
        });
    },

    // 寶箱移動到指定位置動畫
    _moveChestAnim: function (startPos, endPos) {
        if (this._animationsSkipped || this.__isDestroyed) return;
        let bezierConfig = [startPos, cc.pAdd(startPos, cc.p(-100, 200)), endPos];
        this._gafObject.runAction(
            cc.sequence(cc.delayTime(0.3),
                cc.spawn(
                    cc.bezierTo(.3, bezierConfig).easing(cc.easeOut(1.5)),
                    cc.scaleTo(.3, 1),
                    cc.callFunc(() => {
                        if (this.__isDestroyed)
                            return;

                        // 背景淡入
                        this._rewardAnimationLayer.runAction(cc.fadeIn(0.5));

                        // 創標題
                        this._createTitleUI();

                        // 獎勵標題跳出來
                        this._titleNode.runAction(cc.sequence(
                            cc.delayTime(1.3),  // 要等第二段播到打開寶箱再跳
                            cc.show(),
                            cc.spawn(
                                cc.moveBy(0.2, cc.p(0, 50)),
                                cc.scaleTo(0.2, 1)
                            )
                        ));

                        // 播第二段動畫 (跟寶箱移動同時) + (寶箱關閉打開) + 跳出獎勵 + (獎勵跳完 寶箱內光芒消失)
                        this._startOpenChestAnim();
                    })
                )
            )
        );
    },

    // 播第二段動畫 (跟寶箱移動同時) + (寶箱關閉打開) + 跳出獎勵 + (獎勵跳完 寶箱內光芒消失)
    _startOpenChestAnim: function () {
        if (this._animationsSkipped || this.__isDestroyed) return;
        // 播第二段動畫 (跟寶箱移動同時)
        this._playChestAnimAsync("play2")
            .then(() => {
                if (this.__isDestroyed)
                    return;

                // 重複播放第三段動畫 (寶箱關閉打開) + 跳出獎勵
                let rewardList = this._rewardItemList;
                rewardList.reduce(
                    (previousPromise, currObj) => previousPromise.then(() => this._playChestAnimAsync("play3", currObj)),
                    Promise.resolve()
                ).then(() => {
                    // 播第四段動畫 (獎勵跳完 寶箱內光芒消失)
                    if (this.__isDestroyed)
                        return;

                    this._playChestAnimAsync("play4");
                    this._button.setVisible(true);
                    this._skipButton.setVisible(false);
                });
            });
    },


    // 播放獎勵跳出動畫
    _playRewardJumpAnim: function (rewardItem) {
        if (this._animationsSkipped || this.__isDestroyed) return;
        if (!rewardItem)
            return;

        // 抓獎勵項目的worldPos
        let itemWorldPos = this._rewardNode.convertToWorldSpace(rewardItem.getPosition());

        /// 從寶箱裡出現的光點
        let lightSp = new cc.Sprite("#pic_light_01.png");
        lightSp.setPosition(cc.pAdd(this._chestPos, cc.p(-10, -3)));
        lightSp.setVisible(false);
        this.addChild(lightSp, 2);

        // 光點移動到獎勵的位置
        let lightMoveAsync = () => {
            return new Promise(resolve => {
                if (this.__isDestroyed)
                    return;

                lightSp.runAction(cc.sequence(
                    cc.delayTime(0.6),
                    cc.show(),
                    cc.spawn(
                        cc.moveTo(0.3, cc.pAdd(this._rewardAnimationLayer.convertToNodeSpace(itemWorldPos), cc.p(35, 0))),
                        cc.fadeTo(0.3, 100)
                    ),
                    cc.removeSelf(),
                    cc.callFunc(resolve)
                ));
            });
        };

        // 跑跳出獎勵項目的動畫 從寶箱飛出光點到獎勵項目的位置 => 獎勵項目跳出動畫
        lightMoveAsync().then(() => {
            if (this.__isDestroyed)
                return;

            this._rewardShowAsync(rewardItem);
        });
    },


    // 更新碎片進度
    _updateProgressBar: function (nowNumber) {
        // 如果目前的進度大於等於目標進度，代表會合成，要從0再繼續跑
        if (nowNumber >= this.goalShard) {
            // 把拿到的碎片數扣掉合成所需數
            this.getShard -= this.goalShard;
            this.progressLabel.setToNumber(0, false);

            // 如果還有剩下的
            if (this.getShard > 0) {
                // 設定要跑到滿
                this.progressLabel.setToNumber(this.goalShard);
            }
            // 如果等於0或者是負數
            else {
                // 只需要跑到結果的數量
                this.progressLabel.setToNumber(this.currentShard - this.goalShard);
            }
            this.isShowPieceAni = false;
        } else {
            this.progressBarSp.setPercentage(nowNumber / this.goalShard * 100);
        }

        if (!this.isShowPieceAni && nowNumber === this.goalShard) {
            // 碎片加上閃光轉圈動畫
            let sp = new cc.Sprite("#chestReward_bg_radiation_02.png");
            sp.setScale(0.2);
            sp.setOpacity(0);
            this.addChild(sp);

            sp.runAction(cc.sequence(
                    cc.callFunc(() => {
                        this.isShowPieceAni = true;
                    }),
                    cc.spawn(
                        cc.fadeIn(0.05),
                        cc.rotateBy(0.4, 360),
                        cc.scaleTo(0.25, 1)
                    ),
                    cc.delayTime(0.1),
                    cc.removeSelf()
                )
            );
        }
    },

    /**
     * 關掉畫面
     */
    _buttonClicked: function () {
        this._button.setVisible(false);

        this.runAction(cc.sequence(
            cc.fadeOut(0.2),
            cc.delayTime(0.1),
            cc.callFunc(() => {
                this._closeDialogAnimation();
            })
        ));
    },

    /**
     * 跳過動畫按鈕點擊
     */
    _skipAnimeButtonClicked: function () {
        // 送埋點
        // 目前應該有：
        // 埋點：5255 點擊略過動畫按鈕 (特定時段登入獎勵)
        if (this._param.skipClickUserAnalytics) {
            TexasUtility.sendUserAnalyticsTrack(this._param.skipClickUserAnalytics.type, this._param.skipClickUserAnalytics.kind);
        }

        this.skipAnimations();
        this._skipButton.setVisible(false);
    },

    /**
     * 跳過所有動畫
     */
    skipAnimations: function () {
        if (this._animationsSkipped || this.__isDestroyed) return;

        this._animationsSkipped = true;

        // 立即顯示所有獎勵項目
        this._rewardItemList.forEach(rewardItem => {
            rewardItem.stopAllActions();
            rewardItem.setOpacity(255);
            rewardItem.animNode.stopAllActions();
            rewardItem.animNode.setOpacity(255);
            rewardItem.animNode.setScale(1);
            if (rewardItem.animNode.isPiece) {
                rewardItem.animNode.progressLabel && rewardItem.animNode.progressLabel.setToNumber(rewardItem.animNode.currentShard);
            }
        });

        // 顯示確認按鈕
        this._button.setVisible(true);

        // 停止寶箱動畫
        if (this._gafObject) {
            this._gafObject.stopAllActions();
            this._gafObject.playSequence("play4", false);
        }

        // 顯示背景和標題
        this._rewardAnimationLayer.stopAllActions();
        this._rewardAnimationLayer.setOpacity(255);
        this._titleNode.stopAllActions();
        this._titleNode.setVisible(true);
        this._titleNode.setScale(1);
        this._titleNode.setPosition(JSScreenMidPos.x, 204.5 + JSScreenBonusHeight);
    }
});