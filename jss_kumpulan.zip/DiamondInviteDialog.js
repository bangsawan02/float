/**
 * 鑽石賽邀請的dialog
 * 繼承自AvatarDialog
 * diamondType  是紅鑽賽還是橙鑽賽
 * rank         假如是排名的話 會帶這一項
 */

var DiamondInviteDialog = AvatarDialog.extend({
    ctor: function (diamondType, rank = 0) {

        this._diamondType = diamondType;
        this._rank = rank;

        var competeString = LocalizedString.Compete;
        var obj = {
            key: "DiamondInviteDialog",
            buttons: [competeString("馬上參賽")],
            callback: (index) => {
                if (index === 0) {
                    if (rank === 0) {
                        // 埋點
                        DataProcess.sendString(JSStringUtility.format("compete_notify %d 4 1", this._diamondType - 1));
                    }
                    this._goCompete();
                }
            }
        };
        this._super(obj);

        // 沒有排名代表是邀請
        if (rank === 0) {
            // 埋點通知server邀請跳過了
            DataProcess.sendString(JSStringUtility.format("compete_notify %d 0", this._diamondType - 1));
        }
    },

    /**
     * 讀取素材完畢
     * @override
     */
    loadFileDone: function () {
        this._super();

        // 去要鑽石賽資料
        if (!DataModal.regionsData.sendRegionsData(RegionType.Texas)) {
            // 如果沒鑽石賽資料，先關掉按鈕
            this._buttons.forEach(cur => cur.setEnabled(false));
            // 拿到資料將按鈕打開
            GS.addListenerOnce("NotifyRefreshRoomList", () => {
                this._buttons.forEach(cur => cur.setEnabled(true));
            }, this);
        }

        var isRank = this._rank > 0;
        var isRedDiamond = this._diamondType === TexasGameData.Game.RED_DIAMOND;

        var animLayer = this._animationLayer;
        var competeString = LocalizedString.Compete;

        // 標題
        var titleString = isRank ? JSStringUtility.format("%s\n%s", competeString("本局比賽您獲得了"), JSStringUtility.format(competeString("第%d名"), this._rank))
            : isRedDiamond ? competeString("高端玩家專屬") : competeString("挑戰牌技巔峰");
        var titleLabel = new cc.LabelTTF(titleString, JSFontName, 19);
        titleLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        titleLabel.setFontFillColor(cc.color(230, 170, 0));
        titleLabel.setPosition(314 + JSScreenBonusHalfWidth, 218 + JSScreenBonusHalfHeight);
        animLayer.addChild(titleLabel);

        // 鑽石
        {
            // 背景光
            var lightSprite = new cc.Sprite("#bg_simple_alert.png");
            lightSprite.setPosition(314 + JSScreenBonusHalfWidth, 150 + JSScreenBonusHalfHeight);
            lightSprite.runAction(cc.rotateBy(2, 180).repeatForever());
            animLayer.addChild(lightSprite);

            // 鑽石底框
            var bgFrame = new cc.Sprite("#btn_compete_01.png");
            bgFrame.setPosition(lightSprite.getPosition());
            animLayer.addChild(bgFrame);

            // 鑽石
            var diamond = isRedDiamond ? "#pic_diamond_red.png" : "#pic_diamond_orange.png";
            var diamondSprite = new cc.Sprite(diamond);
            diamondSprite.setPosition(lightSprite.getPosition());
            animLayer.addChild(diamondSprite);

            // 絲帶
            var ribbonSprite = new cc.Sprite("#ribbon_01.png");
            ribbonSprite.setScale(1.3, 0.8);
            ribbonSprite.setPosition(cc.pSub(lightSprite.getPosition(), cc.p(0, 15)));
            animLayer.addChild(ribbonSprite);

            // 鑽石顏色
            var color = isRedDiamond ? "red" : "orange";
            var colorLabel = new cc.LabelTTF(competeString(color), JSFontName, 11);
            colorLabel.setPosition(cc.pAdd(ribbonSprite.getPosition(), cc.p(0, 3)));
            animLayer.addChild(colorLabel);
        }

        // 文案
        var content = isRank ? "挑戰牌技巔峰證明實力不敗"
            : isRedDiamond ? "邀您參賽" : "證明實力不敗";
        var contentLabel = new cc.LabelTTF(competeString(content), JSFontName, 12);
        contentLabel.setPosition(312 + JSScreenBonusHalfWidth, 100 + JSScreenBonusHalfHeight);
        animLayer.addChild(contentLabel);

        // 用一個倒數來判斷比賽時間結束關閉畫面
        var remainTime = 0;
        var competeStatus = DataModal.regionsData.competeStatus;
        if (competeStatus.closeTimeObject && competeStatus.closeTimeObject[this._diamondType]) {
            var closeTimeObject = competeStatus.closeTimeObject[this._diamondType];
            remainTime = (closeTimeObject.remainTime - (JSCodeUtility.getNowTime() - closeTimeObject.socketTime));
        }
        var time = new GSTimeLabel("", JSFontName, 10);
        time.setVisible(false);
        time.countdownSeconds(remainTime, () => {
            // 重要資料
            DataProcess.sendString("compete_status");

            // 關掉畫面
            this._closeDialogAnimation();

            // 跳時間到dialog
            if (this.isVisibleRecursive()) {
                DialogManager.addDialog(new AvatarDialog({
                    content: competeString("目前非比賽時間")
                }));
            }
        }, undefined);
        animLayer.addChild(time);
    },

    // 要去比賽桌
    _goCompete: function () {
        var competeString = LocalizedString.Compete;
        var list = DataModal.regionsData.tournament.normalRegions;
        if (list && list[this._diamondType]) {
            var param = list[this._diamondType];
            // 不能進比賽
            if (param.canJoin !== 1) {
                // 金錢不足
                if (param.requireCheck & RegionsData.DiamondCheck.money) {
                    // 埋點
                    DataProcess.sendString(JSStringUtility.format("compete_dialog %d 0 0", param.index + 1));

                    // 差多少錢
                    var lackMoney = param.needMoney - DataModal.profileData.money;

                    // 一般沒錢的Dialog
                    var paymentParamArray = DataModal.tournamentData.tournamentPayment;
                    if (paymentParamArray && paymentParamArray[GSEnum.Tournament.Diamond]) {
                        var paymentParam = paymentParamArray[GSEnum.Tournament.Diamond];
                        var obj = {
                            money: JSCodeUtility.getCurrencyString(lackMoney),
                            purchase: [paymentParam.serverID, paymentParam.verifyID]
                        };
                        DialogManager.addDialog(new AvatarDialog(DialogHelper("RoomNoMoneyWithCompete", obj)));
                    } else {
                        DialogManager.addDialog(new AvatarDialog(DialogHelper("RoomNoMoney", JSCodeUtility.getCurrencyString(lackMoney))));
                    }
                } else if (param.requireCheck & RegionsData.DiamondCheck.diamond) {
                    // 埋點
                    DataProcess.sendString(JSStringUtility.format("compete_dialog %d 1 0", param.index + 1));

                    var content = JSStringUtility.format("#!FFFFFF!#%s#!E6AA00!#%d#!FFFFFF!#%s%s",
                        competeString("尚缺"),
                        param.needDiamond,
                        competeString("鑽石就能參加比賽"),
                        competeString("立即參加紅鑽賽贏得鑽石")
                    );

                    // 跳dialog
                    DialogManager.addDialog(new AvatarDialog(DialogHelper("CompeteNoDiamond", content)));
                } else if (param.canJoin === -1) {
                    DialogManager.addDialog(new AvatarDialog({
                        content: competeString("目前非比賽時間")
                    }));
                }
            } else {
                // 加Loading
                GSLoading.addLoadingView();

                // 設定好GameData (導牌桌要記得設定)
                DataModal.setGameData(GSEnum.Game.Texas);

                // 送入桌cmd
                DataProcess.sendString("joinCompeteP " + param.joinKey);

                // 先設定開哪一頁
                DataModal.lobbyInfo.toLobbyOpenPage = LobbyOpenPage.ROOM;
                DataModal.lobbyInfo.lastGameMode = "Compete";
            }
        }
    }
});