/**
 * 通行證 - 目標代幣數量 Label
 * ```
 * Sample Config: {
 *     goalLabelBgFileName: "luxyPass_pic_frame_star_02.png",        // 目標代幣數量的背景圖
 *     goalLabelFinishBgFileName: "luxyPass_pic_frame_star_03.png",  // 目標代幣數量完成的背景圖
 *     goalLabelBgScale: 1,                                          // 目標代幣數量的背景圖縮放比例
 * }
 * ```
 */
var BasePassGoalLabel = cc.Node.extend({
    ctor: function (config) {
        this._super();

        this.setCascadeOpacityEnabled(true);
        this.setCascadeColorEnabled(true);

        this._bgSpriteFileName = config.goalLabelBgFileName || "luxyPass_pic_frame_star_02.png";
        this._finishBgSpriteName = config.goalLabelFinishBgFileName || "luxyPass_pic_frame_star_03.png";
        this._goalLabelBgScale = config.goalLabelBgScale || 1;

        // 數量背景
        let tokenBgSprite = this._tokenBgSprite = new GSShaderSprite("#" + this._bgSpriteFileName);
        tokenBgSprite.setScale(this._goalLabelBgScale);
        this.addChild(tokenBgSprite);

        // 等級
        let levelLabel = this._levelLabel = new cc.LabelTTF("", JSFontName, 10);
        levelLabel.setScale(this._goalLabelBgScale);
        this.addChild(levelLabel);
    },

    setFinish: function (isFinish) {
        this._tokenBgSprite.setSpriteFrame(isFinish ? this._finishBgSpriteName : this._bgSpriteFileName);
        this._levelLabel.setFontFillColor(isFinish ? cc.color(75, 15, 15) : JSColor.WHITE);
    },

    setString: function (str) {
        this._levelLabel.setString(str);
    }
});