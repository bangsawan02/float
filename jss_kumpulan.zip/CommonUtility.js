/**
 * Created by valerie on 2019/10/31.
 * Slot獨有的設定
 */

var CommonUtility = {};

/**
 * 本機端core版本
 */
CommonUtility.coreVersion = "";

/**
 * 此版本core包的基準版號(簡稱core base)
 */
CommonUtility.coreBase = "";

/**
 * 機台下載狀態 0:不用下載 1:熱更新 2:強更 3:error
 */
CommonUtility.slotDownloadType = 0;

/**
 * 是否從downloadScene來的
 */
CommonUtility.isFromDownloadScene = false;

/**
 * Slot移植設定 不用分平台
 * 下載base url
 * h5暫時預設an
 * v2.0.5開始不分平台，但跨APP版本的舊活動、全部收集冊，皆還是需要使用CommonUtility.replaceURLByOS分平台，因為舊版(v2.0.4)仍有分平台
 */
CommonUtility.OSString = "";
CommonUtility.platformString = cc.sys.isNative ? (cc.sys.os === cc.sys.OS_IOS ? "_HD" : "") : "";
CommonUtility.downloadBaseURL = GS.httpScheme + "//g.mwsrv.com/slots/domino/" + CommonUtility.OSString;
CommonUtility.downloadBaseURLNormal = GS.httpScheme + "//g.mwsrv.com/slots/domino/" + CommonUtility.OSString;
CommonUtility.downloadBaseURLDebug = GS.httpScheme + "//g.mwsrv.com/slots/domino/" + CommonUtility.OSString + "dev/";

/**
 * 機台圖檔儲存位置
 */
CommonUtility.slotsSavePath = JSWriteablePath + "slot/";

/**
 * Slot's feature money animation tag name
 * 機台內副功能專用金幣動畫tag name
 */
CommonUtility.gameFeatureMoneyAnimTagName = "";

CommonUtility.replaceURLByOS = function (url) {
    return url.replace("/wowslot/", "/wowslot/" + CommonUtility.OSString);
};

/**
 * 顯示CutScenesView 轉場動畫
 */
CommonUtility.showCutScenesView = function (type, isUseTimeOut) {
    // 沒啟用布條功能 或 直式介面(目前沒有直的布條) 不做事
    if (!SlotConfig.checkNeedCutScene())
        return;

    var notificationNode = cc.director.getNotificationNode();
    var cutScenesLayer = notificationNode.getChildByTag(9391);

    if (JSIsPortrait || JSNoServeQuickToSlotr) {
        // 直式機台因為沒有門簾,如果有創起來要關掉它
        cutScenesLayer && cutScenesLayer.dismiss();
        return;
    }

    if (cutScenesLayer == null) {
        cutScenesLayer = new CutscenesLayer(isUseTimeOut);
        cutScenesLayer.setTag(9391);
        notificationNode.addChild(cutScenesLayer, 1);
    }

    switch (type) {
        case GSEnum.CutscenesType.IN:
            // 進場轉場動畫(關上布幕)
            cutScenesLayer.showCutScenesInView();
            break;
        case GSEnum.CutscenesType.OUT:
            // 前一個動作為關上布條才做拉開布條的動作
            if (cutScenesLayer.nowType === CutscenesLayer.CUT_SCENE_TYPE.IN) {
                // 出場轉場動畫(拉開布幕)
                cutScenesLayer.showCutScenesOutView();
            } else {
                cutScenesLayer.dismiss();
            }
            break;
        case GSEnum.CutscenesType.FULL:
            // 完整轉場動畫(關上布幕→拉開布幕)
            cutScenesLayer.showCutScenesFullView();
            break;
    }
};

/**
 * 直接移除CutScenesView 轉場動畫
 */
CommonUtility.removeCutScenesView = function (forceRemove) {
    var cutScenesLayer = cc.director.getNotificationNode().getChildByTag(9391);
    if (cutScenesLayer) {
        cutScenesLayer.dismiss();

        if (forceRemove)
            cutScenesLayer.removeFromParent();
    }
};

/**
 *  檢查機台是否有下載
 */
CommonUtility.checkSlotMachineExist = function (sm_id) {
    var projectName = "Slot_" + sm_id;
    var versionKey = LobbySlotItemVersionKEY_Prefix + projectName;
    var isExist = parseInt(GS.localStorage.getItem(versionKey, "0"));

    if (isExist != 0) {
        return true;
    }

    return false;
};

/**
 * 檢查version的格式是否正確 正確格式:
 * "App版本號碼.熱更號碼"
 */
CommonUtility.checkVersionFormatCorrect = function () {
    var len = arguments.length;
    if (len === 0)
        return false;

    for (var i = 0; i < len; i++) {
        if (arguments[i].split(".").length < 2)
            return false;
    }

    return true;
};

/**
 * 檢查ver是否低於comparison
 * 建議使用此func前先用checkVersionFormatCorrect確認格式無誤
 * @param ver 被比較的version
 * @param comparison 比較的version
 */
CommonUtility.checkVersionIsBelow = function (ver, comparison) {
    var vList = ver.split(".").map(cur => parseInt(cur));
    var cList = comparison.split(".").map(cur => parseInt(cur));

    // App版本號碼較小 或 App版本號碼等於且熱更號碼較小
    return (vList[0] < cList[0]) || ((vList[0] === cList[0]) && (vList[1] < cList[1]));
};

/**
 * 檢查ver是否高於comparison
 * 建議使用此func前先用checkVersionFormatCorrect確認格式無誤
 * @param ver 被比較的version
 * @param comparison 比較的version
 */
CommonUtility.checkVersionIsAbove = function (ver, comparison) {
    var vList = ver.split(".").map(cur => parseInt(cur));
    var cList = comparison.split(".").map(cur => parseInt(cur));

    // App版本號碼較大 或 App版本號碼等於且熱更號碼較大
    return (vList[0] > cList[0]) || ((vList[0] === cList[0]) && (vList[1] > cList[1]));
};

/**
 * 將數字轉成縮寫文字表示 Slot移植設定 Domino用
 * @param number 數字
 * @param decimals 小數點幾位
 * @param deleteZero 要不要刪掉小數點最後的零
 */
CommonUtility.getSimpleNumber = function (number, decimals = 0, deleteZero = true) {
    //要由大到小排列
    var money_rule = [
        // {units: 15, simple: "trl"},   // 千兆  Slot移植設定 Domino用 不使用千兆縮寫
        {units: 12, simple: "trl"},   // 兆
        {units: 9, simple: "mlr"},    // 十億
        {units: 6, simple: "jt"},     // 百萬
        {units: 3, simple: "rb"},     // 千
        {units: 0, simple: ""}
    ];

    // 轉成字串跟確定是數字
    number = JSCodeUtility.getStringValue(number).match(/^[1-9]*\d*\.?\d*$/);
    number = (number ? number[0] : "").split(".");

    // 分開整數跟小數
    let integer = number[0];
    let decimal = number[1] || "";

    if (integer.length === 0 && decimal.length === 0) {
        return "";
    }

    // 先找到要用的單位
    let simpleRule = money_rule.find(obj => obj.units < integer.length);

    // 根據縮寫單位調整整數跟小數
    let pointIndex = integer.length - simpleRule.units;
    decimal = integer
        .concat(decimal)
        .substring(pointIndex, pointIndex + decimals);
    integer = integer.substring(0, pointIndex);

    if (deleteZero) {
        // 去掉小數最後的0
        let index = decimal.length - 1;
        for (; index > -1; index--) {
            if (decimal[index] !== "0") {
                break;
            }
        }
        decimal = decimal.substring(0, index + 1);
    }

    // 合併
    let result = integer;
    if (decimal.length > 0) {
        result += "." + decimal;
    }

    return result + simpleRule.simple;
};

/**
 * 將數字轉成縮寫文字表示，基於數字最大長度進行轉化
 * @param number 數字
 * @param maxDigitLength 最大數字長度
 * @param isUseCurrencyString 數字部分要不要用金錢符號
 */
CommonUtility.getSimpleNumberByLength = function (number, maxDigitLength, isUseCurrencyString) {
    // 轉成字串
    let numberString = JSCodeUtility.getStringValue(number);

    // 如果在設定範圍內不用處理，直接回傳
    if (numberString.length <= maxDigitLength || number === 0) {
        numberString = isUseCurrencyString ? JSCodeUtility.getCurrencyString(number) : number;
        return {
            string: numberString,
            digit: numberString,
            suffix: ""
        };
    }

    // Slot移植設定 Domino用 單位，目前到trl
    let moneySuffixArray = [
        [3, "rb"],      // 千
        [6, "jt"],      // 百萬
        [9, "mlr"],     // 十億
        [12, "trl"]     // 兆
    ];
    let moneySuffixMap = new Map(moneySuffixArray);

    // 計算可以減去的位數
    let simplifyNeededLength = numberString.length - maxDigitLength;
    let numberToDecrease = (Math.floor(simplifyNeededLength / 3) + 1) * 3;

    // 看有沒有超過目前有的單位
    let currentMaxUnit = moneySuffixArray[moneySuffixArray.length - 1][0];
    if (numberToDecrease > currentMaxUnit)
        numberToDecrease = currentMaxUnit;

    // 把單位對應的位數拿掉
    let displayNumber = numberString.slice(0, -numberToDecrease);
    let suffix = moneySuffixMap.get(numberToDecrease);
    displayNumber = isUseCurrencyString ? JSCodeUtility.getCurrencyString(displayNumber) : displayNumber;

    return {
        string: displayNumber + suffix,
        digit: displayNumber,
        suffix: suffix
    };
};

/*
 * 將convertToNodeSpace 取得的position再加上 OriginalPos
 */

CommonUtility.convertToNodeSpaceAddOriginalPos = function (worldPoint, target) {
    var pos = cc.pointApplyAffineTransform(worldPoint, target.getWorldToNodeTransform());
    return cc.pAdd(pos, JSOriginPoint);
};

/**
 *
 * @param nodeArray         要排序的所有Node
 */
CommonUtility.getIntegrateNodeAndChangePosX = function (nodeArray) {
    var containerNode = new cc.Node();

    var totalWidth = 0; //所有Node加起來的長度

    //先算總長度
    nodeArray.forEach(function (nodeItem) {
        totalWidth += nodeItem.getBoundingBox().width;
    });

    var nowNodeWidth = -totalWidth / 2; //目前node的長度

    //再去算各自的pos
    nodeArray.forEach(function (nodeItem) {
        nodeItem.setAnchorPoint(cc.p(0, 0.5));
        nodeItem.setPosition(nowNodeWidth, nodeItem.getPositionY());
        containerNode.addChild(nodeItem);

        nowNodeWidth += nodeItem.getBoundingBox().width;
    });

    return containerNode;
};

/**
 * 用圖片的Url轉成base64 string
 * @param url           連結
 * @param callback      callback
 */
CommonUtility.getBase64ByUrl = function (url, callback) {
    var img = new Image(),
        dataURL = '';
    img.setAttribute("crossOrigin", 'Anonymous');
    img.src = url;
    img.onload = function () {
        //讀取圖片
        var canvas = document.createElement("canvas"),
            //創建canvas
            width = img.width,
            //確保canvas尺寸跟圖形一樣大
            height = img.height;
        canvas.width = width;
        canvas.height = height;
        canvas.getContext("2d").drawImage(img, 0, 0, width, height); //將圖片繪製到canvas中
        dataURL = canvas.toDataURL('image/jpeg'); //轉換圖片為dataURL

        callback(dataURL);
    };
};

/**
 * 用RnaderTexture轉成base64 String
 * @param renderTexture
 * @param size              圖片大小
 * @returns {string}        回傳base64 String
 */
CommonUtility.getBase64ByRenderTexture = function (renderTexture, size) {
    var canvas = document.createElement('canvas');
    var ctx = canvas.getContext('2d');
    canvas.width = size.width;
    canvas.height = size.height;

    var width = Math.floor(size.width);
    var height = Math.floor(size.height);
    if (cc._renderType === cc.game.RENDER_TYPE_CANVAS) {
        var texture = renderTexture.getSprite().getTexture();
        var image = texture.getHtmlElementObj();
        ctx.drawImage(image, 0, 0);

        canvas.width = image.width;
        canvas.height = image.height;
    } else if (cc._renderType === cc.game.RENDER_TYPE_WEBGL) {
        var buffer = gl.createFramebuffer();
        gl.bindFramebuffer(gl.FRAMEBUFFER, buffer);
        var texture = renderTexture.getSprite().getTexture()._webTextureObj;

        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
        var data = new Uint8Array(width * height * 4);
        gl.readPixels(0, 0, width, height, gl.RGBA, gl.UNSIGNED_BYTE, data);
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);

        var rowBytes = width * 4;
        for (var row = 0; row < height; row++) {
            var srow = height - 1 - row;
            var data2 = new Uint8ClampedArray(data.buffer, srow * width * 4, rowBytes);
            var imageData = new ImageData(data2, width, 1);
            ctx.putImageData(imageData, 0, row);
        }
    }

    var dataURL = canvas.toDataURL("image/jpeg");
    return dataURL;
};

/**
 * 用Texture轉成base64 String
 * @param Texture
 * @returns {string}        回傳base64 String
 */
CommonUtility.getBase64ByTexture = function (texture) {
    var canvas = document.createElement('canvas');
    var ctx = canvas.getContext('2d');
    canvas.width = texture.width;
    canvas.height = texture.height;

    var width = Math.floor(texture.width);
    var height = Math.floor(texture.height);
    if (cc._renderType === cc.game.RENDER_TYPE_CANVAS) {
        var image = texture.getHtmlElementObj();
        ctx.drawImage(image, 0, 0);

        canvas.width = image.width;
        canvas.height = image.height;
    } else if (cc._renderType === cc.game.RENDER_TYPE_WEBGL) {
        var buffer = gl.createFramebuffer();
        gl.bindFramebuffer(gl.FRAMEBUFFER, buffer);

        var webTexture = texture._webTextureObj;
        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, webTexture, 0);
        var data = new Uint8Array(width * height * 4);
        gl.readPixels(0, 0, width, height, gl.RGBA, gl.UNSIGNED_BYTE, data);
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);

        var rowBytes = width * 4;
        for (var row = 0; row < height; row++) {
            var srow = row;
            var data2 = new Uint8ClampedArray(data.buffer, srow * width * 4, rowBytes);
            var imageData = new ImageData(data2, width, 1);
            ctx.putImageData(imageData, 0, row);
        }
    }

    var dataURL = canvas.toDataURL("image/jpeg");
    return dataURL;
};

/**
 * 設定最長字串
 */
CommonUtility.getMaxSizeString = function (obj, size) {
    if (obj.length > size) obj = obj.substr(0, size);
    return obj;
};

/**
 *
 * @param sprite   翻轉的obj, 目前可用 sprite 和 menuItem
 * @param newImage 翻轉後的圖
 * @param duration 翻轉時間,總時間為 2 x duration
 * @param finishCallback 翻轉結束後執行的funtion
 * @param changeCallback 翻轉換圖時執行的funtion
 */
CommonUtility.flipCardEffect = function (sprite, newImage, duration, finishCallback, changeCallback) {
    if (sprite && newImage) {
        duration = duration || 0.5;

        sprite.runAction(cc.sequence(cc.scaleTo(duration, 0, 1), cc.callFunc(function () {
            sprite.setSpriteFrame(newImage);
        }), cc.scaleTo(duration, 1, 1), cc.callFunc(function () {
            if (finishCallback) finishCallback();
        })).easing(cc.easeExponentialOut()));
    }
};

/**
 *
 * @param sprite   翻轉的menuItem
 * @param newImage 翻轉後的圖
 * @param duration 翻轉時間,總時間為 2 x duration
 * @param finishCallback 翻轉結束後執行的funtion
 * @param changeCallback 翻轉換圖時執行的funtion
 */
CommonUtility.flipCardMenuEffect = function (sprite, newImage, duration, finishCallback, changeCallback) {
    if (sprite && newImage) {
        duration = duration || 0.5;

        sprite.runAction(cc.sequence(cc.scaleTo(duration, 0, 1), cc.callFunc(function () {
            sprite.setNormalImage(new cc.Sprite(newImage));
            sprite.setSelectedImage(new cc.Sprite(newImage));
            sprite.setDisabledImage(new cc.Sprite(newImage));

            var offset = CurrentReelConfig.specificItemOffset[newImage.substr(1, newImage.length - 1)];
            sprite.getSelectedImage().setColor(cc.color(128, 128, 128));
            if (offset) {
                var spriteArray = [sprite.getNormalImage(), sprite.getSelectedImage(), sprite.getDisabledImage()];
                spriteArray.forEach((menuSprite) => {
                    menuSprite.setPosition(menuSprite.getPositionX() + offset.x, menuSprite.getPositionY() + offset.y);
                });
            }

            if (changeCallback) changeCallback();
        }), cc.scaleTo(duration, 1, 1), cc.callFunc(function () {
            if (finishCallback) finishCallback();
        })).easing(cc.easeExponentialOut()));
    }
};

/**
 *
 * @param node1   翻轉的obj, 目前可用 sprite 和 menuItem
 * @param node2   翻轉後的圖
 * @param duration 翻轉時間,總時間為 2 x duration
 * @param finishCallback 翻轉結束後執行的funtion
 * @param changeCallback 翻轉換圖時執行的funtion
 */
CommonUtility.flipNodeEffect = function (node1, node2, duration, finishCallback, changeCallback) {
    if (node1 && node2) {
        duration = duration || 0.5;
        node1.originalScale = node1.getScale();
        var node2Scale = {scaleX: node2.getScaleX(), scaleY: node2.getScaleY()};
        node1.runAction(cc.sequence(
            cc.scaleTo(duration, 0, node1.getScaleY()),
            cc.hide(),
            cc.callFunc(function () {
                node1.setScale(node1.originalScale);
                node2.setVisible(true);
                node2.setScale(0, node2.getScaleY());
                node2.runAction(cc.sequence(
                    cc.scaleTo(duration, node2Scale.scaleX, node2Scale.scaleY),
                    cc.callFunc(function () {
                        if (finishCallback) finishCallback();
                    }))
                );
            })
        ));
    }
};

CommonUtility.loginByFacebook = function (inLoginScene = true) {
    var fbLogin = function () {
        GSLoading.addBigLoadingView();

        DataModal.loginData.loginByFacebook(GSFacebookHelper.getToken());
    };

    if (GSFacebookHelper.isLoggedIn()) {
        //已登入過 開始走FB登入
        if (inLoginScene) {
            fbLogin();
        } else {
            //踢到登入頁再登入
            DataModal.loginData.logout();
            fbLogin();
        }
    } else {
        var isMobile = !cc.sys.isNative && cc.sys.isMobile;
        var useRedirect = false;

        //假如是Mobile iOS要判斷是否為Safari Android判斷是否在In-app browser
        if (isMobile) {
            var userAgent = window.navigator.userAgent.toLowerCase();

            if (cc.sys.os === cc.sys.OS_IOS) {
                //判斷是否Safari
                useRedirect = /safari/.test(userAgent);
            } else if (cc.sys.os === cc.sys.OS_ANDROID) {
                //判斷是否In-App Browser
                useRedirect = (GS.inAppBrowser !== GSEnum.InAppBrowser.NONE);
            } else {
                //其它平台 就先都這樣做
                useRedirect = true;
            }
        }

        if (useRedirect) {
            //把導出訊息關掉
            window.onbeforeunload = null;

            //把有導出記下來
            GS.localStorage.setItem("FBLoginRedirect", "1");

            var redirectPage = window.location;
            var permissions = "public_profile,user_friends";
            var permissionUrl = "https://m.facebook.com/dialog/oauth?client_id=" + GS.fbAppID + "&response_type=token&redirect_uri=" + redirectPage + "&scope=" + permissions;
            window.location = permissionUrl;
        } else {
            GSFacebookHelper.login(function (type, param) {
                if (type === 0) {
                    //開始走FB登入
                    if (inLoginScene)
                        fbLogin();
                    else {
                        //TODO tokenString 目前用不到 不需要傳
                        var tokenString = JSCodeUtility.getStringValue(param["accessToken"]);
                        if (tokenString.length > 0) {
                            CommonUtility.goLoginScene(undefined);
                        }
                    }
                } else if (type === 1 && cc.sys.isNative) {
                    // 原生的 然後又是Error 跳視窗
                    GSFacebookHelper.showError(param);
                }
            });
        }
    }
};

CommonUtility.getCoreBase = function (callback) {
    // core base, 可以用來判斷目前版本的基準
    var path = "core_sync.json";
    if (cc.sys.isNative) {
        var coreJson = jsb.fileUtils.getStringFromFile(path);
        if (jsb.fileUtils.isFileExist(path)) {
            var json = JSON.parse(coreJson);
            if (json && JSCodeUtility.checkIsdefined(json["version_base"])) {
                if (callback)
                    callback(json);
            }
        }
    } else {
        var path = "core_sync.json";
        cc.loader.loadJson(path, function (error, result) {
            if (!error) {
                var json = result;
                if (json && JSCodeUtility.checkIsdefined(json["version_base"])) {
                    if (callback)
                        callback(json);
                }
            } else {
                //失敗
                cc.log("讀取JS Json Error: ", error);
            }
        }.bind(this));
    }
};

CommonUtility.getCoreTimestamp = function (callback) {
    // 時間戳, 可以用來判斷目前的版本是否正確
    var path = "core_sync.json";
    if (cc.sys.isNative) {
        var coreJson = jsb.fileUtils.getStringFromFile(path);
        if (jsb.fileUtils.isFileExist(path)) {
            var json = JSON.parse(coreJson);
            if (json && JSCodeUtility.checkIsdefined(json["timestamp"])) {
                if (callback)
                    callback(json);
            }
        }
    } else {
        cc.loader.loadJson(path, function (error, result) {
            if (!error) {
                var json = result;
                if (json && JSCodeUtility.checkIsdefined(json["timestamp"])) {
                    if (callback)
                        callback(json);
                }
            } else {
                //失敗
                cc.log("讀取JS Json Error: ", error);
            }
        }.bind(this));
    }
};

CommonUtility.getCorePolyfillVersion = function (callback) {
    // 時間戳, 可以用來判斷目前的版本是否正確
    let path = "out_core_polyfill/CorePolyfill.json";
    if (cc.sys.isNative) {
        if (jsb.fileUtils.isFileExist(path)) {
            var coreJson = jsb.fileUtils.getStringFromFile(path);
            var json = JSON.parse(coreJson);
            if (json && JSCodeUtility.checkIsdefined(json["timestamp"])) {
                callback && callback(json);
            }
        } else {
            callback && callback();
        }
    } else {
        cc.loader.loadJson(path, function (error, result) {
            if (!error) {
                var json = result;
                if (json && JSCodeUtility.checkIsdefined(json["timestamp"])) {
                    if (callback)
                        callback(json);
                }
            } else {
                //失敗
                cc.log("讀取JS Json Error: ", error);
            }
        }.bind(this));
    }
};

CommonUtility.getSlotTimestamp = function (callback) {
    // 時間戳, 可以用來判斷目前的版本是否正確 Slot移植設定
    if (cc.sys.isNative) {
        var path = "Vegas_Download/" + CurrentReelConfig.projectName + "/" + CurrentReelConfig.projectName + ".json";
        var coreJson = jsb.fileUtils.getStringFromFile(path);
        if (jsb.fileUtils.isFileExist(path)) {
            var json = JSON.parse(coreJson);
            if (json && JSCodeUtility.checkIsdefined(json["timestamp"])) {
                if (callback)
                    callback(json);
            }
        }

    } else {
        // Slot移植設定
        var path = "out_slots/" + CurrentReelConfig.projectName + "/" + CurrentReelConfig.projectName + ".json";
        cc.loader.loadJson(path, function (error, result) {
            if (!error) {
                var json = result;
                if (json && JSCodeUtility.checkIsdefined(json["timestamp"])) {
                    if (callback)
                        callback(json);
                }
            } else {
                //失敗
                cc.log("讀取JS Json Error: ", error);
            }
        }.bind(this));
    }
};

CommonUtility.getEventTimestamp = function (jsonPath, callback) {
    // 時間戳, 可以用來判斷目前的版本是否正確
    if (cc.sys.isNative) {
        var path = JSStringUtility.format("%sout_events/%s", JSWriteablePath, jsonPath);
        var coreJson = jsb.fileUtils.getStringFromFile(path);
        if (jsb.fileUtils.isFileExist(path)) {
            var json = JSON.parse(coreJson);
            if (json && JSCodeUtility.checkIsdefined(json["timestamp"])) {
                if (callback)
                    callback(json);
            }
        }

    } else {
        var path = JSStringUtility.format("out_events/%s", jsonPath);
        cc.loader.loadJson(path, function (error, result) {
            if (!error) {
                var json = result;
                if (json && JSCodeUtility.checkIsdefined(json["timestamp"])) {
                    if (callback)
                        callback(json);
                }
            } else {
                //失敗
                cc.log("讀取JS Json Error: ", error);
            }
        }.bind(this));
    }
};

/**
 *  導更新app 下載頁
 */
CommonUtility.openAppUpdatePage = function () {
    if (cc.sys.os === cc.sys.OS_ANDROID) {
        cc.sys.openURL("https://play.google.com/store/apps/details?id=com.gamesofa.android.wowslot");
    } else {
        cc.sys.openURL("https://apps.apple.com/us/app/wow-casino-vegas-casino-slots/id1574467335");
    }
};

/**
 * Slot移植設定
 * "機台"到Lobby / Login畫面，支援直式轉橫式
 */
CommonUtility.goLobbyScene = function () {
    // 通知要完全離開機台
    GS.dispatchCustomEvent("NotifyUncacheSlotEffect");

    // 回大廳
    cc.loader.load(ChangeSceneHelper.getResources(GSEnum.Scene.Lobby), () => {
        if (JSIsPortrait) {
            // 如果原本是直版要先轉換回橫版
            // 只有 iPad Air4 直接轉會卡畫面，但不會crash，也沒有crash log，所以讓它晚點切換Scene
            cc.director.getRunningScene().setVisible(false);
            GSDeviceWrapper.setDeviceOrientation(false, () => {
                setTimeout(() => {
                    cc.director.getRunningScene().setVisible(true);
                    ChangeSceneHelper.goLobbyScene();
                }, 1);
            });
        } else {
            ChangeSceneHelper.goLobbyScene();
        }
    });
};

CommonUtility.goLoginScene = function (reLoginObj = undefined) {
    cc.loader.load(ChangeSceneHelper.getResources(GSEnum.Scene.Login), () => {
        if (JSIsPortrait) {
            GSDeviceWrapper.setDeviceOrientation(false, () => {
                cc.director.runScene(new LoginScene(reLoginObj));
            });
        } else {
            cc.director.runScene(new LoginScene(reLoginObj));
        }
    });
};

/**
 * 打開活動畫面，支援直式畫面轉橫顯示橫式畫面
 * @param target scene
 * @param func 要執行的func
 * @param isPushScene 是否為推畫面
 */
CommonUtility.goEventScene = function (target, func, isPushScene = true) {
    if (JSIsPortrait) {
        // pushScene才需要做場景保留
        if (isPushScene) {
            // 設定tag
            DataModal.isGoEventScene = true;
            // retain gaf 避免被砍了
            gaf.retainAllAsset();
            // 先暫停原本的畫面
            CommonUtility.gamePause(target);
        }

        // 推畫面
        GSDeviceWrapper.setDeviceOrientation(false, () => {
            if (isPushScene)
                cc.director.pushScene(new EventScene(func, isPushScene));
            else
                cc.director.runScene(new EventScene(func));
        });
    } else {
        // 橫式直接顯示畫面
        func && func();
    }
};

/**
 * 從活動畫面回來，搭配goEventScene使用
 * @param target
 */
CommonUtility.fromEventScene = function (target) {
    // 重置tag
    DataModal.isFromEventScene = false;
    // release gaf 避免砍不掉
    gaf.releaseAllAsset();
    // 恢復原本畫面
    CommonUtility.gameResume(target);

    GSLoading.removeLoadingView();
};

/**
 * Slot暫停/恢復
 */

CommonUtility.gamePause = function (target) {
    // 暫停所有node
    CommonUtility.pauseAllChild(target);
};

CommonUtility.gameResume = function (target) {
    // 重新開始所有node
    CommonUtility.resumeAllChild(target);
};

/**
 * 暫停所有node
 * @param node 要暫停的node
 */
CommonUtility.pauseAllChild = function (node) {
    node.getChildren().forEach(child => {
        if (child instanceof cc.ScrollView) {
            // FIXME ScrollView args在native會有問題，先跳過不暫停
            cc.warn("ScrollView args在native會有問題，先跳過不暫停");
        } else if (child instanceof SlotReelNode) {
            // 暫停Reel的schedule
            child.rollingClassArray.forEach(rollingClass => GS.pauseScheduleByTarget(rollingClass));

            child.pause();
            CommonUtility.pauseAllChild(child);
        } else {
            // 暫停node
            child.pause();
            CommonUtility.pauseAllChild(child);
        }
    });
};

/**
 * 重新開始所有node
 * @param node 要重新開始的node
 */
CommonUtility.resumeAllChild = function (node) {
    node.getChildren().forEach(child => {
        if (child instanceof cc.ScrollView) {
            // FIXME ScrollView args在native會有問題，跳過不resume
            cc.warn("ScrollView args在native會有問題，跳過不resume");
        } else if (child instanceof SlotReelNode) {
            // 恢復Reel的schedule
            child.rollingClassArray.forEach(rollingClass => GS.resumeScheduleByTarget(rollingClass));

            // 恢復node
            child.resume();
            CommonUtility.resumeAllChild(child);
        } else {
            // 恢復node
            child.resume();
            CommonUtility.resumeAllChild(child);
        }
    });
};

/**
 * 打平array
 * @param arr
 * @returns {*[]}
 */
CommonUtility.flat = function (arr) {
    return [].concat(...arr.map(x => Array.isArray(x) ? CommonUtility.flat(x) : x));
};

/**
 * 開網址送 Funnel資訊
 * @param id
 */
CommonUtility.trackWebFunnel = function (id, debug = false) {
    var funnelParam =
        {
            "machineid1": GSDeviceWrapper.getUUID(!JSDebugMode),
            "machineid2": GSDeviceWrapper.getAndroidID(),
            "machineid3": GSDeviceWrapper.getAnotherUUID(),
            "country": GSDeviceWrapper.getCountry(),
            "version": GS.gameVersion,
            "step": JSCodeUtility.getStringValue(id),
            "device": GS.platform,
            "appid": GS.bundleID
        };

    if (debug) {
        cc.log("track web debug: track_funnel " + JSON.stringify(funnelParam));
    } else {
        let xhr = new XMLHttpRequest();
        var trackUrl = GS.domain + "/mobile/pre_track_funnel.pl?cmd=track_funnel&value=" + JSON.stringify(funnelParam);
        xhr.open('GET', trackUrl, true);
        xhr.send();
    }
};

/**
 * 送 socket cmd
 * @param id
 */
CommonUtility.trackSocketFunnel = function (id, debug = false) {
    if (debug) {
        cc.log("track socket debug: track_funnel " + id);
    } else {
        DataProcess.sendString("track_funnel " + id);
    }
};