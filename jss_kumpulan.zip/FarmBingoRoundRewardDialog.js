/**
 * v5.6.0 齋戒副系統 賓果達成階段獎勵 dialog
 * @param callback? {Function} dialog 關閉後的 callback
 */
var FarmBingoRoundRewardDialog = BaseDialogLayer.extend({
    ctor: function () {
        this._super();

        this.dialogBgColor = cc.color(0, 0, 0, 200);

        var bingoData = DataModal.farmBingoData.bingoParam;

        var titleNode = this._titleNode = new cc.Node();
        titleNode.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 88);
        titleNode.setCascadeOpacityEnabled(true);
        titleNode.setScale(0);
        titleNode.setOpacity(0);
        this.addChild(titleNode, 1);

        // 標題
        var titleSprite = new cc.Sprite("#farm_bingo_w_title_award_02.png");
        titleSprite.setPosition(0, 10);
        titleNode.addChild(titleSprite);

        // Round spine
        var bagSpine = undefined;
        GSSpine.create("spine/ramadan/bingo_award_round/PIC_award_round", 0.25, (spine) => {
            spine.setAnimation(0, "animation", true);
            spine.setPosition(JSScreenMidPos);
            this.addChild(spine);
            bagSpine = spine;
        });

        // 裝底下獎勵底圖跟內容的node 用來跑動畫
        var rewardNode = this._rewardNode = new cc.Node();
        rewardNode.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 52);
        rewardNode.setCascadeOpacityEnabled(true);
        rewardNode.setOpacity(0);
        rewardNode.setScale(0);
        this.addChild(rewardNode, 1);

        // 獎勵框
        var frameSprite = new ccui.Scale9Sprite("farm_bingo_bg_frame_award.png");
        frameSprite.setPreferredSize(cc.size(400, 54));
        rewardNode.addChild(frameSprite);

        // chip
        var chipSprite = new cc.Sprite("#farm_bingo_pic_chip.png");
        chipSprite.setPosition(-105, 2);
        rewardNode.addChild(chipSprite);

        // 獎勵內容
        var countLabel = new cc.LabelTTF(JSStringUtility.format("%s Chips", JSCodeUtility.getCurrencyString(bingoData.round.reward)), JSFontName, 20);
        countLabel.setPosition(18, 2);
        countLabel.setFontFillColor(cc.color(81, 61, 26));
        rewardNode.addChild(countLabel);

        // 領獎按鈕
        var button = new Texas_Button(Texas_Button.Style.GREEN, cc.size(94, 33), LocalizedString.FarmBingo("領獎"));
        button.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 93);
        button.addTouchUpInsideAction(this.closeDialogAnimation, this);
        this.addChild(button, 1);
    },

    _startDialogAnimation: function () {
        let bgColorLayer = this._bgColorLayer;
        if (bgColorLayer) {
            bgColorLayer.stopAllActions();

            var toColor = this.dialogBgColor;
            bgColorLayer.runAction(cc.spawn(
                cc.tintTo(DIALOG_ANIMATION_TIME, toColor.r, toColor.g, toColor.b),
                cc.fadeTo(DIALOG_ANIMATION_TIME, toColor.a))
            );
        }

        this._titleNode.runAction(cc.sequence(
            cc.spawn(
                cc.scaleTo(0.2, 1.1),
                cc.fadeIn(0.2)
            ),
            cc.scaleTo(0.2, 1)
        ));

        this._rewardNode.runAction(cc.sequence(
            cc.spawn(
                cc.scaleTo(0.2, 1.1),
                cc.fadeIn(0.2)
            ),
            cc.scaleTo(0.2, 1)
        ));
    },

    _closeDialogAnimation: function () {
        // 關閉整個獎勵的 dialog
        this.runAction(cc.sequence(
            cc.fadeOut(0.2),
            cc.callFunc(() => {
                // 一切做完，呼叫 callback
                this.__closeCallback && this.__closeCallback();
            }),
            cc.removeSelf()
        ));
    },
});