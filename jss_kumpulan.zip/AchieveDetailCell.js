/**
 * 成就頁內的Cell
 */

var ACHIEVE_DETAIL_IMAGE_URL = "http://d.mwsrv.com/19_60/store/iapp/achievement/";

var AchieveDetailCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        this.setCascadeColorEnabled(true);
        this._param = null;

        // 背景
        var background = new ccui.Scale9Sprite("bg_white_20%.png");
        background.setPreferredSize(cc.size(JSVisibleSize.width - JSScreenBonusWidth - 26, 68));
        background.setAnchorPoint(0, 0);
        background.setPosition(13, 0);
        this.addChild(background);

        // 標題
        var title = this._titleLabel = new cc.LabelTTF("", JSFontBoldName, 20);
        title.setAnchorPoint(0, 0.5);
        title.setPosition(82, 54);
        this.addChild(title);

        // 獎勵
        var reward = new cc.LabelTTF(LocalizedString.Achieve("獎勵："), JSFontBoldName, 11);
        reward.setAnchorPoint(0, 0.5);
        reward.setPosition(82, 31);
        this.addChild(reward);

        // 獎勵內容
        var info = this._info = new cc.Node();
        info.setPosition(116, 31);
        this.addChild(info);

        // 副標題
        var subTitle = this._subTitleLabel = new cc.LabelTTF("", JSFontBoldName, 11);
        subTitle.setAnchorPoint(0, 0.5);
        subTitle.setPosition(82, 12);
        subTitle.setFontFillColor(cc.color(240, 200, 110));
        this.addChild(subTitle);

        // 左邊的成就圖片
        var image = this._image = new GSDownloadSprite();
        image.setTargetSize(cc.size(58, 58));
        image.setPosition(48, 34);
        this.addChild(image);

        // 右邊按鈕
        var btnSize = this._btnSize = cc.size(80, 40);
        var btnNode = new cc.Node();

        // 按鈕的底圖
        var buttonSprite = this._buttonSprite = new ccui.Scale9Sprite("btn_style_01_on.png");
        buttonSprite.setPreferredSize(btnSize);
        btnNode.addChild(buttonSprite);

        // 按鈕的文字
        var buttonLabel = this._buttonLabel = new GSRichTextNode("", JSFontBoldName, 16);
        buttonLabel.setHAlignmentToCenter(true);
        btnNode.addChild(buttonLabel);

        // 建立按鈕
        var button = this._button = new GSControlButton(btnNode, btnSize);
        button.enableTouchCancel(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        button.addTouchUpInsideAction(this._buttonClicked, this);
        button.setPosition(JSVisibleSize.width - JSScreenBonusWidth - 58, 34);
        this.addChild(button);
    },

    /**
     * 更新畫面
     */
    refreshCell: function (param) {
        this._param = param;

        // 左邊的成就圖片
        var imageURL = ACHIEVE_DETAIL_IMAGE_URL + param.icon + ".png";
        var savePath = JSWriteablePath + "AchieveIcon/" + param.icon;
        this._image.refreshByImageUrl(imageURL, savePath);

        // 標題
        this._titleLabel.setString(param.title);

        // 副標題
        this._subTitleLabel.setString(param.info);

        // 獎勵內容
        this._info.removeAllChildren();

        var achieveString = LocalizedString.Achieve;
        var paddingX = 0;
        var bonus = [param.bonus1, param.bonus3, param.bonus4, param.bonus2, param.bonus5];
        var infoTitle = ["德撲幣", "稱號", "物品", "勳章", "表情"];
        var num = 0;
        for (var i = 0; i < 5; i++) {

            // "德撲幣"為0不顯示，其它為""也不顯示；且最多顯示2個成就
            if ((i === 0) ? bonus[i] !== "0" : bonus[i] !== "" && num < 2) {

                // 產生內容 ex. 物品[西洋拳王30天]
                var content = [achieveString(infoTitle[i]), "[", bonus[i], "]"];
                for (var j = 0; j < 4; j++) {

                    // 錢的話要有"," ex.=100,000，其它依server吐的文字
                    var label = new cc.LabelTTF((i === 0 && j === 2) ? JSCodeUtility.getCurrencyString(content[j]) : content[j], JSFontBoldName, 11);
                    label.setAnchorPoint(0, 0.5);
                    label.setPositionX(paddingX);
                    this._info.addChild(label);

                    if (j === 2)
                        label.setFontFillColor(cc.color(0, 255, 255));

                    paddingX += label.getContentSize().width;
                }

                paddingX += 4;
                num++;
            }
        }

        // 按鈕
        if (param.complete) {
            // 已完成
            if (param.hasGetBonus) {
                this._buttonLabel.setText("#!000000!#" + achieveString("完成"), JSFontBoldName, 16);
                this._buttonSprite.setSpriteFrame("btn_style_01_null.png");
                this._button.setEnabled(false);
            } else {
                // 未領獎
                this._buttonLabel.setText(achieveString("領獎"), JSFontBoldName, 16);
                this._buttonSprite.setSpriteFrame("btn_style_01_on.png");
                this._button.setEnabled(true);
            }
        } else {
            if (param.isTimeout) {
                // 成就已過期
                this._buttonLabel.setText("#!000000!#" + achieveString("活動結束"), JSFontBoldName, 16);
                this._buttonSprite.setSpriteFrame("btn_style_01_null.png");
            } else {
                // x/x完成度
                this._buttonLabel.setText("#!FF0000!#" + param.rateTimes + "#!000000!#/" + param.rateNumber + "\n" + achieveString("完成度"), JSFontBoldName, 12);
                this._buttonSprite.setSpriteFrame("btn_style_01_null.png");
            }
            this._button.setEnabled(false);
        }

        // 重新修改一次按鈕的大小 不然在Native下會變回圖片原始的大小
        this._buttonSprite.setPreferredSize(this._btnSize);
    },

    /**
     * 按鈕相關
     */
    // 按下領獎按鈕
    _buttonClicked: function () {
        // 卡loading TODO: 要改成新loading
        GSLoading.addLoadingView(true);

        // 送出領獎指令
        var param = {
            "id": this._param.sid,
            "type": this._param.type
        };
        DataProcess.sendString("patch_achievement_reward " + JSON.stringify(param));
    },
});