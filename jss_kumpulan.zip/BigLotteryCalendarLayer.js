/**
 * [9T] 幸運彩票日曆node
 * Domino移植設定 調整介面/加上輪播
 */

var BigLotteryCalendarLayer = cc.Node.extend({
    ctor: function () {
        this._super();

        this._calendarData = [];        // 日曆資料
        this._pageIndex = 0;            // 現在在哪一頁(預設是0)
        this._pageDoneArray = [];       // 有哪些頁已經加完

        this._isScrolling = false;       // scroll view正在動

        // 下方的page view
        var pageSize = this._pageSize = cc.size(94, 110);
        var pageView = this._pageView = new ccui.PageView();
        pageView.setDirection(ccui.ScrollView.DIR_HORIZONTAL);
        pageView.setContentSize(pageSize);
        pageView.setBounceEnabled(true);                    // 滾到邊界回彈
        pageView.setIndicatorEnabled(true);                 // 下方白點可不可以拖拉
        pageView.setIndicatorIndexNodesScale(0.3);          // 下方白點大小
        pageView.setIndicatorSpaceBetweenIndexNodes(-8);    // 下方白點間距(白點寬 + 這個值)
        pageView.setIndicatorIndexNodesColor(JSColor.GRAY);
        pageView.setIndicatorSelectedIndexColor(JSColor.WHITE);
        pageView.setIndicatorPosition(cc.p(pageSize.width / 2 + 2, 0));
        this.addChild(pageView);

        // 移動要更新頁面
        pageView.addEventListener(() => {
            this._pageIndex = pageView.getCurrentPageIndex();
        });

        // 按鈕
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        this.addChild(menu, 1);

        // 一直更新現在畫面更新到哪些頁面
        this.schedule(this._scheduleUpdatePageView);

        // 預設不顯示
        this.setVisible(false);
    },

    // 一直去檢查PageView有沒有換頁 有的話判斷是否要處理下一頁的東西
    _scheduleUpdatePageView: function () {
        // 沒有資料不做事
        if (!this._calendarData || this._calendarData.length === 0)
            return;

        var pageView = this._pageView;
        var pageIndex = this._pageIndex = pageView.getCurrentPageIndex();
        var pageDoneArray = this._pageDoneArray;

        // 哪些頁要重創
        var needCreateArray = [];
        for (var i = pageIndex - 1; i <= pageIndex + 1; i++)
            pageDoneArray[i] === 0 && needCreateArray.push(i);

        needCreateArray.forEach(index => {
            // 要創
            var layout = this._pageArray[index];
            if (!layout)
                return;

            // Domino移植設定 無需Y位移
            var calendarNode = new BigLotteryCalendarNode(this._calendarData[index]);
            layout.addChild(calendarNode);

            // 記錄這頁好了
            this._pageDoneArray[index] = 1;
        });

    },

    refreshView: function (param) {
        // 以下Page的主畫面
        var pageView = this._pageView;
        pageView.removeAllPages();

        // 沒有資料隱藏畫面
        if (!param || param.length === 0) {
            this.setVisible(false);
        } else {
            this.setVisible(true);

            this._calendarData = param;
            this._pageArray = [];
            this._pageDoneArray = [];
            var totalPage = this._totalPage = param.length;

            for (var i = 0; i < totalPage; i++) {
                // 這邊先加空白的 等有移動到在加
                var layout = this._pageArray[i] = new ccui.Layout();
                layout.setContentSize(this._pageSize);
                pageView.addPage(layout);

                // 記錄哪些頁還沒創
                this._pageDoneArray[i] = 0;
            }

            // 判斷現在應該在哪一頁
            var nowPage = 0;
            param.some((cur, index) => {
                if (!cur.isExpired) {
                    nowPage = index;
                    return true;
                }
            });

            // 抓出預設頁面(防呆超出頁面)
            this._pageIndex = Math.min(nowPage, totalPage);
            pageView.setCurrentPageIndex(this._pageIndex);

            // 先處理一次1, 2頁
            this._scheduleUpdatePageView();

            // Domino移植設定 加上輪播動作
            // 停止之前的輪播動作
            this.stopAllActions();
            // 日曆輪播功能 5秒輪播一頁
            var nextPage = this._pageIndex + 1;
            this.runAction(cc.sequence(cc.delayTime(5), cc.callFunc(() => {

                if (nextPage != this._pageIndex + 1) {
                    // pageIndex有變更(玩家手動滑動過) 從新的頁數開始輪播
                    nextPage = this._pageIndex + 1;
                }

                if (nextPage > totalPage - 1) {
                    // 到最後一頁了 從頭開始
                    nextPage = 0;
                }
                // 滑到下一頁
                pageView.scrollToPage(nextPage);
                nextPage++;
            })).repeatForever());
        }
    }
});