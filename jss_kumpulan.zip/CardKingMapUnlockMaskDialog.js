/**
 * 跑牌王動畫用來擋touch的dialog
 */

var CardKingMapUnlockMaskDialog = BaseDialogLayer.extend({
    ctor: function (skipCallback) {
        this._super();

        this._skipCallback = skipCallback;

        this.key = "CardKingMapUnlockMaskDialog";

        // 鎖定返回鍵
        this.isLockBackKey = true;

        // 背景改成白色(跳過動畫時使用)
        this.dialogBgColor = cc.color(255, 255, 255, 180);

        // 關掉背景
        this._bgColorLayer.setColor(this.dialogBgColor);
        this._bgColorLayer.setVisible(false);

        // 不用跳出動畫 直接設定scale
        this._animationLayer.setScale(1);

        var animationLayer = this._animationLayer;

        var skipNode = this._skipNode = new cc.Node();
        skipNode.setCascadeOpacityEnabled(true);
        skipNode.setPosition(450 + JSScreenBonusWidth, 30);
        animationLayer.addChild(skipNode);

        // 文字背景
        var blackBg = TexasUtility.createBlackBgNode(cc.size(40, 22), 25);
        skipNode.addChild(blackBg);

        // 略過動畫
        var itemNodes = ButtonUtility.createBtnLabelWithUnderLine(LocalizedString.CardKing("略過動畫"), 12, JSColor.WHITE);
        var skipBtn = new GSControlButton(itemNodes[0]);
        skipBtn.addTouchUpInsideAction(this._skipAnimClicked, this);
        skipNode.addChild(skipBtn, 1);
    },

    /**
     * 做彈跳動畫
     * @override
     */
    _startDialogAnimation: function () {
        // 如果可以略過動畫 一秒後淡入按鈕
        var skipNode = this._skipNode;
        if (skipNode) {
            skipNode.setOpacity(0);
            skipNode.setVisible(false);
            skipNode.runAction(cc.sequence(
                cc.delayTime(1 / 6),
                cc.show(),
                cc.fadeIn(0.3)
            ));
        }
    },

    // 關閉dialog
    closeDialog: function () {
        this._closeDialogAnimation();
    },

    /**
     * 關掉Dialog
     * @override
     */
    _closeDialogAnimation: function () {
        if (this._closeAnimation)
            return;

        //  畫面直接淡出
        this.stopAllActions();
        this.runAction(cc.sequence(
            cc.fadeOut(DIALOG_ANIMATION_TIME),
            cc.removeSelf()
        ));

        this._closeAnimation = true;
    },

    /**
     * 按鈕
     */
    // 略過動畫按鈕
    _skipAnimClicked: function () {
        this._skipNode.setVisible(false);

        var bgColorLayer = this._bgColorLayer;
        bgColorLayer.setOpacity(0);
        bgColorLayer.setVisible(true);

        // 讓白背景閃一下後關閉dialog
        bgColorLayer.runAction(cc.sequence(
            cc.fadeTo(DIALOG_ANIMATION_TIME, this.dialogBgColor.a),
            cc.callFunc(() => {
                // 通知要略過動畫
                this._skipCallback && this._skipCallback();
            }),
            cc.callFunc(this._closeDialogAnimation, this)
        ));
    },
});