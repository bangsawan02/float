var BaccaratMoneyType = {
    Small_L: 1000000,
    Small_M: 10000000,
    Small_R: 50000000,
    Big_L: 100000000,
    Big_M: 500000000,
    Big_R: 5000000000,
    Small_L_Chips: "1jt",
    Small_M_Chips: "10jt",
    Small_R_Chips: "50jt",
    Big_L_Chips: "100jt",
    Big_M_Chips: "500jt",
    Big_R_Chips: "5mlr",

    Small_MAX: 200000000,           // 投注總上限 (小注)
    Big_MAX: 20000000000,           // 投注總上限 (大注)
};

// 用來對應小注到大注的金額Array
var BaccaratBetMoneyArray = [
    BaccaratMoneyType.Small_L,
    BaccaratMoneyType.Small_M,
    BaccaratMoneyType.Small_R,
    BaccaratMoneyType.Big_L,
    BaccaratMoneyType.Big_M,
    BaccaratMoneyType.Big_R,
];

// 大注桌所需要的錢
var BaccaratTableMaxMoney = 100000000;

// 下注區域Enum
var BaccaratZoneType = {
    PLAYER: 1,
    PLAYER_PAIR: 2,
    SERI: 3,
    BANKER_PAIR: 4,
    BANKER: 5,
};

// 下注區對應到結算Reslut的陣列位置
var BaccaratZoneTypeToResultPos = [];
BaccaratZoneTypeToResultPos[BaccaratZoneType.PLAYER] = 0;
BaccaratZoneTypeToResultPos[BaccaratZoneType.PLAYER_PAIR] = 1;
BaccaratZoneTypeToResultPos[BaccaratZoneType.SERI] = 2;
BaccaratZoneTypeToResultPos[BaccaratZoneType.BANKER_PAIR] = 3;
BaccaratZoneTypeToResultPos[BaccaratZoneType.BANKER] = 4;

// 下注的籌碼圖片跟數字
var BaccaratBetChips = [
    {money: BaccaratMoneyType.Small_L, image: "#vegas_chip_red.png"},
    {money: BaccaratMoneyType.Small_M, image: "#vegas_chip_blue.png"},
    {money: BaccaratMoneyType.Small_R, image: "#vegas_chip_green.png"},
    {money: BaccaratMoneyType.Big_L, image: "#vegas_chip_green.png"},
    {money: BaccaratMoneyType.Big_M, image: "#vegas_chip_orange.png"},
    {money: BaccaratMoneyType.Big_R, image: "#vegas_chip_red_gray.png"},
];

// 下注的賠率 對應到ZoneType
var BaccaratWinRatio = [0, 1, 11, 8, 11, 0.95];

// 下注籌碼的Offset
var BaccaratBetChipsOffset = [
    cc.p(-7, 0),
    cc.p(7, 0),
    cc.p(0, 10)
];

// 贏家的Type
var BaccaratWinType = {
    NONE: 0,
    PLAYER: 1,
    BANKER: 2,
    PLAYER_PAIR: 3,
    BANKER_PAIR: 4,
    SERI: 5,
};