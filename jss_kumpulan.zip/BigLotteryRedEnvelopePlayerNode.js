/**
 * 5.4.2 移植自中文德撲 by Jimmy.Wen
 * Created by terry on 2021/3/30.
 */

var BigLotteryRedEnvelopePlayerNode = cc.Node.extend({
    ctor: function () {
        this._super();

        var itemNode = new cc.Node();

        // 大頭照
        {
            // 玩家大頭照
            var stencilSprite = new cc.Sprite("#lobby_photo_clip.png");
            var clipNode = new cc.ClippingNode(stencilSprite);
            clipNode.setCascadeColorEnabled(true);
            clipNode.setAlphaThreshold(0.5);
            clipNode.setPositionX(-62);
            itemNode.addChild(clipNode);

            var photoSprite = this._photoSprite = new PhotoSprite("", 56, 56);
            clipNode.addChild(photoSprite);

            // 大頭照縮小
            clipNode.setScale(0.5);
        }

        // 玩家暱稱
        var nicknameLabel = this._playerNickName = new cc.LabelTTF("", JSFontBoldName, 12);
        nicknameLabel.enableStroke(cc.color(115, 15, 0, 255), 2);
        nicknameLabel.setPosition(18, 0);
        itemNode.addChild(nicknameLabel);
        this.setContentSize(cc.size(160, 36));

        // 按鈕
        var button = this._button = new GSControlButton(itemNode, cc.size(160, 30));
        button.addTouchUpInsideAction((sender) => {
            if (sender && sender.userID) {
                // 跳Dialog
                DialogManager.addDialog(new ProfileDialog(sender.userID), false);
            }
        }, this);
        button.enableTouchCancel(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        this.addChild(button);
    },

    // 更新玩家
    refreshByPlayerParam: function (param) {
        if (param) {
            this.setVisible(true);

            this._photoSprite.setPhotoUrlString(param.picUrl);

            // 玩家暱稱
            var nickname = param.nickname.length > 10 ? param.nickname.slice(0, 10) + '...' : param.nickname;
            this._playerNickName.setString(nickname);

            // 設定按鈕
            this._button.userID = param.userID;
        } else {
            this.setVisible(false);
        }
    }
});