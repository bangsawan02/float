/**
 * 9T 幸運彩票共用dialog
 *  obj = {
        key: "",                        // dialog的key
        titleImg: "",                   // 標題
        content: "",                    // 內文
        buttons: ["title"],             // 按鈕的文字
        btnFontColors:[cc.color],       // 按鈕的文字顏色
        btnImages: [],                  // 按鈕背景圖片
        btnSize: null,                  // 按鈕大小
        closeButton: 1,                 // 是否要右上角X按鈕
        callback: cb,                   // Callback
    }
 */
var BigLotteryCommonDialog = BaseDialogLayer.extend({
    ctor: function (obj) {
        this._super();

        this.key = obj.key || "BigLotteryCommonDialog";

        var aniLayer = this._animationLayer;
        this._buttons = [];
        this._callback = obj.callback;
        this._closeBtnNotClose = obj.closeBtnNotClose || false;

        // 預設值
        obj.bgSize = obj.bgSize || cc.size(400, 260);
        obj.titleImg = obj.titleImg || "#bigLottery_word_dialog_title.png";
        obj.content = obj.content || "";
        obj.buttons = obj.buttons || ["OK"];
        obj.btnFontColors = obj.btnFontColors || [JSColor.WHITE];
        obj.needFlower = obj.needFlower || false;

        // 按鈕預設的背景圖片 最右邊的按鈕背景要不一樣
        if (!obj.btnImages) {
            var btnImages = obj.btnImages = [];
            var len = obj.buttons.length;
            for (var i = 0; i < len; ++i) {
                btnImages.push("lobby_btn_01.png");
            }
        }
        obj.btnSize = obj.btnSize || cc.size(85, 35);

        // 背景
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(obj.bgSize);
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite);

        // 標題
        var titleSprite = new cc.Sprite(obj.titleImg);
        titleSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + obj.bgSize.height / 2 - titleSprite.getContentSize().height / 2 - 5);
        aniLayer.addChild(titleSprite);

        // 內文
        var contentLabel = new GSRichTextNode(obj.content, JSFontName, 14);
        contentLabel.setHAlignmentToCenter(true);
        contentLabel.setPosition(JSScreenMidPos);
        aniLayer.addChild(contentLabel);

        // 裝按鈕排版的node
        var btnAutoLayout = new GSAutoLayoutNode();
        btnAutoLayout.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - obj.bgSize.height / 2 + 30);
        btnAutoLayout.setSpace(10);
        aniLayer.addChild(btnAutoLayout);

        // 按鈕
        obj.buttons.forEach((cur, index) => {
            var bgStr = obj.btnImages[index] || "btn_style_01_on.png";
            var fontColor = bgStr.indexOf("null") > 0           // 假如是灰底的圖片 文字顏色要黑色
                ? JSColor.BLACK
                : obj.btnFontColors[index] || JSColor.WHITE;
            var btnItem = ButtonUtility.createArrayScale9Nodes([bgStr, bgStr], obj.btnSize, cur, 14, fontColor);
            btnItem.forEach(cur => cur.label.enableStroke(cc.color(0, 35, 90, 255), 2));
            var button = new GSControlButton(btnItem[0], obj.btnSize);
            button.addTouchUpInsideAction(this._buttonClicked, this);
            btnAutoLayout.addChild(button);

            this._buttons.push(button);
        });

        // Domino移植設定 調整位移
        // 關閉按鈕
        if (obj.closeButton) {
            var closeBtn = new Texas_CloseButton();
            closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
            closeBtn.setPosition(cc.pAdd(JSScreenMidPos, cc.p(obj.bgSize.width / 2 - 5, obj.bgSize.height / 2 - 5)));
            aniLayer.addChild(closeBtn);
        } else {
            // 沒有關閉按鈕鎖an返回
            this.isLockBackKey = true;
        }

        // 花朵
        if (obj.needFlower) {
            for (var i = 0; i < 2; i++) {
                var flowerSprite = new cc.Sprite("#bigLottery_pic_paperFlower.png");
                flowerSprite.setAnchorPoint((i === 0) ? cc.p(1, 0.5) : cc.p(0, 0.5));
                flowerSprite.setFlippedX(i === 0);
                flowerSprite.setPosition(JSScreenMidPos.x - 7 + ((i === 0) ? obj.bgSize.width / 2 : -obj.bgSize.width / 2), JSScreenMidPos.y);
                aniLayer.addChild(flowerSprite);
            }
        }
    },

    /**
     * 按鈕
     */

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        if (!this.isLockBackKey)
            this._closeBtnClicked();
    },

    // 關閉
    _closeBtnClicked: function () {
        MusicUtility.playEffect("Music/Effect/e_clickButton.mp3", false);

        if (this._callback)
            this._callback(-1);

        // 可以關掉
        if (!this._closeBtnNotClose)
            this._closeDialogAnimation();
    },

    // 下方主按鈕
    _buttonClicked: function (sender) {
        MusicUtility.playEffect("Music/Effect/e_clickButton.mp3", false);

        var index = 0;
        for (var i = 0; i < this._buttons.length; i++) {
            if (this._buttons[i] === sender) {
                index = i;
                break;
            }
        }

        if (this._callback)
            this._callback(index);

        this._closeDialogAnimation();
    }
});
