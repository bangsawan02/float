/**
 * 通行證 - TableView
 * config: {
 *     isHaveCycleReward: false,                    // 是否開啟循環獎勵功能
 *     tableViewSize: cc.size(0, 0),                // TableView 尺寸
 *     tableViewCellSize: cc.size(0, 0),            // TableView 普通獎勵 cell size
 *     tableViewCycleCellSize: cc.size(0, 0),       // TableView 循環獎勵 cell size
 *
 *     progressBarBgFileName: "",                   // 進度條背景圖檔
 *     progressBarThumbnailFileName: "",            // 進度條進度圖檔
 *     progressBarAnimeTime: 0.5,                   // 進度條動畫速度
 *     progressBarHeigh: 14,                        // 進度條高度
 * }
 */
var BasePassTableView = cc.TableView.extend({
    ctor: function (config) {
        this._config = config;

        let isHaveCycleReward = this._isHaveCycleReward = config.isHaveCycleReward;
        let tableSize = config.tableViewSize || cc.size(370, 170);
        let cellSize = this._cellSize = config.tableViewCellSize || BasePassRewardCell.NormalRewardCellSize;
        this._lastCellSize = isHaveCycleReward ? (config.tableViewCycleCellSize || BasePassRewardCell.CycleRewardCellSize) : cellSize;

        this._super(this, tableSize);

        this._rewardArray = [];
        this._currentTokenCount = 0;

        this.setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
    },

    /**
     * 更新 TableView 一般獎勵資料
     * @param {object[]}    rewardArray         獎勵資料陣列
     * @param {int}         currentTokenCount   目前擁有的代幣數量
     */
    updateNormalData: function (rewardArray, currentTokenCount) {
        this._rewardArray = rewardArray;
        this._currentTokenCount = currentTokenCount;
    },

    /**
     * 更新 TableView 循環獎勵資料
     * @param {boolean} isInCycleReward     是否在循環獎勵中
     * @param {number}  cycleTokenCount     目前擁有的循環代幣數量
     * @param {number}  cycleTokenRequired  循環獎勵目標代幣數量
     */
    updateCycleData: function (isInCycleReward, cycleTokenCount, cycleTokenRequired) {
        if (!this._isHaveCycleReward) {
            return;
        }

        this._isInCycleReward = isInCycleReward;
        this._cycleTokenRequired = cycleTokenRequired;
        this._cycleTokenCount = cycleTokenCount;
    },

    /**
     * Reload the data and refresh the TableView
     * @param reset
     */
    reloadData: function (reset) {
        if (this.__isDestroyed) {
            return;
        }

        this._super(reset);

        this._createProgressBar();
    },

    /**
     * 取得 cell size
     * @returns {*|cc.Size}
     */
    getCellSize: function () {
        return this._cellSize;
    },

    /**
     * 取得最後一個的 cell size
     */
    getLastCellSize: function () {
        return this._lastCellSize;
    },

    /**
     * 取得循環獎勵 Cell
     * @returns {BasePassRewardCell}
     */
    getCycleRewardCell: function () {
        return this._cycleRewardCell;
    },

    /** Table View Data Sources **/

    tableCellAtIndex: function (table, index) {
        let cell = table.dequeueCell();
        if (!cell) {
            cell = new BasePassRewardCell(this._config);
        }

        let rewardArray = this._rewardArray;
        let currentTokenCount = this._currentTokenCount;
        let cycleTokenCount = this._cycleTokenCount;
        let isHaveCycleReward = this._isHaveCycleReward;
        if (index < rewardArray.length) {
            // Normal rewards.
            cell.refreshCell(rewardArray[index], currentTokenCount);
        } else if (isHaveCycleReward && index === rewardArray.length) {
            // Cycle rewards
            let isInCycleReward = this._isInCycleReward;
            let cycleTokenRequired = this._cycleTokenRequired;
            cell.refreshCycleCell(isInCycleReward, cycleTokenCount, cycleTokenRequired);
            this._cycleRewardCell = cell;
        }

        this._onCellRefreshCallBack && this._onCellRefreshCallBack(index);
        return cell;
    },

    tableCellSizeForIndex: function (table, index) {
        return this._isHaveCycleReward && index === (this._rewardArray || []).length ? this._lastCellSize : this._cellSize;
    },

    numberOfCellsInTableView: function () {
        return this._rewardArray ? this._rewardArray.length + (this._isHaveCycleReward ? 1 : 0) : 0;
    },

    /** End of the Table View Data Source **/

    onCellRefresh: function (callback) {
        this._onCellRefreshCallBack = callback;
    },

    /** Start of the Progress Bar **/

    /**
     * 創進度條 會依照tableView的寬度去創造
     * 所以注意先讓tableView刷新
     */
    _createProgressBar: function () {
        if (this.__isDestroyed) {
            return;
        }

        // 先移除 progress bar
        if (this._progressBar) {
            this._progressBar.removeFromParent();
            this._progressBar = undefined;
        }

        // 再移除 clip node。因為進度條是 clip node 的子節點
        if (this._clipNode) {
            this._clipNode.removeFromParent();
            this._clipNode = undefined;
        }

        let tableViewWidth = this.getContentSize().width;
        // 扣掉最後一個cell的長度
        let stencilWidth = tableViewWidth - this.getLastCellSize().width / 2 + 10;
        // 進度條的長度要比clip要大一點才能有切齊的感覺
        let progressBarWidth = stencilWidth;

        // 放一個clipNode裁切一下進度條
        let stencil = new cc.LayerColor(cc.color(255, 255, 255, 255), stencilWidth, 14);
        let clipNode = this._clipNode = new cc.ClippingNode(stencil);
        clipNode.setPosition(0, this.getViewSize().height / 2 - 13);
        this.getContainer().addChild(clipNode, -1);

        let barH = this._config.progressBarHeigh || 14;

        // 進度條
        let progressBarBgFileName = this._config.progressBarBgFileName || "luxyPass_pic_bar_02.png";
        let progressBarThumbnailFileName = this._config.progressBarThumbnailFileName || "luxyPass_pic_bar_01.png";
        let progressBar = this._progressBar = new GSProgressTimer(
            progressBarBgFileName,
            progressBarThumbnailFileName,
            cc.size(progressBarWidth, barH),
            cc.size(progressBarWidth - 2, barH - 2), true);
        progressBar.setPosition((stencilWidth - 20) / 2, 7);
        progressBar.setAnimationTime(this._config.progressBarAnimeTime || 0.5);
        clipNode.addChild(progressBar);

        progressBar.fullWidth = progressBarWidth - 2;
    },

    /**
     * 取得進度條
     * @returns {*}
     */
    getProgressBar: function () {
        return this._progressBar;
    },

    /** End of the Progress Bar **/
});