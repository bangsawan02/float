/**
 * 龍虎機台用的直式儲值Dialog
 * ChineseStyle
 * DragonTiger 破產
 *
 * server埋點的東西
 C->S track_chinese_style_slot_recharge [破產分群] [編號]
 破產分群(小->大)：
 1: 1~75jt
 2: 75~500jt
 3: 500jt+
 編號定義：
 1: 首次彈跳
 2: 點第一個方案儲值按鈕
 3: 點第二個方案儲值按鈕
 4: 點關閉
 5: 點留下
 */

var DragonTigerBrokenCouponDialog = BaseDialogLayer.extend({
    ctor: function (defaultPlan) {
        this._super();

        this.key = "DragonTigerBrokenCouponDialog";
        this._defaultPlan = defaultPlan;

        // 需要讀取的素材
        this.loadFileArray = ["lobby/lobby_coupons.plist", "lobby/lobby_coupons.png"];
    },

    onExit: function () {
        this._loadFileDone && cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[0]);

        this._super();
    },

    /**
     * 讀取素材完畢
     * @override
     */
    loadFileDone: function () {
        this._super();

        // 先讀圖片Plist
        cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[0], this.loadFileArray[1]);

        // server埋點 1: 首次彈跳
        DataProcess.sendString(JSStringUtility.format("track_chinese_style_slot_recharge %d 1", this._defaultPlan + 1));

        DataModal.purchaseCouponData.dragonTigerBrokenCoupon.canShow = false;

        var aniLayer = this._animationLayer;

        // GAF動畫
        var gafNode = new cc.Node();
        aniLayer.addChild(gafNode);

        // dialog底圖
        var self = this;
        gaf.create("gaf/dragonTiger_dialog_show.gaf", this, true, function (gafAsset) {
            var gafObject = this._gafObject = gafAsset.createObjectAndRun(false);
            gafObject.setPosition(JSScreenMidPos);
            gafObject.runAction(cc.sequence(
                cc.callFunc(() => {
                    gafObject.stop();
                    gafObject.playSequence("start");
                    gafObject.start();
                }),
                cc.delayTime(0.5),
                cc.callFunc(() => {
                    self._createContent();
                    gafObject.stop();
                    gafObject.playSequence("repeat", true);
                    gafObject.start();
                })
            ));
            gafNode.addChild(gafObject);
        });

        // 金幣掉下來
        gaf.create("gaf/dragonTiger_money_fall.gaf", this, true, function (gafAsset) {
            var gafObject = gafAsset.createObjectAndRun(false);
            gafObject.setPosition(JSScreenMidPos);
            gafObject.setVisible(false);
            gafObject.stop();
            gafObject.runAction(cc.sequence(
                cc.delayTime(0.5),
                cc.callFunc(() => {
                    gafObject.playSequence("money_fall");
                    gafObject.setVisible(true);
                    gafObject.start();
                }),
                cc.delayTime(1),
                cc.callFunc(() => {
                    gafObject.stop();
                    gafObject.playSequence("money_repeat", true);
                    gafObject.start();
                })
            ));
            gafNode.addChild(gafObject, 1);
        });

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.setPosition(JSScreenMidPos.x + 125, JSScreenMidPos.y + 245);
        closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
        aniLayer.addChild(closeBtn, 2);

        GS.addListener("NotifyPurchaseSuccess", this.notifyPurchaseSuccess.bind(this), this);
    },

    // 創內容
    _createContent: function () {
        var aniLayer = this._animationLayer;
        var mainNode = new cc.Node();
        aniLayer.addChild(mainNode, 1);

        var data = DataModal.purchaseCouponData.dragonTigerBrokenCoupon;
        var param;

        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        aniLayer.addChild(menu, 2);

        var posYArray = [JSScreenMidPos.y - 10, JSScreenMidPos.y - 143];
        posYArray.forEach((curPos, idx) => {
            if (idx)
                param = data.lowerPlanArray[this._defaultPlan];
            else
                param = data.higherPlanArray[this._defaultPlan];

            // 可獲得籌碼背景
            var chipsNode = new cc.Node();
            chipsNode.setPosition(JSScreenMidPos.x + 33, curPos + 20);
            mainNode.addChild(chipsNode);

            var chipsBgSp = new cc.Sprite(JSStringUtility.format("#dragonTiger_bg_%02d.png", idx + 1));
            chipsNode.addChild(chipsBgSp);

            var numNode = new NumberSimpleNode(param.getChips, "dragonTiger_num_01", cc.size(14, 20), cc.size(8, 20), [cc.size(28, 20), cc.size(18, 20), cc.size(28, 20)], 2, 55, "%d");
            numNode.setScale(1.2);
            chipsNode.addChild(numNode);

            // 假如有第三方的話
            if (param.productIDList.length > 1) {
                var miniSp = new cc.Sprite("#dragonTiger_text_minimal.png");
                miniSp.setPosition(0, 28);
                chipsNode.addChild(miniSp);
            }

            // 左邊金幣圖
            var moneySp = new cc.Sprite(JSStringUtility.format("#dragonTiger_pic_money_%02d.png", idx + 1));
            moneySp.setPosition(JSScreenMidPos.x - 70 - (idx * 5), curPos - 5);
            mainNode.addChild(moneySp);

            // Bonus
            var bonusNode = new cc.Node();
            bonusNode.setPosition(JSScreenMidPos.x - 82, curPos + 55 - (idx * 5));
            mainNode.addChild(bonusNode);

            var bonusBgSp = new cc.Sprite("#dragonTiger_pic_bonus.png");
            bonusNode.addChild(bonusBgSp);

            var bonusSp = new cc.Sprite("#dragonTiger_text_bonus.png");
            bonusSp.setRotation(-20);
            bonusSp.setPosition(5, -3);
            bonusNode.addChild(bonusSp);

            // %數
            var bonusNumNode = new GSNumberNode(param.bonus, "dragonTiger_num_02", cc.size(10, 19), cc.size(0, 0), false, true, 0, "%d");
            bonusNumNode.setSuffixMark("dragonTiger_num_02_%.png", cc.size(15, 10));
            bonusNumNode.setRotation(-20);
            bonusNumNode.setAnchorPoint(0.5, 0);
            bonusNumNode.setPosition(3, 0);
            bonusNumNode.setNumber(param.bonus);
            bonusNode.addChild(bonusNumNode);

            var buyNodes = ButtonUtility.createSingleScale9SpriteNodes(["dragonTiger_btn_green_on.png", "dragonTiger_btn_green_down.png", "dragonTiger_btn_green_down.png"], null, "#dragonTiger_text_buy.png");
            var buyBtn = new cc.MenuItemSprite(buyNodes[0], buyNodes[1], this._clickBuyButton, this);
            buyBtn.setTag(idx);
            buyBtn.setPosition(30 + JSScreenMidPos.x, curPos - 23);
            menu.addChild(buyBtn);
        })
    },

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        this._closeBtnClicked();
    },

    /**
     * 按鈕
     */
    // 按下關閉按鈕
    _closeBtnClicked: function () {
        // server埋點 4: 點關閉
        DataProcess.sendString(JSStringUtility.format("track_chinese_style_slot_recharge %d 4", this._defaultPlan + 1));

        var couponString = LocalizedString.PurchaseCoupon;

        var param = {
            bgSize: cc.size(240, 250),
            content: couponString("確定要放棄嗎?"),
            buttons: [couponString("立刻買"), couponString("要放棄")],
            btnImages: ["lobby_btn_01.png", "lobby_btn_03.png"],
            btnSize: cc.size(85, 30),
            btnFontColors: [JSColor.WHITE, JSColor.WHITE],
            callback: (index) => {
                if (index === 0) {
                    // server埋點 5: 點留下
                    DataProcess.sendString(JSStringUtility.format("track_chinese_style_slot_recharge %d 5", this._defaultPlan + 1));
                } else if (index === 1) {
                    // TODO 有優惠券 通知顯示直版儲值中心提示 // TODO 埋點
                    if (DataModal.purchaseData.isHaveCoupon()) {
                        GS.dispatchCustomEvent('NotifyVipSlotPurchaseLayer_V_Hint', 2);
                    }

                    // 關掉儲值視窗
                    this._closeDialogAnimation();
                }
            }
        };
        DialogManager.addDialog(new Dialog(param), false);
    },

    // 按下購買按鈕
    _clickBuyButton: function (sender) {
        var couponParam = DataModal.purchaseCouponData.dragonTigerBrokenCoupon;
        var tag = sender && sender.getTag();
        var purchaseParam;
        if (tag)
            purchaseParam = couponParam.lowerPlanArray[this._defaultPlan];
        else
            purchaseParam = couponParam.higherPlanArray[this._defaultPlan];

        var productIDList = purchaseParam.productIDList;
        // 只有一個 送儲值
        if (productIDList.length === 1)
            DataModal.purchaseData.sendPurchase(productIDList[0]);

        if (productIDList.length > 1) {
            var dialog = new ProviderChooseDialog(purchaseParam);
            DialogManager.addDialog(dialog, false);
        }

        // server埋點 2: 點第一個方案儲值按鈕 3: 點第二個方案儲值按鈕
        DataProcess.sendString(JSStringUtility.format("track_chinese_style_slot_recharge %d %d", this._defaultPlan + 1, tag + 2));
    },

    /**
     * 通知
     */
    // 通知儲值成功
    notifyPurchaseSuccess: function () {
        // 沒有顯示的時候不處理
        if (!this.isVisibleRecursive())
            return;

        this._closeDialogAnimation();
    }
});