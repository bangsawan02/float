/**
 * 熱更資源包版本
 * 工具會改 手改的剁手手
 */
var BundleVersion = {
    "VegasMapMission": "5.5.2"
};