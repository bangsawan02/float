/**
 * 牌王教學頁
 */

var CardKingTeachLayer = cc.Layer.extend({
    ctor: function (pos) {
        this._super();

        // 提示泡泡匡
        var hintLabel = new cc.LabelTTF(LocalizedString.CardKing("點擊觀看不同階級"), JSFontName, 12);
        hintLabel.setFontFillColor(JSColor.BLACK);

        // 避免超出螢幕
        var padding = ((hintLabel.getContentSize().width / 2 + 7) - pos.x);
        padding = Math.max(padding, 0);

        if (padding > 0)
            padding += (JSScreenSafeHeight / 2);

        var param = {
            mainNode: hintLabel,
            style: BaseMessageNode.Style.WHITE_SHADOW,
            direct: BaseMessageNode.Direct.DOWN,
            arrowType: BaseMessageNode.ArrowType.STRAIGHT,
            arrowPadding: padding,
            closeCallback: () => this.removeFromParent()
        };
        var messageNode = this._messageNode = new BaseMessageNode(param);
        messageNode.setPosition(pos.x, pos.y + 16);
        messageNode.show();
        this.addChild(messageNode);

        // 接收touch
        var dummyTouch = new DummyTouchLayer(JSVisibleSize);
        dummyTouch.setOnTouchCallback(this._leaveLayer.bind(this));
        this.addChild(dummyTouch);
    },

    onEnter: function () {
        this._super();

        PushScene.addBackKeyEnableLayer(this);
    },

    onExit: function () {
        PushScene.removeBackKeyEnableLayer(this);

        this._super();
    },

    keyBackPressed: function () {
        this._leaveLayer();
    },

    _leaveLayer: function () {
        this._messageNode.close();
    }
});