/**
 * Cangkulan的牌
 */
var CapsaSusun_CardNode = PokerCardNode.extend({
    ctor: function (number, type) {
        this._super(number, type);

        // 排序手牌使用
        this.cardSortNumber = this.getCounterBySort(number);

        // 各墩排序使用
        this.cardStackSortNumber = this.getCounterByStackSort(number);
    },

    /**
     * 各墩比大小使用(數字大->小 黑桃->愛心->梅花->紅磚)
     * @returns {number}
     */
    getCounterByStackSort: function () {
        var cardCount = 0;
        if (this.cardNumber.length >= 2) {
            switch (this.cardNumber[0]) {
                case '1':
                    //黑桃
                    cardCount = 4;
                    break;
                case '2':
                    //紅心
                    cardCount = 3;
                    break;
                case '3':
                    //紅磚
                    cardCount = 1;
                    break;
                case '4':
                    //梅花
                    cardCount = 2;
                    break;
            }

            switch (this.cardNumber[1]) {
                case '1':
                    cardCount += 140;
                    break;
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9': {
                    cardCount += (Number.parseInt(this.cardNumber[1]) * 10);
                    break;
                }
                case 'T': {
                    cardCount += 100;
                    break;
                }
                case 'J': {
                    cardCount += 110;
                    break;
                }
                case 'Q': {
                    cardCount += 120;
                    break;
                }
                case 'K': {
                    cardCount += 130;
                    break;
                }
            }
        }
        return cardCount;
    },

    /**
     * 比大小使用 各層比大小使用(數字小->大 黑桃->愛心->梅花->紅磚)
     * @returns {number}
     */
    getCounterBySort: function () {
        var cardCount = 0;
        if (this.cardNumber.length >= 2) {
            switch (this.cardNumber[0]) {
                case '1':
                    //黑桃
                    cardCount = 1;
                    break;
                case '2':
                    //紅心
                    cardCount = 2;
                    break;
                case '3':
                    //紅磚
                    cardCount = 4;
                    break;
                case '4':
                    //梅花
                    cardCount = 3;
                    break;
            }

            switch (this.cardNumber[1]) {
                case '1':
                    cardCount += 140;
                    break;
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9': {
                    cardCount += (Number.parseInt(this.cardNumber[1]) * 10);
                    break;
                }
                case 'T': {
                    cardCount += 100;
                    break;
                }
                case 'J': {
                    cardCount += 110;
                    break;
                }
                case 'Q': {
                    cardCount += 120;
                    break;
                }
                case 'K': {
                    cardCount += 130;
                    break;
                }
            }
        }
        return cardCount;
    }

});