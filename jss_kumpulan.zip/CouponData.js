/**
 * 記有關儲值優惠相關的資料 (首購卡)
 */

var CouponData = cc.Class.extend({
    ctor: function () {

        //註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            "show_coupon_info": this.cmd_show_coupon_info,
            "show_coupon_advance": this.cmd_show_coupon_advance,
        });
    },

    //抓取進大廳所需要的資訊
    startGetInfo: function () {
        // 要先送 show_coupon_info 因為server會因為這指令處理一些東西
        DataProcess.sendString("show_coupon_info");
    },

    /**
     * Socket Callback
     */
    cmd_show_coupon_info: function (key, value) {
        if (DataModal.profileData.isBlackAccount)
            return;

        // 假如是1 代表有coupon
        var jsonValue = JSON.parse(value);
        var couponValue = jsonValue[0] && JSCodeUtility.getIntValue(jsonValue[0]);
        if (couponValue === 1) {
            if (DataModal.profileData.coupon.code === 1) {
                // code 1是生日券 通知跳生日券介面
                GS.dispatchCustomEvent("NotifyShowCouponBirthday");

                // 通知UI秀下方的儲值提示
                GS.dispatchCustomEvent("NotifyShowPurchasePromote");
            } else {
                // 再跟server要資料
                DataProcess.sendString("show_coupon_advance");
            }
        } else {
            // 0的話 通知UI顯示大廳的Coupon優惠 因為1的話要等到 show_coupon_advance 在決定要不要出現
            GS.dispatchCustomEvent("NotifyShowPurchasePromote");
        }
    },

    // 回傳有哪些coupon
    cmd_show_coupon_advance: function (key, value) {
        if (!PushScene.isLobby)
            return;

        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value);

        var couponParam = {};
        var success = JSCodeUtility.getIntValue(jsonValue["success"]) === 1;
        if (success) {
            // 哪一種coupon
            couponParam.type = JSCodeUtility.getIntValue(jsonValue["type"]);

            // 提示訊息
            couponParam.tips = JSCodeUtility.getIntValue(jsonValue["tips"]);

            // 使用者是否打開禮物過
            couponParam.isOpened = JSCodeUtility.getIntValue(jsonValue["open"]) === 1;

            // 目前狀態 0:關閉
            couponParam.status = JSCodeUtility.getStringValue(jsonValue["status"]) || "0";

            if (couponParam.isOpened || couponParam.status === "0")
                return;

            // 獎勵列表
            couponParam.rewardList = (jsonValue["rewardList"] || []).map(cur => {
                return {
                    // 是否為指定獎勵(有的話只有一個是specify = 1)
                    isSpecify: JSCodeUtility.getIntValue(cur["specify"]) === 1,

                    // 獎勵
                    reward: JSCodeUtility.getStringValue(cur["msg"]),

                    // 剩餘時間
                    remainTime: JSCodeUtility.getIntValue(cur["time"]),
                };
            });
        } else {
            // 訊息
            couponParam.errMessage = JSCodeUtility.getStringValue(jsonValue["message"]);
        }

        // 跳Dialog
        switch (couponParam.status) {
            case "A":
            case "B":
                // 晶鑽卡A 要等領完才能出現儲值提示
                if (couponParam.status === "B")
                    GS.dispatchCustomEvent("NotifyShowPurchasePromote");

                // 要跳Dialog
                DialogManager.addLobbyDialog(new CouponAdvanceDialog(couponParam));
                break;
            default:
                // 通知UI秀下方的儲值提示
                GS.dispatchCustomEvent("NotifyShowPurchasePromote");
                break;
        }
    },
});