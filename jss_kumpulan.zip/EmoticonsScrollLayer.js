var EmoticonsScrollLayer = cc.Layer.extend({
    ctor: function (isGameGaple) {
        this._super();

        this._isGameGaple = isGameGaple;

        this.setCascadeOpacityEnabled(true);

        // 先讀材質之後拿掉
        cc.spriteFrameCache.addSpriteFrames("game/emoticons.plist", "game/emoticons.png");

        var pageSize = cc.size(205, 175);
        var pageViewPos = cc.p(7, 35);
        var indicatorPosX = 0;
        var shopPos = cc.p(10, 160);
        if (isGameGaple) {
            pageSize = cc.size(162, 145);
            pageViewPos = cc.p(42, 43);
            indicatorPosX = 5;
            shopPos = cc.p(3, 135);
        }
        this._pageSize = pageSize;
        this._shopPos = shopPos;

        var pageView = this._pageView = new ccui.PageView();
        pageView.setPosition(pageViewPos);
        pageView.setDirection(ccui.ScrollView.DIR_HORIZONTAL);
        pageView.setContentSize(pageSize);
        pageView.setBounceEnabled(true);
        pageView.setIndicatorEnabled(true);
        pageView.setIndicatorSpaceBetweenIndexNodes(10);
        pageView.setIndicatorIndexNodesTexture("lobby_page_point_0.png", ccui.Widget.PLIST_TEXTURE);
        pageView.setIndicatorSelectedIndexColor(cc.color(255, 255, 255));
        pageView.setIndicatorPosition(cc.p(pageSize.width / 2, indicatorPosX));
        pageView.addEventListener(function () {
            // 更新最後的頁面
            GS.localStorage.setItem("LastMoodPage", pageView.getCurrentPageIndex().toString());
        });
        this.addChild(pageView);

        // 第一頁是常用
        this._pageArray = [];
        for (var i = 0; i < 6; i++) {
            var layout = this._pageArray[i] = new ccui.Layout();
            layout.setContentSize(this._pageSize);
            pageView.addPage(layout);

            this._createPage(i);
        }

        // 註冊
        GS.addListener("NotifyGetCampMoodList", this.notifyGetCampMoodList.bind(this), this);
        GS.addListener("NotifyGetStoreMoodList", this.notifyGetStoreMoodList.bind(this), this);
    },

    onEnter: function () {
        this._super();

        // 上次關閉頁面停在哪一頁 要在onEnter做才有用的樣子
        var startPageIndex = parseInt(GS.localStorage.getItem("LastMoodPage", "1"));
        if (startPageIndex === 0) {
            // 如果在第0頁 且常用表情是空的話 指到第一頁
            var lastEmoticonJson = JSON.parse(GS.localStorage.getItem("LastUsedEmoticon2", "[]"));
            if (lastEmoticonJson.length === 0)
                startPageIndex = 1;
        }
        this._pageView.setCurrentPageIndex(startPageIndex);
    },

    onExit: function () {
        cc.spriteFrameCache.removeSpriteFramesFromFile("game/emoticons.plist");

        this._super();
    },

    _getPosition: function (index, isHaveHintString) {
        if (this._isGameGaple) {
            if (isHaveHintString)
                return cc.p(20 + 40 * (index % 4), 108 - 35 * (Math.floor(index / 4)));
            else
                return cc.p(20 + 40 * (index % 4), 125 - 44 * (Math.floor(index / 4)));
        } else
            return cc.p(20 + 50 * (index % 4), 132 - 44 * (Math.floor(index / 4)));
    },

    // 創頁面的東西
    _createPage: function (pageIndex) {
        // 先砍掉舊的
        var page = this._pageArray[pageIndex];
        if (!page)
            return;

        page.removeAllChildren();

        // 計算剩餘時間用
        var nowTime = JSCodeUtility.getNowTime();
        var decreaseTime = nowTime - DataModal.moodData.moodSocketTime;

        var gameString = LocalizedString.Game;
        if (pageIndex === 0) {
            // 常用的表情
            var infoLabel = new cc.LabelTTF(gameString("常用表情"), JSFontBoldName, 8);
            infoLabel.setAnchorPoint(0, 0.5);
            infoLabel.setFontFillColor(JSColor.WHITE);
            infoLabel.setPosition(this._shopPos);
            page.addChild(infoLabel);

            // 抓出常用的資訊
            var lastEmoticonJson = JSON.parse(GS.localStorage.getItem("LastUsedEmoticon2", "[]"));
            lastEmoticonJson.forEach((cur, index) => {
                var emoticon = new EmoticonsNode(cur.type, cur.index, decreaseTime, this._emoticonClicked, this);
                emoticon.setPosition(this._getPosition(index, true));
                emoticon.setScale(0.5);
                page.addChild(emoticon);
            });
        } else {
            // 因頁數轉成表情的Type
            var hintString = undefined;
            var emoticonType;
            switch (pageIndex) {
                case 1:
                    emoticonType = EmoticonsNodeType.NORMAL;
                    break;
                case 2:
                    emoticonType = EmoticonsNodeType.VIP;
                    break;
                case 3:
                    emoticonType = EmoticonsNodeType.STAR;
                    hintString = gameString("想擁有更多表情?");
                    break;
                case 4:
                    emoticonType = EmoticonsNodeType.HEART;
                    hintString = gameString("想擁有更多愛心人表情符號?");
                    break;
                case 5:
                    emoticonType = EmoticonsNodeType.POKER;
                    hintString = gameString("想擁有更多撲克人表情符號?");
                    break;
                default:
                    break;
            }

            // 創新的
            for (var i = 0; i < 10; i++) {
                var emoticon = new EmoticonsNode(emoticonType, i, decreaseTime, this._emoticonClicked, this);
                emoticon.setPosition(this._getPosition(i, hintString));
                emoticon.setScale(0.5);
                page.addChild(emoticon);
            }

            // 判斷是否要加商店的按鈕
            if (hintString) {
                var moreLabel = new cc.LabelTTF(hintString, JSFontBoldName, 7);
                moreLabel.setAnchorPoint(0, 0.5);
                moreLabel.setFontFillColor(JSColor.WHITE);
                moreLabel.setPosition(this._shopPos);
                page.addChild(moreLabel);

                var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", cc.size(35, 17), gameString("前往商城"), 7, JSColor.WHITE);
                itemNodes.forEach(cur => cur.label.enableStroke(cc.color(153, 71, 30), 1));
                var button = new cc.ControlButton(itemNodes[0]);
                button.setBackgroundSpriteForState(itemNodes[1], cc.CONTROL_STATE_HIGHLIGHTED);
                button.addTargetWithActionForControlEvents(this, this._goShopClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
                button.setAdjustBackgroundImage(false);
                button.setZoomOnTouchDown(false);
                button.setSwallowTouches(false);
                button.setTouchDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
                button.setPosition(moreLabel.getPosition().x + moreLabel.getContentSize().width + 20, moreLabel.getPosition().y);
                page.addChild(button);
            }
        }
    },

    // 出現提示文字
    _showHintString: function (hintString, pageIndex) {
        var hintTag = 15384;

        // 先砍掉舊的
        var page = this._pageArray[pageIndex];
        page.removeChildByTag(hintTag);

        // 創新的
        var hintLabel = new cc.LabelTTF(hintString, JSFontBoldName, 10);
        hintLabel.setPosition(this._isGameGaple ? 82 : 102, 90);
        page.addChild(hintLabel, 1, hintTag);

        var action1 = cc.delayTime(2);
        var action2 = cc.fadeOut(0.5);
        var action3 = cc.removeSelf();
        hintLabel.runAction(cc.sequence(action1, action2, action3));
    },

    /**
     * 按鈕
     */
    // 按到表情
    _emoticonClicked: function (senderObj) {
        /*
         {
         page:          //哪一頁
         index:         //第幾個
         emoticonObj:   //表情的物件 有可能是null
         canUse:        //是否能使用
         }
         */
        var sendString;
        switch (senderObj.type) {
            case EmoticonsNodeType.NORMAL:
                // 普通表情
                sendString = "mood mood" + senderObj.index;
                break;
            case EmoticonsNodeType.VIP:
                // VIP表情
                if (senderObj.canUse)
                    sendString = "vmood mood" + senderObj.index;
                else {
                    //出現說明
                    this._showHintString(LocalizedString.Game("限定VIP表情，儲值後馬上使用!"), 2);
                }
                break;
            case EmoticonsNodeType.STAR:
                // 特殊表情
                if (senderObj.canUse)
                    sendString = "use_item_socket " + senderObj.emoticonObj.wid;
                else {
                    //開商城
                    this._goShopClicked();
                }
                break;
            case EmoticonsNodeType.HEART:
            case EmoticonsNodeType.POKER:
                // 商城表情
                if (senderObj.canUse)
                    sendString = "store_mood mood" + senderObj.emoticonObj.serial;
                else {
                    //開商城
                    this._goShopClicked();
                }
                break;
            default:
                break;
        }

        if (sendString) {
            // 送出
            DataProcess.sendString(sendString);

            // 把常用項目記下來 先找出原本常用裡面有沒有他
            var lastEmoticonJson = JSON.parse(GS.localStorage.getItem("LastUsedEmoticon2", "[]"));
            for (var i = 0, len = lastEmoticonJson.length; i < len; i++) {
                var thisObj = lastEmoticonJson[i];
                if (thisObj.type === senderObj.type && thisObj.index === senderObj.index) {
                    // 有找到 要砍掉
                    lastEmoticonJson.splice(i, 1);
                    break;
                }
            }

            // 加入到第0個
            lastEmoticonJson.splice(0, 0, {
                type: senderObj.type,
                index: senderObj.index
            });

            // 超過10個的話砍掉最後一個
            if (lastEmoticonJson.length > 10)
                lastEmoticonJson.pop();

            // 存下來
            GS.localStorage.setItem("LastUsedEmoticon2", JSON.stringify(lastEmoticonJson));

            // 把選單關掉
            GS.dispatchCustomEvent("NotifyCloseEmoticons");
        }

        // AppsFlyer 互動道具、表情、對話功能 (累加)
        GameAppsFlyerTracker.trackByGameName("interacttool");
    },

    // 按到前往商城
    _goShopClicked: function () {
        if (PushScene.isGame) {
            // 因為遊戲內可能會關掉Dialog 透過代參數讓Manager管理
            DialogManager.addDialog(new ChipShopDialog(ChipShopDialog.Type.GAME_SELF, DataModal.profileData.account, ShopProductType.GIFT), true, true);
        } else {
            // 此Dialog不要給Manager控管
            DialogManager.addDialog(new ChipShopDialog(ChipShopDialog.Type.GAME_SELF, DataModal.profileData.account, ShopProductType.GIFT), false);
        }

        // 關掉Dialog
        GS.dispatchCustomEvent("NotifyCloseEmoticons");
    },

    /**
     * 通知
     */
    // 特殊表情更新
    notifyGetCampMoodList: function () {
        // 特殊表情 星星
        this._createPage(2);

        // 最後還是要更新一下表情 會需要server噴回來的序號
        this._createPage(0);
    },

    // 商店賣的表情更新
    notifyGetStoreMoodList: function () {
        // 心表情
        this._createPage(3);
        // 撲克表情
        this._createPage(4);

        // 最後還是要更新一下表情 會需要server噴回來的序號
        this._createPage(0);
    },
});