/**
 * 氣泡框參數
 obj = {
        mainNode: null,                 // 主要內文的Node (必填)
        style: 0,                       // 氣泡框底框類型 (必填)
        direct: 0,                      // 氣泡框尖端的轉角  (必填)
        arrowType: 1,                   // 尖角是直還是斜 1:直 2:斜
        isFlip: false,                  // 尖角是否反轉
        arrowPadding: 0,                // 尖角跟氣泡框中心的偏移量（指向上下就是X軸正負，指向左右就是Y軸正負）
        opacity: 255,                   // 透明度
        arrowScale: 1,                  // 尖角的大小倍率，預設是1，目前不提供(scaleX, scaleY)的客製
        arrowZOrder: 1,                 // 尖角的z-order，要壓在背景上面還是下面
        closeCallback,                  // 關閉時的callback 同下
        autoFixed: true,                // 自動修正位置

        // 以下特定數值設定需要(style === BaseMessageNode.STYLE.CUSTOM)，才有作用
        bgName: "",                     // 背景的檔名 (必填)
        bgBonusSize: cc.size(xx, xx),   // 額外背景大小 (必填)
        arrowName: "",                  // 尖角的檔名 (必填)
        arrowToBgPadding: 0,            // 尖角到背景的額外位移 (CUSTOM預設0，其他style會有各自的設定值，這裡無法調整)
    }
 *
 */

var BaseMessageNode = cc.Node.extend({
    ctor: function (obj) {
        this._super();
        this.setCascadeOpacityEnabled(true);
        this.setCascadeColorEnabled(true);

        // 給一些預設值
        if (obj.arrowType === undefined)
            obj.arrowType = 1;
        if (obj.opacity === undefined)
            obj.opacity = 255;
        if (obj.showArrow === undefined)
            obj.showArrow = true;
        if (obj.arrowPadding === undefined)
            obj.arrowPadding = 0;
        if (obj.arrowToBgPadding === undefined)
            obj.arrowToBgPadding = 0;
        if (obj.arrowScale === undefined)
            obj.arrowScale = 1;
        if (obj.arrowZOrder === undefined)
            obj.arrowZOrder = 1;

        // 整理資料
        this._autoFixed = obj.autoFixed;                // 是否要自動修正
        var direct = this._direct = obj.direct;
        var mainNode = this._mainNode = obj.mainNode;

        // 對話框款式
        var style = ["white", "whiteShadow", "gold", "goldFrame", "yellow", "blue", "black", "goldAndPurple", "red", "yellowShadow"];
        var anchor = [cc.p(0.5, 0), cc.p(0, 0.5), cc.p(0.5, 1), cc.p(1, 0.5), cc.p(1, 0), null, cc.p(1, 1), null, cc.p(0, 0), null, cc.p(0, 1)];
        // 對話框圖框厚度誤差偏移
        var padding = [5, 14, 18, 9, 14, 4, 18, 9, 3.3, 15];

        // 跳出的視窗
        var aniNode = this._animationNode = new cc.Node();
        aniNode.setCascadeColorEnabled(true);
        aniNode.setCascadeOpacityEnabled(true);
        aniNode.setAnchorPoint(anchor[direct]);
        aniNode.setOpacity(obj.opacity);
        aniNode.setScale(0);
        this.addChild(aniNode);

        // 黃色只有斜角，除了白底&白底陰影外都只有直尖角
        if (obj.style == 2)
            obj.arrowType = 2;
        else if (obj.style > 2)
            obj.arrowType = 1;

        // 尖角
        var arrowSprite;
        if (obj.style === BaseMessageNode.Style.CUSTOM)
            arrowSprite = new cc.Sprite("#" + obj.arrowName);
        else
            arrowSprite = new cc.Sprite(JSStringUtility.format("#information_%s_arrow_%d.png", style[obj.style], obj.arrowType));
        arrowSprite.setFlippedX(obj.isFlip);
        arrowSprite.setRotation(direct * 90);
        arrowSprite.setScale(obj.arrowScale);
        arrowSprite.setVisible(obj.showArrow);
        arrowSprite.setAnchorPoint(0.5, 0);
        arrowSprite.setPosition(0, 0);
        aniNode.addChild(arrowSprite, obj.arrowZOrder);

        // 底框
        var arrowToBgPadding = (obj.style === BaseMessageNode.Style.CUSTOM ? obj.arrowToBgPadding : padding[obj.style] / 4);
        var bgSize = mainNode.getContentSize();
        var height = arrowSprite.getContentSize().height;
        var posX, posY;
        switch (direct) {
            // 下靠右
            case BaseMessageNode.Direct.DOWN_RIGHT:
                posX = (-bgSize.width / 2) + (arrowToBgPadding * 2) + obj.arrowPadding;
                posY = (height + bgSize.height / 2 + arrowToBgPadding);
                break;

            // 上靠右
            case BaseMessageNode.Direct.UP_RIGHT:
                posX = (-bgSize.width / 2) + (arrowToBgPadding * 2) + obj.arrowPadding;
                posY = -(height + bgSize.height / 2 + arrowToBgPadding);
                break;

            // 上靠左
            case BaseMessageNode.Direct.UP_LEFT:
                posX = (bgSize.width / 2) - (arrowToBgPadding * 2) - obj.arrowPadding;
                posY = -(height + bgSize.height / 2 + arrowToBgPadding);
                break;

            // 下靠左
            case BaseMessageNode.Direct.DOWN_LEFT:
                posX = (bgSize.width / 2) - (arrowToBgPadding * 2) - obj.arrowPadding;
                posY = (height + bgSize.height / 2 + arrowToBgPadding);
                break;

            default:
                posX = (direct % 2) ? (2 - direct) * (height + bgSize.width / 2 + arrowToBgPadding) : obj.arrowPadding;
                posY = (direct % 2) ? obj.arrowPadding : (1 - direct) * (height + bgSize.height / 2 + arrowToBgPadding);
                break;
        }

        var bgSprite;
        if (obj.style === BaseMessageNode.Style.CUSTOM) {
            bgSprite = new ccui.Scale9Sprite(obj.bgName);
            bgSprite.setPreferredSize(cc.size(bgSize.width + obj.bgBonusSize.width, bgSize.height + obj.bgBonusSize.height));
            obj.bgFlipY && bgSprite.setScaleY(-1);
        } else {
            var padding = padding[obj.style];
            bgSprite = new ccui.Scale9Sprite(JSStringUtility.format("information_%s_bg.png", style[obj.style]));
            bgSprite.setPreferredSize(cc.size(bgSize.width + padding, bgSize.height + padding));
        }
        bgSprite.setPosition(posX, posY);
        aniNode.addChild(bgSprite);

        // 為了加上裝飾品
        this._bgSprite = bgSprite;

        // 內容
        mainNode.setPosition(posX, posY);
        aniNode.addChild(mainNode, 0);

        // 關閉時的callback
        if (obj.closeCallback)
            this._closeCallback = obj.closeCallback;
    },

    /**
     * 修正超出畫面的位置，只檢查上下左右
     * 注意：如果在 PushLayer 前就呼叫，世界位置有可能會算錯，需在 viewDidAppear 之後才做事
     */
    _fixOverVisibleScreen: function () {
        // 例外跳出
        if (!this._autoFixed || this.__isDestroyed || !this.getParent())
            return;

        // 判斷要檢查哪些邊界，只檢查上下左右，根據訊息箭頭位置減少檢查範圍
        var needCheck = true, checkUp = false, checkDown = false, checkLeft = false, checkRight = false;
        switch (this._direct) {
            case BaseMessageNode.Direct.DOWN:           // 下
            case BaseMessageNode.Direct.UP:             // 上
                checkLeft = true;
                checkRight = true;
                break;
            case BaseMessageNode.Direct.LEFT:           // 左
            case BaseMessageNode.Direct.RIGHT:          // 右
                checkUp = true;
                checkDown = true;
                break;
            case BaseMessageNode.Direct.DOWN_RIGHT:     // 下靠右
            case BaseMessageNode.Direct.UP_RIGHT:       // 上靠右
            case BaseMessageNode.Direct.UP_LEFT:        // 上靠左
            case BaseMessageNode.Direct.DOWN_LEFT:      // 下靠左
                needCheck = false;
                break;
        }

        // 判斷是否要檢查
        if (needCheck) {
            // 整理資料
            var fixNumber = 6;                                                                  // 至少要距離邊界多少
            var bgSprite = this._bgSprite;                                                      // 背景
            var mainNode = this._mainNode;                                                      // 文字
            var bgSpriteBox = bgSprite.getBoundingBox();                                        // 抓文字rect，會先updateTTF
            var bgSpriteHalfWidth = bgSpriteBox.width / 2;                                      // 文字一半寬度
            var bgSpriteHalfHeight = bgSpriteBox.height / 2;                                    // 文字一半長度
            var paddingPosX = 0, paddingPosY = 0;                                               // 欲修正偏移值
            var originPosX = JSOriginPoint.x, originPosY = JSOriginPoint.y;
            var JSVisibleWidth = JSVisibleSize.width, JSVisibleHeight = JSVisibleSize.height;   // 螢幕長寬
            var worldPos = this._animationNode.convertToWorldSpace(mainNode.getPosition());     // 文字位置

            // 檢查右邊
            var rightmostPosX = worldPos.x + bgSpriteHalfWidth;
            if (checkRight && rightmostPosX > JSVisibleWidth + originPosX - fixNumber - JSScreenSafeWidth)
                paddingPosX = JSVisibleWidth + originPosX - rightmostPosX - fixNumber - JSScreenSafeWidth;

            // 檢查左邊
            var leftmostPosX = worldPos.x - bgSpriteHalfWidth;
            if (checkLeft && leftmostPosX < originPosX + fixNumber + JSScreenSafeWidth)
                paddingPosX = originPosX + fixNumber - leftmostPosX + JSScreenSafeWidth;

            // 檢查上面
            var topmostPosY = worldPos.y + bgSpriteHalfHeight;
            if (checkUp && topmostPosY > JSVisibleHeight + originPosY - fixNumber - JSScreenSafeHeight)
                paddingPosY = JSVisibleHeight + originPosY - topmostPosY - fixNumber - JSScreenSafeHeight;

            // 檢查下面
            var bottommostPosY = worldPos.y - bgSpriteHalfHeight;
            if (checkDown && bottommostPosY < originPosY + fixNumber + JSScreenSafeHeight)
                paddingPosY = originPosY + fixNumber - bottommostPosY + JSScreenSafeHeight;

            // 文字跟背景都修正
            bgSprite.setPosition(cc.pAdd(bgSprite.getPosition(), cc.p(paddingPosX, paddingPosY)));
            mainNode.setPosition(cc.pAdd(mainNode.getPosition(), cc.p(paddingPosX, paddingPosY)));
        }
    },


    /**
     * 出現Msg
     */
    show: function (time, removeWhenClose = true, closeCallback = undefined) {
        var aniNode = this._animationNode;
        aniNode.setVisible(true);
        aniNode.setScale(0);
        aniNode.stopAllActions();

        // 修正超出畫面的位置，晚一個frame等待被addChild
        this._autoFixed && aniNode.runAction(cc.callFunc(this._fixOverVisibleScreen, this));

        // 有callback
        closeCallback && (this._closeCallback = closeCallback);

        var action1 = cc.scaleTo(DIALOG_ANIMATION_TIME, 1).easing(cc.easeBackOut());
        if (time) {
            // 有時間代表要關掉
            aniNode.runAction(cc.sequence(
                action1,
                cc.delayTime(time),
                cc.scaleTo(DIALOG_ANIMATION_TIME, 0).easing(cc.easeBackIn()),
                cc.callFunc(function () {
                    this._closeCallback && this._closeCallback();
                }, this),
                cc.delayTime(0.01),
                cc.callFunc(() => {
                    if (this.__isDestroyed)
                        return;

                    // 晚一個frame 砍掉自己, 因為怕有人callback那邊拿掉自己了
                    removeWhenClose && this.removeFromParent();
                })
            ));
        } else {
            // 直接跑出來就好
            aniNode.runAction(action1);
        }
    },

    // 隱藏顯示
    hide: function () {
        if (this.__isDestroyed)
            return;

        this._animationNode.stopAllActions();
        this._animationNode.runAction(cc.sequence(
            cc.scaleTo(DIALOG_ANIMATION_TIME, 0).easing(cc.easeBackIn()),
            cc.hide()
        ));
    },

    // 關閉
    close: function () {
        if (this.__isDestroyed)
            return;

        this._animationNode.stopAllActions();
        this._animationNode.runAction(cc.scaleTo(DIALOG_ANIMATION_TIME, 0).easing(cc.easeBackIn()));
        this.runAction(cc.sequence(
            cc.delayTime(DIALOG_ANIMATION_TIME),
            cc.callFunc(() => {
                this._closeCallback && this._closeCallback();
            }),
            cc.delayTime(0.01),
            cc.removeSelf()
        ));
    },

    // 取得_animationNode
    getAnimationNode: function () {
        return this._animationNode;
    },

    // 取得背景的範圍
    getBoundingBox: function () {
        var rect = this._bgSprite.getBoundingBox();
        return cc._rectApplyAffineTransformIn(rect, this.getNodeToParentAffineTransform());
    },

    // 設定關閉的callback
    setCloseCallback: function (closeCallback) {
        this._closeCallback = closeCallback;
    },

    /**
     * 加node在泡泡框的背景圖
     * @param node          外面創好的node
     * @param anchor        自己的anchor
     * @param bgPosAnchor   相對MsgBg的位置以比例計算長寬
     */
    addAdditionalNodeOnMsgBg: function (node, anchor = cc.p(0, 0), bgPosAnchor = cc.p(0, 0)) {
        if (node) {
            var contentSize = this._bgSprite.getContentSize();
            var posX = contentSize.width * bgPosAnchor.x;
            var posY = contentSize.height * bgPosAnchor.y;
            node.setAnchorPoint(anchor);
            node.setPosition(posX, posY);
            this._bgSprite.addChild(node);
        }
    },

    /**
     * 加node在泡泡框
     * @param node          外面創好的node
     * @param anchor        自己的anchor
     * @param bgPosAnchor   相對MsgBg的位置以比例計算長寬
     */
    addAdditionalNode: function (node, anchor = cc.p(0, 0), bgPosAnchor = cc.p(0, 0)) {
        if (node) {
            var bgSprite = this._bgSprite;
            var contentSize = bgSprite.getContentSize();
            var posX = bgSprite.getPositionX();
            var posY = bgSprite.getPositionY() + contentSize.height / 2 * bgPosAnchor.y;
            node.setAnchorPoint(anchor);
            node.setPosition(posX, posY);
            this._animationNode.addChild(node, 2);
        }
    }
});

// 訊息的邊框樣式
BaseMessageNode.Style = {
    CUSTOM: -1,             // 有要自訂義的話 可以傳這個
    WHITE: 0,               // 白底
    WHITE_SHADOW: 1,        // 白底帶陰影
    GOLD: 2,                // 金變 + 由上至下漸層金底
    GOLD_FRAME: 3,          // 白底 + 金邊
    YELLOW: 4,              // 黃底
    BLUE: 5,                // 藍底
    BLACK: 6,               // 黑底
    GOLD_PURPLE: 7,         // 金邊 + 紫底
    RED: 8,                 // 紅底
    YELLOW_SHADOW: 9,       // 黃漸層底帶陰影
};

// 訊息角角在哪
BaseMessageNode.Direct = {
    DOWN: 0,                // 下
    LEFT: 1,                // 左
    UP: 2,                  // 上
    RIGHT: 3,               // 右
    DOWN_RIGHT: 4,          // 下靠右
    UP_RIGHT: 6,            // 上靠右
    DOWN_LEFT: 8,           // 下靠左
    UP_LEFT: 10,            // 上靠左
    RIGHT_DOWN: 11,         // 右靠下
};

// 箭頭的方向
BaseMessageNode.ArrowType = {
    STRAIGHT: 1,            // 直
    SLANT: 2                // 斜
};