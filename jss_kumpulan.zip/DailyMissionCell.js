var DailyMissionCell = cc.TableViewCell.extend({
    ctor: function (whereType) {
        this._super();

        this._isInSlot = whereType === DailyMissionEnum.whereType.Slot;    // 在機台內(含大廳機台)

        var midPosY = DailyMissionCell.HEIGHT / 2;

        // 名稱
        var titleName = this._titleName = new cc.LabelTTF("", JSFontName, 10, cc.size(220, 25), cc.TEXT_ALIGNMENT_LEFT);
        titleName.setFontFillColor(cc.color(255, 236, 122));
        titleName.setAnchorPoint(0, 0.5);
        titleName.setPosition(18, 31);
        this.addChild(titleName);

        // 獎品
        var rewardNode = this._rewardNode = new cc.Node();
        rewardNode.setCascadeColorEnabled(true);
        rewardNode.setCascadeOpacityEnabled(true);
        this.addChild(rewardNode);

        // 進度文字
        var progressLabel = this._progressLabel = new cc.LabelTTF("", JSFontName, 8);
        progressLabel.setAnchorPoint(0, 0.5);
        progressLabel.setPosition(18, 13);
        this.addChild(progressLabel);

        // 進度條
        var barSize = cc.size(220, 4);
        var progressBar = this._progressBar = new GSProgressTimer("daily_mission_pic_bar_01.png", "daily_mission_pic_bar_02.png", barSize, barSize);
        progressBar.setPosition(18 + barSize.width / 2, 6);
        this.addChild(progressBar);

        // 按鈕
        var button = this._button = ButtonUtility.createSimpleButton("lobby_btn_03.png", cc.size(45, 23), "GO", JSColor.WHITE, 10);
        button.label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        button.setPosition(371, midPosY);
        button.setChangeColorWhenDisabled(false);
        button.addTouchUpInsideAction(this._buttonClicked, this);
        this.addChild(button);

        // 分隔線
        var lineSprite = new cc.Sprite("#lobby_division_line.png");
        lineSprite.setScaleX(50);
        lineSprite.setPosition(200, 0);
        this.addChild(lineSprite);
    },

    // 更新Cell
    refreshCell: function (param) {
        this._param = param;

        // 名稱
        this._titleName.setString(param.name);

        // 先清掉舊的獎圖
        var rewardNode = this._rewardNode;
        rewardNode.removeAllChildren();

        // 固定獎勵-活躍值徽章
        var medalSp = new cc.Sprite("#daily_mission_pic_activity-badge.png");
        medalSp.setScale(0.8);
        medalSp.setPosition(257, 26);
        rewardNode.addChild(medalSp);

        // 活躍值數值
        var rewardLabel = new GSAutoSizeLabel(param.activity, JSFontBoldName, 8, cc.size(DailyMissionCell.REWARD_ICON_HEIGHT, 10), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        rewardLabel.setPosition(cc.pAdd(medalSp.getPosition(), cc.p(0, -DailyMissionCell.REWARD_ICON_HEIGHT / 2 - 5)));
        rewardNode.addChild(rewardLabel);

        // 其他獎勵
        var rewardList = param.rewardList;
        rewardList.forEach((reward, idx) => {
            // 獎勵圖
            var imageName = reward.wid + ".png";
            var imageUrl = DailyMissionData.REWARD_BASE_HOST + imageName;
            var savePath = DailyMissionData.SAVE_REWARD_BASE_PATH + imageName;

            var rewardSp = new GSDownloadSprite("", imageUrl, savePath);
            rewardSp.setTargetSize(cc.size(DailyMissionCell.REWARD_ICON_HEIGHT, DailyMissionCell.REWARD_ICON_HEIGHT));
            rewardSp.setPosition(292 + (DailyMissionCell.REWARD_ICON_HEIGHT + 10) * idx, 26);
            rewardNode.addChild(rewardSp);

            // 獎勵文案
            var rewardLabel = new GSAutoSizeLabel(reward.rewardTxt, JSFontBoldName, 8, cc.size(DailyMissionCell.REWARD_ICON_HEIGHT, 10), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
            rewardLabel.setPosition(cc.pAdd(rewardSp.getPosition(), cc.p(0, -DailyMissionCell.REWARD_ICON_HEIGHT / 2 - 5)));
            rewardNode.addChild(rewardLabel);
        });

        // 刷新進度條文字
        this._progressLabel.setString(TexasUtility.getSimpleMoneyString(param.progressList[0]) + "/" + TexasUtility.getSimpleMoneyString(param.progressList[1]));

        // 刷新進度條
        this._progressBar.setPercentage(param.progressList[0] / param.progressList[1] * 100, false);

        // 刷新按鈕
        var btnImg, btnSize, btnString, btnFontColor, btnEnabled;
        switch (param.status) {
            case 0:     // 不可領獎
                // 在lobby & 不在機台中 & server有傳導向過來
                btnEnabled = PushScene.isLobby && !this._isInSlot && param.bannerType !== LobbyBannerMode.None;
                btnSize = cc.size(45, btnEnabled ? 23 : 32);
                btnImg = btnEnabled ? "lobby_btn_03.png" : "lobby_btn_06.png";
                btnString = btnEnabled ? "前往" : "尚未完成";
                btnFontColor = btnEnabled ? JSColor.WHITE : JSColor.BLACK;
                break;
            case 1:     // 可領獎
                btnEnabled = true;
                btnSize = cc.size(45, 23);
                btnImg = "lobby_btn_01.png";
                btnString = "領取";
                btnFontColor = JSColor.BLACK;
                break;
            case 2:     // 已完成
                btnEnabled = false;
                btnSize = cc.size(45, 23);
                btnImg = "lobby_btn_06.png";
                btnString = "已\n領獎";
                btnFontColor = JSColor.BLACK;
                break;
        }
        var btn = this._button;
        btn.bg.setSpriteFrame(btnImg);
        btn.bg.setPreferredSize(btnSize);
        btn.label.setString(LocalizedString.FreeChip(btnString));
        btn.label.setFontFillColor(btnFontColor);
        btn.setEnabled(btnEnabled);
    },

    /**
     * 按鈕
     */
    // 領獎按鈕
    _buttonClicked: function (sender) {
        // 鎖住按鈕等cmd回來
        sender.setEnabled(false);

        var param = this._param;

        // 可領獎
        if (param.status === 1) {
            // 通知領獎
            GS.dispatchCustomEvent("NotifyDailyMissionRewardClicked", param);
        }
        // 不可領獎
        else {
            if (PushScene.isLobby) {
                if (param.bannerType !== LobbyBannerMode.None) {
                    // 進引導流程

                    // 關掉主dialog
                    GS.dispatchCustomEvent("NotifyCloseActionListDialog");

                    var bannerType = param.bannerType;
                    var bannerUrl = param.bannerUrl;
                    if (bannerType === LobbyBannerMode.Play) {
                        // 馬上玩，直接導指定底台

                        var gameType = getGSEumGameType(bannerUrl);
                        // Gaple好友桌沒有馬上玩 pm說Gaple好友桌馬上玩都轉導Gaple桌
                        if (gameType === GSEnum.Game.GapleFriend || GS.nowGame === GSEnum.Game.GapleFriend) {
                            gameType = GSEnum.Game.Gaple;
                            GS.nowGame = GSEnum.Game.Gaple;
                        }

                        // 送入桌cmd
                        var json = {
                            game: gameType,
                            limitFee: param.limitFee
                        };
                        DataProcess.sendString("mix_quickJoin " + JSON.stringify(json));

                        // 卡Loading
                        GSLoading.addLoadingView();
                    } else {
                        // 正常導頁
                        PushLayerHelper.pushLayer(bannerUrl, bannerType);
                    }


                    // 告訴server我們前往某任務了 傳bannerType 後面加0(server固定值)
                    DataProcess.sendString(JSStringUtility.format("dailyMission_update %s 0", param.bannerType));
                }
            }
        }
    }
});

DailyMissionCell.HEIGHT = 47;                   // cell高度
DailyMissionCell.LABEL_ONE_LINE_HEIGHT = 0;     // 獎品一行的高度
DailyMissionCell.MAX_REWARD_LABEL_WIDTH = 140;  // 獎品最大寬度
DailyMissionCell.REWARD_LABEL_FONT_SIZE = 10;   // 獎品的字體大小
DailyMissionCell.ICON_HEIGHT = 40;              // ICON的高
DailyMissionCell.REWARD_ICON_HEIGHT = 25;       // 獎勵ICON的高