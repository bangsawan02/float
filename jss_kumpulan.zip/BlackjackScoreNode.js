/**
 * 21點的牌的分數
 */

var BlackjackScoreNode = cc.Node.extend({
    ctor: function () {
        this._super();

        // 背景
        var bgSprite = this._bgSprite = new ccui.Scale9Sprite("bj_bg_scores.png");
        this.addChild(bgSprite);

        // 分數
        var scoreLabel = this._scoreLabel = new cc.LabelTTF("0", JSFontBoldName, 16);
        this.addChild(scoreLabel);

        // 贏牌 輸牌 爆牌的文字
        var hintBgSprite = this._hintBgSprite = new ccui.Scale9Sprite("bj_bg_blue.png");
        hintBgSprite.setPosition(0, -20);
        hintBgSprite.setVisible(false);
        this.addChild(hintBgSprite, 1);

        var hintLabel = this._hintLabel = new cc.LabelTTF("", JSFontBoldName, 12);
        hintLabel.setPosition(0, -20);
        hintLabel.setVisible(false);
        this.addChild(hintLabel, 1);
    },

    /**
     * 設定分數
     */
    setScore: function (scoreString) {
        scoreString = scoreString || "";

        // 背景要調
        this._bgSprite.setPreferredSize(scoreString.length > 2 ? cc.size(90, 26) : cc.size(40, 26));

        this._scoreLabel.setString(scoreString);
    },

    /**
     * 顯示提示文字
     */
    setHintType: function (type) {
        this.hintType = type;

        // 是否需要顯示
        var needShow = type !== BlackjackScoreType.NONE;

        this._hintBgSprite.setVisible(needShow);
        this._hintLabel.setVisible(needShow);

        if (needShow) {
            var bgSpriteName, bgSize, labelText;
            var bjString = LocalizedString.Blackjack;
            switch (type) {
                case BlackjackScoreType.LOSE:
                    bgSpriteName = "bj_bg_blue.png";
                    bgSize = cc.size(76, 34);
                    labelText = bjString("輸牌");
                    break;
                case BlackjackScoreType.BUST:
                    bgSpriteName = "bj_bg_red.png";
                    bgSize = cc.size(76, 34);
                    labelText = bjString("爆牌");
                    break;
                case BlackjackScoreType.BLACKJACK:
                    bgSpriteName = "bj_bg_yellow.png";
                    bgSize = cc.size(90, 34);
                    labelText = bjString("BLACKJACK");
                    break;
                default:
                    break;
            }

            this._hintBgSprite.setSpriteFrame(bgSpriteName);
            this._hintBgSprite.setPreferredSize(bgSize);
            this._hintLabel.setString(labelText);
        }
    },
});

// 分數的提示文字
var BlackjackScoreType = {
    NONE: 0,        // 不顯示
    LOSE: 1,        // 輸牌
    BUST: 2,        // 爆牌
    BLACKJACK: 3,   // Blackjack
};