/**
 * CapsaSusun 出牌牌墩 + 出牌提示畫面
 */

var CapsaSusun_HintCardMenuLayer = cc.Layer.extend({
    ctor: function (handCardLayer) {
        this._super();

        this._stackObj = [];                    // 墩上面的物件
        this._cardBackArray = [];               // 墩的底圖
        this._algorithmBtnArray = [];           // 快速選牌的按鈕

        this._handCardLayer = handCardLayer;

        // 加黑底
        var bgColorLayer = new cc.LayerColor(cc.color(0, 0, 0, 204), JSVisibleSize.width, JSVisibleSize.height);
        this.addChild(bgColorLayer);

        // 背景
        for (var i = 0; i < 2; i++) {
            var bgSprite = new ccui.Scale9Sprite("capsaSusun_pic_table.png");
            bgSprite.setPreferredSize(cc.size(JSScreenMidPos.x, 201));
            bgSprite.setAnchorPoint(1, 1);
            bgSprite.setScale(-2 * i + 1, 1);
            bgSprite.setPosition(JSScreenMidPos.x, JSVisibleSize.height);
            this.addChild(bgSprite);
        }

        // Menu
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        this.addChild(menu, 2);

        this._stackGafArray = [];
        var stackGafIndex = 0;

        var itemNodes, btn, choseBgSprite;
        var leftPos = cc.p(137 + JSScreenBonusHalfWidth, 250 + JSScreenBonusHeight);
        var btnImages = ["lobby_btn_01.png", "lobby_btn_01.png", "lobby_btn_04.png"];
        // 墩(左) -------------------------------------------
        for (var i = 0; i < CapsaSusun_StackCount; i++) {

            var stackObj = this._stackObj[i] = {};

            var posY = leftPos.y - 61 * i;

            // 背景
            choseBgSprite = new ccui.Scale9Sprite("capsaSusun_pic_black.png");
            choseBgSprite.setPreferredSize(cc.size(i ? 214 : 132, 58));
            choseBgSprite.setPosition(leftPos.x, posY);
            this.addChild(choseBgSprite);

            this._cardBackArray[i] = choseBgSprite.getBoundingBox();
            this._cardBackArray[i].basePos = cc.p(i ? 54 + JSScreenBonusHalfWidth : 95 + JSScreenBonusHalfWidth, posY - 1);

            // 第幾墩的按鈕
            itemNodes = ButtonUtility.createSingleScale9SpriteNodes(btnImages, cc.size(64, 26), "#capsaSusun_word_sort_0" + (i + 1) + ".png");
            itemNodes[2].setOpacity(255);
            btn = stackObj.stackBtn = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._stackBtnClicked, this);
            btn.stackNum = i;
            btn.setPosition(leftPos.x, posY);
            menu.addChild(btn);

            // X按鈕
            itemNodes = ButtonUtility.createSingleScale9SpriteNodes("capsaSusun_pic_btn.png", cc.size(15, 15), "#capsaSusun_icon_X.png");
            itemNodes.forEach(cur => cur.word.setScale(0.45));
            btn = stackObj.cancelBtn = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._cancelBtnClicked, this);
            btn.setPosition(20 + JSScreenBonusHalfWidth, 249 - 60 * i + JSScreenBonusHeight);
            btn.stackNum = i;
            btn.setVisible(false);
            menu.addChild(btn);

            // 打勾 or 叉叉
            var checkSprite = stackObj.rightSptrite = new cc.Sprite("#capsaSusun_pic_ok.png");
            checkSprite.setPosition((i ? 256 : 215) + JSScreenBonusHalfWidth, 250 - 62 * i + JSScreenBonusHeight);
            this.addChild(checkSprite);

            checkSprite = stackObj.errorSptrite = new cc.Sprite("#capsaSusun_pic_no.png");
            checkSprite.setPosition((i ? 256 : 215) + JSScreenBonusHalfWidth, 250 - 62 * i + JSScreenBonusHeight);
            this.addChild(checkSprite);

            gaf.create("gaf/game/capsaSusun_stack.gaf", this, true, (gafAsset) => {
                gafAsset.setRootTimelineWithName(stackGafIndex ? "act2" : "act1");
                var stackGaf = gafAsset.createObject();
                stackGaf.setPosition(leftPos.x, leftPos.y - 61 * stackGafIndex);
                this.addChild(stackGaf);
                stackGafIndex++;

                this._stackGafArray.push(stackGaf);
                stackGaf.setVisible(false);
            });

            this.updateStatus(i, CapsaSusun_HintCardMenuLayer.STATUS.NONE_CARD);
        }

        itemNodes = ButtonUtility.createSingleScale9SpriteNodes("capsaSusun_pic_btn.png", cc.size(20, 20), "#capsaSusun_icon_random.png");
        itemNodes.forEach(cur => cur.word.setScale(0.75));
        btn = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._changeBtnClicked, this);
        btn.setPosition(250 + JSScreenBonusHalfWidth, 158 + JSScreenBonusHeight);
        menu.addChild(btn);

        // 墩(右) -------------------------------------------
        // 背景
        var choseRightBgSprite = new ccui.Scale9Sprite("capsaSusun_pic_black.png");
        choseRightBgSprite.setPreferredSize(cc.size(216, 180));
        choseRightBgSprite.setPosition(389 + JSScreenBonusHalfWidth, 190 + JSScreenBonusHeight);
        this.addChild(choseRightBgSprite);

        // 標題
        var choseTitleSprite = new cc.Sprite("#capsaSusun_word_select.png");
        choseTitleSprite.setPosition(388 + JSScreenBonusHalfWidth, 262 + JSScreenBonusHeight);
        this.addChild(choseTitleSprite);

        // 快速選擇的四個按鈕
        btnImages = ["capsaSusun_pic_btn.png", "capsaSusun_pic_btn.png", "lobby_btn_01.png"];
        for (var i = 0; i < 4; i++) {
            var algorithmObj = {};
            var wordArray = algorithmObj.word = [];

            // 第幾墩的按鈕
            itemNodes = ButtonUtility.createSingleScale9SpriteNodes(btnImages, cc.size(98, 66));
            for (var j = 0; j < CapsaSusun_StackCount; j++) {
                var wordObj = {};

                // 牌型名稱
                var kindSprite = wordObj.normalWorldSprite = new cc.Sprite();
                kindSprite.setPosition(49, 49 - j * 16);
                itemNodes[0].addChild(kindSprite);

                var kindSprite2 = wordObj.selectedWorldSprite = new cc.Sprite();
                kindSprite2.setPosition(49, 49 - j * 16);
                itemNodes[1].addChild(kindSprite2);

                var kindSprite3 = wordObj.disabledWorldSprite = new cc.Sprite();
                kindSprite3.setPosition(49, 49 - j * 16);
                itemNodes[2].addChild(kindSprite3);
                itemNodes[2].setOpacity(255);

                wordArray.push(wordObj);
            }

            // 快速選牌的按鈕
            btn = algorithmObj.btn = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._algorithmBtnClicked, this);
            btn.index = i;
            btn.setPosition(337 + (i % 2) * 102 + JSScreenBonusHalfWidth, 213 - Math.floor(i / 2) * 71 + JSScreenBonusHeight);
            menu.addChild(btn);

            this._algorithmBtnArray.push(algorithmObj);
        }
    },

    clean: function () {
        // 左側三層牌墩
        for (var i = 0; i < CapsaSusun_StackCount; i++) {
            this.updateStatus(i, CapsaSusun_HintCardMenuLayer.STATUS.NONE_CARD);
        }

        // 右側快速選牌
        this.updateAlgorithmBtnEnabled();
    },

    /**
     * 更新墩上的按鈕狀態
     * @param stackNum  : 哪一墩
     * @param status    : 狀態
     */
    updateStatus: function (stackNum, status) {
        var stackObj = this._stackObj[stackNum];

        var isVisible = status === CapsaSusun_HintCardMenuLayer.STATUS.RIGHT_CARD;
        stackObj.rightSptrite.setVisible(isVisible);
        stackObj.errorSptrite.setVisible(!isVisible);

        switch (status) {
            default:
            case CapsaSusun_HintCardMenuLayer.STATUS.TOUCH_OFF:
            case CapsaSusun_HintCardMenuLayer.STATUS.TOUCH_ON:
            case CapsaSusun_HintCardMenuLayer.STATUS.NONE_CARD:
            case CapsaSusun_HintCardMenuLayer.STATUS.HAVE_CARD:
                if (status === CapsaSusun_HintCardMenuLayer.STATUS.TOUCH_ON)
                    stackObj.stackBtn.setEnabled(true);
                else
                    stackObj.stackBtn.setEnabled(false);
                stackObj.stackBtn.setVisible(status !== CapsaSusun_HintCardMenuLayer.STATUS.HAVE_CARD);
                stackObj.cancelBtn.setVisible(false);
                break;
            case CapsaSusun_HintCardMenuLayer.STATUS.RIGHT_CARD:
            case CapsaSusun_HintCardMenuLayer.STATUS.ERROR_CARD:
                stackObj.stackBtn.setVisible(false);
                stackObj.cancelBtn.setVisible(true);
                break;
        }
    },

    /**
     * 更新快速選牌的按鈕可點選
     */
    updateAlgorithmBtnEnabled: function () {
        this._algorithmBtnArray.forEach(cur => {
            cur.btn.setEnabled(true);
        })
    },

    /**
     * 更新推薦牌組按鈕文字
     * @param algorithmObjArray     所有推薦牌組資料
     */
    updateAlgorithmBtn: function (algorithmObjArray) {
        for (var i = 0; i < CapsaSusun_AlgorithmCount; i++) {
            var btnArray = this._algorithmBtnArray[i];
            var btn = btnArray.btn;
            var param = algorithmObjArray[i];  // 要顯示的推薦牌組資訊

            if (param) {
                // 有資料 更新按鈕上牌型文字
                var typeArray = param.cardTypeArray;
                for (var j = 0; j < 3; j++) {
                    var res = this._getCardTypeString(typeArray[j]);
                    var wordSprite = btnArray.word[j];

                    if (!res)
                        continue;

                    wordSprite.normalWorldSprite.setSpriteFrame(res);
                    wordSprite.selectedWorldSprite.setSpriteFrame(res);
                    wordSprite.disabledWorldSprite.setSpriteFrame(res);
                }
                btn.setVisible(true);
            } else {
                // 沒資料 隱藏按鈕
                btn.setVisible(false);
            }
        }
    },

    /**
     * 取牌型文字
     * @param cardType      牌型
     * @returns {string}    牌型文字
     */
    _getCardTypeString: function (cardType) {
        switch (cardType) {
            case  CapsaSusun_CardKindType.None:
                // 高牌
                return "capsaSusun_word_card_type_09.png";

            case  CapsaSusun_CardKindType.OnePair:
                // 一對
                return "capsaSusun_word_card_type_07.png";

            case  CapsaSusun_CardKindType.TwoPair:
                // 兩對
                return "capsaSusun_word_card_type_08.png";

            case  CapsaSusun_CardKindType.ThreeOfAKind:
                // 三條
                return "capsaSusun_word_card_type_06.png";

            case CapsaSusun_CardKindType.Straight:
                // 順子
                return "capsaSusun_word_card_type_05.png";

            case  CapsaSusun_CardKindType.Flush:
                // 同花
                return "capsaSusun_word_card_type_04.png";

            case CapsaSusun_CardKindType.FullHouse:
                // 葫蘆
                return "capsaSusun_word_card_type_03.png";

            case CapsaSusun_CardKindType.FourOfAKind:
                // 鐵支
                return "capsaSusun_word_card_type_02.png";

            case  CapsaSusun_CardKindType.StraightFlush:
                // 同花順
                return "capsaSusun_word_card_type_01.png";

            default:
                return null;
        }
    },

    /**
     * 取碰觸到的牌墩位置
     * @param touch
     * @returns {*}         回傳碰觸到的牌墩位置
     */
    getStackPosByContains: function (touch) {
        var localPos = this.convertTouchToNodeSpace(touch);
        var cardBackArray = this._cardBackArray;

        // 找出碰到哪個位置的牌
        for (var i = 0; i < CapsaSusun_StackCount; i++) {
            var stackIdx = cardBackArray.findIndex(cur => cc.rectContainsPoint(cur, localPos));
            // 找到碰到誰
            if (stackIdx !== -1) {
                return stackIdx;
            }
        }
        // 沒找到 回傳null
        return -1;
    },

    /**
     * 取指定牌墩卡牌的位置
     * @param stackNum      第幾墩
     * @param stackIdx      第幾張
     * @returns {*}         回傳牌墩位置
     */
    getStackPosByStack: function (stackNum) {
        if (!this._cardBackArray[stackNum])
            return false;

        return this._cardBackArray[stackNum].basePos;
    },

    /**
     * 表演牌墩動畫
     * @param stackNum
     * @param isPlay
     */
    playStackAnima: function (stackNum, isPlay) {
        let stackGaf = this._stackGafArray[stackNum];
        stackGaf.stop();
        stackGaf.setVisible(false);

        if (isPlay) {
            stackGaf.setVisible(true);
            stackGaf.setSequenceDelegate((obj) => {
                obj.setVisible(false);
            });
            stackGaf.start();
        }
    },

    /**
     * 按鈕 =============================================
     */

    /**
     * 牌墩按鈕事件
     * @param sender
     */
    _stackBtnClicked: function (sender) {
        this._handCardLayer.addSelectedCardToHint(sender.stackNum);
    },

    /**
     * 點下交換按鈕
     */
    _changeBtnClicked: function () {
        this._handCardLayer.changeStackCards();
    },

    /**
     * 取消牌墩按鈕事件
     * @param sender
     */
    _cancelBtnClicked: function (sender) {
        // 手牌處理
        this._handCardLayer.removeStackCardFromHint(sender.stackNum);
    },

    /**
     * 推薦牌組按鈕
     * @param sender
     */
    _algorithmBtnClicked: function (sender) {
        this.updateAlgorithmBtnEnabled();
        this._handCardLayer.addAlgorithmCardToHint(sender.index);
        sender.setEnabled(false);

        // AppsFlyer 埋點
        GameAppsFlyerTracker.trackFirstClickType(GameAppsFlyerTrackerEnum.DEFAULT);
    },
});

CapsaSusun_HintCardMenuLayer.STATUS = {
    NONE_CARD: 1,    // 沒牌
    HAVE_CARD: 2,    // 有牌
    RIGHT_CARD: 3,   // 正確的牌組
    ERROR_CARD: 4,   // 錯誤的牌組
    TOUCH_ON: 5,     // 可點擊
    TOUCH_OFF: 6     // 不可點擊
};
