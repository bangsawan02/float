/**
 * Domino每日輪盤天數倍率顯示Node
 * isTeach: 是教學頁面使用的 會不給滑動
 */

var DailyLuckyWheelBonusDayNode = cc.Node.extend({
    ctor: function (isTeach = false) {
        this._super();

        var wheelData = DataModal.dailyLuckyWheelData;
        var status = wheelData.rewardStatus;
        var dayBonusList = wheelData.dayBonusList;                          // 天數獎勵倍率陣列
        var today = (status === DailyLuckyWheelData.STATUS.GET_REWARD_DONE) ? wheelData.today : wheelData.today + 1;       // 已領獎->是當天/其他是隔天狀態
        if (today > dayBonusList.length) today = dayBonusList.length;       // 登錄超過陣列天數 設為陣列長度(最後一天)

        // 左下天數顯示區
        var daysAreaNode = new cc.Node();
        this.addChild(daysAreaNode);

        // 天數標題
        var daysTitleSp = new cc.Sprite("#daily_lucky_wheel_word_days.png");
        daysTitleSp.setPosition(0, 85);
        daysAreaNode.addChild(daysTitleSp);

        // 黑底漸層
        var daysBgSp = new ccui.Scale9Sprite("lobby_bg_list_04.png");
        daysBgSp.setPreferredSize(cc.size(90, 152));
        daysBgSp.setPosition(0, 0);
        daysAreaNode.addChild(daysBgSp);

        // 金色外框
        var goldFrameSp = new ccui.Scale9Sprite("lobby_recommend.png");
        goldFrameSp.setPreferredSize(cc.size(90, 152));
        goldFrameSp.setPosition(0, 0);
        daysAreaNode.addChild(goldFrameSp);

        // 金色箭頭
        var goldArrowSp = new cc.Sprite("#daily_lucky_wheel_pic_arrow.png");
        goldArrowSp.setPosition(54, 56);
        daysAreaNode.addChild(goldArrowSp);

        // ScrollView
        var scrollSize = cc.size(85, 138);
        var mainLayer = new cc.Layer();
        var scrollView = this._scrollView = new cc.ScrollView(scrollSize, mainLayer);
        scrollView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        scrollView.setSwallowTouches(false);
        scrollView.setTouchEnabled(!isTeach);               // 教學頁面不能滑動
        scrollView.setPosition(-40, -70);
        daysAreaNode.addChild(scrollView);

        // 一個天數cell的高度
        var dayCellHeight = 18;

        for (var i = 0; i < dayBonusList.length; i++) {
            // 更新scrollView資料
            var curDay = i + 1;
            var isToday = curDay === today;

            if (isToday) {
                // 今日加上藍色背景
                var daySelectSprite = new ccui.Scale9Sprite("daily_lucky_wheel_bg_line_blue.png");
                daySelectSprite.setPreferredSize(cc.size(80, dayCellHeight));
                daySelectSprite.setPosition(39, i * dayCellHeight + 10);
                mainLayer.addChild(daySelectSprite);
            }

            // 天數字串(最後一天特殊顯示)
            var dayString = JSStringUtility.format(((curDay === dayBonusList.length) ? "≥%2s hari  %-sx" : "%3s hari  %-sx"), curDay, dayBonusList[i]);
            var dayLabel = new cc.LabelTTF(dayString, JSFontName, 11);
            dayLabel.setFontFillColor(isToday ? cc.color(255, 255, 0) : JSColor.WHITE);
            dayLabel.enableStroke(JSColor.BLACK, 2);
            dayLabel.setPosition(8, i * dayCellHeight + 3);
            dayLabel.setAnchorPoint(0, 0);
            mainLayer.addChild(dayLabel);
        }

        scrollView.setContentSize(scrollSize.width, dayCellHeight * dayBonusList.length);

        // 教學頁不滑動 介面固定
        if (!isTeach) {
            // 調整scrollView顯示位置
            if (today === dayBonusList.length) // 最後一天之後的高度
                scrollView.setContentOffset(cc.p(0, scrollView.getViewSize().height - dayCellHeight * today));
            else if (today > 7)
                scrollView.setContentOffset(cc.p(0, scrollView.getViewSize().height - dayCellHeight * today - 9));
        }
    }
});