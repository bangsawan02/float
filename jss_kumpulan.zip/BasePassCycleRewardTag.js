/**
 * 通行證 - 循環獎勵右上角可領次數 tag
 */
var BasePassCycleRewardTag = cc.Node.extend({
    ctor: function () {
        this._super();
        let tagSprite = this._tagSprite = new cc.Sprite("#luxyPass_pic_tags_01.png");
        tagSprite.setScale(0.8);
        this.addChild(tagSprite);

        let countLabel = this._countLabel = new cc.LabelTTF("-", JSFontName, 10);
        this.addChild(countLabel);
    },

    /**
     * 設定領獎次數
     * @param {int} times
     */
    setTimes: function (times) {
        this._countLabel.setString(times > 99 ? "99+" : times.toString());
    },

    /**
     * 跑文字縮放動畫
     */
    playLabelAnime: function () {
        this._countLabel.stopAllActions();
        this._countLabel.runAction(cc.sequence(
            cc.scaleTo(0.3, 1.3),
            cc.scaleTo(0.3, 1)
        ));
    },
});