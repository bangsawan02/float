/**
 * 簡單的選擇文字畫面
 */

var SELECT_DIALOG_CELL_WIDTH = 280;             //CELL的寬
var SELECT_DIALOG_CELL_HEIGHT = 40;             //CELL的高

var ArraySelectDialog = BaseDialogLayer.extend({
    ctor: function (array, index, cb) {
        this._super();

        this.key = "ArraySelectDialog";

        var aniNode = this._animationNode;

        this._contentArray = array;
        this._selectIndex = index;
        this._callback = cb;

        // 底
        var bgSprite = new ccui.Scale9Sprite("bg_information1.png");
        bgSprite.setPreferredSize(cc.size(300, 200));
        bgSprite.setPosition(JSScreenMidPos);
        aniNode.addChild(bgSprite);

        // TableView
        var tableSize = cc.size(SELECT_DIALOG_CELL_WIDTH, 180);
        var mainLayer = new cc.Layer();
        var tableView = this._tableView = new cc.TableView(this, tableSize, mainLayer);
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setPosition(JSScreenMidPos.x - tableSize.width / 2, JSScreenMidPos.y - tableSize.height / 2);
        aniNode.addChild(tableView);

        // 跳動畫
        this._startDialogAnimation();
    },

    /**
     * TableView delegate
     */
    tableCellTouched: function (table, cell) {
        // 把高亮拿掉
        cell.setIsHighted(false);

        if (this._callback)
            this._callback(cell.getIdx());

        // 關掉畫面
        this._closeDialogAnimation();
    },

    tableCellHighlight: function (table, cell) {
        if (cell)
            cell.setIsHighted(true);
    },

    tableCellUnhighlight: function (table, cell) {
        if (cell)
            cell.setIsHighted(false);
    },

    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        if (cell == null) {
            cell = new ArraySelectCell();
            cell.setAnchorPoint(cc.p(0, 0));
        }

        cell.refreshCell(this._contentArray[idx], this._selectIndex === idx);

        return cell;
    },

    numberOfCellsInTableView: function () {
        return this._contentArray.length;
    },

    tableCellSizeForIndex: function (table, idx) {
        return cc.size(SELECT_DIALOG_CELL_WIDTH, SELECT_DIALOG_CELL_HEIGHT);
    }
});

var ArraySelectCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        this.setCascadeOpacityEnabled(true);

        var node = this._contentNode = new cc.Node();
        node.setCascadeOpacityEnabled(true);
        this.addChild(node);

        var label = this._contentLabel = new cc.LabelTTF("", JSFontBoldName, 14);
        label.setFontFillColor(JSColor.BLACK);
        label.setPosition(SELECT_DIALOG_CELL_WIDTH / 2, 20);
        node.addChild(label);

        // 下方的線
        var line = new cc.LayerColor(cc.color(100, 100, 100, 200), SELECT_DIALOG_CELL_WIDTH, 1);
        this.addChild(line);
    },

    refreshCell: function (str, isSelect) {
        this._contentLabel.setString(str);
        this._contentLabel.setFontFillColor(isSelect ? JSColor.RED : JSColor.BLACK);
    },

    // 點到他 高亮
    setIsHighted: function (isSelect) {
        this._contentNode.setOpacity(isSelect ? 100 : 255);
    }
});