/**
 * 5.4.0 副系統 - 激戰任務icon
 * FierceBattleIconNode.showType: Room(桌列表) Game(桌內)
 * created by Jim.Chen
 */

var FierceBattleIconNode = LobbyIconNode.extend({
    ctor: function (showType, roomGameStr) {
        this._super();

        this.key = "FierceBattleIconNode";

        this._showType = showType;
        this._roomGameStr = roomGameStr;        // 桌列表會需要帶遊戲編號 用來要資料and開說明網址
        this.setVisible(false);

        var loadFileArray = this._loadFileArray = [
            "lobby/lobby_fierceBattle.plist", "lobby/lobby_fierceBattle.png",
            "common/number/num_06.plist", "common/number/num_06.png"
        ];

        var loadFileDone = () => {
            // 讀圖
            for (var i = 0, length = loadFileArray.length; i < length; i += 2) {
                cc.spriteFrameCache.addSpriteFrames(loadFileArray[i], loadFileArray[i + 1]);
            }

            this._loadFileDone = true;

            // 創畫面
            this._createView();

            // 拿Icon資料
            DataModal.fierceBattleData.startGetIconInfo(this._roomGameStr);

            // 註冊
            GS.addListener("NotifyFierceBattleIconDone", this.notifyFierceBattleIconDone.bind(this), this);
            // 牌桌內註冊
            if (showType === FierceBattleIconNode.showType.Game) {
                GS.addListener("NotifyFierceBattleGetScore", this.notifyFierceBattleGetScore.bind(this), this);
                GS.addListener("NotifyFierceBattleUpdateRank", this.notifyFierceBattleUpdateRank.bind(this), this);
            }
        };

        if (cc.sys.isNative) {
            loadFileDone();
        } else {
            cc.loader.load(loadFileArray, loadFileDone);
        }
    },

    onExit: function () {
        // 砍掉圖檔
        if (this._loadFileDone) {
            var loadFileArray = this._loadFileArray;
            for (var i = 0, length = loadFileArray.length; i < length; i += 2) {
                cc.spriteFrameCache.removeSpriteFramesFromFile(loadFileArray[i]);
            }
        }

        this._super();
    },

    // Override掉
    setVisible: function (value) {
        this._super(value);

        // 通知刷新按鈕的位置
        GS.dispatchCustomEvent("NotifyGameUIRefreshIconContainer");
    },

    /**
     * 創Icon畫面
     */
    _createView: function () {
        // icon按鈕
        var iconBtn = this._iconBtn = ButtonUtility.createSimpleImageButton("fierceBattle_pic_badge.png");
        iconBtn.setChangeColorWhenDisabled(false);
        iconBtn.addTouchUpInsideAction(this._iconClicked, this);
        this.addChild(iconBtn);

        switch (this._showType) {
            case FierceBattleIconNode.showType.Room:
                // 桌列表 無特別樣式
                break;

            case FierceBattleIconNode.showType.Game:
                // 桌內樣式

                // 紅點
                var badgeNode = this._badgeNode = new BadgeNode();
                badgeNode.useDefaultStyle();
                badgeNode.setPosition(cc.p(12, 11));
                badgeNode.setVisible(false);
                iconBtn.addChildToContentNode(badgeNode);

                // 倒數文字背景
                var blackBgSp = this._blackBgSp = new ccui.Scale9Sprite("lobby_pic_black.png");
                blackBgSp.setPreferredSize(cc.size(46, 12));
                blackBgSp.setPosition(0, -12);
                blackBgSp.setVisible(false);
                iconBtn.addChildToContentNode(blackBgSp);

                // 名次 && 倒數條 的背景
                var timerBgSp = this._timerBgSp = new ccui.Scale9Sprite("lobby_icon_textBg_02.png");
                timerBgSp.setCapInsets(cc.rect(7, 4, 8, 8));
                timerBgSp.setPreferredSize(cc.size(40, 14));
                timerBgSp.setPositionY(-12);
                timerBgSp.setVisible(false);
                iconBtn.addChildToContentNode(timerBgSp);

                // 提示文字
                var hintLabel = this._hintLabel = new cc.LabelTTF("", JSFontBoldName, 6);
                hintLabel.setPosition(0, -12);
                iconBtn.addChildToContentNode(hintLabel);

                break;
        }

        // 桌內桌外 都需要倒數
        var timeLabel = this._timeLabel = new GSTimeLabel("", JSFontBoldName, 8);
        timeLabel.setPositionY(-12);
        timeLabel.setMultiFormat("%ddD %hhH", "%hhH %mmM", "%mmM %ssS");
        timeLabel.enableStroke(JSColor.BLACK, 1);
        timeLabel.setVisible(false);
        iconBtn.addChildToContentNode(timeLabel);
    },

    /**
     * 刷新icon
     */
    _refreshView: function (isChangeRank) {
        var fierceStr = LocalizedString.FierceBattle;
        var fierceData = DataModal.fierceBattleData;
        var gameIconParams = fierceData.iconParam.gameIconParams;  // 放各玩法Icon資訊

        if (!gameIconParams[this._roomGameStr] || !gameIconParams[this._roomGameStr].isShowIcon) {
            this.setVisible(false);
            return;
        }

        this.setVisible(true);

        // 該玩法Icon狀態 有名次(可累積才有)&倒數時間
        var gameIconParam = this._gameIconParam = gameIconParams[this._roomGameStr];

        switch (this._showType) {
            case FierceBattleIconNode.showType.Room:
                // 桌列表 無特別變動
                break;

            case FierceBattleIconNode.showType.Game:
                // 桌內 先隱藏所有元件
                this._badgeNode.setVisible(false);
                this._blackBgSp.setVisible(false);
                this._timerBgSp.setVisible(false);
                this._timeLabel.setVisible(false);
                this._hintLabel.setVisible(false);

                switch (gameIconParam.eventStatus) {
                    case FierceBattleData.EventStatusType.ACCUMULATING:
                        // 可累積 顯示名次or倒數時間

                        this._timerBgSp.setVisible(true);
                        if (gameIconParam.myRank) {
                            // 玩家有獎牌 顯示名次
                            this._myRank = gameIconParam.myRank;
                            this._hintLabel.setVisible(true);
                            this._hintLabel.setString(fierceStr("名次-") + this._myRank);
                        } else {
                            // 顯示該時段倒數
                            this._timeLabel.setVisible(true);
                        }

                        // 名次變動顯示小紅點
                        this._badgeNode.setVisible(isChangeRank);
                        break;

                    case FierceBattleData.EventStatusType.RANKING:
                        // 結算中
                        this._blackBgSp.setVisible(true);
                        this._hintLabel.setVisible(true);
                        this._hintLabel.setString(fierceStr("結算中"));

                        break;

                    case FierceBattleData.EventStatusType.NORMAL:
                    case FierceBattleData.EventStatusType.SEASON_END:
                        // 不可累積也非結算(結算完畢) or 賽季過後24hr顯示已結束

                        if (gameIconParam.hasNextContest) {
                            // 稍後還有比賽 顯示時間
                            this._timerBgSp.setVisible(true);
                            this._timeLabel.setVisible(true);
                        } else {
                            // 後面沒有比賽 已結束
                            this._blackBgSp.setVisible(true);
                            this._hintLabel.setVisible(true);
                            this._hintLabel.setString(fierceStr("已結束"));
                        }

                        // 結算完畢小紅點
                        this._badgeNode.setVisible(fierceData.getPeriodEndRedPointStatus(this._roomGameStr));
                        break;

                }
                break;

        }

        // 桌內外都需要倒數
        if (gameIconParam.remainTime) {
            this._timeLabel.countdownSeconds(JSCodeUtility.getRemainTime(gameIconParam.remainTime, gameIconParam.socketTime), () => {
                    this.setVisible(false);

                    // 重新要資料
                    DataModal.fierceBattleData.startGetIconInfo(this._roomGameStr);
                }
            );
        }
    },

    /**
     * icon點擊
     */
    _iconClicked: function () {
        switch (this._showType) {
            case FierceBattleIconNode.showType.Room:
                // 桌列表按鈕點擊  跳說明頁
                var url = TexasUtility.getSimpleInfoURLByKey("fierce_battle", ["game=" + this._roomGameStr]);
                DialogManager.addDialog(new WebViewDialog(url), false);
                break;

            case FierceBattleIconNode.showType.Game:
                // 桌內跳活動視窗
                DialogManager.addDialog(new FierceBattleDialog());

                // 關玩法結算小紅點 或 排名變動小紅點
                DataModal.fierceBattleData.setPeriodEndRedPointStatus(this._roomGameStr, false);
                this._badgeNode.setVisible(false);

                // 埋點
                DataProcess.sendString("track_fierce_battle 3");
                break;
        }
    },

    /**
     * 通知收到資料
     */
    notifyFierceBattleIconDone: function () {
        // 刷新整個icon
        this._refreshView();

    },

    /**
     * 通知獲得獎牌
     */
    notifyFierceBattleGetScore: function (event) {
        // 可累積時才會有該動畫
        if (this._gameIconParam && this._gameIconParam.eventStatus === FierceBattleData.EventStatusType.ACCUMULATING) {
            var medalNum = event.getUserData();

            // 跑動畫 先關掉點擊事件
            this._iconBtn.setEnabled(false);

            if (!this._medalNumSp) {
                var numSprite = this._medalNumSp = new GSSpriteNumberNode({
                    number: 0,
                    spW: 13,
                    numStr: "#num_06_",
                    symbolName: "#num_06_+.png",
                    symbolLoc: GSSpriteNumberNode.SymbolLoc.FRONT
                });
                this.addChild(numSprite);
            }
            this._medalNumSp.setNumber(medalNum);

            var numSprite = this._medalNumSp;
            numSprite.setAnchorPoint(0, 0.5);
            numSprite.setPosition(10, 0);
            numSprite.setOpacity(0);

            numSprite.stopAllActions();
            numSprite.runAction(cc.sequence(
                cc.fadeIn(0.5).easing(cc.easeIn(0.5)),
                cc.fadeOut(0.5).easing(cc.easeIn(0.5))
            ));

            // 按鈕可點擊
            this._iconBtn.setEnabled(true);
        }
    },

    /**
     * 通知名次更新
     */
    notifyFierceBattleUpdateRank: function (event) {
        // 可累積時才會有該動畫
        if (this._gameIconParam && this._gameIconParam.eventStatus === FierceBattleData.EventStatusType.ACCUMULATING) {

            // 跑動畫 先關掉點擊事件
            this._iconBtn.setEnabled(false);

            // 這邊會收到
            var newRank = event.getUserData();
            var myRank = this._myRank;

            var isRankUp = false;               // 排名上升
            var isChangeRank = false;           // 排名是否變更
            if (myRank && newRank !== "-") {
                isRankUp = (myRank === "100+" && newRank <= 100) || (newRank < myRank);
                isChangeRank = (myRank !== newRank.toString());
            }
            // 沒有排名
            else {
                // 判斷新的排名 如果不是-(無排名)就代表排名有更動
                if (newRank !== "-")
                    isChangeRank = true;
            }
            this._gameIconParam.myRank = this._myRank = newRank;             // 更新名次

            if (isRankUp) {
                // 排名上升箭頭
                if (!this._rankUpArrow) {
                    var rankUpArrow = this._rankUpArrow = new cc.Sprite("#fierceBattle_pic_arrow.png");
                    rankUpArrow.setPosition(17, -12);
                    rankUpArrow.setScale(0.5);
                    rankUpArrow.setOpacity(0);
                    rankUpArrow.setRotation(90);
                    this._iconBtn.addChildToContentNode(rankUpArrow);
                }

                // 演排名上升動畫
                var rankUpArrow = this._rankUpArrow;
                rankUpArrow.stopAllActions();
                rankUpArrow.runAction(cc.sequence(
                    cc.fadeIn(0.33),
                    cc.fadeOut(0.33),
                    cc.fadeIn(0.33),
                    cc.fadeOut(0.33),
                    cc.fadeIn(0.33),
                    cc.fadeOut(0.33)
                ));
            }

            // 刷新icon
            this._refreshView(isChangeRank);

            // 按鈕可點擊
            this._iconBtn.setEnabled(true);
        }
    }
});

// icon顯示的地方
FierceBattleIconNode.showType = {
    Room: 0,
    Game: 1
};