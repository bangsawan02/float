/**
 * 通行證 - TableView header
 *
 * Config: {
 *     isHasTicketGradient: true                                // 要不要顯示漸層
 *     ticketGradientFileName: "",                              // 豪華票券背景漸層圖
 *     ticketGradientHeight: 85,                                // 豪華票券背景漸層高度
 *     ticketSpotFileName: "",                                  // 豪華票券背景光點
 *     ticketIconFileName: "",                                  // 豪華票券圖檔
 *     ticketIconPosition: cc.p(0, 46),                         // 豪華票券圖檔位置
 *     superTicketIconFileName: "",                             // 超級豪華票券圖檔 (三通行證系統)
 *     superTicketIconPosition: cc.p(0, 78),                    // 超級豪華票券圖檔位置 (三通行證系統)
 *     freeTicketIconFileName: "",                              // 免費票券圖檔
 *     freeTicketIconPosition: cc.p(0, -44),                    // 免費票券圖檔位置
 *     progressBarBgFileName: "",                               // 進度條背景圖案
 *     progressBarThumbnailFileName: "",                        // 進度條進度圖案
 *     progressBarAnimeTime: 0.5,                               // 進度條動畫速度
 *     progressBarHeigh: 14,                                    // 進度條高度
 *     shortProgressBarTokenScale: 1,                           // 短進度條代幣縮放倍率
 *     isUseThreePassSystem: false,                             // 是否使用三通行證系統
 *     isEnableShortProgressBar: true,                          // 是否啟用短進度條
 * }
 */
var BasePassTableHeaderNode = cc.Node.extend({
    ctor: function (config) {
        this._super();

        this._config = config;
        this._isUseThreePassSystem = config.isUseThreePassSystem || false;

        // 票券相關
        let luxuryGradient = config.ticketGradientFileName || "luxyPass_bg_gradient_01.png";
        let luxuryGradientHeight = config.ticketGradientHeight || 85;
        let luxurySpotLight = config.ticketSpotFileName || "luxyPass_pic_light_spot.png";
        let ticketFileName = config.ticketIconFileName || "luxyPass_pic_ticket_01.png";
        let ticketIconPosition = config.ticketIconPosition || cc.p(0, 46);
        let superTicketFileName = config.superTicketIconFileName || ticketFileName;
        let superTicketIconPosition = config.superTicketIconPosition || cc.p(0, 78);
        let freeTicketFileName = config.freeTicketIconFileName || "luxyPass_pic_ticket_02.png";
        let freeTicketIconPosition = config.freeTicketIconPosition || cc.p(0, -44);

        // 進度條相關
        let progressBarBgFileName = config.progressBarBgFileName || "luxyPass_pic_bar_02.png";
        let progressBarThumbnailFileName = config.progressBarThumbnailFileName || "luxyPass_pic_bar_01.png";
        let tokenIconFileName = config.tokenIconFileName || "luxyPass_pic_star.png";

        // 漸層
        if (config.isHasTicketGradient === undefined || config.isHasTicketGradient === true) {
            let gradientSprite = new ccui.Scale9Sprite(luxuryGradient);
            gradientSprite.setPreferredSize(cc.size(55, this._isUseThreePassSystem ? 120 : luxuryGradientHeight));
            gradientSprite.setPosition(32, 0);
            gradientSprite.setAnchorPoint(1, 0);
            this.addChild(gradientSprite);
        }

        // 光點效果
        if (this._isUseThreePassSystem) {
            // 三通行證系統時，兩個光點效果
            let superSpotLightSprite = new cc.Sprite("#" + luxurySpotLight);
            superSpotLightSprite.setPosition(superTicketIconPosition);
            this.addChild(superSpotLightSprite);

            let luxurySpotLightSprite = new cc.Sprite("#" + luxurySpotLight);
            luxurySpotLightSprite.setPosition(ticketIconPosition);
            this.addChild(luxurySpotLightSprite);
        } else {
            // 原系統只有一個光點
            let luxurySpotLightSprite = new cc.Sprite("#" + luxurySpotLight);
            luxurySpotLightSprite.setPosition(ticketIconPosition);
            this.addChild(luxurySpotLightSprite);
        }

        // 超級豪華票券（三通行證系統）
        if (this._isUseThreePassSystem) {
            let superTicketBtn = this._superTicketBtn = ButtonUtility.createSimpleButton(superTicketFileName);
            superTicketBtn.setChangeColorWhenDisabled(false);
            superTicketBtn.setPosition(superTicketIconPosition);
            this.addChild(superTicketBtn);
        }

        // 豪華票券
        let luxuryTicketBtn = this._luxuryTicketBtn = ButtonUtility.createSimpleButton(ticketFileName);
        luxuryTicketBtn.setChangeColorWhenDisabled(false);
        luxuryTicketBtn.setPosition(ticketIconPosition);
        this.addChild(luxuryTicketBtn);

        // 免費票券
        let freeTicketSprite = new cc.Sprite("#" + freeTicketFileName);
        freeTicketSprite.setPosition(freeTicketIconPosition);
        this.addChild(freeTicketSprite);

        // 放一個clipNode裁切一下進度條
        let stencil = new cc.LayerColor(cc.color(255, 255, 255, 255), 32, 14);
        let clipNode = new cc.ClippingNode(stencil);
        clipNode.setPosition(0, -8);
        this.addChild(clipNode);

        let barH = this._config.progressBarHeigh || 14;

        let isEnableShortProgressBar = this._config.isEnableShortProgressBar === undefined || this._config.isEnableShortProgressBar === true;
        // 前段進度條
        let shortProgressBar = this._shortProgressBar = new GSProgressTimer(
            progressBarBgFileName,
            progressBarThumbnailFileName,
            cc.size(48, barH),
            cc.size(46, barH - 2));
        shortProgressBar.setPosition(20, 7);
        shortProgressBar.setAnimationTime(config.progressBarAnimeTime || 0.5);
        shortProgressBar.setVisible(isEnableShortProgressBar);
        clipNode.addChild(shortProgressBar);

        let tokenSprite = this._progressBarTokenSprite = new cc.Sprite("#" + tokenIconFileName);
        tokenSprite.setScale(config.shortProgressBarTokenScale || 1);
        tokenSprite.setPosition(0, 0);
        tokenSprite.setVisible(isEnableShortProgressBar);
        this.addChild(tokenSprite);
    },

    /**
     * 取得豪華票券按鈕
     * @returns {*}
     */
    getLuxuryTicketBtn: function () {
        return this._luxuryTicketBtn;
    },

    /**
     * 取得超級豪華票券按鈕（三通行證系統）
     * @returns {*}
     */
    getSuperTicketBtn: function () {
        return this._superTicketBtn;
    },

    /**
     * 取得進度條
     * @returns {*}
     */
    getShortProgressBar: function () {
        return this._shortProgressBar;
    },

    /**
     * 取得進度條代幣 icon
     * @returns {*}
     */
    getProgressBarTokenSprite: function () {
        return this._progressBarTokenSprite;
    },

    /**
     * 檢查是否使用三通行證系統
     * @returns {boolean}
     */
    isUseThreePassSystem: function () {
        return this._isUseThreePassSystem;
    },
});