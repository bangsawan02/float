/**
 * CapsaSusun 智慧選牌按鈕選單
 */

var CapsaSusun_HintCardMenuBarLayer = cc.Layer.extend({
    ctor: function (choiceCardByArrayCB) {
        this._super();

        this._btnList = [];                         // 用來記牌型按鈕
        this._clickedCount = 0;                     // 用來記牌型目前點到第幾組提示

        // 需要回傳的callBack
        this._choiceCardByArrayCB = choiceCardByArrayCB;

        this._lastClickType = Pokers_CardKindType.None;

        // 智慧選牌顯示順序
        this._straightFlushArrayShowOrderList = []; // 同花順
        this._fourOfAKindArrayShowOrderList = [];   // 鐵支
        this._fullHouseArrayShowOrderList = [];     // 葫蘆
        this._flushArrayShowOrderList = [];         // 同花
        this._straightArrayShowOrderList = [];      // 順子
        this._threeOfAKindArrayShowOrderList = [];  // 三條
        this._pairArrayShowOrderList = [];          // 一對

        // 牌型按鈕的順序
        var cardKindTypes = this._cardKindTypes = [
            Pokers_CardKindType.StraightFlush,
            Pokers_CardKindType.FourOfAKind,
            Pokers_CardKindType.FullHouse,
            Pokers_CardKindType.Flush,
            Pokers_CardKindType.Straight,
            Pokers_CardKindType.ThreeOfAKind,
            Pokers_CardKindType.OnePair
        ];

        // TabMenu
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        this.addChild(menu);

        var btnImages = ["lobby_btn_01.png", "lobby_btn_01.png", "lobby_btn_04.png"];
        var btnSize = cc.size(71, 27);
        // 開始產生牌型按鈕
        cardKindTypes.forEach((cur, index) => {
            var itemNode = ButtonUtility.createSingleScale9SpriteNodes(btnImages, btnSize, "#capsaSusun_word_card_type_0" + (index + 1) + ".png");
            itemNode.forEach(cur => cur.word.setScale(0.8));
            itemNode[2].setOpacity(255);
            itemNode[2].setColor(JSColor.GRAY);
            var btn = new cc.MenuItemSprite(itemNode[0], itemNode[1], itemNode[2], this._buttonClicked, this);
            btn.cardKindType = cur;
            btn.setPosition(37 + JSScreenBonusHalfWidth + 73 * index, 15);
            menu.addChild(btn);

            this._btnList[cur] = btn;
        });
    },

    /**
     * 功能 =============================================
     */

    /**
     * 檢查牌組
     * @param hintCardTool     傳算牌完的資訊進來
     */
    checkAllCard: function (hintCardTool) {
        // 牌型按鈕的順序
        var cardKindTypes = this._cardKindTypes;

        for (var i = 0; i < cardKindTypes.length; i++) {
            var cardType = cardKindTypes[i];
            switch (cardType) {
                // 同花順
                case  Pokers_CardKindType.StraightFlush:
                    this._straightFlushArrayShowOrderList = hintCardTool.getHintArray(cardType);
                    break;

                // 鐵支
                case Pokers_CardKindType.FourOfAKind:
                    this._fourOfAKindArrayShowOrderList = hintCardTool.getHintArray(cardType);
                    break;

                // 葫蘆
                case Pokers_CardKindType.FullHouse:
                    this._fullHouseArrayShowOrderList = hintCardTool.getHintArray(cardType);
                    break;

                // 同花
                case  Pokers_CardKindType.Flush:
                    this._flushArrayShowOrderList = hintCardTool.getHintArray(cardType);
                    break;

                // 順子
                case Pokers_CardKindType.Straight:
                    this._straightArrayShowOrderList = hintCardTool.getHintArray(cardType);
                    break;

                // 三條
                case  Pokers_CardKindType.ThreeOfAKind:
                    this._threeOfAKindArrayShowOrderList = hintCardTool.getHintArray(cardType);
                    break;

                // 一對
                case  Pokers_CardKindType.OnePair:
                    this._pairArrayShowOrderList = hintCardTool.getHintArray(cardType);
                    break;

                default:
                    continue;
            }
            this._btnList[cardType].setEnabled(this.getHintShowOrderList(cardType).length > 0);
        }
        this._lastClickType = Pokers_CardKindType.None;
        this._clickedCount = 0;
    },

    /**
     * 取得對應的hint顯示順序
     * @param cardKindType      要抓哪個牌型array的顯示順序
     */
    getHintShowOrderList: function (cardKindType) {
        switch (cardKindType) {
            // 同花順
            case  Pokers_CardKindType.StraightFlush:
                return this._straightFlushArrayShowOrderList;

            // 鐵支
            case Pokers_CardKindType.FourOfAKind:
                return this._fourOfAKindArrayShowOrderList;

            // 葫蘆
            case Pokers_CardKindType.FullHouse:
                return this._fullHouseArrayShowOrderList;

            // 同花
            case  Pokers_CardKindType.Flush:
                return this._flushArrayShowOrderList;

            // 順子
            case Pokers_CardKindType.Straight:
                return this._straightArrayShowOrderList;

            // 三條
            case  Pokers_CardKindType.ThreeOfAKind:
                return this._threeOfAKindArrayShowOrderList;

            // 一對
            case  Pokers_CardKindType.OnePair:
                return this._pairArrayShowOrderList;

            default:
                return [];
        }
    },

    /**
     * 按鈕相關 =============================================
     */

    /**
     * 按下選牌按鈕
     * @param sender
     */
    _buttonClicked: function (sender) {
        var cardKindType = sender.cardKindType;

        // 如果按到的牌型跟上次不一樣, 清空上次選的牌型的計數
        if (this._lastClickType !== cardKindType) {
            this._clickedCount = 0;
            // 更新牌型選取紀錄
            this._lastClickType = cardKindType;
        }

        // 抓出提示的array
        var targetArray = this.getHintShowOrderList(cardKindType);

        var param = null;
        if (this._clickedCount >= targetArray.length) {
            // 點超過一輪 重置計數＆降下所有選牌
            this._clickedCount = 0;
        } else {
            // 計數要+1
            param = targetArray[this._clickedCount++];
        }

        // 把提示傳出去
        this._choiceCardByArrayCB(param);
    },
});