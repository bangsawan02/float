/**
 *  百家樂主畫面
 */

var BaccaratLayer = VegasGameBaseLayer.extend({
    ctor: function () {
        this._super();

        this.setCascadeOpacityEnabled(true);

        cc.spriteFrameCache.addSpriteFrames("vegas/baccarat/baccarat.plist", "vegas/baccarat/baccarat.png");

        // 初始化參數
        this._enableProcessMessage = true;          // 是否可以執行cmd
        this._isFirstHit = true;                    // 是否第一次加注 用來決定加倍按鈕要不要出現

        // 設定機台是哪一個 一定要設
        this._vegasType = VegasGameType.BACCARAT;

        // 清掉指令
        DataModal.vegasData.cleanMessageQueue(this._vegasType);

        // 先算出現在預設是要大注還是小注
        var freeTicketCount = DataModal.vegasData.freeTicket.Baccarat;
        this._isBigTable = freeTicketCount === 0 && (DataModal.profileData.money >= BaccaratTableMaxMoney);

        // 背景
        var bgSprite = this._bgSprite = new cc.Sprite(this._isBigTable ? "#bcr_background2.png" : "#bcr_background.png");
        var bgContentSize = bgSprite.getContentSize();
        bgSprite.setPosition(JSScreenMidPos);
        bgSprite.setScaleX(JSVisibleSize.width / bgContentSize.width);
        bgSprite.setScaleY(JSVisibleSize.height / bgContentSize.height);
        this.addChild(bgSprite, -2);

        // 新增返回按鈕
        this._backMenuItem = this._addBackButton(this._backBtnClicked, this, 7);

        // 牌王之路icon
        this._addGamblerRoadIconNode(7, 44);

        // 大小注切換的按鈕
        this._changeBetMenuItem = this._addChangeBetButton(this._isBigTable, this._changeBetClicked, this, 7);

        // 右上方賠率按鈕
        var itemNodes = ButtonUtility.createSingleScale9SpriteNodes("btn_square_up.png", null, "#rate_table_btn.png");
        var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._openRateInfoClicked, this);
        var menu = new cc.Menu(menuItem);
        menu.setPosition(JSVisibleSize.width - 18 - JSScreenSafeWidth, JSVisibleSize.height - 18);
        this.addChild(menu, 5);

        // 標題
        var titleSprite = new cc.Sprite("#brc_logo.png");
        titleSprite.setPosition(JSScreenMidPos.x, JSVisibleSize.height - 26);
        this.addChild(titleSprite);

        // 擺放牌的畫面
        this._pokerLayer = new BaccaratPokerLayer();
        this.addChild(this._pokerLayer);

        // 下注的桌面
        var tableLayer = this._tableLayer = new BaccaratTableLayer(this._tableBetClicked.bind(this));
        this.addChild(tableLayer, 1);

        // 歷史紀錄
        this._recordLayer = new BaccaratRecordLayer();
        this.addChild(this._recordLayer, 1);

        // 下方背景條
        var downBgSprite = new ccui.Scale9Sprite("bcr_bt_menu_bg.png");
        downBgSprite.setPreferredSize(cc.size(JSVisibleSize.width, 40));
        downBgSprite.setPosition(JSScreenMidPos.x, 46);
        this.addChild(downBgSprite, 1);

        // 小注按鈕
        this._betMenuArray = [];
        var smallBetMenu = this._smallBetMenu = new cc.Menu();
        smallBetMenu.setPosition(0, 0);
        this.addChild(smallBetMenu, 7);

        var chipsSpriteName = ["#vegas_cycle_chip_red.png", "#vegas_cycle_chip_blue.png", "#vegas_cycle_chip_green.png"];
        var chipsString = [BaccaratMoneyType.Small_L_Chips, BaccaratMoneyType.Small_M_Chips, BaccaratMoneyType.Small_R_Chips].map(cur => {
            return JSStringUtility.format("#vegas_chip_word_%s.png", cur);
        });
        for (var i = 0; i < 3; i++) {
            var chipBetMenuItem = this._createBetChipMenuItem(chipsSpriteName[i], chipsString[i], this._chipBetClicked, this);
            chipBetMenuItem.setPosition(JSScreenMidPos.x + (48 * (i - 1)), 52);
            smallBetMenu.addChild(chipBetMenuItem);

            this._betMenuArray.push(chipBetMenuItem);
        }

        // 大注按鈕
        var bigBetMenu = this._bigBetMenu = new cc.Menu();
        bigBetMenu.setPosition(0, 0);
        this.addChild(bigBetMenu, 7);

        var chipsSpriteName = ["#vegas_cycle_chip_green.png", "#vegas_cycle_chip_orange.png", "#vegas_cycle_chip_red_gray.png"];
        var chipsString = [BaccaratMoneyType.Big_L_Chips, BaccaratMoneyType.Big_M_Chips, BaccaratMoneyType.Big_R_Chips].map(cur => {
            return JSStringUtility.format("#vegas_chip_word_%s.png", cur);
        });
        for (var i = 0; i < 3; i++) {
            var chipBetMenuItem = this._createBetChipMenuItem(chipsSpriteName[i], chipsString[i], this._chipBetClicked, this);
            chipBetMenuItem.setPosition(JSScreenMidPos.x + (48 * (i - 1)), 52);
            bigBetMenu.addChild(chipBetMenuItem);

            this._betMenuArray.push(chipBetMenuItem);
        }

        // 免費券Node
        var freeTicketNode = this._freeTicketNode = new VegasFreeTicketNode(VegasGameType.BACCARAT);
        freeTicketNode.setPosition(JSScreenMidPos.x, 52);
        freeTicketNode.setEnableAutoRefresh(true);
        freeTicketNode.setScale(1.4);
        freeTicketNode.setVisible(false);
        this.addChild(freeTicketNode, 8);

        // 其他按鈕
        var mainMenu = new cc.Menu();
        mainMenu.setPosition(0, 0);
        this.addChild(mainMenu, 2);

        // 下注金額Led
        var ledPos = cc.p(80 + JSScreenSafeWidth, 44);
        var ledNode = this._ledNode = new BaccaratLedNode();
        ledNode.setPosition(ledPos);
        this.addChild(ledNode, 1);

        // 下注金額文字
        var tableWordSprite = new cc.Sprite("#bcr_word_bet.png");
        tableWordSprite.setPosition(ledPos.x, ledPos.y + 14);
        this.addChild(tableWordSprite, 1);

        // 重覆下注按鈕
        var mainMenu = this._mainMenu = new cc.Menu();
        mainMenu.setPosition(0, 0);
        this.addChild(mainMenu, 1);

        var reBetMenuItem = this._reBetMenuItem = this._createBetMenuItem("#bcr_bt_reroll_up.png",
            "#bcr_bt_reroll_down.png", "#vegase_bt_word_reroll.png", [2, -2, -2], this._reBetClicked, this);
        reBetMenuItem.setPosition(365 + JSScreenBonusWidth, 48);
        mainMenu.addChild(reBetMenuItem);

        // 清除按鈕
        var cleanMenuItem = this._cleanMenuItem = this._createBetMenuItem("#bcr_bt_clear_up.png",
            "#bcr_bt_clear_down.png", "#vegase_bt_word_clear.png", [2, -2, -2], this._cleanClicked, this);
        cleanMenuItem.setPosition(411 + JSScreenBonusWidth, 48);
        mainMenu.addChild(cleanMenuItem);

        // 開使搖骰按鈕
        var startMenuItem = this._startMenuItem = this._createBetMenuItem("#bcr_bt_hit_up.png",
            "#bcr_bt_hit_down.png", "#brc_word_bagi_kartu.png", [4, 0, 0], this._startClicked, this);
        startMenuItem.setPosition(470 + JSScreenBonusWidth, 48);
        mainMenu.addChild(startMenuItem);

        // 新增下方儲值選單
        this._addPurchaseMenu(this._purchaseClicked, this, 10);

        // 新增天線
        this._addAntenna(12);

        // 新增場編
        this._addSerialNumber(10);

        // 判斷大小注的畫面
        smallBetMenu.setVisible(!this._isBigTable);
        bigBetMenu.setVisible(this._isBigTable);

        // 最後切換到該有的桌次
        this._changeTable(this._isBigTable);

        // 動畫相關的Layer
        var effectLayer = this._effectLayer = new BaccaratEffectLayer();
        this.addChild(effectLayer, 12);

        // 加洗牌的畫面
        var washCardLayer = this._washCardLayer = new BaccaratWashCardLayer();
        this.addChild(washCardLayer, 100);

        // 最後創一個檔Touch用的東西 用來防止動畫的時後去按到
        var dummyTouch = this._dummyTouchLayer = new DummyTouchLayer(JSVisibleSize);
        dummyTouch.setVisible(false);
        this.addChild(dummyTouch, 50);

        // 註冊
        GS.addListener("NotifyBaccaratSendDone", this._notifyBaccaratSendDone.bind(this), this);
        GS.addListener("NotifyRefreshFreeTicket", this._notifyRefreshFreeTicket.bind(this), this);
        GS.addListener("NotifySlotFailCMD", this._notifySlotFailCMD.bind(this), this);
    },

    onEnter: function () {
        this._super();

        // 加Android
        PushScene.addBackKeyEnableLayer(this);
    },

    onExit: function () {
        PushScene.removeBackKeyEnableLayer(this);

        // 送出離開
        DataProcess.sendString("slot13_leave");

        cc.spriteFrameCache.removeSpriteFramesFromFile("vegas/baccarat/baccarat.plist");

        this._super();
    },

    _enterVegasGame: function () {
        // 加UI(確認近GameServer才能要資料)
        {
            // 側邊欄 要比下面dummy高
            this._addSideOptionLayer(51);

            // 新增聚寶盆icon
            var treasureBowlIcon = new TreasureBowlGameIconNode();
            treasureBowlIcon.setGameTypeAddProgressBar(VegasGameType.BACCARAT);
            treasureBowlIcon.setScale(0.6);
            treasureBowlIcon.setPosition(JSVisibleSize.width - JSScreenSafeWidth - 100, 15);
            this.addChild(treasureBowlIcon, 11);
        }

        // 第一次進來要動畫
        if (!this._firstIn) {
            this._firstIn = true;

            // Server依靠slot13_start來重新給玩家新一副牌
            DataProcess.sendString("slot13_start");

            // 先洗牌 洗完牌去出現閃亮亮動畫
            this._washCardLayer.startWashCardAsync()
                .then(() => {
                    // 已經砍掉了不做事
                    if (this.__isDestroyed)
                        return;

                    // 設定現在牌的數量
                    this._pokerLayer.setCardCount(312);

                    // 給Table顯示提示
                    this._tableLayer.showFirstHint();
                });
        }
    },

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        // 先判斷返回是否能按
        if (this._dummyTouchLayer.isVisible())
            return;

        this._super();
    },

    /**
     * Push Protocol
     */
    // 畫面要出現
    viewWillAppear: function () {
        this._super();
    },

    // 畫面出現動畫做完後
    viewDidAppear: function () {
        this._super();
    },

    // 畫面要結束
    viewWillDisappear: function () {
        // 要拿掉 Socket CMD監聽
        this._eventListener && cc.eventManager.removeListener(this._eventListener);
        this._eventListener = null;

        this._super();
    },

    /**
     * 重置所有東西 用在結算過後
     */
    _clean: function () {
        // 先把檔Touch關掉
        this._dummyTouchLayer.setVisible(false);

        // 清掉桌面
        this._tableLayer.clean();

        // 清掉牌
        this._pokerLayer.clean();

        // LED歸0
        this._ledNode.setMoney(0, false);

        // 設定沒有重新下注
        this._reBetChipsDone = false;

        // 更新按鈕
        this._updateBetMenuItems();
    },

    /**
     * 更新免費券的使用量
     */
    _refreshFreeTicket: function (isClean) {
        var freeTicketCount = DataModal.vegasData.freeTicket.Baccarat;
        if (freeTicketCount) {
            var usedFreeTicketCount = this._tableLayer.getUsedFreeTicketCount();

            // 不是按到清除按鈕的 都需要扣券數量
            if (!isClean)
                freeTicketCount -= usedFreeTicketCount;

            // 要更新畫面
            this._freeTicketNode.setFreeTicketCount(freeTicketCount < 0 ? 0 : freeTicketCount);
        }
        this._isUseFreeTicket = (!this._isBigTable && freeTicketCount > 0);
        this._freeTicketNode.setVisible(this._isUseFreeTicket);

        // 因為會動態會更新 所以要更新小注的按鈕
        this._smallBetMenu.setVisible(!this._isBigTable && !this._isUseFreeTicket);
    },

    /**
     * 創按鈕類的東西
     */
    // 創下注金額按鈕
    _createBetChipMenuItem: function (chipName, chipString, callback, target) {
        var itemNodes = [];

        for (var i = 0; i < 3; i++) {
            var node = itemNodes[i] = new cc.Node();
            node.setCascadeColorEnabled(true);
            node.setCascadeOpacityEnabled(true);

            var bgSprite = new cc.Sprite(chipName);
            var wordSprite = new cc.Sprite(chipString);
            node.addChild(bgSprite);
            node.addChild(wordSprite);

            var size = bgSprite.getContentSize();
            bgSprite.setPosition(size.width / 2, size.height / 2);
            wordSprite.setPosition(size.width / 2, size.height / 2);

            node.setContentSize(size);

        }
        itemNodes[0].setColor(cc.color(100, 100, 100));
        itemNodes[1].setColor(cc.color(200, 200, 200));

        return new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], callback, target);
    },

    // 創下注系列的按鈕
    _createBetMenuItem: function (bgName, pressBgName, wordName, offsetY, callback, target) {
        var itemNodes = [];

        for (var i = 0; i < 3; i++) {
            var node = itemNodes[i] = new cc.Node();
            node.setCascadeColorEnabled(true);
            node.setCascadeOpacityEnabled(true);

            var bgSprite = new cc.Sprite(i == 0 ? bgName : pressBgName);
            var wordSprite = new cc.Sprite(wordName);
            node.addChild(bgSprite);
            node.addChild(wordSprite);

            var size = bgSprite.getContentSize();
            bgSprite.setPosition(size.width / 2, size.height / 2);
            wordSprite.setPosition(size.width / 2, offsetY[i] + size.height / 2);

            node.setContentSize(size);
        }

        return new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], callback, target);
    },

    /**
     * 按鈕
     */
    // 按到儲值
    _purchaseClicked: function () {
        // 要去儲值頁
        PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
    },

    // 按到切換大小注
    _changeBetClicked: function (sender) {
        // 抓取切換過去後的按鈕
        var selectedMenuItem = sender.getSelectedItem();

        var isBig = !selectedMenuItem.isBig;

        // 切換桌
        this._changeTable(isBig);
    },

    // 按到賠率表
    _openRateInfoClicked: function () {
        DialogManager.addDialog(new VegasIntroDialog(VegasGameType.BACCARAT));
    },

    // 下注籌碼
    _chipBetClicked: function (sender) {
        var clickedIndex = 0;
        this._betMenuArray.forEach(function (cur, index) {
            cur.setEnabled(true);
            if (cur == sender)
                clickedIndex = index;
        });
        sender.setEnabled(false);

        // 告知Table現在的下注籌碼
        this._tableLayer.setBetChipsIndex(clickedIndex);
    },

    // 重新下注
    _reBetClicked: function () {
        this._tableLayer.reBetChips();

        // 已重新下注打開
        this._reBetChipsDone = true;

        // 重置按鈕
        this._updateBetMenuItems();

        // 更新用掉多少免費券
        this._refreshFreeTicket();
    },

    // 清除
    _cleanClicked: function () {
        // 清掉Table上的東西
        this._tableLayer.clean();

        // 已重新下注關掉
        this._reBetChipsDone = false;

        // 清掉LED
        this._ledNode.setMoney(0, false);

        // 更新按鈕
        this._updateBetMenuItems();

        // 更新用掉多少免費券
        this._refreshFreeTicket(true);
    },

    // 開始
    _startClicked: function () {
        this._tableLayer.sendStartCMD();

        // 先把檔Touch打開
        this._dummyTouchLayer.setVisible(true);

        // AppsFlyer埋點
        GSAppsFlyerWrapper.logEvent("casino");

        // Firebase 埋點
        var eventName = GSAnalyticsAdapter.record.game + "娛樂城玩法";
        GSAnalyticsAdapter.logEventByFirebaseAll(eventName, ["大廳"], ["百家樂下注"]);
    },

    // 按到桌子的感應區
    _tableBetClicked: function (zoneType) {
        // 用來更新按鈕
        this._updateBetMenuItems();

        // 更新用掉多少免費券
        this._refreshFreeTicket();
    },

    /**
     * 處理切換大小桌
     */
    _changeTable: function (isBig, isReconnect) {
        this._isBigTable = isBig;

        // 更新切換大小注按鈕
        this._changeBetMenuItem.setSelectedIndex(isBig ? 1 : 0);

        // 清掉Table上的東西 要在免費券上面
        this._tableLayer.clean();

        // 先判斷是否使用免費券
        this._notifyRefreshFreeTicket();

        // 下注按鈕
        this._bigBetMenu.setVisible(isBig);
        this._smallBetMenu.setVisible(!isBig && !this._isUseFreeTicket);

        // 下注按鈕預設第二個 假如有免費券 小注要變第一個
        if (this._isUseFreeTicket)
            this._chipBetClicked(this._betMenuArray[0]);
        else
            this._chipBetClicked(this._betMenuArray[1 + (isBig ? 3 : 0)]);

        // 設定Table是大注還小注
        this._tableLayer.setIsBigTable(isBig);

        // 清掉LED
        this._ledNode.setMoney(0, false);

        // 背景圖更改
        this._bgSprite.setSpriteFrame(isBig ? "bcr_background2.png" : "bcr_background.png");

        // 按鈕重置
        this._reBetChipsDone = false;
        this._updateBetMenuItems();
    },

    /**
     * 處理 重新下注 清除 搖骰 按鈕的開關
     */
    _updateBetMenuItems: function () {
        var canStart = this._tableLayer.getCanStart();
        this._cleanMenuItem.setEnabled(canStart);
        this._startMenuItem.setEnabled(canStart);

        // 可否重新下注判斷
        var canReBet = this._tableLayer.getCanReBetChips();
        this._reBetMenuItem.setEnabled(canReBet && !this._reBetChipsDone);
    },

    /**
     * 通知
     */
    // Socket回來了
    _notifyBaccaratSendDone: function (event) {
        var param = event.getUserData();

        // 把檔Touch打開
        this._dummyTouchLayer.setVisible(true);

        // 把紀錄關掉
        this._recordLayer.close();

        // 更新聚寶盆 透過網址
        var betMoney = param.betMoney;
        DataModal.treasureBowlData.treasureBowlParam && DataModal.treasureBowlData.updateDataBy(betMoney);

        // 存下遊戲紀錄
        this._savePlayerRecord();

        // 開始動畫
        this._pokerLayer.sendFirstCardAsync(param)                                  // 發四張牌
            .then(res => this._tableLayer.showBigRoadAsync(param))                  // 判斷是否要出現有一對的牌
            .then(res => this._pokerLayer.sendLastCardAsync(param))                 // 發最後兩張牌
            .then(res => this._tableLayer.showWinReslutAsync(param))                // 結算畫面
            .then(res => {
                // 把牌收起來
                this._pokerLayer.closeCard();

                // 輸贏動畫
                return this._effectLayer.showFinishResultAsync(param, res);
            })
            .then(res => {
                // 清掉畫面
                this._clean();
                // 通知外面動畫結束，檢查有沒有事情要做
                this.notifyVegasGameFinished();
                // 出現紀錄
                this._recordLayer.updateRecord(param);

                // 判斷是否要洗牌
                if (param.needShuffle) {
                    this._washCardLayer.startWashCardAsync()
                        .then(res => {
                            // 設定現在牌的數量
                            this._pokerLayer.setCardCount(312);
                        });
                }
            });

        // 更新身上的錢
        // 有比排的特殊動畫
        // slot13_send {"total":"278","road":["1","05"],"cards":["15","4K","3K","1T","45","48"],"shuffle":"0","bet_tmoney":"997906000","totalbet":"1000000","win_status":"1","result":["2000000","0","0","0","0"],"tmoney":"999906000","totalwin":"2000000"}
    },

    // 更新免費券
    _notifyRefreshFreeTicket: function () {
        this._refreshFreeTicket();
    },

    // 下注失敗
    _notifySlotFailCMD: function (event) {
        if (event && event.getUserData()) {
            // 把按鈕打開
            this._clean();
        }
    }
});
