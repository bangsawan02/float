/**
 * v5.4.5 背包
 * 目前用在大廳商城裡面的背包
 *
 * tabTitles: 上方頁籤(有預設 可不給)
 */
var BackpackDialog = BaseDialogLayer.extend({
    ctor: function (tabTitles) {
        this._super();

        this.key = "BackpackDialog";

        this.setCascadeOpacityEnabled(true);

        var aniLayer = this._animationLayer;

        this._tabButton = [];
        this._pageArray = [];

        var shopString = LocalizedString.Shop;

        if (!tabTitles) {
            tabTitles = [
                {title: "物品", type: ShopType.BACKPACK},
                {title: "延效", type: ShopType.EXTEND},
                {title: "頭像框", type: ShopType.FRAME},
                {title: "勳章", type: ShopType.MEDAL},
                {title: "其它", type: ShopType.OTHER},
                {title: "碎片", type: ShopType.SHARD}
            ];
        }

        // 背景底
        var bgSprite = this._bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(cc.size(384, 276));
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite, -1);

        // 光暈
        var lightSprite = new cc.Sprite("#lobby_pic_pink_light.png");
        lightSprite.setScale(100);
        lightSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(lightSprite, -1);

        // 黑底
        var blackBgSprite = new ccui.Scale9Sprite("lobby_bg_list_04.png");
        blackBgSprite.setPreferredSize(cc.size(345, 214));
        blackBgSprite.setPosition(JSScreenMidPos.x, 138 + JSScreenBonusHalfHeight);
        aniLayer.addChild(blackBgSprite);

        // 上方光暈
        var topBgLightSprite = new cc.Sprite("#lobby_pic_light_gold.png");
        topBgLightSprite.setPosition(JSScreenMidPos.x, 254 + JSScreenBonusHalfHeight);
        aniLayer.addChild(topBgLightSprite);

        // 下方光暈
        var bottomBgLightSprite = new cc.Sprite("#lobby_pic_light_gold.png");
        bottomBgLightSprite.setFlippedY(true);
        bottomBgLightSprite.setPosition(JSScreenMidPos.x, 22 + JSScreenBonusHalfHeight);
        aniLayer.addChild(bottomBgLightSprite);

        // tab可以滑動
        var scrollSize = cc.size(337, 30);
        var mainLayer = this._mainLayer = new cc.Layer();
        var scrollView = this._scrollView = new cc.ScrollView(scrollSize, mainLayer);
        scrollView.setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
        scrollView.setPosition(85 + JSScreenBonusHalfWidth, 244 + JSScreenBonusHalfHeight);
        aniLayer.addChild(scrollView);

        var leftDummyTouchLayer = new DummyTouchLayer(cc.size(85, 30));
        leftDummyTouchLayer.setPosition(0, 244 + JSScreenBonusHalfHeight);
        aniLayer.addChild(leftDummyTouchLayer);

        var rightDummyTouchLayer = new DummyTouchLayer(cc.size(JSVisibleSize.width - 422, 30));
        rightDummyTouchLayer.setPosition(422 + JSScreenBonusHalfWidth, 244 + JSScreenBonusHalfHeight);
        aniLayer.addChild(rightDummyTouchLayer);

        // 建立tab
        var btnImages = ["lobby_btn_tab_02.png", "lobby_btn_tab_02.png", "lobby_btn_tab_01.png"];
        var btnSize = cc.size(62, 20);
        var offsetX = btnSize.width + 2;
        var len = tabTitles.length;
        for (var i = 0; i < len; i++) {
            var itemNode = ButtonUtility.createArrayScale9Nodes(btnImages, btnSize, shopString(tabTitles[i].title), 10, JSColor.WHITE);

            // 重新設定
            itemNode[2].setColor(JSColor.WHITE);
            itemNode[2].setOpacity(255);

            // 上方頁籤按鈕
            var button = this._tabButton[i] = new GSControlButton(itemNode[0], btnSize);
            button.setCascadeOpacityEnabled(true);
            button.setAnchorPoint(0, 0);
            button.setPosition(i * offsetX, 0);
            button.addTouchUpInsideAction(this._tabClicked, this);
            button.setBackgroundSpriteForState(itemNode[2], cc.CONTROL_STATE_DISABLED);
            button.enableTouchCancel(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
            button.type = tabTitles[i].type;
            mainLayer.addChild(button);
        }
        this._scrollView.setContentSize(cc.size((btnSize.width + 2) * len, 30));

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.addTouchUpInsideAction(this._closeDialogAnimation, this);
        closeBtn.setPosition(440 + JSScreenBonusHalfWidth, 272 + JSScreenBonusHalfHeight);
        aniLayer.addChild(closeBtn);

        // 預設Tab 之前要先跑Dialog 讓位置對好
        this._tabClicked(this._tabButton[0]);

        // 註冊
        GS.addListener("NotifyShopBuyClose", this.notifyShopBuyClose.bind(this), this);
    },

    /**
     * 按鈕
     */
    // 按到Tab
    _tabClicked: function (sender) {
        var pageArray = this._pageArray;
        var senderType = sender.type;

        var clickedPos = 0;
        for (var i = 0; i < this._tabButton.length; i++) {
            if (sender == this._tabButton[i]) {
                clickedPos = i;
            }
            this._tabButton[i].setEnabled(true);

            // 把其他頁面關掉
            var page = pageArray[i];
            page && page.setVisible(false);
        }
        sender.setEnabled(false);

        if (!pageArray[clickedPos]) {
            // 創分頁

            //創分頁
            if (senderType === ShopType.SHARD) {
                // 碎片頁面跟其他的不一樣
                var page = pageArray[clickedPos] = new BackpackPageShardLayer();
                page.setPosition(135 + JSScreenBonusHalfWidth, 38 + JSScreenBonusHalfHeight);
            } else {
                var page = pageArray[clickedPos] = new BackpackBasePageViewLayer(senderType);
            }
            this._animationNode.addChild(page, 2);
        }

        // 重新更新Socket
        if (pageArray[clickedPos] && senderType !== ShopType.SHARD) {
            pageArray[clickedPos].refreshItemCheckStatus();
            // 刷新裡面物品使用狀態
            pageArray[clickedPos].sendSocketCommand();
        }

        pageArray[clickedPos].setVisible(true);
    },

    /**
     * 通知
     */
    // 在遊戲裡收到 要連自己也要關掉
    notifyShopBuyClose: function (event) {
        var forceClose = event.getUserData();
        if (PushScene.isGame || forceClose) {
            this._closeDialogAnimation();
        }
    }
});