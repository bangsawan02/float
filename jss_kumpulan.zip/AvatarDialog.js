/**
 * 有Avatar的Dialog
 obj = {
        key: ""                         //Dialog名稱
        loadFileArray: ["xxx.plist", "xxx.png"],    // 需要讀取的素材
        title: "",                      //標題
        content: "",                    //內文
        buttons: ["title"],             //按鈕的文字
        btnFontColors: [cc.color],      //按鈕的文字顏色
        buttonHints: [""],              //有的話 按鈕的文字要往上一點
        btnImages: [],                  //按鈕背景圖片
        btnIcons: [],                   //按鈕文字旁的icon
        btnIconScales: [],              //按鈕文字旁的icon縮放大小
        callback: cb,                   //Callback
        subTitle: "",                   //副標
        contentLeft : "0",              //內文置左 (給條列式訊息使用,預設置中)
        tip: "",                        //最下方的小提示
        avatarPic: "",                  //取代Avatar照片
        closeButton: 1,                 //是否要右上角X按鈕
        linePoxY: "",                   //標題下方分隔線高度
        needKeyBack: true,              //是否需要key back吃到btn的callback
    }

 按鈕顯示由左至右
 *
 */

var AvatarDialog = BaseDialogLayer.extend({
    ctor: function (obj) {
        this._super();

        this.obj = obj;

        // 需要讀取的素材
        this.loadFileArray = obj.loadFileArray || [];
    },

    onExit: function () {
        if (this._loadFileDone && this.loadFileArray.length) {
            for (let i = 0, len = this.loadFileArray.length; i < len; i += 2) {
                cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[i]);
            }
        }

        this._super();
    },

    /**
     * 讀取素材完畢
     * @override
     */
    loadFileDone: function () {
        this._super();

        if (this.loadFileArray.length) {
            for (var i = 0; i < this.loadFileArray.length; i += 2) {
                cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[i], this.loadFileArray[i + 1]);
            }
        }

        // 預設值
        var obj = this.obj;
        this.key = obj.key || "";
        obj.contentLeft = obj.contentLeft ? 1 : 0;
        obj.buttons = obj.buttons ? obj.buttons : [LocalizedString.Common("確定")];
        obj.btnFontColors = obj.btnFontColors || [];
        obj.buttonHints = obj.buttonHints || [];
        obj.btnImages = obj.btnImages || [];
        obj.btnIcons = obj.btnIcons || [];
        obj.btnIconScales = obj.btnIconScales || [];
        obj.closeButton = obj.closeButton === undefined ? 1 : obj.closeButton;
        obj.needKeyBack = obj.needKeyBack || false;
        obj.bgSize = obj.bgSize || cc.size(JSIsPortrait ? 270 : 377, 224);

        var aniLayer = this._animationLayer;

        // 背景底
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(obj.bgSize);
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite, -1);

        var lightSprite = new cc.Sprite("#lobby_pic_pink_light.png");
        lightSprite.setScale(100, 50);
        lightSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(lightSprite, -1);

        // Avatar
        var avatarNode = null;
        if (GS.useSpineAvatar && !obj.avatarPic) {
            var spineArray = [
                SelectGameManager.getNowGameFile("avatar_domino_half.json"),
                SelectGameManager.getNowGameFile("avatar_domino_half.atlas"),
                SelectGameManager.getNowGameFile("avatar_domino_half.png")
            ];
            avatarNode = new cc.Node();
            avatarNode.setScale(GS.isLuxyPoker ? 0.9 : 1);
            avatarNode.setPosition(JSScreenMidPos.x - 106, JSScreenMidPos.y - (GS.isLuxyPoker ? 4 : 114));
            aniLayer.addChild(avatarNode);
            var addSpineAvatar = function () {
                var avatar = new sp.SkeletonAnimation(spineArray[0], spineArray[1], 0.25);
                avatar.setAnimation(0, 'animation', true);
                avatarNode.addChild(avatar);
            };
            if (!cc.sys.isNative) {
                // H5要先去讀
                cc.loader.load(spineArray, function (a, b) {
                    addSpineAvatar();
                });
            } else {
                // 原生不用讀
                addSpineAvatar();
            }
        } else {
            if (obj.avatarPic) {
                avatarNode = new cc.Sprite(obj.avatarPic);
            } else {
                // 5.5.8改看板娘有額外調整(之後如果要改回原版看板娘要再調整回去)
                avatarNode = new cc.Sprite(SelectGameManager.getNowGameFile("common_avatar.png"));

                // 直式稍微縮小一點
                var scale = JSIsPortrait ? 0.9 : 1;

                // 單一版的avatar比較大
                avatarNode.setScale(scale * (GS.isLuxyPoker ? 0.5 : 0.7));
            }
            avatarNode.setAnchorPoint(JSAnchorPoint.M_BOTTOM);
            avatarNode.setPosition(JSScreenMidPos.x - (JSIsPortrait ? 95 : 120), JSScreenMidPos.y - 108);
            aniLayer.addChild(avatarNode, -1);
        }

        // 標題 圖或文
        var titleMidPosX = (JSIsPortrait) ? JSScreenMidPos.x + 20 : JSScreenMidPos.x + 58;
        var title = obj.title;
        if (title && title.length > 0) {
            var titleMessage;
            if (JSStringUtility.containString(title, ".png")) {
                // title 是圖
                titleMessage = new cc.Sprite(title);
            } else {
                // 文字
                titleMessage = new GSRichTextNode(title, JSFontBoldName, 19, cc.size(250, 30));
                titleMessage.setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                titleMessage.setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
            }
            titleMessage.setPosition(titleMidPosX, JSScreenMidPos.y + 74);
            aniLayer.addChild(titleMessage);

            // 分隔線
            var linePoxY = (obj.linePoxY) ? obj.linePoxY + JSScreenBonusHalfHeight : JSScreenMidPos.y + 45;
            var lineSprite = new cc.Sprite("#lobby_division_line.png");
            lineSprite.setScaleX(21);
            lineSprite.setPosition(titleMidPosX, linePoxY);
            aniLayer.addChild(lineSprite);
        }

        if (obj.subTitle) {
            // 有副標
            var subTitle = new GSRichTextNode(obj.subTitle, JSFontBoldName, 11);
            subTitle.setPosition(JSScreenMidPos.x + 48, JSScreenMidPos.y + 56);
            aniLayer.addChild(subTitle);
        }

        // 內文
        var messageLabel = this.messageLabel = new GSRichTextNode(obj.content, JSFontBoldName, 13, cc.size(JSIsPortrait ? 168 : 210, 0));
        messageLabel.setTextHorizontalAlignment(obj.contentLeft ? cc.TEXT_ALIGNMENT_LEFT : cc.TEXT_ALIGNMENT_CENTER);
        messageLabel.setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        messageLabel.setPosition((JSIsPortrait) ? JSScreenMidPos.x + 40 : titleMidPosX, JSScreenMidPos.y - 4);
        aniLayer.addChild(messageLabel);

        // 按鈕
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        aniLayer.addChild(menu);

        var basePos = cc.p(titleMidPosX, JSScreenMidPos.y - 72);
        var btnLen = obj.buttons.length;
        var btnSize = cc.size(btnLen === 3 ? 80 : 100, 30);
        var tx = basePos.x;
        var ty = basePos.y;
        var paddingX = 11;

        // 一個按鈕置中 其它要往左邊對齊
        if (btnLen === 2) {
            tx -= (btnSize.width + paddingX) / 2;
        } else if (btnLen === 3) {
            tx -= (btnSize.width + paddingX);
        }

        this._buttons = [];
        obj.buttons.forEach((cur, index) => {
            var btnImage = obj.btnImages[index] || "lobby_btn_01.png";
            var btnFontColor = obj.btnFontColors[index] || JSColor.BLACK;
            var btnIcon = obj.btnIcons[index];
            var btnIconScale = obj.btnIconScales[index];
            var btnItem = ButtonUtility.createSingleScale9NodesWithIcon(btnImage, btnSize, btnIcon, btnIconScale, cur, 12, btnFontColor, 2);
            btnItem[1].label.setOpacity(150);
            btnItem[2].setOpacity(255);
            btnItem[2].setColor(JSColor.GRAY);
            var btn = new cc.MenuItemSprite(btnItem[0], btnItem[1], btnItem[2], this._buttonClicked, this);
            btn.setPosition(tx, ty);
            menu.addChild(btn);
            this._buttons.push(btn);

            // 判斷是否有提示文字
            var hint = obj.buttonHints[index];
            if (hint) {
                // 文字要往上一些
                btnItem.forEach((btn) => {
                    var label = btn.label;
                    label.setPositionY(label.getPositionY() + 6);

                    // 加提示文字
                    var hintLabel = new cc.LabelTTF(hint, JSFontBoldName, 10);
                    hintLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                    hintLabel.setFontFillColor(JSColor.BLACK);
                    hintLabel.setPosition(cc.pAdd(label.getPosition(), cc.p(0, -12)));
                    btn.addChild(hintLabel);
                });
            }

            tx += btn.getContentSize().width + paddingX;
        });

        if (obj.tip) {
            // 有最下方的小提示
            var tip = new GSRichTextNode(obj.tip, JSFontBoldName, 10);
            tip.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 101);
            aniLayer.addChild(tip);

            if (obj.tipBackground) {
                var tipBackground = new ccui.Scale9Sprite("bg_shadow_02.png");
                tipBackground.setPreferredSize(cc.size(tip.getContentSize().width + 10, tip.getContentSize().height));
                tipBackground.setPosition(tip.getPosition());
                tipBackground.setOpacity(128);
                aniLayer.addChild(tipBackground, -1);
            }
        }

        this._callback = obj.callback;

        // 離開按鈕
        if (obj.closeButton) {
            var closeBtn = new Texas_CloseButton();
            closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
            closeBtn.setPosition(JSScreenMidPos.x + obj.bgSize.width / 2 - 10, JSScreenMidPos.y + 105);
            aniLayer.addChild(closeBtn);
        }
    },

    getAnimNode: function () {
        return this._animationLayer;
    },

    keyBackPressed: function () {
        if (!this.obj.needKeyBack)
            this._super();
        else {
            this._closeBtnClicked();
        }
    },

    /**
     * 按鈕
     */
    // 關掉畫面
    _closeBtnClicked: function () {
        if (this._callback)
            this._callback(-1);

        this._closeDialogAnimation();
    },

    _buttonClicked: function (sender) {
        var index = 0;
        for (var i = 0; i < this._buttons.length; i++) {
            if (this._buttons[i] === sender) {
                index = i;
                break;
            }
        }

        if (this._callback)
            this._callback(index);

        this._closeDialogAnimation();
    }
});