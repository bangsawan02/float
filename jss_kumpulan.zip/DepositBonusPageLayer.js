/**
 * v5.6.6 滿額贈模組化
 * create by tony.cheng
 */
var DepositBonusPageLayer = PurchaseTriggerIntegrationPageLayer.extend({
    ctor: function (dialog) {
        this._super(dialog);

        this.key = "DepositBonusPageLayer";
        this.type = PurchaseTriggerIntegrationData.purchaseType.DEPOSIT_BONUS;
    },

    canExit: function () {
        // 不在儲值中心才可以跳 promotion dialog
        if (!PushScene.checkNowLayer(PurchaseLayer)) {
            // 埋點 4715 看到挽留 dialog
            this._sendUserAnalyticsTrack(4715);

            // 跳Dialog
            this.showDialog(new Dialog({
                content: LocalizedString.Purchase("儲值中心有更多超值活動方案，走過路過不錯過！"),
                buttons: [LocalizedString.Purchase("前往")],
                btnFontColors: [JSColor.BLACK],
                callback: (index) => {
                    // 關掉畫面 (要先關 不然會被因為沒顯示導致關不掉)
                    this.closeDialogAnimation();
                    if (index === 0) {
                        // 埋點 4716 點擊滿額贈挽留 dialog 前往
                        this._sendUserAnalyticsTrack(4716);

                        // 導儲值中心
                        PushScene.pushLayer(new PurchaseLayer());
                    }
                }
            }));
            return false;
        }
        // 不要讓爸爸直接關掉
        return true;
    },

    loadFileDone: function () {
        this._super();

        // 先加 loading
        this.setLoadingSprite(true, true);

        // 埋點 4713 進入滿額贈人數
        this._sendUserAnalyticsTrack(4713);

        // 放內容的node
        let contentNode = this._contentNode = new cc.Node();
        this.addChild(contentNode);

        // 註冊通知
        GS.addListener("NotifyDepositBonusInfoDone", this.notifyDepositBonusInfoDone.bind(this), this);

        // 要資料
        DataProcess.sendString("deposit_bonus_info");
    },

    /**
     * 重刷畫面
     */
    _refreshView: function () {
        // 檢查活動有沒有開
        let param = this._param = DataModal.purchaseTriggerIntegrationData.depositBonusInfo;
        if (!param || !param.isOpen) {
            // this.showEventEndDialog();
            return;
        }

        // 位置 要偏右一點
        let basePosition = this._basePosition = cc.p(JSScreenBonusHalfWidth + 308.5, JSScreenMidPos.y);

        // 先砍掉所有東西
        let contentNode = this._contentNode;
        contentNode.removeAllChildren();

        let bgSize = cc.size(407.5, 288);
        let imageFolder = JSStringUtility.format("%sDepositBonus_Template/", JSWriteablePath);
        let imageSavePath = JSStringUtility.format("%s%s", imageFolder, param.banner_img);
        let imageUrl = GS.httpScheme + param.banner_url + param.banner_img;

        if (cc.sys.isNative) {
            // 判斷是否已有檔案，如果沒有代表要重新下載，先清掉舊圖片
            if (!jsb.fileUtils.isFileExist(imageSavePath)) {
                jsb.fileUtils.removeDirectory(imageFolder);
            }
        }

        // 判斷是圖片還是GAF
        if (imageUrl.indexOf(".zip") === imageUrl.length - 4) {
            // 卡loading
            this.setLoadingSprite(true, true);

            // 是GAF的檔案
            let fileName = imageUrl.split("/").pop();
            let fileNameNoExt = fileName.substring(0, fileName.indexOf(".zip"));

            let entryFile = JSStringUtility.format("%s/%s.gaf", fileNameNoExt, fileNameNoExt);
            gaf.createAndDownloadWithBundle(imageUrl, imageSavePath, entryFile, this, (gafAsset) => {
                // 假如此畫面不見 跳掉
                if (this.__isDestroyed)
                    return;

                if (gafAsset) {
                    let gafObject = gafAsset.createObjectAndRun(true);
                    // 因為美術設計尺寸是HD，但是我們的設計尺寸是SD所以要除2
                    let sceneSize = cc.size(gafAsset.getSceneWidth() / 2, gafAsset.getSceneHeight() / 2);
                    gafObject.setScaleX(bgSize.width / sceneSize.width);
                    gafObject.setScaleY(bgSize.height / sceneSize.height);
                    gafObject.setPosition(basePosition);
                    contentNode.addChild(gafObject, -1);

                    // 圖檔有正確載完才創完整內容
                    this._createWholeContent();
                }

                // 解掉loading
                this.setLoadingSprite(false, false);
            }, undefined);
        } else {
            // 卡loading
            this.setLoadingSprite(true, true);

            // 是圖片
            let bgSprite = new GSDownloadSprite("", imageUrl, imageSavePath, (msg) => {
                // 解掉loading
                this.setLoadingSprite(false, false);

                // 載圖有問題
                if (msg) {
                    this.showDialog(new Dialog({
                        content: LocalizedString.Common("系統忙碌中，請稍後再試！"),
                        callback: () => {
                            this.closeDialogAnimation();
                        }
                    }));
                } else {
                    // 圖檔有正確載完才創完整內容
                    this._createWholeContent();
                }
            }, true);
            bgSprite.setTargetSize(bgSize);
            bgSprite.setPosition(basePosition);
            contentNode.addChild(bgSprite);
        }
    },

    _createWholeContent: function () {
        let contentNode = this._contentNode;
        let basePosition = this._basePosition;
        let param = this._param;

        // 底部 前往購買按鈕
        let btnStyle = GS.isLuxyPoker ? Texas_Button.Style.ORANGE : Texas_Button.Style.GREEN;
        let goBtn = new Texas_Button(btnStyle, cc.size(90, 33), LocalizedString.Purchase("購買"));
        goBtn.addTouchUpInsideAction(this._goBtnClicked, this);
        goBtn.setPosition(basePosition.x, JSScreenBonusHalfHeight + 51);
        contentNode.addChild(goBtn);
        goBtn.runAction(Texas_AnimationUtility.buttonScaleAni().repeatForever());

        // 倒數
        let remainTimeLabel = new RemainTimeLabel(RemainTimeLabel.Style.WHITE);
        remainTimeLabel.setPosition(basePosition.x, JSScreenBonusHalfHeight + 26);
        remainTimeLabel.enableBg();
        contentNode.addChild(remainTimeLabel);

        // 開始倒數
        remainTimeLabel.countdownSeconds(JSCodeUtility.getRemainTimeByParam(param), () => {
            // 重要資料
            DataProcess.sendString("deposit_bonus_info");

            // 卡loading
            this.setLoadingSprite(true, true);
        });
    },

    _goBtnClicked: function () {
        // 埋點 4714 點擊馬上去
        this._sendUserAnalyticsTrack(4714);

        if (!PushScene.checkNowLayer(PurchaseLayer))
            PushScene.pushLayer(new PurchaseLayer());
        else
            this.closeDialogAnimation();
    },

    /**
     * 埋點
     */
    _sendUserAnalyticsTrack: function (track) {
        let data = DataModal.purchaseTriggerIntegrationData.depositBonusInfo;
        if (data && data.cluster)
            TexasUtility.sendUserAnalyticsTrack(track, data.cluster);
    },

    notifyDepositBonusInfoDone: function () {
        this._refreshView();
    },

    createDebugTestObject: function () {
        return new TestMenuDebugObject("滿額贈模組化", {
            "info": () => DataProcess.sendCustomStringToSelf('deposit_bonus_info {"banner_img":"5-1_ios.jpg","cluster":"5","error":"0","banner_url":"//d.mwsrv.com/19_60/store/ID_moneybanner/banner/KL/2/","template":"2","remain":"1537464"}'),
            "10s": () => DataProcess.sendCustomStringToSelf('deposit_bonus_info {"banner_img":"5-1_ios.jpg","cluster":"5","error":"0","banner_url":"//d.mwsrv.com/19_60/store/ID_moneybanner/banner/KL/2/","template":"2","remain":"10"}'),
            "event end": () => DataProcess.sendCustomStringToSelf('deposit_bonus_info {"error":"1"}')
        });
    },
});