/**
 * v5.7.0 激爆彈珠台 共用 dialog
 *
 * @param {object} param
 * @param {string} param.title
 * @param {string} param.content
 * @param {Array} param.buttonList
 * @param {Function} param.closeCallback
 * @param {boolean} param.isReconnected
 * @param {boolean} param.isLockBackKey
 */
var BlastPinballCommonDialog = BaseDialogLayer.extend({
    ctor: function (param = {}) {
        this._super();

        let title = param.title || "";
        let content = param.content || "";
        let btnList = param.buttonList || [];
        let isReconnected = param.isReconnected;

        this.isLockBackKey = param.isLockBackKey;

        this.setCloseCallback(param.closeCallback);

        let aniLayer = this._animationLayer;

        let bgSprite = new ccui.Scale9Sprite("blastPinball_pic_Dialog-1.png");
        bgSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 6);
        bgSprite.setPreferredSize(cc.size(235, 162));
        aniLayer.addChild(bgSprite);

        let contentBgSprite = new ccui.Scale9Sprite("blastPinball_pic_Dialog-2.png");
        contentBgSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 14);
        contentBgSprite.setPreferredSize(cc.size(208, 70));
        aniLayer.addChild(contentBgSprite);

        let titleLabel = new GSRichTextNode("", JSFontName, 15);
        titleLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 65);
        titleLabel.setDefaultTextColor(cc.color(94, 9, 0));
        titleLabel.setText(title, JSFontName, 15);
        aniLayer.addChild(titleLabel);

        let contentLabel = new GSRichTextNode(content, JSFontName, 12);
        contentLabel.setPosition(contentBgSprite.getPosition());
        contentLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        aniLayer.addChild(contentLabel);

        if (isReconnected) {
            let reconnectLabel = new cc.LabelTTF(LocalizedString.BlastPinballString("因連線不穩定，獎勵已發送囉"), JSFontName, 10);
            reconnectLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 30);
            reconnectLabel.setFontFillColor(cc.color(128, 53, 7));
            aniLayer.addChild(reconnectLabel);
        }

        let btnAutoLayout = new GSAutoLayoutNode();
        btnAutoLayout.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 53);
        aniLayer.addChild(btnAutoLayout);

        if (btnList.length === 0) {
            let button = new Texas_Button(Texas_Button.Style.GREEN, cc.size(85, 30), "OK");
            button.addTouchUpInsideAction(() => this.closeDialogAnimation(), this);
            btnAutoLayout.addChild(button);
        } else {
            btnList.forEach((btnCtor) => {
                btnAutoLayout.addChild(btnCtor(this));
            });
        }
    }
});