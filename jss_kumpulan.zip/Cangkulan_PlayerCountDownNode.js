/**
 * Cangkulan倒數的畫面
 */

var Cangkulan_PlayerCountDownNode = cc.Node.extend({

    ctor: function (callback) {
        this._super();

        this._callback = callback;
        this._greenColor = cc.color(0, 255, 0);

        var timer = this._timer = new Cangkulan_PlayerProgressTimer(new cc.Sprite("#game_pic_circle.png"));
        timer.setPercentage(100);
        timer.setReverseDirection(true);
        timer.setColor(this._greenColor);
        this.addChild(timer);

        // 中間的顯示
        var midTimer = this._midTimer = new cc.ProgressTimer(new cc.Sprite("#lobby_photo_clip.png"));
        midTimer.setPercentage(100);
        midTimer.setReverseDirection(true);
        midTimer.setColor(cc.color(JSColor.BLACK));
        midTimer.setOpacity(100);
        midTimer.setType(cc.ProgressTimer.TYPE_RADIAL);
        this.addChild(midTimer);

        // 中間的數字
        var numberLayout = this._numberLayout = new GSAutoLayoutNode();
        numberLayout.setScale(1.2);
        numberLayout.setSpace(-8);
        this.addChild(numberLayout);
    },

    start: function (sec, isSelf) {
        this.setVisible(true);

        // 先把現在時間記下來
        this._maxTime = sec;

        var timer = this._timer;
        var midTimer = this._midTimer;

        timer.setColor(this._greenColor);
        timer.setPercentage(100);
        midTimer.setPercentage(100);

        // progress動作
        timer.stopAllActions();
        timer.runAction(cc.sequence(
            cc.progressFromTo(sec, 100, 0),
            cc.callFunc(function () {
                this.stop();
            }, this)
        ));

        midTimer.stopAllActions();
        midTimer.runAction(cc.progressFromTo(sec, 100, 0));

        // 中間的Timer要變化數字
        midTimer.runAction(cc.repeatForever(cc.sequence(
            cc.delayTime(0.5),
            cc.callFunc(this._updateMidNumber, this)
        )));
        this._updateMidNumber();

        // 是自己 要加倒數秒小於3秒提示音效
        if (isSelf) {
            var nowSec;
            var callFunc = cc.callFunc(function () {
                if (typeof nowSec === 'undefined')
                    nowSec = sec;

                nowSec--;

                if (nowSec < 0)
                    this._timer.stopAction(callFunc);
                else if (nowSec === 2)
                    // 通知搖晃手牌
                    GS.dispatchCustomEvent("NotifyGameShakeCard");
                else if (nowSec < 3) {
                    MusicUtility.playEffect("Music/Effect/clockhurry.mp3");

                    // 判斷是否要震動
                    if (DataModal.settingData.cangkulan.vibrateBefore3Sec && cc.sys.isNative) {
                        cc.Device.vibrate(0.2);
                    }
                }

            }, this);

            this._timer.runAction(cc.repeatForever(cc.sequence(callFunc, cc.delayTime(1))));
        }
    },

    /**
     * 轉位完要重設，不然畫面會怪怪的
     */
    reset: function () {
        this.setVisible(false);
        this._timer.removeFromParent();

        var timer = this._timer = new Cangkulan_PlayerProgressTimer(new cc.Sprite("#game_pic_circle.png"));
        timer.setPercentage(100);
        timer.setReverseDirection(true);
        timer.setColor(this._greenColor);
        this.addChild(timer);
    },

    stop: function () {
        this.setVisible(false);

        this._timer.stopAllActions();
        this._midTimer.stopAllActions();
        this._numberLayout.removeAllChildren();

        if (this._callback) {
            this._callback();
        }
    },

    /**
     * 更新中間倒數的數字
     */
    _updateMidNumber: function () {
        var numberLayout = this._numberLayout;
        numberLayout.removeAllChildren();

        var nowNumber = Math.ceil(this._maxTime * this._midTimer.getPercentage() / 100);
        var numberString = nowNumber.toString();
        for (var i = 0, len = numberString.length; i < len; i++) {
            var numberSprite = new cc.Sprite(JSStringUtility.format("#game_number_elec_%s.png", numberString[i]));
            numberLayout.addChild(numberSprite);
        }
    },
});

var Cangkulan_PlayerProgressTimer = cc.ProgressTimer.extend({
    ctor: function (sprite) {
        this._super(sprite);

        this._colors = [
            cc.color(0, 255, 0),
            cc.color(0, 246, 81),
            cc.color(0, 255, 0),
            cc.color(194, 223, 43),
            cc.color(223, 213, 20),
            cc.color(255, 203, 1),
            cc.color(246, 171, 0),
            cc.color(239, 137, 1),
            cc.color(231, 103, 3),
            cc.color(222, 67, 1),
            cc.color(212, 35, 1),
            cc.color(203, 0, 0)
        ];
        this._unit = 100 / (this._colors.length - 1);
        this._previousColor = cc.color(0, 0, 0);
        this._len = this._colors.length;
    },

    setPercentage: function (percentage) {
        if (this._colors) {
            var index = Math.floor(percentage / this._unit);
            var color = this._colors[this._len - index - 1];
            if (!cc.colorEqual(this._previousColor, color)) {
                this._previousColor = color;
                this.setColor(color);

                this.stopActionByTag(19830617);
                var act = cc.tintTo(0.2, color.r, color.g, color.b);
                act.setTag(19830617);
                this.runAction(act);
            }
        }
        cc.ProgressTimer.prototype.setPercentage.call(this, percentage);
    },
});