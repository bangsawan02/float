/**
 * v5.6.5 農場賓果 - 大廳Icon
 */

var FarmBingoLobbyIconNode = LobbyTimeIconNode.extend({
    ctor: function (isInVegasLobby) {
        this._super();

        this.key = "FarmBingoLobbyIconNode";

        this._isInVegasLobby = isInVegasLobby;

        GS.addListener("NotifyFarmBingoIconDone", this.notifyFarmBingoIconDone.bind(this), this);
        GS.addListener("NotifyFarmBingoIconRefresh", this.notifyFarmBingoIconRefresh.bind(this), this);
    },

    onEnterTransitionDidFinish: function () {
        this._super();

        // 先刷新一次
        // ctor要先隱藏 然後onEnter後才可以刷新顯示 不然parent不會refresh重排位置
        this._refreshView();
    },

    /**
     * 更新畫面
     */
    _refreshView: function () {
        let mainNode = this._mainNode;
        mainNode.removeAllChildren();

        // 抓資料
        let data = DataModal.farmBingoData;
        let iconParam = data.iconParam;
        if (!data.getEventIsOpen()) {
            this.setVisible(false);
            return;
        }

        // 設定看的到
        this.setVisible(true);

        // Icon圖片
        let iconSprite = new cc.Sprite("#lobby_icon_farm_pass.png");
        mainNode.addChild(iconSprite);

        // 小紅點
        if (data.shouldShowBadge()) {
            let badgeNode = this._badgeNode = new BadgeNode();
            badgeNode.setPosition(this._isInVegasLobby ? cc.p(15, 15) : cc.p(18, 9));
            badgeNode.useDefaultStyle();
            badgeNode.setVisible(true);
            mainNode.addChild(badgeNode);
        }

        let remainTime = JSCodeUtility.getRemainTime(iconParam.remainTime, iconParam.socketTime);
        this.createTimeLabelWithBackground(remainTime, () => {
            // 倒數時間結束，先隱藏
            this.setVisible(false);
            DataModal.farmBingoData.startGetIconInfo();
        });

        // 主動跳
        if (iconParam.pop) {
            // 跳dialog
            this._iconClicked();
            iconParam.pop = false;
        }
    },

    addBackground: function () {
        if (this._isInVegasLobby) {
            this.addVipSlotLobbyBackground();
        } else {
            this._super();
        }
    },

    /**
     * 按鈕
     */
    _iconClicked: function (sender) {
        if (this._isInVegasLobby) {
            // 埋點 5089：>=5.6.8 點擊副系統區塊任一ICON
            TexasUtility.sendUserAnalyticsTrack(5089);

            // 埋點 5092：>=5.6.8 點擊農場賓果
            TexasUtility.sendUserAnalyticsTrack(5092);
        }

        // 跳Dialog
        if (!DialogManager.isExist("FarmBingoDialog")) {
            let dialog = new FarmBingoDialog();
            DialogManager.addDialog(dialog, true, true);
        }
    },

    /**
     * icon 刷新
     */
    notifyFarmBingoIconRefresh: function () {
        this._refreshView();
    },

    /**
     * 收到 icon 資料
     */
    notifyFarmBingoIconDone: function () {
        this._refreshView();
    },
});