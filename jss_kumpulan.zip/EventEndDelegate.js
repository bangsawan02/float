/**
 * 活動結束流程代理
 *
 * @example 套用範例
 * var Node = cc.Node.extend({
 *     ctor: function() {
 *         this._super();
 *         EventEndDelegate.delegate(this);
 *     },
 * });
 *
 * 運作方式：
 * 這裡使用 Semaphore（maxCount = 1）來控制活動結束的流程。
 *
 * 當有人呼叫上鎖時，若目前沒有其他人，會直接執行 lock 後方的 then function
 * 若有其他人正在執行且尚未 unlock 時，會排隊等待。
 *
 * 當呼叫 emitEventEnd 後，後續的 lock 都不再有效。
 *
 * 詳細的 Semaphore 運作方式可以參考 Semaphore.js 內的說明
 *
 * @author kai.wu
 */
class EventEndDelegate {
    constructor() {
        // 是否多個活動共用（儲值整合視窗）
        this._isShared = false;
        this._semaphore = new Semaphore(1);
    }

    set isShared(isShared) {
        this._isShared = isShared;
    }

    /**
     * 鎖住活動結束
     *
     * @example
     * this.eventEndDelegate.lockEventEnd().then((key) => {
     *     // key 是解鎖時必須的 random string，請妥善保存
     * });
     *
     * @returns {Promise<String>}
     */
    lock() {
        return this._semaphore?.acquire() ??
            Promise.reject(JSDebugMode ? "<EventEndDelegate> 已清除後仍呼叫 lock" : null);
    }

    /**
     * 解鎖活動結束
     * @param {String} key
     * @return {void}
     */
    unlock(key) {
        this._semaphore?.release(key);
    }

    /**
     * 取得排隊長度
     * @returns {Number}
     */
    getLength() {
        return this._semaphore?.getLength() ?? 0;
    }

    /**
     * 告知活動結束
     */
    emitEventEnd() {
        return this._semaphore?.acquire()
            .then(() => {
                // 拒絕後面的所有人
                JSDebugMode && cc.log("<EventEndDelegate> 活動結束");

                if (this._isShared) {
                    // 會共用，僅清除
                    this._semaphore?.clear();
                } else {
                    // 非共用，清除後不允許再使用 lock
                    this.destroy();
                }

                return Promise.resolve();
            }) ?? Promise.reject(JSDebugMode ? "<EventEndDelegate> 已清除後仍呼叫 emitEventEnd" : null);
    }

    destroy() {
        this._semaphore?.clear();
        this._semaphore = null;
    }

    /**
     * 套用
     * @param {Object} target
     */
    static delegate(target) {
        if (target.eventEndDelegate) {
            // 已經套用過了
            return;
        }

        let onExitPtr = target.onExit;

        // Add delegate methods
        target.eventEndDelegate = new EventEndDelegate();
        target.eventEndDelegate._semaphore.bind2Node(target, "eventEndSemaphore");

        // Clear semaphore when exit
        target.onExit = () => {
            target.eventEndDelegate.destroy();
            onExitPtr?.call(target);
        };
    }
}