var LocalizedString = LocalizedString || {};

(function () {
    let keyValue = {
        "免費": "GRATIS",
        "領取優惠立即解鎖": "Ambil ini dulu",
        "儲值成功！恭喜獲得": "Top-up berhasil! Dapat",
        "恭喜獲得": "Selamat dapat",
        "已領取本期所有獎勵！感謝參與！": "Semua hadiah sudah diambil, terima kasih!",
        "(活動已完成，頁面將消失)": "(event akan ditutup)",
    };
    LocalizedString.ContinueRechargeV3 = function (str) {
        return USE_i18n ? (keyValue[str] || str) : str;
    };
})();
