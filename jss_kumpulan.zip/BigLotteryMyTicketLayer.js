/**
 * 9T 幸運彩票 - 我的彩券 頁面
 */

var BigLotteryMyTicketLayer = BigLotteryBaseLayer.extend({
    ctor: function () {
        this._super();

        this.pageType = BigLotteryLayer.PageType.MY_TICKET_PAGE;
        this._totalCellCount = 1;
        var bigLotteryStr = LocalizedString.BigLottery;

        // 主要畫面
        {
            var mainNode = this._mainNode;

            // Domino移植設定 略縮tableView寬度
            // TableView
            var tableViewSize = cc.size(418, 210 + JSScreenBonusHeight);
            var mainLayer = this._mainLayer = new cc.Layer();
            var tableView = this._tableView = new cc.TableView(this, tableViewSize, mainLayer);
            tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
            tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
            tableView.setDelegate(this);
            tableView.setPositionX(94 + JSScreenBonusHalfWidth);
            mainNode.addChild(tableView, 1);
        }

        // 沒有彩票
        {
            var noTicketNode = this._noTicketNode = new cc.Node();
            this.addChild(noTicketNode);

            // Domino移植設定 調整文字描邊/文案
            // 提示文字
            var hintLabel = new cc.LabelTTF(bigLotteryStr("您目前沒有任何票卷唷~\n趕快購買彩票，拚頭獎!"), JSFontName, 14);
            hintLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            hintLabel.enableStroke(cc.color(190, 30, 0, 255), 2);
            hintLabel.setPosition(JSScreenMidPos.x, 140 + JSScreenBonusHalfHeight);
            noTicketNode.addChild(hintLabel);

            // Domino移植設定 調整圖檔/位移
            // 錢幣堆
            var coinSprite = new cc.Sprite("#bigLottery_pic_money.png");
            coinSprite.setPosition(464 + JSScreenBonusHalfWidth, 86);
            noTicketNode.addChild(coinSprite);

            // 按鈕
            var menu = new cc.Menu();
            menu.setPosition(0, 0);
            noTicketNode.addChild(menu);

            // 前往購買按鈕
            var itemNode = ButtonUtility.createArrayScale9Nodes(["lobby_btn_03.png", "lobby_btn_03.png", "lobby_btn_06.png"], cc.size(85, 35), bigLotteryStr("前往購買"), 14);
            itemNode.forEach((cur, index) => {
                var fontStrokeColor = (index === 2) ? TexasUtility.OutlineColor.GRAY : TexasUtility.OutlineColor.BLUE;
                cur.label.enableStroke(fontStrokeColor, 2);
            });
            itemNode[2].setOpacity(255);
            var goPurchaseBtn = this._goPurchaseBtn = new cc.MenuItemSprite(itemNode[0], itemNode[1], itemNode[2], this._goPurchaseClicked, this);
            goPurchaseBtn.setPosition(JSScreenMidPos.x, 69 + JSScreenBonusHalfHeight);
            menu.addChild(goPurchaseBtn);
        }

        // 倒數的node
        var clockNode = new BigLotteryClockNode();
        clockNode.setScale(0.75);
        clockNode.setPosition(462 + JSScreenBonusHalfWidth, JSVisibleSize.height - 28);
        this.addChild(clockNode);

        // 註冊
        GS.addListener("NotifyBigLotteryMyTicketInfoDone", this.notifyBigLotteryMyTicketInfoDone.bind(this), this);
    },

    /**
     * override
     */
    _enterPage: function () {
        var bigLotteryData = DataModal.bigLotteryData;

        // 有資料了直接重刷
        if (bigLotteryData.myTicketParam) {
            this._refreshView();
        } else {
            // 初始化狀態
            this._loadingSprite.start();
            this._mainNode.setVisible(false);
            this._noTicketNode.setVisible(false);

            // 要資料
            DataProcess.sendString("big_lottery_my_ticket");
        }
    },


    /**
     * 更新畫面
     */
    _refreshView: function () {
        // remove loading
        this._loadingSprite.stop();

        var mainNode = this._mainNode;
        var noTicketNode = this._noTicketNode;
        var mainLayer = this._mainLayer;

        // 抓資料
        var bigLotteryData = DataModal.bigLotteryData;
        var myTicketParam = bigLotteryData.myTicketParam;
        if (myTicketParam) {
            var ticketList = this._ticketList = myTicketParam.ticketList;

            var isOnlyFirstCell = this._isOnlyFirstCell = false;

            // 沒買票
            if (myTicketParam.totalTicketNum === 0) {
                // 顯示沒買票的node
                mainNode.setVisible(false);
                noTicketNode.setVisible(true);

                this._totalCellCount = 0;

                // Domino移植設定 引導主頁
                // 判斷可不可以購買,可以開啟引導至主頁按鈕
                this._goPurchaseBtn.setEnabled(bigLotteryData.status === BigLotteryData.Status.NORMAL);

            } else {
                isOnlyFirstCell = (myTicketParam.totalTicketNum === myTicketParam.notSelectTicketNum);

                var totalCellCount = this._totalCellCount = (isOnlyFirstCell) ? 1 : ticketList.length + 1;

                // 顯示主畫面的node
                mainNode.setVisible(true);
                noTicketNode.setVisible(false);

                // 先清掉所有東西
                mainLayer.removeAllChildren();

                // 算top Cell高度
                var topCellPosY = (isOnlyFirstCell) ? -134 : (totalCellCount - 1) * BigLotteryMyTicketCell.HEIGHT;

                var topCell = new BigLotteryMyTicketTopCell();
                topCell.refreshCell(isOnlyFirstCell);
                topCell.setPosition(0, topCellPosY);
                mainLayer.addChild(topCell);

                // 刷新table view
                this._tableView.reloadData(true);
            }
        }
    },

    /**
     * 按鈕
     */

    // 點擊前往購買按鈕
    _goPurchaseClicked: function () {
        MusicUtility.playEffect("Music/Effect/e_clickButton.mp3", false);

        // 通知要切到購買彩券頁面
        var page = BigLotteryLayer.PageType.MAIN_PAGE;
        GS.dispatchCustomEvent("NotifyBigLotteryChangePage", page);
    },

    /**
     * 通知
     */

    // 通知收到我的票券資料
    notifyBigLotteryMyTicketInfoDone: function () {
        this._refreshView();
    },

    /**
     * TableView delegate
     */
    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        if (cell == null) {
            cell = new BigLotteryMyTicketCell();
            cell.setAnchorPoint(0, 0);
        }

        // 第一個不顯示 是top node
        cell.setVisible(idx !== 0);

        if (idx > 0 && idx <= this._ticketList.length) {
            var param = this._ticketList[idx - 1];
            cell.refreshCell(param);
        }

        return cell;
    },

    numberOfCellsInTableView: function (table) {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function (table, idx) {
        if (this._isOnlyFirstCell)
            return cc.size(BigLotteryMyTicketCell.WIDTH, BigLotteryMyTicketTopCell.NO_TICKET_HEIGHT);
        else {
            if (idx === 0)
                return cc.size(BigLotteryMyTicketCell.WIDTH, BigLotteryMyTicketTopCell.HEIGHT);
            else
                return cc.size(BigLotteryMyTicketCell.WIDTH, BigLotteryMyTicketCell.HEIGHT);
        }
    }
});