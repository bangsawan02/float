/**
 * v5.4.4 Free Chip - 頁籤按鈕
 * created by lichieh on 2022/9/23
 */
var FreeChipTabButton = GSControlButton.extend({
    ctor: function (param) {
        var btnSize = this._btnSize = cc.size(78, 32);
        this._super(undefined, btnSize);

        this.page = param.page;
        this._changeColorWhenDisabled = false;

        var contentNode = this._contentNode;

        // 底
        var bgSprite = this._bgSprite = new ccui.Scale9Sprite("lobby_btn_tab_02.png");
        bgSprite.setPreferredSize(cc.size(btnSize.height, btnSize.width));
        bgSprite.setRotation(-90);
        contentNode.addChild(bgSprite);

        // 文字
        var titleLabel = new cc.LabelTTF(LocalizedString.FreeChip(param.title), JSFontBoldName, 12);
        titleLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        contentNode.addChild(titleLabel, 1);

        // 創小紅點
        var badge = this._badgeNode = new BadgeNode();
        badge.useDefaultStyle();
        badge.setPosition(-35, 11.5);
        badge.setVisible(false);
        contentNode.addChild(badge);
    },

    /**
     * 不能按的時候 要改變顏色
     */
    setEnabled: function (enable) {
        this._super(enable);

        // 把背景圖片換掉
        var bgSprite = this._bgSprite;
        if (enable) {
            bgSprite.setSpriteFrame("lobby_btn_tab_02.png");
        } else {
            bgSprite.setSpriteFrame("lobby_btn_tab_01.png");
        }
        var btnSize = this._btnSize;
        bgSprite.setPreferredSize(cc.size(btnSize.height, btnSize.width));
    },

    getIsBadgeVisible: function () {
        return this._badgeNode.isVisible();
    },

    /**
     * 更新小紅點
     */
    updateBadge: function (param) {
        var badgeNode = this._badgeNode;
        badgeNode.setVisible(false);
        if (!param || !param.koinLuxy || !param.chips)
            return;

        switch (this.page) {
            case FreeChipDialog.Page.PLAY:
                if (param.koinLuxy.playList && param.chips.playList) {
                    var isShowBadge = (param.koinLuxy.playList.findIndex(cur => cur.isBadgeVisible && cur.isOpen) !== -1)
                        || (param.chips.playList.findIndex(cur => cur.isBadgeVisible && cur.isOpen) !== -1);
                    badgeNode.setVisible(isShowBadge);
                }
                break;

            case FreeChipDialog.Page.LOGIN:
                if (param.koinLuxy.loginList && param.chips.loginList) {
                    var isShowBadge = (param.koinLuxy.loginList.findIndex(cur => cur.isBadgeVisible && cur.isOpen) !== -1)
                        || (param.chips.loginList.findIndex(cur => cur.isBadgeVisible && cur.isOpen) !== -1);
                    badgeNode.setVisible(isShowBadge);
                }
                break;

            case FreeChipDialog.Page.MISSION:
                if (param.koinLuxy.missionList && param.chips.missionList) {
                    var isShowBadge = (param.koinLuxy.missionList.findIndex(cur => cur.isBadgeVisible && cur.isOpen) !== -1)
                        || (param.chips.missionList.findIndex(cur => cur.isBadgeVisible && cur.isOpen) !== -1);
                    badgeNode.setVisible(isShowBadge);
                }
                break;

            case FreeChipDialog.Page.EVENT:
                if (param.koinLuxy.eventList && param.chips.eventList) {
                    var isShowBadge = (param.koinLuxy.eventList.findIndex(cur => cur.isBadgeVisible && cur.isOpen) !== -1)
                        || (param.chips.eventList.findIndex(cur => cur.isBadgeVisible && cur.isOpen) !== -1);
                    badgeNode.setVisible(isShowBadge);
                }
                break;

            case FreeChipDialog.Page.VIP:
                if (param.koinLuxy.vipList && param.chips.vipList) {
                    var isShowBadge = (param.koinLuxy.vipList.findIndex(cur => cur.isBadgeVisible && cur.isOpen) !== -1)
                        || (param.chips.vipList.findIndex(cur => cur.isBadgeVisible && cur.isOpen) !== -1);
                    badgeNode.setVisible(isShowBadge);
                }
                break;

            case FreeChipDialog.Page.CHANGE:
                if (param.koinLuxy.changeList && param.chips.changeList) {
                    var isShowBadge = (param.koinLuxy.changeList.findIndex(cur => cur.isBadgeVisible && cur.isOpen) !== -1)
                        || (param.chips.changeList.findIndex(cur => cur.isBadgeVisible && cur.isOpen) !== -1);
                    badgeNode.setVisible(isShowBadge);
                }
                break;
        }
    }
});