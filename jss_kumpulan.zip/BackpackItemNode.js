/**
 * v5.4.5 背包 - 背包的裡面的物品 / 桌內商城物品也是用同一個
 */
var BackpackItemNode = cc.Node.extend({
    ctor: function (shopObj, callback, context) {
        this._super();

        var shopString = LocalizedString.Shop;
        this._shopObj = shopObj;
        this._callback = callback;
        this._context = context;

        // 圖片尺寸 5.2.3版本跟pm確認其他欄位只有比賽券 因為比賽券是長方形 pm希望可以放大顯示 之後更新如果有其他東西放到其他欄位要請pm確認一下
        // 5.4.1 新增保護令 與pm確認後以wid做特別處理
        var imgSize = (shopObj.type === ShopType.OTHER) ? 72 : 42;
        if (shopObj.type === ShopType.FRAME) {
            //圖片
            var imageNode = new PlayerIdentityNode();
            imageNode.setIdentity(shopObj.serial);
            imageNode.setPosition(0, 16);
            this.addChild(imageNode);
        } else {
            //先加讀取
            var loadingSprite = new GSLoadingSprite();
            loadingSprite.setColor(JSColor.WHITE);
            loadingSprite.setPosition(0, 16);
            loadingSprite.setScale(0.6);
            loadingSprite.start();
            this.addChild(loadingSprite);

            // 加入其他物品，需要重製圖片大小
            switch (shopObj.wid) {
                case "3327":        //保護令
                    imgSize = 48;
                    break;
                default:
                    break;
            }

            // 圖片
            var imageNode = new AccessoryItemNode(shopObj.serial, imgSize, imgSize, function () {
                // 砍掉Loading
                if (loadingSprite) {
                    loadingSprite.removeFromParent();
                    loadingSprite = null;
                }
            });
            imageNode.setPosition(0, 16);
            this.addChild(imageNode);
        }

        // 商城標籤
        var promoteType = shopObj.promoteType;
        if (promoteType && promoteType.length) {
            var bgImage = "sticker_0.png";                          // 背景圖片文字
            var bgImagePos = cc.p(20, 40);                          // 背景圖片位置
            var labelColor = JSColor.WHITE;                         // 文字顏色
            var labelPos = cc.p(bgImagePos.x + 1, bgImagePos.y);    // 文字位置
            var promoteText;                                        // 文字訊息
            var capInsets = cc.rect(14, 8, 10, 4);
            var contentHeight = 21;
            switch (promoteType) {
                case "N1":
                    promoteText = "新品到";
                    break;
                case "N2":
                    promoteText = "新話題";
                    break;
                case "N3":
                    promoteText = "新上架";
                    break;
                case "D1":
                    promoteText = "優惠中";
                    break;
                case "D2":
                    promoteText = "特價中";
                    break;
                case "D3":
                    promoteText = "破盤價";
                    break;
                case "Q1":
                    promoteText = "限量版";
                    break;
                case "T1":
                    promoteText = "限時優惠";
                    bgImage = "sticker_T.png";
                    bgImagePos = cc.p(22, 40);
                    labelColor = cc.color(170, 0, 25);
                    labelPos = cc.p(bgImagePos.x + 1, bgImagePos.y + 5);
                    capInsets = cc.rect(28, 17, 5, 3);
                    contentHeight = 28;
                    break;
                case "T2":
                    promoteText = "期間限定";
                    break;
                case "T3":
                    promoteText = "限時銷售";
                    bgImage = "sticker_T.png";
                    bgImagePos = cc.p(22, 40);
                    labelColor = cc.color(170, 0, 25);
                    labelPos = cc.p(bgImagePos.x + 1, bgImagePos.y + 5);
                    capInsets = cc.rect(28, 17, 5, 3);
                    contentHeight = 28;
                    break;
                case "H1":
                    promoteText = "熱賣中";
                    labelColor = cc.color(255, 241, 80);
                    break;
                case "H2":
                    promoteText = "熱門商品";
                    labelColor = cc.color(255, 241, 80);
                    break;
            }

            var promoteLabel = new cc.LabelTTF(LocalizedString.Shop(promoteText), JSFontBoldName, 7);
            promoteLabel.setRotation(-5);
            promoteLabel.setPosition(labelPos);
            promoteLabel.setFontFillColor(labelColor);
            this.addChild(promoteLabel, 1);

            var labelWidth = promoteLabel.getContentSize().width + 17;

            var bgImageSprite = new ccui.Scale9Sprite(bgImage);
            bgImageSprite.setCapInsets(capInsets);
            bgImageSprite.setContentSize(cc.size(labelWidth, contentHeight));
            bgImageSprite.setPosition(bgImagePos);
            this.addChild(bgImageSprite);
        }

        // 下面文字
        var useRedColor = false;
        var moneyString;
        switch (shopObj.type) {
            case ShopType.BACKPACK:
            case ShopType.MEDAL:
            case ShopType.FRAME:
                var expireTime = shopObj.expire;
                if (expireTime === -1)
                    moneyString = shopString("永久");
                else {
                    var day = Math.floor(expireTime / 86400);
                    var hour = Math.floor((expireTime % 86400) / 3600);
                    var min = Math.floor((expireTime % 3600) / 60);
                    moneyString = JSStringUtility.format("%d%s%d%s%d%s",
                        day, shopString("天"),
                        hour, shopString("時"),
                        min, shopString("分")
                    );

                    if (day === 0)
                        useRedColor = true;
                }
                break;
            case ShopType.OTHER:
                // 有數量的話顯示有幾個
                var count = shopObj.count;
                if (count > 0)
                    moneyString = "×" + count;
                break;
            case ShopType.EMPTY:
                break;
            default:
                moneyString = "$" + JSCodeUtility.getCurrencyString(shopObj.money);
                break;
        }

        // 產品文字
        if (shopObj.type !== ShopType.EMPTY) {
            var fontSize = (shopObj.type === ShopType.OTHER) ? 12 : 8;
            var nameLabel = new GSAutoSizeLabel(shopObj.name, JSFontBoldName, fontSize, cc.size(70, 18), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
            nameLabel.resizeToFit(6);
            nameLabel.setPosition(0, -14);
            nameLabel.setFontFillColor(useRedColor ? JSColor.RED : JSColor.WHITE);
            this.addChild(nameLabel);
        }

        // 賣多少錢或還剩下多少天
        if (moneyString) {
            var moneyLabel = new GSAutoSizeLabel(moneyString, JSFontBoldName, 10, cc.size(70, 14), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
            moneyLabel.setPosition(0, -28);
            moneyLabel.setFontFillColor(useRedColor ? JSColor.RED : JSColor.WHITE);
            this.addChild(moneyLabel);
        }

        // 空白按鈕
        var btnSize = cc.size(60, 80);
        var itemNode = new ccui.Scale9Sprite();
        itemNode.setPreferredSize(btnSize);
        var button = new cc.ControlButton(itemNode);
        button.addTargetWithActionForControlEvents(this, this._itemClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        button.setAdjustBackgroundImage(false);
        button.setZoomOnTouchDown(false);
        button.setSwallowTouches(false);
        button.setTouchDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
        button.setPosition(0, 10);
        this.addChild(button);

        // 判斷是不是自己的物品
        this.checkItemNeededFrame();
    },

    /**
     * 判斷是否需要外框
     */
    checkItemNeededFrame: function () {
        var shopObj = this._shopObj;

        var profileData = DataModal.profileData;
        var nowItem;
        switch (shopObj.type) {
            case ShopType.BACKPACK:
                nowItem = profileData.accessory.code;
                break;

            case ShopType.MEDAL:
                nowItem = profileData.medal.code;
                break;

            case ShopType.FRAME:
                nowItem = profileData.vip.code;
                break;
        }

        if (shopObj.serial === nowItem) {
            // 要顯示外框
            if (!this._selectedFrame) {
                var frame = this._selectedFrame = new ccui.Scale9Sprite("shop_choose.png");
                frame.setPreferredSize(cc.size(72, 90));
                frame.setPosition(0, 3);
                this.addChild(this._selectedFrame);
            }
            this._selectedFrame.setVisible(true);
        } else {
            // 關掉外框
            this._selectedFrame && this._selectedFrame.setVisible(false);
        }
    },

    /**
     * 按到
     */
    _itemClicked: function () {
        this._callback && this._callback.call(this._context, this._shopObj);
    },
});