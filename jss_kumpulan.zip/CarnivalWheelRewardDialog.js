/**
 * 5.4.0 [儲值]轉輪大狂歡 - 領獎的Dialog
 *
 * created by Wen
 */

var CarnivalWheelRewardDialog = BaseDialogLayer.extend({
    /**
     * ```
     * param = {
     *     type:        Dialog 樣式
     *
     *     只有內文
     *     for type = CarnivalWheelRewardDialog.Type.MESSAGE
     *     message:     內文
     *
     *     領獎
     *     for type = CarnivalWheelRewardDialog.Type.GET_REWARD
     *     wheelStep:   第幾階段的轉輪,(1~3)
     *     getReward:   可領取獎勵值,(10000000)
     *     isPurchase:  是否是儲值
     *     isMaxReward: 是否是最大獎勵
     *
     *     儲值
     *     for type = CarnivalWheelRewardDialog.Type.PURCHASE
     *     getReward:   可領取獎勵值,(10000000)
     *     payMoney:    儲值金額,(10000000)
     *     isMaxReward: 是否是最大獎勵
     *
     *     共用
     *     callback:    () => {}
     * }
     * ```
     */
    ctor: function (param) {
        this._super();

        this.key = "CarnivalWheelRewardDialog";

        this._param = param;
        this._type = param.type ? param.type : CarnivalWheelRewardDialog.Type.MESSAGE;
    },

    /**
     * 讀取素材完畢
     * @override
     */
    loadFileDone: function () {
        this._super();

        // 根據 type 創建 ui
        if (this._type === CarnivalWheelRewardDialog.Type.MESSAGE)
            this._createMessageUI();
        else if (this._type === CarnivalWheelRewardDialog.Type.GET_REWARD)
            this._createGetRewardUI();
        else if (this._type === CarnivalWheelRewardDialog.Type.PURCHASE)
            this._createPurchaseUI();
    },

    /**
     * 純文字 ui
     */
    _createMessageUI: function () {
        let aniLayer = this._animationLayer;
        let param = this._param;

        // OK button
        let isLuxyPoker = GS.isLuxyPoker;

        // 背景
        let bgSprite = new ccui.Scale9Sprite("carnivalWheel_bg_frame_02.png");
        bgSprite.setPreferredSize(cc.size(245, 153));
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite);

        // 內文
        let messageLabel = new cc.LabelTTF(param.message, JSFontName, 13);
        messageLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 13);
        messageLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        messageLabel.setFontFillColor(JSColor.WHITE);
        aniLayer.addChild(messageLabel);

        // ok button
        let btnSize = cc.size(90, 35 + (isLuxyPoker ? 5 : 0));
        let okBtn = new Texas_Button(Texas_Button.Style.ORANGE, btnSize, "OK", {fontSize: 14});
        okBtn.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 45);
        okBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
        aniLayer.addChild(okBtn);
    },

    /**
     * 領獎 ui
     */
    _createGetRewardUI: function () {
        let aniLayer = this._animationLayer;
        let param = this._param;
        let isLuxyPoker = GS.isLuxyPoker;

        // 創一個 node 放噴金幣動畫
        let coinAniNode = new cc.Node();
        aniLayer.addChild(coinAniNode);
        // 創噴金幣動畫
        this._createCoinAnimation(coinAniNode);

        // 背景
        let bgSprite = new ccui.Scale9Sprite("carnivalWheel_bg_frame_02.png");
        bgSprite.setPreferredSize(cc.size(320, 198));
        bgSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 10);
        aniLayer.addChild(bgSprite);

        // 標題
        let titleSp = new cc.Sprite(param.isMaxReward ? "#carnivalWheel_w_superlucky.png" : "#carnivalWheel_w_congratulations.png");
        titleSp.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 83);
        aniLayer.addChild(titleSp);

        // 恭喜文字
        let congratsMsg = new GSRichTextNode(LocalizedString.PurchaseCoupon(param.isMaxReward ? "你轉中了最大獎" : "您獲得了"), JSFontName, 15);
        congratsMsg.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 41);
        aniLayer.addChild(congratsMsg);

        // 獎勵字
        {
            let rewardPosition = cc.p(JSScreenMidPos.x, JSScreenMidPos.y - 7.5);

            // 獎勵字黃色底
            let yellowBgSprite = new ccui.Scale9Sprite("carnivalWheel_bg_yellow.png");
            yellowBgSprite.setPreferredSize(cc.size(275, 34));
            yellowBgSprite.setPosition(rewardPosition);
            aniLayer.addChild(yellowBgSprite);

            // 獎勵字
            let rewardString = TexasUtility.getSimpleMoneyString(param.getReward) + " chips";
            let rewardLabel = new cc.LabelTTF(rewardString, JSFontName, 20);
            rewardLabel.setPosition(rewardPosition);
            rewardLabel.setFontFillColor(JSColor.BLACK);
            aniLayer.addChild(rewardLabel);
        }

        // 領獎 btn
        let rewardBtnSize = cc.size(90, 35 + (isLuxyPoker ? 5 : 0));
        let rewardBtn = new Texas_Button(Texas_Button.Style.ORANGE, rewardBtnSize, LocalizedString.Purchase("領獎"), {fontSize: 14});
        rewardBtn.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 69);
        rewardBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
        aniLayer.addChild(rewardBtn);
    },

    /**
     * 儲值 ui
     */
    _createPurchaseUI: function () {
        let aniLayer = this._animationLayer;
        let param = this._param;
        let isLuxyPoker = GS.isLuxyPoker;

        // 創一個 node 放噴金幣動畫
        let coinAniNode = new cc.Node();
        aniLayer.addChild(coinAniNode);
        // 創噴金幣動畫
        this._createCoinAnimation(coinAniNode);

        // 背景
        let bgSprite = new ccui.Scale9Sprite("carnivalWheel_bg_frame_01.png");
        bgSprite.setPreferredSize(cc.size(320, 198));
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite);

        // 標題背景
        let titleBgSpPath = isLuxyPoker ? "#carnivalWheel_bg_title_purple.png" : "#carnivalWheel_pic_title_bg.png";
        let titleBgSp = new cc.Sprite(titleBgSpPath);
        titleBgSp.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 92);
        aniLayer.addChild(titleBgSp);

        // 標題
        let titleSp = new cc.Sprite(param.isMaxReward ? "#carnivalWheel_w_superlucky.png" : "#carnivalWheel_w_congratulations.png");
        titleSp.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 92);
        aniLayer.addChild(titleSp);

        // 恭喜文字
        let topLabel = new cc.LabelTTF(LocalizedString.PurchaseCoupon(param.isMaxReward ? "你轉中了最大獎" : "您獲得了"), JSFontName, 15);
        topLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 46);
        topLabel.setFontFillColor(JSColor.WHITE);
        aniLayer.addChild(topLabel);

        // 獎勵字
        {
            let rewardPosition = cc.p(JSScreenMidPos.x, JSScreenMidPos.y + 2);

            // 獎勵字黃色底
            let yellowBgSprite = new ccui.Scale9Sprite("carnivalWheel_bg_yellow.png");
            yellowBgSprite.setPreferredSize(cc.size(275, 34));
            yellowBgSprite.setPosition(rewardPosition);
            aniLayer.addChild(yellowBgSprite);

            // 獎勵字
            let rewardString = TexasUtility.getSimpleMoneyString(param.getReward) + " chips";
            let rewardLabel = new cc.LabelTTF(rewardString, JSFontName, 20);
            rewardLabel.setPosition(rewardPosition);
            rewardLabel.setFontFillColor(JSColor.BLACK);
            aniLayer.addChild(rewardLabel);
        }

        // 儲值按鈕
        let purchaseString = JSStringUtility.format("%s\n%s %s", LocalizedString.Purchase("領取"), TexasUtility.CURRENCY_STRING, param.payMoney);
        let purchaseBtnSize = cc.size(90, 45 + (isLuxyPoker ? 5 : 0));
        let purchaseBtn = new Texas_Button(Texas_Button.Style.GREEN, purchaseBtnSize, purchaseString);
        purchaseBtn.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 55);
        purchaseBtn.addTouchUpInsideAction(this._buyBtnClicked, this);
        aniLayer.addChild(purchaseBtn);

        // 關閉按鈕
        let closeBtn = new Texas_CloseButton();
        closeBtn.setPosition(JSVisibleSize.width - JSScreenSafeWidth - 30, JSVisibleSize.height - 30);
        closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
        aniLayer.addChild(closeBtn);
    },

    /**
     * 創噴金幣動畫
     * @param node - 動畫放在哪個node
     */
    _createCoinAnimation: function (node) {
        // 噴金幣動畫
        let coinSpinPath = "lobby/purchasePack/carnivalWheel/ani_coin";
        GS.loadSpine(coinSpinPath, () => {
            let coinSpine = new sp.SkeletonAnimation(coinSpinPath + ".json", coinSpinPath + ".atlas", 0.25);
            coinSpine.setPosition(JSScreenMidPos);
            coinSpine.setAnimation(0, "ani_01", true);
            node.addChild(coinSpine);
        });
    },

    /**
     * An返回
     */
    keyBackPressed: function () {
        if (this.isLockBackKey)
            return;

        this._closeBtnClicked();
    },

    /**
     * 按下購買按鈕
     */
    _buyBtnClicked: function () {
        // 判斷有沒有第三方
        var data = DataModal.purchaseStructuresData.packMap[PurchaseStructuresData.PackSkin.CARNIVAL_WHEEL];

        var param = data.purchaseParam;
        if (param.productIDList.length > 1)
            DialogManager.addDialog(new ProviderChooseDialog(param), false);
        else
            DataModal.purchaseData.sendPurchase(param.productIDList[0]);

        // 送通知設定已轉完
        GS.dispatchCustomEvent("NotifyCarnivalWheelSetSpinFinished", {wheelStep: data.step});

        this._closeDialogAnimation();
    },

    /**
     * 按下關閉按鈕
     */
    _closeBtnClicked: function () {
        let param = this._param;

        if (this._type === CarnivalWheelRewardDialog.Type.MESSAGE) {
            // 執行callback
            param.callback && param.callback();
        } else if (param.isPurchaseSuccess) {
            // 執行callback
            param.callback && param.callback();
        } else {
            // 有遇到連點會出事 先鎖定an返回
            this.isLockBackKey = true;

            // 送通知設定已轉完
            GS.dispatchCustomEvent("NotifyCarnivalWheelSetSpinFinished", {
                wheelStep: param.wheelStep,
                isPurchase: param.isPurchase
            });
        }

        this._closeDialogAnimation();
    }
});

CarnivalWheelRewardDialog.Type = GSEnumHelper({
    MESSAGE: -1,        // 只有內文
    GET_REWARD: -1,     // 領獎
    PURCHASE: -1,       // 儲值 Dialog
});