/**
 * Cangkulan 抽牌區
 */
var Cangkulan_DrawCardLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 抽牌區的位置
        var drawPos = this._drawPos = cc.pAdd(JSScreenMidPos, Cangkulan_Offset.DRAW);

        // 存放疊起來的牌
        this._cardArray = [];
        var cardsNode = this._cardsNode = new cc.Node();
        cardsNode.setPosition(cc.pAdd(JSScreenMidPos, Cangkulan_Offset.WASH));
        this.addChild(cardsNode);

        var defaultPos = this._defaultPos = cc.pAdd(drawPos, cc.p(0, 4.4));

        // 抽取區上面的數字
        var numberObj = {
            number: 0,
            numStr: "#cangkulan_num_0",
            spW: 15
        };
        var cardCountNode = this._cardCountNode = new GSSpriteNumberNode(numberObj);
        cardCountNode.setPosition(defaultPos);
        this.addChild(cardCountNode);

        // 表演用的一張牌
        var cardAnimNode = this._cardAnimaNode = new PokerCardNode("12");
        cardAnimNode.setPosition(defaultPos);
        cardAnimNode.setCardIsInBack(true);
        this.addChild(cardAnimNode);

        this.clean();
    },

    clean: function () {
        this.cardCount = 0;

        this._cardAnimaNode.stopAllActions();
        this._cardAnimaNode.setVisible(false);

        this._cardCountNode.setScale(1);
        this._cardCountNode.setVisible(false);

        // 把場上剩餘的牌清掉
        this._cardsNode.removeAllChildren();
        this._cardArray = [];
    },

    /**
     * 設定抽牌區剩餘的張數
     * @param drawCount
     */
    setDrawCount: function (drawCount) {
        // 需要跑抽牌動畫 先記住抽完後剩餘的張數
        if (this.cardCount && drawCount !== this.cardCount)
            this._newDrawCount = drawCount;
        else {
            // 不需要跑抽牌動畫 直接顯示剩餘的張數
            if (!this._newDrawCount)
                this._newDrawCount = drawCount;

            this.cardCount = drawCount;
            this._showDrawCount();
        }
    },

    /**
     * 顯示抽牌區
     * @param pos
     */
    showDrawCards: function (pos, cardCount) {
        pos = pos || Cangkulan_Offset.WASH;
        this._cardsNode.setPosition(cc.pAdd(JSScreenMidPos, pos));

        // 牌局重現時疊牌的數量不是固定
        var drawCount = (cardCount && cardCount < Cangkulan_DeawDrawStackCount)
            ? cardCount
            : Cangkulan_DeawDrawStackCount;

        // 產生抽牌區疊起來的牌
        for (var i = 0; i < drawCount; i++) {
            var pokerNode = new PokerCardNode();
            pokerNode.setCardIsInBack(true);
            pokerNode.setPosition(0, i * 0.4);
            this._cardsNode.addChild(pokerNode);

            this._cardArray.push(pokerNode);
        }

        // 牌局重現時要顯示抽牌區  to do
        if (cc.pointEqualToPoint(pos, Cangkulan_Offset.DRAW))
            this._cardCountNode.setVisible(true);
    },

    /**
     * 發完牌要把牌移到發牌區 & 顯示棄牌區
     * @returns {Promise<any>}
     */
    runDealEndAnim: function (resolve) {
        this._cardsNode.runAction(cc.sequence(
            // 移動到抽牌區
            cc.moveTo(0.4, this._drawPos),
            cc.callFunc(() => {
                // 抽牌區的數量
                this._cardCountNode.setVisible(true);
                this._cardCountNode.setNumber(this.cardCount);
                resolve();
            })
        ));
    },

    /**
     * 抽牌區表演飛入手牌
     * @param pos 牌飛入的位置
     * @param card 抽到的牌
     * @param isFinish 是不是最後一張
     */
    runDrawCardAnim: function (pos, card, isFinish) {
        // 顯示剩餘的張數
        if (this._newDrawCount <= this.cardCount) {
            this.cardCount--;
            this._showDrawCount();
        }

        if (this.cardCount < Cangkulan_DeawDrawStackCount) {
            // 抽牌區的牌需要做減少的效果
            var cardNode = this._cardArray.pop();
            if (cardNode)
                cardNode.removeFromParent();
        }

        if (card) {
            // 自己的 從抽牌區飛入自己的手牌 牌需要打開
            this._runDrawFlyCardAnim(pos, card, true, isFinish);
        } else {
            // 其他人 從抽牌區飛入其他人的手牌 以牌背飛入
            this._runDrawFlyCardAnim(pos, card, false, isFinish);
        }
    },

    /**
     * 表演從抽牌區飛入手牌
     * @param pos     終點的位置
     * @param isSelf  是不是自己
     * @private
     */
    _runDrawFlyCardAnim: function (pos, card, isSelf, isFinish) {
        this._resetDrawCard(card);

        var moveTime = 0.25;

        if (isSelf)
            var endPos = pos;
        else {
            var direction = DataModal.gameData.getDirectionByServerDirection(pos);
            var endPos = Cangkulan_GameUtility.getDealCardPosition(direction);
        }
        var endScale = (isSelf) ? 1 : 0.3;

        // 最後一張要把張數號碼隱藏
        this._cardCountNode.setVisible(this.cardCount);

        this._cardAnimaNode.runAction(cc.sequence(
            cc.spawn(
                cc.moveTo(moveTime, endPos),
                cc.scaleTo(moveTime, endScale)
            ),
            cc.callFunc(() => {
                if (isSelf)
                    // 通知顯示在手牌中
                    GS.dispatchCustomEvent("NotifyGameShowDrawCard");
                else
                    // 其他玩家的牌
                    GS.dispatchCustomEvent("NotifyAddPlayerHandCard", pos);

                if (isFinish)
                    GS.dispatchCustomEvent("NotifyEnableProcessMessage");

            }, this),
            cc.hide()
        ));
    },

    /**
     * 重設表演用的牌初始設定
     * @param card
     * @private
     */
    _resetDrawCard: function () {
        var cardAnimaNode = this._cardAnimaNode;
        cardAnimaNode.setScale(1);
        cardAnimaNode.setPosition(this._defaultPos);
        cardAnimaNode.setVisible(true);
    },

    /**
     * 顯示抽牌區剩餘的數量
     * @private
     */
    _showDrawCount: function () {
        if (this.cardCount <= 0) {
            this._cardCountNode.setVisible(false);
            return;
        }

        // 剩餘三張牌要把牌放大
        if (this.cardCount <= 3)
            this._cardCountNode.setScale(1.5);
        this._cardCountNode.setNumber(this.cardCount);
    }
});