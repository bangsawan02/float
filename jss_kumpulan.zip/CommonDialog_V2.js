/**
 * 提醒、獲獎用的Dialog
 * created by andrew.chang
 *
 * @param {Object} obj - 對話框的設定物件。
 * @param {string} [obj.key] - 對話框的鍵標識符。
 * @param {Array} [obj.loadFileArray] - 要載入的檔案陣列。
 * @param {string} [obj.bgImg] - 對話框的背景圖片。
 * @param {string} [obj.titleStr] - 對話框的標題字串。
 * @param {cc.Color} [obj.titleColor] - 對話框的標題顏色。
 * @param {string} [obj.frameImg] - 對話框的框架圖片。
 * @param {Array} [obj.contentArray] - 對話框的內容字串陣列。
 * @param {cc.Color} [obj.contentColor] - 對話框的內容顏色。
 * @param {Int} [obj.contentFontSize] - 對話框的內容文字大小。
 * @param {Array} [obj.btnStrArray] - 對話框的按鈕字串陣列。
 * @param {Array} [obj.btnStyleArray] - 對話框的按鈕樣式陣列。
 * @param {boolean} [obj.needKeyBack] - 對話框是否需要返回鍵操作。
 * @param {Function} [obj.callback] - 按鈕點擊時執行的回呼函數。
 * @param {Texas_Button.Style} [obj.closeBtnStyle] - 關閉按鈕類型
 */

var CommonDialog_V2 = BaseDialogLayer.extend({
    ctor: function (obj) {
        this._super();

        this.key = obj.key || "CommonDialog_V2";

        // 記下資料
        this.obj = obj;

        // 需要讀取的素材
        this.loadFileArray = obj.loadFileArray || [];
    },

    onExit: function () {
        if (this._loadFileDone && this.loadFileArray.length) {
            for (let i = 0, len = this.loadFileArray.length; i < len; i += 2) {
                cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[i]);
            }
        }

        this._super();
    },

    /**
     * 讀取素材完畢
     * @override
     */
    loadFileDone: function () {
        this._super();

        if (this.loadFileArray.length) {
            for (var i = 0; i < this.loadFileArray.length; i += 2) {
                cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[i], this.loadFileArray[i + 1]);
            }
        }

        // 處理預設值
        var obj = this.obj;
        obj.bgImg = obj.bgImg || "frame_01.png";
        obj.titleStr = obj.titleStr || "";
        obj.titleColor = obj.titleColor || JSColor.BLACK;
        obj.frameImg = obj.frameImg || "frame_02.png";
        obj.contentArray = obj.contentArray || [];
        obj.contentColor = obj.contentColor || JSColor.BLACK;
        obj.contentFontSize = obj.contentFontSize || 15;
        obj.btnStrArray = obj.btnStrArray || [LocalizedString.Common("確認")];
        obj.btnStyleArray = obj.btnStyleArray || [Texas_Button.Style.BLUE, Texas_Button.Style.GREEN];

        // 有沒有標題
        var hasTitle = obj.titleStr.length;
        var bgPos = cc.p(JSScreenMidPos.x, (hasTitle ? 148 : 138) + JSScreenBonusHalfHeight);
        var bgSize = cc.size(312, hasTitle ? 218 : 198);

        var aniLayer = this._animationLayer;

        // 背景底
        var bgSprite = new ccui.Scale9Sprite(obj.bgImg);
        bgSprite.setPreferredSize(bgSize);
        bgSprite.setPosition(bgPos);
        aniLayer.addChild(bgSprite, -1);

        // 標題
        if (hasTitle) {
            var titleLabel = new GSRichLabelNode(obj.titleStr, JSFontName, 18);
            titleLabel.setFontFillColor(obj.titleColor);
            titleLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            titleLabel.setPosition(bgPos.x, bgPos.y + 84);
            aniLayer.addChild(titleLabel);
        }

        // 內文相關
        {
            // 內文框
            var frameSize = cc.size(275, 115);
            var framePosY = 161 + JSScreenBonusHalfHeight;
            var frameSprite = new ccui.Scale9Sprite(obj.frameImg);
            frameSprite.setPreferredSize(frameSize);
            frameSprite.setPosition(bgPos.x, framePosY);
            aniLayer.addChild(frameSprite);

            // 文字排版的node
            let layoutNode = new GSAutoLayoutNode();
            layoutNode.setType(GSAutoLayout.TYPE.VERTICAL);

            let scrollViewSize = cc.size(frameSize.width - 8, frameSize.height - 8);

            // 所有的內文
            let totalHeight = 0;
            let contentLen = obj.contentArray.length;
            obj.contentArray.forEach(cur => {
                // 內文
                let contentLabel = new GSRichLabelNode("", JSFontName, obj.contentFontSize, cc.size(scrollViewSize.width, 0));
                contentLabel.setFontFillColor(obj.contentColor);
                contentLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                contentLabel.setWordBreakBySpace(true);

                // 這裡才設定內容，因為 setWordBreakBySpace 不會更新畫面
                contentLabel.setString(cur);
                layoutNode.addChild(contentLabel);

                // 算高度
                totalHeight += contentLabel.getContentSize().height;
            });

            let isNeedScrollView = totalHeight > scrollViewSize.height;
            if (isNeedScrollView) {
                // 創ScrollView
                let mainLayer = new cc.Layer();
                let scrollView = new cc.ScrollView(scrollViewSize, mainLayer);
                scrollView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
                scrollView.setPosition(bgPos.x - scrollViewSize.width / 2, framePosY - scrollViewSize.height / 2);
                aniLayer.addChild(scrollView);

                // 把內文加上去
                layoutNode.setAnchorPoint(0, 0);
                mainLayer.addChild(layoutNode);

                // 設置scrollView大小
                scrollView.setContentSize(scrollViewSize.width, totalHeight);

                // 先不讓他滑動
                scrollView.setTouchEnabled(false);

                // 先跑到最上面
                scrollView.setContentOffset(scrollView.minContainerOffset());

                // 動畫時間
                var animTime = 0.1;
                let delayTime = 0.05;

                // 需要滾動
                if (scrollViewSize.height < totalHeight) {
                    // 每個訊息出現時間
                    animTime = contentLen * delayTime;

                    layoutNode.getChildren().forEach((child, index) => {
                        // 先隱藏
                        child.setVisible(false);

                        // 在出現
                        child.runAction(cc.sequence(
                            cc.delayTime(index * (delayTime - 0.01)),
                            cc.show()
                        ));
                    });

                    // 再跑到最下面
                    scrollView.setContentOffsetInDuration(scrollView.maxContainerOffset(), animTime);
                }

                // 等動畫完
                this.runAction(cc.sequence(
                    cc.delayTime(animTime),
                    cc.callFunc(() => {
                        // 可滑動
                        scrollView.setTouchEnabled(true);
                    }))
                );
            } else {
                // 直接加到畫面上
                layoutNode.setPosition(bgPos.x, framePosY);
                aniLayer.addChild(layoutNode);
            }
        }

        // 按鈕相關
        {
            // 排版用的node
            let btnLayoutNode = new GSAutoLayoutNode();
            btnLayoutNode.setSpace(30);
            btnLayoutNode.setPosition(bgPos.x, 76 + JSScreenBonusHalfHeight);
            aniLayer.addChild(btnLayoutNode);

            // 按鈕(最多兩顆按鈕)
            for (let i = 0, btnLen = Math.min(obj.btnStrArray.length, 2); i < btnLen; i++) {
                let btnStr = obj.btnStrArray[i];
                let btnStyle = obj.btnStyleArray[i];
                let btn = new Texas_Button(btnStyle, cc.size(100, 38), btnStr, {fontSize: 13});
                btn.index = i;
                btn.addTouchUpInsideAction(this._buttonClicked, this);
                btnLayoutNode.addChild(btn);
            }

            if (obj.closeBtnStyle) {
                let closeBtn = new Texas_CloseButton(obj.closeBtnStyle);
                closeBtn.setPosition(bgPos.x + bgSize.width / 2 - 5, bgPos.y + bgSize.height / 2 - 5);
                closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
                aniLayer.addChild(closeBtn);
            }
        }
    },

    keyBackPressed: function () {
        if (!this.obj.needKeyBack)
            this._super();
        else {
            this._closeBtnClicked();
        }
    },

    /**
     * 按鈕
     */
    // 關掉畫面
    _closeBtnClicked: function () {
        // 執行callback
        if (this.obj.callback)
            this.obj.callback(-1);

        // 關掉畫面
        this._closeDialogAnimation();
    },

    // 按鈕點擊
    _buttonClicked: function (sender) {
        // 沒有按鈕不做事
        if (!sender)
            return;

        // 執行callback
        if (this.obj.callback)
            this.obj.callback(sender.index);

        // 關掉畫面
        this._closeDialogAnimation();
    }
});