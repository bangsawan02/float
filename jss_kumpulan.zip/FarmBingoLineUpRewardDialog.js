/**
 * v5.6.0 齋戒副系統 賓果連線 dialog
 * @param callback? {Function} 關閉 dialog 後的 callback
 */
var FarmBingoLineUpRewardDialog = BaseDialogLayer.extend({
    ctor: function (options) {
        this._super();

        this._onBingoAnimeEnd = options.onBingoAnimeEnd;
    },

    _startDialogAnimation: function () {
        let bgColorLayer = this._bgColorLayer;
        bgColorLayer.setOpacity(200);

        // 賓果球跳出動畫
        GSSpine.create("spine/FarmBingo/bingo/bingo", 0.25, (spine) => {
            spine.setOpacity(0);
            spine.setAnimation(0, "ani01", false);
            spine.setPosition(JSScreenMidPos);
            this.addChild(spine, 1);

            spine.runAction(cc.sequence(
                cc.fadeIn(0.2),
                cc.delayTime(2),
                cc.spawn(
                    cc.scaleTo(0.2, 0),
                    cc.callFunc(() => {
                        bgColorLayer.runAction(cc.fadeOut(0.2));
                    })
                ),
                cc.callFunc(() => {
                    this._onBingoAnimeEnd();
                    this._playBagFlyAnimation();
                }),
                cc.removeSelf()
            ));
        });
    },

    _closeDialogAnimation: function () {
        // 關閉整個獎勵的 dialog
        this.runAction(cc.sequence(
            cc.fadeOut(0.2),
            cc.callFunc(() => {
                // 一切做完，呼叫 callback
                this.__closeCallback && this.__closeCallback();
            }),
            cc.removeSelf()
        ));
    },

    // 錢袋飛出動畫
    _playBagFlyAnimation: function () {
        // 錢袋飛出
        var bagSprite = new cc.Sprite("#farm_bingo_pic_shop.png");
        bagSprite.setPosition(JSScreenMidPos.x - 201, JSScreenMidPos.y + 78);
        this.addChild(bagSprite);

        bagSprite.runAction(cc.sequence(
            cc.moveTo(0.2, cc.pAdd(JSScreenMidPos, cc.p(-111, 50))),
            cc.moveTo(0.2, JSScreenMidPos),
            cc.spawn(
                cc.fadeOut(0.2),
                cc.callFunc(this._playEnterAnimation.bind(this))
            )
        ));
    },

    _playEnterAnimation: function () {
        this._bgColorLayer.runAction(cc.fadeTo(0.2, 200));

        // 第一行標題
        var titleSprite = new cc.Sprite("#farm_bingo_w_title_award_01.png");
        titleSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 88);
        this.addChild(titleSprite, 1);

        titleSprite.runAction(cc.sequence(
            cc.spawn(
                cc.scaleTo(0.2, 1.1),
                cc.fadeIn(0.2)
            ),
            cc.scaleTo(0.2, 1)
        ));

        // 錢袋 spine
        var bagSpine = undefined;
        GSSpine.create("spine/FarmBingo/PIC_award_chain/PIC_award_chain", 0.25, (spine) => {
            spine.setAnimation(0, "ani_1", true);
            spine.setPosition(JSScreenMidPos);
            this.addChild(spine);
            bagSpine = spine;
        });

        // 裝底下獎勵底圖跟內容的node 用來跑動畫
        var rewardNode = new cc.Node();
        rewardNode.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 52);
        rewardNode.setCascadeOpacityEnabled(true);
        rewardNode.setOpacity(0);
        rewardNode.setScale(0);
        this.addChild(rewardNode, 1);

        rewardNode.runAction(cc.sequence(
            cc.spawn(
                cc.scaleTo(0.2, 1.1),
                cc.fadeIn(0.2)
            ),
            cc.scaleTo(0.2, 1)
        ));

        // 獎勵框
        var frameSprite = new ccui.Scale9Sprite("farm_bingo_bg_frame_award.png");
        frameSprite.setPreferredSize(cc.size(400, 54));
        rewardNode.addChild(frameSprite);

        // 獎勵內容
        var rewardAutoLayout = new GSAutoLayoutNode();
        rewardAutoLayout.setCascadeOpacityEnabled(true);
        rewardNode.addChild(rewardAutoLayout);

        DataModal.farmBingoData.bingoParam.ballRewardPot.forEach((element, i) => {
            // UI 空間只允許兩個獎勵，超過的不顯示
            if (i > 1) {
                return;
            }

            // 預留 icon size 使 auto layout 能正常運作
            var rewardSpriteWrapperNode = new cc.Node();
            rewardSpriteWrapperNode.setContentSize(cc.size(54, 54));
            rewardSpriteWrapperNode.setCascadeOpacityEnabled(true);
            rewardAutoLayout.addChild(rewardSpriteWrapperNode);

            // 獎勵圖示，疊在預留空間上
            var imageUrl = TexasUtility.getItemImageUrl(element.picFileName);
            var savePath = JSWriteablePath + "shop/" + element.picFileName + ".png";
            var rewardSprite = new GSDownloadSprite("", imageUrl, savePath);
            rewardSprite.setPosition(27, 27);
            rewardSprite.setTargetSize(cc.size(40, 40));
            rewardSpriteWrapperNode.addChild(rewardSprite);

            // 獎勵數量
            var countLabel = new cc.LabelTTF(element.count, JSFontName, 20);
            countLabel.setFontFillColor(cc.color(81, 61, 26));
            rewardAutoLayout.addChild(countLabel);

            if (i === 0) {
                rewardAutoLayout.addEmptyNode(cc.size(8, 0));
                // 加號
                var plusLabel = new cc.LabelTTF("+", JSFontName, 20);
                plusLabel.setFontFillColor(cc.color(81, 61, 26));
                rewardAutoLayout.addChild(plusLabel);
            }
        });

        // 領獎按鈕
        var button = new Texas_Button(Texas_Button.Style.GREEN, cc.size(94, 33), LocalizedString.FarmBingo("領獎"));
        button.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 93);
        button.addTouchUpInsideAction(this.closeDialogAnimation, this);
        this.addChild(button, 1);
    },
});