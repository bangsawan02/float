var LocalizedString = LocalizedString || {};

LocalizedString.CouponChallengeString = function (str) {
    let keyValue = {
        "優惠券挑戰": "Ekstra Kupon",
        "使用當前的優惠券來解鎖下一張": "Pakai kupon untuk dapat kupon selanjutnya!",
        "以上優惠券僅可在儲值中心使用": "Kupon hanya bisa digunakan di halaman Get Chip.",
        "所有方案可使用": "Top-up berapa pun",
        "限 %s 以上": "%s ke atas",
        "已使用": "Sudah\ndipakai",
        "優惠大挑戰活動已結束": "Event Ekstra Kupon Berakhir",
        "活動發送的優惠券已過期\n將從您的背包移除": "Kupon dari event sudah kedaluwarsa\nKupon tidak bisa dipakai lagi",
        "優惠券用完了": "Voucher Habis",
        "活動提前結束": "Event akan ditutup",
        "OK": "OK",
    };

    return USE_i18n ? (keyValue[str] || str) : str;
};