/**
 * v5.6.5 農場 Pass
 */

var FarmPassDialog = BasePassDialog.extend({
    ctor: function () {
        let tokenIconFileName = "lobby_icon_farm_pass.png";
        let ticketIconFileName = "farm_pass_pic_ticket_01.png";
        let freeTicketIconFileName = "farm_pass_pic_ticket_02.png";

        this._isFirstIn = true;

        this._super({
            // Dialog key
            key: "FarmPassDialog",

            // Table View settings.
            tableViewSize: cc.size(273, 184),
            tableViewPosition: cc.p(JSScreenMidPos.x - 179, JSScreenMidPos.y - 110),
            tableViewCellSize: cc.size(85, 184),
            tableViewNodeClass: FarmPassRewardItemNode,

            // Emphasize reward node settings.
            emphasizeRewardNodeBgFileName: "farm_pass_pic_frame_05.png",
            emphasizeRewardOriginPositionY: JSScreenMidPos.y - 18,
            emphasizeRewardShowPositionX: 314 + JSScreenBonusHalfWidth,

            // 按鈕群設定
            buttonGroupPosition: cc.p(JSScreenMidPos.x + 172, JSScreenMidPos.y - 60),
            buttonGroupAlignment: BasePassButtonGroup.Alignment.VERTICAL,
            claimAllBtnText: LocalizedString.FarmBingo("全部領取"),
            purchaseBtnDiscountFileName: "farm_pass_pic_Label_01.png",
            purchaseBtnDiscountPosition: cc.p(0, -32),
            purchaseBtnDiscountRotation: 0,
            purchaseBtnDiscountScale: 1,
            purchaseBtnDiscountFontColor: cc.color(255, 245, 102),
            purchaseBtnDiscountFontSize: 10,
            purchaseBtnDiscountLabelPosition: cc.p(0, -4),

            // 目標代幣數量標籤設定
            goalLabelOffset: cc.p(0, -6),

            // 代幣與票券 icon 檔名
            tokenIconFileName: tokenIconFileName,
            ticketGradientHeight: 96,
            ticketIconFileName: ticketIconFileName,
            freeTicketIconFileName: freeTicketIconFileName,

            // 進度條設定
            shortProgressBarTokenScale: 1,
            progressBarBgFileName: "farm_pass_pic_bar_02.png",
            progressBarThumbnailFileName: "farm_pass_pic_bar_01.png",

            // 目標代幣數量標籤設定
            goalLabelBgFileName: "farm_pass_pic_frame_star_02.png",

            // 左上方代幣數量設定
            tokenBarIconFileName: tokenIconFileName,
            tokenBarIconScale: 0.55,
            tokenBarIconOffset: cc.p(5, -1),
            tokenBarFontColor: JSColor.WHITE,
            tokenBarIsShowPlusBtn: false,

            // 左側雙票券設定
            tableViewHeaderPosition: cc.p(JSScreenMidPos.x - 211, JSScreenMidPos.y - 23),
            ticketGradientFileName: "farm_pass_bg_gradient_Light.png",

            // 一般訊息類 dialog 設定
            messageDialogBgFileName: "farm_pass_bg_frame.png",

            // 獲獎 dialog 設定
            getRewardNodeContextBgFileName: "farm_pass_bg_green_02.png",
            getRewardNodeContextTitleFileName: "farm_pass_w_title_07.png",
            getRewardDialogContentOpacity: 204,
            getRewardDialogTitleFileName: "farm_pass_w_title_04.png",
        });

        this.loadFileArray = [
            "luxyPass/luxyPass.plist",
            "luxyPass/luxyPass.png",
        ];
    },

    onEnter: function () {
        this._super();

        // 埋點：進入介面 4419
        DataModal.farmBingoData.sendTrackingData(4419);
    },

    onExit: function () {
        this._super();

        this._releaseEventEndSemaphore();
    },

    loadFileDone: function () {
        this._super();

        let aniLayer = this._animationLayer;

        // 底圖
        let dialogBgSprite = new cc.Sprite("farmBingo/farm_bingo_bg_farm.jpg");
        dialogBgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(dialogBgSprite, -2);

        // 背景
        let tableViewBgSprite = new ccui.Scale9Sprite("farm_pass_bg_frame.png");
        tableViewBgSprite.setPreferredSize(cc.size(500, 205));
        tableViewBgSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 18);
        aniLayer.addChild(tableViewBgSprite, -1);

        // 右側金線
        let goldLineSprite = new ccui.Scale9Sprite("farm_pass_bg_ground.png");
        goldLineSprite.setPreferredSize(cc.size(75, 184));
        goldLineSprite.setPosition(JSScreenMidPos.x + 58, JSScreenMidPos.y - 18);
        aniLayer.addChild(goldLineSprite, -1);

        // 上半背景
        let upperBgSprite = new ccui.Scale9Sprite("farm_pass_bg_green.png");
        upperBgSprite.setPreferredSize(cc.size(335, 96));
        upperBgSprite.setPosition(JSScreenMidPos.x - 72, JSScreenMidPos.y + 26);
        aniLayer.addChild(upperBgSprite, -1);

        // 黑色漸層
        let blackLayerGradient = new ccui.Scale9Sprite("farm_pass_bg_gradient_dark.png");
        blackLayerGradient.setPreferredSize(cc.size(70, 183));
        blackLayerGradient.setPosition(JSScreenMidPos.x - 177, JSScreenMidPos.y - 18);
        blackLayerGradient.setAnchorPoint(0, 0.5);
        aniLayer.addChild(blackLayerGradient, -1);

        // 標題
        let titleSprite = new cc.Sprite("#farm_pass_w_title_01.png");
        titleSprite.setPosition(JSScreenMidPos.x, 264 + JSScreenBonusHalfHeight);
        aniLayer.addChild(titleSprite);

        // 右側手推車
        let cartSprite = new cc.Sprite("#farm_pass_pic_cart.png");
        cartSprite.setPosition(JSScreenMidPos.x + 160, JSScreenMidPos.y + 46);
        aniLayer.addChild(cartSprite);

        // 代幣數量的node
        let tokenBar = this._tokenBar = new BasePassTokenBar(this._config);
        tokenBar.setVisible(false);
        tokenBar.setPosition(81 + JSScreenBonusHalfWidth, 271 + JSScreenBonusHalfHeight);
        aniLayer.addChild(tokenBar);

        // 按鈕事件綁定
        this._buttonGroup.claimAllButton.addTouchUpInsideAction(this._claimAllClicked, this);
        this._buttonGroup.playNowButton.addTouchUpInsideAction(this._playNowClicked, this);
        this._buttonGroup.purchaseButton.addTouchUpInsideAction(this._purchaseClicked, this);
        this.tableViewHeaderNode.getLuxuryTicketBtn().addTouchUpInsideAction(this._luxuryTicketButtonClicked, this);

        // 通知
        GS.addListener("NotifyFarmPassInfoDone", this.notifyFarmPassInfoDone.bind(this), this);
        GS.addListener("NotifyFarmPassShowDialog", this.notifyFarmPassShowDialog.bind(this), this);
        GS.addListener("NotifyFarmPassRechargeDone", this.notifyFarmPassRechargeDone.bind(this), this);

        DataModal.farmBingoData.startGetPassInfo();
    },

    /**
     * 刷新畫面
     */
    _refreshView: function () {
        if (this.__isDestroyed) {
            return;
        }

        this._isPurchasing = false;
        this.setLoadingSprite(false, false);

        let data = this._data = DataModal.farmBingoData;
        let passData = this._param = data.passData;
        if (!passData.isSuccess()) {
            this.showEventEndDialog();
            return;
        }

        // 埋點：進入介面且有累積人數 4420
        if (!this._isSendTrackDone && passData.tokenCount > 0) {
            DataModal.farmBingoData.sendTrackingData(4420);

            // 送過埋點flag
            this._isSendTrackDone = true;
        }

        let rewardArray = this._rewardArray = passData.rewardArray;
        let maxTokenRequired = this._maxTokenRequired = rewardArray[rewardArray.length - 1].goal;
        let newTokenCount = this._currentTokenCount = passData.tokenCount;
        let tokenRecord = this.getTokenRecord(UserDefaultKey.FarmPassTokenCount);
        // 記錄的賓果球<server給的數量才表演 && 記錄的賓果球<server給的獎勵最大數量
        let isNeedAnimation = tokenRecord < newTokenCount && tokenRecord < maxTokenRequired;
        this._oldTokenCount = isNeedAnimation ? tokenRecord : newTokenCount;
        if (!isNeedAnimation) {
            // 不用演動畫 直接塞server的資料
            this.saveTokenRecord(UserDefaultKey.FarmPassTokenCount, newTokenCount);
        }

        // 要更新資料
        this._tableView.updateNormalData(rewardArray, this._oldTokenCount);
        this._tableView.reloadData();

        // 更新進度條
        this.setProgress(this._oldTokenCount, false);

        // 達到最後階段
        let reachFinal = this._tableView.getProgressBar().getPercentage() === 100;

        // 當前賓果數量
        this._tokenBar.setVisible(!reachFinal);
        this._tokenBar.setQuantity(this._currentTokenCount);

        // 更新按鈕狀態
        let purchaseParam = passData.purchaseParam;
        this.tableViewHeaderNode.getLuxuryTicketBtn().setEnabled(!!purchaseParam);
        this._buttonGroup.refreshView(purchaseParam, reachFinal, passData.isObtainable(), passData.isPassUnlocked);
        this._buttonGroup.setVisible(true);
        this._skipBtn.setPosition(cc.pAdd(this._buttonGroup.getPosition(), cc.p(0, -16)));
        this._skipBtn.setVisible(false);

        // Button Group 埋點
        if (!reachFinal) {
            // 顯示領獎按鈕埋點 4471、顯示馬上玩按鈕埋點 4473
            DataModal.farmBingoData.sendTrackingData(passData.isObtainable() ? 4471 : 4473);
        }

        // 滑動到當前賓果數量的位置
        this.scrollTableViewByTokenCount(this._oldTokenCount);

        if (isNeedAnimation) {
            // 做動畫
            this._isInAnimation = true;

            // 動畫表演時都不給按
            this._closeButton.setEnabled(false);

            // 不給按
            this.setLoadingSprite(false, true);

            // 告知按鈕群正在跑動畫
            this._skipBtn.setVisible(true);
            this._skipBtn.setEnabled(true);
            this._buttonGroup.setVisible(false);
            this._playTokenFlyAnimeAsync()
                // 一般獎勵的進度
                .then(() => this.playProgressAnimationAsync(this._oldTokenCount, this._currentTokenCount))
                .catch(() => Promise.resolve())
                .then(() => {
                    // 重設一些狀態
                    this._isSkipped = false;
                    this._isInAnimation = false;
                    this._closeButton.setEnabled(true);

                    // 記下目前的賓果數
                    this.saveTokenRecord(UserDefaultKey.FarmPassTokenCount, this._currentTokenCount);

                    // 刷新畫面
                    this._refreshView();
                });
        }
    },

    /**
     * TableView cell 更新時呼叫，BasePassDialog will call it.
     * @param {int} index
     * @protected
     */
    _onCellRefresh: function (index) {
        let rewardArray = this._rewardArray;
        let emphasizeIndex = this._emphasizeRewardLayer.getEmphasizeIndex(index, this._rewardArray.length);
        let currentTokenCount = this._currentTokenCount;
        let stageParam = rewardArray[emphasizeIndex];

        if (!stageParam) {
            this._emphasizeRewardLayer.setVisible(false);
        } else {
            this._emphasizeRewardLayer.refreshView(stageParam, currentTokenCount, stageParam.goal);
        }
    },

    /**
     * 代幣飛行動畫
     * @return {Promise<void>}
     */
    _playTokenFlyAnimeAsync: function () {
        if (this.__isDestroyed || this._isSkipped)
            return Promise.reject();

        let aniNode = this._aniNode = new BasePassTokenFlyAnimationNode(this._config);
        this.addChild(aniNode, 12);

        let startParam = {
            pos: this._tokenBar.getTokenSpritePosition(),
            scale: this._tokenBar.iconScale,
        };
        let endParam = {
            pos: cc.pAdd(this.tableViewHeaderNode.getPosition(), this.tableViewHeaderNode.getProgressBarTokenSprite().getPosition()),
            scale: this.tableViewHeaderNode.getProgressBarTokenSprite().getScale(),
        };
        return aniNode.playAsync(startParam, endParam);
    },

    /**
     * 高級票券點擊
     */
    _luxuryTicketButtonClicked: function () {
        if (this._param && this._param.purchaseParam) {
            GS.dispatchCustomEvent("NotifyFarmPassShowDialog", {
                type: BasePassDialogType.BUY_PASS,
            });
        }
    },

    /**
     * 全部領獎按鈕點擊
     */
    _claimAllClicked: function (sender) {
        this.setLoadingSprite(true, true);

        // 埋點：點擊全部領取按鈕 4472
        DataModal.farmBingoData.sendTrackingData(4472);

        // 送領獎
        DataProcess.sendString("farm_bingo_pass_reward 3");
    },

    /**
     * 馬上玩按鈕點擊
     */
    _playNowClicked: function (sender) {
        // 埋點：點擊馬上玩按鈕 4474
        sender && DataModal.farmBingoData.sendTrackingData(4474);

        // 馬上玩
        this.showDialog(new BasePassCommonDialog(this._config, {
            contentText: LocalizedString.FarmBingo("獲得澆水器\n即可累積進度!"),
            buttonGroup: [
                () => {
                    let btn = new Texas_Button(Texas_Button.Style.GREEN, cc.size(100, 32), LocalizedString.FarmBingo("前往"));
                    btn.addTouchUpInsideAction(() => {
                        this.closeDialogAnimation();
                    }, this);
                    btn.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 38);
                    return btn;
                },
            ],
            isShowCloseButton: true,
        }));
    },

    /**
     * 購買按鈕點擊
     */
    _purchaseClicked: function (sender) {
        // 埋點：點擊解鎖按鈕 4469
        sender && DataModal.farmBingoData.sendTrackingData(4469);

        // 埋點使用紀錄從哪邊從哪邊去儲值
        this._buyPassFromWhere = BasePassBuyFromWhere.MAIN_DIALOG;

        // 暫停 dialog 跳出 (BasePassDialog.onExit or BasePassDialog.notifyPurchaseFail 解鎖)
        DialogManager.pauseShowDialog();

        // 卡賓果活動結束，在儲值成功後解鎖
        this._acquireEventEndSemaphore();

        // 送儲值
        DataModal.purchaseData.goPurchase(sender.productParam);
    },

    /**
     * 跳過動畫按鈕點擊
     * @private
     */
    _skipBtnClicked: function (sender) {
        sender && sender.setEnabled(false);
        this._isSkipped = true;
        this._aniNode && this._aniNode.setSkipped(true);
        this.setLoadingSprite(true, true);
    },

    _closeBtnClicked: function () {
        // 動畫中 儲值等待過帳中 不做事
        if (!this.canCloseDialog())
            return;

        let param = this._param;

        if (!param || !param.leaveParam || !param.purchaseParam) {
            this.closeDialogAnimation();
            return;
        }

        let key = UserDefaultKey.FarmPassLeaveDialogPop + DataModal.profileData.account;
        let savedLeavePopParam = JSON.parse(GS.localStorage.getItem(key, JSON.stringify({
            time: TexasUtility.getNowTimeMillisecondString(),
            popTimes: 0
        })));

        // 當天跳過2次就不跳了
        let isChangeDay = TexasUtility.getNowIsChangeDay(savedLeavePopParam.time);
        if (!isChangeDay && savedLeavePopParam.popTimes >= 2) {
            this.closeDialogAnimation();
            return;
        }

        // 埋點：跳出離開提示 dialog 4538
        DataModal.farmBingoData.sendTrackingData(4538);

        this.showDialog(new BasePassLeaveNoticeDialog(this._config, {
            title: JSStringUtility.format(LocalizedString.FarmBingo("恭喜達到%s澆水器"), this._param.tokenCount),
            titleColor: cc.color(255, 231, 166),
            contentTitleText: LocalizedString.FarmBingo("解鎖農場PASS可立即獲得以下獎勵！"),
            contentTitleFontSize: 12,
            leaveParam: param.leaveParam,
            purchaseParam: param.purchaseParam,
            purchaseBtnOnClick: (sender) => {
                // 埋點：點擊離開提示 dialog 儲值按鈕 4539
                sender && DataModal.farmBingoData.sendTrackingData(4539);

                // 卡賓果活動結束，在儲值成功後解鎖
                this._acquireEventEndSemaphore();

                // 埋點使用紀錄從哪邊從哪邊去儲值
                this._buyPassFromWhere = BasePassBuyFromWhere.LEAVE_NOTICE_DIALOG;
            },
        }));

        // 記錄今天跳過幾次，日期不同就覆蓋掉且紀錄一次，相同就把次數+1
        GS.localStorage.setItem(key, JSON.stringify({
            time: TexasUtility.getNowTimeMillisecondString(),
            popTimes: isChangeDay ? 1 : savedLeavePopParam.popTimes + 1
        }));
    },

    /**
     * 建立說明 dialog. BaseEventDialog 會呼叫。
     */
    _createEventInfoDialog: function (sender) {
        return new WebViewDialog(TexasUtility.getSimpleInfoURLByKey(
                "farm_bingo_pass_info",
                JSStringUtility.format("group=%s", DataModal.farmBingoData.group)),
            null,
            null,
            true
        );
    },

    /**
     * 創活動結束dialog. BaseEventDialog 會呼叫。
     */
    _createEventEndDialog: function () {
        return new BasePassCommonDialog(this._config, {
            contentText: LocalizedString.FarmBingo("活動已結束！"),
            onCloseCallback: () => {
                // 關掉dialog
                var mainDialog = DialogManager.getDialogByKey("FarmBingoDialog");
                if (mainDialog) {
                    mainDialog.closeDialogAnimation();
                }
            }
        });
    },

    /**
     * 通知跳出Dialog
     */
    notifyFarmPassShowDialog: function (event) {
        if (event && event.getUserData()) {
            let param = event.getUserData();
            let purchaseParam = this._param.purchaseParam;
            let dialog;
            switch (param.type) {
                case BasePassDialogType.BUY_PASS:
                    // 埋點：跳出解鎖 dialog 4475
                    DataModal.farmBingoData.sendTrackingData(4475);

                    dialog = new FarmPassBuyPassDialog(this._config, {
                        purchaseParam: purchaseParam,
                        purchaseBtnOnClick: (sender) => {
                            // 埋點：點擊儲值按鈕 4476
                            sender && DataModal.farmBingoData.sendTrackingData(4476);

                            // 卡賓果活動結束，在儲值成功後解鎖
                            this._acquireEventEndSemaphore();

                            // 埋點使用紀錄從哪邊從哪邊去儲值
                            this._buyPassFromWhere = BasePassBuyFromWhere.BUY_PASS_DIALOG;
                        },
                    });
                    break;
                case BasePassDialogType.GET_REWARD:
                    dialog = new BasePassGetRewardDialog(this._config, param.msgArray);
                    dialog.setCloseCallback(() => {
                        // 加loading
                        this.setLoadingSprite(true, true);

                        // 重要資料
                        DataModal.farmBingoData.startGetPassInfo();
                    });
                    break;
                case BasePassDialogType.NOT_RECHARGE_GET_REWARD:
                    // 埋點：跳出未儲值獲獎 dialog 4535
                    DataModal.farmBingoData.sendTrackingData(4535);
                    dialog = new BasePassNotChargeGetRewardDialog(this._config, {
                        purchaseParam: purchaseParam,
                        rechargeRewardArray: param.rechargeRewardArray,
                        msgArray: param.msgArray,
                        purchaseBtnOnClick: (sender) => {
                            // 埋點：點擊未儲值獲獎Dialog儲值按鈕 4536
                            sender && DataModal.farmBingoData.sendTrackingData(4536);

                            // 卡賓果活動結束，在儲值成功後解鎖
                            this._acquireEventEndSemaphore();

                            // 埋點使用紀錄從哪邊從哪邊去儲值
                            this._buyPassFromWhere = BasePassBuyFromWhere.NOT_CHARGE_GET_REWARD_DIALOG;
                        },
                    });
                    dialog.setCloseCallback(() => {
                        // 加loading
                        this.setLoadingSprite(true, true);

                        // 重要資料
                        DataModal.farmBingoData.startGetPassInfo();
                    });
                    break;
                case BasePassDialogType.GET_TOKEN:
                    dialog = new BasePassCommonDialog(this._config, {
                        contentText: LocalizedString.FarmBingo("獲得澆水器\n即可累積進度!"),
                        buttonGroup: [
                            () => {
                                let btn = new Texas_Button(Texas_Button.Style.GREEN, cc.size(110, 38), LocalizedString.FarmBingo("前往"));
                                btn.addTouchUpInsideAction(() => {
                                    this._closeDialogAnimation();
                                }, this);
                                return btn;
                            },
                        ],
                        isShowCloseButton: true,
                    });
                    break;
            }

            dialog && this.showDialog(dialog);
        }
    },

    notifyFarmPassInfoDone: function () {
        this._refreshView();
    },

    /**
     * 儲值成功
     */
    notifyPurchaseSuccess: function () {
        this._super();

        // 已經儲值成功，等待過帳完成，先清掉離開提醒資料
        this._param.leaveParam = undefined;
    },

    /**
     * 過帳完成
     */
    notifyFarmPassRechargeDone: function (event) {
        if (event && event.getUserData()) {
            // 埋點：從哪裡儲值成功
            if (this._buyPassFromWhere !== undefined) {
                let trackMap = [];
                trackMap[BasePassBuyFromWhere.MAIN_DIALOG] = 4470;
                trackMap[BasePassBuyFromWhere.BUY_PASS_DIALOG] = 4477;
                trackMap[BasePassBuyFromWhere.NOT_CHARGE_GET_REWARD_DIALOG] = 4537;
                trackMap[BasePassBuyFromWhere.LEAVE_NOTICE_DIALOG] = 4540;
                DataModal.farmBingoData.sendTrackingData(trackMap[this._buyPassFromWhere]);
                this._buyPassFromWhere = undefined;
            }

            let data = event.getUserData();
            let msgArray = data.msgArray;

            // 儲值成功，清除購買資料，避免按關閉按鈕跳出 LeaveNoticeDialog
            DataModal.farmBingoData.passData.purchaseParam = this._param.purchaseParam = undefined;

            // 這邊如果是活動結束才儲值完會同時收到可領獎的獎勵
            if (!data.isEventEnd()) {
                this.showDialog(new BasePassCommonDialog({
                    ...this._config,
                    messageDialogSize: cc.size(280, 153),
                }, {
                    titleText: "#!FFE7A6!#" + LocalizedString.FarmBingo("儲值成功！"),
                    contentText: JSStringUtility.format("#!FFFFFF!#%s #!FFFF00!#%s#!FFFFFF!# +\n%s",
                        LocalizedString.FarmBingo("恭喜獲得（儲值成功dialog）"),
                        msgArray[0],
                        LocalizedString.FarmBingo("恭喜解鎖農場Pass，快來領取豪華獎勵!")
                    ),
                    onCloseCallback: () => {
                        // 表演解鎖動畫
                        this.playUnlockAnimationAsync()
                            .then(() => {
                                // 重要info
                                DataModal.farmBingoData.startGetPassInfo();
                            });
                    }
                }));
            } else {
                let dialog = new BasePassGetRewardDialog(this._config, msgArray);
                dialog.setCloseCallback(() => {
                    // 表演解鎖動畫
                    this.playUnlockAnimationAsync()
                        .then(() => {
                            // 活動結束
                            this._releaseEventEndSemaphore();
                            this.closeDialogAnimation();
                        });
                });
                this.showDialog(dialog);
            }
        }
    },

    /**
     * 儲值失敗，已在 BasePassDialog 監聽
     */
    notifyPurchaseFail: function () {
        this._super();
        this._releaseEventEndSemaphore();
    },

    _acquireEventEndSemaphore: function () {
        // 卡賓果活動結束，在儲值成功後解鎖
        !this._eventEndSemaphoreKey && SemaphoreManager.get("FarmBingoDialogEventEndSemaphore").acquire().then((key) => {
            this._eventEndSemaphoreKey = key;
        });
    },

    _releaseEventEndSemaphore: function () {
        if (this._eventEndSemaphoreKey) {
            SemaphoreManager.get("FarmBingoDialogEventEndSemaphore").release(this._eventEndSemaphoreKey);
            this._eventEndSemaphoreKey = undefined;
        }
    },

    /**
     * 測試用選單
     * @private
     */
    createDebugTestObject: function () {
        return new TestMenuDebugObject("農場 Pass", {
            "pass_info 0 顆": () => DataProcess.sendCustomStringToSelf('farm_bingo_pass_info {"error":"0","stars":"0","img_url":"//d.mwsrv.com/19_60/store/iapp/goods/","pass_unlocked":"0","free_rewards":[{"step":"1","status":"1","goal":"0","pic":"7097","count":"10"},{"step":"2","status":"0","goal":"20","pic":"7097","count":"10"},{"step":"3","status":"0","goal":"30","pic":"7097","count":"10"},{"step":"4","status":"0","goal":"40","pic":"7097","count":"10"}],"pass_rewards":[{"step":"1","status":"0","goal":"0","pic":"7097","count":"10"},{"step":"2","status":"0","goal":"20","pic":"7097","count":"10"},{"step":"3","status":"0","goal":"30","pic":"7097","count":"10"},{"step":"4","status":"0","goal":"40","pic":"7097","count":"10"},{"step":"5","status":"0","goal":"50","pic":"7097","count":"10"}],"recharge_info":{"img_url":"//d.mwsrv.com/19_60/store/iapp/download/payment/ID/","product_list":{"pic":["Google_01.png","Telkomsel_01.png","Codapay_SMS01.png"],"productID":["XXX","OOO"],"top_msg":"AAABBBBCCC"},"button_msg":"15000","value_msg":"999999"},"leave_pop":{"count":"1050000000","pic":"5009"}}'),
            "pass_info 20 顆": () => DataProcess.sendCustomStringToSelf('farm_bingo_pass_info {"error":"0","stars":"20","img_url":"//d.mwsrv.com/19_60/store/iapp/goods/","pass_unlocked":"0","free_rewards":[{"step":"1","status":"2","goal":"0","pic":"7097","count":"10"},{"step":"2","status":"1","goal":"20","pic":"7097","count":"10"},{"step":"3","status":"0","goal":"30","pic":"7097","count":"10"},{"step":"4","status":"0","goal":"40","pic":"7097","count":"10"}],"pass_rewards":[{"step":"1","status":"2","goal":"0","pic":"7097","count":"10"},{"step":"2","status":"1","goal":"20","pic":"7097","count":"10"},{"step":"3","status":"0","goal":"30","pic":"7097","count":"10"},{"step":"4","status":"0","goal":"40","pic":"7097","count":"10"},{"step":"5","status":"0","goal":"50","pic":"7097","count":"10"}],"recharge_info":{"img_url":"//d.mwsrv.com/19_60/store/iapp/download/payment/ID/","product_list":{"pic":["Google_01.png","Telkomsel_01.png","Codapay_SMS01.png"],"productID":["XXX","OOO"],"top_msg":"AAABBBBCCC"},"button_msg":"15000","value_msg":"999999"},"leave_pop":{"count":"1050000000","pic":"5009"}}'),
            "pass_info 有儲": () => DataProcess.sendCustomStringToSelf('farm_bingo_pass_info {"error":"0","stars":"0","img_url":"//d.mwsrv.com/19_60/store/iapp/goods/","pass_unlocked":"1","free_rewards":[{"step":"1","status":"0","goal":"0","pic":"7097","count":"10"},{"step":"2","status":"0","goal":"20","pic":"7097","count":"10"},{"step":"3","status":"0","goal":"30","pic":"7097","count":"10"},{"step":"4","status":"0","goal":"40","pic":"7097","count":"10"}],"pass_rewards":[{"step":"1","status":"0","goal":"0","pic":"7097","count":"10"},{"step":"2","status":"0","goal":"20","pic":"7097","count":"10"},{"step":"3","status":"0","goal":"30","pic":"7097","count":"10"},{"step":"4","status":"0","goal":"40","pic":"7097","count":"10"},{"step":"5","status":"0","goal":"50","pic":"7097","count":"10"}],"recharge_info":{"img_url":"//d.mwsrv.com/19_60/store/iapp/download/payment/ID/","product_list":{"pic":["Google_01.png","Telkomsel_01.png","Codapay_SMS01.png"],"productID":["XXX","OOO"],"top_msg":"AAABBBBCCC"},"button_msg":"15000","value_msg":"999999"},"leave_pop":{"count":"1050000000","pic":"5009"}}'),
            "無儲獲獎 < 6": () => DataProcess.sendCustomStringToSelf('farm_bingo_pass_reward {"msg":["No Can Do 2 Hari"],"locked_reward":{"RP":{"pic":"7011_rp","count":"220"},"tmoney":{"count":"1050500000","pic":"5009"},"normal_item":[{"pic":"6102","count":"3"}]},"error":"0"}'),
            "無儲獲獎 > 6": () => DataProcess.sendCustomStringToSelf('farm_bingo_pass_reward {"msg":["No Can Do 2 Hari"],"locked_reward":{"RP":{"pic":"7011_rp","count":"220"},"tmoney":{"count":"1050500000","pic":"5009"},"normal_item":[{"pic":"6102","count":"3"},{"pic":"6102","count":"3"},{"pic":"6102","count":"3"},{"pic":"6102","count":"3"},{"pic":"6102","count":"3"}]},"error":"0"}'),
            "有儲獲獎 (單一獎勵)": () => DataProcess.sendCustomStringToSelf('farm_bingo_pass_reward {"msg":["No Can Do 2 Hari"],"error":"0"}'),
            "有儲獲獎 (多項獎勵)": () => DataProcess.sendCustomStringToSelf('farm_bingo_pass_reward {"msg":["No Can Do 2 Hari", "No Can Do 2 Hari", "No Can Do 2 Hari", "No Can Do 2 Hari", "No Can Do 2 Hari", "No Can Do 2 Hari", "No Can Do 2 Hari", "No Can Do 2 Hari", "No Can Do 2 Hari", "No Can Do 2 Hari", "No Can Do 2 Hari", "No Can Do 2 Hari"],"error":"0"}'),
            "Leaving dialog": () => this.showDialog(new BasePassLeaveNoticeDialog(this._config, {
                title: JSStringUtility.format(LocalizedString.FarmBingo("恭喜達到%s澆水器"), this._param.tokenCount),
                titleColor: cc.color(255, 231, 166),
                contentTitleText: LocalizedString.FarmBingo("解鎖農場PASS可立即獲得以下獎勵！"),
                contentTitleFontSize: 12,
                chipCount: 123456789000,
                picFileName: 5057,
                purchaseParam: this._param.purchaseParam
            })),
            "PurchaseSuccess": () => GS.dispatchCustomEvent("NotifyPurchaseSuccess"),
            "儲值成功": () => DataProcess.sendCustomStringToSelf('farm_bingo_pass_recharge_done {"can_reward":"1","recharge_reward":["2.2mlr chips"],"error":"0"}'),
            "儲值成功(活動已結束)": () => DataProcess.sendCustomStringToSelf('farm_bingo_pass_recharge_done {"event_reward":["1.1jt chips","530 RP(Koin Luxy)","Pedang Emas 1 Hari","Kupon Multiplayer Sicbo 1 Lembar","Kupon Multiplayer Koprok 4 Lembar","Perisai Poin x 1","[Serpihan]100% Voucher Bonus (Rp. 15,000 ke atas) x 1","Pesta Gembira 2 Hari","No Can Do 2 Hari"],"can_reward":"0","recharge_reward":["1mlr chips"],"error":"0"}'),
            "Parent Semaphore Acquire": () => {
                SemaphoreManager.get("FarmBingoDialogEventEndSemaphore").acquire().then((key) => {
                    this._debugSemaphoreKey = key;
                    console.log("Parent Semaphore Acquired");
                });
            },
            "Parent Semaphore Release": () => {
                SemaphoreManager.get("FarmBingoDialogEventEndSemaphore").release(this._debugSemaphoreKey);
                this._debugSemaphoreKey = undefined;
                console.log("Parent Semaphore Released");
            },
        });
    },
});