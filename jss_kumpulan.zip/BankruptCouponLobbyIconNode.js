/**
 * ID破產儲值禮包(移植 BankruptCouponDialog)
 */

var BankruptCouponLobbyIconNode = LobbyTimeIconNode.extend({
    ctor: function () {
        this._super();

        this.key = "BankruptCouponLobbyIconNode";

        // 註冊通知
        GS.addListener("NotifyShowBankruptCoupon", this.notifyShowBankruptCoupon.bind(this), this);
        GS.addListener("NotifyPurchaseSuccess", this.notifyPurchaseSuccess.bind(this), this);
    },

    onExit: function () {
        this._loadFileDone && cc.spriteFrameCache.removeSpriteFramesFromFile("lobby/lobby_coupons.plist");

        this._super();
    },

    /**
     * 刷新畫面
     */
    _refreshView: function () {
        var bankruptCouponParam = DataModal.purchaseCouponData.bankruptCouponParam;
        var remainTime = bankruptCouponParam.countdownTime - JSCodeUtility.getNowTime();
        if (!bankruptCouponParam || remainTime <= 0) {
            // 如果沒資料或是倒數結束就關掉
            this.setVisible(false);
            return;
        }

        // 加Resources的Function
        var resources = ["lobby/lobby_coupons.plist", "lobby/lobby_coupons.png"];

        // 加Icon的Function
        var addIconFunc = () => {
            // 讀取Plist
            cc.spriteFrameCache.addSpriteFrames(resources[0], resources[1]);
            this._loadFileDone = true;

            // 將畫面清除
            var mainNode = this._mainNode;
            mainNode.removeAllChildren();

            // icon
            var iconSp = new cc.Sprite("#bankrupt_icon_moneyBag.png");
            iconSp.setScale(0.8);
            mainNode.addChild(iconSp);

            // 倒數剩餘秒數
            if (remainTime > 0) {
                // 加入倒數時間
                this.createTimeLabelWithBackground(remainTime,
                    () => {
                        // 倒數完直接隱藏
                        this.setVisible(false);

                        // 關閉dialog
                        GS.dispatchCustomEvent("NotifyBankruptCouponFinish");
                    },
                    (remainTime) => {
                        // 將時間轉換成剩餘數量
                        this.timeLabel.setString(Math.ceil(remainTime / 5));

                    }
                );
            }

            // 設定顯示
            this.setVisible(true);
        };

        if (cc.sys.isNative || cc.textureCache.getTextureForKey(resources[1])) {
            addIconFunc();
        } else {
            // H5要先Loader
            cc.loader.load(resources, function () {
                addIconFunc();
            });
        }
    },

    /**
     * 點擊跳出Dialog
     */
    _iconClicked: function () {
        var dialog = new BankruptCouponDialog();
        dialog.setOpenWorldPosition(this.convertToWorldSpace(cc.p(0, 0)));
        DialogManager.addDialog(dialog);
    },

    /**
     * 通知showIcon
     */
    notifyShowBankruptCoupon: function () {
        this._refreshView();
    },

    /**
     * 通知購買完成
     */
    notifyPurchaseSuccess: function () {
        this.setVisible(false);
        this.timeLabel && this.timeLabel.clearTimer();
    }
});