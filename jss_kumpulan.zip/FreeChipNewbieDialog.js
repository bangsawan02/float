/**
 * v5.4.4 FreeChip - 教學提示
 * 目前FreeChip icon固定在最後一個位置 如果有調整位置這邊在做變更
 * created by lichieh on 2022/9/30
 */
var FreeChipNewbieDialog = BaseDialogLayer.extend({
    ctor: function (pos = cc.p(472 + JSScreenBonusWidth, 24)) {
        this._super();

        this.key = "FreeChipNewbieDialog";

        this.openNeedAnimation = false;

        this.isLockBackKey = true;

        var btnSize = cc.size(45, 35);

        // 用來當底的Node
        var node = new ccui.Scale9Sprite();
        node.setContentSize(btnSize);

        // 主要放東西的node
        var mainNode = new cc.Node();
        mainNode.setCascadeColorEnabled(true);
        mainNode.setCascadeOpacityEnabled(true);
        mainNode.setPosition(btnSize.width / 2, btnSize.height / 2);
        node.addChild(mainNode);

        // icon
        var iconSp = new cc.Sprite("#lobby_icon_free_chip.png");
        iconSp.setPosition(0, 2);
        mainNode.addChild(iconSp);

        // Free Chip文字
        var wordSp = new cc.Sprite("#lobby_word_free_chip.png");
        wordSp.setPosition(0, -12);
        mainNode.addChild(wordSp);

        // 小紅點
        var badgeNode = new BadgeNode();
        badgeNode.useDefaultStyle();
        badgeNode.setPosition(14, 13);
        mainNode.addChild(badgeNode);

        // 假的按鈕
        var freeChipBtn = this._freeChipBtn = new GSControlButton(node, btnSize);
        freeChipBtn.setPosition(pos);
        freeChipBtn.addTouchUpInsideAction(this._freeChipBtnClicked, this);
        this.addChild(freeChipBtn);

        // 訊息
        var message = LocalizedString.FreeChip("點我看領獎秘訣！");
        var messageLabel = new cc.LabelTTF(message, JSFontBoldName, 12);
        messageLabel.setFontFillColor(JSColor.BLACK);

        var param = {
            mainNode: messageLabel,
            style: 3,
            direct: BaseMessageNode.Direct.RIGHT,
            isFlip: false,
            arrowPadding: 0,
            closeCallback: () => {
                // 清掉紀錄
                this._messageNode = undefined;
                this._freeChipBtnClicked();
            }
        };
        var msg = this._messageNode = new BaseMessageNode(param);
        msg.setPosition(pos.x - 20, pos.y);
        msg.show(3, false);
        this.addChild(msg);

        GS.dispatchCustomEvent("NotifySetChatRoomVisible", false);
    },

    /**
     * 點擊icon
     */
    _freeChipBtnClicked: function () {
        this.setVisible(false);

        // 停止泡泡框動畫
        this._messageNode && this._messageNode.getAnimationNode().stopAllActions();

        var dialog = new FreeChipDialog();
        dialog.setCloseCallback(() => {
            // 恢復彈跳
            DialogManager.resumeShowDialog();

            DialogManager.setAllDialogVisible(true);
        });
        DialogManager.addDialog(dialog, false);

        GS.dispatchCustomEvent("NotifySetChatRoomVisible", true);

        this.closeDialogAnimation();
    }
});