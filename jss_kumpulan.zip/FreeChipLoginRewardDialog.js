/**
 * v5.4.3 特定時段登入獎勵 - 主Dialog
 * cmd: https://hackmd.io/@Vic-wu/id543
 * created by lichieh on 2022/8/23
 */
var FreeChipLoginRewardDialog = BaseDialogLayer.extend({
    ctor: function () {
        this._super();

        this.key = "FreeChipLoginRewardDialog";

        // 需要讀取的素材
        this.loadFileArray = ["lobby/freeChip/freeChip_loginReward.plist", "lobby/freeChip/freeChip_loginReward.png"];
    },

    onExit: function () {
        this._loadFileDone && cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[0]);

        // 繼續可以跳其他Dialog
        DialogManager.resumeShowDialog();

        this._super();
    },

    // 載入
    loadFileDone: function () {
        this._super();

        cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[0], this.loadFileArray[1]);

        var aniLayer = this._animationLayer;

        this._giftGrayArray = [];
        this._labelArray = [];
        this._rewardAreaBtnArray = [];
        this._getRewardIndex = -1;      // 領獎時要送的編號 0:早上 1:中午 2:下午

        // 放金幣使用
        var coinNode = new cc.Node();
        aniLayer.addChild(coinNode);
        // 噴金幣動畫
        gaf.create("gaf/reward_coins_03.gaf", this, true, (gafAsset) => {
            if (!gafAsset)
                return;

            for (var i = 0; i < 2; i++) {
                var gafObject = gafAsset.createObjectAndRun(true);
                gafObject.setPosition(94 + i * 331 + JSScreenBonusHalfWidth, 164 + JSScreenBonusHalfHeight);
                gafObject.setScale(-2 * i + 1, 1);
                coinNode.addChild(gafObject);
            }
        });

        // 創背景
        for (var i = 0; i < 2; i++) {
            // 背景光
            var bgLightSprite = new cc.Sprite("#loginReward_pic_bg_02.png");
            bgLightSprite.setPosition(160 + 185 * i + JSScreenBonusHalfWidth, 133 + JSScreenBonusHalfHeight);
            aniLayer.addChild(bgLightSprite);

            // 背景
            var bgSprite = new cc.Sprite("#loginReward_pic_bg.png");
            bgSprite.setScale(-2 * i + 1, 1);
            bgSprite.setAnchorPoint(1, 0.5);
            bgSprite.setPosition(JSScreenMidPos.x - i, JSScreenMidPos.y);
            aniLayer.addChild(bgSprite);

            // 左邊的雞 右邊的禮物盒
            var itemSprite = new cc.Sprite(JSStringUtility.format("#loginReward_pic_item_0%d.png", i + 1));
            itemSprite.setPosition(101 + 304 * i + JSScreenBonusHalfWidth, 119 - i * 13 + JSScreenBonusHalfHeight);
            aniLayer.addChild(itemSprite);
        }

        // 三時段領獎點擊區
        var btnMainNodeArray = [];
        for (var i = 0; i < 3; i++) {

            // 放btn物件的node
            var btnSize = cc.size(90, 107);
            var btnMainNode = btnMainNodeArray[i] = new cc.Node();

            // 背景框
            var frameSprite = new ccui.Scale9Sprite("loginReward_pic_frame_02.png");
            frameSprite.setCapInsets(cc.rect(30, 20, 15, 8));
            frameSprite.setPreferredSize(btnSize);
            btnMainNode.addChild(frameSprite);

            // 禮物標題框
            var giftFrameSprite = new ccui.Scale9Sprite("loginReward_pic_frame_01.png");
            giftFrameSprite.setPreferredSize(cc.size(84, 26));
            giftFrameSprite.setPositionY(61);
            btnMainNode.addChild(giftFrameSprite);

            // 禮物
            var giftSprite = new cc.Sprite(JSStringUtility.format("#loginReward_pic_gift_0%d.png", i + 1));
            giftSprite.setPositionY(1);
            btnMainNode.addChild(giftSprite);

            // 禮物標題
            var giftTitleSprite = new cc.Sprite(JSStringUtility.format("#loginReward_word_period_0%d.png", i + 1));
            giftTitleSprite.setPosition(1, 61);
            btnMainNode.addChild(giftTitleSprite);

            // 領獎區按鈕
            var rewardAreaBtn = this._rewardAreaBtnArray[i] = new GSControlButton(btnMainNode, btnSize);
            rewardAreaBtn.setChangeColorWhenDisabled(false);
            rewardAreaBtn.addTouchUpInsideAction(this._getRewardBtnClicked, this);
            rewardAreaBtn.setPosition(164 + 92 * i + JSScreenBonusHalfWidth, 129 + JSScreenBonusHalfHeight);
            aniLayer.addChild(rewardAreaBtn);
        }

        // 標題
        var titleSprite = new cc.Sprite("#loginReward_word_title.png");
        titleSprite.setPosition(JSScreenMidPos.x, 242 + JSScreenBonusHalfHeight);
        aniLayer.addChild(titleSprite);

        // 閃爍的LED燈
        var posArray = [
            [cc.p(141, 236), cc.p(116, 236), cc.p(98, 217), cc.p(99, 191), cc.p(102, 161)],
            [cc.p(371, 236), cc.p(396, 236), cc.p(413, 217), cc.p(412, 191), cc.p(410, 161)]
        ];
        var bonusPos = cc.p(JSScreenBonusHalfWidth, JSScreenBonusHalfHeight);
        for (var j = 0; j < 2; j++) {
            var bigLightSprite = new cc.Sprite("#loginReward_pic_light.png");
            bigLightSprite.setPosition(posArray[j][0]);
            aniLayer.addChild(bigLightSprite);

            bigLightSprite.runAction(cc.sequence(
                cc.delayTime(0.1), cc.fadeOut(0.1), cc.moveTo(0.1, cc.pAdd(bonusPos, posArray[j][1])).easing(cc.easeSineIn(1)), cc.fadeIn(0.1),
                cc.delayTime(0.1), cc.fadeOut(0.1), cc.moveTo(0.1, cc.pAdd(bonusPos, posArray[j][2])).easing(cc.easeSineIn(1)), cc.fadeIn(0.1),
                cc.delayTime(0.1), cc.fadeOut(0.1), cc.moveTo(0.1, cc.pAdd(bonusPos, posArray[j][3])).easing(cc.easeSineIn(1)), cc.fadeIn(0.1),
                cc.delayTime(0.1), cc.fadeOut(0.1), cc.moveTo(0.1, cc.pAdd(bonusPos, posArray[j][4])).easing(cc.easeSineIn(1)), cc.fadeIn(0.1),
                cc.delayTime(0.1), cc.fadeOut(0.1), cc.moveTo(0.1, cc.pAdd(bonusPos, posArray[j][0])).easing(cc.easeSineIn(1)), cc.fadeIn(0.1)).repeatForever());
        }

        // 文字區
        for (var i = 0; i < 3; i++) {
            var btnMainNode = btnMainNodeArray[i];
            this._labelArray[i] = {};

            // 時間文字
            var timeLabel = this._labelArray[i].timeLabel = new cc.LabelTTF("", JSFontName, 10);
            timeLabel.setFontFillColor(cc.color(189, 53, 0));
            timeLabel.setPositionY(34);
            btnMainNode.addChild(timeLabel);

            // 獎勵文字
            var rewardLabel = this._labelArray[i].rewardLabel = new cc.LabelTTF("", JSFontName, 9);
            rewardLabel.setPositionY(-40);
            btnMainNode.addChild(rewardLabel);
        }

        // 關閉按鈕
        var closeBtn = ButtonUtility.createSimpleImageButton("lobby_btn_circle_04.png", null, "#lobby_btn_pic_window_x.png");
        closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
        closeBtn.setPosition(422 + JSScreenBonusHalfWidth, 233 + JSScreenBonusHalfHeight);
        aniLayer.addChild(closeBtn, 20);

        // 領獎按鈕
        let getRewardBtn = this._getRewardBtn = new Texas_Button(Texas_Button.Style.GREEN, cc.size(85, 32), LocalizedString.FreeChip("領取"));
        getRewardBtn.setPosition(JSScreenMidPos.x, 50 + JSScreenBonusHalfHeight);
        getRewardBtn.addTouchUpInsideAction(this._getRewardBtnClicked, this);
        getRewardBtn.setChangeColorWhenDisabled(false);
        aniLayer.addChild(getRewardBtn);

        // 埋點：2:進入頁面
        DataProcess.sendString("track_period_login_bonus 2");

        // 埋點：5253 >=5.7.0 進入特定時段登入獎勵
        TexasUtility.sendUserAnalyticsTrack(5253);

        this._refreshView();

        // 註冊通知
        GS.addListener("NotifyFreeChipLoginInfoDone", this.notifyFreeChipLoginInfoDone.bind(this), this);
        GS.addListener("NotifyFreeChipLoginRefreshStatus", this.notifyFreeChipLoginInfoDone.bind(this), this);
    },

    addLoadingLayer: function () {
        var aniLayer = this._animationLayer;

        // 加之前先檢查有沒有加過，有的話要拿掉
        this.removeLoadingLayer();

        var loadingLayer = this._loadingLayer = new DummyTouchLayer(JSVisibleSize);
        aniLayer.addChild(loadingLayer, 10);

        // 加讀取
        var loadingColorLayer = new cc.LayerColor(this.dialogBgColor, JSVisibleSize.width, JSVisibleSize.height);
        loadingLayer.addChild(loadingColorLayer);

        // 讀取sprite
        var loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(JSScreenMidPos);
        loadingSprite.start();
        loadingLayer.addChild(loadingSprite);
    },

    /**
     * 刷新畫面
     */
    _refreshView: function () {
        this.removeLoadingLayer();

        var data = DataModal.freeChipsData.loginInfo;
        if (!data.isOpen) {
            this._closeDialogAnimation();
            return;
        }

        var isCanReward = false;
        this._getRewardIndex = -1;
        for (var i = 0; i < 3; i++) {
            // 先關時段領獎區點擊
            this._rewardAreaBtnArray[i].setEnabled(false);

            if (!data.taskList[i])
                continue;

            var offsetX = 92 * i;

            // 刷新獎勵狀態
            var status = data.taskList[i].status;
            switch (status) {
                case FreeChipsData.loginStatus.TimeOver:
                case FreeChipsData.loginStatus.FinishReward:
                    // 已過期(壓黑+過期文字)
                    // 已領獎(壓黑+打勾)

                    if (!this._giftGrayArray[i]) {
                        var aniLayer = this._animationLayer;

                        var grayNode = this._giftGrayArray[i] = new cc.Node();
                        aniLayer.addChild(grayNode);

                        // 灰框
                        var giftGrayFrameSprite = new ccui.Scale9Sprite("loginReward_pic_frame_03.png");
                        giftGrayFrameSprite.setCapInsets(cc.rect(20, 14, 41, 8));
                        giftGrayFrameSprite.setPreferredSize(cc.size(78, 80));
                        giftGrayFrameSprite.setPosition(164 + offsetX + JSScreenBonusHalfWidth, 139 + JSScreenBonusHalfHeight);
                        grayNode.addChild(giftGrayFrameSprite);

                        // 上面要放的圖
                        var statusSprite = this._giftGrayArray[i].statusSprite = new cc.Sprite();
                        statusSprite.setPosition(164 + offsetX + JSScreenBonusHalfWidth, 134 + JSScreenBonusHalfHeight);
                        grayNode.addChild(statusSprite);
                    }

                    var statusPic = (status === FreeChipsData.loginStatus.TimeOver) ? "loginReward_word_miss.png" : "lobby_pic_check_02.png";
                    this._giftGrayArray[i].statusSprite.setSpriteFrame(statusPic);
                    this._giftGrayArray[i].setVisible(true);
                    break;


                case FreeChipsData.loginStatus.CanReward:
                case FreeChipsData.loginStatus.HaveTime:
                    // 可領獎
                    // 時間未到

                    // 關掉壓黑
                    this._giftGrayArray[i] && this._giftGrayArray[i].setVisible(false);

                    // 可以領獎
                    if (status === FreeChipsData.loginStatus.CanReward) {
                        isCanReward = true;
                        this._getRewardIndex = i;

                        // 該時段領獎區可點擊
                        this._rewardAreaBtnArray[i].setEnabled(true);
                    }
                    break;
            }

            // 獎勵文字
            this._labelArray[i].rewardLabel.setString(data.taskList[i].rewardString);
            // 時間文字
            this._labelArray[i].timeLabel.setString(data.taskList[i].timeString);
        }

        // 刷新領取按鈕
        this._getRewardBtn.setEnabled(isCanReward);
        this._getRewardBtn.setBtnString(isCanReward ? LocalizedString.FreeChip("領取") : LocalizedString.FreeChip("等待中"));
        this._getRewardBtn.setBtnStyle(
            isCanReward ? Texas_Button.Style.GREEN : Texas_Button.Style.GRAY,
            cc.size(isCanReward ? 85 : 140, 32)
        );
    },

    /**
     * An返回
     */
    keyBackPressed: function () {
        this._closeBtnClicked();
    },

    /**
     * 點擊領獎按鈕
     */
    _getRewardBtnClicked: function (sender) {
        // 領獎
        if (this._getRewardIndex === -1)
            return;

        this.addLoadingLayer();

        // 送出領獎 0:早上 1:中午 2:下午
        DataProcess.sendString("period_login_bonus_reward " + this._getRewardIndex);

        // 點擊時間區塊，額外埋點 14
        if (this._rewardAreaBtnArray.indexOf(sender) >= 0)
            DataProcess.sendString("track_period_login_bonus 14");

        // 埋點：5254 >=5.7.0點擊領取獎勵 (不包含關閉按鈕自動幫領)
        if (!sender.isFromCloseBtn) {
            TexasUtility.sendUserAnalyticsTrack(5254);
        }

        // 送過就重置，讓Dialog可以關閉
        this._getRewardIndex = -1;
    },

    /**
     * 點擊關閉按鈕
     */
    _closeBtnClicked: function () {
        // 可以領獎，幫領獎
        if (this._getRewardIndex !== -1) {
            var dialog = new Dialog({
                bgSize: cc.size(320, 200),
                content: LocalizedString.FreeChip("您有獎勵未領\n小幫手自動領獎喔！"),
                closeButton: 0,
                callback: () => {
                    // 去領獎
                    this._getRewardBtnClicked({isFromCloseBtn: true});
                }
            });

            this._animationLayer.addChild(dialog, 10000);
            dialog.startDialogAnimation();

            // 埋點 10:跳出幫忙領獎Dialog
            DataProcess.sendString("track_period_login_bonus 10");
        } else
            this._closeDialogAnimation();
    },

    /**
     * 通知收到資料
     */
    notifyFreeChipLoginInfoDone: function () {
        this._refreshView();
    }
});