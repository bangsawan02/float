/**
 * 9T 幸運彩票電腦選號dialog
 */
var BigLotteryAutoSelectDialog = BaseDialogLayer.extend({
    ctor: function () {
        this._super();

        this.key = "BigLotteryAutoSelectDialog";
        var bigLotteryStr = LocalizedString.BigLottery;

        var animLayer = this._animationLayer;

        // 抓資料
        var myTicketParam = DataModal.bigLotteryData.myTicketParam;
        this._notSelectTicketNum = myTicketParam.notSelectTicketNum;
        this._currentTicketNum = this._notSelectTicketNum;

        // Domino移植設定 背景拉寬
        // 背景
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(cc.size(376, 160));
        bgSprite.setPosition(JSScreenMidPos);
        animLayer.addChild(bgSprite);

        // 標題
        var titleSprite = new cc.Sprite("#bigLottery_word_autoSelect.png");
        titleSprite.setPosition(JSScreenMidPos.x, 197 + JSScreenBonusHalfHeight);
        animLayer.addChild(titleSprite);

        // 文字: 請選擇電腦選張數
        var hintLabel = new cc.LabelTTF(bigLotteryStr("請選擇電腦選號張數"), JSFontName, 14);
        hintLabel.setPosition(JSScreenMidPos.x, 165 + JSScreenBonusHalfHeight);
        animLayer.addChild(hintLabel);

        // 數量背景
        var numBgSprite = new ccui.Scale9Sprite("bg_04.png");
        numBgSprite.setPreferredSize(cc.size(65, 30));
        numBgSprite.setPosition(JSScreenMidPos.x, 133 + JSScreenBonusHalfHeight);
        animLayer.addChild(numBgSprite);

        // 目前多少張
        var numLabel = this._numLabel = new cc.LabelTTF(this._currentTicketNum, JSFontName, 14);
        numLabel.setPosition(JSScreenMidPos.x, 134 + JSScreenBonusHalfHeight);
        animLayer.addChild(numLabel);

        // 按鈕
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        animLayer.addChild(menu);

        // 最小最大加減按鈕
        var btnStrings = ["最小", "最大"].map(string => bigLotteryStr(string));
        var btnStringColors = [cc.color(0, 35, 90, 255), cc.color(0, 35, 90, 255), cc.color(45, 45, 45, 255)];
        var btnBgImages = ["lobby_btn_03.png", "lobby_btn_03.png", "lobby_btn_03.png"];
        var btnImages = ["#bigLottery_pic_minor.png", "#bigLottery_pic_plus.png"];
        this._btnArray = [];
        for (var i = 0; i < 2; i++) {
            // 最小最大按鈕
            var itemNode = ButtonUtility.createArrayScale9Nodes(btnBgImages, cc.size(60, 30), [btnStrings[i]], 8);
            itemNode.forEach((node, index) => node.label.enableStroke(btnStringColors[index], 2));
            var menuItem = this._btnArray[i * 2] = new cc.MenuItemSprite(itemNode[0], itemNode[1], itemNode[2], this._operateClicked, this);
            menuItem.setPosition(158 + i * 201 + JSScreenBonusHalfWidth, 134 + JSScreenBonusHalfHeight);
            menu.addChild(menuItem);

            // 加減按鈕
            itemNode = ButtonUtility.createSingleScale9SpriteNodes(btnBgImages, cc.size(30, 30), [btnImages[i]]);
            menuItem = this._btnArray[i * 2 + 1] = new cc.MenuItemSprite(itemNode[0], itemNode[1], itemNode[2], this._operateClicked, this);
            menuItem.setPosition(205 + i * 105 + JSScreenBonusHalfWidth, 134 + JSScreenBonusHalfHeight);
            menu.addChild(menuItem);
        }

        // 確定按鈕
        var itemNode = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", cc.size(85, 35), "OK", 16);
        itemNode.forEach(cur => cur.label.enableStroke(cc.color(0, 35, 90, 255), 2));
        var confirmBtn = new cc.MenuItemSprite(itemNode[0], itemNode[1], itemNode[2], this._confirmClicked, this);
        confirmBtn.setPosition(JSScreenMidPos.x, 90 + JSScreenBonusHalfHeight);
        menu.addChild(confirmBtn);

        // 關閉按鈕
        var closeBtnNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_circle_04.png", null, "#lobby_btn_pic_window_x.png");
        var closeBtn = new cc.MenuItemSprite(closeBtnNodes[0], closeBtnNodes[1], this._closeButtonClicked, this);
        closeBtn.setPosition(cc.pAdd(JSScreenMidPos, cc.p(bgSprite.width / 2 - 5, bgSprite.height / 2 - 5)));
        menu.addChild(closeBtn);

        // 刷新畫面
        this._refreshView();

        // 註冊通知
        GS.addListener("NotifyBigLotteryAutoSelectResult", this.notifyBigLotteryAutoSelectResult.bind(this), this);
    },

    /**
     * 刷新畫面
     */
    _refreshView: function () {
        var current = this._currentTicketNum;

        // 判斷最小最大
        var isMin = current === 1;
        var isMax = current === this._notSelectTicketNum;

        // 調整按鈕狀態
        this._btnArray.forEach((btn, index) => {
            btn.setEnabled((index < 2) ? !isMin : !isMax);
        });
    },

    /**
     * 按鈕
     */

    /**
     * Android Back Key
     * @override
     */
    keyBackPressed: function () {
        this._closeButtonClicked();
    },

    /**
     * 點擊關閉按鈕
     */
    _closeButtonClicked: function () {
        MusicUtility.playEffect("Music/Effect/e_clickButton.mp3", false);

        // 關掉dialog
        this._closeDialogAnimation();
    },

    /**
     * 點擊加減最大最小按鈕
     */
    _operateClicked: function (sender) {
        MusicUtility.playEffect("Music/Effect/e_clickButton.mp3", false);

        var btnArray = this._btnArray;

        switch (sender) {
            // 最小按鈕
            case btnArray[0]:
                this._currentTicketNum = 1;
                break;

            // 減少按鈕
            case btnArray[1]:
                this._currentTicketNum = Math.max(this._currentTicketNum - 1, 1);
                break;

            // 最大按鈕
            case btnArray[2]:
                this._currentTicketNum = this._notSelectTicketNum;
                break;

            // 增加按鈕
            case btnArray[3]:
                this._currentTicketNum = Math.min(this._currentTicketNum + 1, this._notSelectTicketNum);
                break;
        }

        // 刷新中間數字
        this._numLabel.setString(this._currentTicketNum);

        // 刷新狀態
        this._refreshView();
    },

    /**
     * 點擊確認按鈕
     */
    _confirmClicked: function () {
        MusicUtility.playEffect("Music/Effect/e_clickButton.mp3", false);

        // 通知server
        DataProcess.sendString(JSStringUtility.format("big_lottery_auto_choose %d", this._currentTicketNum));

        var animLayer = this._animationLayer;

        // add loading
        var loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(JSScreenMidPos);
        animLayer.addChild(loadingSprite, 10);

        // 擋touch
        var dummyTouchLayer = new DummyTouchLayer(cc.size(JSVisibleSize.width, 254 + JSScreenBonusHalfHeight));
        animLayer.addChild(dummyTouchLayer, 10);
    },

    /**
     * 通知
     */
    // 通知收到自動選號結果
    notifyBigLotteryAutoSelectResult: function (event) {
        if (event && event.getUserData()) {
            var param = event.getUserData();

            // 拿掉loading
            this._loadingSprite && this._loadingSprite.removeFromParent();

            // 關掉畫面
            this._closeDialogAnimation();

            var bigLotteryStr = LocalizedString.BigLottery;

            if (param.isSuccess) {
                // 跳成功選票dialog
                var param = {
                    key: "BigLotteryCommonDialog",
                    bgSize: cc.size(410, 170), // Domino移植設定 背景拉寬
                    content: JSStringUtility.format(bigLotteryStr("您的%d張彩票已選號完畢\n快去『我的彩票』頁看看吧!"), param.ticketNum),
                    buttons: [bigLotteryStr("馬上前往")],
                    callback: () => {
                        // 通知要切到我的彩券頁面
                        var page = BigLotteryLayer.PageType.MY_TICKET_PAGE;
                        GS.dispatchCustomEvent("NotifyBigLotteryChangePage", page);
                    },
                    needFlower: true,
                };
                DialogManager.addDialog(new BigLotteryCommonDialog(param), false);

                MusicUtility.playEffect("Music/Effect/Domino/bigLottery/bigLottery_selectComplete.mp3", false);
            } else {
                // 跳錯誤dialog
                var param = {
                    key: "BigLotteryCommonDialog",
                    bgSize: cc.size(290, 170),
                    content: bigLotteryStr("發生錯誤"),
                    buttons: ["OK"],
                };
                DialogManager.addDialog(new BigLotteryCommonDialog(param), false);
            }

            // 重要資料
            DataProcess.sendString("big_lottery_my_ticket");
        }
    },
});
