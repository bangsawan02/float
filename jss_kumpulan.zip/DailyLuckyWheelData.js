/**
 * 每日簽到輪盤資料
 */
var DailyLuckyWheelData = cc.Class.extend({
    ctor: function () {
        // 初始化
        this.clean();

        // 註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            "lucky_wheel_icon_status": this.cmd_lucky_wheel_icon_status,               // 登入獎勵輪盤 大廳的icon 資訊
            "lucky_wheel_info": this.cmd_lucky_wheel_info,                             // 登入獎勵輪盤 轉盤、VIP、Bonus的資訊
            "lucky_wheel_run": this.cmd_lucky_wheel_run,                               // 登入獎勵輪盤 按下SPIN按鈕後的結算資訊
            "lucky_wheel_push_set": this.cmd_lucky_wheel_push_set                      // 登入獎勵輪盤 開關推播按鈕
        });
    },

    // 清空資料
    clean: function () {
        this.isEventOpen = false;                               // 活動是否開啟
        this.isInfoSuccess = false;                             // info的資料是否正確
        this.today = 0;                                         // 簽到第幾天
        this.nowVip = 1;                                        // 目前vip等級
        this.rewardStatus = 0;                                  // 領獎狀態 0:未完成任務 1:完成未領 2:已領獎
        this.leftTime = 0;                                      // 換天時間
        this.wheelAwardList = [];                               // 轉盤上金額
        this.dayBonusList = [];                                 // 簽到天數對應獎勵倍率
        this.vipBonusList = [];                                 // vip等級對應獎勵倍率
        this.isPushNotify = true;                               // 輪盤獎勵推播(預設開啟)
    },

    // 抓取進大廳所需要的每日輪盤資訊
    startGetInfo: function () {
        this.clean();

        DataProcess.sendString("lucky_wheel_icon_status");
    },

    /**
     * 確認活動是否領獎
     */
    getEventCanReward: function () {
        return this.isEventOpen && this.rewardStatus === DailyLuckyWheelData.STATUS.CAN_GET_REWARD;
    },

    // 抓取處理好的Key 紀錄小紅點用
    getIconClickKey: function () {
        var date = new Date();
        var dateString = JSStringUtility.format("%s-%s-%s", date.getFullYear(), date.getMonth() + 1, date.getDate());       // 生成今天日期字串 getMonth 從0 開始 所以需要+1
        return JSStringUtility.format("%s_DailyLuckyWheelIconClicked_%s", DataModal.profileData.account, dateString);       // 接上帳號/日期
    },

    cmd_lucky_wheel_icon_status: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value);

        // 活動是否開啟 0:關閉 1:開啟
        this.isEventOpen = JSCodeUtility.getBooleanValue(jsonValue["open"]);

        // 簽到狀態(可參照DailyLuckyWheelData.STATUS)
        this.rewardStatus = JSCodeUtility.getIntValue(jsonValue["can_reward"]);

        // 主動跳視窗
        if (JSCodeUtility.getBooleanValue(jsonValue["pop"]))
            GS.dispatchCustomEvent("NotifyShowDailyLuckyWheelDialog");
    },

    /**
     *  登入獎勵 Lucky Wheel
     *  格式參考wiki:https://hackmd.io/@mango314/HyaNRFIDO#%E8%BD%89%E7%9B%A4%E7%8D%8E%E5%8B%B5
     */
    cmd_lucky_wheel_info: function (key, value) {
        var jsonValue = JSON.parse(value);
        
        var isSuccess = this.isInfoSuccess = JSCodeUtility.getIntValue(jsonValue["error"], -1) === 0;
        if (isSuccess) {
            this.today = JSCodeUtility.getIntValue(jsonValue["day"]);                                                   // 簽到第幾天
            this.nowVip = JSCodeUtility.getIntValue(jsonValue["vip"]);                                                  // 目前vip等級
            this.rewardStatus = JSCodeUtility.getIntValue(jsonValue["can_reward"]);                                     // 領獎狀態 0:未完成任務 1:完成未領 2:已領獎
            this.leftTime = JSCodeUtility.getIntValue(jsonValue["time_left"]);                                          // server傳來的剩餘時間
            this.socketTime = JSCodeUtility.getNowTime();                                                               // 收到socket時間
            this.wheelAwardList = (jsonValue["wheel"] || []).map((cur) => JSCodeUtility.getIntValue(cur));              // 轉盤各獎勵數字
            this.dayBonusList = (jsonValue["day_bonus_list"] || []).map((cur) => JSCodeUtility.getFloatValue(cur));     // 簽到天數對應獎勵倍率
            this.vipBonusList = (jsonValue["vip_bonus_list"] || []).map((cur) => JSCodeUtility.getFloatValue(cur));     // vip等級對應獎勵倍率
            this.isPushNotify = JSCodeUtility.getBooleanValue(jsonValue["is_push"]);                                  // 是否推播
        }

        GS.dispatchCustomEvent("NotifyLuckyWheelInfoDone");
    },

    // 輪盤結果
    cmd_lucky_wheel_run: function (key, value) {
        var jsonValue = JSON.parse(value);

        var param = {};
        var error = param.error = JSCodeUtility.getIntValue(jsonValue["error"]);
        if (error === 0) {
            // 正常讀取資料
            param.originalMoney = JSCodeUtility.getIntValue(jsonValue["money"]);
            param.targetIndex = JSCodeUtility.getIntValue(jsonValue["wheel_target"]);
            param.bouns = {
                day: JSCodeUtility.getFloatValue(jsonValue["bonus"]["day"]),
                vip: JSCodeUtility.getFloatValue(jsonValue["bonus"]["vip"])
            };

            // 記下已領獎
            this.rewardStatus = DailyLuckyWheelData.STATUS.GET_REWARD_DONE;
        }

        GS.dispatchCustomEvent("NotifyLuckyWheelRunDone", param);
    },

    // 每日輪盤推播開關
    cmd_lucky_wheel_push_set: function (key, value) {
        var jsonValue = JSON.parse(value);

        var param = {
            success: JSCodeUtility.getIntValue(jsonValue["error"]) === 0,
            isPushNotify: JSCodeUtility.getBooleanValue(jsonValue["is_push"])
        };

        // 送通知
        GS.dispatchCustomEvent("NotifyLuckyWheelPushSetDone", param);
    }
});

// 簽到輪盤狀態
DailyLuckyWheelData.STATUS = {
    NOT_COMPLETE:       0, // 未完成
    CAN_GET_REWARD:     1, // 可領獎
    GET_REWARD_DONE:    2, // 已經領獎
};