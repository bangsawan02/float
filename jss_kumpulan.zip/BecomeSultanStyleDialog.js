/**
 * v5.4.8 成為蘇丹 額外訊息的Dialog
 *
 * create by Wen
 */

var BecomeSultanStyleDialog = BaseDialogLayer.extend({
    ctor: function (message) {
        this._super();
        // 預設值
        this.key = "BecomeSultanStyleDialog";
        this._message = message;

        this.loadFileArray = ["lobby/becomeSultan.plist", "lobby/becomeSultan.png"];
    },

    onExit: function () {
        if (this._loadFileDone)
            cc.spriteFrameCache.removeSpriteFramesFromFile("lobby/becomeSultan.plist");

        this._super();
    },

    /**
     * 讀取素材完畢
     * @override
     */
    loadFileDone: function () {
        this._super();

        cc.spriteFrameCache.addSpriteFrames("lobby/becomeSultan.plist", "lobby/becomeSultan.png");

        var aniLayer = this._animationLayer;

        // 背景底
        var bgSize = cc.size(280, 150);
        var bgSprite = new ccui.Scale9Sprite("becomeSultan_bg_window_02.png");
        bgSprite.setPreferredSize(bgSize);
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite, -1);

        // 內文
        var messageLabel = new GSRichTextNode(this._message, JSFontName, 12, cc.size(300, 0));
        messageLabel.setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        messageLabel.setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        messageLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 10);
        aniLayer.addChild(messageLabel);

        // ok按鈕 = 關閉
        var okBtn = ButtonUtility.createSimpleButton("lobby_btn_01.png", cc.size(95, 24), "OK", JSColor.BLACK, 12.5);
        okBtn.addTouchUpInsideAction(this._closeDialogAnimation, this);
        okBtn.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - bgSize.height / 2 + 30);
        okBtn.label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        aniLayer.addChild(okBtn);

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.addTouchUpInsideAction(this._closeDialogAnimation, this);
        closeBtn.setPosition(JSScreenMidPos.x + bgSize.width / 2 - 10, JSScreenMidPos.y + bgSize.height / 2 - 10);
        aniLayer.addChild(closeBtn);
    },

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        this._closeDialogAnimation();
    }
});