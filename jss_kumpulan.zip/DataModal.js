var DataModal = ({
    init: function () {
        // 一些參數設定

        // 推撥
        this.pushNotification = new PushNotification();
        this.pushNotification.init();

        // Socket用
        this.dataProcess = new DataProcess();

        // 可以共用的 或 只想產生一次的
        this.debugTestData = new DebugTestData();                                       // 測試資料
        this.handleUrlAndNotifyData = new HandleUrlAndNotifyData();                     // 處理URL點進來App或推撥過來的資料

        // Data
        this.achieveData = new AchieveData();                                           // 成就的資料
        this.awardAndMailData = new AwardAndMailData();                                 // 信件領獎整合
        this.bigLotteryData = new BigLotteryData();                                     // 幸運彩票的資料
        this.blacklistData = new BlacklistData();                                       // 黑名單資料
        this.cardKingData = new CardKingData();                                         // 牌王資料
        this.chatData = new ChatData();                                                 // 聊天的資料
        this.chatRoomData = new ChatRoomData();                                          // 好友聊天室
        this.cloneModelData = new CloneModelData();                                     // 分身模組資料
        this.cloudClubData = new CloudClubData();                                       // 風雲會共用資料
        this.continueRechargeData = new ContinueRechargeData();                         // 連續儲值
        this.couponData = new CouponData();                                             // Coupon的資料
        this.dailyLuckyWheelData = new DailyLuckyWheelData();                           // 保留輪盤資料
        this.dailyMissionData = new DailyMissionData();                                 // 每日任務資料
        this.farmBingoData = new FarmBingoData();                                       // 農場賓果
        this.fierceBattleData = new FierceBattleData();                                 // 激戰任務
        this.freeChipsData = new FreeChipsData();                                       // 免費幣整合的資料
        this.friendData = new FriendData();                                             // 好友
        this.gamblerRoadData = new GamblerRoadData();                                   // 牌王之路(5.5.2新版, 舊版為kindRoad)
        this.gameMissionData = new TexasGameMissionData();                              // 9T裡面的遊戲牌王任務資料
        this.gameRankData = new GameRankData();                                         // 積分系統的資料
        this.goldMedalTaskData = new GoldMedalTaskData();                               // 金牌任務
        this.goldenEggsData = new GoldenEggsData();                                     // 金雞抓抓樂
        this.goldRushData = new GoldRushData();                                         // 尋寶抽抽樂
        this.growingMissionData = new GrowingMissionData();                             // 成長任務的資料
        this.guildData = new GuildData();                                               // 公會資料
        this.hotBoardData = new HotBoardData();                                         // 熱門看板
        this.hotfixData = new HotfixData();                                             // InApp活動的資料
        this.koinLuxyData = new KoinLuxyData();                                         // KoinLuxy系統的資料
        this.lobbyActionData = new LobbyActionData();                                   // action_list的資料
        this.lobbyInfo = new LobbyInfo();                                               // 大廳的資料
        this.localNotificationData = new LocalNotificationData();                      // 本地推播資料
        this.loginData = new LoginData();                                               // 登入資訊
        this.lotteryShopData = new LotteryShopData();                                   // 彩券行資料
        this.luckyDiceCollectionData = new LuckyDiceCollectionData();                   // 幸運集集樂資料
        this.luxyPassData = new LuxyPassData();                                         // LuxyPass資料
        this.mapInviteData = new MapInviteData();                                       // 地圖資料
        this.masterPokerData = new MasterPokerData();                                   // 大廳猜手牌遊戲的資料
        this.moodData = new MoodData();                                                 // 互動道具, 表情相關
        this.newbieData = new NewbieData();                                             // 新手教學資料
        this.newsWallData = new NewsWallData();                                         // 新聞牆資料
        this.noviceSignInData = new NoviceSignInData();                                 // 新手簽到資料
        this.phoneToGiftData = new PhoneToGiftData();                                   // 填寫手機資料
        this.playerProfileData = new PlayerProfileData();                               // 玩家個人資料
        this.profileData = new ProfileData();                                           // 個人資訊
        this.purchaseBonusData = new PurchaseBonusData();                               // 轉金樂儲值
        this.purchaseCouponData = new PurchaseCouponData();                             // 衝動儲值的資料
        this.purchaseD0PayData = new PurchaseD0PayData();                               // D0限定優惠
        this.purchaseData = new PurchaseData();                                         // 儲值資訊
        this.purchaseRecommendProductData = new PurchaseRecommendProductData();         // 儲值推薦的相關資料(破產儲值之類的)
        this.purchaseStructuresData = new PurchaseStructuresData();                     // 放置只有單一接收Command的儲值項目
        this.purchaseTriggerIntegrationData = new PurchaseTriggerIntegrationData();     // 儲值觸發整合資訊
        this.ramadanData = new RamadanData();                                           // 齋戒月副系統
        this.rankData = new RankData();                                                 // 排行資料(包含名人堂)
        this.reappearData = new ReappearData();                                         // 牌局重現資料
        this.rebateWalletData = new RebateWalletData();                                 // 超值返利錢包
        this.realVideoData = new RealVideoData();                                       // 視訊/語音資料
        this.regionsData = new RegionsData();                                           // 大廳桌列表資料
        this.reportData = new ReportData();                                             // LuxyPoker檢舉資料
        this.returnMissionData = new ReturnMissionData();                               // 回流任務
        this.returnWelfareData = new ReturnWelfareData();                               // 回流相關
        this.scratchCardData = new ScratchCardData();                                   // 刮刮卡的資料
        this.scratchCardShopData = new ScratchCardShopData();                           // 刮刮樂的資料
        this.serialNumberPrizeData = new SerialNumberPrizeData();                       // 序號兌換獎勵的資料
        this.settingData = new SettingData();                                           // 設定的資料
        this.shardData = new ShardData();                                               // 碎片資料
        this.shopData = new ShopData();                                                 // 商品資訊
        this.signInData = new SignInData();                                             // 簽到系統
        this.slotAgainData = new SlotAgainData();										// 再儲拉霸
        this.stoneGamblingData = new StoneGamblingData();                               // 賭石大師
        this.tokenSubsystemData = new TokenSubsystemData();                             // 代幣副系統 - 夏日慶典
        this.tournamentData = new TournamentData();                                     // 比賽
        this.treasureQuestData = new TreasureQuestData();                               // 奪寶冒險
        this.treasureBowlData = new TreasureBowlData();                                 // 聚寶盆資訊
        this.videoADData = new VideoADData();                                           // 影片廣告的資料
        this.vipData = new VipData();                                                   // VIP資訊
        this.webData = new WebData();                                                   // 接收網頁的指令
        this.puzzleHomeRunData = new PuzzleHomeRunData();                                     // 拼圖家園資料

        // 娛樂城相關
        this.multiBlackjackData = new MultiBlackjackData();                             // 多人21點
        this.pk5Data = new PK5Data();                                                   // PK5資料
        this.pk5VipData = new PK5VipData();                                             // PK5 VIP 資料
        this.vegasCompeteData = new VegasCompeteData();                                 // 機台爭霸賽資料
        this.vegasData = new VegasData();                                               // 娛樂城資料
        this.vegasDragonVsLeopardData = new VegasDragonVsLeopardData();                 // 龍豹對決資料
        this.vegasMapMissionData = new VegasMapMissionData();                           // 地圖式機台任務
        this.vegasNewbieMissionData = new VegasNewbieMissionData();                     // 機台新手任務
        this.vegasRacingData = new VegasRacingData();                                   // 極速競飆

        // 遊戲內部共用的Data 用來對外取用
        this.gameData = null;

        // 是不是從Login進去LobbyLayer
        this.isComeFromLoginScene = false;

        // 上一次產生的遊戲Data 用來砍掉用
        this._oldGameData = null;

        // 紀錄上次的桌子
        this.lastTableGame = undefined;

        // 記錄上一次玩法類型
        this.lastGameType = GSEnum.GameType.NONE;
        this.lastVegasType = VegasGameType.NONE;
    },

    /**
     * 設定GameData
     * @param gameType
     */
    setGameData: function (gameType) {
        // 設定現在什麼遊戲
        GS.nowGame = gameType;
        var isTableGame = true;

        var newGameData = null;
        switch (gameType) {
            case GSEnum.Game.Texas19:
            case GSEnum.Game.Texas:
                // 德撲
                if (gameType === GSEnum.Game.Texas19) {
                    GS.nowGame = GSEnum.Game.Texas;
                    gameType = GSEnum.Game.Texas;
                }

                if (!(this._oldGameData instanceof TexasGameData))
                    newGameData = new TexasGameData();
                break;
            case GSEnum.Game.GapleFriend:
            case GSEnum.Game.GapleChat:
            // Gaple語音
            case GSEnum.Game.Gaple:
                // Gaple
                if (!(this._oldGameData instanceof GapleGameData))
                    newGameData = new GapleGameData();
                break;
            case GSEnum.Game.GapleVideo:
            // Gaple視訊
            case GSEnum.Game.GaplePlus:
                // Gaple加倍
                if (!(this._oldGameData instanceof GaplePlusGameData))
                    newGameData = new GaplePlusGameData();
                break;
            case GSEnum.Game.Domino:
                // Domino
                if (!(this._oldGameData instanceof DominoGameData))
                    newGameData = new DominoGameData();
                break;
            case GSEnum.Game.Remi:
                // Remi
                if (!(this._oldGameData instanceof RemiGameData))
                    newGameData = new RemiGameData();
                break;
            case GSEnum.Game.Cangkulan:
                // CangkulanGameData
                if (!(this._oldGameData instanceof CangkulanGameData))
                    newGameData = new CangkulanGameData();
                break;
            case GSEnum.Game.TebakQQ:
                // TebakQQ 機台
                if (!(this._oldGameData instanceof TebakQQGameData))
                    newGameData = new TebakQQGameData();
                isTableGame = false;
                break;
            case GSEnum.Game.CapsaSusun:
                // CapsaSusun
                if (!(this._oldGameData instanceof CapsaSusunGameData))
                    newGameData = new CapsaSusunGameData();
                break;
            default:
                break;
        }

        // 判斷是否要砍掉舊有的
        if (newGameData) {
            // 砍掉其他GameData
            this._oldGameData && this._oldGameData.destroyGameData();
            // 設定GameData
            this.gameData = this._oldGameData = newGameData;
            if (isTableGame) {
                this.lastTableGame = gameType;
            }
        }

        // 記下現在是牌桌類玩法
        if (GS.nowGame !== GSEnum.Game.TebakQQ)
            DataModal.lastGameType = GSEnum.GameType.TABLE;
    },

    /**
     * 設定最後一次Vegas玩法
     * @param gameType
     */
    setLastVegasType: function (gameType) {
        // 百人骰寶實驗A要額外處理
        if (gameType === VegasGameType.MULTI_DICEBO_TEST_A)
            gameType = VegasGameType.MULTI_DICEBO;

        // 記下玩法
        DataModal.lastVegasType = gameType;
    },

    /**
     * 用來檢查上次的玩法
     */
    checkLastGame: function () {
        if (this.lastTableGame)
            GS.nowGame = this.lastTableGame;
        else
            GS.nowGame = GS.isLuxyPoker ? GSEnum.Game.Texas19 : GSEnum.Game.Domino;
    }
});
