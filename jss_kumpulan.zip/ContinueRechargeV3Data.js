/**
 * 連續儲值 v3 - 金錢瘋暴 - Data
 */
class ContinueRechargeV3Data extends PurchaseTriggerIntegrationDataTemplate {
    constructor() {
        super();
        this.registerSocket({
            "continue_recharge_v3_icon": this.cmd_continue_recharge_v3_icon,
            "continue_recharge_v3_info": this.cmd_continue_recharge_v3_info,
            "continue_recharge_v3_free": this.cmd_continue_recharge_v3_free,
            "continue_recharge_v3_recharge_done": this.cmd_continue_recharge_v3_recharge_done,
        });
    }

    clean() {
        super.clean();
        this._rewardInfoArray = [];
        this.period = null;
    }

    requestIcon() {
        DataProcess.sendString("continue_recharge_v3_icon");
    }

    requestInfo() {
        DataProcess.sendString("continue_recharge_v3_info");
    }

    sendGetFreeReward() {
        DataProcess.sendString("continue_recharge_v3_free");
    }

    /**
     * 更新紅點
     * 儲值整合 icon 每 1s 更新一次
     */
    refreshBadge() {
        // Restore state.
        this.isShowBadge = false;

        if (this.isOpen) {
            // 換天小紅點
            let periodKey = UserDefaultKey.ContinueRechargeV3DailyBadge + DataModal.profileData.account;
            let lastTime = GS.localStorage.getItem(periodKey, "0");
            this.isShowBadge |= TexasUtility.getNowIsChangeDay(lastTime);

            // 儲值剩餘時間剩 2hrs
            if (this.getRemainTime() < 7200) {
                let key = UserDefaultKey.ContinueRechargeV32HrBadge + DataModal.profileData.account;
                let lastShowPeriod = GS.localStorage.getItem(key, "0");
                this.isShowBadge |= lastShowPeriod !== this.period;
            }

            // 是否有免費獎勵可領
            this.isShowBadge |= this._rewardInfoArray[0]?.price === 0;
        }
    }

    /**
     * 紀錄兩小時紅點已顯示
     */
    record2HrBadge() {
        let key = UserDefaultKey.ContinueRechargeV32HrBadge + DataModal.profileData.account;
        GS.localStorage.setItem(key, this.period);
    }

    /**
     * 紀錄每日紅點已顯示
     */
    recordDailyBadge() {
        let key = UserDefaultKey.ContinueRechargeV3DailyBadge + DataModal.profileData.account;
        GS.localStorage.setItem(key, TexasUtility.getNowTimeMillisecondString());
    }

    /**
     * 領獎成功 / 儲值成功後，從獎勵列表中移除第一個
     */
    shiftRewardInfoArray() {
        this._rewardInfoArray.shift();
    }

    /**
     * 關閉活動
     */
    closeEvent() {
        this.clean();

        // 更新小紅點
        this._integrationData.refreshPurchaseActivityRedPoint();

        // 刷畫面
        this._integrationData.updateOpenPurchaseActivityCount();
    }

    /**
     * 獎勵列表
     */
    get rewardInfoArray() {
        return this._rewardInfoArray;
    }

    /**
     * 道具圖片網址
     */
    getItemUrlByWid(wid) {
        return UrlUtils.getWidSpritePaths(wid, this._imgUrl?.goods);
    }

    cmd_continue_recharge_v3_icon(key, value) {
        const jsonValue = JSON.parse(value ?? "{}");

        // 是否成功，有錯 server 不會送
        const isSuccess = this.isSuccessful = JSCodeUtility.getBooleanValue(jsonValue["success"]);

        // 活動提前結束
        let isFinished = false;
        if (isSuccess) {
            isFinished = JSCodeUtility.getBooleanValue(jsonValue["finish"], false);
            // 如果活動結束，關掉活動
            if (isFinished) {
                this.isSuccessful = false;
            }
        }

        // 確定 isSuccess 且 活動沒結束
        if (isSuccess && !isFinished) {
            // 剩餘時間
            this.setRemainTime(JSCodeUtility.getIntValue(jsonValue["remain"], 0));

            // 是否顯示小紅點。無資料時，用塞假資料的方式來顯示小紅點
            if (this._rewardInfoArray.length === 0 && JSCodeUtility.getBooleanValue(jsonValue["redPoint"], false)) {
                this._rewardInfoArray[0] = {price: 0};
            }

            // 分群
            this.group = JSCodeUtility.getIntValue(jsonValue["cluster"]);

            // 走期
            this.period = JSCodeUtility.getStringValue(jsonValue["period"]);

            // 主動彈跳
            if (JSCodeUtility.getBooleanValue(jsonValue["pop"], false)) {
                this.setPopType(PurchaseTriggerIntegrationData.purchaseType.CONTINUE_RECHARGE_V3);
            }
        }

        // 更新小紅點
        this._integrationData.refreshPurchaseActivityRedPoint();

        // 刷畫面
        this._integrationData.updateOpenPurchaseActivityCount();
    }

    cmd_continue_recharge_v3_info(key, value) {
        const jsonValue = JSON.parse(value ?? "{}");

        let param = {
            isSuccess: JSCodeUtility.getBooleanValue(jsonValue["success"]),
            isFinished: JSCodeUtility.getBooleanValue(jsonValue["finish"])
        };

        if (param.isSuccess) {
            // 倒數時間
            this.setRemainTime(jsonValue["timeLeft"]);

            this._imgUrl = param.imgUrl = {
                goods: UrlUtils.normalize(jsonValue["img_url"]?.["goods"], UrlUtils.widIconUrlRoot),
                recharge: UrlUtils.normalize(jsonValue["img_url"]?.["recharge"], UrlUtils.providerUrlRoot),
            };

            // 獎勵內容
            param.rewardInfoArray = this._rewardInfoArray = (jsonValue["plans"] || [])
                .filter(cur => !!cur)
                .map(cur => {
                    return {
                        price: JSCodeUtility.getIntValue(cur["price"]),                 // 價錢
                        purchaseParam: DataModal.purchaseData.processProviderChoosePurchase(cur, param.imgUrl.recharge, ["top_msg", "productID", "pic"]),
                        bonus: JSCodeUtility.getIntValue(cur["bonus"]),                 // 加贈%數
                        rewardList: (cur["rewards"] || []).map(innerCur => {            // 獎項內容
                            return {
                                wid: JSCodeUtility.getStringValue(innerCur["img"]),
                                count: JSCodeUtility.getStringValue(innerCur["name"])
                            };
                        }),
                        trackType: JSCodeUtility.getStringValue(cur["track_type"])      // 埋點
                    };
                });

            // 埋點分群
            this.group = JSCodeUtility.getStringValue(jsonValue["kind"]);
        }

        // 更新小紅點
        this._integrationData.refreshPurchaseActivityRedPoint();

        // 刷畫面
        this._integrationData.updateOpenPurchaseActivityCount();

        // 通知畫面
        GS.dispatchCustomEvent("NotifyContinueRechargeV3InfoDone", param);
    }

    cmd_continue_recharge_v3_free(key, value) {
        const jsonValue = JSON.parse(value ?? "{}");
        const param = {
            isSuccess: JSCodeUtility.getBooleanValue(jsonValue["success"])
        };

        if (param.isSuccess) {
            param.rewardMsg = JSCodeUtility.getStringValue(jsonValue["rewardMsg"]);
        }

        // 通知畫面
        GS.dispatchCustomEvent("NotifyContinueRechargeV3GetFreeRewardDone", param);
    }

    cmd_continue_recharge_v3_recharge_done(key, value) {
        const jsonValue = JSON.parse(value ?? "{}");
        const param = {
            isSuccess: JSCodeUtility.getBooleanValue(jsonValue["success"])
        };

        if (param.isSuccess) {
            param.rewardMsg = JSCodeUtility.getStringValue(jsonValue["rewardMsg"]);
        }

        // 通知畫面
        GS.dispatchCustomEvent("NotifyContinueRechargeV3RechargeDone", param);
    }
}