/**
 * 出牌提示
 */

var Cangkulan_PlayerFoldCardNode = cc.Node.extend({
    ctor: function () {
        this._super();

        var mainNode = this._mainNode = new cc.Node();
        this.addChild(mainNode);

        var msgPos = cc.p(20, 0);
        var msgSp = this._msgSp = new cc.Sprite();
        msgSp.setPosition(msgPos);
        msgSp.setOpacity(200);
        mainNode.addChild(msgSp);

        var lightMsgSp = this._lightMsgSp = new cc.Sprite();
        lightMsgSp.setPosition(msgPos);
        lightMsgSp.setVisible(false);
        mainNode.addChild(lightMsgSp);

        var suitNode = this._suitNode = new cc.Node();
        mainNode.addChild(suitNode);

        var numberLabel = this._numberLabel = new cc.LabelTTF("", JSFontName, 16);
        numberLabel.setFontFillColor(JSColor.RED);
        suitNode.addChild(numberLabel);

        var suitSp = this._suitSp = new cc.Sprite();
        suitNode.addChild(suitSp);

        this.setVisible(false);
    },

    setSitNum: function (serverSitNum) {
        var index = serverSitNum % 2;
        var flip = {};
        var pos;
        switch (serverSitNum) {
            case 0:
                flip.x = false;
                flip.y = true;
                pos = cc.p(10, 5);
                this._shinePos = cc.p(20, 5);
                this._mainNode.setPosition(125, 48);
                break;
            case 1:
                flip.x = false;
                flip.y = false;
                pos = cc.p(15, 0);
                this._shinePos = cc.p(25, 0);
                this._mainNode.setPosition(33, 10);
                break;
            case 2:
                flip.x = false;
                flip.y = false;
                pos = cc.p(10, -5);
                this._shinePos = cc.p(20, -5);
                this._mainNode.setPosition(-60, -53);
                break;
            case 3:
                flip.x = true;
                flip.y = false;
                pos = cc.p(5, 0);
                this._shinePos = cc.p(15, 0);
                this._mainNode.setPosition(-70, 10);
                break;
        }

        this._msgSp.setSpriteFrame("cangkulan_pic_msg_" + index + ".png");
        this._msgSp.setAnchorPoint(0.5, 0.5);
        this._msgSp.setFlippedX(flip.x);
        this._msgSp.setFlippedY(flip.y);

        this._lightMsgSp.setSpriteFrame("cangkulan_pic_msgLight_" + index + ".png");
        this._lightMsgSp.setAnchorPoint(0.5, 0.5);
        this._lightMsgSp.setFlippedX(flip.x);
        this._lightMsgSp.setFlippedY(flip.y);

        this._suitNode.setPosition(pos);
    },

    /**
     * 設定棄掉的牌
     * @param card : 2T
     */
    setPlayerFoldCard: function (card) {
        if (!card)
            this.setVisible(false);
        else {
            // 顯示花色 ＆ 數字
            var suit = card[0];
            var number = card[1];

            // 10跟1顯示會比較特殊
            if (number === "T")
                number = "10";
            else if (number === "1")
                number = "A";
            this._numberLabel.setString(number);

            // 黑色: 梅花、黑桃 紅色: 愛心、方塊
            this._numberLabel.setFontFillColor((suit === "1" || suit === "4") ? JSColor.BLACK : JSColor.RED);
            this._suitSp.setSpriteFrame("cangkulan_pic_suit_" + suit + ".png");
            this._suitSp.setPosition(20, 0);
            this.setVisible(true);
        }
    },

    /**
     * 閃爍動畫
     */
    runShineAsync: function () {
        return new Promise(resolve => {
            this._lightMsgSp.setVisible(true);
            this._lightMsgSp.setOpacity(0);

            // 亮燈
            this._lightMsgSp.runAction(cc.sequence(
                cc.fadeIn(0.2),
                cc.delayTime(0.2),
                cc.hide()
            ));

            // 閃爍
            gaf.create("gaf/game/cangkulan_light.gaf", this, true, (gafAsset) => {
                // GAF播放設定
                var shineGafObject = gafAsset.createObjectAndRun(false);
                shineGafObject.setPosition(this._shinePos);
                this._mainNode.addChild(shineGafObject, 2);

                // 設定播完動畫後的事
                shineGafObject.runAction(cc.sequence(
                    cc.delayTime(0.7),
                    cc.callFunc(() => {
                        resolve();
                    }),
                    cc.removeSelf()
                ));
            });
        });
    }
});