/**
 * 遊戲上方的提示畫面
 */

var Cangkulan_GameHintLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // Queue Array
        this._queueArray = [];

        // 是否在顯示動畫中
        this._isShowing = false;

        // 上方的提示訊息
        this._oldMessageNode = null;

        // 是否正在顯示人生一次的提示訊息
        this._showIntroType = 0;

        //加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: false,
            onTouchBegan: this._onTouchBegan.bind(this)
        }, this);

        // 監聽
        GS.addListener("NotifyShowTopMessage", this.notifyShowTopMessage.bind(this), this);
    },

    clean: function () {
        // 等待其他玩家入桌的提示
        if (this._waitPlayerNode) {
            this._waitPlayerNode.removeFromParent();
            this._waitPlayerNode = null;
        }

        // 牌局開始倒數
        if (this._gameReadyNode) {
            this._gameReadyNode.removeFromParent();
            this._gameReadyNode = null;
        }

        // 等待下一局開始
        if (this._nextRoundNode) {
            this._nextRoundNode.removeFromParent();
            this._nextRoundNode = null;
        }
    },

    /**
     * 開始出現
     */
    _show: function () {
        if (this._queueArray.length === 0 || this._isShowing || this._oldMessageNode)
            return;

        // 讓他出現
        this._isShowing = true;

        var showNode = this._queueArray.shift();
        var height = showNode.getContentSize().height;
        showNode.setAnchorPoint(0.5, 0.5);
        showNode.setVisible(true);
        showNode.setPosition(JSScreenMidPos.x, JSVisibleSize.height + height / 2);
        showNode.runAction(cc.sequence(
            cc.moveBy(0.5, cc.p(0, -height)).easing(cc.easeIn(2)),
            cc.delayTime(2),
            cc.moveBy(0.5, cc.p(0, height)).easing(cc.easeOut(2)),
            cc.callFunc(function () {
                // 設定沒顯示了
                this._isShowing = false;

                // 再跑一次 看有沒有新的
                this._show();
            }, this),
            cc.removeSelf()
        ));
    },


    /**
     * 出現自訂義的畫面
     */
    showWithNode: function (node) {
        this._queueArray.push(node);

        // 把node先加進來 當做retain用
        this.addChild(node);
        node.setVisible(false);

        // 統一給show那邊判斷
        this._show();
    },

    /**
     * 出現等待其他玩家入桌提示
     */
    showWaitPlayerHint: function () {
        if (this._waitPlayerNode) {
            this._waitPlayerNode.removeFromParent();
            this._waitPlayerNode = null;
        }

        var waitPlayerNode = this._waitPlayerNode = new cc.Node();
        this.addChild(waitPlayerNode);

        // 背景
        var bgSprite = new ccui.Scale9Sprite("game_pic_line_purple.png");
        bgSprite.setPreferredSize(cc.size(320, 28));
        bgSprite.setPosition(JSScreenMidPos);
        waitPlayerNode.addChild(bgSprite);

        // 金邊
        var lightArray = [];
        for (var i = 0; i < 2; i++) {
            var vy = JSScreenMidPos.y + 14 - i * 28;

            var lineSp = new ccui.Scale9Sprite("game_pic_line_gold.png");
            lineSp.setPreferredSize(cc.size(310, 2));
            lineSp.setPosition(JSScreenMidPos.x, vy);
            waitPlayerNode.addChild(lineSp);

            var defaultX = JSScreenMidPos.x - 110 + 220 * i;
            var lineLightSp = lightArray[i] = new cc.Sprite("#game_pic_line_reflective.png");
            lineLightSp.setPosition(defaultX, vy);
            waitPlayerNode.addChild(lineLightSp);
        }

        // 金邊動畫
        lightArray[0].runAction(cc.repeatForever(cc.sequence(
            cc.fadeIn(0.2),
            cc.moveBy(1.5, cc.p(220, 0)),
            cc.fadeOut(0.2),
            cc.callFunc(() => {
                lightArray[0].setPositionX(JSScreenMidPos.x - 110);
            })
        )));

        lightArray[1].runAction(cc.repeatForever(cc.sequence(
            cc.fadeIn(0.2),
            cc.moveBy(1.5, cc.p(-220, 0)),
            cc.fadeOut(0.2),
            cc.callFunc(() => {
                lightArray[1].setPositionX(JSScreenMidPos.x + 110);
            })
        )));

        // 文字
        var hintLabel1 = new cc.LabelTTF(LocalizedString.Game("等待其他玩家入桌"), JSFontBoldName, 12);
        hintLabel1.setAnchorPoint(0, 0.5);
        waitPlayerNode.addChild(hintLabel1);

        var hintLabel2 = new cc.LabelTTF("...", JSFontBoldName, 12);
        hintLabel2.setAnchorPoint(0, 0.5);
        waitPlayerNode.addChild(hintLabel2);

        var hintLabel1Width = hintLabel1.getContentSize().width;
        var totalWidth = hintLabel1Width + hintLabel2.getContentSize().width;
        hintLabel1.setPosition(JSScreenMidPos.x - totalWidth / 2, JSScreenMidPos.y);
        hintLabel2.setPosition(JSScreenMidPos.x - totalWidth / 2 + hintLabel1Width, JSScreenMidPos.y);

        // 文字動畫
        var changeStringArray = [".", "..", "..."];
        var changeCount = 0;
        hintLabel2.runAction(cc.repeatForever(cc.sequence(
            cc.delayTime(0.5),
            cc.callFunc(function () {
                hintLabel2.setString(changeStringArray[changeCount % 3]);
                changeCount++;
            }, this)
        )));

        // 換桌按鈕
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        waitPlayerNode.addChild(menu);

        var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", cc.size(100, 30), LocalizedString.Game("馬上換桌"), 9, JSColor.BLACK);
        var changeItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], function () {
            // 要換桌
            GS.dispatchCustomEvent("NotifyGameUIChangePlaceClicked", {isReplaceRoomByClickedUIButton: true});
        }, this);
        changeItem.setPosition(JSScreenMidPos.x, 100 + JSScreenBonusHalfHeight);
        changeItem.setVisible(false);
        menu.addChild(changeItem);

        // 幾秒後出現
        var changeTime = DataModal.gameData.waitChangeTime || 10;
        changeItem.runAction(cc.sequence(
            cc.delayTime(changeTime),
            cc.show()
        ));
    },

    /**
     * 關掉等待其他玩家提示
     */
    closeWaitPlayerHint: function () {
        if (this._waitPlayerNode) {
            this._waitPlayerNode.removeFromParent();
            this._waitPlayerNode = null;
        }
    },

    /**
     * 出現牌局開始倒數
     */
    showGameReadyHint: function (time) {
        this.closeGameReadyHint();

        var gameReadyNode = this._gameReadyNode = new cc.Node();
        this.addChild(gameReadyNode);

        // 背景
        var bgSprite = new ccui.Scale9Sprite("game_pic_line_purple.png");
        bgSprite.setPreferredSize(cc.size(320, 28));
        bgSprite.setPosition(JSScreenMidPos);
        gameReadyNode.addChild(bgSprite);

        // 金邊
        var lightArray = [];
        for (var i = 0; i < 2; i++) {
            var vy = JSScreenMidPos.y + 14 - i * 28;

            var lineSp = new ccui.Scale9Sprite("game_pic_line_gold.png");
            lineSp.setPreferredSize(cc.size(310, 2));
            lineSp.setPosition(JSScreenMidPos.x, vy);
            gameReadyNode.addChild(lineSp);

            var defaultX = JSScreenMidPos.x - 110 + 220 * i;
            var lineLightSp = lightArray[i] = new cc.Sprite("#game_pic_line_reflective.png");
            lineLightSp.setPosition(defaultX, vy);
            gameReadyNode.addChild(lineLightSp);
        }

        // 金邊動畫
        lightArray[0].runAction(cc.repeatForever(cc.sequence(
            cc.fadeIn(0.2),
            cc.moveBy(1.5, cc.p(220, 0)),
            cc.fadeOut(0.2),
            cc.callFunc(() => {
                lightArray[0].setPositionX(JSScreenMidPos.x - 110);
            })
        )));

        lightArray[1].runAction(cc.repeatForever(cc.sequence(
            cc.fadeIn(0.2),
            cc.moveBy(1.5, cc.p(-220, 0)),
            cc.fadeOut(0.2),
            cc.callFunc(() => {
                lightArray[1].setPositionX(JSScreenMidPos.x + 110);
            })
        )));

        // 文字
        var hintLabel = new cc.LabelTTF(LocalizedString.Game("牌局即將開始"), JSFontBoldName, 12);
        hintLabel.setPosition(JSScreenMidPos);
        gameReadyNode.addChild(hintLabel);

        // 倒數圖片
        var autoLayout = new GSAutoLayoutNode();
        autoLayout.setSpace(-8);
        autoLayout.setPosition(JSScreenMidPos.x, 97 + JSScreenBonusHalfHeight);
        gameReadyNode.addChild(autoLayout);

        var startTime = new Date().getTime();
        var showTime = () => {
            var reduceTime = Math.floor((new Date().getTime() - startTime) / 1000);
            var nowTime = time - reduceTime;
            if (nowTime < 0) {
                if (this._gameReadyNode) {
                    this._gameReadyNode.removeFromParent();
                    this._gameReadyNode = null;
                }
                return;
            }

            var timeString = nowTime.toString();
            autoLayout.removeAllChildren();
            for (var i = 0, len = timeString.length; i < len; i++) {
                var timeSprite = new cc.Sprite(JSStringUtility.format("#num_09_%s.png", timeString[i]));
                autoLayout.addChild(timeSprite);
            }
        };
        showTime();

        gameReadyNode.runAction(cc.repeatForever(cc.sequence(
            cc.delayTime(0.5),
            cc.callFunc(showTime)
        )));
    },

    /**
     * 關掉牌局開始提示
     */
    closeGameReadyHint: function () {
        if (this._gameReadyNode) {
            this._gameReadyNode.removeFromParent();
            this._gameReadyNode = null;
        }
    },

    /**
     * 出現牌局開始倒數
     */
    showNextRoundHint: function () {
        this.closeNextRoundHint();

        var nextRoundNode = this._nextRoundNode = new cc.Node();
        this.addChild(nextRoundNode);

        // 背景
        var posX = 310 + JSScreenBonusHalfWidth;
        var posY = 20;
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_list_04.png");
        bgSprite.setPreferredSize(cc.size(72, 30));
        bgSprite.setScaleX(4.2);
        bgSprite.setPosition(posX, posY);
        nextRoundNode.addChild(bgSprite);

        // 文字
        var hintLabel1 = new cc.LabelTTF(LocalizedString.Game("等待下一局開始"), JSFontBoldName, 14);
        hintLabel1.setAnchorPoint(0, 0.5);
        nextRoundNode.addChild(hintLabel1);

        var hintLabel2 = new cc.LabelTTF("...", JSFontBoldName, 12);
        hintLabel2.setAnchorPoint(0, 0.5);
        nextRoundNode.addChild(hintLabel2);

        var hintLabel1Width = hintLabel1.getContentSize().width;
        var totalWidth = hintLabel1Width + hintLabel2.getContentSize().width;
        hintLabel1.setPosition(posX - totalWidth / 2, posY);
        hintLabel2.setPosition(posX - totalWidth / 2 + hintLabel1Width, posY);

        // 文字動畫
        var changeStringArray = [".", "..", "..."];
        var changeCount = 0;
        hintLabel2.runAction(cc.repeatForever(cc.sequence(
            cc.delayTime(0.5),
            cc.callFunc(function () {
                hintLabel2.setString(changeStringArray[changeCount % 3]);
                changeCount++;
            }, this)
        )));
    },

    /**
     * 關掉牌局開始提示
     */
    closeNextRoundHint: function () {
        if (this._nextRoundNode) {
            this._nextRoundNode.removeFromParent();
            this._nextRoundNode = null;
        }
    },

    /**
     * 顯示玩牌提示 抽牌/棄牌/計牌器
     * @param type
     */
    showGameIntro: function (type) {
        this._showIntroType = type;

        if (!this._introNode) {
            var introNode = this._introNode = new cc.Node();
            this.addChild(introNode);
        }

        switch (type) {
            case "1":
            case "2":
                // 背景
                var bgSprite = new ccui.Scale9Sprite("cangkulan_pic_msg.png");
                bgSprite.setPreferredSize(cc.size(343, 44));
                bgSprite.setPosition(JSScreenMidPos.x, JSVisibleSize.height - 25);
                this._introNode.addChild(bgSprite);

                // 文字
                var str = (type === "1") ? "點選一張要出的牌" : "要出同花色的牌";
                var label = new cc.LabelTTF(LocalizedString.Game(str), JSFontBoldName, 10);
                label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                label.setFontFillColor(JSColor.BLACK);
                label.setPosition(JSScreenMidPos.x, JSVisibleSize.height - 25);
                this._introNode.addChild(label);

                // 步驟1之後會多1個步驟 這邊多做1個監聽
                if (type === "1")
                    GS.addListener("NotifyShowGameIntroHint", this.notifyShowGameIntroHint.bind(this), this);

                GS.dispatchCustomEvent("NotifyGameShowFirstHint", type);
                break;

            case "1.5":
            case "3":
            case "4":
                if (type === "3" || type === "4") {
                    // 背景
                    var bgSprite = new ccui.Scale9Sprite("cangkulan_pic_msg.png");
                    bgSprite.setPreferredSize(cc.size(343, 44));
                    bgSprite.setPosition(JSScreenMidPos.x, JSVisibleSize.height - 25);
                    this._introNode.addChild(bgSprite);

                    // 文字
                    var str = (type === "3") ? "沒有同花色的牌，要抽到有同花色的牌" : "沒有同花色的牌，需要抽一張牌";
                    var label = new cc.LabelTTF(LocalizedString.Game(str), JSFontBoldName, 10);
                    label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                    label.setFontFillColor(JSColor.BLACK);
                    label.setPosition(JSScreenMidPos.x, JSVisibleSize.height - 25);
                    this._introNode.addChild(label);
                }

                // 設定手指位置
                var finger = new cc.Sprite("#game_pic_finger_01.png");
                finger.setPosition(JSScreenMidPos.x - 20, 74 + JSScreenBonusHalfHeight);
                this._introNode.addChild(finger);
                finger.runAction(cc.repeatForever(cc.sequence(cc.rotateTo(0.3, -30), cc.rotateTo(0.3, 0))));
                break;

            case "5":
                // 跳出計牌器的提示泡泡框
                var message = LocalizedString.Game("點這邊看尚未被丟棄的牌");
                var messageLabel = new cc.LabelTTF(message, JSFontName, 12);
                messageLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                messageLabel.setFontFillColor(JSColor.BLACK);

                var param = {
                    mainNode: messageLabel,
                    style: BaseMessageNode.Style.GOLD,
                    direct: BaseMessageNode.Direct.RIGHT,
                    isFlip: false,
                    arrowPadding: 0,
                };

                var msg = new BaseMessageNode(param);
                msg.setPosition(JSVisibleSize.width - 30, JSVisibleSize.height - 35);
                msg.show();
                this._introNode.addChild(msg);
                break;
        }

        GS.dispatchCustomEvent("NotifyEnableProcessMessage");
    },

    /**
     * 關閉玩牌提示(自動玩的時候)
     */
    closeGameIntro: function () {
        // 沒有提示 不處理
        if (!this._showIntroType)
            return;

        // 步驟1 & 2在手牌有顯示黃框要通知關掉
        if (this._showIntroType === "1" || this._showIntroType === "2") {
            GS.dispatchCustomEvent("NotifyGameShowFirstHint", false);
        }
        // 移除提示
        this._introNode && this._introNode.removeAllChildren();
        this._showIntroType = false;
    },

    /**
     * 通知
     */
    // 上方顯示的訊息
    notifyShowTopMessage: function (event) {
        if (event) {
            var obj = event.getUserData();

            // 這部份特別處理 因為他可以連點 要即時顯示
            if (this._oldMessageNode) {
                this._oldMessageNode.stopAllActions();
                this._oldMessageNode.removeFromParent();
                this._oldMessageNode = null;
            }

            if (!obj)
                return;

            // 創新的畫面
            var showHeight = 44;
            var showMidHeight = showHeight / 2;
            var showNode = this._oldMessageNode = new cc.Node();
            showNode.setContentSize(cc.size(0, showHeight));
            this.addChild(showNode);

            // 背景
            var bgSprite = new ccui.Scale9Sprite("cangkulan_pic_msg.png");
            bgSprite.setPreferredSize(cc.size(343, showHeight));
            bgSprite.setPosition(0, showMidHeight);
            showNode.addChild(bgSprite);

            // 文字
            var label = new cc.LabelTTF(obj, JSFontBoldName, 10);
            label.setFontFillColor(JSColor.BLACK);
            label.setPosition(0, showMidHeight);
            showNode.addChild(label);

            // 顯示
            showNode.setPosition(JSScreenMidPos.x, JSVisibleSize.height + showHeight / 2);
            showNode.setAnchorPoint(0.5, 0.5);
            showNode.runAction(cc.sequence(
                cc.moveBy(0.5, cc.p(0, -showHeight)).easing(cc.easeIn(1.8)),
                cc.delayTime(1.8),
                cc.moveBy(0.5, cc.p(0, showHeight)).easing(cc.easeOut(1.8)),
                cc.callFunc(function () {
                    // 設定沒了
                    this._oldMessageNode = null;

                    // 再跑一次 看有沒有新的
                    this._show();
                }, this),
                cc.removeSelf()
            ));
        }
    },

    /**
     * 玩牌提示步驟1之後會顯示1個小手在棄牌上 次為步驟1.5
     */
    notifyShowGameIntroHint: function () {
        this.showGameIntro("1.5");
    },

    /**
     * Touch的東西
     */
    _onTouchBegan: function () {

        // 沒有提示 不處理
        if (!this._showIntroType)
            return;

        // 有玩牌提示

        // 送給server 步驟 (步驟1有兩個階段1.5為步驟1第二階段 做到第二階段後才給server存擋)
        if (this._showIntroType !== "1") {
            var sendType = (this._showIntroType === "1.5") ? "1" : this._showIntroType;
            DataProcess.sendString("save_game_intro " + sendType);
        }

        // 關閉玩牌提示
        this.closeGameIntro();
        return true;
    },

    // 用來跳桌內上方的保護令提示
    cmd_gameRank_protect_info: function (value) {
        // gameRank_protect_info x   (x為保護令手數)
        var number = parseInt(value);
        var totalText = JSStringUtility.format(LocalizedString.GameRank("獲得俱樂部保護令防護%d手，\n祝牌運亨通！"), number);

        var showNode = new cc.Node();

        // 文字
        var textNode = new GSRichTextNode(totalText, JSFontBoldName, 14);
        textNode.setHAlignmentToCenter(true);
        showNode.addChild(textNode, 1);

        // 算大小
        var textSize = textNode.getContentSize();
        var totalSize = cc.size(textSize.width + 30, textSize.height + 10);
        var midPos = cc.p(totalSize.width / 2, totalSize.height / 2);

        // 背景
        var bgNode = new ccui.Scale9Sprite("lobby_pic_black.png");
        bgNode.setPreferredSize(totalSize);
        showNode.addChild(bgNode);

        // 設定位置
        textNode.setPosition(midPos);
        bgNode.setPosition(midPos);

        // 設定大小
        showNode.setContentSize(totalSize);

        // 顯示
        this.showWithNode(showNode);
    },
});