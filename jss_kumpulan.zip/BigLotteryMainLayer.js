/**
 * 9T 幸運彩票 - 主頁面
 * Domino移植設定 印尼版畫面有調整跟中撲差蠻多的
 */

var BigLotteryMainLayer = BigLotteryBaseLayer.extend({
    ctor: function () {
        this._super();

        this.pageType = BigLotteryLayer.PageType.MAIN_PAGE;
        var bigLotteryStr = LocalizedString.BigLottery;
        this._canBuyTicket = false;                             // 能不能購買彩券

        // 主要畫面
        {
            // 主要畫面的node
            var mainNode = this._mainNode;

            // 放要刷新的東西
            var contentNode = this._contentNode = new cc.Node();
            mainNode.addChild(contentNode);

            // 錢幣堆
            var coinSprite = new cc.Sprite("#bigLottery_pic_money.png");
            coinSprite.setPosition(464 + JSScreenBonusHalfWidth, 86);
            contentNode.addChild(coinSprite);

            // 不能購買時擋住購買view的漸層
            var cantBuyNode = this._canBuyNode = new cc.Node();
            cantBuyNode.setPosition(306 + JSScreenBonusHalfWidth, JSScreenMidPos.y - 104);
            mainNode.addChild(cantBuyNode);

            // 加黑底
            var bgColorLayer = new ccui.Scale9Sprite("lobby_pic_black.png");
            bgColorLayer.setPreferredSize(cc.size(400, 38));
            cantBuyNode.addChild(bgColorLayer);

            var label = new cc.LabelTTF(bigLotteryStr("目前無法購買唷!"), JSFontName, 14);
            cantBuyNode.addChild(label);
        }

        // 準備中畫面
        {
            // 準備中node
            var prepareNode = this._prepareNode = new cc.Node();
            prepareNode.setVisible(false);
            this.addChild(prepareNode);

            // 文字: 下期幸運彩票準備中
            var label = new cc.LabelTTF(bigLotteryStr("下一期幸運彩票準備中..."), JSFontName, 14);
            label.enableStroke(cc.color(190, 30, 0, 255), 2);
            label.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            label.setPosition(JSScreenBonusHalfWidth + 254, 133 + JSScreenBonusHalfHeight);
            prepareNode.addChild(label);

            // 提示文字
            var hintLabel = new cc.LabelTTF(bigLotteryStr("開放倒數後，即可購買下期彩票"), JSFontName, 14);
            hintLabel.enableStroke(cc.color(190, 30, 0, 255), 2);
            hintLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            hintLabel.setPosition(JSScreenBonusHalfWidth + 254, 52 + JSScreenBonusHalfHeight);
            prepareNode.addChild(hintLabel);

            // 錢幣堆
            var coinSprite = new cc.Sprite("#bigLottery_pic_money.png");
            coinSprite.setPosition(464 + JSScreenBonusHalfWidth, 86);
            prepareNode.addChild(coinSprite);
        }

        // 倒數
        var clockNode = this._clockNode = new BigLotteryClockNode();
        clockNode.setScale(0.75);
        clockNode.setPosition(462 + JSScreenBonusHalfWidth, JSVisibleSize.height - 28);
        this.addChild(clockNode);

        GS.addListener("NotifyBigLotteryInfoBuyDone", this.notifyBigLotteryInfoBuyDone.bind(this), this);
    },

    /**
     * 更新畫面
     */
    _refreshView: function (param) {
        this._param = param;

        // 停止跑馬燈
        if (this._marqueeNode) {
            this._marqueeNode.stopAllActions();
            this._marqueeNode.removeFromParent();
            this._marqueeNode = null;
        }

        // remove loading
        this._loadingSprite.stop();

        var bigLotteryData = DataModal.bigLotteryData;
        var bigLotteryStr = LocalizedString.BigLottery;
        this._canBuyTicket = bigLotteryData.status === BigLotteryData.Status.NORMAL;           // 可否購買彩券

        // 顯示倒數
        var clockNode = this._clockNode;
        clockNode.setVisible(true);

        var status = bigLotteryData.status;
        switch (status) {
            case BigLotteryData.Status.DRAW_FINISH:
            case BigLotteryData.Status.RESETTING:
                // (重置中>開獎完)顯示準備中頁面
                this._mainNode.setVisible(false);
                this._prepareNode.setVisible(true);
                break;

            case BigLotteryData.Status.NORMAL:
            case BigLotteryData.Status.CANNOT_BUY:
            case BigLotteryData.Status.CANNOT_SELECT:
            case BigLotteryData.Status.AUTO_SELECT_FINISH:
                this._mainNode.setVisible(true);
                this._prepareNode.setVisible(false);

                // 先清掉東西
                var contentNode = this._contentNode;
                contentNode.removeAllChildren();

                // 總彩金文字定位(預設無加碼紅包狀態)
                var periodLabelPos = cc.p(300 + JSScreenBonusHalfWidth, JSScreenBonusHalfHeight + 154);

                // 跑馬燈
                if (param.marqueeArray.length > 0) {

                    var marqueeNode = this._marqueeNode = new cc.Node();
                    marqueeNode.setPosition(JSScreenMidPos.x + 45, JSScreenMidPos.y + 59);
                    contentNode.addChild(marqueeNode);

                    var bgColorLayer = new ccui.Scale9Sprite("lobby_pic_black.png");
                    bgColorLayer.setPreferredSize(cc.size(360, 16));
                    marqueeNode.addChild(bgColorLayer);

                    var marquee = this._marquee = new MarqueeNode({
                        width: 356,
                        height: 16,
                        fontSize: 12,
                        isLoop: true,
                        sec: param.pollSec,
                        disableBG: true
                    });
                    marqueeNode.addChild(marquee);

                    // 輪播
                    var currentIndex = 0;
                    var marqueeArray = param.marqueeArray;
                    marqueeNode.runAction(cc.sequence(
                        cc.callFunc(() => {
                            marquee.push({
                                message: marqueeArray[currentIndex],
                                color: JSColor.WHITE,
                            });
                            currentIndex = (currentIndex + 1) % marqueeArray.length;
                        }),
                        cc.delayTime(param.pollSec)
                    ).repeatForever());
                }

                // 有額外加碼(頭獎加碼/大紅包/幸運數字)
                // 幸運數字 不會跟頭獎加碼/大紅包 同時開
                if (bigLotteryData.haveExtraMoney || bigLotteryData.haveRedEnvelope || param.luckyNumber) {
                    // 背景
                    var bgSprite = new ccui.Scale9Sprite("bigLottery_bg_red2.png");
                    bgSprite.setPreferredSize(cc.size(360, 100));
                    bgSprite.setPosition(JSScreenMidPos.x + 45, JSScreenMidPos.y - 5);
                    contentNode.addChild(bgSprite);

                    // 變更總彩金文字位置(加碼或大紅包)
                    periodLabelPos = cc.p(304 + JSScreenBonusHalfWidth, JSScreenBonusHalfHeight + 178);

                    // 頭彩數字
                    var priceNode = new GSSpriteNumberNode({
                        number: param.prize,
                        numStr: "#num_11_",
                        dotStr: ",",
                        addDot: true,
                        spW: 14,
                        spH: 22,
                        dotW: 7,
                        isDotHeightAsNum: true
                    });
                    priceNode.setPosition(JSScreenMidPos.x + 45, JSScreenMidPos.y + 10);
                    priceNode.setScale(1.2);
                    contentNode.addChild(priceNode);

                    if (bigLotteryData.haveExtraMoney && bigLotteryData.haveRedEnvelope) {
                        var titleArray = ["#bigLottery_word_extraMoney.png", "#bigLottery_word_thisEnvelope.png"];
                        var iconArray = ["#bigLottery_pic_award02.png", "#bigLottery_pic_award01.png"];
                        var moneyArray = [param.extraPrice, param.envelope];
                        for (var i = 0; i < 2; i++) {
                            // 暗金框
                            var bgSprite = new ccui.Scale9Sprite("bigLottery_pic_ticketNormal.png");
                            bgSprite.setPreferredSize(cc.size(175, 45));
                            bgSprite.setPosition(JSScreenMidPos.x - 43 + i * 177, JSScreenMidPos.y - 28);
                            contentNode.addChild(bgSprite);

                            // 標題
                            var titleSprite = new cc.Sprite(titleArray[i]);
                            titleSprite.setPosition(JSScreenMidPos.x - 42 + i * 177, JSScreenMidPos.y - 21);
                            titleSprite.setScale(0.8);
                            contentNode.addChild(titleSprite);

                            // 金額
                            var moneyLabel = new cc.LabelTTF(TexasUtility.getSimpleMoneyString(moneyArray[i]), JSFontName, 14);
                            moneyLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                            moneyLabel.enableStroke(cc.color(190, 30, 0, 255), 2);
                            moneyLabel.setPosition(JSScreenMidPos.x - 42 + i * 177, JSScreenMidPos.y - 35);
                            contentNode.addChild(moneyLabel);

                            // special圖
                            var iconSprite = new cc.Sprite("#bigLottery_special.png");
                            iconSprite.setPosition(JSScreenMidPos.x - 111 + i * 178, JSScreenMidPos.y - 22);
                            contentNode.addChild(iconSprite);
                        }
                    }
                    // 只有頭彩加碼
                    else if (bigLotteryData.haveExtraMoney) {

                        // 標題: 本期頭獎再加碼
                        var titleSprite = new cc.Sprite("#bigLottery_word_extraMoney.png");
                        titleSprite.setScale(1.3);
                        titleSprite.setPosition(JSScreenMidPos.x + 47, JSScreenMidPos.y - 20);
                        contentNode.addChild(titleSprite);

                        // 加碼金額
                        var moneyLabel = new cc.LabelTTF(TexasUtility.getSimpleMoneyString(param.extraPrice), JSFontName, 14);
                        moneyLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                        moneyLabel.enableStroke(cc.color(190, 30, 0, 255), 2);
                        moneyLabel.setPosition(JSScreenMidPos.x + 45, JSScreenMidPos.y - 39);
                        contentNode.addChild(moneyLabel);

                        // 左上special圖
                        var iconSprite = new cc.Sprite("#bigLottery_special.png");
                        iconSprite.setPosition(JSScreenMidPos.x - 112, JSScreenMidPos.y - 22);
                        contentNode.addChild(iconSprite);

                        // 暗金框
                        var bgSprite = new ccui.Scale9Sprite("bigLottery_pic_ticketNormal.png");
                        bgSprite.setPreferredSize(cc.size(356, 46));
                        bgSprite.setPosition(JSScreenMidPos.x + 45, JSScreenMidPos.y - 28);
                        contentNode.addChild(bgSprite);
                    } else if (bigLotteryData.haveRedEnvelope) {
                        // 只有大紅包

                        // 標題: 本期大紅包
                        var titleSprite = new cc.Sprite("#bigLottery_word_thisEnvelope.png");
                        titleSprite.setScale(1.3);
                        titleSprite.setPosition(JSScreenMidPos.x + 47, JSScreenMidPos.y - 20);
                        contentNode.addChild(titleSprite);

                        // 紅包金額
                        var moneyLabel = new cc.LabelTTF(TexasUtility.getSimpleMoneyString(param.envelope), JSFontName, 14);
                        moneyLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                        moneyLabel.enableStroke(cc.color(190, 30, 0, 255), 2);
                        moneyLabel.setPosition(JSScreenMidPos.x + 45, JSScreenMidPos.y - 39);
                        contentNode.addChild(moneyLabel);

                        // 左上special圖
                        var iconSprite = new cc.Sprite("#bigLottery_special.png");
                        iconSprite.setPosition(JSScreenMidPos.x - 112, JSScreenMidPos.y - 22);
                        contentNode.addChild(iconSprite);

                        // 暗金框
                        var bgSprite = new ccui.Scale9Sprite("bigLottery_pic_ticketNormal.png");
                        bgSprite.setPreferredSize(cc.size(356, 46));
                        bgSprite.setPosition(JSScreenMidPos.x + 45, JSScreenMidPos.y - 28);
                        contentNode.addChild(bgSprite);
                    }

                    // 幸運數字
                    else if (param.luckyNumber) {
                        // 背景
                        var bgSprite = new ccui.Scale9Sprite("bigLottery_bg_red2.png");
                        bgSprite.setPreferredSize(cc.size(350, 46));
                        bgSprite.setPosition(JSScreenMidPos.x + 45, JSScreenMidPos.y - 28);
                        contentNode.addChild(bgSprite);

                        // 標題: 本期幸運數字獎金
                        var titleSprite = new cc.Sprite("#bigLottery_word_totalBingoMoney.png");
                        titleSprite.setPosition(JSScreenMidPos.x + 45, JSScreenMidPos.y - 16);
                        contentNode.addChild(titleSprite);

                        // 金額
                        var moneyLabel = new cc.LabelTTF(TexasUtility.getSimpleMoneyString(param.luckyNumber), JSFontName, 14);
                        moneyLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                        moneyLabel.setFontFillColor(JSColor.YELLOW);
                        moneyLabel.enableStroke(TexasUtility.OutlineColor.DARK_RED, 3);
                        moneyLabel.setPosition(JSScreenMidPos.x + 45, JSScreenMidPos.y - 30);
                        contentNode.addChild(moneyLabel);

                        var tipLabel = new cc.LabelTTF(bigLotteryStr("(任一號碼與幸運數字相同即中獎)"), JSFontName, 10);
                        tipLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                        tipLabel.enableStroke(cc.color(115, 15, 0, 255), 2);
                        tipLabel.setPosition(JSScreenMidPos.x + 45, JSScreenMidPos.y - 42);
                        contentNode.addChild(tipLabel);

                        // 賓果圖
                        var iconSprite = new cc.Sprite("#bigLottery_pic_ball_03.png");
                        iconSprite.setPosition(JSScreenMidPos.x - 70, JSScreenMidPos.y - 22);
                        iconSprite.setScale(0.6);
                        // iconSprite.setScaleY(0.75);
                        contentNode.addChild(iconSprite);

                        // 問號圖
                        var quesSprite = new cc.Sprite("#bigLottery_word_ques.png");
                        quesSprite.setPosition(JSScreenMidPos.x - 70, JSScreenMidPos.y - 22);
                        quesSprite.setScale(0.6);
                        contentNode.addChild(quesSprite);

                        // 標籤圖
                        var labelSprite = new cc.Sprite("#bigLottery_pic_label.png");
                        labelSprite.setRotation(-15);
                        // labelSprite.setScale(1.1);
                        labelSprite.setPosition(JSScreenMidPos.x + 213, JSScreenMidPos.y - 10);
                        contentNode.addChild(labelSprite);

                        // 標籤美術字圖
                        var labelWordSprite = new cc.Sprite("#bigLottery_word_limit.png");
                        labelWordSprite.setPosition(JSScreenMidPos.x + 213, JSScreenMidPos.y - 10);
                        contentNode.addChild(labelWordSprite);
                    }
                }
                // 常態狀態
                else {
                    // 背景
                    var bgSprite = new ccui.Scale9Sprite("bigLottery_bg_red2.png");
                    bgSprite.setPreferredSize(cc.size(360, 100));
                    bgSprite.setPosition(JSScreenMidPos.x + 45, JSScreenMidPos.y - 5);
                    contentNode.addChild(bgSprite);

                    // 頭彩數字
                    var priceNode = new GSSpriteNumberNode({
                        number: param.prize,
                        numStr: "#num_11_",
                        dotStr: ",",
                        addDot: true,
                        spW: 14,
                        spH: 22,
                        dotW: 7,
                        isDotHeightAsNum: true
                    });
                    priceNode.setPosition(300 + JSScreenBonusHalfWidth, JSScreenBonusHalfHeight + 125);
                    priceNode.setScale(1.2);
                    contentNode.addChild(priceNode);
                }

                // 期數加上總彩金文字
                var periodLabel = this._periodLabel = new cc.LabelTTF(JSStringUtility.format("Periode %s, Total Hadiah", bigLotteryData.period), JSFontName, 12);
                periodLabel.enableStroke(cc.color(190, 30, 0, 255), 2);
                periodLabel.setPosition(periodLabelPos);
                contentNode.addChild(periodLabel);

                // TableView 購買禮包方案
                var tableViewSize = cc.size(380, 86);
                var mainLayer = this._mainLayer = new cc.Layer();
                var tableView = this._tableView = new cc.TableView(this, tableViewSize, mainLayer);
                tableView.setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
                tableView.setDelegate(this);
                tableView.setPosition(110 + JSScreenBonusHalfWidth, JSScreenBonusHalfHeight + 7);
                contentNode.addChild(tableView);

                // 可以購買顯示購買區 其他時候顯示黑幕
                this._tableView.setVisible(this._canBuyTicket);
                this._canBuyNode.setVisible(!this._canBuyTicket);
                break;

            default:
                // 顯示準備中頁面
                this._mainNode.setVisible(false);
                this._prepareNode.setVisible(true);
                break;
        }

    },

    /**
     * 更新購買方案tableView資訊
     */
    _refreshPurchaseView: function () {
        // 刷新tableView
        var bigLotteryData = DataModal.bigLotteryData;
        this._productArray = bigLotteryData.productArray;
        this._totalCellCount = this._productArray.length;
        this._tableView && this._tableView.reloadData(true);
    },

    /**
     * override
     */
    _enterPage: function () {
        // 初始化狀態
        this._loadingSprite.start();
        this._mainNode.setVisible(false);
        this._clockNode.setVisible(false);

        // 要資料
        DataProcess.sendString("big_lottery_info_buy");
    },

    /**
     * 通知
     */

    // 通知收到頁面與儲值資料
    notifyBigLotteryInfoBuyDone: function (event) {
        if (event && event.getUserData()) {
            var param = event.getUserData();

            // 刷新主畫面
            this._refreshView(param);
        }

        // 刷新下方購買tableView
        this._refreshPurchaseView();
    },

    /**
     * TableView delegate
     */
    tableCellTouched: function (table, cell) {
        cell.purchaseBtnClicked();
    },

    tableCellHighlight: function (table, cell) {
        if (cell)
            cell.setIsHighlight(true);
    },

    tableCellUnhighlight: function (table, cell) {
        if (cell)
            cell.setIsHighlight(false);
    },

    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        if (cell == null) {
            cell = new BigLotteryPurchaseCell();
            cell.setAnchorPoint(0, 0);
        }

        if (this._productArray && idx < this._productArray.length) {
            var param = this._productArray[idx];
            cell.refreshCell(idx, param);
        }

        return cell;
    },

    numberOfCellsInTableView: function (table) {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function (table, idx) {
        return cc.size(BigLotteryPurchaseCell.WIDTH, BigLotteryPurchaseCell.HEIGHT);
    }
});