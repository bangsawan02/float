/**
 * Bonus機台 牌桌上倒數時鐘 Node
 */
var BonusClockNode = cc.Node.extend({
    ctor: function () {
        this._super();

        // 時鐘圖
        var bgSp = new cc.Sprite("#bonus_clock.png");
        this.addChild(bgSp);

        // 中間倒數文字
        var timerNode = this._timerNode = new GSSpriteNumberNode({
            number: 0,
            numStr: "#bonus_number_",
            spW: 6,
            spH: 12
        });
        this.addChild(timerNode);
    },

    /**
     *    檢查秒數更新的schedule
     *    @private
     */
    _tick: function () {
        if (!this._time) {
            return this.unscheduleAllCallbacks();
        }

        var nowTime = new Date().getTime();
        var targetTime = this._time;
        var seconds = Math.max(0, Math.round((targetTime - nowTime) / 1000));
        this._timerNode.setToNumber(seconds);
        this._prevSeconds = seconds;

        if (targetTime < nowTime) {
            // 通知倒數結束
            GS.dispatchCustomEvent("NotifyBonusClockExpire");
            this.clearTimer();
        }
    },

    /**
     * 設定倒數時間
     * @param seconds 秒數
     * @param nowTime
     */
    setTimer: function (seconds, nowTime) {
        this._time = new Date(nowTime + seconds * 1000);
        this._timerNode.setToNumber(seconds);
        this.setVisible(true);
    },

    /**
     * 開始倒數
     */
    startCountdown: function () {
        this._tick();
        this.unschedule(this._tick);
        this.schedule(this._tick, 1 / 3);
    },

    /**
     *    停止倒數
     */
    clearTimer: function () {
        this.setVisible(false);
        this.unschedule(this._tick);
        this._time = null;
    }
});