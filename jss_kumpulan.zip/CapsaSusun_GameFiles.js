/**
 * 這邊存CapsaSusun遊戲的檔案列表
 */

var CapsaSusun_GameFiles = CommonGameFiles.concat([
    "out_src/GameScene/CapsaSusun/CapsaSusun_GameScene.js",
    "out_src/GameScene/CapsaSusun/CapsaSusun_GameLayer.js",
    "out_src/GameScene/CapsaSusun/CapsaSusun_GameUtility.js",
    "out_src/GameScene/CapsaSusun/Animation/CapsaSusun_AnimationLayer.js",
    "out_src/GameScene/CapsaSusun/Animation/CapsaSusun_CardTypeAnimNode.js",
    "out_src/GameScene/CapsaSusun/Animation/CapsaSusun_ScoreAnimNode.js",
    "out_src/GameScene/CapsaSusun/Animation/CapsaSusun_ScoreLayer.js",
    "out_src/GameScene/CapsaSusun/Background/CapsaSusun_BackgroundLayer.js",
    "out_src/GameScene/CapsaSusun/CardsLayer/CapsaSusun_CardNode.js",
    "out_src/GameScene/CapsaSusun/CardsLayer/CapsaSusun_CardsLayer.js",
    "out_src/GameScene/CapsaSusun/CardsLayer/CapsaSusun_ClockNode.js",
    "out_src/GameScene/CapsaSusun/CardsLayer/CapsaSusun_HandCardLayer.js",
    "out_src/GameScene/CapsaSusun/CardsLayer/CapsaSusun_HintCardTool.js",
    "out_src/GameScene/CapsaSusun/CardsLayer/CapsaSusun_HintCardMenuBarLayer.js",
    "out_src/GameScene/CapsaSusun/CardsLayer/CapsaSusun_HintCardMenuLayer.js",
    "out_src/GameScene/CapsaSusun/CardsLayer/CapsaSusun_HintCardTool.js",
    "out_src/GameScene/CapsaSusun/CardsLayer/CapsaSusun_OutCardLayer.js",
    "out_src/GameScene/CapsaSusun/PlayersLayer/CapsaSusun_PlayerNode.js",
    "out_src/GameScene/CapsaSusun/PlayersLayer/CapsaSusun_PlayersLayer.js",
    "out_src/GameScene/CapsaSusun/PlayersLayer/CapsaSusun_PlayerAnimLayer.js",
    "out_src/GameScene/CapsaSusun/PlayersLayer/CapsaSusun_PlayerAnimNode.js",
    "out_src/GameScene/CapsaSusun/UILayer/CapsaSusun_AutoPlayLayer.js",
    "out_src/GameScene/CapsaSusun/UILayer/CapsaSusun_GameHintLayer.js",
    "out_src/GameScene/CapsaSusun/UILayer/CapsaSusun_UILayer.js",
    "out_src/GameScene/CapsaSusun/UILayer/CapsaSusun_UIOptionButton.js",
    "out_src/GameScene/CapsaSusun/UILayer/CapsaSusun_UIOptionLayer.js",
]);