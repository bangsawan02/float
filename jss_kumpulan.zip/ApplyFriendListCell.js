/**
 * 好友申請列表的Cell
 */

var ApplyFriendListCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        var midPosY = ApplyFriendListCell.HEIGHT / 2 + 3;

        // 放要變色的東西
        var mainNode = this._mainNode = new cc.Node();
        mainNode.setCascadeColorEnabled(true);
        this.addChild(mainNode);

        // 大頭照
        var photoNode = this._photoSprite = new LobbyCircleProfileNode();
        photoNode.setPosition(30, midPosY);
        photoNode.setScale(0.7);
        mainNode.addChild(photoNode);

        // 暱稱
        var nicknameLabel = this._nicknameLabel = new GSAutoSizeLabel("", JSFontBoldName, 12, cc.size(110, GameRankRankCell.HEIGHT), cc.TEXT_ALIGNMENT_LEFT, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        nicknameLabel.setAnchorPoint(0, 0.5);
        nicknameLabel.setPosition(53, midPosY);
        mainNode.addChild(nicknameLabel);

        // 個人資訊的按鈕(點大頭照&暱稱會跳出個人資訊頁)
        var profileBtn = new GSControlButton("", cc.size(147, ApplyFriendListCell.HEIGHT));
        profileBtn.setCascadeOpacityEnabled(true);
        profileBtn.addTargetWithActionForControlEvents(this, this._profileBtnClicked,
            cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
            cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
            cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
        profileBtn.setPosition(0, 0);
        profileBtn.setAnchorPoint(0, 0);
        profileBtn.enableTouchCancel(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        this.addChild(profileBtn);

        // 按鈕Ｘ
        var itemNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_circle_05.png", null, "#lobby_icon_no.png");
        itemNodes.forEach(item => {
            item.bg.setScale(1.1);
            item.word.setScale(0.7);
        });
        var noBtn = new cc.ControlButton(itemNodes[0]);
        noBtn.setBackgroundSpriteForState(itemNodes[1], cc.CONTROL_STATE_HIGHLIGHTED);
        noBtn.setAdjustBackgroundImage(false);
        noBtn.setZoomOnTouchDown(false);
        noBtn.setSwallowTouches(false);
        noBtn.setTouchDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        noBtn.addTargetWithActionForControlEvents(this, this._noBtnClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        noBtn.setPosition(320, midPosY);
        this.addChild(noBtn);

        // 按鈕O
        itemNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_circle_04.png", null, "#lobby_icon_yes.png");
        itemNodes.forEach(item => {
            item.bg.setScale(1.1);
            item.word.setScale(0.7);
        });
        var yesBtn = new cc.ControlButton(itemNodes[0]);
        yesBtn.setBackgroundSpriteForState(itemNodes[1], cc.CONTROL_STATE_HIGHLIGHTED);
        yesBtn.setAdjustBackgroundImage(false);
        yesBtn.setZoomOnTouchDown(false);
        yesBtn.setSwallowTouches(false);
        yesBtn.setTouchDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        yesBtn.addTargetWithActionForControlEvents(this, this._yesBtnClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        yesBtn.setPosition(354, midPosY);
        this.addChild(yesBtn);

        // cell分隔線
        var lineSp = new ccui.Scale9Sprite("lobby_brown_line.png");
        lineSp.setPreferredSize(cc.size(357, 2));
        lineSp.setPosition(197, 4);
        this.addChild(lineSp);

        // 監聽封鎖其他玩家事件
        GS.addListener("NotifyRefreshIsForbidden", this.notifyRefreshIsForbidden.bind(this), this);
    },

    /**
     * 刷新Cell
     * @param param : DataModal.friendData.applyFriendList
     */
    refreshCell: function (param) {
        if (!param)
            return;

        this._photo = param.photo;

        this._userID = param.userID;

        // 暱稱
        this._nicknameLabel.setString(param.nickname);

        // 刷新大頭貼
        this._photoSprite.setPhotoUrl(param.photo, param.userID);
    },

    /**
     * 同意點擊
     */
    _yesBtnClicked: function () {
        if (!this._userID)
            return;

        // 卡loading TODO: 要改成新loading
        GSLoading.addLoadingView();
        // 同意加入好友
        var obj = {
            userid: this._userID,
            type: 2
        };
        DataProcess.sendString("user_invite_friend " + JSON.stringify(obj));
    },

    /**
     * 不同意點擊
     */
    _noBtnClicked: function () {
        if (!this._userID)
            return;

        // 卡loading TODO: 要改成新loading
        GSLoading.addLoadingView();

        // 不同意好友
        var obj = {
            userid: this._userID,
            type: 3
        };
        DataProcess.sendString("user_invite_friend " + JSON.stringify(obj));
    },

    /**
     *  個人資訊頁點擊
     */
    _profileBtnClicked: function (sender, type) {
        var isTouched = (type === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || type === cc.CONTROL_EVENT_TOUCH_DOWN);
        this._mainNode.setColor(isTouched ? JSColor.GRAY : JSColor.WHITE);

        if (type === cc.CONTROL_EVENT_TOUCH_UP_INSIDE) {
            if (!this._userID)
                return;

            DialogManager.addDialog(new ProfileDialog(this._userID));
        }
    },

    notifyRefreshIsForbidden: function (event) {
        if (event.getUserData() === this._userID) {
            this._photoSprite.setPhotoUrl(this._photo, this._userID);
        }
    },
});

ApplyFriendListCell.HEIGHT = 52;