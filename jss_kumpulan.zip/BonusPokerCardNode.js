/**
 * Bonus機台 撲克牌
 */
var BonusPokerCardNode = PokerCardNode.extend({
    /**
     * 顯示贏牌動畫
     */
    displayWinAni: function () {
        var contentSize = this._contentSize;
        // 把所有東西放到contentNode內
        var contentNode = new cc.Node();
        contentNode.setContentSize(contentSize);
        contentNode.setPosition(contentSize.width / 2, contentSize.height / 2);
        this.addChild(contentNode);

        // 外框
        var cardWinBg = new cc.Sprite("#bonus_bet_winning_card_circle.png");
        cardWinBg.setScale(0.92, 0.8);
        contentNode.addChild(cardWinBg, -1);

        // 星星
        var winStar = new cc.Sprite("#bonus_bet_winning_card_star.png");
        winStar.setPosition(-23, 31);
        contentNode.addChild(winStar, 1);

        winStar.runAction(
            cc.repeatForever(cc.sequence(
                    cc.scaleTo(0.5, 0.5),
                    cc.scaleTo(0.5, 1)
                )
            )
        );
        winStar.runAction(cc.rotateBy(3, 540));

        winStar = new cc.Sprite("#bonus_bet_winning_card_star.png");
        winStar.setPosition(0, -32);
        contentNode.addChild(winStar, 1);

        winStar.runAction(
            cc.repeatForever(cc.sequence(
                    cc.scaleTo(0.5, 0.5),
                    cc.scaleTo(0.5, 1)
                )
            )
        );
        winStar.runAction(cc.rotateBy(3, 540));

        contentNode.runAction(cc.sequence(
            cc.delayTime(3),
            cc.removeSelf()
        ));
    },

    /**
     * 輸牌動畫
     */
    displayLoseColor: function () {
        this.setColor(cc.color(150, 150, 150));

        this.runAction(cc.sequence(
            cc.delayTime(3),
            cc.callFunc(() => this.setColor(cc.color(255, 255, 255)))
        ));
    },

    /**
     * 將牌的位置做位移
     * @param {Boolean}     isMoveUp    是上移或往下移
     * @param {Function}    callback    位移完的callback
     */
    pushCard: function (isMoveUp = false, callback) {
        var margin = 5;
        if (!isMoveUp)
            margin = -margin;

        this.runAction(cc.sequence(
            cc.moveBy(0.2, cc.p(0, margin)),
            cc.delayTime(0.6),
            cc.callFunc(() => {
                callback && callback();
            })
        ));
    }
});