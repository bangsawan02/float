/**
 * 這邊存Cangkulan遊戲的檔案列表
 */

var Cangkulan_GameFiles = CommonGameFiles.concat([
    "out_src/GameScene/Cangkulan/Cangkulan_GameScene.js",
    "out_src/GameScene/Cangkulan/Cangkulan_GameLayer.js",
    "out_src/GameScene/Cangkulan/Cangkulan_GameSetting.js",
    "out_src/GameScene/Cangkulan/Cangkulan_GameUtility.js",
    "out_src/GameScene/Cangkulan/Animation/Cangkulan_AnimationLayer.js",
    "out_src/GameScene/Cangkulan/Background/Cangkulan_BackgroundLayer.js",
    "out_src/GameScene/Cangkulan/Background/Cangkulan_SpotLightLayer.js",
    "out_src/GameScene/Cangkulan/CardsLayer/Cangkulan_CardCounterLayer.js",
    "out_src/GameScene/Cangkulan/CardsLayer/Cangkulan_CardNode.js",
    "out_src/GameScene/Cangkulan/CardsLayer/Cangkulan_CardsLayer.js",
    "out_src/GameScene/Cangkulan/CardsLayer/Cangkulan_DrawCardLayer.js",
    "out_src/GameScene/Cangkulan/CardsLayer/Cangkulan_FoldCardLayer.js",
    "out_src/GameScene/Cangkulan/CardsLayer/Cangkulan_HandCardCountNode.js",
    "out_src/GameScene/Cangkulan/CardsLayer/Cangkulan_HandCardsLayer.js",
    "out_src/GameScene/Cangkulan/CardsLayer/Cangkulan_SeaCardsLayer.js",
    "out_src/GameScene/Cangkulan/PlayersLayer/Cangkulan_PlayerCountDownNode.js",
    "out_src/GameScene/Cangkulan/PlayersLayer/Cangkulan_PlayerNode.js",
    "out_src/GameScene/Cangkulan/PlayersLayer/Cangkulan_PlayersLayer.js",
    "out_src/GameScene/Cangkulan/PlayersLayer/Cangkulan_PlayerFoldCardNode.js",
    "out_src/GameScene/Cangkulan/PlayersLayer/Cangkulan_PlayerAnimLayer.js",
    "out_src/GameScene/Cangkulan/PlayersLayer/Cangkulan_PlayerAnimNode.js",
    "out_src/GameScene/Cangkulan/UILayer/Cangkulan_AutoPlayLayer.js",
    "out_src/GameScene/Cangkulan/UILayer/Cangkulan_GameHintLayer.js",
    "out_src/GameScene/Cangkulan/UILayer/Cangkulan_GameRankGameLayer.js",
    "out_src/GameScene/Cangkulan/UILayer/Cangkulan_UILayer.js",
    "out_src/GameScene/Cangkulan/UILayer/Cangkulan_UIOptionButton.js",
    "out_src/GameScene/Cangkulan/UILayer/Cangkulan_UIOptionLayer.js",
]);