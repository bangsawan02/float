/**
 * 農場 pass - 購買 pass dialog
 */
var FarmPassBuyPassDialog = BasePassBuyPassDialog.extend({
    ctor: function (config, param) {
        this._super(config, param);
    },

    _createContentView: function () {
        let ticketIconFileName = this.config.ticketIconFileName || "luxyPass_pic_ticket_01.png";
        let richTextNode = new BasePassRichTextNode([
            [
                // 第一行
                {
                    type: BasePassRichTextNode.Type.TEXT,
                    text: LocalizedString.FarmBingo("需先獲得"),
                },
                {
                    type: BasePassRichTextNode.Type.SPRITE,
                    fileName: "#" + ticketIconFileName,
                    scale: 0.6,
                },
                {
                    type: BasePassRichTextNode.Type.TEXT,
                    text: LocalizedString.FarmBingo("解鎖喔"),
                }
            ],
        ]);
        richTextNode.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 24);
        this._animationLayer.addChild(richTextNode);
    },
});