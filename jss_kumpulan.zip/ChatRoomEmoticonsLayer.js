/**
 * 好友聊天的表情符號貼圖
 */

var ChatRoomEmoticonsLayer = cc.Layer.extend({
    ctor: function (isGuild) {
        this._super();

        var bgSize = this._bgSize = cc.size(188, 103);
        this._isGuild = isGuild;

        // 背景
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(bgSize);
        bgSprite.setAnchorPoint(0, 0);
        bgSprite.setPosition(0, 29);
        this.addChild(bgSprite);

        // 黑底
        var blackBgSprite = new ccui.Scale9Sprite("lobby_bg_list_04.png");
        blackBgSprite.setPreferredSize(cc.size(this._bgSize.width - 15, this._bgSize.height - 31));
        blackBgSprite.setAnchorPoint(0, 0);
        blackBgSprite.setPosition(8, 43);
        this.addChild(blackBgSprite);

        // page
        var pageSize = this._pageSize = cc.size(bgSize.width - 13, bgSize.height);
        var pageView = this._pageView = new ccui.PageView();
        pageView.setPosition(5, 37);
        pageView.setDirection(ccui.ScrollView.DIR_HORIZONTAL);
        pageView.setContentSize(pageSize);
        pageView.setBounceEnabled(true);
        pageView.setIndicatorEnabled(true);
        pageView.setIndicatorSpaceBetweenIndexNodes(10);
        pageView.setIndicatorIndexNodesTexture("lobby_page_point_0.png", ccui.Widget.PLIST_TEXTURE);
        pageView.setIndicatorSelectedIndexColor(cc.color(255, 255, 255));
        pageView.setIndicatorPosition(cc.p(pageSize.width / 2, 0));
        pageView.addEventListener(function () {
            // 更新最後的頁面
            GS.localStorage.setItem("ChatLastMoodPage", pageView.getCurrentPageIndex().toString());
        });
        this.addChild(pageView);

        // 第一頁是常用
        this._pageArray = [];
        for (var i = 0; i < 6; i++) {
            var layout = this._pageArray[i] = new ccui.Layout();
            layout.setContentSize(this._pageSize);
            pageView.addPage(layout);

            this._createPage(i);
        }

        // 加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this._onTouchBegan.bind(this),
        }, this);

        // 註冊
        GS.addListener("NotifyGetCampMoodList", this.notifyGetCampMoodList.bind(this), this);
        GS.addListener("NotifyGetStoreMoodList", this.notifyGetStoreMoodList.bind(this), this);
    },

    /**
     * override
     */
    setVisible: function (visible) {
        // 打開的時候才去檢查需不要重要貼圖資料
        visible && DataModal.moodData.sendMoodInfo();

        this._super(visible);
    },

    onEnter: function () {
        this._super();

        // 拿貼圖資料
        DataModal.moodData.sendMoodInfo();

        // 上次關閉頁面停在哪一頁 要在onEnter做才有用的樣子
        var startPageIndex = parseInt(GS.localStorage.getItem("ChatLastMoodPage", "1"));
        if (startPageIndex === 0) {
            // 如果在第0頁 且常用表情是空的話 指到第一頁
            var lastEmoticonJson = JSON.parse(GS.localStorage.getItem("ChatLastUsedEmoticon2", "[]"));
            if (lastEmoticonJson.length === 0)
                startPageIndex = 1;
        }
        this._pageView.setCurrentPageIndex(startPageIndex);
    },

    onExit: function () {
        cc.spriteFrameCache.removeSpriteFramesFromFile("game/emoticons.plist");

        this._super();
    },

    //創頁面的東西
    _createPage: function (pageIndex) {
        // 先砍掉舊的
        var page = this._pageArray[pageIndex];
        if (!page)
            return;

        page.removeAllChildren();

        // 計算剩餘時間用
        var nowTime = new Date().getTime() / 1000;
        var decreaseTime = nowTime - DataModal.moodData.moodSocketTime;

        var gameString = LocalizedString.Game;
        if (pageIndex == 0) {
            // 常用的表情
            var infoLabel = new cc.LabelTTF(gameString("常用表情"), JSFontBoldName, 8);
            infoLabel.setAnchorPoint(0, 0.5);
            infoLabel.setPosition(10, 84);
            page.addChild(infoLabel);

            // 抓出常用的資訊
            var lastEmoticonJson = JSON.parse(GS.localStorage.getItem("ChatLastUsedEmoticon2", "[]"));
            lastEmoticonJson.forEach((cur, index) => {
                var emoticon = new EmoticonsNode(cur.type, cur.index, decreaseTime, this._emoticonClicked, this, true);
                emoticon.setPosition(18 + 34 * (index % 5), 60 - 35 * (Math.floor(index / 5)));
                emoticon.setScale(0.6);
                page.addChild(emoticon);
            });
        } else {
            // 因頁數轉成表情的Type
            var hintString = null;
            var emoticonType;
            switch (pageIndex) {
                case 1:
                    emoticonType = EmoticonsNodeType.NORMAL;
                    break;
                case 2:
                    emoticonType = EmoticonsNodeType.VIP;
                    break;
                case 3:
                    emoticonType = EmoticonsNodeType.STAR;
                    hintString = gameString("想擁有更多表情?");
                    break;
                case 4:
                    emoticonType = EmoticonsNodeType.HEART;
                    hintString = gameString("想擁有更多愛心人表情符號?");
                    break;
                case 5:
                    emoticonType = EmoticonsNodeType.POKER;
                    hintString = gameString("想擁有更多撲克人表情符號?");
                    break;
                default:
                    break;
            }

            // 創新的
            for (var i = 0; i < 10; i++) {
                var emoticon = new EmoticonsNode(emoticonType, i, decreaseTime, this._emoticonClicked, this, true);
                emoticon.setPosition(18 + 34 * (i % 5), 60 - 35 * (Math.floor(i / 5)));
                emoticon.setScale(0.6);
                page.addChild(emoticon);
            }

            // 判斷是否要加商店的按鈕
            if (hintString) {
                var moreLabel = new cc.LabelTTF(hintString, JSFontBoldName, 11);
                moreLabel.setAnchorPoint(0, 0.5);
                moreLabel.setFontFillColor(JSColor.WHITE);
                moreLabel.setPosition(10, 166);
                page.addChild(moreLabel);

                var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_03.png", cc.size(56, 20), gameString("前往商城"), 10, JSColor.WHITE);
                var button = new cc.ControlButton(itemNodes[0]);
                button.setBackgroundSpriteForState(itemNodes[1], cc.CONTROL_STATE_HIGHLIGHTED);
                button.addTargetWithActionForControlEvents(this, this._goShopClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
                button.setAdjustBackgroundImage(false);
                button.setZoomOnTouchDown(false);
                button.setSwallowTouches(false);
                button.setTouchDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
                button.setPosition(moreLabel.getPosition().x + moreLabel.getContentSize().width + 32, moreLabel.getPosition().y);
                page.addChild(button);
            }
        }
    },

    //出現提示文字
    _showHintString: function (hintString, pageIndex) {
        var hintTag = 15384;
        //先砍掉舊的
        var page = this._pageArray[pageIndex];
        page.removeChildByTag(hintTag);

        //創新的
        var hintLabel = new cc.LabelTTF(hintString, JSFontBoldName, 8);
        hintLabel.setAnchorPoint(0, 1);
        hintLabel.setPosition(3, 88);
        page.addChild(hintLabel, 1, hintTag);

        var action1 = cc.delayTime(2);
        var action2 = cc.fadeOut(0.5);
        var action3 = cc.removeSelf();
        hintLabel.runAction(cc.sequence(action1, action2, action3));
    },

    /**
     * 按鈕
     */
    //按到表情
    _emoticonClicked: function (senderObj) {
        /*
         {
         page:          //哪一頁
         index:         //第幾個
         emoticonObj:   //表情的物件 有可能是null
         canUse:        //是否能使用
         }
         */
        if (!this.isVisible())
            return;

        var sendString;
        switch (senderObj.type) {
            case EmoticonsNodeType.NORMAL:
                // 普通表情
                sendString = "emoticons_n_0" + senderObj.index;
                break;
            case EmoticonsNodeType.VIP:
                // VIP表情
                if (senderObj.canUse)
                    sendString = "emoticons_v_0" + senderObj.index;
                else {
                    //出現說明
                    this._showHintString(LocalizedString.Game("VIP限定表情"), 2);
                }
                break;
            case EmoticonsNodeType.STAR:
                // 特殊表情
                if (senderObj.canUse)
                    sendString = "emoticons_s_" + senderObj.emoticonObj.serial;
                else {
                    //開商城
                    this._goShopClicked();
                }
                break;
            case EmoticonsNodeType.HEART:
                // 商城表情
                if (senderObj.canUse)
                    sendString = "emoticons_h_" + senderObj.emoticonObj.serial;
                else {
                    //開商城
                    this._goShopClicked();
                }
                break;
            case EmoticonsNodeType.POKER:
                // 商城表情
                if (senderObj.canUse)
                    sendString = "emoticons_p_" + senderObj.emoticonObj.serial;
                else {
                    //開商城
                    this._goShopClicked();
                }
                break;
            default:
                break;
        }

        if (sendString) {
            // 送出貼圖
            if (this._isGuild) {
                var sendStr = {};
                sendStr.type = 2;
                sendStr.message = sendString;
                DataProcess.sendString("guild_say " + JSON.stringify(sendStr));
            } else {
                DataModal.chatRoomData.sendFriendChatMessageCmd(ChatRoomData.MessageType.Emoticons, sendString);
            }
            // 把常用項目記下來 先找出原本常用裡面有沒有他
            var lastEmoticonJson = JSON.parse(GS.localStorage.getItem("ChatLastUsedEmoticon2", "[]"));
            for (var i = 0, len = lastEmoticonJson.length; i < len; i++) {
                var thisObj = lastEmoticonJson[i];
                if (thisObj.type === senderObj.type && thisObj.index === senderObj.index) {
                    // 有找到 要砍掉
                    lastEmoticonJson.splice(i, 1);
                    break;
                }
            }

            // 加入到第0個
            lastEmoticonJson.splice(0, 0, {
                type: senderObj.type,
                index: senderObj.index
            });

            // 超過10個的話砍掉最後一個
            if (lastEmoticonJson.length > 10)
                lastEmoticonJson.pop();

            // 存下來
            GS.localStorage.setItem("ChatLastUsedEmoticon2", JSON.stringify(lastEmoticonJson));

            this._createPage(0);

            // 把選單關掉
            this.setVisible(false);
        }
    },

    //按到前往商城
    _goShopClicked: function () {
        if (PushScene.isGame) {
            // 因為遊戲內可能會關掉Dialog 透過代參數讓Manager管理
            DialogManager.addDialog(new ChipShopDialog(ChipShopDialog.Type.GAME_SELF, DataModal.profileData.account, ShopProductType.GIFT), true, true);
        } else {
            // 此Dialog不要給Manager控管
            DialogManager.addDialog(new ChipShopDialog(ChipShopDialog.Type.LOBBY, DataModal.profileData.account, ShopProductType.GIFT), false);
        }

        // 關掉
        this.setVisible(false);
    },

    /**
     * touch點擊
     * 點擊非聊天室會關閉視窗
     */
    _onTouchBegan: function (touch, event) {
        var target = event.getCurrentTarget();
        if (!target.isVisible())
            return false;
        for (var c = target.parent; c != null; c = c.parent) {
            if (!c.isVisible())
                return false;
        }

        var boundBox = cc.rect(0, 0, this._bgSize.WIDTH, this._bgSize.height);
        var touchPos = this.convertToNodeSpace(touch.getLocation());
        if (!cc.rectContainsPoint(boundBox, touchPos)) {
            // 不是點到聊天室 關閉視窗
            this.setVisible(false);
        }
        return true;
    },

    /**
     * 通知
     */
    // 特殊表情更新
    notifyGetCampMoodList: function () {
        // 特殊表情 星星
        this._createPage(3);

        // 最後還是要更新一下表情 會需要server噴回來的序號
        this._createPage(0);
    },

    //商店賣的表情更新
    notifyGetStoreMoodList: function () {
        // 心表情
        this._createPage(4);
        // 撲克表情
        this._createPage(5);

        // 最後還是要更新一下表情 會需要server噴回來的序號
        this._createPage(0);
    }
});