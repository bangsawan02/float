/**
 * CapsaSusun 所有放牌的地方都在這 (發牌、手牌、智慧選牌)
 */
var CapsaSusun_CardsLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 擋touch
        var dummyTouchLayer = this._dummyTouchLayer = new DummyTouchLayer(JSVisibleSize);
        dummyTouchLayer.setVisible(false);
        this.addChild(dummyTouchLayer);

        // 在場上的各家手牌
        var outCardLayer = this._outCardLayer = new CapsaSusun_OutCardLayer();
        this.addChild(outCardLayer);

        // 玩家的手牌(決策區)
        var handCardLayer = this._handCardLayer = new CapsaSusun_HandCardLayer();
        this.addChild(handCardLayer);

        // 倒數計時(放在最上層)
        var clockNode = this._clockNode = new CapsaSusun_ClockNode();
        clockNode.setPosition(255 + JSScreenBonusHalfWidth, 145 + JSScreenBonusHalfHeight);
        this.addChild(clockNode);

        this.clean();
    },

    clean: function () {
        // 場上正在玩的玩家
        this._playingPlayers = [];
        // this._outCardArray[玩家座位server][全部的牌]
        this._outCardArray = {};

        // 清掉手牌
        this._handCardLayer.clean();
        this._handCardLayer.setVisible(false);

        // 清掉場上的牌
        this._outCardLayer.clean();

        this._clockNode.setVisible(false);
    },

    /**
     * 設定是否輪到我
     * @param {boolean} isTurnMe
     */
    setIsTurnMe: function (isTurnMe) {
        // 按照是否輪到自己設定倒數時間
        if (!isTurnMe)
            this._clockNode.stop();

    },

    /**
     * 正在玩的玩家(server位置)
     */
    setPlayingPlayers: function (playerArray) {
        this._playingPlayers = playerArray;
    },

    /**
     * 開始倒數
     */
    startClock: function (time) {
        this._clockNode.start(time);
    },

    stopClock: function () {
        this._clockNode.stop();
    },

    /**
     * 決策頁面開啟/關閉
     * @param isVisible  開啟/關閉
     */
    setHandCardVisible: function (isVisible) {
        if (!isVisible) {
            this._clockNode.setPosition(255 + JSScreenBonusHalfWidth, 145 + JSScreenBonusHalfHeight);
        } else {
            this._clockNode.setPosition(255 + JSScreenBonusHalfWidth, 263 + JSScreenBonusHeight);
            this._handCardLayer.startChangeCard();
        }

        this._dummyTouchLayer.setVisible(isVisible);
        this._handCardLayer.setVisible(isVisible);
    },

    /**
     * 顯示當前是否決策完畢
     * @param isSpecial  : 有特殊牌型不用決策
     */
    showChangeCardAnim: function (isSpecial) {
        if (!isSpecial)
            this._outCardLayer.showReadyFight(0, false);

        this._playingPlayers.forEach(cur => {
            // 自己在前面處理掉了
            if (DataModal.gameData.myPos !== cur) {
                var sitPos = DataModal.gameData.getDirectionByServerDirection(cur);
                this._outCardLayer.showReadyFight(sitPos, false);
            }
        });

        // 3秒跑換牌動畫
        this._outCardLayer.showChangeCardAnim();
    },

    /**
     * 開始比牌(打開比牌 關掉決策)
     */
    showFightCardLayer: function () {
        this._outCardLayer.setVisible(true);
        this.setHandCardVisible(false);

        // 開始比牌 關閉換牌動畫
        this._outCardLayer.startFight();

        // 開始比牌 要跟server說玩家有沒有動過牌
        this._handCardLayer.startFight();
    },

    /**
     * 開始發牌動畫
     * @param dealerPos     dealer的位置
     * @param sendPosArray  發給哪些玩家
     * @param handCards     自己的手牌
     */
    dealCardAnim: function (dealerPos, sendPosArray, handCards) {
        // 先轉成正確位置
        dealerPos = DataModal.gameData.getDirectionByServerDirection(dealerPos);
        var playerSendPosArray = sendPosArray.map(cur => DataModal.gameData.getDirectionByServerDirection(cur));

        this._outCardLayer.shuffleAnim(dealerPos, playerSendPosArray, handCards);
        this.setPlayingPlayers(sendPosArray);
    },

    addHandCard: function (handCards) {
        // 放入手牌
        this._handCardLayer.addHandCard(handCards);
    },

    // 一般動畫
    showNormalCardFighting: function (posArray) {
        // 照順序開始翻開
        this.runAction(
            cc.sequence(
                cc.callFunc(() => {
                    posArray.forEach(pos => {
                        this._outCardLayer.showFightingAnim(pos, 0);
                    });
                }),
                cc.delayTime(0.75),
                cc.callFunc(() => {
                    posArray.forEach(pos => {
                        this._outCardLayer.showFightingAnim(pos, 1);
                    });
                }),
                cc.delayTime(0.75),
                cc.callFunc(() => {
                    posArray.forEach(pos => {
                        this._outCardLayer.showFightingAnim(pos, 2);
                    });
                }),
                cc.delayTime(0.75),
                cc.callFunc(() => {
                    posArray.forEach(pos => {
                        this._outCardLayer.showFightingAnim(pos, 3);
                    });
                })
            )
        );
    },

    // 特殊動畫
    showSpecialFighting: function (posArray) {
        posArray.forEach((cur) => {
            this._outCardLayer.showSpecialOutCard(cur, cur !== DataModal.gameData.myPos);
        });
    },

    // 直接一起翻牌
    showAllCardSkipAnimation: function (posArray, isSpecial) {
        posArray.forEach(pos => {
            if (isSpecial)
                this._outCardLayer.showSpecialCardSkipAnimation(pos);
            else
                this._outCardLayer.showFightingAnim(pos, 3);
        });
    },

    /**
     * 特殊牌型默認有在玩
     */
    cmd_special: function () {
        this._handCardLayer.setPlaying(true);
    },

    // 設定玩家決策完畢，準備好比牌
    cmd_plready: function (serverDir, cardArray, isSpecial) {
        // 提前出牌 停止震動
        if (serverDir === DataModal.gameData.myPos)
            this._clockNode.setShock(false);

        this._outCardLayer.setOutCard(serverDir, cardArray, isSpecial);
        // 先記錄下來
        this._outCardArray[serverDir] = cardArray;
    },

    /**
     * 牌局重現
     */
    cmd_current_playing: function (jsonValue, isPlaying, specialPosArray) {
        // 設定正在玩的玩家
        var playingPlayers = (jsonValue["playing"] || []).map(cur => parseInt(cur));
        this.setPlayingPlayers(playingPlayers);

        var special = JSCodeUtility.getIntValue(jsonValue["gotSpecial"]);

        // 手牌
        var isReady = JSCodeUtility.getIntValue(jsonValue["ready"]);
        var handCards = JSCodeUtility.getStringValue(jsonValue["handCard"]).match(REGEXP_TWO_NUMBERS);
        var decisionTime = JSCodeUtility.getIntValue(jsonValue["remainTimer"]);
        handCards && this.addHandCard(handCards);

        if (decisionTime) {
            // 出牌階段
            this.startClock(decisionTime);

            // 已經出玩牌 or 是觀戰玩家 要停止震動
            if (isReady || DataModal.gameData.myPos === -1)
                this._clockNode.setShock(false);

            this.setHandCardVisible(isPlaying && !isReady && !special);
        } else {
            this._clockNode.setShock(false);
            this.setHandCardVisible(false);
        }

        this._outCardLayer.cmd_current_playing(this._playingPlayers, this._outCardArray, specialPosArray, handCards);
    },

    // 重現要比牌
    current_playing_fighting: function (specialPosArray) {
        this._outCardLayer.cmd_current_playing(this._playingPlayers, this._outCardArray, specialPosArray);
    }
});