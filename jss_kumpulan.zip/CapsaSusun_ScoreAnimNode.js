/**
 *  CapsaSusun 分數Node
 */
var CapsaSusun_ScoreAnimNode = cc.Node.extend({
    ctor: function (sitNum) {
        this._super();

        // 總得分
        this._totalScore = 0;
        this._sitNum = sitNum;

        // 牌右邊放每墩分數顯示的Node
        var stackScoreNode = this._stackScoreNode = new cc.Node();
        this.addChild(stackScoreNode);

        // 底下放總分數字顯示的Node
        var totalScoreNode = this._totalScoreNode = new cc.Node();
        this.addChild(totalScoreNode);
    },

    // 清掉所有東西
    clean: function () {
        this._totalScore = 0;                       // 總得分
        this._stackScoreNode.removeAllChildren();   // 每次都會重新加 所以清掉子物件
        this._totalScoreNode.removeAllChildren();   // 每次都會重新加 所以清掉子物件
    },

    // 在畫面加上別人的指定牌墩分數
    _addOtherStackScore: function (stackNum, score) {
        var posX = (stackNum) ? 50 : 30;
        var posY = (1 - stackNum) * 28;
        var numScale = 1.25;
        var numberSp, numStr, symbolStr;
        var stackScoreNode = this._stackScoreNode;

        // 分數 ------------------------------------
        if (score < 0) {
            numStr = "#capsaSusun_num_02_";
            symbolStr = "#capsaSusun_num_02_-.png";
            score = score * -1;
        } else {
            numStr = "#capsaSusun_num_01_";
            symbolStr = "#capsaSusun_num_01_+.png";
        }

        // 分數數字圖
        numberSp = new GSSpriteNumberNode({
            symbolName: symbolStr,
            symbolLoc: GSSpriteNumberNode.SymbolLoc.FRONT,
            number: score,
            numStr: numStr,
            spW: 8,
        });
        numberSp.setScale(numScale);
        numberSp.setPosition(posX, posY);
        numberSp.setAnchorPoint(0, 0.5);
        stackScoreNode.addChild(numberSp, 1);
    },

    // 在畫面加上自己的指定牌墩分數
    _addSelfStackScore: function (stackNum, score, specialScore) {
        var posX = 70;
        var posY = (2 - stackNum) * 20 - 15;
        var numScale = 1.25;
        var numberSp, numStr, symbolStr;
        var stackScoreNode = this._stackScoreNode;

        if (stackNum === 0) {
            var bgSp = new ccui.Scale9Sprite("capsaSusun_pic_frame_02.png");
            bgSp.setPreferredSize(cc.size(160, 90));
            bgSp.setPosition(posX + 75, -5);
            stackScoreNode.addChild(bgSp);
        }

        // 第幾墩圖字
        var sp = new cc.Sprite("#capsaSusun_word_round_0" + (stackNum + 1) + ".png");
        sp.setPosition(posX, posY);
        sp.setAnchorPoint(0, 0.5);
        stackScoreNode.addChild(sp);
        posX += sp.getContentSize().width;

        // 分數 ------------------------------------
        if (score < 0) {
            numStr = "#capsaSusun_num_02_";
            symbolStr = "#capsaSusun_num_02_-.png";
            score = score * -1;
        } else {
            numStr = "#capsaSusun_num_01_";
            symbolStr = "#capsaSusun_num_01_+.png";
        }

        // 分數數字圖
        numberSp = new GSSpriteNumberNode({
            symbolName: symbolStr,
            symbolLoc: GSSpriteNumberNode.SymbolLoc.FRONT,
            number: score,
            numStr: numStr,
            spW: 8,
        });
        numberSp.setScale(numScale);
        numberSp.setPosition(posX, posY);
        numberSp.setAnchorPoint(0, 0.5);
        stackScoreNode.addChild(numberSp, 1);
        posX += numberSp.getContentSize().width * numScale;

        // 特殊分數 ------------------------------------
        if (specialScore == 0)
            return;

        if (specialScore < 0) {
            numStr = "#capsaSusun_num_02_";
            symbolStr = "#capsaSusun_num_02_-.png";
            specialScore = specialScore * -1;
        } else {
            numStr = "#capsaSusun_num_01_";
            symbolStr = "#capsaSusun_num_01_+.png";
        }
        // 左括號
        sp = new cc.Sprite(numStr + "(.png");
        sp.setScale(numScale);
        sp.setAnchorPoint(0, 0.5);
        sp.setPosition(posX, posY);
        stackScoreNode.addChild(sp);
        posX += 7;

        // 特殊分數數字圖
        numberSp = new GSSpriteNumberNode({
            symbolName: symbolStr,
            symbolLoc: GSSpriteNumberNode.SymbolLoc.FRONT,
            number: specialScore,
            numStr: numStr,
            spW: 8,
        });
        numberSp.setPosition(posX, posY);
        numberSp.setScale(numScale);
        numberSp.setAnchorPoint(0, 0.5);
        stackScoreNode.addChild(numberSp, 1);
        posX += numberSp.getContentSize().width * numScale;

        // 右括號
        sp = new cc.Sprite(numStr + "(.png");
        sp.setFlippedX(true);
        sp.setScale(numScale);
        sp.setAnchorPoint(0, 0.5);
        sp.setPosition(posX, posY);
        stackScoreNode.addChild(sp);
    },

    // 其他人更新總分
    _updateOtherTotalScore: function (score, addScore) {
        this._stackScoreNode.removeAllChildren();
        if (addScore) {
            // 要加上去
            this._totalScore += score;
            score = this._totalScore;
        } else {
            // 直接取代總分
            this._totalScore = score;
        }

        // 清除舊的數字Node
        var totalScoreNode = this._totalScoreNode;
        totalScoreNode.removeAllChildren();
        totalScoreNode.setPosition(0, -42);

        var bgSp = new ccui.Scale9Sprite("capsaSusun_pic_frame_01.png");
        bgSp.setPreferredSize(cc.size(100, 22));
        totalScoreNode.addChild(bgSp);

        // 總得分 ------------------------------------
        var numStr, symbolStr, wordSpName;
        if (score < 0) {
            numStr = "#capsaSusun_num_02_";
            symbolStr = "#capsaSusun_num_02_-.png";
            wordSpName = "#capsaSusun_word_total_02.png";
            score = score * -1;
        } else {
            numStr = "#capsaSusun_num_01_";
            symbolStr = "#capsaSusun_num_01_+.png";
            wordSpName = "#capsaSusun_word_total_01.png";
        }

        var totalWord = new cc.Sprite(wordSpName);
        totalWord.setPosition(-2, 0);
        totalWord.setAnchorPoint(1, 0.5);
        totalScoreNode.addChild(totalWord);

        // 分數數字圖
        var numberSp = new GSSpriteNumberNode({
            symbolName: symbolStr,
            symbolLoc: GSSpriteNumberNode.SymbolLoc.FRONT,
            number: score,
            numStr: numStr,
            spW: 8,
        });
        numberSp.setAnchorPoint(0, 0.5);
        numberSp.setPosition(3, 0);
        totalScoreNode.addChild(numberSp);

        // 縮放動畫
        totalScoreNode.setScale(0.8);
        totalScoreNode.runAction(cc.sequence(cc.scaleTo(0.3, 0.7), cc.scaleTo(0.15, 1.2), cc.scaleTo(0.15, 0.9)));
    },

    // 更新自己總分
    _updateSelfTotalScore: function (score, addScore) {
        if (addScore) {
            // 要加上去
            this._totalScore += score;
            score = this._totalScore;
        } else {
            // 直接取代總分
            this._totalScore = score;
        }

        var totalScoreNode = this._totalScoreNode;
        totalScoreNode.removeAllChildren();
        totalScoreNode.setPosition(150, -41);

        // 總得分 ------------------------------------
        var numStr, symbolStr, wordSpName;
        if (score < 0) {
            numStr = "#capsaSusun_num_02_";
            symbolStr = "#capsaSusun_num_02_-.png";
            wordSpName = "#capsaSusun_word_total_02.png";
            score = score * -1;
        } else {
            numStr = "#capsaSusun_num_01_";
            symbolStr = "#capsaSusun_num_01_+.png";
            wordSpName = "#capsaSusun_word_total_01.png";
        }

        var totalWord = new cc.Sprite(wordSpName);
        totalWord.setPosition(-2, 0);
        totalWord.setAnchorPoint(1, 0.5);
        totalScoreNode.addChild(totalWord);

        // 分數數字圖
        var numberSp = new GSSpriteNumberNode({
            symbolName: symbolStr,
            symbolLoc: GSSpriteNumberNode.SymbolLoc.FRONT,
            number: score,
            numStr: numStr,
            spW: 8,
        });
        numberSp.setAnchorPoint(0, 0.5);
        numberSp.setPosition(3, 0);
        totalScoreNode.addChild(numberSp);
        // 縮放動畫
        numberSp.runAction(cc.sequence(cc.scaleTo(0.3, 0.6), cc.scaleTo(0.15, 1.2), cc.scaleTo(0.15, 1)));
    },

    // 在畫面加上指定牌墩分數
    // stackNum:第幾墩, score:分數, specialScore:特殊分數
    addStackScore: function (stackNum, score, specialScore) {
        var myPos = DataModal.gameData.myPos;
        var direction = DataModal.gameData.getDirectionByServerDirection(myPos);
        if (this._sitNum === direction) {
            this._addSelfStackScore(stackNum, score, specialScore);
            var totalAddScore = parseInt(score) + parseInt(specialScore);
            this._updateSelfTotalScore(totalAddScore, true);
        } else
            this._addOtherStackScore(stackNum, score);
    },

    // 更新總分
    // score 分數, addScore(true: 要加上去, false: 直接取代總分)
    updateTotalScore: function (score, addScore = false) {
        var myPos = DataModal.gameData.myPos;
        var direction = DataModal.gameData.getDirectionByServerDirection(myPos);
        if (this._sitNum === direction)
            this._updateSelfTotalScore(score, addScore);
        else
            this._updateOtherTotalScore(score, addScore);
    },

});
