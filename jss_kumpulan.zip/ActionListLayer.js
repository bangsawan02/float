/**
 * JSScreenBonusHalfWidth / JSScreenBonusHalfHeight在外面加了
 */
var ActionListLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        var freeChipString = LocalizedString.FreeChip;

        var bgMidSprite = new ccui.Scale9Sprite("lobby_bg_list_04.png");
        bgMidSprite.setPreferredSize(cc.size(400, 217));
        bgMidSprite.setAnchorPoint(0.5, 0);
        bgMidSprite.setPosition(295, 16);
        this.addChild(bgMidSprite);

        // 說明文字
        var infoLabel = new cc.LabelTTF(freeChipString("點擊圖片查看詳情"), JSFontBoldName, 10);
        infoLabel.setPosition(447, 226);
        infoLabel.setAnchorPoint(1, 0.5);
        this.addChild(infoLabel);

        // 下方主體
        var mainLayer = this._mainLayer = new cc.Layer();
        var scrollSize = cc.size(290, 200);
        var scrollView = this._scrollView = new cc.ScrollView(scrollSize, mainLayer);
        scrollView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        scrollView.setPosition(150, 17);
        scrollView.setContentOffset(cc.p(0, 0));
        scrollView.setCascadeOpacityEnabled(true);
        this.addChild(scrollView);

        // 更新畫面
        this._refreshView();

        // 註冊
        GS.addListener("NotifyActionListDone", this.notifyActionListDone.bind(this), this);
    },

    /**
     * 更新畫面
     */
    _refreshView: function () {
        var mainLayer = this._mainLayer;
        var scrollView = this._scrollView;
        var actionList = DataModal.lobbyActionData.actionList;

        // 先砍光東西
        mainLayer.removeAllChildren();

        // 算內容大小
        var totalLen = actionList.length;
        var eachHeight = 150;               // 每一個高度
        var totalHeight = Math.floor((totalLen + 1) / 2) * eachHeight;
        var contentSize = cc.size(scrollView.getViewSize().width, totalHeight);
        scrollView.setContentSize(contentSize);

        // 排畫面
        var nowPosY = totalHeight;
        for (var i = 0; i < totalLen; i++) {
            var actionParam = actionList[i];

            // 按鈕
            var posX = 80 + 130 * (i % 2);
            var button = new ActionListButton(actionParam);
            button.setPosition(posX, nowPosY - 53);
            button.addTargetWithActionForControlEvents(this, this._buttonClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
            mainLayer.addChild(button);

            // 文字
            var nameLabel = new cc.LabelTTF(actionParam.name, JSFontBoldName, 16);
            nameLabel.setPosition(posX, nowPosY - 124);
            mainLayer.addChild(nameLabel, 1);

            if (i % 2 === 1)
                nowPosY -= eachHeight;
        }

        // 重新對位
        scrollView.setContentOffset(cc.p(0, scrollView.getViewSize().height - contentSize.height));
    },

    /**
     * 按鈕
     */
    _buttonClicked: function (sender) {
        // 透過picNum來抓下一個動作
        var actionParam = sender.actionParam;
        switch (actionParam.picNum) {
            case 4:
                // 問券 到下一頁
                var title = actionParam.name.replace("\n", " ");
                var nextLayer = new LobbyWebViewLayer(title, GS.transferDomain(DataModal.lobbyActionData.questParam.url));
                nextLayer.viewDidDisappear = function () {
                    // 要送拿reward的指令
                    DataProcess.sendString("questionnairel_getReward");
                };
                PushScene.pushLayer(nextLayer);
                break;
            case 6:
                if (actionParam.isNoviceSignIn) {
                    // 新手簽到
                    DialogManager.addDialog(new NoviceSignInDialog(), true, true);
                }
                break;
        }

        // 關掉此Dialog
        GS.dispatchCustomEvent("NotifyCloseActionListDialog");
    },

    /**
     * 通知
     */
    // 更新List
    notifyActionListDone: function () {
        this._refreshView();
    },
});