/**
 * 玩家的手牌 非自己的
 */
// 手牌張數的設定 分別有 1 2 3 4張的設定
var DOMINO_PLAYER_HAND_CARD_SETTING = {
    1: {
        pos: [cc.p(0, 0)],
        rotation: [0],
    },
    2: {
        pos: [cc.p(-3, 0), cc.p(3, 0)],
        rotation: [-20, 20],
    },
    3: {
        pos: [cc.p(-7, -2), cc.p(0, 0), cc.p(7, -2)],
        rotation: [-30, 0, 30],
    },
    4: {
        pos: [cc.p(-7, -2), cc.p(-2, 0), cc.p(2, 0), cc.p(7, -2)],
        rotation: [-30, -15, 15, 30],
    }
};

var Domino_PlayerHandCardNode = cc.Node.extend({
    ctor: function () {
        this._super();

        this.setCascadeOpacityEnabled(true);

        this._cardSpriteArray = [];         // 牌都放在這

    },

    cleanData: function () {
        this._cardSpriteArray = [];

        // 清掉所有畫面
        this.removeAllChildren();
    },

    /**
     * 增加手牌
     */
    addCard: function () {
        var nowLen = this._cardSpriteArray.length;
        if (nowLen >= 4)
            return;

        var settingParam = DOMINO_PLAYER_HAND_CARD_SETTING[nowLen + 1];

        // 先加一張
        var cardSprite = new cc.Sprite("#game_card_bg_back.png");
        cardSprite.setScale(0.55);
        this.addChild(cardSprite);
        this._cardSpriteArray.push(cardSprite);

        // 所有的牌移到定位
        var moveTime = 0.2;
        this._cardSpriteArray.forEach(function (cur, index) {
            var moveTag = 9278;
            // 先停掉移動的Action
            cur.stopActionByTag(moveTag);

            // 新增移動的Action
            var action = cc.spawn(
                cc.moveTo(moveTime, settingParam.pos[index]),
                cc.rotateTo(moveTime, settingParam.rotation[index])
            );
            action.setTag(moveTag);
            cur.runAction(action);
        });

        // 第一張加跑淡入
        cardSprite.setOpacity(0);
        cardSprite.runAction(cc.fadeIn(0.1));
    },

    /**
     * 抓取手牌數量
     */
    getCardCount: function () {
        return this._cardSpriteArray.length;
    },
});