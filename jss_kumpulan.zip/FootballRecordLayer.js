/**
 * 足球機台的紀錄
 */

var FootballRecordLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this._showPos = cc.p(JSVisibleSize.width - 25 - JSScreenSafeWidth, 0);
        this._closePos = cc.p(JSVisibleSize.width + 25, 0);
        this._isShow = false;

        // 主要放的Node 48 * 38
        var showNode = this._showNode = new cc.Node();
        showNode.setPosition(this._closePos);
        showNode.setVisible(false);
        this.addChild(showNode);

        // 背景
        var bgSprite = new ccui.Scale9Sprite("bg_black_and_gray_frame.png");
        bgSprite.setPreferredSize(cc.size(55, 185));
        bgSprite.setPosition(0, JSScreenMidPos.y + 16);
        showNode.addChild(bgSprite);

        // 五個紀錄的位置
        this._recordNodes = [];
        for (var i = 0; i < 5; i++) {
            var recordNode = this._recordNodes[i] = new cc.Node();
            recordNode.setPosition(0, JSScreenMidPos.y + 88 - i * 36);
            showNode.addChild(recordNode);

            // 背景
            var recordBgSprite = new cc.Sprite("#football_pic_record.png");
            recordNode.addChild(recordBgSprite);
        }
    },

    /**
     * 出現或關掉
     */
    showOrClose: function () {
        this._isShow = !this._isShow;

        var showNode = this._showNode;
        showNode.stopAllActions();

        if (this._isShow) {
            // 要出現
            showNode.setVisible(true);
            showNode.runAction(cc.moveTo(0.2, this._showPos).easing(cc.easeBackOut()));

            // 更新一次畫面
            this.refreshRecord();
        } else {
            // 要關掉
            showNode.runAction(cc.sequence(
                cc.moveTo(0.2, this._closePos).easing(cc.easeBackIn()),
                cc.hide()
            ));
        }
    },

    /**
     * 更新記錄
     */
    refreshRecord: function () {
        // 假如沒出現畫面就不理它
        if (!this._isShow)
            return;

        // 沒有筆數也不理它
        var footballRecordHistory = DataModal.vegasData.footballRecordHistory;
        if (!footballRecordHistory || footballRecordHistory.length === 0)
            return;

        // 最多5筆
        var len = footballRecordHistory.length;
        for (var i = 0; i < 5 && i < len; i++) {
            var recordNode = this._recordNodes[i];

            // 方向圖片
            var arrowSprite = recordNode.arrowSprite;
            if (!arrowSprite) {
                arrowSprite = new cc.Sprite("#football_pic_record_arrow.png");
                arrowSprite.setScale(0.65);
                arrowSprite.setAnchorPoint(0.5, 0);
                arrowSprite.setPosition(0, -7);
                recordNode.arrowSprite = arrowSprite;
                recordNode.addChild(arrowSprite);
            }

            var rotation;
            switch (footballRecordHistory[i]) {
                case FootballLayer.Direction.UP:
                    rotation = 0;
                    break;
                case FootballLayer.Direction.UP_LEFT:
                    rotation = -45;
                    break;
                case FootballLayer.Direction.UP_RIGHT:
                    rotation = 45;
                    break;
                case FootballLayer.Direction.DOWN_LEFT:
                    rotation = -90;
                    break;
                case FootballLayer.Direction.DOWN_RIGHT:
                    rotation = 90;
                    break;
            }
            arrowSprite.setRotation(rotation);
        }
    },
});