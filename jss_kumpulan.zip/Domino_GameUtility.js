var Domino_GameUtility = {};

/*
 Server傳來的座位玩家不一定在0

 4    (荷官)   5
 3                    6
 2                    7
 1   0(玩家)   8

 ServerPos                 <-->        GamePos
 九人 [0,1,2,3,4,5,6,7,8]              [0,1,2,3,4,5,6,7,8]
 五人 [0,-,2,-,4,-,6,-,8]              [0,-,2,-,4,5,-,7,-]
 三人 [0,-,-,3,-,-,6,-,-]              [0,-,-,3,-,-,6,-,-]

 */

(function () {
    // 玩家位置 (先產生好 之後要加上JSScreenBonus 這樣可以減省掉每次都要產生多次的cc.p)
    var GAME_PLAYER_POSITION = [
        cc.p(219, 95),
        cc.p(115, 97),
        cc.p(60, 170),
        cc.p(168, 241),
        cc.p(352, 241),
        cc.p(453, 170),
        cc.p(397, 97)
    ];

    // 發牌到玩家的位置 (先產生好 之後要加上JSScreenBonus 這樣可以減省掉每次都要產生多次的cc.p)
    var GAME_DEAL_CARD_POSITION = [
        cc.p(249, 120),
        cc.p(147, 123),
        cc.p(123, 177),
        cc.p(167, 201),
        cc.p(345, 201),
        cc.p(395, 177),
        cc.p(370, 123)
    ];

    // 莊家圖片的位置 (先產生好 之後要加上JSScreenBonus 這樣可以減省掉每次都要產生多次的cc.p)
    var GAME_DEAL_IMAGE_POSITION = [
        cc.p(263, 124),
        cc.p(160, 126),
        cc.p(133, 164),
        cc.p(194, 199),
        cc.p(318, 199),
        cc.p(379, 164),
        cc.p(352, 126)
    ];

    /**
     * 回傳玩家大頭貼的位置 <br/>
     * @param {sitNum} 畫面上的位置 <br/>
     */
    Domino_GameUtility.getPlayerPosition = function (sitNum) {
        // -1是荷官
        if (parseInt(sitNum) === -1) {
            return cc.p(JSScreenMidPos.x, 238 + JSScreenBonusHalfHeight);
        }

        // 其他位置
        var originPos = GAME_PLAYER_POSITION[sitNum];
        return cc.p(originPos.x + JSScreenBonusHalfWidth, originPos.y + JSScreenBonusHalfHeight);
    };

    /**
     * 回傳玩家發牌的位置 <br/>
     * @param {sitNum} 畫面上的位置 <br/>
     */
    Domino_GameUtility.getDealCardPosition = function (sitNum) {
        var originPos = GAME_DEAL_CARD_POSITION[sitNum];
        return cc.p(originPos.x + JSScreenBonusHalfWidth, originPos.y + JSScreenBonusHalfHeight);
    };

    /**
     * 回傳這一局的Dealer的位置(黑色底圖上面有一個"D") <br/>
     * @param {sitNum} 畫面上的位置
     */
    Domino_GameUtility.getDealerPosition = function (sitNum) {
        var originPos = GAME_DEAL_IMAGE_POSITION[sitNum];
        return cc.p(originPos.x + JSScreenBonusHalfWidth, originPos.y + JSScreenBonusHalfHeight);
    };

    /**
     * 回傳多少錢籌碼應該要是什麼顏色 <br/>
     * @param {money} 多少錢
     */
    Domino_GameUtility.getChipImage = function (money) {
        var image;
        if (money < 1000)
            image = "#game_pic_chips01.png";
        else if (money < 10000)
            image = "#game_pic_chips02.png";
        else if (money < 100000)
            image = "#game_pic_chips03.png";
        else if (money < 1000000)
            image = "#game_pic_chips04.png";
        else if (money < 10000000)
            image = "#game_pic_chips05.png";
        else
            image = "#game_pic_chips06.png";

        return image;
    };

    Domino_GameUtility.getDealerImage = function (dealerIndex) {
        var defaultDealer = JSStringUtility.format("common/dealer/dealer_basic_0%d.png", dealerIndex);

        return GameTableTheme.getDealerTheme(GSEnum.Game.Domino, defaultDealer);
    };
})();
