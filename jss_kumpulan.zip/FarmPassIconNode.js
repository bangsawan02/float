/**
 * v5.6.5 農場 Pass - icon
 */

var FarmPassIconNode = GSControlButton.extend({
    ctor: function () {
        window.aa = this;
        this._super(undefined, cc.size(40, 40));

        this.key = "FarmPassIconNode";

        var contentNode = this._contentNode;
        this._mainNode.setPosition(20, 20);

        // icon
        const iconSp = new cc.Sprite("#farm_pass_bt_clover_coupon.png");
        contentNode.addChild(iconSp);

        var badgeNode = this._badgeNode = new BadgeNode();
        badgeNode.setPosition(18, 9);
        badgeNode.useDefaultStyle();
        contentNode.addChild(badgeNode, 1);

        this.setVisible(false);

        let progressBar = this._progressBar = new GSProgressTimer("farm_pass_pic_bar_03.png", "loading_bar.png", cc.size(38, 10), cc.size(38, 10), true);
        progressBar.setPosition(0, -14);
        contentNode.addChild(progressBar, 1);
    },

    refreshView: function () {
        let data = DataModal.farmBingoData;
        let passIconParam = data.passIconParam;
        if (!passIconParam) {
            this.setVisible(false);
            return;
        }

        if (!this._goalArray) {
            this.refreshGoalArray();
        }

        let maxGoal = passIconParam.goalArray[passIconParam.goalArray.length - 1];
        this._progressBar.setPercentage(cc.clampf(data.currentBingoBall / maxGoal * 100, 0, 100));

        this.setVisible(true);
        this.refreshRedPoint();
    },

    refreshGoalArray: function () {
        let data = DataModal.farmBingoData;
        let passIconParam = data.passIconParam;
        if (!passIconParam) {
            return;
        }

        this._goalArray = passIconParam.goalArray.filter(element => element > data.currentBingoBall);
    },

    refreshRedPoint: function () {
        let data = DataModal.farmBingoData;
        let passIconParam = data.passIconParam;
        let passParam = data.passData;
        if (!passIconParam) {
            return;
        }

        // 刷新小紅點
        let isChangeDay = TexasUtility.getNowIsChangeDay(GS.localStorage.getItem(UserDefaultKey.FarmPassIconRedPoint + DataModal.profileData.account, "0"));
        let isTokenReachGoal = !!this._goalArray[0] && this._goalArray[0] <= data.currentBingoBall;
        let isVisible = isChangeDay || isTokenReachGoal || (passParam.errorCode === 0 ? passParam.isObtainable() : passIconParam.isGetReward);

        this._badgeNode.setVisible(isVisible);
    },
});