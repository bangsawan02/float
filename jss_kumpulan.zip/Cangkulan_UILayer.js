/**
 * Cangkulan UI的畫面
 */

var Cangkulan_UILayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 創建棄牌/抽牌的按鈕
        var mainMenu = new cc.Menu();
        mainMenu.setPosition(0, 0);
        this.addChild(mainMenu);
        this._decisionBtns = [];
        var btnObj = [
            {
                // 棄牌按鈕
                btn: "lobby_btn_01.png",
                word: "#cangkulan_word_01.png",
                type: Cangkulan_UILayer.DecisionButtonType.FOLD
            },
            {
                // 棄牌(灰階)按鈕
                btn: "lobby_btn_04.png",
                word: "#cangkulan_word_01.png",
                type: Cangkulan_UILayer.DecisionButtonType.GRAY_FOLD
            },
            {
                // 抽牌按鈕
                btn: "lobby_btn_01.png",
                word: "#cangkulan_word_02.png",
                type: Cangkulan_UILayer.DecisionButtonType.DRAW
            }
        ];
        btnObj.forEach(cur => {
            var itemNodes = ButtonUtility.createSingleScale9SpriteNodes(cur.btn, cc.size(75, 28), cur.word);
            var menuItem = this._decisionBtns[cur.type] = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._decisionMenuClicked, this);
            menuItem.setPosition(JSScreenMidPos.x, 99 + JSScreenBonusHalfHeight);
            menuItem.setTag(cur.type);
            mainMenu.addChild(menuItem);
        });

        // 關閉所有決策按鈕
        this.refreshDecisionBtn(Cangkulan_UILayer.DecisionStatus.NONE);

        // 表情 & 對話 按鈕
        var emoticonMenu = this._emoticonMenu = new cc.Menu();
        emoticonMenu.setPosition(0, 0);
        emoticonMenu.setVisible(false);         // 預設先不出現表情與對話
        this.addChild(emoticonMenu);

        // 表情
        var emoticonMenuWidth = 27;
        this._emoticonPos = cc.p(18 + JSScreenSafeWidth, 15);
        var itemNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_07.png", cc.size(emoticonMenuWidth, 27), "#game_pic_emoticons.png");
        var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._emoticonMenuClicked, this);
        menuItem.setPosition(this._emoticonPos);
        emoticonMenu.addChild(menuItem);

        // 聊天按鈕
        var itemNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_07.png", cc.size(emoticonMenuWidth, 27), "#game_btn_chat.png");
        var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._chatMenuClicked, this);
        menuItem.setPosition(18 + emoticonMenuWidth + 2 + JSScreenSafeWidth, 15);
        emoticonMenu.addChild(menuItem);

        // 桌內koinLuxy (黑帳號 不顯示)
        if (!DataModal.profileData.isBlackAccount) {
            var koinLuxyNode = this._koinLuxyNode = new KoinLuxyGameNode();
            koinLuxyNode.setPosition(2 + JSScreenSafeWidth, 214 + JSScreenBonusHeight);
            this.addChild(koinLuxyNode);
        }

        // 桌內好友提示(加好友/好友上線)
        var friendGameHintLayer = new FriendGameHintLayer();
        this.addChild(friendGameHintLayer);


        //加入事件
        GS.addListener("NotifyGameUISetMenuStatus", this.notifyGameUISetMenuStatus.bind(this), this);
        GS.addListener("NotifyGameTableFunctionHint", this.notifyGameTableFunctionHint.bind(this), this);
    },

    cleanData: function () {
        this._status = null;
    },

    /**
     * 刷新決策按鈕
     * @param status : Cangkulan_UILayer.DecisionStatus
     */
    refreshDecisionBtn: function (status) {
        this._status = status;
        var btnType = Cangkulan_UILayer.DecisionButtonType;
        // 按鈕的狀態切換
        this._decisionBtns.forEach(cur => {
            var btn = cur.getTag();
            switch (btn) {
                case btnType.FOLD:
                    // 棄牌按鈕
                    cur.setVisible(status.fold);
                    break;
                case btnType.DRAW:
                    // 抽牌按鈕
                    cur.setVisible(status.draw);
                    break;
                case btnType.GRAY_FOLD:
                    // 灰色的棄牌按鈕
                    cur.setVisible(status.grayFold);
                    break;
            }
        });
    },

    /**
     * 決策按鈕點擊(棄牌/抽牌)
     * @private
     */
    _decisionMenuClicked: function (sender) {
        var type = sender.getTag();
        var btnType = Cangkulan_UILayer.DecisionButtonType;

        // 點了棄牌 or 抽牌 都要關閉按鈕
        if (type !== btnType.GRAY_FOLD)
            this.refreshDecisionBtn(Cangkulan_UILayer.DecisionStatus.NONE);

        switch (type) {
            case btnType.FOLD:
                // 點到棄牌按鈕
                GS.dispatchCustomEvent("NotifyFoldHandCard");
                break;
            case btnType.DRAW:
                // 點到抽牌按鈕
                DataProcess.sendString("draw");
                break;
            case btnType.GRAY_FOLD:
                // 點到灰色的棄牌
                GS.dispatchCustomEvent("NotifyShowTopMessage", LocalizedString.Game("請選擇一張要丟棄的手牌"));
                break;
        }
    },

    /**
     * 按到表情
     */
    _emoticonMenuClicked: function () {
        // 因為遊戲內可能會關掉Dialog 透過代參數讓Manager管理
        DialogManager.addDialog(new EmoticonsDialog(this._emoticonPos), true, true);

        // 撥放音效
        MusicUtility.playEffect("Music/Effect/button_click.mp3");

        // 拿掉泡泡框
        if (this._msgNode) {
            this._msgNode.close();
            this._msgNode = undefined;
        }
    },

    /**
     * 按到聊天對話
     */
    _chatMenuClicked: function () {
        GS.dispatchCustomEvent("NotifyShowGameChat");

        // 撥放音效
        MusicUtility.playEffect("Music/Effect/button_click.mp3");

        // 拿掉泡泡框
        if (this._msgNode) {
            this._msgNode.close();
            this._msgNode = undefined;
        }
    },

    /**
     * 是否要開啟表情&對話按鈕
     */
    setEmoticonVisible: function (isVisible) {
        this._emoticonMenu.setVisible(isVisible && DataModal.gameData.haveMe);
    },

    /**
     * 表情按鈕跳提示泡泡框
     */
    _showEmoticonHintMsg: function (msg, time = 2) {
        if (msg && msg.length) {
            if (this._msgNode) {
                this._msgNode = undefined;
            }

            // 泡泡框
            var msgLabel = new GSRichTextNode("#!000000!#" + msg, JSFontName, 12);
            var msgLabelHalfWidth = msgLabel.getContentSize().width / 2;
            var param = {
                mainNode: msgLabel,
                style: BaseMessageNode.Style.WHITE,
                direct: BaseMessageNode.Direct.DOWN,
                arrowType: BaseMessageNode.ArrowType.STRAIGHT,
                arrowPadding: (msgLabelHalfWidth < 15) ? 0 : msgLabelHalfWidth - 15,
                closeCallback: () => {
                    // 拿掉泡泡框
                    if (this._msgNode) {
                        this._msgNode = undefined;
                    }
                }
            };
            var targetPos = this._emoticonPos;
            var msgNode = this._msgNode = new BaseMessageNode(param);
            msgNode.setPosition(targetPos.x, targetPos.y + 16);
            msgNode.show(time);
            this.addChild(msgNode, 2);
        }
    },

    cmd_current_playing: function (jsonObj) {
        var actionBtn = jsonObj["actionBtn"];
        if (actionBtn) {
            this.cmd_action_btn(actionBtn);
        }
    },

    /**
     * 下一局時，重設外觀
     */
    cmd_OLEH: function () {
        // 把上一局資訊清掉
        this.cleanData();
    },

    /**
     * 更新koinLuxy
     * @param {String} value socke傳回來的值
     */
    cmd_koin_luxy_room_status: function (value) {
        var jsonValue = JSON.parse(value);
        this._koinLuxyNode && this._koinLuxyNode.refreshKoinStatus(jsonValue);
    },

    cmd_action_btn: function (array) {
        var status = Cangkulan_UILayer.DecisionStatus.NONE;

        if (array[0]) {
            // 可否出牌
            status = Cangkulan_UILayer.DecisionStatus.NOT_FOLD;
        } else if (array[1])
            // 可否抽牌
            status = Cangkulan_UILayer.DecisionStatus.DRAW;
        this.refreshDecisionBtn(status);
    },

    /**
     * 通知刷新決策的按鈕
     */
    notifyGameUISetMenuStatus: function (event) {
        if (event && event.getUserData()) {
            var status = event.getUserData();
            this.refreshDecisionBtn(status);
        }
    },

    /**
     * 牌桌內功能提示
     */
    notifyGameTableFunctionHint: function (event) {
        var hintType = event.getUserData();
        if (hintType === NewbieData.GameTableFunctionHintType.EMOTICON && this._emoticonMenu.isVisible()) {
            // 泡泡框
            this._showEmoticonHintMsg(LocalizedString.Game("與牌友互動一下吧!"), 3);

            // 紀錄已經跳過
            DataModal.newbieData.saveGameTableFunctionShowed(hintType);
        }
    }
});

// 決策按鈕
Cangkulan_UILayer.DecisionButtonType = {
    GRAY_FOLD: 0,     // 棄牌(灰)
    DRAW: 1,          // 抽牌
    FOLD: 2           // 棄牌
};

// 決策狀態
Cangkulan_UILayer.DecisionStatus = {
    NONE: {
        fold: false,
        grayFold: false,
        draw: false
    },
    // 可以點擊棄牌(棄牌階段)
    CAN_FOLD: {
        fold: true,
        grayFold: false,
        draw: false
    },
    // 不能點擊棄牌(棄牌階段)
    NOT_FOLD: {
        fold: false,
        grayFold: true,
        draw: false
    },
    // 抽牌
    DRAW: {
        fold: false,
        grayFold: false,
        draw: true
    }
};