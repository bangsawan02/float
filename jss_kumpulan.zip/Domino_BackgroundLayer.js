var Domino_BackgroundLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 牌桌
        var anteValue = DataModal.gameData.anteValue;
        var tableNumber;

        if (anteValue < 1000000)
            tableNumber = 1;
        else if (anteValue >= 1000000 && anteValue < 10000000)
            tableNumber = 2;
        else
            tableNumber = 3;

        var bgRes = JSStringUtility.format("#game_bg_carpet_0%d.png", tableNumber);
        var tableRes = JSStringUtility.format("game_domino_table_01.png");
        // 主題的地毯、桌面
        var tableThemeRes = GameTableTheme.getTableTheme(GSEnum.Game.Domino, [bgRes, tableRes]);
        var bgString = tableThemeRes[0];
        var tableString = tableThemeRes[1];

        // 背景
        var bgSprite = new cc.Sprite(bgString);
        var scaleX = (JSVisibleSize.width + 150) / bgSprite.getContentSize().width;
        var scaleY = (JSVisibleSize.height + 150) / bgSprite.getContentSize().height;
        var maxScale = Math.max(scaleX, scaleY);
        bgSprite.setScale(maxScale);
        bgSprite.setPosition(JSVisibleSize.width / 2, JSVisibleSize.height / 2);
        this.addChild(bgSprite, -10);

        // Repeat background images
        var repeatBG = new cc.Sprite("game/game_bg_pattern.png");
        repeatBG.setTextureRect(cc.rect(0, 0, JSVisibleSize.width, JSVisibleSize.height));
        repeatBG.setAnchorPoint(0, 0);
        repeatBG.getTexture().setTexParameters(cc.LINEAR, cc.LINEAR, cc.REPEAT, cc.REPEAT);
        this.addChild(repeatBG, -5);

        // 上方的背景窗戶
        var windowSpriteR = new cc.Sprite("game/Domino/game_bg_windows.png");
        windowSpriteR.setAnchorPoint(0, 0.5);
        windowSpriteR.setPosition(JSScreenMidPos.x - 1, 277 + JSScreenBonusHalfHeight);
        this.addChild(windowSpriteR);

        var windowSpriteL = new cc.Sprite("game/Domino/game_bg_windows.png");
        windowSpriteL.setFlippedX(true);
        windowSpriteL.setAnchorPoint(1, 0.5);
        windowSpriteL.setPosition(JSScreenMidPos.x + 1, 277 + JSScreenBonusHalfHeight);
        this.addChild(windowSpriteL);

        // 桌子 要先去讀圖 Native不用 background/Domino/
        var self = this;
        var addTable = function () {
            var tableSpriteR = new cc.Sprite("background/Domino/" + tableString);
            tableSpriteR.setScale(0.73);
            tableSpriteR.setAnchorPoint(0, 0.5);
            tableSpriteR.setPosition(JSScreenMidPos.x, 134 + JSScreenBonusHalfHeight);
            self.addChild(tableSpriteR, -1);

            var tableSpriteL = new cc.Sprite("background/Domino/" + tableString);
            tableSpriteL.setFlippedX(true);
            tableSpriteL.setScale(0.73);
            tableSpriteL.setAnchorPoint(1, 0.5);
            tableSpriteL.setPosition(tableSpriteR.getPosition());
            self.addChild(tableSpriteL, -1);
        };
        if (cc.sys.isNative)
            addTable();
        else {
            cc.loader.load("background/Domino/" + tableString, function () {
                addTable();
            });
        }

        // Dealer的圖(黑色圓圖、上面寫著D，是莊家的意思)
        var dealerSprite = this._dealerSprite = new cc.Sprite("#game_pic_dealer.png");
        dealerSprite.setPosition(Domino_GameUtility.getDealerPosition(0));
        dealerSprite.setVisible(false);
        this.addChild(dealerSprite);

        // 網速
        var antenna = new AntennaLayer(AntennaType.NORMAL_GAME);
        this.addChild(antenna);

        // 房間玩法 名稱 底注
        var modeLabel = this._modeLabel = new cc.LabelTTF(DataModal.gameData.gameRoomTypeName, JSFontName, 7);
        modeLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 20);
        modeLabel.setOpacity(150);
        this.addChild(modeLabel, 1);

        var nameLabel = this._nameLabel = new cc.LabelTTF("", JSFontName, 7);
        nameLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 10);
        nameLabel.setOpacity(150);
        this.addChild(nameLabel, 1);

        // 場編
        var serialLabel = this._serialLabel = new cc.LabelTTF("", JSFontName, 7);
        serialLabel.setAnchorPoint(1, 0.5);
        serialLabel.setPosition(JSVisibleSize.width - JSScreenSafeWidth - 24, JSVisibleSize.height - 12);
        this.addChild(serialLabel, 1);

        //事件
        GS.addListener("NotifyGameTurnPositionFinish", this.notifyGameTurnPositionFinish.bind(this), this);
    },

    cleanData: function () {
        this._dealerServerSitNum = -1;
        this._dealerSprite.setVisible(false);

        // 場編清掉
        this._serialLabel.setString("");
    },

    /**
     * 抓取莊家位置
     */
    getDealerPosition: function () {
        return this._dealerServerSitNum;
    },

    /**
     * 設定莊家位置
     * @param {serverSitNum} server的位置
     */
    setDealerPosition: function (serverSitNum) {
        var dealerSprite = this._dealerSprite;
        if (serverSitNum === -1) {
            // 代表要關掉
            dealerSprite.setVisible(false);
        } else {
            var sitNum = DataModal.gameData.getDirectionByServerDirection(serverSitNum);
            var pos = Domino_GameUtility.getDealerPosition(sitNum);
            dealerSprite.setVisible(true);
            dealerSprite.stopAllActions();
            dealerSprite.runAction(cc.moveTo(0.6, pos));
        }
    },

    /**
     * 收到OLEH重置外觀
     */
    cmd_OLEH: function () {
        this._serialLabel.setString(LocalizedString.Game("場編資訊:") + " " + DataModal.gameData.gameSerialID);

        this._dealerServerSitNum = -1;
        this._dealerSprite.setVisible(false);
    },


    /**
     * dealer x 莊家的位置
     * @param {value} socke收到的value
     */
    cmd_dealer: function (value) {
        this._dealerServerSitNum = value;
        this.setDealerPosition(value);
    },

    /**
     * 底注的文字
     */
    cmd_roomparam: function () {
        var gameData = DataModal.gameData;
        this._nameLabel.setString(gameData.gameRoomName + " " + LocalizedString.Lobby("底注") + ": " + TexasUtility.getSimpleMoneyString(gameData.anteValue));
    },

    /**
     * 換位置時自已轉到畫面上0的位置結束時觸發,修改Dealer的位置
     * @private
     */
    notifyGameTurnPositionFinish: function () {
        if (!this._dealerSprite.isVisible())
            return;

        this.setDealerPosition(this._dealerServerSitNum);
    },
});