/**
 * 5.4.0 [儲值]轉輪大狂歡 - 輪子實作
 *
 * 參考Domino幸運轉輪MegaWheel製作
 *
 * created by Wen
 *
 * 5.6.6 edited by tony.cheng
 */

var CarnivalWheelPackWheelNode = BaseWheelNode.extend({
    /**
     * param = {            輪子單格資訊
            wheelStep:      第幾階段的轉輪(1~3)
            nowStep:        當前進行階段(1~3)
            wheelTarget:    要轉到哪裡(0~7)
            wheelList:      轉輪內容[money,money,money,money....]
            needSpinAnim:   是否要自動轉(創輪子就會馬上開轉)(true/false)
            payMoney:       儲值金額
        };
     */
    ctor: function (param) {
        // 不直接用BaseWheelNode的，要等淡入後才initWheel
        cc.Node.prototype.ctor.call(this);
        this.setCascadeOpacityEnabled(true);
        this.setCascadeColorEnabled(true);

        // 初始化屬性
        this.initProperties();

        // 上層傳來的狀態
        let wheelStep = this._wheelStep = param.wheelStep;  // 這是第幾階段的轉輪
        this._needSpinAnim = param.needSpinAnim;            // 是否需要演旋轉的動畫，需要動畫的轉完就會消失了
        this._endCallBackSeconds = 3.2;                     // 轉完後幾秒呼叫callBack

        // server傳來的數值
        let dataStep = this._dataStep = param.nowStep;                       // server傳來當前進行到第幾轉輪階段
        this._rewardArray = param.wheelList.rewardList;     // 轉輪上的獎項
        this._rewardIndex = param.wheelTarget;              // 要轉到第幾項 server從0開始
        this._payMoney = param.payMoney;                    // 儲值金額

        // 綜合判斷或設定的狀態
        this._needPay = wheelStep !== 1;                    // 是否要儲值才可以領獎
        this._isLocked = dataStep !== wheelStep;            // 是否已經解鎖可以轉
        this._hasSpinned = wheelStep < dataStep;            // 是否已經領取

        // 黑幕先進來，其他再出現
        let aniTime = 0.15;
        this._initWheel(aniTime);
    },

    onEnter: function () {
        this._super();

        // 註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            "wheel_carnival_recharge": this.cmd_wheel_carnival_recharge     // 轉輪大狂歡(儲值領獎)
        });
    },

    onExit: function () {
        // 拿掉註冊SocketKey
        DataProcess.removeSocketKeyDispatch(this);

        // 如果有closeCallback就執行
        this._closeCallback && this._closeCallback();

        this._super();
    },

    /**
     * 設定開始轉的callback
     */
    setSpinCallback: function (callback) {
        this._spinCallback = callback;
    },

    /**
     * 設定轉完的callback
     */
    setSpinFinishCallback: function (callback) {
        this._spinFinishCallback = callback;
    },

    /**
     * 生成轉盤
     * aniTime {Number} 淡入動畫時間
     */
    _initWheel: function (aniTime) {
        let dataStep = this._dataStep;
        let wheelSpineFilePath = SelectGameManager.getNowGameFile("ani_wheel", "lobby/purchasePack/carnivalWheel/");
        let index = this._wheelStep - 1;
        let posX = [-175, -25, 150];
        let wheelStep = this._wheelStep;

        // 放轉輪的node
        let wheelContainer = this._wheelContainer = new cc.Node();
        wheelContainer.setCascadeColorEnabled(true);
        wheelContainer.setCascadeOpacityEnabled(true);
        wheelContainer.setOpacity(0);
        this.addChild(wheelContainer);
        wheelContainer.runAction(cc.fadeIn(aniTime));

        // 放所有東西
        let contentNode = this._contentNode = new cc.Node();
        contentNode.setCascadeOpacityEnabled(true);
        contentNode.setCascadeColorEnabled(true);
        contentNode.setOpacity(0);
        this.addChild(contentNode);
        contentNode.runAction(cc.fadeIn(aniTime));

        // 轉盤的陰影
        let wheelShadow = new cc.Sprite("#carnivalWheel_bg_shadow.png");
        wheelShadow.setScale(2.5);
        wheelShadow.setPositionY(-120);
        contentNode.addChild(wheelShadow);

        // 轉盤下的亮光
        let wheelDownLight = new cc.Sprite(JSStringUtility.format("#carnivalWheel_bg_reflective_%02d.png", wheelStep));
        wheelDownLight.setScale(2.5);
        wheelDownLight.setPositionY(-120);
        contentNode.addChild(wheelDownLight);

        // 轉盤外框
        GS.loadSpine(wheelSpineFilePath, () => {
            let aniName = JSStringUtility.format('ani_%02d', 1 + ((this._wheelStep - 1) * 3));
            let wheelBgSpine = this._wheelBgSpine = new sp.SkeletonAnimation(wheelSpineFilePath + ".json", wheelSpineFilePath + ".atlas", 0.25);
            wheelBgSpine.setAnimation(0, aniName, false);
            contentNode.addChild(wheelBgSpine);
        });

        // 鎖頭 只有階段2跟3有 (當前階段和轉過的沒有鎖頭)
        let lockSpineFilePath = "lobby/purchasePack/carnivalWheel/ani_lock";
        if (wheelStep >= 2) {
            if (!(wheelStep <= dataStep)) {
                GS.loadSpine(lockSpineFilePath, () => {
                    let lockSpine = this._lockSp = new sp.SkeletonAnimation(lockSpineFilePath + ".json", lockSpineFilePath + ".atlas", 0.25);
                    lockSpine.setAnimation(0, 'ani_01', false);
                    contentNode.addChild(lockSpine);
                });
            }
        }

        let tmpCount = this._wheelStep - 1;
        if (tmpCount) {
            let decoPosArray = [cc.p(38, 104), cc.p(44, 107)];
            for (let i = 0; i < 2; i++) {
                let frameDecoSp = new cc.Sprite(JSStringUtility.format("#carnivalWheel_pic_decorate_%02d.png", tmpCount));
                frameDecoSp.setAnchorPoint(0, 0.5);
                frameDecoSp.setScale(i ? 1 : -1, 1);
                frameDecoSp.setPosition(i ? -decoPosArray[tmpCount - 1].x : decoPosArray[tmpCount - 1].x, decoPosArray[tmpCount - 1].y);
                contentNode.addChild(frameDecoSp);
            }
        }

        // 轉盤內容物相關參數
        let rewardArray = this._rewardArray;

        // 修正距離
        let extraLen = 6;
        // 轉盤內容
        this._rewardNodeArray = rewardArray.map((cur, index) => {
            let degree = index * 60;
            let radian = degree * Math.PI / 180;

            // 轉盤內容本體
            let rewardNode = new cc.Node();
            rewardNode.setRotation(degree);
            rewardNode.setPosition(-extraLen * Math.sin(radian), -extraLen * Math.cos(radian));
            rewardNode.setCascadeColorEnabled(true);
            rewardNode.setCascadeOpacityEnabled(true);
            wheelContainer.addChild(rewardNode);

            // 轉盤獎項背景
            let rewardBg = new cc.Sprite(JSStringUtility.format("#carnivalWheel_pic_wheel_%02d.png", 1 + ((this._wheelStep - 1) * 3) + (index % 2)));
            rewardBg.setScale(1.1);
            rewardBg.setAnchorPoint(0.5, 0);
            rewardNode.addChild(rewardBg);

            // 大獎要特別背景顏色
            if (index === 0)
                rewardBg.setSpriteFrame(JSStringUtility.format("carnivalWheel_pic_wheel_%02d.png", 3 + ((this._wheelStep - 1) * 3)));

            // 轉盤獎項文字
            let rewardTxt = TexasUtility.getSimpleMoneyString(cur, 1, false, true);
            let rewardLabel = new cc.LabelTTF(rewardTxt, JSFontName, index === 0 ? 20 : 18);
            rewardLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            rewardLabel.setFontFillColor(index === 0 ? JSColor.YELLOW : JSColor.WHITE);
            rewardLabel.enableStroke(JSColor.BLACK, 2);
            rewardLabel.setPosition(0, 70);
            rewardNode.addChild(rewardLabel);

            return rewardNode;
        });

        // 燈泡動畫
        let lightFrames1 = this._lightFrame1 = [
            cc.spriteFrameCache.getSpriteFrame("carnivalWheel_pic_bulb_01.png"),
            cc.spriteFrameCache.getSpriteFrame("carnivalWheel_pic_bulb_02.png")
        ];

        // 燈泡動畫2
        let lightFrames2 = this._lightFrame2 = lightFrames1.slice().reverse();

        let len = 111;
        this._lightArray = [];
        // // 放燈泡
        for (let i = 0; i < 12; i++) {
            let radian = 30 * i * Math.PI / 180;
            let posX = len * Math.cos(radian);
            let posY = len * Math.sin(radian);

            let light = new cc.Sprite();
            light.setScale(1.2);
            light.setPosition(posX, posY);
            contentNode.addChild(light, 2);

            this._lightArray.push(light);

            light.runAction(cc.animate(new cc.Animation(i % 2 ? lightFrames1 : lightFrames2, 0.5)).repeatForever());
        }

        // 指針
        let pointerSprite = new cc.Sprite("#carnivalWheel_pic_pointer.png");
        pointerSprite.setPosition(0, 110);
        contentNode.addChild(pointerSprite, 2);

        // 開轉按鈕
        let btnTitle = dataStep === 1 ? LocalizedString.FreeChip("Free") : ("Rp. " + this._payMoney);
        let btnStyle = dataStep === 1 ? Texas_Button.Style.ORANGE : Texas_Button.Style.GREEN;
        let spinBtn = this._spinBtn = new Texas_Button(
            btnStyle,
            cc.size(120, 45),
            btnTitle,
            {fontSize: 16}
        );
        spinBtn.addTouchUpInsideAction(dataStep === 1 ? this._preCheckSpinBtnClicked : this._buyBtnClicked, this);
        spinBtn.setVisible(wheelStep === dataStep);
        spinBtn.setPositionY(-110);
        contentNode.addChild(spinBtn, 2);

        // 已經轉過了
        if (this._hasSpinned) {
            this.setSpinFinishedStatus();
        }

        if (!this._needSpinAnim) {
            // 不需要轉轉盤動畫，直接轉到位
            this._wheelContainer.setRotation(360 * 3 + this._rewardIndex * -60);
        }
    },

    // 鎖頭解鎖動畫
    lockFall: function () {
        if (!this._lockSp) return;
        this._lockSp.runAction(cc.sequence(
            // 左右搖晃
            cc.callFunc(() => this._lockSp.setAnimation(0, 'ani_01', false)),
            cc.delayTime(0.5),
            // 掉下來
            cc.callFunc(() => this._lockSp.setAnimation(0, 'ani_02', false)),
            cc.delayTime(1.5),
            cc.removeSelf()
        ));
    },

    /**
     * 按下馬上轉，先檢查
     */
    _preCheckSpinBtnClicked: function () {
        // 設定成要開始轉的狀態
        this.setStartSpinStatus();

        // 送免費轉指令
        DataProcess.sendString("wheel_carnival_reward");

        GS.dispatchCustomEvent("NotifyCarnivalWheelLoadingLayer", {startLoading: true});
    },

    /**
     * 設定成要開始轉的狀態
     */
    setStartSpinStatus: function () {
        // 按鈕關掉
        this._spinBtn.setVisible(false);
    },

    /**
     * 按下購買按鈕
     */
    _buyBtnClicked: function () {
        // 判斷有沒有第三方
        var data = DataModal.purchaseStructuresData.packMap[PurchaseStructuresData.PackSkin.CARNIVAL_WHEEL];

        var param = data.purchaseParam;
        if (param.productIDList.length > 1)
            DialogManager.addDialog(new ProviderChooseDialog(param), false);
        else
            DataModal.purchaseData.sendPurchase(param.productIDList[0]);
    },

    /**
     * 檢查過才真的按下馬上轉
     */
    _spinBtnClicked: function (sender) {
        this.stopAllActions();

        sender && sender.setEnabled(false);

        // 按鈕開始動畫
        let aniName = this._wheelStep === 1 ? "ani_02" : (this._wheelStep === 2 ? "ani_05" : "ani_08");
        this.runAction(cc.sequence(
            cc.delayTime(0.5),
            cc.callFunc(() => {
                this._wheelBgSpine.setAnimation(0, aniName, false);
            }),
            cc.delayTime(0.5),
            cc.callFunc(() => this.scheduleUpdate())
        ));

        // 要轉到第幾格
        let rewardIndex = this._rewardIndex;

        // 計算轉盤最終位置
        this._targetRotation = 360 * 3 + rewardIndex * -60;

        // 轉盤起始速度
        this._wheelSpeed = 1;

        this._rewardNodeArray.forEach(node => node.setColor(JSColor.WHITE));
    },

    spin: function () {
        this._spinBtnClicked(this._spinBtn);
    },

    /**
     * update
     * delta 每幀run的秒數
     */
    update: function (delta) {
        this.isTurning = true;
        var tmpSpeed = 0;
        var targetRotation = this._targetRotation;

        // 最後一圈開始減速
        if (this._wheelContainer.getRotation() > (targetRotation - 360)) {
            // 最近的rotation
            var curRotation = this._wheelContainer.getRotation();

            // 利用rotation來控制速度
            tmpSpeed = (targetRotation - curRotation) * delta;

            // 防止最後轉的時候太慢
            if (tmpSpeed < 0.07) {
                tmpSpeed = 0.07;
            }

            var nowRotation = curRotation + tmpSpeed;

            // 防呆 避免轉盤轉不停
            if (nowRotation >= targetRotation)
                nowRotation = targetRotation;

            // 設置rotation
            this._wheelContainer.setRotation(nowRotation);

            // 到達目標角度
            if (Math.abs(nowRotation - targetRotation) < 0.1) {
                this._spinEnd();
            }
        } else {
            // 一開始的加速度
            tmpSpeed = (this._wheelSpeed *= 1.02);

            // 設置速度上限
            if (tmpSpeed >= 10)
                tmpSpeed = 10;

            var rotation = Math.floor(this._wheelContainer.getRotation()) + Math.floor(tmpSpeed);
            this._wheelContainer.setRotation(rotation);
        }
    },

    /**
     * 轉完了要關動畫
     */
    _spinEnd: function () {
        this.unscheduleUpdate();

        // 把沒中獎的壓黑
        this._rewardNodeArray.forEach((node, index) => index !== this._rewardIndex && node.setColor(JSColor.GRAY));

        // 外框閃爍
        if (this.isTurning && this._wheelStep === this._dataStep) {
            this._lightArray.forEach(light => {
                light.stopAllActions();
                light.runAction(cc.animate(new cc.Animation(this._lightFrame1, 0.5)).repeat(3));
            });
        }
        this._spinFinishCallback && this._spinFinishCallback();
    },

    spinEnd: function () {
        // 要轉到第幾格
        let rewardIndex = this._rewardIndex;

        // step 1 沒有給wheelTarget，wheel_carnival_reward回來再抓
        if (rewardIndex < 0)
            rewardIndex = this._rewardIndex = DataModal.purchaseStructuresData.packMap[PurchaseStructuresData.PackSkin.CARNIVAL_WHEEL].wheelTarget;

        // 計算轉盤最終位置
        this._targetRotation = 360 * 3 + rewardIndex * -60;
        // 設置rotation
        this._wheelContainer.setRotation(this._targetRotation);

        // 轉輪中獎位置發光
        if (this.isTurning) {
            let aniName = this._wheelStep === 1 ? "ani_03" : (this._wheelStep === 2 ? "ani_06" : "ani_10");
            this._wheelBgSpine && this._wheelBgSpine.setAnimation(0, aniName, false);
        }

        // 轉完了
        this._spinEnd();
    },

    /**
     * 設定成已經轉完的樣子
     */
    setSpinFinishedStatus: function (canPurchase = false, needAni = false) {
        if (!canPurchase) {
            this._spinBtn && this._spinBtn.removeFromParent();
            this._spinBtn = undefined;

            // 售完標籤 and 動畫
            let soldOutSp = new cc.Sprite("#carnivalWheel_pic_label_received.png");
            soldOutSp.setPosition(0, 0);
            soldOutSp.setScale(1.5);
            soldOutSp.setOpacity(0.5);
            soldOutSp.setRotation(-5);
            this._contentNode.addChild(soldOutSp, 2);
            soldOutSp.runAction(cc.sequence(
                cc.delayTime(needAni ? 0.5 : 0),
                cc.spawn(
                    cc.fadeIn(0.2),
                    cc.scaleTo(0.2, 0.9)
                ),
                // 縮回 1
                cc.scaleTo(0.1, 1),
                // 放大 1.1
                cc.scaleTo(0.1, 1.1),
                // 縮回 1
                cc.scaleTo(0.1, 1)
            ));
        }
        this.spinEnd();
    },

    /**
     * 拿到轉輪儲值結果
     * 第二或第三個轉輪儲值成功後
     * S -> C wheel_carnival_recharge {
     *          "error":"0",            # 0:領獎正常, 1: 系統忙碌中, 2: 活動結束
     *          "reward":"780000",      # (因要小數兩位，這邊請client自行轉)
     *          "wheel_target":'10',    # 轉輪index位置
     * }
     */
    cmd_wheel_carnival_recharge: function (key, value) {
        let data = DataModal.purchaseStructuresData.packMap[PurchaseStructuresData.PackSkin.CARNIVAL_WHEEL];
        let dataStep = data.step;

        if (this._wheelStep !== dataStep)
            return;

        // 解開loading
        GS.dispatchCustomEvent("NotifyCarnivalWheelLoadingLayer", {startLoading: false});

        let jsonValue = JSON.parse(value);

        let errorCode = JSCodeUtility.getIntValue(jsonValue["error"], 1);
        if (errorCode === 0) {
            // 領獎正常
            this._rewardIndex = JSCodeUtility.getIntValue(jsonValue["wheel_target"]);

            // 領獎dialog
            let reward = JSCodeUtility.getIntValue(jsonValue["reward"]);
            let dialog = new CarnivalWheelRewardDialog({
                type: CarnivalWheelRewardDialog.Type.GET_REWARD,
                getReward: reward,
                isPurchaseSuccess: true,
                wheelStep: dataStep,
                needPay: false,
                isMaxReward: data.wheelList[dataStep - 1].maxReward === reward,
                group: data.group,
                callback: () => {
                    if (data.step === 2) {
                        // 送通知自動轉
                        GS.dispatchCustomEvent("NotifyCarnivalWheelSetSpinFinished", {
                            wheelStep: data.step,
                            isPurchase: true
                        });
                    } else {
                        // 通知儲值完畢
                        GS.dispatchCustomEvent("NotifyCarnivalWheelPurchaseDone");
                    }
                }
            });
            GS.dispatchCustomEvent("NotifyCarnivalWheelShowDialog", {dialog: dialog});
        } else if (errorCode === 2) {
            // 活動結束
            let dialog = new Dialog({
                title: LocalizedString.Common("提醒"),
                content: LocalizedString.Purchase("活動已結束"),
                closeButton: false,
                callback: function () {
                    DialogManager.closeDialogByKey("PurchasePackDialog_CarnivalWheel");
                }
            });
            GS.dispatchCustomEvent("NotifyCarnivalWheelShowDialog", {dialog: dialog});
        } else {
            // 其他都跳系統忙碌
            let commonStr = LocalizedString.Common;
            let dialog = new Dialog({
                title: commonStr("提醒"),
                content: commonStr("系統忙碌中，請稍後再試！"),
                closeButton: false,
                callback: () => {
                    // 重要資料
                    DataModal.purchaseStructuresData.startGetInfo(PurchaseStructuresData.PackSkin.CARNIVAL_WHEEL);
                }
            });
            GS.dispatchCustomEvent("NotifyCarnivalWheelShowDialog", {dialog: dialog});
        }
    }
});

CarnivalWheelPackWheelNode.Level = {
    FIRST: 0,
    SECOND: 1,
    THIRD: 2
};

CarnivalWheelPackWheelNode.LightMode = {
    NORMAL: 0,
    FAST: 1,
    PRIZE: 2
};
