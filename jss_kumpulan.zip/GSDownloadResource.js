/**
 * 不要使用這東西
 * 使用GSDownloadFile下載檔案
 *
 * param = {
 *      identifier: "",             // 識別名稱
 *      url: "",                    // 下載路徑
 *      savePath: "",               // 儲存路徑
 *      needUnCompress: false,      // 是否需要解壓縮 (預設false)
 * }
 */
// var GSDownloadResource = cc.Class.extend({
//
//     ctor: function () {
//         this.param = null;
//     },
//
//     /**
//      * 開始下載
//      * @param param         下載的一些參數
//      */
//     start: function (param) {
//         this._param = param;
//
//         if (!cc.sys.isNative)
//             return;
//
//         // cc.log("[GSDownloadResource start] identifier:" + param.identifier);
//         // cc.log("[GSDownloadResource start] url:" + param.url);
//         // cc.log("[GSDownloadResource start] savePath:" + param.savePath);
//
//         GSDownloadFile.getInstance().addDownloadQueue(
//             param.url,
//             param.identifier || "",
//             param.savePath,
//             this,
//             !!param.needUnCompress
//         );
//     },
//
//     onDownloadFileError: function (identifier, errorStr, errorCode) {
//         // cc.log("[GSDownloadResource onDownloadFileError] identifier: " + identifier + ", errorStr: " + errorStr + " , errorCode: " + errorCode);
//         if (this._param && this._param.onDownloadFileError) {
//             this._param.onDownloadFileError(errorStr, errorCode);
//         }
//     },
//
//     onDownloadFileProgress: function (identifier, bytesReceived, totalBytesReceived, totalBytesExpected) {
//         var percent = Math.round(totalBytesReceived / totalBytesExpected * 100);
//         // cc.log("[GSDownloadResource onDownloadFileProgress] identifier: " + identifier + ", downloadPercent: " + percent);
//         if (this._param && this._param.onDownloadFileProgress) {
//             this._param.onDownloadFileProgress(percent);
//         }
//     },
//
//     onDownloadFileSuccess: function (identifier, success) {
//         // cc.log("[GSDownloadResource onDownloadFileSuccess] identifier: " + identifier + ", success: " + success);
//         if (this._param && this._param.onDownloadFileSuccess) {
//             this._param.onDownloadFileSuccess();
//         }
//     },
// });