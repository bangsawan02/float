/**
 * v5.5.2 分身模組 - 累積獎勵顯示Node
 * created by Jim.chen
 * 兩種顯示樣式  1:平常顯示 2:做動畫
 */
var CloneModelRewardChipsNode = cc.Node.extend({
    ctor: function (whereType) {
        this._super();

        this._whereType = whereType;
        var infoParam = this._infoParam = DataModal.cloneModelData.infoParam;
        this._isClickEnabled = false;     // 預設不能點擊

        var nowCoinProgress = infoParam.nowCoinProgress || 0; // 目前累積籌碼值

        // 主畫面的node
        var mainNode = this._mainNode = new cc.Node();
        mainNode.setCascadeColorEnabled(true);
        this.addChild(mainNode);

        // 背景底
        var bgBoundingBox;
        for (var i = 0; i < 2; i++) {
            var bgSp = new cc.Sprite("#cloneModel_bg_window_2.png");
            bgSp.setAnchorPoint(i, 0.5);
            bgSp.setFlippedX(!i);
            bgBoundingBox = bgSp.getBoundingBox();
            bgSp.setPosition(-0.19 + i * 0.38, 0);
            mainNode.addChild(bgSp);
        }

        // 設定觸控範圍
        var bgSize = this._bgSize = cc.size(bgBoundingBox.width * 2, bgBoundingBox.height);
        this._boundingBox = cc.rect(-bgSize.w / 2, -bgSize.height / 2, bgSize.width, bgSize.height);

        // 右邊壓黑
        var blackMaskSp = new cc.Sprite("#cloneModel_bg_window_3.png");
        blackMaskSp.setPosition(93, -2);
        mainNode.addChild(blackMaskSp);

        // 上方黃光
        for (var i = 0; i < 2; i++) {
            var lightSp = new cc.Sprite("#cloneModel_pic_light_yellow.png");
            lightSp.setAnchorPoint(i, 0.5);
            lightSp.setFlippedX(!i);
            lightSp.setPosition(-0.1 + i * 0.2, 23);
            mainNode.addChild(lightSp);
        }

        // 籌碼槽 + 主籌碼圖
        var coinBgPosX = -97;
        var coinBgSp = new cc.Sprite("#cloneModel_bg_window_4.png");
        coinBgSp.setPosition(coinBgPosX, 1);
        mainNode.addChild(coinBgSp);

        var coinSp = new cc.Sprite("#cloneModel_pic_coin_1.png");
        coinSp.setPosition(coinBgPosX, 1);
        mainNode.addChild(coinSp);

        // 創三個籌碼槽
        this._coinBgSpArray = [];
        var offsetX = 46;
        for (var i = 0; i < 3; i++) {
            var pos = cc.p(-42 + offsetX * i, 0);

            var coinBgSp = this._coinBgSpArray[i] = new cc.Sprite("#cloneModel_bg_window_4.png");
            coinBgSp.setScale(0.74);
            coinBgSp.setPosition(pos);
            mainNode.addChild(coinBgSp);

            // 每個槽的籌碼
            var coinSp = coinBgSp.coinSp = new cc.Sprite("#lobby_icon_cloneModel_02.png");
            coinSp.setPosition(pos);
            coinSp.setVisible(nowCoinProgress - 1 >= i);
            mainNode.addChild(coinSp);
        }

        // 轉盤 icon
        var wheelIconSprite = this._wheelIconSprite = new cc.Sprite("#cloneModal_pic_wheel.png");
        wheelIconSprite.setPosition(100, 0);
        mainNode.addChild(wheelIconSprite);

        // 顯示泡泡框
        this._showHintMsgNode();

        // 加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this._onTouchBegan.bind(this),
            onTouchEnded: this._onTouchEnded.bind(this),
            onTouchCancelled: this._onTouchEnded.bind(this)
        }, this);
    },

    /**
     * 縮放mainNode
     */
    setMainNodeScale: function (scale) {
        this._mainNode.setScale(scale);

        // 縮小觸控偵測範圍
        var bgSize = this._bgSize = cc.size(this._bgSize.width * scale, this._bgSize.height * scale);
        this._boundingBox = cc.rect(-bgSize.width / 2, -bgSize.height / 2, bgSize.width, bgSize.height);
    },

    /**
     * 設定能否點擊
     */
    setClickEnabled: function (enabled) {
        this._isClickEnabled = enabled;
    },

    /**
     * 更新籌碼顯示
     */
    _refreshCoinSp: function () {
        var nowCoinProgress = this._infoParam.nowCoinProgress;
        this._coinBgSpArray.forEach((curBgSp, idx) => {
            curBgSp.coinSp.setVisible(nowCoinProgress - 1 >= idx);
        });
    },

    /**
     * 跳泡泡框
     */
    _showHintMsgNode: function () {
        let iconParam = DataModal.cloneModelData.iconParam;
        if (this._hintMsgNode) {
            // 有泡泡框先關掉
            this._hintMsgNode.close();
            return;
        }

        var nowCoinProgress = this._infoParam.nowCoinProgress;

        if (nowCoinProgress > 2) {
            // 三枚以上不顯示泡泡框
            return;
        }

        // 泡泡框
        var msgAutoLayout = new GSAutoLayoutNode();
        msgAutoLayout.setSpace(5);

        // 0~1 枚：儲值拿；2 枚：差一枚轉出最高XXXmlr
        let msgLabelString;
        if (nowCoinProgress > 1) {
            // 註：iconParam.title 是 max_chips 沒錯，不用懷疑
            let maxChips = TexasUtility.getSimpleMoneyString(iconParam.title, 1);
            msgLabelString = JSStringUtility.format(LocalizedString.Purchase("差一枚轉出最高 %s!"), maxChips);
        } else {
            msgLabelString = LocalizedString.Purchase("儲值拿");
        }
        var msgLabel = new cc.LabelTTF(LocalizedString.Purchase(msgLabelString), JSFontName, 10, cc.size(0, 0), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        msgLabel.setFontFillColor(JSColor.BLACK);
        msgAutoLayout.addChild(msgLabel);

        if (nowCoinProgress <= 1) {
            var coinSprite = new cc.Sprite("#lobby_icon_cloneModel_02.png");
            coinSprite.setScale(0.5);
            msgAutoLayout.addChild(coinSprite);
        }

        var param = {
            mainNode: msgAutoLayout,
            style: BaseMessageNode.Style.WHITE,
            direct: BaseMessageNode.Direct.DOWN_RIGHT,
            arrowType: BaseMessageNode.ArrowType.STRAIGHT,
            arrowPadding: 30,
            closeCallback: () => {
                // 拿掉泡泡框
                if (this._hintMsgNode) {
                    this._hintMsgNode = undefined;
                }

                // 間隔五秒後再次顯示
                this.runAction(cc.sequence(
                    cc.delayTime(5),
                    cc.callFunc(this._showHintMsgNode.bind(this))
                ));
            }
        };
        var hintMsgNode = this._hintMsgNode = new BaseMessageNode(param);
        hintMsgNode.setPosition(25, this._wheelIconSprite.getPosition().y + 15);
        hintMsgNode.show(2);
        this.addChild(hintMsgNode);
    },

    /**
     * Touch began
     */
    _onTouchBegan: function (touch) {
        if (this.__isDestroyed || !this._isClickEnabled)
            return;

        var touchPos = this.convertToNodeSpace(touch.getLocation());
        if (cc.rectContainsPoint(this._boundingBox, touchPos)) {
            // 點到Node
            this._isTouchNode = true;

            // 設定Node顏色
            this._mainNode.setColor(JSColor.GRAY);

            return true;
        } else {
            // 點在外面 do nothing.
            return false;
        }
    },

    /**
     * Touch end
     */
    _onTouchEnded: function (touch) {
        if (!this._isTouchNode || !this._isClickEnabled)
            return;

        var touchPos = this.convertToNodeSpace(touch.getLocation());
        if (cc.rectContainsPoint(this._boundingBox, touchPos)) {
            // 埋點：3418 點擊轉盤獎勵
            TexasUtility.sendUserAnalyticsTrack(3418, DataModal.cloneModelData.infoParam.cluster);

            // 點到Node裡面，開啟轉盤
            DialogManager.addDialog(this.createWheelAwardDialog(true), false);
        }

        this._isTouchNode = false;

        // 設定Node顏色
        this._mainNode.setColor(JSColor.WHITE);
    },

    createWheelAwardDialog: function (isRefreshOnReturn = false) {
        let dialog = new CloneModelWheelAwardDialog(this._whereType);
        isRefreshOnReturn && dialog.setCloseCallback(() => {
            // 當分身模組主 dialog 收到新資料時會無情清掉所有的 components，包括這個 node，所以擋一下
            if (this.__isDestroyed)
                return;

            this._refreshCoinSp();
        });
        return dialog;
    },
});