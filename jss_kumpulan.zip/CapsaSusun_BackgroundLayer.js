/**
 * CapsaSusun的背景畫面
 */

var CapsaSusun_BackgroundLayer = cc.Layer.extend({

    ctor: function () {
        this._super();

        // 背景
        var bgSprite = new cc.Sprite("background/Domino/game_capsaSusun_background.jpg");
        bgSprite.setPosition(JSScreenMidPos);
        this.addChild(bgSprite, -10);

        // 地板、桌子
        var res = ["game/Domino/game_cangkulan_table_01.png", "game/Domino/game_cangkulan_table_01.png"];
        res.forEach(cur => {
            for (var i = 0; i < 2; i++) {
                var bgSp = new cc.Sprite(cur);
                bgSp.setAnchorPoint(1, 0.5);
                bgSp.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 54);
                bgSp.setScaleX(i === 0 ? 1 : -1);
                this.addChild(bgSp, -10);
            }
        });

        // capsaSusun Logo
        var logoSp = new cc.Sprite("#capsaSusun_word_capsaSusun.png");
        logoSp.setPosition(JSScreenMidPos.x, 151 + JSScreenBonusHalfHeight);
        this.addChild(logoSp);

        // 網速
        var antenna = new AntennaLayer(AntennaType.GAME_RIGHT);
        this.addChild(antenna, 2);

        // 底注文字跟背景
        var betBgPos = cc.p(JSScreenMidPos.x, 130 + JSScreenBonusHalfHeight);
        var betBgSprite = this._betBgSprite = new ccui.Scale9Sprite("capsaSusun_pic_bet_bg.png");
        betBgSprite.setPosition(betBgPos);
        betBgSprite.setOpacity(100);
        betBgSprite.setVisible(false);
        this.addChild(betBgSprite);

        var betLabel = this._betLabel = new cc.LabelTTF("", JSFontName, 9);
        betLabel.setPosition(betBgPos);
        betLabel.setOpacity(100);
        this.addChild(betLabel, 1);

        // 場編
        var serialLabel = this._serialLabel = new cc.LabelTTF("", JSFontName, 7);
        serialLabel.enableStroke(JSColor.BLACK, 2);
        serialLabel.setAnchorPoint(1, 0.5);
        serialLabel.setPosition(JSVisibleSize.width - JSScreenSafeWidth - 24, JSVisibleSize.height - 12);
        this.addChild(serialLabel, 1);

    },

    cleanData: function () {
        this._dealerServerSitNum = -1;

        // 場編清掉
        this._serialLabel.setString("");
    },

    /**
     * 抓取莊家位置
     */
    getDealerPosition: function () {
        return this._dealerServerSitNum;
    },

    /**
     * 收到OLEH重置外觀
     */
    cmd_OLEH: function () {
        if (DataModal.gameData.gameSerialID)
            this._serialLabel.setString(LocalizedString.Game("場編資訊:") + " " + DataModal.gameData.gameSerialID);
        else
            this._serialLabel.setString("");

        this._dealerServerSitNum = -1;
    },


    /**
     * dealer x 莊家的位置
     * @param {value} socke收到的value
     */
    cmd_dealer: function (value) {
        this._dealerServerSitNum = value;
    },

    /**
     * 底注的文字
     */
    cmd_roomparam: function () {
        var gameData = DataModal.gameData;
        var betBgSprite = this._betBgSprite;
        var betLabel = this._betLabel;

        // 設定底注文字
        betLabel.setString("Buta:" + TexasUtility.getSimpleMoneyString(gameData.anteValue));

        // 背景大小調整
        betBgSprite.setPreferredSize(cc.size(betLabel.getContentSize().width + 32, 20));
        betBgSprite.setVisible(true);
    },

});