// 表情的類型
var EmoticonsNodeType = {
    NORMAL: 0,
    VIP: 1,
    STAR: 2,
    HEART: 3,
    POKER: 4
};

var EmoticonsNode = cc.Node.extend({
    ctor: function (type, index, dt, callback, context, isChat) {
        this._super();

        var moodData = DataModal.moodData;

        this._type = type;
        this._index = index;
        this._callback = callback;
        this._context = context;
        this._isChat = isChat;

        //計算剩餘時間用
        this._decreaseTime = dt;

        var imageName = null;
        switch (type) {
            case EmoticonsNodeType.NORMAL:
                // 普通表情
                imageName = "emoticons_n_0" + index + ".png";
                break;
            case EmoticonsNodeType.VIP:
                // VIP表情
                imageName = "emoticons_v_0" + index + ".png";
                break;
            case EmoticonsNodeType.STAR:
                // 特殊表情
                if (index < moodData.spEmoticonArray.length)
                    imageName = "emoticons_s_" + moodData.spEmoticonArray[index].serial + ".png";
                break;
            case EmoticonsNodeType.HEART:
                // 特殊表情
                if (index < moodData.storeEmoticonArray.length)
                    imageName = "emoticons_h_" + moodData.storeEmoticonArray[index].serial + ".png";
                break;
            case EmoticonsNodeType.POKER:
                // 特殊表情
                index += 10;        // 要位移
                if (index < moodData.storeEmoticonArray.length)
                    imageName = "emoticons_p_" + moodData.storeEmoticonArray[index].serial + ".png";
                break;
            default:
                break;
        }

        console.log(imageName);

        if (!imageName) {
            // 沒圖片加個Loading
            var loadingSprite = new GSLoadingSprite();
            loadingSprite.setScale(0.8);
            loadingSprite.start();
            this.addChild(loadingSprite);
            return;
        }

        var itemSprite1 = new ccui.Scale9Sprite(imageName);
        var itemSprite2 = new ccui.Scale9Sprite(imageName);
        itemSprite2.setColor(JSColor.GRAY);

        // 星星在聊天室時要縮一下(太大了)
        if (type === EmoticonsNodeType.STAR && this._isChat) {
            itemSprite1.setScale(0.75);
            itemSprite2.setScale(0.75);
        }


        var button = this._button = new cc.ControlButton(itemSprite1);
        button.setBackgroundSpriteForState(itemSprite2, cc.CONTROL_STATE_HIGHLIGHTED);
        button.addTargetWithActionForControlEvents(this, this._emoticonClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        button.setAdjustBackgroundImage(false);
        button.setZoomOnTouchDown(false);
        button.setSwallowTouches(false);
        button.setTouchDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
        this.addChild(button);

        //判斷是否可以按
        this._emoticonObj = null;
        this._canUse = true;
        if (type === EmoticonsNodeType.NORMAL) {
            // 一般表情 都會有
        } else if (type === EmoticonsNodeType.VIP) {
            // VIP表情
            var profileData = DataModal.profileData;
            if (profileData.vipRank <= 1) {
                button.setOpacity(100);
                this._canUse = false;
            }
        } else {
            // 特殊表情 & 商城表情
            var emoticonArray = (type === EmoticonsNodeType.STAR ? moodData.spEmoticonArray : moodData.storeEmoticonArray);

            var emoticonObj = this._emoticonObj = emoticonArray[index];
            if (emoticonObj) {
                //有物件
                if (emoticonObj.canUse) {
                    // 可使用 加剩餘時間
                    var expireTimeString = this._calculateExpireTime(emoticonObj.expireTime);

                    if (expireTimeString.length > 0) {
                        // 加剩餘時間
                        // 在聊天室時的尺寸會比較小
                        var fontSize = (this._isChat) ? 8 : 10;
                        var vy = (this._isChat) ? -27 : -37;
                        var expireTimeLabel = this._expireTimeLabel = new cc.LabelTTF(expireTimeString, JSFontBoldName, fontSize);
                        expireTimeLabel.setPosition(0, vy);
                        this.addChild(expireTimeLabel);

                        // // 低於1天要變色
                        var surplusTime = emoticonObj.expireTime - this._decreaseTime;
                        if (surplusTime < 3600)
                            expireTimeLabel.setFontFillColor(JSColor.YELLOW);
                        else
                            expireTimeLabel.setFontFillColor(JSColor.WHITE);

                        // update time
                        // this.schedule(this._updateItemTime, 60);
                    } else {
                        // 逾時 不加剩餘時間並反灰
                        button.setOpacity(150);
                        // this.unschedule(this._updateItemTime);
                    }

                } else {
                    button.setOpacity(150);
                    this._canUse = false;
                }
            } else {
                //沒物件 設定看不到
                // this.setVisible(false);

                this._canUse = false;
            }
        }
    },

    // onExit: function () {
    //     this.unschedule(this._updateItemTime);
    //
    //     this._super();
    // },

    //計算時間文字
    _calculateExpireTime: function (time) {
        var expireTime = "";

        //剩餘時間 <=0表示逾時
        var surplusTime = time - this._decreaseTime;
        if (surplusTime > 0) {
            // 還有剩餘時間
            var day = Math.floor((surplusTime / 3600) / 24);
            var hour = (surplusTime / 3600) % 24;

            if (day > 1 || hour > 1) {
                expireTime = JSStringUtility.format("%dD%dH", day, hour);
            } else {
                //因為只會顯示整數 所以讓時間小數無條件進位
                var min = Math.ceil((surplusTime / 60) % 60);
                expireTime = JSStringUtility.format("%dM", min);
            }
        }

        return expireTime;
    },

    _updateItemTime: function () {
        var expireTimeString = this._calculateExpireTime(this._emoticonObj.expireTime);
        this._expireTimeLabel.setString(expireTimeString);

        // 逾時
        if (expireTimeString.length === "") {
            this._button.setOpacity(150);
            this.unschedule(this._updateItemTime);
        }
    },

    /**
     * 按鈕
     */
    //按到表情
    _emoticonClicked: function () {
        if (this._callback) {
            this._callback.call(this._context, {
                type: this._type,               //什麼表情類型
                index: this._index,             //第幾個
                emoticonObj: this._emoticonObj, //表情的物件 有可能是null
                canUse: this._canUse            //是否能使用
            });
        }
    }
});
