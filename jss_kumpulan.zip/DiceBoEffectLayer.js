/**
 *  骰寶特效畫面
 */

var DiceBoEffectLayer = cc.Layer.extend({
    ctor: function () {
        this._super();
    },

    /**
     * 清除畫面
     */
    clean: function () {
        this.removeAllChildren();
    },

    /**
     * 出現下注教學提示
     */
    showTeachBetHint: function (cb) {
        // 讓下面不要被按到
        var dummyTouch = new DummyTouchLayer(JSVisibleSize);
        dummyTouch.setOnTouchCallback(() => {
            cb();
            this.clean();
        });
        this.addChild(dummyTouch);

        // 小手手
        var fingerSprite = new cc.Sprite("#lobby_pic_finger.png");
        fingerSprite.setPosition(310 + JSScreenBonusHalfWidth, 22);
        fingerSprite.setRotation(330);
        this.addChild(fingerSprite);

        // 提示訊息
        var msgLabel = new cc.LabelTTF(LocalizedString.DiceBo("左右滑動可選擇投注額哦!"), JSFontBoldName, 12);
        msgLabel.setFontFillColor(JSColor.BLACK);
        var param = {
            mainNode: msgLabel,
            style: BaseMessageNode.Style.GOLD,
            direct: BaseMessageNode.Direct.DOWN,
            arrowType: BaseMessageNode.ArrowType.SLANT,
            isFlip: true,
            arrowPadding: 0,
        };

        // 泡泡框
        var msgNode = new BaseMessageNode(param);
        msgNode.setPosition(JSScreenMidPos.x, 60);
        msgNode.show(2, true);
        this.addChild(msgNode);

        // 小手手動畫
        fingerSprite.runAction(cc.sequence(
            cc.moveTo(2, cc.p(220 + JSScreenBonusHalfWidth, 22)),
            cc.callFunc(() => {
                GS.localStorage.setItem("ShowDiceBoTeach", "1");
                this.clean();
            })
        ));
    },

    /**
     * 出現搖骰畫面
     */
    showDiceAnimation: function (diceBoParam, callback) {
        var animationNode = new cc.Node();
        animationNode.setCascadeOpacityEnabled(true);
        this.addChild(animationNode);

        // 黑底
        var bgLayer = new cc.LayerColor(cc.color(0, 0, 0, 150), JSVisibleSize.width + 2, JSVisibleSize.height + 2);
        bgLayer.setPosition(-1, -1);
        animationNode.addChild(bgLayer);

        var self = this;
        gaf.create("vegas/dicebo/diceCup.gaf", this, true, function (gafAsset) {
            var gafObject = gafAsset.createObjectAndRun(true);
            gafObject.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 60);
            animationNode.addChild(gafObject);

            // 一陣子後 要加入骰子到GAF裡面
            var diceNum = diceBoParam.diceNum;
            animationNode.runAction(cc.sequence(
                cc.delayTime(1.5),
                cc.callFunc(function () {
                    // 三顆骰子
                    var dicePos = [
                        cc.p(-22, 58),
                        cc.p(18, 64),
                        cc.p(4, 47)
                    ];

                    // 因為Native下的GAF有改動Scale的動作 讓不同CSF可以顯示一樣 所以這邊把物件加到畫面上要特別修改Scale
                    var bonusScale = (cc.sys.isNative ? 8 : 2) / cc.director.getContentScaleFactor();
                    for (var i = 0; i < 3; i++) {
                        var nowPos = cc.pAdd(dicePos[i], cc.p(JSCodeUtility.getRandomInt(-3, 3), JSCodeUtility.getRandomInt(-3, -3)));
                        var diceSprite = new cc.Sprite(JSStringUtility.format("#anim_dice_0%d.png", diceNum[i]));
                        diceSprite.setPosition(nowPos.x * bonusScale, nowPos.y * bonusScale);
                        diceSprite.setScale(bonusScale);
                        gafObject.getObjectByName("container_dice").addChild(diceSprite);
                    }
                })
            ));

            // 撥放音效
            animationNode.runAction(cc.sequence(
                cc.delayTime(0.3),
                cc.callFunc(function () {
                    Vegas_MusicUtility.playEffect("Music/Effect/dicebo_shake.mp3");
                }),
                cc.delayTime(1.5),
                cc.callFunc(function () {
                    Vegas_MusicUtility.playEffect("Music/Effect/dicebo_show.mp3");
                })
            ));

            // 設定撥完動畫後的事
            gafObject.addEventListener(gaf.EVENT_SEQUENCE_END, function () {
                // 停止動畫
                gafObject.pauseAnimation();
                gafObject.stop();

                // 加入骰子數字
                var diceNumTotal = diceNum[0] + diceNum[1] + diceNum[2];
                var isTriple = false;
                if (diceNum[0] === diceNum[1] && diceNum[1] === diceNum[2])
                    isTriple = true;

                var wordColor, wordText;
                if (isTriple) {
                    wordColor = cc.color(76, 255, 26);
                    wordText = LocalizedString.DiceBo("豹");
                } else if (diceNumTotal > 10) {
                    wordColor = cc.color(0, 38, 226);
                    wordText = LocalizedString.DiceBo("大");
                } else {
                    wordColor = cc.color(209, 0, 0);
                    wordText = LocalizedString.DiceBo("小");
                }

                // 背景
                var diceBg = new cc.Sprite("#db_dice_word_bg.png");
                diceBg.setPosition(JSScreenMidPos.x, 100 + JSScreenBonusHalfHeight);
                diceBg.setScaleX(3);
                animationNode.addChild(diceBg);

                // 文字
                var diceTotalLabel = new cc.LabelTTF(diceNumTotal.toString(), JSFontBoldName, 16);
                diceTotalLabel.setPosition((isTriple ? 238 : 231) + JSScreenBonusHalfWidth, 100 + JSScreenBonusHalfHeight);
                diceTotalLabel.setFontFillColor(wordColor);
                animationNode.addChild(diceTotalLabel, 1);

                var diceNameLabel = new cc.LabelTTF(wordText, JSFontBoldName, 16);
                diceNameLabel.setPosition((isTriple ? 279 : 277) + JSScreenBonusHalfWidth, 100 + JSScreenBonusHalfHeight);
                diceNameLabel.setFontFillColor(wordColor);
                animationNode.addChild(diceNameLabel, 1);

                // 過幾秒後全部結束
                animationNode.runAction(cc.sequence(
                    cc.delayTime(1.0),
                    cc.fadeOut(0.2),
                    cc.callFunc(function () {
                        animationNode.removeFromParent();

                        // callback回去
                        callback && callback();
                    })
                ));
            });
        });
    },


    /**
     * 出現結算畫面
     */
    showFinishResult: function (diceParam, totalBetMoney, isTriple) {
        var winMoney = diceParam.reward;

        var resultNode = new cc.Node();
        resultNode.setCascadeOpacityEnabled(true);
        this.addChild(resultNode);

        // 黑底
        var bgLayer = new cc.LayerColor(cc.color(0, 0, 0, 210), JSVisibleSize.width + 2, JSVisibleSize.height + 2);
        bgLayer.setPosition(-1, -1);
        resultNode.addChild(bgLayer);

        // 判斷東西
        var bgName = "#db_bg_light.png";
        var wordName = "#vegase_word_win.png";
        var idleTime = 0;
        var isSpecialEffect = false;
        var wordY = JSScreenMidPos.y - 12;
        if (isTriple) {
            isSpecialEffect = true;
            idleTime = 6;
        } else if (winMoney >= totalBetMoney * 2.5) {
            // 中獎大於壓注總金額的2.5倍
            isSpecialEffect = true;
            idleTime = 3;
        } else if (winMoney <= 0) {
            // 輸
            bgName = "#db_bg_lose.png";
            wordName = "#vegase_word_lose.png";
            wordY = JSScreenMidPos.y - 34;
        }

        // 勝利撥放光條
        if (winMoney > 0) {
            var self = this;
            resultNode.schedule(function () {
                resultNode.addChild(self._createFlashLight());
            }, 0.3);
        }

        // 背景
        if (isSpecialEffect) {
            // 創外框
            var scaleX = (JSVisibleSize.width - 8) / 4;
            var scaleY = (215 + JSScreenBonusHalfHeight) / 215;
            var frameLeft = new cc.Sprite("#db_winFrame01.png");
            frameLeft.setFlippedX(true);
            frameLeft.setAnchorPoint(0, 0);
            frameLeft.setPosition(0, 30);
            frameLeft.setScaleY(scaleY);
            resultNode.addChild(frameLeft);

            var frameRight = new cc.Sprite("#db_winFrame01.png");
            frameRight.setAnchorPoint(1, 0);
            frameRight.setPosition(JSVisibleSize.width, 30);
            frameRight.setScaleY(scaleY);
            resultNode.addChild(frameRight);

            var frameMid = new cc.Sprite("#db_winFrame02.png");
            frameMid.setAnchorPoint(0.5, 0);
            frameMid.setPosition(JSScreenMidPos.x, 30);
            frameMid.setScaleX(scaleX);
            frameMid.setScaleY(scaleY);
            resultNode.addChild(frameMid);

            // 創光點動畫
            resultNode.addChild(this._createLightBall(true, 1, 3));
            resultNode.addChild(this._createLightBall(false, 1, 3));
            resultNode.runAction(cc.sequence(
                cc.delayTime(1),
                cc.callFunc(function () {
                    resultNode.addChild(this._createLightBall(true, 0.75, 6));
                    resultNode.addChild(this._createLightBall(false, 0.75, 6));
                }, this),
                cc.delayTime(1),
                cc.callFunc(function () {
                    resultNode.addChild(this._createLightBall(true, 0.5, 9));
                    resultNode.addChild(this._createLightBall(false, 0.5, 9));
                }, this),
                cc.delayTime(1),
                cc.callFunc(function () {
                    resultNode.addChild(this._createLightBall(true, 0.25, 12));
                    resultNode.addChild(this._createLightBall(false, 0.25, 12));
                }, this)
            ));

            // 放金幣
            var self = this;
            resultNode.schedule(function () {
                resultNode.addChild(self._createCoinAnimation());
            }, 0.05);

            // 撥放音樂
            Vegas_MusicUtility.playEffect("Music/Effect/slot_coin.mp3");
            Vegas_MusicUtility.playEffect("Music/Effect/blackjack_bigWin.mp3");
        } else {
            var bgSprite = new cc.Sprite(bgName);
            var scaleX = JSVisibleSize.width / bgSprite.getContentSize().width;
            bgSprite.setScaleX(scaleX);
            bgSprite.setScaleY(0);
            bgSprite.setPosition(JSScreenMidPos);
            bgSprite.setOpacity(0);
            resultNode.addChild(bgSprite);

            bgSprite.runAction(cc.scaleTo(1, scaleX, 1));
            bgSprite.runAction(cc.fadeTo(2, 200).easing(cc.easeInOut(2)));

            // 撥放音樂
            if (winMoney <= 0)
                Vegas_MusicUtility.playEffect("Music/Effect/blackjack_lose.mp3");
            else
                Vegas_MusicUtility.playEffect("Music/Effect/blackjack_win.mp3");
        }

        // 文字
        var wordSprite = new cc.Sprite(wordName);
        wordSprite.setAnchorPoint(0.5, 0);
        wordSprite.setPosition(JSScreenMidPos.x, wordY);
        wordSprite.setScale(0.8);
        wordSprite.setOpacity(0);
        resultNode.addChild(wordSprite, 1);

        wordSprite.runAction(cc.spawn(
            cc.scaleTo(1, 1),
            cc.fadeTo(2, 255).easing(cc.easeInOut(2))
        ));

        // 判斷是否要出現金額 平手不show
        if (winMoney > 0) {
            var moneyPosY = JSScreenMidPos.y - 26;
            var moneyNode = this._createMoneyNode(winMoney);
            moneyNode.setPosition(JSScreenMidPos.x, moneyPosY);
            moneyNode.setOpacity(0);
            moneyNode.setScale(0.8);
            resultNode.addChild(moneyNode, 1);

            // 動畫
            moneyNode.runAction(cc.scaleTo(1, 1));
            moneyNode.runAction(cc.fadeIn(2).easing(cc.easeInOut(2)));
        }

        // 最後要設定關掉
        resultNode.runAction(cc.sequence(
            cc.delayTime(2 + idleTime),
            cc.fadeOut(0.3),
            cc.callFunc(function () {
                // 更新現在的金錢
                DataModal.profileData.money = diceParam.money;

                // 通知UI更新金錢
                GS.dispatchCustomEvent("NotifySetTMoney");

                // 通知動畫做完了
                GS.dispatchCustomEvent("NotifyDiceBoResultDone");
            }),
            cc.removeSelf()
        ));
    },

    // 創金錢的數字
    _createMoneyNode: function (money) {
        // 先計算Sprite總寬度 數字高度固定為50 逗點寬26 其他寬40
        var retNode = new cc.Node();
        retNode.setCascadeOpacityEnabled(true);

        var moneyString = JSCodeUtility.getCurrencyString(money);
        var moneyLen = moneyString.length;
        var moneyPosX = 0;
        for (var i = 0; i < moneyLen; i++) {
            var moneyChar = moneyString[i];
            var isDot = (moneyChar === ",");
            var moneySprite = new cc.Sprite("#vegase_number" + moneyChar + ".png");
            moneySprite.setPosition(moneyPosX, isDot ? -15 : 0);
            moneySprite.setAnchorPoint(0, 0.5);
            retNode.addChild(moneySprite);

            moneyPosX += (isDot ? 16 : 30);
        }

        // 要重新對位
        var offsetX = moneyPosX / 2;
        retNode.getChildren().forEach(function (cur) {
            var originPos = cur.getPosition();
            cur.setPosition(originPos.x - offsetX, originPos.y);
        });


        return retNode;
    },

    // 亮光點的動畫
    _createLightBall: function (isRight, scaleSize, speed) {
        var point = isRight ? cc.p(JSVisibleSize.width - 1, 30) : cc.p(1, JSScreenMidPos.y + 99);
        var width = JSVisibleSize.width - 2;
        var height = 213 + JSScreenBonusHalfHeight;
        var pointArray = [
            cc.p(0, 0),
            cc.p(isRight ? -width : width, 0),
            cc.p(isRight ? -width : width, isRight ? height : -height),
            cc.p(0, isRight ? height : -height),
            cc.p(0, 0)
        ];

        var lightBallSprite = new cc.Sprite("#vegas_effectLight_02.png");
        lightBallSprite.setScale(scaleSize);
        lightBallSprite.setPosition(point);

        // 動畫
        lightBallSprite.runAction(cc.repeatForever(cc.cardinalSplineBy(speed, pointArray, 1)));

        lightBallSprite.runAction(cc.repeatForever(cc.rotateBy(1, 360)));

        if (scaleSize < 1) {
            lightBallSprite.runAction(cc.repeatForever(cc.sequence(
                cc.fadeTo(0.5, 40),
                cc.fadeTo(0.5, 255)
            )));
        }

        return lightBallSprite;
    },

    // 亮光條的動畫
    _createFlashLight: function () {
        var retNode = new cc.Node();
        retNode.setCascadeOpacityEnabled(true);

        for (var i = 0; i < 2; i++) {
            var lightSprite = new cc.Sprite("#db_winSpotLight.png");
            lightSprite.setScale(2);
            lightSprite.setAnchorPoint(0.5, 0);
            lightSprite.setPosition(JSScreenMidPos.x + (i === 0 ? -154 : 154), JSScreenMidPos.y - 56);
            lightSprite.setRotation(i === 0 ? -90 : 90);
            lightSprite.setOpacity(0);
            retNode.addChild(lightSprite);

            lightSprite.runAction(cc.rotateBy(1.3, i === 0 ? 180 : -180));
            lightSprite.runAction(cc.sequence(
                cc.fadeTo(0.2, 30),
                cc.delayTime(0.8),
                cc.fadeTo(0.3, 0),
                cc.removeSelf()
            ));
        }

        return retNode;
    },

    // 金幣的動畫
    _createCoinAnimation: function () {
        var retNode = new cc.Node();
        retNode.setCascadeOpacityEnabled(true);

        var coinSprite = new cc.Sprite("#anim_chip_0.png");
        coinSprite.setOpacity(0);
        coinSprite.setPosition(JSScreenMidPos.x + JSCodeUtility.getRandomInt(-230, 230), JSScreenMidPos.y + JSCodeUtility.getRandomInt(-44, 0));
        retNode.addChild(coinSprite);

        // 一直換圖
        var aniFramesArray = [];
        for (var i = 0; i < 6; i++) {
            aniFramesArray.push(cc.spriteFrameCache.getSpriteFrame(JSStringUtility.format("anim_chip_%d.png", i)));
        }
        coinSprite.runAction(cc.repeatForever(cc.animate(new cc.Animation(aniFramesArray, 0.1))));

        // 動畫
        coinSprite.runAction(cc.sequence(
            cc.fadeIn(0.2),
            cc.delayTime(1),
            cc.fadeOut(0.2),
            cc.removeSelf()
        ));
        coinSprite.runAction(cc.jumpTo(1.4, cc.p(JSScreenMidPos.x + JSCodeUtility.getRandomInt(-230, 230), -30), 200, 1));

        return retNode;
    },
});