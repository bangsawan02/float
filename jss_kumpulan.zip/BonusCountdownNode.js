/**
 * Bonus機台 玩家 倒數 Node
 */
var BonusCountdownNode = cc.Node.extend({
    ctor: function () {
        this._super();

        // Timer主體
        var timer = this._timer = new BonusCountdownTimer(new cc.Sprite("#bonus_pic_circle.png"));
        timer.setScale(0.8);
        timer.setReverseDirection(true);
        timer.setPercentage(100);
        this.addChild(timer);
    },

    /**
     * 每一個frame都去倒數
     * @private
     */
    _scheduleUpdateTimer: function () {
        // 先抓出現在時間 (這邊要用到毫秒)
        var nowTime = new Date().getTime();
        var reduceTime = nowTime - this._baseTime;          // 減少了多少時間
        var remainTime = this._totalTime - reduceTime;      // 剩下多少時間

        // 算百分比
        var percent = remainTime * 100 / this._totalTime;

        if (percent < 0) {
            // 時間到了
            this.stop();
        } else {
            // 時間還沒到
            this._timer.setPercentage(percent);
        }

    },

    /**
     * 開始倒數
     * @param time      倒數時間
     * @param isSelf    是否為自己
     */
    start: function (time, isSelf) {
        // 設定自己看的到
        this.setVisible(true);

        // 先把他設成100%
        this._timer.setPercentage(100);
        this._timer.setTime(time);

        // 倒數動作 時間要*1000 有毫秒 (這邊自己處理 因為程式縮下去 在回來 要自己扣掉時間)
        this._totalTime = time * 1000;
        this._baseTime = new Date().getTime();

        // 開始倒數
        this.schedule(this._scheduleUpdateTimer);

        // 是自己 要加倒數秒小於3秒提示音效
        if (isSelf) {
            // 這邊自己做一個Action就好了 撥放音效不用那麼準確
            var checkFunc = () => {
                // 剩下多少時間
                var remainTime = (this._totalTime - (new Date().getTime() - this._baseTime)) / 1000;

                if (remainTime > 0 && remainTime < 3) {
                    // 撥放音效
                    Vegas_MusicUtility.playEffect("Music/Effect/clockhurry.mp3");

                    // 判斷是否要震動
                    if (cc.sys.isNative && DataModal.settingData.texas.vibrateBefore3Sec)
                        cc.Device.vibrate(0.2);
                }
            };
            this.runAction(cc.repeatForever(cc.sequence(
                cc.delayTime(1),
                cc.callFunc(checkFunc, this)
            )));
        }
    },

    /**
     * 停止倒數
     */
    stop: function () {
        this.setVisible(false);

        // 停掉Schedule 跟 倒數的Action
        this.unscheduleAllCallbacks();
        this.stopAllActions();
    }
});