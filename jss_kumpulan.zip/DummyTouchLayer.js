/**
 * 用來檔住 Touch 往下跑的 Layer
 * touchSize    區域大小
 * debug        是否出現 touchSize 位置
 * isReverse    false 碰到 touchSize 的 touch 吃掉，true 碰到 touchSize 以外的 touch 吃掉
 */

var DummyTouchLayer = cc.Layer.extend({

    /**
     * @param {cc.Size} touchSize   - 要檔住的區域大小
     * @param {boolean} [debug]     - 是否顯示擋住區域的 Debug 畫面
     * @param {boolean} [isReverse] - 是否要反轉觸碰區域的邏輯
     */
    ctor: function (touchSize, debug, isReverse) {
        this._super();

        this._touchSize = touchSize;                // 要檔住的大小
        this._onTouchEventName = undefined;         // 假如點到檔住的區域 可以設定是否要發通知出去
        this._onTouchEndedEventName = undefined;    // 假如點到檔住的區域 結束時 可以設定是否要發通知出去
        this._onTouchCallback = undefined;          // onTouchBegan 的 Callback
        this._onTouchEndedCallback = undefined;     // onTouchEnded 的 Callback
        this._isReverse = isReverse;                // 是否要反轉
        this._debug = debug;                        // 是否要顯示擋住區域

        if (debug) {
            // 要加Debug畫面
            const colorLayer = this._colorLayer = new cc.LayerColor(isReverse ? cc.color(0, 255, 0, 100) : cc.color(255, 0, 0, 100), touchSize.width, touchSize.height);
            this.addChild(colorLayer);
        }

        // 加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this.onTouchBegan.bind(this),
            onTouchEnded: this.onTouchEnded.bind(this)
        }, this);

        if (!cc.sys.isNative) {
            // H5 要加 Mouse 吃掉滑鼠事件
            cc.eventManager.addListener({
                event: cc.EventListener.MOUSE,
                swallowTouches: true,
                onMouseScroll: this.onMouseScroll.bind(this)
            }, this);
        }
    },

    /**
     * 設定點到該擋住的區域時(onTouchBegan)，需要送什麼通知出去
     * @param {string} eventName - 事件名稱
     * @return {void}
     */
    setOnTouchEventName: function (eventName) {
        this._onTouchEventName = eventName;
    },

    /**
     * 設定點到該擋住的區域時(onTouchEnded)，需要送什麼通知出去
     * @param {string} eventName - 事件名稱
     * @return {void}
     */
    setOnTouchEndedEventName: function (eventName) {
        this._onTouchEndedEventName = eventName;
    },

    /**
     * 設定點到該擋住的區域時(onTouchBegan)，需要執行的 Callback
     * @param {Function} callback - 觸碰開始時的回調函數
     * @return {void}
     */
    setOnTouchCallback: function (callback) {
        this._onTouchCallback = callback;
    },

    /**
     * 設定點到該擋住的區域時(onTouchEnded)，需要執行的 Callback
     * @param {Function} callback - 觸碰結束時的回調函數
     * @return {void}
     */
    setOnTouchEndedCallback: function (callback) {
        this._onTouchEndedCallback = callback;
    },

    /**
     * 重新設定 touchSize
     * @param {cc.Size} touchSize - 新的觸碰區域大小
     * @return {void}
     */
    setTouchSize: function (touchSize) {
        this._touchSize = touchSize;

        if (this._debug === true) {
            //要加Debug畫面
            this._colorLayer.removeFromParent();
            this._colorLayer = new cc.LayerColor(cc.color(255, 0, 0, 100), touchSize.width, touchSize.height);
            this.addChild(this._colorLayer);
        }
    },

    /**
     * 觸碰開始時的處理。
     * @param {cc.Touch} touch - 觸控事件的具體資訊
     * @param {cc.Event} event - 事件的相關資訊
     * @return {boolean} - 如果觸碰在指定區域內返回 true，否則返回 false
     */
    onTouchBegan: function (touch, event) {
        const target = event.getCurrentTarget();
        if (!target.isVisible())
            return false;
        for (let c = target.parent; c != null; c = c.parent) {
            if (!c.isVisible())
                return false;
        }

        const boundBox = cc.rect(0, 0, this._touchSize.width, this._touchSize.height);
        const touchPos = this.convertToNodeSpace(touch.getLocation());

        let touchInside = cc.rectContainsPoint(boundBox, touchPos);

        // 判斷反轉
        this._isReverse && (touchInside = !touchInside);

        if (touchInside) {
            // 送出設定的通知出去
            this._onTouchEventName && GS.dispatchCustomEvent(this._onTouchEventName);

            // 是否有 Callback
            this._onTouchCallback?.(touchPos);

            return true;
        } else {
            return false;
        }
    },

    /**
     * 觸碰結束時的處理。
     * @param {cc.Touch} touch - 觸控事件的具體資訊
     * @param {cc.Event} event - 事件的相關資訊
     * @return {void}
     */
    onTouchEnded: function (touch, event) {
        const target = event.getCurrentTarget();
        if (!target.isVisible())
            return;
        for (let c = target.parent; c != null; c = c.parent) {
            if (!c.isVisible())
                return;
        }

        const boundBox = cc.rect(0, 0, this._touchSize.width, this._touchSize.height);
        const touchPos = this.convertToNodeSpace(touch.getLocation());

        let touchInside = cc.rectContainsPoint(boundBox, touchPos);

        // 判斷反轉
        this._isReverse && (touchInside = !touchInside);

        if (touchInside) {
            // 送出設定的通知出去
            this._onTouchEndedEventName && GS.dispatchCustomEvent(this._onTouchEndedEventName);

            // 是否有 Callback
            this._onTouchEndedCallback?.(touchPos);
        }
    },

    onMouseScroll: function (event) {
        const target = event.getCurrentTarget();
        if (!target.isVisible())
            return false;
        for (let c = target.parent; c != null; c = c.parent) {
            if (!c.isVisible())
                return false;
        }

        const boundBox = cc.rect(0, 0, this._touchSize.width, this._touchSize.height);
        const mousePos = this.convertToNodeSpace(event.getLocation());

        let touchInside = cc.rectContainsPoint(boundBox, mousePos);

        // 判斷反轉
        this._isReverse && (touchInside = !touchInside);

        if (touchInside) {
            // 目前不做任何事
            // // 送出設定的通知出去
            // this._onTouchEventName && GS.dispatchCustomEvent(this._onTouchEventName);

            // // 是否有 Callback
            // this._onTouchCallback?.(mousePos);

            return true;
        }

        return false;
    }
});