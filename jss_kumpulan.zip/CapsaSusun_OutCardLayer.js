/**
 * CapsaSusun 所有玩家的手牌(發牌 & 出牌)
 */
var CapsaSusun_OutCardLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this.clean();

        // 設定放牌的起始位置(左上角第一張牌的位置)
        var stackPosArray = this._stackPosArray = {};
        for (var i = 0; i < 4; i++) {
            switch (i) {
                case GSEnum.GameDirection.RIGHT:
                    stackPosArray[i] = cc.p(347 + JSScreenBonusHalfWidth, 171 + JSScreenBonusHalfHeight);
                    break;

                case GSEnum.GameDirection.BOTTOM:
                    stackPosArray[i] = cc.p(236 + JSScreenBonusHalfWidth, 83 + JSScreenBonusHalfHeight);
                    break;

                case GSEnum.GameDirection.LEFT:
                    stackPosArray[i] = cc.p(125 + JSScreenBonusHalfWidth, 171 + JSScreenBonusHalfHeight);
                    break;

                case GSEnum.GameDirection.TOP:
                    stackPosArray[i] = cc.p(236 + JSScreenBonusHalfWidth, 261 + JSScreenBonusHalfHeight);
                    break;
            }
        }
    },

    // 清掉所有的牌
    clean: function () {
        // this._outCardNodeArray[玩家座位direction][第幾墩][第幾張牌]
        this._outCardNodeArray = [[], [], [], []];
        this._sendCardArray = [];       // 產生要發出去的牌
        this._statusSp = {};            // 牌上面蓋著的圖片

        this._currentPlay = false;

        this._cardAnimaNode && this._cardAnimaNode.stopAllActions();

        this.removeAllChildren();

        var cardAnimNode = this._cardAnimaNode = new cc.Node();
        this.addChild(cardAnimNode);
    },

    // 洗牌動畫
    shuffleAnim: function (dealerPos, sendPosArray, handCards) {
        this.clean();

        var playerNum = sendPosArray.length;
        var self = this;
        this._sendCardArray = [];
        gaf.create("gaf/game/remi_shuffle.gaf", this, true, function (asset) {
            var gafObject = asset.createObjectAndRun(false);
            gafObject.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 10);
            self.addChild(gafObject, 1);
            // 設定播完動畫後的事
            gafObject.runAction(cc.sequence(
                cc.delayTime(0.8),
                cc.callFunc(() => {
                    var sendCard = CapsaSusun_DealStackCount;
                    for (var i = 0; i < sendCard; i++) {
                        for (var j = 0; j < playerNum; j++) {
                            var cardNode = new PokerCardNode();
                            cardNode.setCardIsInBack(true);
                            cardNode.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + i * 0.5);
                            self.addChild(cardNode);

                            self._sendCardArray.push(cardNode);
                        }
                    }

                    // 開始發牌動畫
                    self._startDealAnim(dealerPos, sendPosArray, handCards)
                }),
                cc.removeSelf()
            ));
        });
    },

    // 取得該張牌是第幾區
    // cardIndex :玩家牌的index(每個人有13張 0~2/3~7/8~12)
    // return {number} :回傳在哪一區
    _getCardStack: function (cardIndex) {
        var stackCount = 0;
        if (cardIndex > 2 && cardIndex <= 7)
            stackCount = 1;
        else if (cardIndex > 7)
            stackCount = 2;

        return stackCount;
    },

    // 取得該張牌的位置
    // direction :玩家位置, cardCount :第幾張牌
    _getDealCardPosition: function (direction, cardCount, stackNum = -1) {
        var cardInfo = {};

        var pos = this._stackPosArray[direction];

        // 擺放第幾區的牌
        var stackCount = (stackNum === -1) ? this._getCardStack(cardCount) : stackNum;

        // 計算該區的第幾張牌
        var idx = [0, 3, 8];
        var stackCardIndex = (stackNum === -1) ? cardCount - idx[stackCount] : cardCount;

        var posX = stackCardIndex * 20 + pos.x + CapsaSusun_OutCardLayer.CardOffsetXArray[stackCount];
        var posY = pos.y - 27 * stackCount + CapsaSusun_OutCardLayer.CardOffsetYArray[stackCount][stackCardIndex];
        cardInfo.pos = cc.p(posX, posY);
        cardInfo.rotation = CapsaSusun_OutCardLayer.CardRotationArray[stackCount][stackCardIndex];

        return cardInfo;
    },

    // 求要顯示牌的位置
    _getShowCardPosition: function (direction, cardCount, stackNum) {
        var pos = this._stackPosArray[direction];

        // 計算該區的第幾張牌
        var idx = [0, 1, 1];
        var stackCardIndex = cardCount - idx[stackNum];

        var posX = stackCardIndex * 20 + pos.x;
        var posY = pos.y - 27 * stackNum;
        return cc.p(posX, posY);
    },

    // 開始發牌
    // dealerPos :該局的dealer位置, sendPosArray :要發牌給哪幾位玩家, handCards :自己的手牌
    _startDealAnim: function (dealerPos, sendPosArray, handCards) {
        // 先記下來是否有自己
        this._selfPlaying = !!handCards;

        var sendPosLen = sendPosArray.length;               // 要發給幾位玩家
        var totalCards = this._sendCardArray.length;        // 全部要發牌的張數
        var selfCardCount = 0;                              // 自己手牌的張數
        var nowDealCount = 0;                               // 當前發牌的數量
        var dealCount = -1;                                 // 每個玩家手上已收到的張數(0~12共13張 跟array算法一樣)
        var startDeal = sendPosArray.indexOf(dealerPos);    // 從哪個位置開始發牌

        if (startDeal === -1)
            startDeal = 0;

        var outCardArray = this._outCardNodeArray;
        this.runAction(cc.repeat(cc.sequence(
            cc.callFunc(function () {
                // 算現在的位置
                var nowLen = (startDeal + nowDealCount) % sendPosLen;
                var direction = sendPosArray[nowLen];

                // 把最後一張牌取出來
                var cardNode = this._sendCardArray.pop();
                if (!cardNode)
                    return;

                cardNode.idx = dealCount + 1;
                cardNode.setLocalZOrder(dealCount + 1);

                // 計算每個玩家發了幾張牌(0~12共13張)
                if (direction === dealerPos)
                    dealCount++;

                // 判斷要送去哪
                var dealCardInfo = this._getDealCardPosition(direction, dealCount);
                var toPos = dealCardInfo.pos;
                var toRotaion = dealCardInfo.rotation;

                // 塞入自己手牌的數字
                if (direction === 0 && this._selfPlaying && handCards[selfCardCount]) {
                    cardNode.setCardNumber(handCards[selfCardCount]);
                    cardNode.setCardIsInBack(true);
                    selfCardCount++;
                }

                // 加到各家手牌中
                var stack = this._getCardStack(dealCount);
                if (!outCardArray[direction][stack])
                    outCardArray[direction][stack] = [];
                outCardArray[direction][stack].push(cardNode);

                // 發送到各家
                var moveTime = 0.07;
                var isLast = nowDealCount === totalCards - 1;
                var self = this;
                cardNode && cardNode.runAction(cc.sequence(
                    cc.spawn(
                        cc.moveTo(moveTime, toPos),
                        cc.rotateBy(moveTime, toRotaion),
                        cc.scaleTo(moveTime, 0.68)
                    ),
                    cc.callFunc(function (cardNode) {
                        if (direction === 0 && self._selfPlaying) {
                            // 自己的手牌 翻開
                            cardNode.turnRiver(0);
                        }

                        // 發牌結束
                        if (isLast) {
                            GS.dispatchCustomEvent("NotifyEnableProcessMessage");
                        }

                    }, this)
                ));

                // 個數++
                nowDealCount++;
            }, this),
            cc.delayTime(0.04)
        ), totalCards));
    },

    // 是否決策完成的圖片
    // playerSit位置,isReady是否準備好, isSpecial是否是特殊牌
    showReadyFight: function (playerSit, isReady, isSpecial) {
        var res = "#capsaSusun_word_decision_02.png";
        if (isReady)
            res = "#capsaSusun_word_decision_01.png";
        if (isSpecial)
            res = "#capsaSusun_pic_special.png";
        var sp = this._statusSp[playerSit] = new cc.Sprite(res);
        var playerPos = CapsaSusun_GameUtility.getCardStacksMidPos(playerSit);
        sp.setPosition(cc.p(playerPos.x, playerPos.y));
        this.addChild(sp, 100);
        this._statusSp[playerSit].isReady = isReady;
    },

    // 跑換牌動畫
    // changeArray :哪兩張要換牌
    runChangeCardAnim: function (changeArray) {
        // 兩張卡片互換位置

        var cardA = changeArray[0];
        var cardB = changeArray[1];

        var zorderA = cardA.getLocalZOrder();
        var zorderB = cardB.getLocalZOrder();

        var posA = cardA.getPosition();
        var posB = cardB.getPosition();

        var rotationA = cardA.getRotation();
        var rotationB = cardB.getRotation();

        cardA.setLocalZOrder(zorderB);
        cardA.runAction(cc.sequence(
            cc.spawn(
                cc.moveTo(0.4, posB),
                cc.rotateTo(0.4, rotationB)
            ),
            cc.delayTime(0.2),
            cc.callFunc(() => {
                this._isChangeAnim = false;

                // 動畫做完要去整理牌
                if (this._needStopChangeCard) {
                    this.stopChangeCardAnim();
                }
            })
        ));

        cardB.setLocalZOrder(zorderA);
        cardB.runAction(cc.sequence(
            cc.spawn(
                cc.moveTo(0.4, posA),
                cc.rotateTo(0.4, rotationA)
            )
        ));
    },

    // 停止換牌動畫
    stopChangeCardAnim: function () {
        this._cardAnimaNode.stopAllActions();

        // 換牌動畫還在進行中 不整理(避免位置錯亂 等換牌結束後再整理)
        if (this._isChangeAnim)
            return;

        // 整理牌
        this._outCardNodeArray.forEach((curPlayer, idx) => {
            if (curPlayer && curPlayer[0]) {
                var playerCard = [].concat(...curPlayer);

                playerCard.sort((a, b) => a.idx - b.idx);

                var cardIdx = 0;
                curPlayer = [];
                for (var i = 0; i < CapsaSusun_StackCount; i++) {
                    curPlayer[i] = [];
                    for (var j = 0, len = CapsaSusun_CardStackCount[i]; j < len; j++) {
                        curPlayer[i][j] = playerCard[cardIdx];
                        var card = curPlayer[i][j];
                        if (card) {
                            var posInfo = this._getDealCardPosition(idx, cardIdx);
                            card.setPosition(posInfo.pos);
                            card.setRotation(posInfo.rotation);
                            card.idx = cardIdx + 1;
                            card.setLocalZOrder(card.idx);
                            cardIdx++;
                        }
                    }

                }
            }
        })
    },

    // show決策時的換牌動畫
    showChangeCardAnim: function () {
        // 是否要暫停換牌動畫
        this._needStopChangeCard = true;

        this.stopChangeCardAnim();

        // 還在決策的玩家(扣除自己)
        var players = [];
        for (var key in this._statusSp) {
            if (!this._statusSp[key].isReady && key !== "0")
                players.push(key);
        }
        var playerLen = players.length - 1;

        // 所有玩家都出牌了
        if (playerLen < 0)
            return;

        var time = JSCodeUtility.getRandomInt(3, 5);

        this._cardAnimaNode.runAction(cc.repeatForever(cc.sequence(
            cc.delayTime(time),
            cc.callFunc(() => {
                // 每次表演動畫隨機秒數
                time = JSCodeUtility.getRandomInt(3, 5);

                var radomSit = JSCodeUtility.getRandomInt(0, playerLen);
                var animCards = this._outCardNodeArray[players[radomSit]];

                // 是否正在進行換牌動畫
                this._isChangeAnim = true;

                this._needStopChangeCard = false;

                // 動隨機不重複的牌做換牌動畫
                var arr0 = [0, 1, 2];
                var arr1 = [0, 1, 2, 3, 4];
                var arr2 = [0, 1, 2, 3, 4];

                var radomStack0 = JSCodeUtility.getRandomInt(0, 2);
                arr0.splice(radomStack0, 1);
                var radomStack1 = JSCodeUtility.getRandomInt(0, 4);
                arr1.splice(radomStack1, 1);
                var radomStack2 = JSCodeUtility.getRandomInt(0, 4);
                arr2.splice(radomStack2, 1);

                var radomNum2 = JSCodeUtility.getRandomInt(0, 3);
                var radomNum1_1 = JSCodeUtility.getRandomInt(0, 3);
                var cardIdx = arr1[radomNum1_1];
                arr1.splice(radomNum1_1, 1);
                var radomNum1_2 = JSCodeUtility.getRandomInt(0, 2);

                var changeCards = [
                    [animCards[0][radomStack0], animCards[1][cardIdx]],
                    [animCards[1][radomStack1], animCards[2][arr2[radomNum2]]],
                    [animCards[2][radomStack2], animCards[1][arr1[radomNum1_2]]],
                ];

                changeCards.forEach(curArray => {
                    this.runChangeCardAnim(curArray);
                });

            }, this)
        )));
    },

    // 開始比牌
    startFight: function () {
        // 關閉換牌動畫
        this._needStopChangeCard = true;

        this.stopChangeCardAnim();
    },

    // 收到出牌
    // direction :方位, serverCardStrArray :server傳來的字串(牌, 牌組), isSpecial :是否是特殊牌組
    setOutCard: function (serverDir, serverCardStrArray = [], isSpecial = false) {
        var isMe = serverDir === DataModal.gameData.myPos;
        var direction = DataModal.gameData.getDirectionByServerDirection(serverDir);

        // 擺放牌墩
        var cardCount = 0;
        for (var i = 0; i < CapsaSusun_StackCount; i++) {
            for (var j = 0, len = CapsaSusun_CardStackCount[i]; j < len; j++) {
                var cardNum = serverCardStrArray[cardCount];
                // 假如有的話 直接改牌
                if (this._outCardNodeArray[direction].length) {
                    if (this._outCardNodeArray[direction][i][j]) {
                        this._outCardNodeArray[direction][i][j].setCardNumber(cardNum);
                        this._outCardNodeArray[direction][i][j].setCardIsInBack(!isMe);

                        isMe && this._outCardNodeArray[direction][i][j].setColor(JSColor.GRAY);
                    }
                }

                cardCount++;
            }
        }

        if (this._statusSp[direction]) {
            // 特殊牌組
            if (isSpecial)
                this._statusSp[direction].setSpriteFrame("capsaSusun_pic_special.png");
            else
                this._statusSp[direction].setSpriteFrame("capsaSusun_word_decision_01.png");

            this._statusSp[direction].isReady = true;

            this.showChangeCardAnim();
        } else {
            this.showReadyFight(direction, true, isSpecial);
        }
    },

    // 開始比牌
    // stackNum :0/1/2個代表1/2/3墩開牌, stackNum :3代表全部開牌
    showFightingAnim: function (serverDir, stackNum) {
        var direction = DataModal.gameData.getDirectionByServerDirection(serverDir);
        if (!this._outCardNodeArray[direction] || !this._outCardNodeArray[direction].length)
            return;

        // "特殊牌組"圖字關閉
        this._statusSp[direction] && this._statusSp[direction].setVisible(false);

        // 先全部設定變暗 並重設角度
        for (var i = 0; i < 3; i++) {
            this._outCardNodeArray[direction][i].forEach((card, idx) => {
                var originParam = this._getDealCardPosition(direction, idx, i);
                card.setPosition(originParam.pos);
                card.setRotation(originParam.rotation);
                card.setLocalZOrder(1);
                // 假如是都翻過了就全部設成白色
                if (stackNum >= CapsaSusun_StackCount)
                    card.setColor(JSColor.WHITE);
                else
                    card.setColor(JSColor.GRAY);
            })
        }

        // 全翻過了就可以離開了
        if (stackNum >= CapsaSusun_StackCount)
            return;

        // 立正牌修改角度 變回原色然後翻牌
        var cardStacks = this._outCardNodeArray[direction];
        cardStacks[stackNum].forEach((card, idx) => {
            var showPos = this._getShowCardPosition(direction, idx, stackNum);
            card.setPosition(showPos);
            card.setRotation(0);
            card.setLocalZOrder(2);
            card.setColor(JSColor.WHITE);
            card.turnRiver(0);
        });
    },

    // 特殊牌組亮牌 serverDir 方位
    showSpecialOutCard: function (serverDir, isTurnCard = true) {
        var direction = DataModal.gameData.getDirectionByServerDirection(serverDir);
        if (!this._outCardNodeArray[direction].length)
            return;
        // "特殊牌組"圖字關閉
        this._statusSp[direction] && this._statusSp[direction].setVisible(false);

        for (var i = 0; i < CapsaSusun_StackCount; i++) {
            this._outCardNodeArray[direction][i].forEach(card => {
                card.setLocalZOrder(1);
                card.setColor(JSColor.WHITE);
                isTurnCard && card.turnRiver(0);   // 翻開撲克牌
            });
        }

        var specialBgSp = new cc.Sprite("#capsaSusun_pic_pokerglow.png");
        specialBgSp.setPosition(cc.pAdd(CapsaSusun_GameUtility.getCardStacksMidPos(direction), cc.p(1, 0)));
        this.addChild(specialBgSp);

        if (!isTurnCard) {
            specialBgSp.runAction(cc.sequence(
                cc.fadeIn(0.5),
                cc.delayTime(0.5),
                cc.fadeOut(0.25),
                cc.fadeIn(0.25),
                cc.fadeOut(0.25),
                cc.fadeIn(0.25),
                cc.fadeOut(0.25),
                cc.removeSelf()
            ));
        } else {
            specialBgSp.runAction(cc.sequence(
                cc.fadeIn(0.5),
                cc.delayTime(0.5),
                cc.fadeOut(0.25),
                cc.fadeIn(0.25),
                cc.fadeOut(0.25),
                cc.fadeIn(0.25)
            ));
        }
    },

    // 特殊開牌 但是跳過翻牌動畫
    showSpecialCardSkipAnimation: function (serverDir) {
        var direction = DataModal.gameData.getDirectionByServerDirection(serverDir);
        if (!this._outCardNodeArray[direction].length)
            return;
        // "特殊牌組"圖字關閉
        this._statusSp[direction] && this._statusSp[direction].setVisible(false);

        for (var i = 0; i < CapsaSusun_StackCount; i++) {
            this._outCardNodeArray[direction][i].forEach(card => {
                card.setLocalZOrder(1);
                card.setColor(JSColor.WHITE);
            });
        }

        var specialBgSp = new cc.Sprite("#capsaSusun_pic_pokerglow.png");
        specialBgSp.setPosition(cc.pAdd(CapsaSusun_GameUtility.getCardStacksMidPos(direction), cc.p(1, 0)));
        this.addChild(specialBgSp);
    },

    // 牌局重現 通知轉位完成 開始設定場上的牌
    cmd_current_playing: function (playingPlayers, readyCardArray, specialPosArray, handCards) {
        // cmd current_play會送兩次 所以每次收到都要先清場
        this.clean();

        var readyPosArray = [];
        for (var key in readyCardArray) {
            readyPosArray.push(parseInt(key));
        }

        // 自己在畫面的位置
        var myPos = DataModal.gameData.myPos;
        // 有玩的開始創牌
        playingPlayers.forEach(curPlayer => {
            var direction = DataModal.gameData.getDirectionByServerDirection(curPlayer);
            var isMe = (myPos === curPlayer);
            var playerCard = this._outCardNodeArray[direction] = [];
            var cardCount = 0;
            for (var i = 0; i < CapsaSusun_StackCount; i++) {
                playerCard[i] = [];
                for (var j = 0; j < CapsaSusun_CardStackCount[i]; j++) {
                    var PosInfo = this._getDealCardPosition(direction, cardCount);
                    var cardNode = new PokerCardNode();
                    cardNode.setScale(0.68);
                    cardNode.setPosition(PosInfo.pos);
                    cardNode.setRotation(PosInfo.rotation);
                    this.addChild(cardNode, cardCount);
                    playerCard[i].push(cardNode);

                    // 自己的牌要有數字
                    cardNode.setCardIsInBack(!isMe);
                    if (isMe) {
                        handCards && cardNode.setCardNumber(handCards[cardCount]);
                        cardNode.setColor(JSColor.GRAY);
                    }

                    cardCount++;
                }
            }
            this.showReadyFight(direction, false);
        });

        // 已經出完牌的玩家
        readyPosArray.forEach(curPlayer => {
            var cardArray = readyCardArray[curPlayer];
            if (cardArray.length) {
                var isSpecial = (specialPosArray.indexOf(curPlayer) !== -1);
                this.setOutCard(curPlayer, cardArray, isSpecial);
                if (curPlayer === myPos && isSpecial)
                    this.showSpecialOutCard(curPlayer, false);
            }
        });

        // 還在出牌階段
        this.showChangeCardAnim();
    }
});

// 每一區的每張牌旋轉角度
CapsaSusun_OutCardLayer.CardRotationArray = [[-10, 0, 10], [-10, -5, 0, 5, 10], [-10, -5, 0, 5, 10]];
// 每一區每張牌的位移量
CapsaSusun_OutCardLayer.CardOffsetYArray = [[0, 2, 0], [0, 3, 4, 3, 0], [0, 3, 4, 3, 0]];
// 每一區第一張的位移量
CapsaSusun_OutCardLayer.CardOffsetXArray = [0, -20, -20];