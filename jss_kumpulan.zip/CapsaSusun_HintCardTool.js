/**
 * CapsaSusun 牌型計算工具
 */
var CapsaSusun_HintCardTool = Pokers_HintCardBaseTool.extend({
    ctor: function () {
        this._super();

        this._lastCardArray = null;

        this.pairFit5Array = [];                        // 一對 (湊5張)
        this.twoPairFit5Array = [];                     // 兩對 (湊5張)
        this.threeOfAKindFit5Array = [];                // 三條 (湊5張)
    },

    cleanData: function () {
        this._lastCardArray = null;

        this.pairFit5Array = [];                        // 一對 (湊5張)
        this.twoPairFit5Array = [];                     // 兩對 (湊5張)
        this.threeOfAKindFit5Array = [];                // 三條 (湊5張)
    },

    /**
     * @override
     * 檢查可以出的牌組
     * @param cardArray         要分析的牌組(格式是server字串)
     * @param checkAlgorithm    是否分析推薦牌組
     */
    checkAllCard: function (cardArray, checkAlgorithm = false) {

        if (JSON.stringify(this._lastCardArray) === JSON.stringify(cardArray)) {
            // cc.log("跟上次算的牌組一樣. 不重複算");
            return;
        }

        this._lastCardArray = cardArray;
        this._super(cardArray);

        // 檢查所有牌型
        this.checkPair();
        this.checkTwoPair();
        this.checkThreeOfAKind();
        this.checkFlush();
        this.checkStraight();
        this.checkFullHouse();
        this.checkFourOfAKind();
        this.checkStraightFlush();

        // 葫蘆 在推薦牌組部分要按照CP值排序, 複製一份並重新排序
        this._algorithmFullHouseArray = this.fullHouseArray.slice();
        this._algorithmFullHouseArray.sort((a, b) => {
            return this._checkCardArrayBetter(a.realNumberCardList, b.realNumberCardList);
        });

        // 鐵支 在推薦牌組部分要按照CP值排序, 複製一份並重新排序
        this._algorithmFourOfAKindArray = this.fourOfAKindArray.slice();
        this._algorithmFourOfAKindArray.sort((a, b) => {
            return this._checkCardArrayBetter(a.realNumberCardList, b.realNumberCardList);
        });

        checkAlgorithm && this._checkAlgorithmCard();
    },

    /**
     * 找該牌型的下一個組合
     * @param algorithmObj
     * @param cardGroupArray    傳類型的組合進來，如果沒有傳，代表是按按鈕做的
     * @returns {boolean}       有沒有下一組
     */
    nextAlgorithmParam: function (algorithmObj, cardGroupArray) {
        var cardTypeArray = algorithmObj.cardTypeArray;
        var isGetCardGroupArrayBySelf = !cardGroupArray;
        cardGroupArray = cardGroupArray || [
            this._getHintArrayByCapsaSusunCardKindType(cardTypeArray[0]),  // 取不是5張的組合
            this._getOriginArrayByCardType(cardTypeArray[1]),
            this._getOriginArrayByCardType(cardTypeArray[2])
        ];

        var originLengthList = [cardGroupArray[0].length - 1, cardGroupArray[1].length - 1, cardGroupArray[2].length - 1];
        var lengthList = algorithmObj.nextIndexList ? algorithmObj.nextIndexList : originLengthList;

        // 如果第一墩 是一對／三條 且跟第二墩不是同牌型 拉出來額外處理. 以1 3 2牌墩順序放牌
        if ((cardTypeArray[0] === CapsaSusun_CardKindType.OnePair || cardTypeArray[0] === CapsaSusun_CardKindType.ThreeOfAKind) && cardTypeArray[0] !== cardTypeArray[1]) {
            // 取第ㄧ墩牌型牌組
            for (var i = lengthList[0]; i >= 0; i--) {
                // 推薦牌組Obj
                var cardList0 = cardGroupArray[0][i].realNumberCardList;
                var cardArray0 = cardList0.slice();

                // 取第三墩牌型牌組
                for (var j = lengthList[2]; j >= 0; j--) {
                    // 推薦牌組Obj
                    var cardList2 = cardGroupArray[2][j].realNumberCardList;
                    var cardArray2 = cardList2.slice();

                    // 檢查牌有沒有重複
                    if (this._checkCardRepeat(cardArray2, cardArray0))
                        continue;

                    // 跟原本資料的長度一樣 且 同樣牌型 要找比他小的
                    var index = (lengthList[1] === originLengthList[0] && cardTypeArray[2] === cardTypeArray[1]) ? j - 1 : lengthList[1];
                    // 取第二墩牌型牌組
                    for (var k = index; k >= 0; k--) {
                        var cardList1 = cardGroupArray[1][k].realNumberCardList;

                        // 檢查牌有沒有重複
                        if (this._checkCardRepeat(cardArray2, cardList1) || this._checkCardRepeat(cardArray0, cardList1))
                            continue;

                        var cardArray1 = cardList1.slice();

                        // 一對 要補上最後一張牌
                        if (cardTypeArray[0] === CapsaSusun_CardKindType.OnePair) {
                            var lastCard = this._findRemainCards(cardArray0.concat(cardArray2).concat(cardArray1));
                            cardArray0 = cardArray0.concat(lastCard);

                            // 檢查是不是符合牌型
                            if (cardTypeArray[0] !== this._check13CardKindByCardsArray(cardArray0))
                                continue;
                        }

                        if (this.checkHintCardConform([cardArray0, cardArray1, cardArray2]).isConform) {
                            // 新增這組牌型 並且記下現在跑到哪裡
                            this._addAlgorithmParamToArray([cardArray0, cardArray1, cardArray2], algorithmObj.algorithmArray);
                            algorithmObj.nextIndexList = [i, k - 1, j];
                            return true;
                        } else {
                            algorithmObj.nextIndexList = [i, k - 1, j];
                        }

                    }

                    // 都沒有找到 而且 是按按鈕做的，要重置
                    if (isGetCardGroupArrayBySelf)
                        lengthList[1] = originLengthList[1];
                }

                // 都沒有找到 而且 是按按鈕做的，要重置
                if (isGetCardGroupArrayBySelf)
                    lengthList[2] = originLengthList[2];
            }
        } else {
            // 取第三墩牌型牌組
            for (var x = lengthList[2]; x >= 0; x--) {
                // 推薦牌組Obj
                var cardList2 = cardGroupArray[2][x].realNumberCardList;
                var cardArray2 = cardList2.slice();

                // 第二墩是烏龍 (即第一, 二墩都是烏龍)
                if (cardTypeArray[1] === CapsaSusun_CardKindType.None) {
                    var tempArray = this._findRemainCards(cardList2);    // 找出剩下的牌

                    // 要錯開大小, 最大放在第二墩 第2大放在第一墩
                    var cardArray1 = [tempArray[2], tempArray[3], tempArray[4], tempArray[5], tempArray[7]];
                    var cardArray0 = [tempArray[0], tempArray[1], tempArray[6]];

                    // 檢查是否真烏龍
                    if (this._check13CardKindByCardsArray(cardArray1) === CapsaSusun_CardKindType.None && this._check13CardKindByCardsArray(cardArray0) === CapsaSusun_CardKindType.None) {
                        // 新增這組牌型 並且記下現在跑到哪裡
                        if (this.checkHintCardConform([cardArray0, cardArray1, cardArray2]).isConform) {
                            this._addAlgorithmParamToArray([cardArray0, cardArray1, cardArray2], algorithmObj.algorithmArray);
                            algorithmObj.nextIndexList = [-1, originLengthList[0], x - 1];
                            return true;
                        } else {
                            algorithmObj.nextIndexList = [-1, originLengthList[0], x - 1];
                        }

                    }
                } else {
                    // 跟原本資料的長度一樣 且 同樣牌型 要找比他小的
                    var index = (lengthList[1] === originLengthList[0] && cardTypeArray[2] === cardTypeArray[1]) ? x - 1 : lengthList[1];
                    // 取第二墩牌型牌組
                    for (var y = index; y >= 0; y--) {
                        var cardList1 = cardGroupArray[1][y].realNumberCardList;

                        // 檢查牌有沒有重複
                        if (this._checkCardRepeat(cardArray2, cardList1))
                            continue;

                        var cardArray1 = cardList1.slice();

                        // 第一墩，先找出最後剩下什麼牌
                        var cardArray0 = this._findRemainCards(cardList2.concat(cardList1));

                        // 檢查是不是符合牌型
                        if (cardTypeArray[0] === this._check13CardKindByCardsArray(cardArray0)) {
                            // 第一, 二墩一樣牌型 (不會是烏龍，因為第二墩已經處理掉烏龍了)
                            if (cardTypeArray[0] === cardTypeArray[1]) {
                                // 如果第二墩沒比較大，就下一個 (這裡都拿中間的牌，因為前面有排序過，idx為1的值 必定會是 一對或三條 的數字)
                                if (!this._checkCardBigger(cardArray1[1], cardArray0[1]))
                                    continue;
                            }

                            // 一對 要特別調整位置，讓 單張 放在最右邊
                            cardTypeArray[0] === CapsaSusun_CardKindType.OnePair
                            && Pokers_CardUtility.cardNumberByRealNumber(cardArray0[0]) !== Pokers_CardUtility.cardNumberByRealNumber(cardArray0[1])
                            && cardArray0.push(cardArray0.shift());

                            // 新增這組牌型 並且記下現在跑到哪裡
                            if (this.checkHintCardConform([cardArray0, cardArray1, cardArray2]).isConform) {
                                this._addAlgorithmParamToArray([cardArray0, cardArray1, cardArray2], algorithmObj.algorithmArray);
                                algorithmObj.nextIndexList = [-1, y - 1, x];
                                return true;
                            } else {
                                algorithmObj.nextIndexList = [-1, y - 1, x];
                            }
                        }
                    }
                    // 都沒有找到 而且 是按按鈕做的，要重置
                    if (isGetCardGroupArrayBySelf)
                        lengthList[1] = originLengthList[1];
                }
            }
        }

        // 沒有下一組了
        algorithmObj.nextIndexList = [-1, -1, -1];
        return false;
    },

    /**
     * 算推薦牌組
     */
    _checkAlgorithmCard: function () {
        var totalCardArray = this._totalCardArray = [];
        var count = 0;

        // 先把手牌資訊抓出來 (A > K, 從i = 1(即數字為2的牌)開使轉, 最後再轉i = 13(即數字為A的牌))
        for (var i = 1; i < 14; ++i) {
            for (var j = 0; j < 4; ++j) {
                if (this._parseCardArray[i][j]) {
                    totalCardArray[count++] = 10 * (((i === 13) ? 0 : i) + 1) + (j + 1);    // 轉成RealNumber
                }
            }
        }
        this.algorithmObjArray = [];

        this._combineCards();       // 湊牌
        this._startCounting();

        // 最後備份一下 會被更新的 各種牌類初始組合 (要拿來給後續 nextAlgorithmParam 算組合，否則當牌類組合在checkAllCard被更新之後 就會出錯)
        this._originPairArray = this.pairArray.slice();
        this._originThreeOfAKindArray = this.threeOfAKindArray.slice();
        this._originStraightArray = this.straightArray.slice();
        this._originFlushArray = this.flushArray.slice();
        this._originFullHouseArray = this._algorithmFullHouseArray.slice();
        this._originFourOfAKindArray = this._algorithmFourOfAKindArray.slice();
        this._originStraightFlushArray = this.straightFlushArray.slice();
    },

    /**
     * 確認是否符合出牌的規則(3墩>2墩>1墩 同牌型 比較數字的大小)
     * @param cardsArray    : 3墩的牌(cardRealNumber)
     */
    checkHintCardConform: function (cardsArray) {
        var obj = {};
        var hintCardKind = [];
        var bigNumber = [];
        cardsArray.forEach(curArray => {
            // 該墩的牌型
            var kind = this._check13CardKindByCardsArray(curArray);
            hintCardKind.push(kind);

            // 該牌型最大的數字
            bigNumber.push(this._getMaxCardKindByNumber(kind, curArray));
        });

        // 存放三層的牌型
        var hintKind = [];
        // 相同的牌行會比較數字的大小(設定權重)
        var weightArray = hintCardKind.map((cur, idx) => {
            // 牌行*100000000000 + 該牌行最大的數字(一對(會待上三張牌) ＆ 二對 會帶上單張牌)
            hintKind.push(cur);
            return cur * CapsaSusun_CardKindWeight + bigNumber[idx];
        });

        // 因為第一層層跟第二層只比三張牌  如果數字一樣比牌型最大的花色
        // 取出1、2層的三張牌權重
        var num = weightArray[0] < 10000000 ? 100000 : 10000000;
        var weight0 = weightArray[0] < 10000000 ? Math.floor(weightArray[0] / 10) : Math.floor(weightArray[0] / 10000000);
        var weight1 = Math.floor(weightArray[1] / num);

        // 比較1、2層 當牌型一樣時
        // 三條 只比較最大的數字
        // 其他牌型數字都一樣時要比較最大數字的花色
        var str0 = weightArray[0].toString();
        var str1 = weightArray[1].toString();
        var str0Len = str0.length;
        var str1Len = str1.length;
        if (hintKind[0] === hintKind[1]
            && hintKind[0] === CapsaSusun_CardKindType.ThreeOfAKind) {
            // 1、2層牌型是 三條時只比較最大的數字
            var suit0 = parseInt(str0[str0Len - 2] + str0[str0Len - 1]);
            var suit1 = parseInt(str1[str1Len - 2] + str1[str1Len - 1]);
        } else {
            // 1、2層牌型跟數字相同時 比較最大花色
            var suit0 = parseInt(str0[str0Len - 1]);
            var suit1 = parseInt(str1[str1Len - 1]);
        }

        // 正確的牌型大小 第3層 > 第2層 > 第1層 (牌型相同比數字)
        obj.isConform = weightArray[2] >= weightArray[1] && weight1 > weight0
            || weightArray[2] >= weightArray[1] && weight1 === weight0 && suit1 > suit0;
        obj.kindType = hintCardKind;
        obj.weightArray = weightArray;

        return obj;
    },

    /**
     * 找出該牌型最大的數字
     * @param kind          牌型
     * @param cardsArray    牌(cardRealNumber)
     */
    _getMaxCardKindByNumber: function (kind, cardsArr) {

        var cardsArray = [];

        // A最大把A轉14
        cardsArr.forEach(cur => {
            // A最大
            if (cur >= 11 && cur <= 14)
                cur = 140 + cur % 10;

            // 避免cur是undefine
            cur && cardsArray.push(cur);
        });

        cardsArray.sort((a, b) => b - a);

        switch (kind) {
            case CapsaSusun_CardKindType.StraightFlush:
            case CapsaSusun_CardKindType.Straight:
                // 同花順、順子
                // 找出最大張的牌

                // A 5 4 3 2 這組順子最大要去比 5 而非A
                if (cardsArray[0] >= 141 && cardsArray[0] <= 144 && cardsArray[1] >= 51 && cardsArray[1] <= 54) {
                    return cardsArray[1];
                } else
                    return Math.max(...cardsArray);

            case CapsaSusun_CardKindType.Flush:
            case CapsaSusun_CardKindType.None:
                // 高牌、同花
                if (cardsArray.length === 0)
                    return 0;

                // 最大張花色
                var maxSuit = cardsArray[0] % 10;

                // 把牌的數字串起來
                var numberArray = cardsArray.map(cur => {
                    var str = cur.toString();
                    return parseInt(str.substring(0, str.length - 1));
                });

                var numStr = "";

                // 個位數要補0
                numberArray.forEach(cur => {
                    numStr += JSStringUtility.format("%02d", cur);
                });

                numStr += maxSuit;

                return parseInt(numStr);

            case CapsaSusun_CardKindType.FullHouse:
            case CapsaSusun_CardKindType.FourOfAKind:
            case CapsaSusun_CardKindType.ThreeOfAKind:
            case CapsaSusun_CardKindType.TwoPair:
            case CapsaSusun_CardKindType.OnePair:

                // 取出數字
                var numberArray = cardsArray.map(cur => {
                    var str = cur.toString();
                    return parseInt(str.substring(0, str.length - 1));
                });

                // 找出相同的牌
                var kindArray = numberArray.filter((item, index) => numberArray.indexOf(item) !== index);

                if (kind === CapsaSusun_CardKindType.FullHouse) {
                    // 葫蘆 (找出三條的那組牌)
                    kindArray = kindArray.filter((item, index) => kindArray.indexOf(item) !== index);
                    kindArray.push(0);
                    return Math.max(...kindArray);
                } else if (kind === CapsaSusun_CardKindType.TwoPair || kind === CapsaSusun_CardKindType.OnePair) {
                    // 兩對 1對
                    kindArray.sort((a, b) => b - a);

                    var arr2 = [];
                    var arr1 = [];
                    var maxNum = 0;
                    var weight = 1000000000;

                    // 排序(對子放前面 再放單張 依照數字大>小 花色大>小)
                    kindArray.forEach(curKind => {
                        var rangeMin = curKind * 10 + 1;
                        var rangeMax = curKind * 10 + 4;

                        arr2 = [];
                        for (var i = 0, len = cardsArray.length; i < len && i >= 0; i++) {
                            if (cardsArray[i] >= rangeMin && cardsArray[i] <= rangeMax) {
                                arr1.push(cardsArray[i]);
                                cardsArray.splice(i, 1);
                                i--;
                                len--;
                            } else
                                arr2.push(cardsArray[i]);
                        }

                        maxNum = maxNum + curKind * weight;
                        weight /= 100;
                    });

                    var hightCard = numberArray.filter(cur => cur !== kindArray[0]);
                    hightCard.sort((a, b) => b - a);

                    hightCard.forEach(cur => {
                        maxNum = maxNum + cur * weight;
                        weight /= 100;
                    });

                    cardsArray = arr1.concat(arr2);
                    var maxSuit = cardsArray[0] % 10;

                    maxNum += maxSuit;

                    return maxNum;
                } else {
                    kindArray.push(0);
                    // 找出最大張的牌

                    var maxNum = Math.max(...kindArray);

                    return maxNum;
                }

            default:
                return 0;
        }
    },

    /**
     * 13支 湊牌檢查
     * @param cardsArray    要檢查的撲克牌陣列
     * @returns {*}
     */
    _check13CardKindByCardsArray: function (cardsArray) {
        // 轉成算牌用二維陣列
        var array = Pokers_CardUtility.parseCardArray(cardsArray, false);

        // 不滿5張直接跳過這些檢查
        if (cardsArray.length === 5) {
            if (Pokers_CardUtility.checkKindStraightFlush(array)) {
                // 同花順
                return CapsaSusun_CardKindType.StraightFlush;
            } else if (Pokers_CardUtility.checkKindFourOfAKind(array)) {
                // 鐵支
                return CapsaSusun_CardKindType.FourOfAKind;
            } else if (Pokers_CardUtility.checkKindFullHouse(array)) {
                // 葫蘆
                return CapsaSusun_CardKindType.FullHouse;
            } else if (Pokers_CardUtility.checkKindFlush(array)) {
                // 同花
                return CapsaSusun_CardKindType.Flush;
            } else if (Pokers_CardUtility.checkKindStraight(array)) {
                // 順子
                return CapsaSusun_CardKindType.Straight;
            } else if (Pokers_CardUtility.checkKindTwoPair(array)) {
                // 兩對
                return CapsaSusun_CardKindType.TwoPair;
            }
        }

        if (Pokers_CardUtility.checkKindThreeOfAKind(array)) {
            // 三條
            return CapsaSusun_CardKindType.ThreeOfAKind;
        } else if (Pokers_CardUtility.checkKindOnePair(array)) {
            // 對子
            return CapsaSusun_CardKindType.OnePair;
        }
        return CapsaSusun_CardKindType.None;
    },

    /**
     * 把不滿五張的合成五張
     */
    _combineCards: function () {
        var totalCardArray = this._totalCardArray;
        var array, fit5Array;

        // 一對 湊5張
        array = this.pairArray;
        fit5Array = this.pairFit5Array;
        fit5Array.length = 0;
        for (var i = 0, len = array.length; i < len; i++) {
            var cardsList = array[i].realNumberCardList.slice();

            for (var a = 12; a >= 0; a--) {
                if (cardsList.some(cur => cur === totalCardArray[a]))
                    continue;
                for (var b = a - 1; b >= 0; b--) {
                    if (cardsList.some(cur => cur === totalCardArray[b]))
                        continue;
                    for (var c = b - 1; c >= 0; c--) {
                        if (cardsList.some(cur => cur === totalCardArray[c]))
                            continue;

                        var tempList = cardsList.concat([totalCardArray[a], totalCardArray[b], totalCardArray[c]]);
                        if (this._check13CardKindByCardsArray(tempList) === CapsaSusun_CardKindType.OnePair) {
                            fit5Array.push(new Pokers_HintCardParam(CapsaSusun_CardKindType.OnePair, tempList.slice()));
                        }
                    }
                }
            }
        }

        // 兩對 湊5張
        array = this.twoPairArray;
        fit5Array = this.twoPairFit5Array;
        fit5Array.length = 0;
        for (var i = 0, len = array.length; i < len; i++) {
            var cardsList = array[i].realNumberCardList.slice();

            for (var a = 12; a >= 0; a--) {
                if (cardsList.some(cur => cur === totalCardArray[a]))
                    continue;

                var tempList = cardsList.concat([totalCardArray[a]]);
                if (this._check13CardKindByCardsArray(tempList) === CapsaSusun_CardKindType.TwoPair) {
                    fit5Array.push(new Pokers_HintCardParam(CapsaSusun_CardKindType.TwoPair, tempList.slice()));
                }
            }
        }

        // 三條 湊5張
        array = this.threeOfAKindArray;
        fit5Array = this.threeOfAKindFit5Array;
        fit5Array.length = 0;
        for (var i = 0, len = array.length; i < len; i++) {
            var cardsList = array[i].realNumberCardList.slice();

            for (var a = 12; a >= 0; a--) {
                if (cardsList.some(cur => cur === totalCardArray[a]))
                    continue;
                for (var b = a - 1; b >= 0; b--) {
                    if (cardsList.some(cur => cur === totalCardArray[b]))
                        continue;

                    var tempList = cardsList.concat([totalCardArray[a], totalCardArray[b]]);
                    if (this._check13CardKindByCardsArray(tempList) === CapsaSusun_CardKindType.ThreeOfAKind) {
                        fit5Array.push(new Pokers_HintCardParam(CapsaSusun_CardKindType.ThreeOfAKind, tempList.slice()));
                    }
                }
            }
        }
    },

    /**
     * 開始算推薦牌組
     */
    _startCounting: function () {
        var cardGroupArray = [[], [], []];
        var cardTypeArray = [0, 0, 0];
        for (var x = parseInt(CapsaSusun_CardKindType.Length) - 1; x >= 0; x--) {
            cardGroupArray[2] = this._getArrayByCardType(x);

            if (!cardGroupArray[2] || !cardGroupArray[2].length)
                continue;

            cardTypeArray[2] = x;

            for (var y = x; y >= 0; y--) {
                cardGroupArray[1] = this._getArrayByCardType(y);

                if (y !== CapsaSusun_CardKindType.None) {
                    // 不是烏龍, 判斷有沒有牌型
                    if (!cardGroupArray[1] || !cardGroupArray[1].length)
                        continue;
                }
                cardTypeArray[1] = y;

                // 第一墩
                for (var z = (y > 3) ? 3 : y; z >= 0; z--) {
                    switch (z) {
                        // 一對
                        case  CapsaSusun_CardKindType.OnePair:
                            cardGroupArray[0] = this.pairArray;

                            if (!cardGroupArray[0] || !cardGroupArray[0].length)
                                continue;
                            else
                                break;

                        // 兩對
                        case  CapsaSusun_CardKindType.TwoPair:
                            continue;

                        // 三條 (第一墩 要變衝三)
                        case  CapsaSusun_CardKindType.ThreeOfAKind:
                            cardGroupArray[0] = this.threeOfAKindArray;

                            if (!cardGroupArray[0] || !cardGroupArray[0].length)
                                continue;
                            else
                                break;

                        default:
                            cardGroupArray[0] = [];
                            break;
                    }
                    cardTypeArray[0] = z;

                    // cc.log("......開始算Type " + x + "|" + y + "|" + z + "|");
                    // 已經有這牌型 代表第一墩不用在找了
                    if (this._countWeightByArray(cardGroupArray, cardTypeArray)) {
                        // cc.log("++++新增 Type " + x + "|" + y + "|" + z + "|");
                        break;
                    }
                    // cc.log("----算完, 沒有此Type");
                }
            }
        }
        // cc.log("==========END==========");
    },

    /**
     * 指定牌型拼算牌組
     * @param cardGroupArray    指定牌型所有個別組合
     * @param cardTypeArray     牌型陣列
     * @returns {boolean}       回傳是否有找到並加入推薦牌組陣列
     */
    _countWeightByArray: function (cardGroupArray, cardTypeArray) {
        var nowWeight = 4 * cardTypeArray[0] + 3 * cardTypeArray[1] + 2 * cardTypeArray[2];
        var algorithmObjArray = this.algorithmObjArray;

        // 排除重複的牌型
        algorithmObjArray.some(cur => {
            if (cur.cardTypeArray[0] && cur.cardTypeArray[1] && cur.cardTypeArray[2])
                return false;
        });

        // 比權重 只算六個比較重就好
        if (algorithmObjArray.length === CapsaSusun_AlgorithmCount && !algorithmObjArray.some(cur => cur.weight < nowWeight))
            return false;

        // 快速選牌顯示順序的權重(第一墩 > 第二墩 > 第三墩)
        var sortWeight = 100 * cardTypeArray[0] + 20 * cardTypeArray[1] + 2 * cardTypeArray[2];

        // 存同牌型牌組
        var algorithmObj = {
            sortWeight: sortWeight,
            weight: nowWeight,                      // 權重
            cardTypeArray: cardTypeArray.slice(),   // 各牌墩牌型
            algorithmArray: [],                     // 存所有牌組
            nextIndexList: null,                    // 格式：[0, 0, 0]，第一、二、三墩牌下次要從哪一個index開始找 (之後往下算要用)
        };

        // 有找到對應牌型的推薦牌組
        if (this.nextAlgorithmParam(algorithmObj, cardGroupArray)) {
            algorithmObjArray.push(algorithmObj);                                             // 存起來
            algorithmObjArray.sort((a, b) => b.weight - a.weight);                            // 按照權重排序
            (algorithmObjArray.length > CapsaSusun_AlgorithmCount) && algorithmObjArray.pop();   // 如果數量超過要的組數, 把最輕的丟掉
            return true;
        } else {
            // 回傳沒找到
            return false;
        }
    },

    /**
     * 檢查2張牌大小, 回傳A是否大於B
     * @param cardRealNumA
     * @param cardRealNumB
     * @returns {boolean}
     */
    _checkCardBigger: function (cardRealNumA, cardRealNumB) {
        // 檢查是否需要加成
        Pokers_CardUtility.isBiggerThenK(cardRealNumA) && (cardRealNumA += 130);
        Pokers_CardUtility.isBiggerThenK(cardRealNumB) && (cardRealNumB += 130);

        // 比大小
        return (cardRealNumA - cardRealNumB) > 0;
    },

    /**
     * 比較2同牌型牌組哪個CP值高 (主牌最大+配牌最小)
     * @param realNumberCardListA
     * @param realNumberCardListB
     * @returns {number}
     * @private
     */
    _checkCardArrayBetter: function (realNumberCardListA, realNumberCardListB) {
        var cardRealNumA = realNumberCardListA[0];
        var cardRealNumB = realNumberCardListB[0];

        // 取數字
        var aCardNum = Pokers_CardUtility.cardNumberByRealNumber(cardRealNumA);
        var bCardNum = Pokers_CardUtility.cardNumberByRealNumber(cardRealNumB);

        // 如果主牌數字一樣, 比配牌
        if ((aCardNum - bCardNum) === 0) {
            cardRealNumA = realNumberCardListA[4];
            cardRealNumB = realNumberCardListB[4];

            // 比大小, 小的放前面
            return (this._checkCardBigger(cardRealNumA, cardRealNumB) ? -1 : 1);
        } else {
            // 比大小, 大的放前面
            return (this._checkCardBigger(cardRealNumA, cardRealNumB) ? 1 : -1);
        }
    },

    /**
     * 把推薦牌組存起來
     * @param cardArray         要存的牌組
     * @param algorithmArray    要存的位置
     * @returns {boolean}       是否成功存入
     */
    _addAlgorithmParamToArray: function (cardArray, algorithmArray) {
        // 判斷牌數量是否正確
        if (cardArray[2].length === 5 && cardArray[1].length === 5 && cardArray[0].length === 3) {
            algorithmArray.push(cardArray); // 存起來
            return true;    // 回傳新增成功
        }
        return false;       // 回傳新增失敗
    },

    /**
     * 取手牌剩餘牌(已經有按照大小排序)
     * @param delCardArray  已經抓住, 要從手牌剔除的牌陣列
     * @returns {any[]}     剩下的手牌
     */
    _findRemainCards: function (delCardArray) {
        var returnArray = this._totalCardArray.slice();

        // 找出剩下的牌
        delCardArray.forEach((cur) => {
            var idx = returnArray.indexOf(cur);
            (idx !== -1) && returnArray.splice(idx, 1);
        });

        // 排序大小
        returnArray.sort((a, b) => {
            // 比大小
            return (this._checkCardBigger(a, b) ? 1 : -1);
        });

        return returnArray;
    },

    /**
     * 檢查2陣列是否有相同牌
     * @param listA         第一個陣列
     * @param listB         第二個陣列
     * @returns {boolean}   true: 有重複. false: 沒重複
     */
    _checkCardRepeat: function (listA, listB) {
        for (var i = 0, len = listB.length; i < len; i++) {
            if (listA.some(cur => cur === listB[i]))
                return true;
        }
        return false;
    },

    /**
     * 取得對應的hintArray
     * @param cardKindType 要抓哪個牌型的array
     */
    _getHintArrayByCapsaSusunCardKindType: function (cardKindType) {
        switch (cardKindType) {
            // 一對
            case CapsaSusun_CardKindType.OnePair:
                return this._originPairArray;

            // 三條
            case CapsaSusun_CardKindType.ThreeOfAKind:
                return this._originThreeOfAKindArray;

            default:
                return this._getArrayByCardType(cardKindType);
        }
    },

    /**
     * 取對應牌型的資料(湊滿5張的)
     * @param cardType      牌型
     * @returns {Array}
     */
    _getArrayByCardType: function (cardType) {
        switch (cardType) {
            // 一對
            case CapsaSusun_CardKindType.OnePair:
                return this.pairFit5Array;

            // 兩對
            case CapsaSusun_CardKindType.TwoPair:
                return this.twoPairFit5Array;

            // 三條
            case CapsaSusun_CardKindType.ThreeOfAKind:
                return this.threeOfAKindFit5Array;

            // 順子
            case CapsaSusun_CardKindType.Straight:
                return this.straightArray;

            // 同花
            case CapsaSusun_CardKindType.Flush:
                return this.flushArray;

            // 葫蘆 (第二墩 要變中蹲葫蘆)
            case CapsaSusun_CardKindType.FullHouse:
                return this._algorithmFullHouseArray;       // 回傳推薦牌組用陣列

            // 鐵支
            case CapsaSusun_CardKindType.FourOfAKind:
                return this._algorithmFourOfAKindArray;     // 回傳推薦牌組用陣列

            // 同花順
            case CapsaSusun_CardKindType.StraightFlush:
                return this.straightFlushArray;

            default:
                return [];
        }
    },

    /**
     * 取最初對應牌型的資料(湊滿5張的)
     * @param cardType      牌型
     * @returns {Array}
     */
    _getOriginArrayByCardType: function (cardType) {
        switch (cardType) {
            // 一對, 兩對, 三條 都拿原本的，因為不會被更新
            case CapsaSusun_CardKindType.OnePair:
            case CapsaSusun_CardKindType.TwoPair:
            case CapsaSusun_CardKindType.ThreeOfAKind:
                return this._getArrayByCardType(cardType);

            // 順子
            case CapsaSusun_CardKindType.Straight:
                return this._originStraightArray;

            // 同花
            case CapsaSusun_CardKindType.Flush:
                return this._originFlushArray;

            // 葫蘆 (第二墩 要變中蹲葫蘆)
            case CapsaSusun_CardKindType.FullHouse:
                return this._originFullHouseArray;

            // 鐵支
            case CapsaSusun_CardKindType.FourOfAKind:
                return this._originFourOfAKindArray;

            // 同花順
            case CapsaSusun_CardKindType.StraightFlush:
                return this._originStraightFlushArray;

            default:
                return [];
        }
    },
});

