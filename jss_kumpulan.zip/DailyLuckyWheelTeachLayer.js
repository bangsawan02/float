/**
 * 每日輪盤首次領獎的教學頁
 */

var DailyLuckyWheelTeachLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        var node = this._container = new cc.Node();
        this.addChild(node);
    },

    onEnter: function () {
        this._super();

        // 擋Back Key
        PushScene.addBackKeyEnableLayer(this);
    },

    onExit: function () {
        PushScene.removeBackKeyEnableLayer(this);

        this._super();
    },

    //  Android Back Key
    keyBackPressed: function () {
        // 不做事
    },

    // 顯示教學頁
    showTeach: function () {
        var node = this._container;
        var luckyWheelStr = LocalizedString.DailyLuckyWheel;

        // 黑色壓底
        var blackLayer = new cc.LayerColor(cc.color(0, 0, 0, 200), JSVisibleSize.width, JSVisibleSize.height);
        node.addChild(blackLayer);

        // Avatar
        // 5.5.8改看板娘有額外調整(之後如果要改回原版看板娘要再調整回去)
        var avatar = new cc.Sprite(SelectGameManager.getNowGameFile("common_avatar.png"));
        avatar.setScale(-0.75, 0.75);
        avatar.setPosition(432 + JSScreenBonusHalfWidth, (GS.isLuxyPoker ? 95 : 152) + JSScreenBonusHalfHeight);
        node.addChild(avatar);

        // 天數倍率顯示區
        var bonusDayNode = new DailyLuckyWheelBonusDayNode(true);
        bonusDayNode.setPosition(84 + JSScreenBonusHalfWidth, 122 + JSScreenBonusHalfHeight);
        node.addChild(bonusDayNode);

        // 垂直排版Node
        var layoutNode = new GSAutoLayoutNode();
        layoutNode.setType(GSAutoLayout.TYPE.VERTICAL);

        // 做訊息視窗
        var richTextNode = new GSRichTextNode("#!000000!#" + luckyWheelStr("連續完成越多天，加倍獎勵越高。明天記得回來唷♥"), JSFontName, 12, cc.size(350, 35));
        richTextNode.setHAlignmentToCenter(true);
        layoutNode.addChild(richTextNode);

        // 繼續玩牌按鈕
        var playBtn = ButtonUtility.createSimpleButton("lobby_btn_03.png", cc.size(120, 30), luckyWheelStr("繼續玩牌"), JSColor.WHITE, 16);
        playBtn.addTouchUpInsideAction(this._close, this);
        layoutNode.addChild(playBtn);

        var param = {
            mainNode: layoutNode,
            style: BaseMessageNode.Style.WHITE_SHADOW,
            direct: BaseMessageNode.Direct.UP,
            arrowType: BaseMessageNode.ArrowType.STRAIGHT,
            isFlip: true,
            arrowPadding: -130,
            arrowToBgPadding: 5,
            bgBonusSize: cc.size(15, 15)
        };

        var messageNode = new BaseMessageNode(param);
        messageNode.setPosition(440 + JSScreenBonusHalfWidth, 120 + JSScreenBonusHalfHeight);
        messageNode.show();
        node.addChild(messageNode);
    },

    // 關閉導引
    _close: function () {
        // 存client紀錄
        GS.localStorage.setItem("dailyLuckyWheelTeachDone", "1");

        // 執行領取動畫 true->教學頁結束要直接引導馬上玩
        GS.dispatchCustomEvent("NotifyLuckyWheelCollectClicked", true);
        this.removeFromParent();
    }
});