/**
 * v5.6.0 夾娃娃機挑戰 - 轉盤本體
 * created by Jimmy.wen
 */

var ClawMachineChallengeWheelNode = cc.Node.extend({
    /**
     * @param {ClawMachineChallengePageLayer} pageLayerPtr
     */
    ctor: function (pageLayerPtr) {
        this._super();

        this.key = "ClawMachineChallengeWheelNode";
        this._rewardIndex = -1;
        this._isJackpot = false;
        this._nowLevel = 0;
        this.isSpining = false;
        this._pageLayerPtr = pageLayerPtr;

        // 小轉盤中心
        var wheelMidPoint = this._wheelMidPoint = cc.p(152 + JSScreenBonusHalfWidth, 202.5 + JSScreenBonusHalfHeight);

        // 大轉盤中心
        this._bigWheelMidPoint = cc.p(JSScreenMidPos.x, JSVisibleSize.height - 237);

        // 放大轉盤出現才出現的node
        var mainNodesArray = this._mainNodesArray = [];

        // 小轉盤
        var wheelSp = this._wheelSp = new cc.Sprite("#clawMachineChallenge_pic_wheel_01.png");
        wheelSp.setPosition(wheelMidPoint);
        this.addChild(wheelSp);

        // 背景底色 (創2個是轉盤升級換色用)
        this._bgSpArray = [0, 1].map(cur => {
            var bgSp = new ccui.Scale9Sprite("clawMachineChallenge_bg_01.png");
            bgSp.setPosition(JSScreenMidPos);
            if (cur === 0)
                mainNodesArray.push(bgSp);
            else
                bgSp.setOpacity(0);
            this.addChild(bgSp);

            return bgSp;
        });

        // 背景上方的光 (創2個是轉盤升級換色用)
        this._bgLightSpArray = [0, 1].map(cur => {
            var bgLightSp = new cc.Sprite();
            bgLightSp.setPosition(JSScreenMidPos.x, JSVisibleSize.height);
            bgLightSp.setAnchorPoint(cc.p(0.5, 1));
            bgLightSp.setScale(3);
            if (cur === 0)
                mainNodesArray.push(bgLightSp);
            else
                bgLightSp.setOpacity(0);
            this.addChild(bgLightSp);

            return bgLightSp;
        });

        // 背景擋touch
        var dummyTouchLayer = this._dummyTouchLayer = new DummyTouchLayer(JSVisibleSize);
        dummyTouchLayer.setVisible(false);
        this.addChild(dummyTouchLayer);

        // 標題
        var titleSp = this._titleSp = new cc.Sprite("#clawMachineChallenge_word_title_02.png");
        titleSp.setPosition(256 + JSScreenBonusHalfWidth, JSVisibleSize.height - 21.5);
        mainNodesArray.push(titleSp);
        this.addChild(titleSp);

        // 標題左右的星星
        this._starSpArray = [189, 321.5].map((cur, index) => {
            var starSp = new cc.Sprite("#clawMachineChallenge_pic_star.png");
            starSp.setPosition(cur + JSScreenBonusHalfWidth, JSVisibleSize.height - 16.5);
            starSp.setFlippedX(index === 1);
            mainNodesArray.push(starSp);
            this.addChild(starSp);

            return starSp;
        });

        // 放上方最大獎數字的autoLayoutNode
        var jackpotAutoLayoutNode = this._jackpotAutoLayoutNode = new GSAutoLayoutNode();
        jackpotAutoLayoutNode.setPosition(256 + JSScreenBonusHalfWidth, JSVisibleSize.height - 51.5);
        jackpotAutoLayoutNode.setScale(0.65);
        jackpotAutoLayoutNode.setSpace(3);
        mainNodesArray.push(jackpotAutoLayoutNode);

        // 頭獎金額
        var numberSp = this._numberSp = new GSSpriteNumberNode({
            number: 0,
            numStr: "#num_26_",
            addDot: true,
            isDotHeightAsNum: true,
            spW: 26,
            dotW: 8
        });
        jackpotAutoLayoutNode.addChild(numberSp);

        // 「Chips」美術圖
        var wordChipsSp = new cc.Sprite("#clawMachineChallenge_word_chips.png");
        jackpotAutoLayoutNode.addChild(wordChipsSp);
        this.addChild(jackpotAutoLayoutNode);

        // 放小轉盤前面、大轉盤後面的動畫的node
        var wheelBgAniNode = this._wheelBgAniNode = new cc.Node();
        this.addChild(wheelBgAniNode);

        // 放整個轉盤的node
        var wholeWheelNode = this._wholeWheelNode = new cc.Node();
        wholeWheelNode.setPosition(wheelMidPoint);
        wholeWheelNode.setScale(0.2);
        wholeWheelNode.setCascadeColorEnabled(true);
        wholeWheelNode.setCascadeOpacityEnabled(true);
        wholeWheelNode.setOpacity(0);
        this.addChild(wholeWheelNode);

        // 轉盤外框 this._wheelFrameSpriteArray[0]是左半
        this._wheelFrameSpriteArray = [0, 1].map(_cur => {
            return [0, 1].map(cur => {
                var wheelFrameSprite = new cc.Sprite("#clawMachineChallenge_pic_wheel_frame_01.png");
                wheelFrameSprite.setAnchorPoint(_cur, 0.5);
                wheelFrameSprite.setFlippedX(_cur === 0);
                cur === 1 && wheelFrameSprite.setOpacity(0);
                wholeWheelNode.addChild(wheelFrameSprite);

                return wheelFrameSprite;
            });
        });

        // 放拿來轉的轉盤的node
        var wheelNode = this._wheelNode = new cc.Node();
        wheelNode.setCascadeOpacityEnabled(true);
        wholeWheelNode.addChild(wheelNode);

        // 轉盤內容物相關參數
        var wheelBgNum = ["1", "2", "4", "5", "3", "2", "4", "5"];             // 圖檔的名稱

        this._wheelRewardNodeArray = wheelBgNum.map((num, index) => {
            var rewardNode = new cc.Node();
            rewardNode.setRotation(index * 45);
            rewardNode.setCascadeColorEnabled(true);
            rewardNode.setCascadeOpacityEnabled(true);
            wheelNode.addChild(rewardNode);

            // 獎項背景
            var rewardBg = new cc.Sprite(JSStringUtility.format("#clawMachineChallenge_pic_wheel_wheel_0%s.png", num));
            rewardBg.setPositionY(-12);         // 美術出圖圖片沒切在邊上 所以要這樣調整...
            rewardBg.setAnchorPoint(0.5, 0);
            rewardNode.addChild(rewardBg);

            // 獎項文字
            var rewardLabel = rewardNode.rewardLabel = new cc.LabelTTF("", JSFontName, 12.5);
            rewardLabel.setRotation(90);
            rewardLabel.setFontFillColor(JSColor.WHITE);
            rewardLabel.enableStroke(JSColor.BLACK, 3);
            rewardLabel.setPositionY(rewardBg.getContentSize().height / 2 + (index === 0 ? 5 : 10));
            rewardNode.addChild(rewardLabel);

            return rewardNode;
        });

        // 邊邊上的燈泡
        {
            var distance = 150;
            var bulbPosArray = [];
            // 因為寬螢幕裝置會看到轉盤下面 這邊直接繞一圈
            for (let i = 4; i > -12; i--) {
                var angle = Math.PI / 8 * i;
                bulbPosArray.push(cc.p(distance * Math.cos(angle), distance * Math.sin(angle)));
            }
            bulbPosArray.forEach((cur, index) => {
                var isOffFirst = (index % 2) === 0;

                var bulbSp = new cc.Sprite("#clawMachineChallenge_pic_light01.png");
                bulbSp.setPosition(cur);
                wholeWheelNode.addChild(bulbSp);

                var bulbSp2 = new cc.Sprite("#clawMachineChallenge_pic_light02.png");
                bulbSp2.setPosition(cur);
                isOffFirst && bulbSp2.setOpacity(0);
                wholeWheelNode.addChild(bulbSp2);

                if (isOffFirst) {
                    // 先變亮再變暗
                    bulbSp2.runAction(cc.sequence(
                        cc.fadeIn(0.5),
                        cc.delayTime(0.2),
                        cc.fadeOut(0.5),
                        cc.delayTime(0.2)
                    ).repeatForever());
                } else {
                    // 先變暗再變亮
                    bulbSp2.runAction(cc.sequence(
                        cc.fadeOut(0.5),
                        cc.delayTime(0.2),
                        cc.fadeIn(0.5),
                        cc.delayTime(0.2)
                    ).repeatForever());
                }
            });
        }

        // 中獎那格的框
        var wheelSelectFrameSp = new cc.Sprite("#clawMachineChallenge_pic_wheel_wheel_select.png");
        wheelSelectFrameSp.setPositionY(64.5);
        wholeWheelNode.addChild(wheelSelectFrameSp);

        // 指針
        var pointerSp = new cc.Sprite("#clawMachineChallenge_pic_pointer.png");
        pointerSp.setPositionY(138);
        wholeWheelNode.addChild(pointerSp, 2);

        // 旋轉按鈕
        var spinBtn = this._spinBtn = ButtonUtility.createSimpleButton(undefined, cc.size(99, 99), "()", undefined, 17);
        spinBtn.addTouchUpInsideAction(this._spinBtnClicked, this);
        spinBtn.label.setPositionY(-16.5);
        spinBtn.label.enableStroke(JSColor.BLACK, 3);
        spinBtn.label.setLocalZOrder(2);
        spinBtn.setEnabled(false);
        wholeWheelNode.addChild(spinBtn, 2);

        // 按鈕縮放+噴光動畫
        this._playSkeletonAni(ClawMachineChallengeWheelNode.SPINE_ANI_NUMBER.CAN_SPIN_SCALE_AND_LIGHT, spinBtn, cc.p(-3, 0), true);

        // 按鈕文字動畫另外做
        spinBtn.label.runAction(cc.sequence(
            cc.scaleTo(0.3, 1.1),
            cc.scaleTo(0.1333, 0.92),
            cc.scaleTo(0.0667, 1.03),
            cc.scaleTo(0.0667, 0.97),
            cc.scaleTo(0.0666, 1.01),
            cc.scaleTo(0.0667, 1)
        ));

        // 左邊「最大獎機率」底圖 (創2個是轉盤升級換色用)
        var jackpotRateBgPos = this._jackpotRateBgPos = cc.p(68.5 + JSScreenBonusHalfWidth, JSVisibleSize.height - 117);
        this._jackpotRateBgArray = [0, 1].map(cur => {
            var jackpotRateBg = new ccui.Scale9Sprite("clawMachineChallenge_bg_jackpot_01.png");
            jackpotRateBg.setPosition(jackpotRateBgPos);
            if (cur === 0)
                mainNodesArray.push(jackpotRateBg);
            else
                jackpotRateBg.setOpacity(0);
            this.addChild(jackpotRateBg);

            return jackpotRateBg;
        });

        // 左邊「最大獎機率」文字1
        var jackpotRateLabel1 = new cc.LabelTTF(LocalizedString.Purchase("最大獎機率"), JSFontName, 11);
        jackpotRateLabel1.setPosition(68.5 + JSScreenBonusHalfWidth, JSVisibleSize.height - 100.5);
        jackpotRateLabel1.setFontFillColor(cc.color(255, 240, 0));
        mainNodesArray.push(jackpotRateLabel1);
        this.addChild(jackpotRateLabel1);

        // 左邊「最大獎機率」文字2
        var jackpotRateLabel2 = this._jackpotRateLabel2 = new cc.LabelTTF("", JSFontName, 20);
        jackpotRateLabel2.setPosition(68.5 + JSScreenBonusHalfWidth, JSVisibleSize.height - 121.5);
        mainNodesArray.push(jackpotRateLabel2);
        this.addChild(jackpotRateLabel2);

        // 右下角「跳過動畫」按鈕
        var skipBtn = this._skipBtn = ButtonUtility.createSimpleButton("lobby_btn_03.png", cc.size(84, 28.5), LocalizedString.Purchase("跳過動畫"), JSColor.WHITE, 15);
        skipBtn.setPosition(460 + JSScreenBonusHalfWidth, 30);
        skipBtn.addTouchUpInsideAction(this._skipBtnClicked, this);
        skipBtn.setVisible(false);
        this.addChild(skipBtn);

        // loading圖
        var loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y);
        loadingSprite.start();
        loadingSprite.setVisible(false);
        this.addChild(loadingSprite);

        // 把主要元件隱藏
        mainNodesArray.forEach(cur => cur.setVisible(false));

        GS.addListener("NotifyClawMachineChallengeWheelGetReward", this.notifyClawMachineChallengeWheelGetReward.bind(this), this);
    },

    /**
     * 刷新介面
     */
    refreshView: function () {
        var clawMachineInfo = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE);
        var param = clawMachineInfo.wheelData;

        // 背景換色
        this._bgSpArray[0].setSpriteFrame(JSStringUtility.format("clawMachineChallenge_bg_0%s.png", param.level));
        this._bgSpArray[0].setPreferredSize(JSVisibleSize);

        // 背景光換色
        this._bgLightSpArray[0].setSpriteFrame(JSStringUtility.format("clawMachineChallenge_bg_top_light_0%s.png", param.level));

        // 大獎金額刷新
        this._numberSp.setNumber(param.maxReward);
        this._jackpotAutoLayoutNode.refresh();

        // 大獎機率換色
        this._jackpotRateBgArray[0].setSpriteFrame(JSStringUtility.format("clawMachineChallenge_bg_jackpot_0%s.png", param.level));
        this._jackpotRateBgArray[0].setPreferredSize(cc.size(127, 72));

        // 小轉盤換色
        this._wheelSp.setSpriteFrame(JSStringUtility.format("clawMachineChallenge_pic_wheel_0%s.png", param.level));

        // 轉盤外框換色
        this._wheelFrameSpriteArray.forEach(cur => {
            cur[0].setSpriteFrame(JSStringUtility.format("clawMachineChallenge_pic_wheel_frame_0%s.png", param.level));
        });

        // 刷新機率
        this._refreshJackpotRate();

        // 刷新轉盤亮暗
        this._refreshWheelStatus();

        // 刷新轉盤內容
        this._refreshWheelReward();

        // 刷新可以轉的次數
        this._spinBtn.label.setString(JSStringUtility.format("(%s)", clawMachineInfo.getWheelRewardCount));

        // 記下現在等級
        this._nowLevel = param.level;
    },

    /**
     * 根據isGet刷新轉盤的亮暗
     * @private
     */
    _refreshWheelStatus: function () {
        var clawMachineInfo = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE);
        var isGetArray = clawMachineInfo.wheelData.isGetArray;

        this._wheelRewardNodeArray.forEach((cur, index) => {
            if (isGetArray.indexOf(index) !== -1) {
                cur.setColor(cc.color(80, 80, 80));
            } else {
                cur.setColor(JSColor.WHITE);
            }
        });
    },

    /**
     * 刷新轉盤文字內容
     * @private
     */
    _refreshWheelReward: function () {
        var clawMachineInfo = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE);
        var wheelList = clawMachineInfo.wheelData.wheelList;

        this._wheelRewardNodeArray.forEach((cur, index) => {
            // 頭獎要顯示「最大獎」文字 而不是數字
            var jpPosList = clawMachineInfo.wheelData.jackpotPosList;
            cur.rewardLabel.setString(jpPosList.indexOf(index) !== -1 ? LocalizedString.Purchase("最大獎") : wheelList[index]);
        });
    },

    /**
     * 刷新大獎機率
     * @private
     */
    _refreshJackpotRate: function () {
        var clawMachineInfo = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE);
        var wheelParam = clawMachineInfo.wheelData;
        var isGetArray = wheelParam.isGetArray;
        var rate = Math.floor(10000 / (8 - isGetArray.length));
        this._jackpotRateLabel2.setString(JSStringUtility.format("%f%%", rate / 100));
    },

    // 鎖back
    _setIsLockBackKey: function (isLock = false) {
        this._pageLayerPtr.setAllBtnEnabled(!isLock);
    },

    // 卡loading
    _setIsLoading: function (isLoading) {
        this._loadingSprite.setVisible(isLoading);
        this._skipBtn.setEnabled(!isLoading);
    },

    /**
     * 調整標題狀態
     * @param type 是哪種，可參考ClawMachineChallengeWheelNode.TITLE_STATUS
     * @private
     */
    _setTitleStatus: function (type) {
        var titlePos, starPosArray;
        switch (type) {
            case ClawMachineChallengeWheelNode.TITLE_STATUS.SHOW_JACKPOT:
                // 顯示標題：最大獎
                titlePos = JSVisibleSize.height - 21.5;
                starPosArray = [cc.p(189 + JSScreenBonusHalfWidth, JSVisibleSize.height - 16.5), cc.p(321.5 + JSScreenBonusHalfWidth, JSVisibleSize.height - 16.5)];
                break;
            case ClawMachineChallengeWheelNode.TITLE_STATUS.WHEEL_UPGRADE:
                // 顯示標題：恭喜轉盤升級至X等
                titlePos = JSVisibleSize.height - 22;
                starPosArray = [cc.p(171.5 + JSScreenBonusHalfWidth, JSVisibleSize.height - 17), cc.p(339.5 + JSScreenBonusHalfWidth, JSVisibleSize.height - 17)];
                break;
            case ClawMachineChallengeWheelNode.TITLE_STATUS.JACKPOT_RATE_UP:
                // 顯示標題：最大獎中獎率提升
                titlePos = JSVisibleSize.height - 39;
                starPosArray = [cc.p(63 + JSScreenBonusHalfWidth, JSVisibleSize.height - 34), cc.p(448 + JSScreenBonusHalfWidth, JSVisibleSize.height - 34)];
                break;
            case ClawMachineChallengeWheelNode.TITLE_STATUS.MAX_WHEEL:
                // 顯示標題：已達最高級轉盤！快來拿大獎吧
                titlePos = JSVisibleSize.height - 42;
                starPosArray = [cc.p(103 + JSScreenBonusHalfWidth, JSVisibleSize.height - 27), cc.p(408 + JSScreenBonusHalfWidth, JSVisibleSize.height - 27)];
                break;
        }

        if (titlePos) {
            this._titleSp.setSpriteFrame(JSStringUtility.format("clawMachineChallenge_word_title_0%s.png", type));
            this._titleSp.setPositionY(titlePos);
            this._titleSp.setVisible(true);

            // 星星調整位置
            this._starSpArray.forEach((cur, index) => {
                this._starSpArray[index].setPosition(starPosArray[index]);
                cur.setVisible(true);
            });
        }
    },

    /**
     * 播放動畫檔案
     * @param num spine檔案的內部編號，可參考ClawMachineChallengeWheelNode.SPINE_ANI_NUMBER
     * @param node 要把動畫加在哪個node
     * @param pos 位置
     * @param isLoop 是否連續播放
     * @private
     */
    _playSkeletonAni: function (num, node, pos, isLoop) {
        // 防呆 範圍外不做事
        if (num >= 1 && num <= Object.keys(ClawMachineChallengeWheelNode.SPINE_ANI_NUMBER).length) {
            // 播放動畫
            var animationPath = "spine/PurchaseTriggerIntegration/ClawMachineChallenge/ani_wheel";
            GS.loadSpine(animationPath, () => {
                var wheelSpine = new sp.SkeletonAnimation(animationPath + ".json", animationPath + ".atlas", 0.25);
                wheelSpine.setAnimation(0, JSStringUtility.format('ani_0%d', num), isLoop);
                wheelSpine.setPosition(pos);
                wheelSpine.setAnimationListener(this, () => {
                    (!isLoop) && wheelSpine.removeFromParent();

                    switch (num) {
                        case ClawMachineChallengeWheelNode.SPINE_ANI_NUMBER.CAN_SPIN_SCALE_AND_LIGHT:
                            this._spinBtn.label.stopAllActions();   // 標籤動畫停止

                            // 可點擊狀態的話 跟著重複播放
                            this._spinBtn.isEnabled() && this._spinBtn.label.runAction(cc.sequence(
                                cc.scaleTo(0.3, 1.1),
                                cc.scaleTo(0.1333, 0.92),
                                cc.scaleTo(0.0667, 1.03),
                                cc.scaleTo(0.0667, 0.97),
                                cc.scaleTo(0.0666, 1.01),
                                cc.scaleTo(0.0667, 1)
                            ));
                            break;
                    }
                });

                if (num === ClawMachineChallengeWheelNode.SPINE_ANI_NUMBER.CAN_SPIN_SCALE_AND_LIGHT) {
                    this._spinBtnAni = wheelSpine;          // 記下來

                    // 這個是GSControlButton 要加在裡面
                    node.addChildToContentNode(wheelSpine);
                } else
                    node.addChild(wheelSpine);
            });
        }
    },

    // 給外部呼叫用的 播放進度條滿之後的小轉盤後面的光的動畫
    playProcessFullAni: function () {
        this._playSkeletonAni(ClawMachineChallengeWheelNode.SPINE_ANI_NUMBER.PROCESSING_FULL_LIGHT, this._wheelBgAniNode, this._wheelMidPoint, false);
    },

    // 轉盤移動動畫
    runWheelMoveAnimate: function () {
        // 打開擋touch
        this._dummyTouchLayer.setVisible(true);

        // 通知鎖住back按鈕
        this._setIsLockBackKey(true);

        // 大轉盤
        this._wholeWheelNode.stopAllActions();
        this._wholeWheelNode.setPosition(this._wheelMidPoint);
        this._wholeWheelNode.runAction(cc.sequence(
            cc.spawn(
                cc.fadeIn(0.5).easing(cc.easeOut(0.8)),
                cc.moveTo(0.5, this._bigWheelMidPoint),
                cc.scaleTo(0.5, 1)
            ),
            cc.callFunc(() => {
                this._bgSpArray[0].setVisible(true);
            })
        ));

        // 移動完後把需要的東西顯示
        this.runAction(cc.sequence(
            cc.delayTime(0.5),
            cc.callFunc(() => {
                this._mainNodesArray.forEach(cur => cur.setVisible(true));
                this._spinBtn.setEnabled(true);
            })
        ));

        // 5.6.0埋點 主動彈跳轉盤
        DataModal.purchaseTriggerIntegrationData.sendClawMachineChallengeUserAnalyticsTrack(3056);
    },

    // 轉盤歸位動畫
    _runWheelBackAnimate: function () {
        var clawMachineInfo = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE);
        var wheelParam = clawMachineInfo.wheelData || {};

        // 鎖旋轉按鈕
        this._spinBtn.setEnabled(false);

        // 刷新小轉盤顏色
        this._wheelSp.setSpriteFrame(JSStringUtility.format("clawMachineChallenge_pic_wheel_0%s.png", wheelParam.level));

        // 縮小大轉盤+移動回去
        this._wholeWheelNode.runAction(cc.sequence(
            cc.scaleTo(0.3, 0.2),
            cc.spawn(
                cc.moveTo(0.3, this._wheelMidPoint),
                cc.fadeOut(0.3).easing(cc.easeOut(0.8))
            ),
            cc.callFunc(() => {
                this._mainNodesArray.forEach(cur => cur.setVisible(false));
                this._dummyTouchLayer.setVisible(false);
                this._wholeWheelNode.setPosition(148 + JSScreenBonusHalfWidth, 239 + JSScreenBonusHalfHeight);

                // 通知解鎖back按鈕
                this._setIsLockBackKey();

                // 先刷新一次主介面
                GS.dispatchCustomEvent("NotifyClawMachineChallengeInfoDone");

                // 讓夾娃娃機介面卡loading
                this._pageLayerPtr.setLoadingSprite(true, true);

                // 重要資料
                DataModal.purchaseTriggerIntegrationData.startGetInfoByType(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE);
            })
        ));
    },

    /**
     * 創獲獎畫面第一步驟：
     * 一般：轉動靜止，中獎格以外的顯示皆壓黑(約0.5秒)
     * 大獎：轉動靜止，中獎格以外的顯示皆壓黑，旁邊有金幣從轉盤為中心向四周噴出(約0.5秒)
     * @private
     */
    _getRewardStep1: function () {
        this._wheelRewardNodeArray.forEach((cur, index) => {
            if (index !== this._rewardIndex) {
                cur.setColor(cc.color(80, 80, 80));
            }
        });

        // 播放大獎的噴金幣動畫
        if (this._isJackpot) {
            this._playSkeletonAni(ClawMachineChallengeWheelNode.SPINE_ANI_NUMBER.JACKPOT_COIN, this._wheelBgAniNode, this._bigWheelMidPoint, false);
        }

        this.runAction(cc.sequence(
            cc.delayTime(0.5),
            cc.callFunc(() => {
                this._getRewardStep2();
            })
        ));
    },

    /**
     * 創獲獎畫面第二步驟：
     * 顯示獲獎區塊，淡出彈跳顯示(約2秒)
     * @private
     */
    _getRewardStep2: function () {
        var clawMachineInfo = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE);
        var chips = clawMachineInfo.wheelData.rewardTxtArray ? clawMachineInfo.wheelData.rewardTxtArray[0] : 0;

        var getRewardNode = new cc.Node();
        getRewardNode.setPosition(JSScreenMidPos.x, JSVisibleSize.height - 51);
        getRewardNode.setScale(0.5);
        getRewardNode.setCascadeOpacityEnabled(true);
        getRewardNode.setOpacity(0);
        this.addChild(getRewardNode);

        // 背景
        [0, 1].forEach(cur => {
            var rewardBgSp = new cc.Sprite("#clawMachineChallenge_bg_frame.png");
            rewardBgSp.setAnchorPoint(cur, 0.5);
            rewardBgSp.setFlippedX(cur === 0);
            getRewardNode.addChild(rewardBgSp);
        });

        // 裝標題的autoLayoutNode
        var titleAutoLayoutNode = new GSAutoLayoutNode();
        titleAutoLayoutNode.setCascadeOpacityEnabled(true);
        titleAutoLayoutNode.setSpace(-12);
        titleAutoLayoutNode.setPositionY(27.5);

        // 小獎大獎都有的標題文字
        var commonTitleSp = new cc.Sprite("#clawMachineChallenge_word_title_06.png");
        titleAutoLayoutNode.addChild(commonTitleSp);

        // 大獎才額外有的標題文字
        if (this._isJackpot) {
            var jackpotTitleSp = new cc.Sprite("#clawMachineChallenge_word_title_07.png");
            titleAutoLayoutNode.addChild(jackpotTitleSp);
        }

        // 放得獎數字的autoLayoutNode
        var chipAutoLayoutNode = new GSAutoLayoutNode();
        chipAutoLayoutNode.setCascadeOpacityEnabled(true);
        chipAutoLayoutNode.setSpace(5);
        chipAutoLayoutNode.setScale(0.65);

        // 金額
        var numberSp = new GSSpriteNumberNode({
            number: chips,
            numStr: "#num_26_",
            addDot: true,
            isDotHeightAsNum: true,
            spW: 24,
            dotW: 8
        });
        chipAutoLayoutNode.addChild(numberSp);

        // 「Chips」美術圖
        var wordChipsNode = new cc.Node();
        wordChipsNode.setCascadeOpacityEnabled(true);
        var wordChipsSp = new cc.Sprite("#clawMachineChallenge_word_chips.png");
        wordChipsSp.setPosition(wordChipsSp.getContentSize().width / 2, wordChipsSp.getContentSize().height / 2 - 3);
        wordChipsNode.addChild(wordChipsSp);
        wordChipsNode.setContentSize(wordChipsSp.getContentSize());
        chipAutoLayoutNode.addChild(wordChipsNode);

        // 最後才加入autoLayout
        getRewardNode.addChild(titleAutoLayoutNode);
        getRewardNode.addChild(chipAutoLayoutNode);

        // 彈出動畫
        getRewardNode.runAction(cc.sequence(
            cc.spawn(cc.fadeIn(0.4),
                cc.scaleTo(0.4, 1.3)),
            cc.scaleTo(0.1, 1),
            cc.scaleTo(0.1, 1.3),
            cc.scaleTo(0.2, 1),
            cc.delayTime(1.5),
            cc.fadeOut(1),
            cc.callFunc(() => {
                this._getRewardStep3();
                cc.removeSelf();
            })
        ));
    },

    /**
     * 創獲獎畫面第三步驟：獲獎區塊往下消失，顯示完整轉盤，且指針固定在大獎位置
     * @private
     */
    _getRewardStep3: function () {
        this._wheelNode.setRotation(0);
        this._refreshWheelStatus();
        this._getRewardStep4();

    },

    /**
     * 創獲獎畫面第四步驟：有光束從轉盤處跑到最大獎機率的顯示格子(約0.5秒)、標題顯示：最大獎中獎率提升
     * @private
     */
    _getRewardStep4: function () {
        var clawMachineInfo = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE);
        var wheelParam = clawMachineInfo.wheelData || {};

        if (this._isJackpot) {
            // 刷新機率、獎項
            this._refreshJackpotRate();
            this._refreshWheelStatus();

            var isLegalLv = wheelParam.level <= ClawMachineChallengeWheelNode.MAX_LEVEL && wheelParam.level > 0;
            if (isLegalLv && (this._nowLevel < wheelParam.level)) {
                // 未達最高級轉盤：顯示升級動畫
                this._upgradeWheel();
            } else {
                // 已達最高級轉盤：顯示一般畫面

                // 刷新獎項
                this._refreshWheelReward();

                // 顯示標題：已達最高級轉盤！快來拿大獎吧
                this._setTitleStatus(ClawMachineChallengeWheelNode.TITLE_STATUS.MAX_WHEEL);

                this.runAction(cc.sequence(
                    cc.delayTime(1),
                    cc.callFunc(() => this._endReward())
                ));
            }
        } else {
            // 有光束從轉盤處跑到最大獎機率的顯示格子
            var startPos = cc.p(200 + JSScreenBonusHalfWidth, JSVisibleSize.height - 188);
            var endPosArray = [this._jackpotRateBgPos, cc.pAdd(this._jackpotRateBgPos, cc.p(-25, 0))];

            // 粒子效果
            for (let i = 0; i < 2; i++) {
                var particle = new cc.ParticleSystem("Particle/particle_light.plist");
                particle.setPosition(startPos);
                particle.setAutoRemoveOnFinish(true);
                this.addChild(particle, 100);

                particle.runAction(cc.sequence(
                    cc.delayTime(i),
                    cc.moveTo(0.5, endPosArray[i]),
                    cc.fadeOut(0.2)
                ));
            }

            // 顯示標題：最大獎中獎率提升
            this._setTitleStatus(ClawMachineChallengeWheelNode.TITLE_STATUS.JACKPOT_RATE_UP);

            this.runAction(cc.sequence(
                cc.delayTime(2),
                cc.callFunc(() => {
                    this._titleSp.setVisible(false);
                    this._starSpArray.forEach(cur => cur.setVisible(false));
                    this._getRewardStep5();
                })
            ));
        }
    },

    /**
     * 創獲獎畫面第五步驟：顯示文案：最大獎XXX,XXX，XXX須千分位，顯示當前大獎數字、最大獎機率動畫：有多個上升箭頭，往上移動消失
     * @private
     */
    _getRewardStep5: function () {
        var clawMachineInfo = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE);
        var wheelParam = clawMachineInfo.wheelData || {};

        // 顯示標題：最大獎
        this._setTitleStatus(ClawMachineChallengeWheelNode.TITLE_STATUS.SHOW_JACKPOT);

        // 顯示最大獎金額
        this._numberSp.setNumber(wheelParam.maxReward);
        this._jackpotAutoLayoutNode.refresh();
        this._jackpotAutoLayoutNode.setVisible(true);

        // 箭頭&判定
        this.runAction(cc.sequence(
            cc.callFunc(() => {
                if (!this._isJackpot)
                    this._playArrowAni();
            }),
            cc.delayTime(4),
            cc.callFunc(() => {
                this._endReward();
            })
        ));
    },

    /**
     * 結束轉盤的得獎動畫後做的事
     * @private
     */
    _endReward: function () {
        var clawMachineInfo = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE);
        var wheelParam = clawMachineInfo.wheelData || {};

        // 顯示標題：最大獎
        this._setTitleStatus(ClawMachineChallengeWheelNode.TITLE_STATUS.SHOW_JACKPOT);

        // 顯示最大獎金額
        this._numberSp.setNumber(wheelParam.maxReward);
        this._jackpotAutoLayoutNode.refresh();
        this._jackpotAutoLayoutNode.setVisible(true);

        // 記下現在等級
        this._nowLevel = wheelParam.level;

        // 刷新旋轉按鈕文字
        this._spinBtn.label.setString(JSStringUtility.format("(%s)", clawMachineInfo.getWheelRewardCount));

        // 通知儲值整合視窗轉完了 時間如果到了就可以關畫面了
        this.isSpining = false;
        GS.dispatchCustomEvent("NotifyPurchaseTriggerIntegrationIsWheelSpin", false);

        // 判定還有沒有次數
        if (clawMachineInfo.getWheelRewardCount > 0) {
            // 恢復旋轉按鈕
            this._spinBtn.setEnabled(true);
            this._spinBtnAni && this._spinBtnAni.setAnimation(0, "ani_06", true);

            // 按鈕文字動畫
            this._spinBtn.label.runAction(cc.sequence(
                cc.scaleTo(0.3, 1.1),
                cc.scaleTo(0.1333, 0.92),
                cc.scaleTo(0.0667, 1.03),
                cc.scaleTo(0.0667, 0.97),
                cc.scaleTo(0.0666, 1.01),
                cc.scaleTo(0.0667, 1)
            ));

            // 刷新轉盤狀態
            this._refreshWheelStatus();
        } else {
            // 沒有次數了，演轉盤結束動畫
            this._runWheelBackAnimate();
        }
    },

    /**
     * 播放中小獎後 大獎機率提升的箭頭動畫
     * @private
     */
    _playArrowAni: function () {
        [cc.p(-43, 1), cc.p(-14, 24), cc.p(43, 3)].forEach((cur, index) => {
            var arrowSp = new cc.Sprite("#clawMachineChallenge_pic_arrow.png");
            arrowSp.setPosition(cc.pAdd(cur, this._jackpotRateBgPos));
            arrowSp.setOpacity(0);
            this.addChild(arrowSp);

            arrowSp.runAction(cc.sequence(
                cc.delayTime(index * 0.5),
                cc.sequence(
                    cc.spawn(
                        cc.fadeIn(0.2),
                        cc.moveBy(0.5, cc.p(0, 10))
                    ),
                    cc.spawn(
                        cc.fadeOut(0.2),
                        cc.moveBy(0.5, cc.p(0, 10))
                    ),
                    cc.moveBy(0, cc.p(0, -20)),
                    cc.callFunc(() => {
                        // 刷新機率
                        this._refreshJackpotRate();
                    }),
                    cc.delayTime(0.5)).repeat(2),
                cc.removeSelf()
            ));
        });
    },

    /**
     * 升級轉盤
     * @private
     */
    _upgradeWheel: function () {
        var clawMachineInfo = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE);
        var wheelParam = clawMachineInfo.wheelData || {};

        // 顯示標題：恭喜轉盤升級至X等
        this._setTitleStatus(ClawMachineChallengeWheelNode.TITLE_STATUS.WHEEL_UPGRADE);

        // 放等級-X的node
        var levelNode = this._levelNode = new cc.Node();
        levelNode.setPosition(256 + JSScreenBonusHalfWidth, JSVisibleSize.height - 48);
        this.addChild(levelNode);
        var levelSp = new cc.Sprite("#clawMachineChallenge_word_level.png");
        levelSp.setPositionX(-14);
        levelSp.setScale(0.65);
        levelNode.addChild(levelSp);
        var dashSp = new cc.Sprite("#clawMachineChallenge_word_-.png");
        dashSp.setPositionX(24);
        dashSp.setScale(0.65);
        levelNode.addChild(dashSp);
        var numberSp = new cc.Sprite(JSStringUtility.format("#num_26_%s.png", wheelParam.level));
        numberSp.setPosition(38, 2);
        numberSp.setScale(0.65);
        levelNode.addChild(numberSp);


        // 轉盤後面的光
        this._playSkeletonAni(ClawMachineChallengeWheelNode.SPINE_ANI_NUMBER.UPGRADE_BACK_LIGHT, this._wheelBgAniNode, this._bigWheelMidPoint, false);

        // 轉盤前面的光
        this._playSkeletonAni(ClawMachineChallengeWheelNode.SPINE_ANI_NUMBER.UPGRADE_FRONT_LIGHT, this._wholeWheelNode, cc.p(0, 0), false);

        // 背景換色
        var needChangeSpArray = [{nodes: this._bgSpArray, pic: "clawMachineChallenge_bg_0%s.png", size: JSVisibleSize},
            {nodes: this._bgLightSpArray, pic: "clawMachineChallenge_bg_top_light_0%s.png"},
            {
                nodes: this._jackpotRateBgArray,
                pic: "clawMachineChallenge_bg_jackpot_0%s.png",
                size: cc.size(127, 72)
            },
            {nodes: this._wheelFrameSpriteArray[0], pic: "clawMachineChallenge_pic_wheel_frame_0%s.png"},
            {nodes: this._wheelFrameSpriteArray[1], pic: "clawMachineChallenge_pic_wheel_frame_0%s.png"}];

        needChangeSpArray.forEach(cur => {
            cur.nodes[0].runAction(cc.fadeOut(0.5));
            cur.nodes[1].setSpriteFrame(JSStringUtility.format(cur.pic, wheelParam.level));
            cur.size && cur.nodes[1].setPreferredSize(cur.size);
            cur.nodes[1].runAction(cc.sequence(
                cc.fadeIn(0.5),
                cc.delayTime(2),
                cc.callFunc(() => {
                    cur.nodes[0].setSpriteFrame(JSStringUtility.format(cur.pic, wheelParam.level));
                    cur.size && cur.nodes[0].setPreferredSize(cur.size);
                    cur.nodes[0].setOpacity(255);
                    cur.nodes[1].setOpacity(0);
                })
            ));
        });

        // 金幣動畫
        this._runCoinAnimation();

        // 轉盤縮放
        this._wholeWheelNode.runAction(cc.sequence(
            cc.delayTime(0.8),
            cc.scaleTo(0.2, 1.09),
            cc.scaleTo(0.2, 0.92),
            cc.scaleTo(0.2, 1.03),
            cc.scaleTo(0.2, 0.97),
            cc.scaleTo(0.2, 1.01),
            cc.scaleTo(0.2, 1),
            cc.callFunc(() => {
                // 刷新獎項
                this._refreshWheelReward();

                // 刷中獎框
                this._playSkeletonAni(ClawMachineChallengeWheelNode.SPINE_ANI_NUMBER.JACKPOT_FRAME_SHINING, this._wholeWheelNode, cc.p(0, 69.5), false);
            }),
            cc.delayTime(2),
            cc.callFunc(() => {
                // 拿掉升級文字
                if (this._levelNode) {
                    this._levelNode.removeFromParent();
                    this._levelNode = undefined;
                }

                // 結束得獎做的事
                this._endReward();
            })
        ));
    },

    // 轉盤 啟動!
    _wheelSpin: function () {
        // 隱藏標題、大獎數字
        this._titleSp.setVisible(false);
        this._starSpArray.forEach(cur => {
            cur.setVisible(false);
        });
        this._jackpotAutoLayoutNode.setVisible(false);

        // 顯示跳過按鈕
        this._skipBtn.setVisible(true);

        // 先算旋轉角度
        var angle = (24 - this._rewardIndex + 8 * Math.floor(Math.random() * 2)) * 45;

        // 旋轉轉盤
        var time = 2;
        this._wheelNode.runAction(cc.sequence(
            cc.rotateBy(time, angle).easing(cc.easeQuarticActionOut()),
            cc.callFunc(() => {
                // 轉完做的事
                this._wheelEndRotate();
            })
        ));
    },

    // 轉盤轉完時做的事
    _wheelEndRotate: function () {
        // 把按鈕隱藏
        this._skipBtn.setVisible(false);

        this._getRewardStep1();
    },

    /**
     * 噴錢動畫 (從中間產生噴到獎勵視窗的德撲幣上)
     * @private
     */
    _runCoinAnimation: function () {
        this._coinTimes = 0;
        var coinCount = 5;
        for (var i = 0; i < coinCount; i++) {
            var startPos = cc.p(76 + JSScreenBonusHalfWidth, JSVisibleSize.height + 12);
            var targetPos = cc.p(213 + JSScreenBonusHalfWidth, JSVisibleSize.height - 93);

            var coinSp = new cc.Sprite("#clawMachineChallenge_pic_coin.png");
            coinSp.setPosition(startPos);
            coinSp.setScale(0);
            this.addChild(coinSp);

            var scale = cc.scaleTo(0.2, 0.6);
            var moveTo = cc.moveTo(0.2, targetPos);
            var spawn = cc.spawn(moveTo, scale);
            var fadeOut = cc.fadeOut(0.25);
            var delay = cc.delayTime(0.08 * (i + 1));
            var callCheck = cc.callFunc(() => {
                this._coinTimes++;
                if (this._coinTimes === coinCount) {
                    // 金幣動畫跑完 刷新大獎金額
                    this._refreshWheelReward();
                }
            }, this);
            var removeCoin = cc.removeSelf();
            var seq = cc.sequence(delay, spawn, fadeOut, callCheck, removeCoin);
            coinSp.runAction(seq);
        }
    },

    /**
     * 加一個防呆server沒回的動畫
     */
    _addTimeOutAnimation: function () {
        // 防呆15秒server沒回的話關掉畫面
        var action = cc.sequence(
            cc.delayTime(15),
            cc.callFunc(() => {
                // 拿掉loading
                this._setIsLoading(false);

                // 砍掉說明dialog
                var dialog = DialogManager.getDialogByKey("WebViewDialog");
                if (dialog) {
                    dialog.closeDialogAnimation();
                }

                // 跳忙碌中dialog
                var dialog = new Dialog({
                    content: LocalizedString.Common("目前系統忙碌中\n請稍後再試"),
                    closeButton: 0,
                    callback: () => {
                        this._pageLayerPtr.closeDialogAnimation();
                    }
                });
                dialog.startDialogAnimation();
                this.addChild(dialog, 10000);
            })
        );
        action.setTag(9487);
        this.runAction(action);
    },

    /**
     * 按鈕
     */

    // 旋轉按鈕
    _spinBtnClicked: function () {
        var clawMachineInfo = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE);

        // 壓loading
        this._setIsLoading(true);

        // 點完就鎖住不能再點
        this._spinBtn.setEnabled(false);

        // 刷新旋轉按鈕文字
        this._spinBtn.label.setString(JSStringUtility.format("(%s)", clawMachineInfo.getWheelRewardCount - 1));

        // 停止動畫
        this._spinBtnAni && this._spinBtnAni.setAnimation(0, "ani_08", false);
        this._spinBtn.label.stopAllActions();

        // 防卡死
        this._addTimeOutAnimation();

        // 送通知給server
        DataProcess.sendString("claw_machine_challenge_wheel_reward");

        // 通知儲值整合視窗現在要轉了 時間到先不要關閉
        this.isSpining = true;
        GS.dispatchCustomEvent("NotifyPurchaseTriggerIntegrationIsWheelSpin", true);

        // 5.6.0埋點 點擊旋轉按鈕
        DataModal.purchaseTriggerIntegrationData.sendClawMachineChallengeUserAnalyticsTrack(3085);
    },

    // 跳過按鈕
    _skipBtnClicked: function () {
        this._wheelNode.stopAllActions();
        this._wheelNode.setRotation((8 - this._rewardIndex) * 45);
        this._wheelEndRotate();

        // 5.6.0埋點 點擊跳過按鈕
        DataModal.purchaseTriggerIntegrationData.sendClawMachineChallengeUserAnalyticsTrack(3086);
    },

    /**
     * 以下通知
     */

    // 收到通知開始轉轉盤
    notifyClawMachineChallengeWheelGetReward: function (event) {
        // 拿掉loading
        this._setIsLoading(false);

        // 拿掉防卡死
        this.stopActionByTag(9487);

        var param = event && event.getUserData();
        if (param.isSuccess) {
            // 記下轉完的角度、是否為大獎
            this._rewardIndex = param.rewardIndex;
            this._isJackpot = param.rewardIndex === 0;

            // 轉盤
            this._wheelSpin();
        } else {
            DialogManager.addDialog(new Dialog({
                title: LocalizedString.Common("提醒"),
                content: LocalizedString.Common("系統忙碌中，請稍後再試！"),
                buttons: [LocalizedString.Common("確認")],
                closeButton: false,
                callback: () => {
                    var dialog = DialogManager.getDialogByKey("PurchaseTriggerIntegrationDialog");
                    dialog && dialog.closeDialogAnimation();
                }
            }), false);
        }
    }

});

ClawMachineChallengeWheelNode.MAX_LEVEL = 3;

ClawMachineChallengeWheelNode.SPINE_ANI_NUMBER = {
    UPGRADE_BACK_LIGHT: 1,      // 轉盤升級光芒效果(轉盤後的光芒)
    UPGRADE_FRONT_LIGHT: 2,     // 轉盤升級光芒效果(轉盤前的光芒)
    JACKPOT_FRAME_SHINING: 3,   // 最大獎格子刷光+框放大
    JACKPOT_COIN: 4,            // 獲得大獎_噴金幣
    PROCESSING_FULL_LIGHT: 5,   // 進度條集滿時光芒效果
    CAN_SPIN_SCALE_AND_LIGHT: 6 // 可以旋轉時的按鈕動畫
};

// 標題圖片狀態 對應圖片檔名
ClawMachineChallengeWheelNode.TITLE_STATUS = {
    SHOW_JACKPOT: 2,        // 最大獎
    WHEEL_UPGRADE: 3,       // 恭喜轉盤升級至
    JACKPOT_RATE_UP: 4,     // 最大獎率提升！
    MAX_WHEEL: 5,           // 已達最高級轉盤!快來拿大獎吧
};