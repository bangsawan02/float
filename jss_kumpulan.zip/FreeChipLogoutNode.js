var FreeChipLogoutNode = cc.ControlButton.extend({
    ctor: function (type) {
        this._super();

        this._type = type;

        var btnSize = cc.size(74, 70);
        var node = this._mainNode = new ccui.Scale9Sprite();
        node.setCascadeColorEnabled(true);
        node.setCascadeOpacityEnabled(true);
        node.setContentSize(btnSize);

        // 底圖
        var bgSprite = new ccui.Scale9Sprite("lobby_pic_frame_02.png");
        bgSprite.setPreferredSize(btnSize);
        bgSprite.setOpacity(200);
        bgSprite.setPosition(37, 35);
        node.addChild(bgSprite);

        // 按鈕圖
        var btnSprite = new ccui.Scale9Sprite("lobby_btn_01.png");
        btnSprite.setPreferredSize(cc.size(54, 20));
        btnSprite.setPosition(37, 3);
        node.addChild(btnSprite);

        // 領取文字
        var wordSprite = new cc.Sprite("#lobby_word_ambil.png");
        wordSprite.setPosition(37, 3);
        node.addChild(wordSprite);

        // 檢查是否有需要先載入的資源
        var loadFileArray = this._loadFileArray = this._getItemLoadResource(type);
        // 更新icon的Function
        var addIconSp = (type) => {
            // 讀取Plist
            if (loadFileArray) {
                cc.spriteFrameCache.addSpriteFrames(loadFileArray[0], loadFileArray[1]);

                this._loadFileDone = true;
            }

            // icon
            var param = this._getItemIconParam(type);
            if (param.iconName) {
                var iconSp = new cc.Sprite(param.iconName);
                iconSp.setPosition(37, 35);
                iconSp.setScale(param.iconScale);
                node.addChild(iconSp);
            }
            // 沒有iconName要用客製化的
            else {
                var iconNode = this._getItemIconNode(type);
                if (iconNode) {
                    iconNode.setPosition(37, 35);
                    node.addChild(iconNode);
                }
            }
        };

        if (!loadFileArray || cc.sys.isNative || cc.textureCache.getTextureForKey(loadFileArray[1])) {
            addIconSp(type);
        } else {
            // H5要先Loader
            cc.loader.load(loadFileArray, function () {
                addIconSp(type);
            });
        }

        // 自己的設定
        this.setPreferredSize(btnSize);         // 一定要加這行 Native才會是對的
        this.setBackgroundSpriteForState(node, cc.CONTROL_STATE_NORMAL);
        this.addTargetWithActionForControlEvents(this, this._buttonClicked,
            cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
            cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
            cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
        this.setAdjustBackgroundImage(false);
        this.setZoomOnTouchDown(false);
        this.setSwallowTouches(false);
        this.setTouchDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
    },

    onExit: function () {
        if (this._loadFileDone) {
            cc.spriteFrameCache.removeSpriteFramesFromFile(this._loadFileArray[0]);
        }

        this._super();
    },

    // 取得項目的icon資料
    _getItemIconParam: function (type) {
        var param = {iconScale: 1.2};

        switch (type) {
            case FreeChipListType.DAILY_MISSION:
                param.iconName = "#lobby_icon_daily_mission.png";
                break;

            case FreeChipListType.DAILY_LOGIN:
                param.iconName = "#lobby_icon_daily_login.png";
                break;

            case FreeChipListType.VIDEO_AD:
                param.iconName = "#lobby_vad_icon.png";
                break;

            case FreeChipListType.QUESTIONNAIREL:
                param.iconName = "#lobby_icon_questionnairel.png";
                break;

            case FreeChipListType.GUILD_SURPRISE:
                param.iconName = "#lobby_icon_guild_surprise.png";
                break;

            case FreeChipListType.SERIAL_PRIZE:
                param.iconName = "#lobby_icon_serialCode.png";
                break;

            case FreeChipListType.JOIN_GUILD:
                param.iconName = "#lobby_icon_joinGuild.png";
                break;

            case FreeChipListType.GAME_RANK:
                param.iconName = "#gameRank_icon.png";
                break;

            case FreeChipListType.GROWING_MISSION:
                param.iconName = "#lobby_icon_growing_mission.png";
                break;

            case FreeChipListType.DAILY_LUCKY_WHEEL:
                param.iconName = "#lobby_icon_daily_lucky_wheel.png";
                param.iconScale = 1;
                break;

            case FreeChipListType.VEGAS_RACING:
                param.iconName = "#vegasRacing_icon.png";
                param.iconScale = 0.8;
                break;

            case FreeChipListType.VEGAS_NEWBIE_MISSION:
                param.iconName = "#lobby_icon_newbie_mission.png";
                break;

            case FreeChipListType.NEWBIE_LEVEL_GIFT:
                param.iconName = "#lobby_icon_levelUp.png";
                break;

            case FreeChipListType.LOGIN_REWARD:
                param.iconName = "#lobby_icon_login.png";
                break;

            case FreeChipListType.CLAW_MACHINE:
                param.iconName = "#lobby_icon_clawCoin.png";
                param.iconScale = 1.5;
                break;
        }

        return param;
    },

    // 取得各項目的icon node
    _getItemIconNode: function (type) {
        var node = new cc.Node();
        node.setCascadeColorEnabled(true);
        node.setCascadeOpacityEnabled(true);

        // 機台編號
        var machineType = undefined;

        switch (type) {
            case FreeChipListType.DICE_BO:
                machineType = LobbySelectGameSetting.GameType.DiceBo;
                break;
            case FreeChipListType.BLACK_JACK:
                machineType = LobbySelectGameSetting.GameType.Blackjack;
                break;
            case FreeChipListType.MULTI_DICE_BO:
                machineType = LobbySelectGameSetting.GameType.MultiDiceBo;
                break;
            case FreeChipListType.MULTI_BLACK_JACK:
                machineType = LobbySelectGameSetting.GameType.MultiBlackjack;
                break;
            case FreeChipListType.MULTI_HOOHEYHOW:
                machineType = LobbySelectGameSetting.GameType.MultiHooHeyHow;
                break;
        }

        // 是娛樂城機台
        if (machineType) {
            // 機台畫面
            var gameNode = new LobbySelectGameNode({
                serverType: machineType,
                isBig: false
            });
            gameNode.setScale(0.5);

            return gameNode;
        }

        return node;
    },

    // 取得項目需要先載入的資源
    _getItemLoadResource: function (type) {
        switch (type) {
            case FreeChipListType.VIDEO_AD:
                return ["lobby/lobby_video_ad.plist", "lobby/lobby_video_ad.png"];

            case FreeChipListType.GAME_RANK:
                return ["rank/gameRank.plist", "rank/gameRank.png"];

            case FreeChipListType.VEGAS_RACING:
                return ["vegas/vegasRacing/vegas_racing.plist", "vegas/vegasRacing/vegas_racing.png"];

            default:
                return undefined;
        }
    },

    // 點擊按鈕
    _buttonClicked: function (sender, type) {
        if (type === cc.CONTROL_EVENT_TOUCH_UP_INSIDE) {
            DialogManager.closeDialogByKey("FreeChipLogoutDialog");

            switch (this._type) {
                case FreeChipListType.DAILY_MISSION:
                    // 開每日任務dialog
                    DialogManager.addDialog(new ActionListDialog(0, DailyMissionEnum.whereType.Lobby));
                    break;

                case FreeChipListType.DAILY_LOGIN:
                    // 開每日簽到dialog
                    DialogManager.addDialog(new SignInDialog());
                    break;

                case FreeChipListType.VIDEO_AD:
                    // 開常駐廣告dialog
                    DialogManager.addDialog(new VideoADDialog());
                    break;

                case FreeChipListType.QUESTIONNAIREL:
                    // 開啟問卷
                    var questParam = DataModal.lobbyActionData.questParam;
                    var questName = questParam.name || "";
                    var questUrl = questParam.url;

                    // url如果沒值就不做事
                    if (!questUrl)
                        break;

                    var title = questName.replace("\n", " ");
                    var nextLayer = new LobbyWebViewLayer(title, GS.transferDomain(questUrl));
                    nextLayer.viewDidDisappear = function () {
                        // 要送拿reward的指令
                        DataProcess.sendString("questionnairel_getReward");
                    };
                    PushScene.pushLayer(nextLayer);
                    break;

                case FreeChipListType.JOIN_GUILD:
                case FreeChipListType.GUILD_SURPRISE:
                    PushScene.pushLayer(new GuildLayer());
                    break;

                case FreeChipListType.SERIAL_PRIZE:
                    DialogManager.addDialog(new SerialNumberPrizeDialog());
                    break;

                case FreeChipListType.DICE_BO:
                    PushLayerHelper.pushLayer("", LobbyBannerMode.DiceBo);
                    break;

                case FreeChipListType.BLACK_JACK:
                    PushLayerHelper.pushLayer("", LobbyBannerMode.Blackjack);
                    break;

                case FreeChipListType.MULTI_DICE_BO:
                    PushLayerHelper.pushLayer("", LobbyBannerMode.MultiDiceBo);
                    break;

                case FreeChipListType.MULTI_BLACK_JACK:
                    PushLayerHelper.pushLayer("", LobbyBannerMode.MultiBlackjack);
                    break;

                case FreeChipListType.MULTI_HOOHEYHOW:
                    PushLayerHelper.pushLayer("", LobbyBannerMode.MultiHooHeyHow);
                    break;

                case FreeChipListType.GROWING_MISSION:
                    PushScene.pushLayer(new GrowingMissionLayer());
                    break;

                case FreeChipListType.DAILY_LUCKY_WHEEL:
                    // 按到每日輪盤 因為視窗要從特定位置跳 所以丟Notify出去
                    // 紀錄今日點過了
                    // 比照 FreeChipListNode作法
                    GS.localStorage.setItem(DataModal.dailyLuckyWheelData.getIconClickKey(), "1");
                    GS.dispatchCustomEvent("NotifyShowDailyLuckyWheelDialog");
                    break;

                case FreeChipListType.VEGAS_RACING:
                    PushLayerHelper.pushLayer("", LobbyBannerMode.VegasRacing);
                    break;

                case FreeChipListType.NEWBIE_LEVEL_GIFT:
                    // 因為視窗要從特定位置跳 所以丟Notify出去
                    GS.dispatchCustomEvent("NotifyShowNewbieLevelGift");
                    break;

                case FreeChipListType.LOGIN_REWARD:
                    // 埋點 1:點擊大廳Free chip 中icon
                    DataProcess.sendString("track_period_login_bonus 1");
                    DialogManager.addLobbyDialog(new FreeChipLoginRewardDialog());
                    break;

                case FreeChipListType.VEGAS_NEWBIE_MISSION:
                    DialogManager.addDialog(new VegasNewbieMissionDialog(), true, true);
                    break;

                case FreeChipListType.CLAW_MACHINE:
                    // 52: 夾娃娃機Dialog
                    DataProcess.sendString("track_claw_machine_challenge 12");
                    DialogManager.addLobbyDialog(new PurchaseTriggerIntegrationDialog(PurchaseTriggerIntegrationData.purchaseType.CLAW_MACHINE_CHALLENGE));

                    // 5.6.0 點擊離開前提示裡的夾娃娃icon
                    TexasUtility.sendUserAnalyticsTrack(3078);
                    break;

                default:
                    break;
            }

            // 埋點 點按鈕就送
            DataProcess.sendString("track_logout_notice_click 1");

            // 5.6.0埋點 點擊引導按鈕
            TexasUtility.sendUserAnalyticsTrack(3071);
        }

        // 設定按到的顏色
        var isTouched = (type === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || type === cc.CONTROL_EVENT_TOUCH_DOWN);
        this._mainNode.setColor(isTouched ? JSColor.GRAY : JSColor.WHITE);
    }
});