/**
 * 每日任務 VIP獎勵加成說明頁
 */

var DailyMissionVIPBonusDialog = BaseDialogLayer.extend({
    ctor: function () {
        this._super();

        // 先設定此Dialog的Key 之後容易砍
        this.key = "DailyMissionVIPBonusDialog";

        var aniLayer = this._animationLayer;
        var freeChipString = LocalizedString.FreeChip;

        // 背景
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(cc.size(390, 190));
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite);

        // 獎勵加成倍數算法描述
        var descriptionString = ["#!FFFFFF!#獎勵加成倍數算法：", "#!FFFF33!#● 任務德撲幣獎勵 x VIP加成倍數 = 獲得的最終獎勵。", "#!FFFFFF!#● 加成僅適用在每日任務的德撲幣獎勵中，下方寶箱獎勵", "#!FFFFFF!#● VIP加成獎勵"];

        // 排版用的node
        var autoLayoutNode = new GSAutoLayoutNode();
        autoLayoutNode.setAnchorPoint(0, 1);
        autoLayoutNode.setPosition(106 + JSScreenBonusHalfWidth, 220 + JSScreenBonusHalfHeight);
        autoLayoutNode.setType(GSAutoLayout.TYPE.VERTICAL_LEFT);
        aniLayer.addChild(autoLayoutNode);

        descriptionString.forEach(cur => {
            var label = new GSRichTextNode(freeChipString(cur), JSFontName, 12);
            autoLayoutNode.addChild(label);
        });

        // 加成文字
        var data = DataModal.vipData.vipInfo["vip_dailyMission_discount_info"];
        if (data && data.dailyMissionBonus) {
            var array = [];
            data.dailyMissionBonus.forEach(cur => {
                if (cur.length === 2) {
                    var title = JSCodeUtility.getStringValue(cur[0]);
                    var bonus = JSCodeUtility.getStringValue(cur[1]);
                    array.push([title, JSStringUtility.format("+%s%%", bonus)]);
                }
            });

            if (array.length) {
                array.unshift([freeChipString("會員\n等級"), freeChipString("加成倍數")]);

                // 表格上半部紅色背景
                var redBgSprite = new ccui.Scale9Sprite("vip_bg_pink.png");
                redBgSprite.setPreferredSize(cc.size(360, 40));
                redBgSprite.setPosition(257 + JSScreenBonusHalfWidth, 124 + JSScreenBonusHalfHeight);
                aniLayer.addChild(redBgSprite);

                // 表格下半部白色背景
                var whiteBgSprite = new ccui.Scale9Sprite("vip_bg_white.png");
                whiteBgSprite.setPreferredSize(cc.size(360, 40));
                whiteBgSprite.setPosition(257 + JSScreenBonusHalfWidth, 86 + JSScreenBonusHalfHeight);
                aniLayer.addChild(whiteBgSprite);

                // scroll view
                var scrollViewSize = cc.size(350, 74);
                var scrollLayer = new cc.Layer();
                var scrollView = new cc.ScrollView(scrollViewSize, scrollLayer);
                scrollView.setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
                scrollView.setPosition(82 + JSScreenBonusHalfWidth, 73 + JSScreenBonusHalfHeight);
                aniLayer.addChild(scrollView);
            }

            var totalWidth = 0;
            array.forEach((cur, index) => {
                var isFirst = index === 0;
                var fontSize = isFirst ? 10 : 14;
                var width = isFirst ? 60 : 48;
                var centerX = totalWidth + width / 2;

                // 會員等級
                var levelLabel = new cc.LabelTTF(cur[0], JSFontName, fontSize);
                levelLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                levelLabel.setPosition(centerX, 50);
                scrollLayer.addChild(levelLabel);

                // 線條
                var lineSprite = new ccui.Scale9Sprite("btn_function_line.png");
                lineSprite.setPosition(totalWidth + width, 50);
                lineSprite.setPreferredSize(cc.size(1, 23));
                scrollLayer.addChild(lineSprite);

                // 倍數
                var ratioLabel = new cc.LabelTTF(JSStringUtility.format("%s", cur[1]), JSFontName, fontSize);
                ratioLabel.setFontFillColor(JSColor.BLACK);
                ratioLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                ratioLabel.setPosition(centerX, 13);
                scrollLayer.addChild(ratioLabel);

                if (isFirst) {
                    // 線條
                    var lineSprite = new ccui.Scale9Sprite("btn_function_line.png");
                    lineSprite.setPosition(totalWidth + width, 50);
                    lineSprite.setPreferredSize(cc.size(1, 23));
                    scrollLayer.addChild(lineSprite);
                } else {
                    // 灰背景
                    var grayBgSprite = new ccui.Scale9Sprite("vip_bg_green.png");
                    grayBgSprite.setPreferredSize(cc.size(46, 26));
                    grayBgSprite.setPosition(ratioLabel.getPosition());
                    grayBgSprite.setOpacity(40);
                    scrollLayer.addChild(grayBgSprite);
                }
                totalWidth += width;
            });

            scrollView && scrollView.setContentSize(cc.size(totalWidth, scrollViewSize.height));
        }

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.addTouchUpInsideAction(this._closeDialogAnimation, this);
        closeBtn.setPosition(446 + JSScreenBonusHalfWidth, 234 + JSScreenBonusHalfHeight);
        aniLayer.addChild(closeBtn);
    }
});