/**
 * 通行證 - 獲獎 dialog
 * ```
 * config: {
 *     messageDialogBgFileName: "",             // dialog 背景
 *     getRewardDialogContentBgFileName: "",    // 獎勵列表背景
 *     getRewardDialogContentOpacity: 255,      // 獎勵列表背景透明度
 *     getRewardDialogTitleFileName: "",        // 標題圖檔
 * }
 * ```
 * @param {Object} config 設定
 * @param {String} config.messageDialogBgFileName dialog 背景
 * @param {String} config.getRewardDialogContentBgFileName 獎勵列表背景
 * @param {Number} config.getRewardDialogContentOpacity 獎勵列表背景透明度
 * @param {String} config.getRewardDialogTitleFileName 標題圖檔
 * @param {String[]} msgArray 獎勵列表
 */
var BasePassGetRewardDialog = BaseEventDialog.extend({
    ctor: function (config, msgArray) {
        this._super();
        this._config = config;
        this._msgArray = msgArray;

        this.key = "BasePassGetRewardDialog";

        this.loadFileArray = config.loadFileArray || [];
    },

    loadFileDone: function () {
        this._super();
        this.setLoadingSprite(false, false);

        let config = this._config;
        let msgArray = this._msgArray;
        let bgFileName = config.messageDialogBgFileName || "luxyPass_bg_frame.png";
        let contentBgFileName = config.getRewardDialogContentBgFileName || "luxyPass_pic_frame_07.png";
        let contentBgOpacity = config.getRewardDialogContentOpacity || 127;
        let titleFileName = config.getRewardDialogTitleFileName || "luxyPass_word_title_04.png";
        let animationLayer = this._animationLayer;

        // 背景
        let bgSprite = new ccui.Scale9Sprite(bgFileName);
        bgSprite.setPreferredSize(cc.size(244, 170));
        bgSprite.setPosition(JSScreenMidPos);
        animationLayer.addChild(bgSprite);

        // 文字底
        let contentBgSprite = new ccui.Scale9Sprite(contentBgFileName);
        contentBgSprite.setPreferredSize(cc.size(196, 76));
        contentBgSprite.setOpacity(contentBgOpacity);
        contentBgSprite.setPosition(JSScreenMidPos.x, 152 + JSScreenBonusHalfHeight);
        animationLayer.addChild(contentBgSprite);

        // 標題圖片
        let titleSprite = new cc.Sprite("#" + titleFileName);
        titleSprite.setPosition(JSScreenMidPos.x, 222 + JSScreenBonusHalfHeight);
        animationLayer.addChild(titleSprite);

        // 大片的彩帶
        for (let i = 0; i < 2; i++) {
            let ribbonSprite = new cc.Sprite("#luxyPass_pic_papperflower_01.png");
            ribbonSprite.setPosition(JSScreenMidPos.x - 156 + 312 * i, JSScreenMidPos.y + 54.5);
            ribbonSprite.setFlippedX(i === 1);
            animationLayer.addChild(ribbonSprite);
        }

        // 小片的彩帶
        [cc.p(160.5, -14), cc.p(137, -40.5), cc.p(-156, -60), cc.p(-160.5, -14), cc.p(-137, -40.5), cc.p(156, -60)].forEach((cur, index) => {
            let smallRibbonSprite = new cc.Sprite("#luxyPass_pic_papperflower_0" + (index % 3 + 2) + ".png");
            smallRibbonSprite.setPosition(cc.pAdd(JSScreenMidPos, cur));
            smallRibbonSprite.setFlippedX(Math.floor(index / 3) === 1);
            animationLayer.addChild(smallRibbonSprite);
        });

        // 按鈕
        let okBtnStyle = config.isUseOldBtnStyle ? Texas_Button.Style.COMMON_GREEN : Texas_Button.Style.GREEN;
        let okButton = this._okButton = new Texas_Button(okBtnStyle, cc.size(100, 32), "OK");
        okButton.addTouchUpInsideAction(this._closeDialogAnimation, this);
        okButton.setPosition(JSScreenMidPos.x, 90 + JSScreenBonusHalfHeight);
        animationLayer.addChild(okButton);

        this._createScrollView(msgArray);
    },

    /**
     * 建立獎勵 ScrollView
     * @param {String[]} msgArray 獎勵列表
     */
    _createScrollView: function (msgArray) {
        let bgSize = cc.size(196, 76);
        let aniLayer = this._animationLayer;

        // 只有一個獎勵
        if (msgArray.length === 1) {
            let messageLabel = new cc.LabelTTF(msgArray[0], JSFontName, 11, cc.size(bgSize.width - 44, 0));
            messageLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            messageLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 9);
            aniLayer.addChild(messageLabel);
        } else {
            // 隱藏確認按鈕
            this._okButton.setVisible(false);

            // 加ScrollView
            let scrollViewSize = cc.size(bgSize.width - 40, bgSize.height - 20);
            let mainLayer = new cc.Layer();
            let scrollView = new cc.ScrollView(scrollViewSize, mainLayer);
            scrollView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
            scrollView.setPosition(JSScreenMidPos.x - 3 - scrollViewSize.width / 2, JSScreenMidPos.y + 9 - scrollViewSize.height / 2);
            aniLayer.addChild(scrollView);

            // 文字排版的node
            let layoutNode = new GSAutoLayoutNode();
            layoutNode.setType(GSAutoLayout.TYPE.VERTICAL);
            layoutNode.setAnchorPoint(0, 0);
            mainLayer.addChild(layoutNode);

            // 創文字
            let totalHeight = 0;
            let delayTime = 0.05;
            msgArray.forEach(cur => {
                // 內文
                let messageLabel = new cc.LabelTTF(cur, JSFontName, 11, cc.size(scrollViewSize.width - 2, 0));
                messageLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                layoutNode.addChild(messageLabel);

                // 算高度
                totalHeight += messageLabel.getContentSize().height;
            });

            // 設置scrollView大小
            scrollView.setContentSize(scrollViewSize.width, totalHeight);

            // 先不讓他滑動
            scrollView.setTouchEnabled(false);

            // 先跑到最上面
            scrollView.setContentOffset(scrollView.minContainerOffset());

            // 動畫時間
            var animTime = 0.1;

            // 需要滾動
            if (scrollViewSize.height < totalHeight) {
                // 每個訊息出現時間
                animTime = msgArray.length * delayTime;

                layoutNode.getChildren().forEach((child, index) => {
                    // 先隱藏
                    child.setVisible(false);

                    // 在出現
                    child.runAction(cc.sequence(
                        cc.delayTime(index * (delayTime - 0.01)),
                        cc.show()
                    ));
                });

                // 再跑到最下面
                scrollView.setContentOffsetInDuration(scrollView.maxContainerOffset(), animTime);
            }

            // 等動畫完
            this.runAction(cc.sequence(
                cc.delayTime(animTime),
                cc.callFunc(() => {
                    // 可滑動
                    scrollView.setTouchEnabled(true);

                    // 顯示確認按鈕
                    this._okButton.setVisible(true);
                }))
            );
        }
    },

    // 給外部呼叫用
    getOkBtn: function () {
        return this._okButton;
    }
});