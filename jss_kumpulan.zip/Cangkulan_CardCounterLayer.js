/**
 * Cangkulan 計牌器
 */
var Cangkulan_CardCounterLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        this.addChild(menu);

        // 創出按鈕(開關計牌器)
        var iconSp = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_07.png", cc.size(40, 40), "#game_btn_cardCounter.png");
        var counterBtn = new cc.MenuItemSprite(iconSp[0], iconSp[1], iconSp[2], this._buttonClicked, this);
        counterBtn.setPosition(JSVisibleSize.width - 25 - JSScreenSafeWidth, JSVisibleSize.height - 45);
        counterBtn.setScale(0.8);
        menu.addChild(counterBtn);

        // 先創一個擺放計牌器畫面的Node
        var bgSize = cc.size(225, 110);
        var cardCounterNode = this._cardCounterNode = new cc.Node();
        cardCounterNode.setPosition(JSVisibleSize.width - bgSize.width - 45 - JSScreenSafeWidth, JSVisibleSize.height - bgSize.height);
        cardCounterNode.setVisible(false);
        this.addChild(cardCounterNode);

        // 創計牌器的底圖
        var bgSprite = new ccui.Scale9Sprite("cangkulan_menu_pop_01.png");
        bgSprite.setPreferredSize(bgSize);
        bgSprite.setAnchorPoint(0, 0);
        cardCounterNode.addChild(bgSprite);

        // 創計牌器箭號
        var arrowSp = new cc.Sprite("#cangkulan_menu_pop_02.png");
        arrowSp.setPosition(bgSize.width + 4, bgSize.height - 50);
        arrowSp.setAnchorPoint(0, 0.5);
        arrowSp.setScale(1.1);
        arrowSp.setRotation(-90);
        cardCounterNode.addChild(arrowSp);

        // 創黑色底線
        var lineSp = new cc.Sprite("#cangkulan_pic_line_01.png");
        lineSp.setScaleY(6);
        lineSp.setRotation(90);
        lineSp.setPosition(bgSize.width / 2, 20);
        cardCounterNode.addChild(lineSp, 1);

        var note = new cc.LabelTTF(LocalizedString.Game("*亮起來為可能拿到的牌"), JSFontName, 9);
        note.setPosition(bgSize.width / 2, 13);
        note.setAnchorPoint(0.5, 0.5);
        cardCounterNode.addChild(note);

        // 上方的牌顯示
        for (var i = 1; i < 5; i++) {
            var spName = JSStringUtility.format("#cangkulan_pic_suitLight_%d.png", i);
            var flowerSp = new cc.Sprite(spName);
            flowerSp.setPosition(18, bgSize.height - 20 * i + 5);
            cardCounterNode.addChild(flowerSp);
        }

        // 擺放數字文字Label
        this._counterLabelArray = [];

        // 棄牌區的牌
        this._foldCardNumber = "";
        // 排序位置 A KQJ 10 98765432
        var num = "";
        var posX = 0;
        var numWord = ["J", "Q", "K"];
        for (var f = 1; f < 5; f++) {
            var eachLine = [];
            for (var n = 1; n < 14; n++) {
                switch (n) {
                    case 1:
                        num = "A";
                        posX = 36;
                        break;
                    case 10:
                        num = "10";
                        posX = 94;
                        break;
                    case 11:
                    case 12:
                    case 13:
                        num = numWord[n - 11];
                        posX = 78 - (n - 11) * 14;
                        break;
                    default:
                        num = n;
                        posX = bgSize.width - n * 14 + 12;
                        break;
                }
                var cardNum = new cc.LabelTTF(num, JSFontName, 13, cc.size(0, 0), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
                cardNum.setPosition(posX, bgSize.height - 20 * f + 5);
                cardNum.setFontFillColor(cc.color(255, 255, 160));
                cardCounterNode.addChild(cardNum);
                eachLine.push(cardNum);
            }
            this._counterLabelArray.push(eachLine);
        }
    },

    // 清掉東西
    clean: function (isClose) {
        // 假如為true 就要關掉
        if (isClose)
            this._cardCounterNode.setVisible(false);

        // 清掉點數的文字
        this._counterLabelArray.forEach(array => {
            array.forEach(cur => {
                cur.setOpacity(255);
                cur.setFontFillColor(cc.color(255, 255, 160));
            });
        });
    },

    // 從cmd拿資料回來更新記牌器
    refreshCardCounterByDataArray: function (array) {
        this.clean();
        array && array.forEach(cur => {
            this.refreshCardCounterBySingleCard(cur, true);
        });
    },

    // 更新單張牌計牌器, card:什麼牌, isMarked:是否被標記(T:變暗/F:亮黃色)
    refreshCardCounterBySingleCard: function (card, isMarked) {
        if (!card)
            return;

        var param = this._switchCardNum(card);
        var counted = this._counterLabelArray[param.flower][param.num];
        if (isMarked) {
            counted.setOpacity(75);
            counted.setFontFillColor(cc.color(255, 255, 255));
        } else {
            counted.setOpacity(255);
            counted.setFontFillColor(cc.color(255, 255, 160));
        }
    },

    // 點到計牌器
    _buttonClicked: function (sender, event) {
        var isVisible = this._cardCounterNode.isVisible();
        this._cardCounterNode.setVisible(!isVisible);
    },

    // 轉換花色數字到對應的array位置
    _switchCardNum: function (card) {
        var param = {};
        var flower = parseInt(card[0]);
        switch (flower) {
            // server的3是方塊,4是梅花 => 這邊4是方塊,3是梅花
            case 3:
                param.flower = 4;
                break;
            case 4:
                param.flower = 3;
                break;
            default:
                param.flower = flower;
                break;
        }

        var num = card[1];
        switch (num) {
            case "K":
                param.num = 13;
                break;
            case "Q":
                param.num = 12;
                break;
            case "J":
                param.num = 11;
                break;
            case "T":
                param.num = 10;
                break;
            default:
                param.num = parseInt(num);
                break;
        }

        // array位子從0開始，所以要再-1
        param.num -= 1;
        param.flower -= 1;

        return param;
    },
});