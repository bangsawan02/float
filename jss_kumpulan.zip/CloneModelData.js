/**
 * v5.5.2 分身模組 - 資料
 * created by Jim.chen
 */
var CloneModelData = cc.Class.extend({
    ctor: function () {

        // 初始化
        this.cleanData();

        // 註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            "plan_replacement_icon": this.cmd_plan_replacement_icon,
            "plan_replacement_info": this.cmd_plan_replacement_info,
            "plan_replacement_recharge_done": this.cmd_plan_replacement_recharge_done
        });
    },

    /**
     * 砍掉Data
     */
    destroyData: function () {
        DataProcess.removeSocketKeyDispatch(this);
    },

    /**
     * 拿Icon資訊
     * @param whereType type 0:大廳 1:大廳儲值中心 2:遊戲內儲值中心
     */
    startGetIconInfo: function (whereType) {
        DataProcess.sendString("plan_replacement_icon " + JSON.stringify({type: whereType.toString()}));
    },

    /**
     * 拿活動資訊
     */
    startGetInfo: function () {
        DataProcess.sendString("plan_replacement_info");
    },

    /**
     * 抓活動剩餘時間
     */
    getRemainTime: function () {
        var iconParam = this.iconParam;
        if (!iconParam)
            return 0;

        return JSCodeUtility.getRemainTimeByParam(iconParam);
    },

    /**
     * 清除資料
     */
    cleanData: function () {
        this.iconParam = undefined;        // icon的資料
        this.infoParam = undefined;        // 活動的資料
        this.rechargeParam = undefined;    // 儲值成功的資料

        // 紀錄icon小紅點相關資料
        this.iconRedPointObj = {
            todayPeriod: "0",                // 今日六點期數
            isShowIconRedPoint: false,       // 大廳小紅點顯示
            isShowDayRedPoint: false,        // 顯示每日小紅點
            // 倒數三小時的小紅點
            threeHoursObj: {
                isShow: false,               // 需要顯示
                isShowed: false              // 顯示過了
            }
        };
    },

    /**
     * 要顯示小紅點
     * 1: FID開啟時 當日尚未進入活動
     * 2: 距離倒數時間剩3hrs時出現 (由icon倒數出現)
     */
    updateRedPointStatus: function () {
        var iconRedPointObj = this.iconRedPointObj;

        // 每日進入活動介面的小紅點
        var isShowDayRedPoint = iconRedPointObj.isShowDayRedPoint = this.isTodayRedPointShowedByDefaultKey(UserDefaultKey.CloneModelDayRedPoint);

        // 倒數三小時的小紅點
        var isShowThreeHoursRedPoint = false;
        if (this.iconParam && this.getRemainTime() <= 10800) {
            if (this.isTodayRedPointShowedByDefaultKey(UserDefaultKey.CloneModelThreeHoursRedPoint)) {
                // 需要顯示，並紀錄顯示過
                isShowThreeHoursRedPoint = iconRedPointObj.threeHoursObj.isShow = true;
                iconRedPointObj.threeHoursObj.isShowed = true;
            }
        }

        this.iconRedPointObj.isShowIconRedPoint = isShowDayRedPoint || isShowThreeHoursRedPoint;

        // 通知更新小紅點
        GS.dispatchCustomEvent("NotifyPlanReplacementIconUpdateRedPoint");
    },

    /**
     * 丟DefaultKey判斷該紅點是否要跳
     */
    isTodayRedPointShowedByDefaultKey: function (key) {
        // 用DefaultKey抓上次跳過的期數
        var key = JSStringUtility.format("%s%s", key, DataModal.profileData.account);
        var lastPeriod = parseInt(GS.localStorage.getItem(key, "0"));
        return this.iconRedPointObj.todayPeriod !== lastPeriod;
    },

    /**
     * 小紅點按過，紀錄新的期數
     */
    setRedPointRecord: function () {
        var iconRedPointObj = this.iconRedPointObj;

        // 每日小紅點
        var key;
        if (iconRedPointObj.isShowDayRedPoint) {
            key = JSStringUtility.format("%s%s", UserDefaultKey.CloneModelDayRedPoint, DataModal.profileData.account);
            GS.localStorage.setItem(key, this.iconRedPointObj.todayPeriod.toString());

            iconRedPointObj.isShowDayRedPoint = false;
        }

        // 倒數三小時小紅點
        if (iconRedPointObj.threeHoursObj.isShow) {
            key = JSStringUtility.format("%s%s", UserDefaultKey.CloneModelThreeHoursRedPoint, DataModal.profileData.account);
            GS.localStorage.setItem(key, this.iconRedPointObj.todayPeriod.toString());

            iconRedPointObj.threeHoursObj.isShow = false;
        }

        // 更新小紅點狀態
        this.updateRedPointStatus();
    },

    /**
     * 活動是否開啟
     */
    isEventOpen: function () {
        var iconParam = this.iconParam;
        return iconParam && iconParam.isSuccess && this.getRemainTime() > 0;
    },

    /**
     * 從儲值資料更新現有資料
     */
    updateDataFromRechargeParam: function () {
        if (this.rechargeParam) {
            this.infoParam.wheelList = Array.from(this.rechargeParam.wheelList);
            this.infoParam.nowCoinProgress = this.rechargeParam.nextCoinProgress;
            this.rechargeParam = undefined;
        }
    },

    /**
     * ===============
     * Socket Callback
     * ===============
     */

    /**
     * 分身模組 (Icon資料)
     * C->S plan_replacement_icon {"type":"0"} #type 0:大廳 1:大廳儲值中心 2:遊戲內儲值中心
     * S->C plan_replacement_icon {"error":"1","success":"0"}
     */
    cmd_plan_replacement_icon: function (key, value) {
        // 黑帳號不做事
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value || "{}");
        var iconParam = this.iconParam = {};

        iconParam.isSuccess = JSCodeUtility.getBooleanValue(jsonValue["success"], false);

        if (iconParam.isSuccess) {
            // 倒數時間
            iconParam.remainTime = JSCodeUtility.getIntValue(jsonValue["time_left"], 0);
            iconParam.socketTime = JSCodeUtility.getNowTime();

            // 每天六點的期數(小紅點用)
            this.iconRedPointObj.todayPeriod = JSCodeUtility.getIntValue(jsonValue["period"]);

            // 更新小紅點狀態
            this.updateRedPointStatus();

            // 首次觸發需要刷新儲值中心
            var isRefreshBill = JSCodeUtility.getBooleanValue(jsonValue["refresh_bill"], false);
            if (isRefreshBill)
                DataModal.purchaseData.sendGetPurchaseListCMD();

            // 自動彈跳
            iconParam.isPop = JSCodeUtility.getBooleanValue(jsonValue["pop"], false);

            // 轉盤相關，有儲值資料不收，避免舊轉盤資料被覆蓋
            if (!this.rechargeParam) {
                if (!this.infoParam) {
                    this.infoParam = {};
                }

                this.infoParam.wheelList = (jsonValue["wheel_list"] || []).map((e) => {
                    return {
                        pic: JSCodeUtility.getStringValue(e["pic"]),
                        txt: JSCodeUtility.getStringValue(e["txt"])
                    };
                });
            }

            // 當前需要顯示幾個代幣
            iconParam.coinsCount = JSCodeUtility.getIntValue(jsonValue["user_progress"]);

            // 可以獲得的金錢
            iconParam.title = JSCodeUtility.getIntValue(jsonValue["max_chips"]);

            // 分群
            iconParam.cluster = JSCodeUtility.getIntValue(jsonValue["cluster"]);
        }

        GS.dispatchCustomEvent("NotifyPlanReplacementIconDone");
    },

    /**
     * C->S plan_replacement_info
     * S->C plan_replacement_info
     */
    cmd_plan_replacement_info: function (key, value) {
        // 黑帳號不做事
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value || "{}");
        var infoParam = this.infoParam = this.infoParam || {};

        infoParam.isSuccess = JSCodeUtility.getBooleanValue(jsonValue["success"], false);

        if (infoParam.isSuccess) {
            // 說明頁使用模組type
            infoParam.skinType = JSCodeUtility.getIntValue(jsonValue["skin"]);

            // 圖片基本網址
            infoParam.baseUrl = JSCodeUtility.getStringValue(jsonValue["banner_url"]);
            // 包裝圖檔名
            infoParam.img = JSCodeUtility.getStringValue(jsonValue["banner_img"]);

            // 累積籌碼次數
            infoParam.nowCoinProgress = JSCodeUtility.getIntValue(jsonValue["user_progress"]);
            // 最大籌碼累積值
            infoParam.maxCoinProgress = JSCodeUtility.getIntValue(jsonValue["progress_total"]);

            // 儲值Rp.XXX以上
            infoParam.planMoneyStr = JSCodeUtility.getStringValue(jsonValue["plan_money"]);

            // 分群
            infoParam.cluster = JSCodeUtility.getIntValue(jsonValue["cluster"]);
            infoParam.group = JSCodeUtility.getIntValue(jsonValue["group"]);

            // 轉盤相關，有儲值資料不收，避免舊轉盤資料被覆蓋
            if (!this.rechargeParam) {
                infoParam.wheelList = (jsonValue["wheel_list"] || []).map((e) => {
                    return {
                        pic: JSCodeUtility.getStringValue(e["pic"]),
                        txt: JSCodeUtility.getStringValue(e["txt"])
                    };
                });
            }
        }

        GS.dispatchCustomEvent("NotifyPlanReplacementInfoDone");
    },

    /**
     * S->C plan_replacement_recharge_done
     * {
     *     "success":"1",
     *     "user_progress":"3",                   #此次儲值後累積數
     *     "reward_msg":["500 RP(Koin Luxy)","Night Fireworks 5 Kali","100jt chips"],  #儲值就會獲得的獎勵
     *     "progress_reward_msg":["100jt chips"], #如果拿到累積獎勵才有這個
     * }
     */
    cmd_plan_replacement_recharge_done: function (key, value) {
        // 黑帳號不做事
        if (DataModal.profileData.isBlackAccount)
            return;

        // 有之前的儲值資料，先更新轉盤再收
        if (this.rechargeParam) {
            this.updateDataFromRechargeParam();
        }

        var jsonValue = JSON.parse(value || "{}");
        var rechargeParam = this.rechargeParam = {};

        rechargeParam.isSuccess = JSCodeUtility.getBooleanValue(jsonValue["success"], false);

        if (rechargeParam.isSuccess) {
            // 儲值後的累積數量
            rechargeParam.nextCoinProgress = JSCodeUtility.getIntValue(jsonValue["user_progress"]);

            // 獎勵內容
            rechargeParam.rewardMsg = (jsonValue["reward_msg"] || []).map((e) => {
                return JSCodeUtility.getStringValue(e);
            });

            // hit
            rechargeParam.hit = JSCodeUtility.getIntValue(jsonValue["hit"], -1);

            if (jsonValue["progress_reward"]) {
                rechargeParam.progressReward = {
                    pic: jsonValue["progress_reward"]["pic"],
                    count: jsonValue["progress_reward"]["count"]
                }
            }

            // 轉盤相關
            rechargeParam.wheelList = (jsonValue["wheel_list"] || []).map((e) => {
                return {
                    pic: JSCodeUtility.getStringValue(e["pic"]),
                    txt: JSCodeUtility.getStringValue(e["txt"])
                };
            });

            // 關閉分身模組 dialog
            GS.dispatchCustomEvent("NotifyCloseCloneMainDialog", { isAnimeEnabled: false });

            // 通知外面演動畫。 rechargeParam不直接丟出去是因為有可能在直式儲值中心儲值，要等回大廳再判斷演動畫。
            GS.dispatchCustomEvent("NotifyPlanReplacementRechargeDone");

            // 儲值完後要資料
            this.startGetInfo();
        }
    }
});