/**
 * 連續儲值 v3 - 金錢瘋暴 - 獎勵 Node
 */
var ContinueRechargeV3RewardNode = class extends cc.Node {
    constructor() {
        super();

        this.setCascadeOpacityEnabled(true);

        // 是否為第一個獎勵
        this._isFirstReward = false;
        this._isFreeReward = false;

        /** @type {ContinueRechargeV3Data} */
        this._dataPtr = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(PurchaseTriggerIntegrationData.purchaseType.CONTINUE_RECHARGE_V3);

        // 背景
        const bgSprite = this._bgSprite = new ccui.Scale9Sprite("continueRechargeV3_pic_frame_3.png");
        bgSprite.availableBgFileName = "continueRechargeV3_pic_frame_1.png";
        bgSprite.unavailableBgFileName = "continueRechargeV3_pic_frame_3.png";
        bgSprite.setPreferredSize(cc.size(122, 106));
        this.addChild(bgSprite);

        // 獎勵背景
        const rewardBgSprite = this._rewardBgSprite = new ccui.Scale9Sprite("continueRechargeV3_bg_frame_03-1.png");
        rewardBgSprite.availableBgFileName = "continueRechargeV3_bg_frame_01-1.png";
        rewardBgSprite.unavailableBgFileName = "continueRechargeV3_bg_frame_03-1.png";
        rewardBgSprite.setPreferredSize(cc.size(107, 59));
        rewardBgSprite.setPosition(0, 16);
        this.addChild(rewardBgSprite);

        // 獎勵 Auto Layout
        const rewardAutoLayout = this._rewardAutoLayout = new GSAutoLayoutNode();
        rewardAutoLayout.setPosition(rewardBgSprite.getPosition());
        rewardAutoLayout.setSpace(5);
        this.addChild(rewardAutoLayout);

        // 按鈕
        const button = this._button = new Texas_Button(Texas_Button.Style.GREEN, cc.size(96, 30), "Rp XXX,XXX", {
            fontSize: 13,
        });
        button.setPosition(0, -32);
        button.addTouchUpInsideAction(this._onClickButton, this);
        this.addChild(button);
    }

    refreshView(param, index) {
        // 儲存儲值資料
        this._purchaseParam = param.purchaseParam;

        // 設定獎圖
        this._setReward(param.rewardList);

        // 設定優惠標籤
        this._setSaleText(param.bonus);

        // 設定儲值按鈕
        this._button.setBtnString(param.price ? TexasUtility.getCurrencyPriceString(param.price) : LocalizedString.ContinueRechargeV3("免費"));
        this._isFreeReward = !param.price;
        this._isFirstReward = index === 0;

        // 設定狀態
        this.setAvailable(index === 0);
        this.setLockVisible(index > 0);
    }

    /**
     * 建立獎勵 node
     * @param {String} wid 獎勵 wid
     * @param {String} rewardCount 獎勵數量
     * @private
     */
    _createRewardItem(wid, rewardCount) {
        const wrapper = new GSAutoLayoutNode();
        wrapper.setType(GSAutoLayout.TYPE.VERTICAL);

        // 下載獎勵 icon
        const [itemUrl, savePath] = this._dataPtr.getItemUrlByWid(wid);
        const iconSprite = new GSDownloadSprite(null, itemUrl, savePath);
        iconSprite.setTargetSize(cc.size(40, 40));
        wrapper.addChild(iconSprite);

        // 數量 label
        const countLabel = new cc.LabelTTF(rewardCount, JSFontName, 10);
        wrapper.addChild(countLabel);

        return wrapper;
    }

    /**
     * 設定是否顯示提示訊息
     */
    setHintMessageVisible(isVisible) {
        if (!this._hintMsgPop && isVisible) {
            const textLabel = new cc.LabelTTF(LocalizedString.ContinueRechargeV3("領取優惠立即解鎖"), JSFontName, 12);
            textLabel.setFontFillColor(JSColor.BLACK);

            const hintMsgPop = this._hintMsgPop = new BaseMessageNode({
                mainNode: textLabel,
                style: BaseMessageNode.Style.WHITE,
                direct: BaseMessageNode.Direct.UP,
            });
            hintMsgPop.setPosition(0, -40);
            this.addChild(hintMsgPop);

            hintMsgPop.show();
        } else if (this._hintMsgPop && !isVisible) {
            this._hintMsgPop.removeFromParent();
            this._hintMsgPop = null;
        }
    }

    /**
     * 設定優惠標籤是否顯示
     * @param {String?} labelText - 標籤文字
     */
    _setSaleText(labelText = null) {
        if (!this._saleNode && labelText) {
            // 建立優惠 label
            const saleNode = this._saleNode = new cc.Node();
            saleNode.setCascadeOpacityEnabled(true);
            saleNode.setPosition(56, 36);
            saleNode.setRotation(12);
            this.addChild(saleNode);

            // 紅刺框
            const saleBgSprite = new cc.Sprite("#continueRechargeV3_pic_label.png");
            saleNode.addChild(saleBgSprite);

            // 優惠文字 auto layout
            const saleTextAutoLayout = new GSAutoLayoutNode();
            saleTextAutoLayout.setSpace(-2);
            saleNode.addChild(saleTextAutoLayout);

            // 優惠文字數值
            const saleTextLabel = new cc.LabelTTF(labelText, JSFontName, 15);
            saleTextLabel.setColor(JSColor.YELLOW);
            saleTextLabel.enableStroke(JSColor.OUTLINE_YELLOW, 2);
            saleTextAutoLayout.addChild(saleTextLabel);

            // 優惠文字數值
            const percentLabel = new cc.LabelTTF("%", JSFontName, 12);
            percentLabel.setColor(JSColor.YELLOW);
            percentLabel.enableStroke(JSColor.OUTLINE_YELLOW, 2);
            saleTextAutoLayout.addChild(percentLabel);
        } else if (this._saleNode && !labelText) {
            // 移除優惠 label
            this._saleNode.removeFromParent();
            this._saleNode = null;
        }
    }

    /**
     * 設定獎勵
     * @param {{wid: string, count: string}[]} rewardArray 獎勵資料陣列
     */
    _setReward(rewardArray) {
        // 先砍掉所有東西
        this._rewardAutoLayout.removeAllChildren();

        // 加上獎圖
        rewardArray.forEach(item => this._rewardAutoLayout.addChild(this._createRewardItem(item.wid, item.count)));
    }

    /**
     * 設定是否有效
     * @param {Boolean} isAvailable - 是否有效
     */
    setAvailable(isAvailable) {
        // setSpriteFrame 會讓大小跑掉，所以要先記錄下來
        const bgSize = this._bgSprite.getContentSize();
        const rewardBgSize = this._rewardBgSprite.getContentSize();

        if (isAvailable) {
            // 有效
            this._bgSprite.setSpriteFrame(this._bgSprite.availableBgFileName);
            this._rewardBgSprite.setSpriteFrame(this._rewardBgSprite.availableBgFileName);
        } else {
            // 無效
            this._bgSprite.setSpriteFrame(this._bgSprite.unavailableBgFileName);
            this._rewardBgSprite.setSpriteFrame(this._rewardBgSprite.unavailableBgFileName);
        }

        // 恢復大小
        this._bgSprite.setPreferredSize(bgSize);
        this._rewardBgSprite.setPreferredSize(rewardBgSize);
    }

    /**
     * 設定按鈕鎖頭是否顯示
     * @param {Boolean} isVisible - 是否顯示
     */
    setLockVisible(isVisible) {
        if (!this._lockSpine && isVisible) {
            // 建立鎖頭 spine
            GSSpine.create("spine/PurchaseTriggerIntegration/ContinueRechargeV3/ani_lock", 0.25, (spine) => {
                this._lockSpine = spine;
                spine.setPosition(-45, -32);
                spine.setAnimation(0, "lock_keep", false);
                spine.setScale(0.8);
                this.addChild(spine);
            });
        } else if (this._lockSpine) {
            if (isVisible) {
                this._lockSpine.setAnimation(0, "lock_keep", false);
            } else {
                // 移除鎖頭 spine
                this._lockSpine.removeFromParent();
                this._lockSpine = null;
            }
        }
    }

    /**
     * 播放鎖頭解鎖動畫
     */
    playUnlockAnimAsync() {
        return new Promise((resolve, reject) => {
            if (this.__isDestroyed) {
                return reject();
            }

            // 播放鎖頭解鎖動畫
            if (this._lockSpine) {
                this._lockSpine.setCompleteListener(() => {
                    this._lockSpine.setCompleteListener(null);
                    resolve();
                });
                this._lockSpine.setAnimation(0, "lock_open", false);
            } else {
                resolve();
            }
        });
    }

    /**
     * 播放紅刺框放下動畫
     */
    playDropSaleAnimAsync() {
        return new Promise((resolve, reject) => {
            if (this.__isDestroyed) {
                return reject();
            }

            if (this._saleNode) {
                const saleNode = this._saleNode;
                saleNode.setScale(3);
                saleNode.setOpacity(0);
                saleNode.runAction(cc.spawn(
                    cc.fadeIn(0.1),
                    cc.sequence(
                        cc.scaleTo(0.4, 1).easing(cc.easeBounceOut()),
                        cc.callFunc(() => resolve())
                    )
                ));
            } else {
                // node 不存在直接結束
                resolve();
            }
        });
    }

    /**
     * 播放領獎成功動畫
     */
    playCollectSuccessAnimAsync() {
        // 文字縮小離場動畫
        return new Promise((resolve, reject) => {
            if (this.__isDestroyed)
                return reject();

            if (this._button) {
                const textLabel = this._button.getTitleLabel();
                // 文字縮小動畫
                textLabel.runAction(cc.sequence(
                    cc.scaleTo(0.3, 0),
                    cc.callFunc(() => resolve())
                ));
            } else {
                resolve();
            }
        })
            // 打勾圖片放大入場動畫
            .then(() => new Promise((resolve, reject) => {
                if (this.__isDestroyed)
                    return reject();

                const checkSprite = new cc.Sprite("#continueRechargeV3_pic_check.png");
                checkSprite.setPosition(GS.isLuxyPoker ? cc.p(0, 2) : cc.p(0, 0));
                checkSprite.setScale(0);
                this._button.addChildToContentNode(checkSprite);

                checkSprite.runAction(cc.sequence(
                    cc.scaleTo(0.2, 1),
                    cc.callFunc(() => resolve())
                ));
            }));
    }

    /**
     * Button clicking event
     */
    _onClickButton() {
        if (this._isFirstReward) {
            if (this._isFreeReward) {
                // 領免費獎勵
                GS.dispatchCustomEvent("NotifyContinueRechargeV3StartGetFreeReward");
            } else {
                // 儲值囉！
                GS.dispatchCustomEvent("NotifyContinueRechargeV3StartPurchase", this._purchaseParam);
            }
        } else {
            // 顯示提示訊息
            GS.dispatchCustomEvent("NotifyContinueRechargeV3PageLayerShowHintLayer");
        }
    }
};