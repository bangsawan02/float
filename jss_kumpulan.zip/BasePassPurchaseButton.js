/**
 * 通行證 - 儲值按鈕
 * @example
 * new BasePassPurchaseButton({
 *     ticketIconFileName: "",                            // 票券圖示圖檔
 *     isUseOldBtnStyle: false,                           // 是否使用舊的按鈕樣式（Common Style）
 *     purchaseBtnStyle: Texas_Button.Style.COMMON_GREEN, // 按鈕 Style
 *     purchaseBtnIsShowTicketIcon: false,                // 是否顯示票券
 *     purchaseBtnMessage: "",                            // 按鈕顯示的文字
 *     purchaseBtnIsShowDiscount: false,                  // 是否顯示折扣標籤
 *     purchaseBtnIsShowPrice: true,                      // 要不要顯示價格
 *     purchaseBtnAlwaysUseDiscountMessage: false,        // 是否總是使用折扣訊息
 *     purchaseBtnDiscountMessage: "",                    // 折扣標籤文字
 *     purchaseBtnDiscountFileName: "",                   // 折扣標籤圖檔
 *     purchaseBtnDiscountPosition: cc.p(76, 6),          // 折扣標籤位置
 *     purchaseBtnDiscountRotation: 10,                   // 折扣標籤旋轉角度
 *     purchaseBtnDiscountScale: 0.9,                     // 折扣標籤縮放倍率
 *     purchaseBtnDiscountFontColor: cc.color(255, 255, 153), // 折扣標籤顏色
 *     purchaseBtnDiscountFontSize: 10,                   // 折扣標籤字體大小
 *     purchaseBtnDiscountLabelPosition: cc.p(0, 0),      // 折扣標籤文字位置
 *     purchaseBtnOnClick: () => {},                      // 點擊 callback
 * });
 *
 * @param {Object}    config                          - 設定
 * @param {string}    config.ticketIconFileName       - 票券圖示圖檔的檔名。
 * @param {string}    config.purchaseBtnTicketIconFileName    - 購買票券圖示圖檔的檔名。(未設定則使用 config.ticketIconFileName)
 * @param {float}     config.purchaseBtnTicketScale   - 購買票券圖示縮放 (預設 0.7)
 * @param {boolean}   config.isUseOldBtnStyle         - 是否使用舊的按鈕樣式。
 * @param {string}    config.purchaseBtnStyle         - 儲值按鈕的樣式。
 * @param {boolean}   config.purchaseBtnIsShowTicketIcon - 是否顯示票券圖示。
 * @param {string}    config.purchaseBtnMessage       - 儲值按鈕上顯示的文字。
 * @param {boolean}   config.purchaseBtnIsShowDiscount - 是否顯示折扣標籤。
 * @param {boolean}   config.purchaseBtnAlwaysUseDiscountMessage - 是否總是使用折扣訊息。
 * @param {string}    config.purchaseBtnIsShowPrice      - 儲值按鈕是否要顯示價格
 * @param {string}    config.purchaseBtnDiscountMessage - 折扣標籤上的文字。
 * @param {string}    config.purchaseBtnDiscountFileName - 折扣標籤的圖檔檔名。
 * @param {cc.Point}  config.purchaseBtnDiscountPosition - 折扣標籤的位置。
 * @param {number}    config.purchaseBtnDiscountRotation - 折扣標籤的旋轉角度。
 * @param {number}    config.purchaseBtnDiscountScale - 折扣標籤的縮放比例。
 * @param {cc.Color}  config.purchaseBtnDiscountFontColor - 折扣標籤的字體顏色。
 * @param {number}    config.purchaseBtnDiscountFontSize - 折扣標籤的字體大小。
 * @param {cc.Point}  config.purchaseBtnDiscountLabelPosition - 折扣標籤文字的位置。
 * @param {Function}  config.purchaseBtnOnClick       - 按鈕點擊事件的 callback。
 */
var BasePassPurchaseButton = Texas_Button.extend({
    ctor: function (config = {}) {
        // 按鈕基礎設定
        let btnSize = cc.size(110, 38);
        let btnStyle = config.purchaseBtnStyle !== undefined ? config.purchaseBtnStyle : (config.isUseOldBtnStyle ? Texas_Button.Style.COMMON_GREEN : Texas_Button.Style.GREEN);
        let btnMessage = config.purchaseBtnMessage || "";
        this._super(btnStyle, btnSize, btnMessage, {isAutoSizeLabel: true});

        this.setChangeColorWhenDisabled(false);
        this.setChangeOpacityWhenDisabled(false);
        this.addTouchUpInsideAction(config.purchaseBtnOnClick ? config.purchaseBtnOnClick : () => {}, this);

        let isShowTicketIcon = config.purchaseBtnIsShowTicketIcon === undefined ? true : config.purchaseBtnIsShowTicketIcon;
        let isShowDiscountLabel = config.purchaseBtnIsShowDiscount === undefined ? true : config.purchaseBtnIsShowDiscount;
        config.purchaseBtnDiscountFileName = config.purchaseBtnDiscountFileName || "luxyPass_pic_label.png";
        config.purchaseBtnDiscountMessage = config.purchaseBtnDiscountMessage || "";
        config.ticketIconFileName = config.ticketIconFileName || "luxyPass_pic_ticket_01.png";
        config.purchaseBtnTicketIconFileName = config.purchaseBtnTicketIconFileName || config.ticketIconFileName;
        config.purchaseBtnTicketScale = config.purchaseBtnTicketScale || 0.7;
        config.purchaseBtnIsShowPrice = config.purchaseBtnIsShowPrice === undefined ? true : config.purchaseBtnIsShowPrice;
        config.purchaseBtnAlwaysUseDiscountMessage = config.purchaseBtnAlwaysUseDiscountMessage === undefined ? false : config.purchaseBtnAlwaysUseDiscountMessage;

        this._config = config;

        isShowTicketIcon && this._createTicketIcon();
        isShowDiscountLabel && this._createDiscountLabel();

        // 其中一個有顯示要稍微縮小寬度，避免被蓋住
        if (isShowTicketIcon || isShowDiscountLabel) {
            this.getTitleLabel().setDimensions2(btnSize.width - 32, btnSize.height);
        }
    },

    /**
     * 建立票券圖示
     * @private
     */
    _createTicketIcon: function () {
        let ticketSprite = new cc.Sprite("#" + this._config.purchaseBtnTicketIconFileName);
        ticketSprite.setPosition(-56, 0);
        ticketSprite.setScale(this._config.purchaseBtnTicketScale);
        this.addChildToContentNode(ticketSprite);
    },

    /**
     * 建立折扣標籤
     * @private
     */
    _createDiscountLabel: function () {
        let position = this._config.purchaseBtnDiscountPosition || cc.p(76, 6);
        let rotation = this._config.purchaseBtnDiscountRotation !== undefined ? this._config.purchaseBtnDiscountRotation : 10;
        let scale = this._config.purchaseBtnDiscountScale !== undefined ? this._config.purchaseBtnDiscountScale : 0.9;
        let fontColor = this._config.purchaseBtnDiscountFontColor || cc.color(255, 255, 153);
        let fontSize = this._config.purchaseBtnDiscountFontSize || 10;

        let discountNode = new cc.Node();
        discountNode.setPosition(position);
        discountNode.setRotation(rotation);
        this.addChildToContentNode(discountNode);

        let discountSprite = new cc.Sprite("#" + this._config.purchaseBtnDiscountFileName);
        discountSprite.setScale(scale);
        discountNode.addChild(discountSprite);

        let discountLabelPosition = this._config.purchaseBtnDiscountLabelPosition || cc.p(3, 0.5);
        let discountLabel = this._discountLabel = new cc.LabelTTF(this._config.purchaseBtnDiscountMessage, JSFontName, fontSize);
        discountLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        discountLabel.setFontFillColor(fontColor);
        discountLabel.setPosition(discountLabelPosition);
        discountNode.addChild(discountLabel);
    },

    /**
     * 更新畫面
     * @param {object}  purchaseParam    儲值資料
     * @param {boolean} isShowNowGetText 是否顯示馬上領文字
     */
    refreshView: function (purchaseParam, isShowNowGetText = false) {
        this.stopAnimation();
        if (purchaseParam) {
            this.setVisible(true);

            let nowGetText = isShowNowGetText ? (LocalizedString.BasePass("馬上領") + "\n") : "";

            let discountValue = this._formatPrice(purchaseParam.valueMsg || purchaseParam.tipMsg);
            let priceValue = this._formatPrice(purchaseParam.buttonMsg);

            if (this._config.purchaseBtnAlwaysUseDiscountMessage) {
                this._discountLabel && this._discountLabel.setString(this._config.purchaseBtnDiscountMessage || LocalizedString.BasePass("獎勵價值") + "\n" + TexasUtility.getCurrencyPriceString(discountValue));
            } else {
                this._discountLabel && this._discountLabel.setString(LocalizedString.BasePass("獎勵價值") + "\n" + TexasUtility.getCurrencyPriceString(discountValue));
            }

            this.getTitleLabel().setString(nowGetText + TexasUtility.getCurrencyPriceString(priceValue));
            if (!this._config.purchaseBtnIsShowPrice) {
                // 不顯示價格，顯示「解鎖」
                this.getTitleLabel().setString(LocalizedString.BasePass("解鎖 pass"));
            }
            this.productParam = purchaseParam.productParam;
        } else {
            this.setVisible(false);
        }
    },

    playAnimation: function () {
        this.stopAnimation();
        this.runAction(Texas_AnimationUtility.buttonScaleAni().repeatForever());
    },

    stopAnimation: function () {
        if (this.__isDestroyed)
            return;

        this.stopAllActions();
        this.setScale(1);
    },

    /**
     * 格式化價格
     * @param {string|number} value
     * @returns {number|*}
     * @private
     */
    _formatPrice: function (value) {
        switch (JSCodeUtility.checkType(value)) {
            // "RP. 100,000" -> 100000
            case JSTYPE.STRING:
                let price = value.replace(/\D/g, "");
                return price.length > 0 ? parseInt(price, 10) : 0;

            // 100000 -> 100000
            case JSTYPE.NUMBER:
                return value;
        }
        return 0;
    },
});