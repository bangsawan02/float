/**
 * 免費幣整合在大廳的圖示
 */
var FreeChipLobbyIconNode = LobbyIconNode.extend({
    ctor: function (showLayer) {
        this._super();

        this.key = "FreeChipLobbyIconNode";

        this._showLayer = showLayer;

        var btnSize = cc.size(45, 35);

        // 用來當底的Node
        var node = new ccui.Scale9Sprite();
        node.setContentSize(btnSize);

        // 主要放東西的node
        var mainNode = this._mainNode = new cc.Node();
        mainNode.setCascadeColorEnabled(true);
        mainNode.setCascadeOpacityEnabled(true);
        mainNode.setPosition(btnSize.width / 2, btnSize.height / 2);
        node.addChild(mainNode);

        // icon
        var iconSp = new cc.Sprite("#lobby_icon_free_chip.png");
        iconSp.setPosition(0, 2);
        mainNode.addChild(iconSp);

        // Free Chip文字
        var wordSp = new cc.Sprite("#lobby_word_free_chip.png");
        wordSp.setPosition(0, -12);
        mainNode.addChild(wordSp, 1);

        // 小紅點
        var badgeNode = this._badgeNode = new BadgeNode();
        badgeNode.useDefaultStyle();
        badgeNode.setPosition(14, 13);
        this.addChild(badgeNode, 10);

        // 按鈕的設定
        var controlButton = new cc.ControlButton();
        controlButton.setPreferredSize(btnSize);         // 一定要加這行 Native才會是對的
        controlButton.setBackgroundSpriteForState(node, cc.CONTROL_STATE_NORMAL);
        controlButton.addTargetWithActionForControlEvents(this, this._buttonClicked,
            cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
            cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
            cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
        controlButton.setAdjustBackgroundImage(false);
        controlButton.setZoomOnTouchDown(false);
        this.addChild(controlButton);

        // 預設會有每日任務 所以先更新一次畫面
        this.notifyFreeChipAvailableListRefresh();

        // 註冊
        var refreshFunc = this.notifyItemRefresh.bind(this);
        GS.addListener("NotifyFreeChipAvailableListRefresh", this.notifyFreeChipAvailableListRefresh.bind(this), this);
        GS.addListener("NotifyUpdateDailyMission", refreshFunc, this);
        GS.addListener("NotifyUpdateDailyScratch", refreshFunc, this);
        GS.addListener("NotifyShowAdInfoDone", refreshFunc, this);
        GS.addListener("NotifyActionListDone", refreshFunc, this);
        GS.addListener("NotifyGetGuildInfo", refreshFunc, this);                        // 公會要第一筆資料
        GS.addListener("NotifyGuildInformationDone", refreshFunc, this);                // 公會後續更新資料
        GS.addListener("NotifyGuildShowSurpriseReward", refreshFunc, this);             // 領過獎的更新
        GS.addListener("NotifySerialNumberPrizeInfoDone", refreshFunc, this);           // 序號領獎
        GS.addListener("NotifySerialNumberPrizeTimeOut", refreshFunc, this);            // 序號時間結束
        GS.addListener("NotifyContinueSignInInfoDone", refreshFunc, this);              // 連續簽到
        GS.addListener("NotifyMasterPokerInfoDone", refreshFunc, this);                 // 猜手牌遊戲
        GS.addListener("NotifyReturnMissionInfoDone", refreshFunc, this);               // 回流任務
        GS.addListener("NotifyUpdateEventRewardInfo", refreshFunc, this);               // 活動可領獎
        GS.addListener("NotifyFetchAchievementTabInfoDone", refreshFunc, this);         // 成就可領獎
        GS.addListener("NotifyCardKingInfoDone", refreshFunc, this);                    // 牌王
        GS.addListener("NotifyVipDailyDone", refreshFunc, this);                        // vip每日獎勵
        GS.addListener("NotifyVipInfoDone", refreshFunc, this);                         // vip
        GS.addListener("NotifyShowReturnMission", this.notifyShowReturnMission.bind(this), this);                   // 跳回歸任務
        GS.addListener("NotifyFreeChipLoginInfoDone", this.notifyFreeChipLoginInfoDone.bind(this), this);           // 特定時段登入獎勵
        GS.addListener("NotifyShowDailyLuckyWheelDialog", this.notifyShowDailyLuckyWheelDialog.bind(this), this);   // 要跳出每日登入輪盤
        GS.addListener("NotifySignInInfoDone", this.notifySignInInfoDone.bind(this), this);                         // 整合簽到
    },

    /**
     * 按到的時後 要改變顏色
     */
    _buttonClicked: function (sender, type) {
        var isTouched = (type === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || type === cc.CONTROL_EVENT_TOUCH_DOWN);
        this._mainNode.setColor(isTouched ? JSColor.GRAY : JSColor.WHITE);

        if (type === cc.CONTROL_EVENT_TOUCH_UP_INSIDE) {
            // 埋點
            DataProcess.sendString("track_new_free_chip 1");

            // 埋點: 點擊Free Chip次數
            TexasUtility.sendUserAnalyticsTrack(1925);

            // 埋點 >=5.4.5進入Free chips 且有觸發填寫手機資料icon人數
            if (DataModal.phoneToGiftData.isOpen)
                DataProcess.sendString("track_new_free_chip 12");

            // 跳出Dialog
            if (!DialogManager.isExist("FreeChipNewbieDialog"))
                DialogManager.addLobbyDialog(new FreeChipDialog());

            // AppsFlyer
            GSAppsFlyerWrapper.logEvent("lobby_freechip");
        }
    },

    /**
     * 免費幣整合介面更新通知
     */
    notifyFreeChipAvailableListRefresh: function () {
        // 檢查是否需要顯示小紅點
        var isShow = DataModal.freeChipsData.isShowFreeChipBadge;
        this._badgeNode.setVisible(isShow);

        if (isShow) {
            if (DataModal.freeChipsData.freeChipParam.isPop
                && !DialogManager.isExist("FreeChipDialog")
                && !DialogManager.isExist("FreeChipNewbieDialog")
                && PushScene.checkNowLayer(LobbyLayer)) {

                DataModal.freeChipsData.freeChipParam.isPop = false;

                // 跳免費幣教學
                if ((parseInt(GS.localStorage.getItem("ShowNewFreeChipDialogHint", "0")) === 0) && this._showLayer && this._showLayer.getChildren().length === 0) {
                    // 顯示教學引導 教學icon固定在最後面
                    var pos = this.getParent() ? this.getParent().getPosition() : undefined;

                    // 先把在大廳的其它Dialog設為隱藏，之後回到大廳會在跳出來
                    DialogManager.setAllDialogVisible(false);

                    // Dialog先不要跳出
                    DialogManager.pauseShowDialog();

                    var newbieDialog = new FreeChipNewbieDialog(pos);
                    this._showLayer.addChild(newbieDialog);
                    newbieDialog.startDialogAnimation();

                    // 顯示過了 下次不用顯示
                    GS.localStorage.setItem("ShowNewFreeChipDialogHint", "1");
                } else {
                    DataModal.freeChipsData.isDialogPop = true;
                    // 跳出
                    DialogManager.addLobbyDialog(new FreeChipDialog());
                }
            }

            this._updateTimer();
        }
    },

    /**
     * 新增/更新 timer，只倒數剩餘時間較短的
     */
    _updateTimer: function () {
        // 需要倒數的data，順便加上倒結束要送的 [重抓 cmd]
        let timerParam = [
            Object.assign({}, DataModal.freeChipsData.pulsaParam, {sendCmd: ["free_pulsa_info"]}),
            Object.assign({}, DataModal.freeChipsData.questionnaireV2Param, {sendCmd: ["questionnaire_v2_info"]}),
            Object.assign({}, DataModal.cloudClubData, {sendCmd: ['cloud_club_info {"which":"31"}']}),
            Object.assign({}, DataModal.cardKingData, {sendCmd: ['crown_king_info', 'crown_king_map_main']}),
        ]
            // 篩選有倒數資料
            .filter((it) => it.remainTime && it.socketTime)
            // map成 JSCodeUtility remain time
            .map((it) => {
                it.remainTime = JSCodeUtility.getRemainTime(it.remainTime, it.socketTime);
                return it;
            })
            // 只要大於 1
            .filter((it) => it.remainTime > 1)
            // 小到大
            .sort((a, b) => a.remainTime - b.remainTime)
            [0]; // 取出最小的剩餘時間

        // 剩餘時間大於 0 才創
        if (timerParam && timerParam.remainTime > 0) {
            let remainTime = timerParam.remainTime;
            let sendCmd = timerParam.sendCmd;

            let timerNode = this._timerNode;
            // 如果沒有 timer 創一個
            if (!timerNode) {
                timerNode = this._timerNode = new GSTimerNode();
                this.addChild(timerNode);
            }
            timerNode.countdownSeconds(remainTime, () => {
                // 時間到 送出重抓和更新 timer
                sendCmd.forEach((cmd) => DataProcess.sendString(cmd));
                this._updateTimer();
            }, undefined);
        }
    },

    /**
     * 刷新可顯示的icon
     */
    notifyItemRefresh: function () {
        DataModal.freeChipsData.refreshAvailableList();
    },

    /**
     * 通知要跳回歸任務
     */
    notifyShowReturnMission: function () {
        // 如果dialog已經跳了 或是 在回流流程中不做事
        if (!DialogManager.isExist("ReturnMissionDialog") && !DialogManager.isExist("ReturnWelfareUIHelperDialog")) {
            DialogManager.addDialog(new ReturnMissionDialog(this));
        }
    },

    /**
     * 跳出每日登入輪盤 因為要從這個Node的位置跳出Dialog所以放在這邊
     */
    notifyShowDailyLuckyWheelDialog: function () {
        DialogManager.addLobbyDialog(new DailyLuckyWheelFullDialog(this.convertToWorldSpace(cc.p(0, 0))), true);
    },

    /**
     * 通知特定時段登入獎勵
     */
    notifyFreeChipLoginInfoDone: function () {
        // 刷新清單
        DataModal.freeChipsData.refreshAvailableList();

        // 處理刷新時間
        var data = DataModal.freeChipsData.loginInfo;
        if (data.isOpen) {
            if (!this._logintimeLabel) {
                var loginTimeLabel = this._logintimeLabel = new GSTimeLabel("", JSFontName, 12);
                loginTimeLabel.setVisible(false);
                this.addChild(loginTimeLabel);
            }
            var remainTime = JSCodeUtility.getRemainTime(data.remainTime, data.socketTime);
            this._logintimeLabel.countdownSeconds(remainTime, () => {
                // 刷新狀態
                DataModal.freeChipsData.refreshLoinRewardStatus();

                // 特定時段登入獎勵
                DataProcess.sendString("period_login_bonus_info");
            });
        }
    },

    /**
     * 通知收到整合簽到
     */
    notifySignInInfoDone: function () {
        // 刷新清單
        DataModal.freeChipsData.refreshAvailableList();

        // 處理刷新時間
        var data = DataModal.signInData;
        if (data.getEventIsOpen()) {
            if (!this._signInTimerNode) {
                var timerNode = this._signInTimerNode = new GSTimerNode();
                this.addChild(timerNode);
            }

            this._signInTimerNode.countdownSeconds(data.getEventRemainTime(), () => {
                // 重要資料
                data.startGetInfo();
            });
        }
    },
});