/**
 * 用來對應Native GSDeviceInfo用的
 */

var GSDeviceWrapper = {};

(function () {
    // h5用的ENC token
    var h5EncToken = cc.sys.isNative ? "" : (Cookie.get("enc") || "");
    var _UUID = "";

    /**
     * 抓取手機UUID
     */
    GSDeviceWrapper.getUUID = function (h5UseRandom = true) {
        // 第一次要抓機碼
        if (_UUID.length === 0) {
            // 機碼
            if (cc.sys.isNative)
                _UUID = GSDeviceInfo.getUUID();
            else {
                // H5有分兩種 一種自己產生 一種用Fingerprint FingerPrint的話會有機率撞到, 先統一改成自行產生
                if (h5UseRandom && false)
                    _UUID = GS.fingerprint = new Fingerprint({canvas: true}).get().toString();
                else {
                    _UUID = GS.localStorage.getItem("TestUUID", "");
                    if (_UUID.length === 0) {
                        // 使用Random來產生機碼
                        var randomString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                        var totalLen = 16;
                        var randomLen = randomString.length;
                        _UUID = "";
                        for (var i = 0; i < totalLen; i++) {
                            _UUID += randomString[JSCodeUtility.getRandomInt(0, randomLen - 1)];
                        }
                        // 把他記下來
                        GS.localStorage.setItem("TestUUID", _UUID);
                    }
                }
            }
        }

        return _UUID;
    };

    /**
     * 抓取手機語系
     */
    GSDeviceWrapper.getCountry = function () {
        if (cc.sys.isNative)
            return GSDeviceInfo.getCountry();
        else
            return "";
    };

    // 抓手機語言(新版)
    GSDeviceWrapper.getLanguage = function () {
        if (cc.sys.isNative)
            return GSDeviceInfo.getLanguage();
        else
            return cc.sys.language;
    };

    // 抓手機地區
    GSDeviceWrapper.getCountryCode = function () {
        if (cc.sys.isNative)
            return GSDeviceInfo.getCountryCode();
        else
            return "";
    };

    /**
     * 抓取從哪邊進來的ENC token
     */
    GSDeviceWrapper.getEncToken = function () {
        if (cc.sys.isNative)
            return GSDeviceInfo.getEncToken();
        else
            return h5EncToken;
    };

    /**
     * 抓取推播過來的ID
     */
    GSDeviceWrapper.getNotifyID = function () {
        if (cc.sys.isNative)
            return GSDeviceInfo.getNotifyID();
        else
            return "";
    };

    /**
     * 設定推播過來的ID
     */
    GSDeviceWrapper.setNotifyID = function (notifyID) {
        if (cc.sys.isNative)
            GSDeviceInfo.setNotifyID(notifyID);
    };

    /**
     * 抓取AndroidID
     */
    GSDeviceWrapper.getAndroidID = function () {
        if (cc.sys.isNative)
            return GSDeviceInfo.getAndroidID();
        else
            return "";
    };

    /**
     * 抓取Android 另一個UUID
     */
    GSDeviceWrapper.getAnotherUUID = function () {
        if (cc.sys.isNative)
            return GSDeviceInfo.getAnotherUUID();
        else
            return "";
    };

    /**
     * 抓取Android Serial ID
     */
    GSDeviceWrapper.getSerialID = function () {
        if (cc.sys.isNative)
            return GSDeviceInfo.getSerialID();
        else
            return "";
    };

    /**
     * 檢查現在網路狀況
     */
    GSDeviceWrapper.checkInternetConnection = function () {
        if (cc.sys.isNative)
            return GSDeviceInfo.checkInternetConnection();
        else
            return true;
    };

    /**
     * 重新連接 HTTPClient (目前只有 axlib 需要這功能)
     */
    GSDeviceWrapper.restartHTTPClient = function () {
        // 目前axlib正常了 用不到
        // cc.sys.isNative && cc.IS_AX_LIB && GSDeviceInfo.restartHTTPClient();
    };

    /**
     * 抓取畫面的轉向 可以通過監聽 NotifyDeviceOrientationDidChange 來監聽手機轉向
     */
    GSDeviceWrapper.ORIENTATION = {
        UNKNOW: 0,                  // 不知道
        PORTRAIT: 1,                // 直向 話筒在上
        PORTRAIT_UPSIDE_DOWN: 2,    // 直向 話筒在下
        LANDSCAPE_RIGHT: 3,         // 橫向 劉海在左邊
        LANDSCAPE_LEFT: 4,          // 橫向 劉海在右邊
    };
    GSDeviceWrapper.getDeviceOrientation = function () {
        if (cc.sys.isNative) {
            return GSDeviceInfo.getDeviceOrientation();
        } else {
            return GSDeviceWrapper.ORIENTATION.UNKNOW;
        }
    };

    /**
     * 設定畫面的直向or橫向
     */
    GSDeviceWrapper.setDeviceOrientation = function (isPortrait, callback) {
        if (cc.sys.isNative) {
            GSDeviceInfo.setDeviceOrientation(isPortrait, function () {
                // 重新設定東西
                JSConfigReset();

                // callback回去
                callback && callback();
            });
        } else {
            if (cc.sys.isMobile && window["GSBrowserOrientation"] && !cc.sys.isLineIPad) {
                // 給另一邊處理監聽轉向
                GSBrowserOrientation.startCheckSize(isPortrait, callback);
            } else {
                // 先抓出原本的設計大小
                var oldDesignSize = cc.view.getDesignResolutionSize();
                var oldIsPortrait = oldDesignSize.width < oldDesignSize.height;
                if (oldIsPortrait !== isPortrait) {
                    // 代表需要轉向
                    !cc.sys.isLineIPad && cc.view.setOrientation(isPortrait ? cc.ORIENTATION_PORTRAIT : cc.ORIENTATION_LANDSCAPE);

                    // 重新設定設計大小
                    cc.view.setDesignResolutionSize(oldDesignSize.height, oldDesignSize.width, cc.ResolutionPolicy.SHOW_ALL);

                    // 重新設定東西
                    JSConfigReset();
                }

                // callback回去
                callback && callback();
            }
        }
    };

    /**
     * 判斷是否為模擬器
     */
    GSDeviceWrapper.getIsEmulator = function () {
        if (cc.sys.isNative)
            return GSDeviceInfo.getIsEmulator();
        else
            return false;
    };

    /**
     * 判斷是否為PC (目前只有Android在Google Play Games for PC上跑的遊戲才會有)
     */
    var __isPC = undefined;
    GSDeviceWrapper.getIsPC = function () {
        if (__isPC === undefined) {
            if (cc.sys.isNative && cc.sys.os === cc.sys.OS_ANDROID)
                __isPC = jsb.reflection.callStaticMethod("com/gamesofa/GSDeviceInfo", "getIsPC", "()Z");
            else
                __isPC = false;
        }

        return __isPC;
    };

    /**
     * 抓取是從哪一個AppStore下載
     */
    GSDeviceWrapper.getEncIsDownloadFromThirdStore = function () {
        if (cc.sys.isNative)
            return GSDeviceInfo.getEncIsDownloadFromThirdStore();
        else
            return 0;
    };

    /**
     * 抓取安裝App的額外訊息 回傳Object
     */
    GSDeviceWrapper.getInstallReferrerJson = function () {
        if (cc.sys.isNative)
            return JSON.parse(GSDeviceInfo.getInstallReferrerJson());
        else
            return {};
    };

    /**
     * 抓取此裝置有安裝的app
     */
    GSDeviceWrapper.getInstalledGamesfaGames = function (bundleIDArray) {
        if (cc.sys.isNative)
            return GSDeviceInfo.getInstalledGamesfaGames(bundleIDArray);
        else
            return "";
    };

    /**
     * 設定備用icon(iOS限定)
     */
    GSDeviceWrapper.setAlternateIconName = function (iconName) {
        if (cc.sys.isNative)
            GSDeviceInfo.setAlternateIconName(iconName);
    };

    /**
     * 取得ATT授權結果
     */
    GSDeviceWrapper.needATTAuthorization = function () {
        if (cc.sys.isNative)
            return GSDeviceInfo.needATTAuthorization();
        else
            return false;
    };

    /**
     * 顯示ATT授權詢問
     */
    GSDeviceWrapper.showATTAuthorization = function () {
        if (cc.sys.isNative) {
            GSDeviceInfo.showATTAuthorization();
        }
    };

    /**
     * 顯示ATT授權詢問+推播註冊
     */
    GSDeviceWrapper.showATTAndNotificationAuthorization = function () {
        if (cc.sys.isNative) {
            GSDeviceInfo.showATTAndNotificationAuthorization();
        }
    };

    /**
     * 取得玩家是否授權ATT
     */
    GSDeviceWrapper.getATTIsAuthorized = function () {
        if (cc.sys.isNative) {
            return GSDeviceInfo.getATTIsAuthorized();
        } else {
            return false;
        }
    };

    /**
     * 抓取APP簽章 (Android才會有)
     */
    GSDeviceWrapper.getSignedKeyHash = function () {
        if (cc.sys.isNative) {
            return GSDeviceInfo.getSignedKeyHash();
        } else {
            return "";
        }
    };

    /**
     * 抓取CPU資訊 (Android才會有)
     */
    GSDeviceWrapper.getCPUInfo = function () {
        if (cc.sys.isNative) {
            return GSDeviceInfo.getCPUInfo();
        } else {
            return "";
        }
    };

    /**
     * 取得製造商
     */
    GSDeviceWrapper.getDeviceManufacturer = function () {
        if (cc.sys.isNative) {
            return GSDeviceInfo.getDeviceManufacturer();
        } else {
            return "";
        }
    };

    /**
     * 取得型號
     */
    GSDeviceWrapper.getDeviceModel = function () {
        if (cc.sys.isNative) {
            return GSDeviceInfo.getDeviceModel();
        } else {
            return "";
        }
    };

    /**
     * 取得OS版號(operating systems)
     */
    GSDeviceWrapper.getDeviceVersion = function () {
        if (cc.sys.isNative) {
            return GSDeviceInfo.getDeviceVersion();
        } else {
            return "";
        }
    };

    /**
     * 取得製造商 型號
     */
    GSDeviceWrapper.getDeviceManufacturerAndModel = function () {
        if (cc.sys.isNative) {
            return GSDeviceInfo.getDeviceManufacturerAndModel();
        } else {
            return "";
        }
    };

    /**
     * 取得製造商 型號 OS版號(operating systems)
     */
    GSDeviceWrapper.getDeviceName = function () {
        if (cc.sys.isNative) {
            return GSDeviceInfo.getDeviceName();
        } else {
            return "";
        }
    };

    /**
     * 跳到原生系統設定App頁面
     */
    GSDeviceWrapper.openAppSettingPage = function () {
        if (cc.sys.isNative)
            GSDeviceInfo.openAppSettingPage();
    };

    /**
     * 抓取App名稱
     */
    GSDeviceWrapper.getAppName = function () {
        if (cc.sys.isNative)
            return GSDeviceInfo.getAppName();
        else
            return "";
    };
})();