/**
 * 通行證 - 共用 dialog
 * config: {
 *     messageDialogBgFileName: "",                 // dialog 背景圖
 *     messageDialogSize: cc.size(0, 0),            // dialog size
 *     messageDialogFontColor: cc.color(0, 0, 0),   // dialog 預設內文顏色
 * }
 * param: {
 *     titleText: "",                           // 標題文字
 *     titleWordFileName: "",                   // 標題文字圖檔
 *     contentText: "",                         // 內文
 *     isShowCloseButton: false,                // 是否顯示關閉按鈕
 *     onCloseCallback: () => {},               // 關閉時的 callback
 *     buttonGroup: [],                         // 按鈕群
 * }
 */
var BasePassCommonDialog = BaseDialogLayer.extend({
    ctor: function (config, param) {
        this._super();

        this.key = "BasePassCommonDialog";
        this.config = config;
        this.param = param;

        let bgFileName = config.messageDialogBgFileName || "luxyPass_bg_frame.png";
        let dialogSize = this._dialogSize = config.messageDialogSize || cc.size(270, 153);

        this.setCloseCallback(param.onCloseCallback);

        let animationLayer = this._animationLayer;

        // 背景
        let bgSprite = new ccui.Scale9Sprite(bgFileName);
        bgSprite.setPreferredSize(dialogSize);
        bgSprite.setPosition(JSScreenMidPos);
        animationLayer.addChild(bgSprite);

        this._createView();
    },

    /**
     * Create the dialog.
     * You may override it for customization.
     * @protected
     */
    _createView: function () {
        this._createTitleView();
        this._createContentView();
        this._createButtonGroup();
        this._createCloseButton();
    },

    /**
     * Create the title.
     * You may override it for customization.
     * @protected
     */
    _createTitleView: function () {
        let titleText = this.param.titleText;
        let titleColor = this.param.titleColor || JSColor.WHITE;
        let titleWordFileName = this.param.titleWordFileName;

        let titleNode;
        if (titleText) {
            // 標題文字
            titleNode = new GSRichLabelNode(titleText, JSFontName, 16, this._dialogSize);
            titleNode.setFontFillColor(titleColor);
        } else if (titleWordFileName) {
            // 標題圖檔
            titleNode = new cc.Sprite("#" + titleWordFileName);
        }

        if (titleNode) {
            titleNode.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 45);
            this._animationLayer.addChild(titleNode);
            this._titleNode = titleNode;
        }
    },

    /**
     * Create the content.
     * You may override it for customization.
     * @protected
     */
    _createContentView: function () {
        let contentText = this.param.contentText;
        let contentFontSize = this.param.contentFontSize || 12;
        let contentColor = this.config.messageDialogFontColor || JSColor.WHITE;

        // 內文
        let contentSize = cc.size(this._dialogSize.width - 40, this._dialogSize.height - 40);
        let contentLabel = new GSRichLabelNode(contentText, JSFontName, contentFontSize, contentSize);
        contentLabel.setFontFillColor(contentColor);
        contentLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + (this._titleNode ? 5 : 14));
        this._animationLayer.addChild(contentLabel);
    },

    /**
     * Create the buttons.
     * You may override it for customization.
     * @protected
     */
    _createButtonGroup: function () {
        let buttonGroup = new GSAutoLayoutNode();
        buttonGroup.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 38);
        this._animationLayer.addChild(buttonGroup);
        if (this.param.buttonGroup && this.param.buttonGroup.length > 0) {
            this.param.buttonGroup.forEach(element => {
                let instance;
                switch (JSCodeUtility.checkType(element)) {
                    case JSTYPE.FUNCTION:
                        instance = element();
                        break;
                    case JSTYPE.OBJECT:
                        instance = element;
                }
                instance && buttonGroup.addChild(instance);
            });
        } else {
            // ok按鈕
            let okBtnStyle = this.config.isUseOldBtnStyle ? Texas_Button.Style.COMMON_GREEN : Texas_Button.Style.GREEN;
            let okBtn = new Texas_Button(okBtnStyle, cc.size(100, 32), "OK");
            okBtn.addTouchUpInsideAction(this._closeDialogAnimation, this);
            okBtn.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - this._dialogSize.height / 4);
            this._animationLayer.addChild(okBtn);
        }
    },

    /**
     * Create the close button.
     * You may override it for customization.
     * @protected
     */
    _createCloseButton: function () {
        if (this.param.isShowCloseButton) {
            let closeButton = new Texas_CloseButton();
            closeButton.setPosition(JSScreenMidPos.x + this._dialogSize.width / 2 - 12, JSScreenMidPos.y + this._dialogSize.height / 2 - 12);
            closeButton.addTouchUpInsideAction(this._closeDialogAnimation, this);
            this._animationLayer.addChild(closeButton);
        }
    },
});
