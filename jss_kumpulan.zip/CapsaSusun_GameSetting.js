// 對照server給的牌型enum
var CapsaSusun_CardKindType = GSEnumHelper({
    None: -1,               // 烏龍
    OnePair: -1,            // 一對
    TwoPair: -1,            // 兩對
    ThreeOfAKind: -1,       // 三條
    Straight: -1,           // 順子
    Flush: -1,              // 同花
    FullHouse: -1,          // 葫蘆
    FourOfAKind: -1,        // 鐵支
    StraightFlush: -1,      // 同花順
    Length: -1,
});

var CapsaSusun_SpecialCardType = {
    None: -1,               // 預設值
    CDragon: 1,             // 清龍
    OneDragon: 2,           // 一條龍
    SixPair: 3,             // 六對半
    ThreeStraight: 4,       // 三順子
    ThreeFlush: 5,          // 三同花
    twelveKing: 6,          // 12王族
    ThreeRoyalFlush: 7,     // 三同花順
    ThreeDivide: 8,         // 三分天下
    AllBig: 9,              // 全大
    AllSmall: 10,           // 全小
    SameColor: 11,          // 湊一色
    FourThree: 12,          // 四套三條
    HomeRun: 13,            // 全壘打
};

// 馬上玩類型
var CAPSA_SUSUN_ROOM_TYPE = {
    NORMAL: 0,              //一般桌
};

// CapsaSusun 現在預約離桌 換桌 的類型
var CapsaSusun_LeaveGameStatus = {
    CAN_LEAVE: 0,               // 可以直接離桌
    NO_LEAVE: 1,                // 現在是不能離桌狀態
    BOOKING_LEAVE: 2,           // 預約離桌
    BOOKING_CHANGE_TABLE: 3,    // 預約換桌
};

var CapsaSusun_CardKindWeight = 100000000000;   // 牌型加權基本分
var CapsaSusun_DealStackCount = 13;             // 每個玩家要發幾張牌
var CapsaSusun_AlgorithmCount = 4;              // 要顯示的智慧牌組數量
var CapsaSusun_StackCount = 3;                  // 有幾噸
var CapsaSusun_CardStackCount = [3, 5, 5];      // 每個牌墩牌數量