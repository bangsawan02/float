/**
 * 9T 幸運彩票 倒數時間
 */

var BigLotteryClockNode = cc.Node.extend({
    ctor: function () {
        this._super();

        // 背景
        var bgSprite = new ccui.Scale9Sprite("bigLottery_bg_purpleBoard.png");
        bgSprite.setPreferredSize(cc.size(120, 67));
        this.addChild(bgSprite);

        // 標題
        var titleSprite = this._titleSprite = new cc.Sprite("#bigLottery_word_openRewardCountdown.png");
        titleSprite.setPositionY(16);
        this.addChild(titleSprite);

        // 白色背景
        var whiteBgSprite = new ccui.Scale9Sprite("bigLottery_bg_countdown_white.png");
        whiteBgSprite.setPreferredSize(cc.size(102, 28));
        whiteBgSprite.setPositionY(-11);
        this.addChild(whiteBgSprite);

        // 倒數
        var timeLabel = this._timeLabel = new GSTimeLabel("", JSFontBoldName, 14);
        timeLabel.setMultiFormat("%ddD:%hhH:%mmM", "%hhH:%mmM:%ssS", "%mmM:%ssS");
        timeLabel.setPositionY(whiteBgSprite.getPositionY());
        timeLabel.setFontFillColor(JSColor.BLACK);
        this.addChild(timeLabel);

        // 燈泡
        var bulbArray = [];
        var bulbPosArray = [
            cc.p(-51, 32), cc.p(-37, 32), cc.p(-23, 32), cc.p(-9, 32), cc.p(5, 32),
            cc.p(19, 32), cc.p(33, 32), cc.p(47, 32), cc.p(-51, -31), cc.p(-37, -31),
            cc.p(-23, -31), cc.p(-9, -31), cc.p(5, -31), cc.p(19, -31), cc.p(33, -31),
            cc.p(47, -31), cc.p(57, 25), cc.p(57, 13), cc.p(57, 0), cc.p(57, -13),
            cc.p(57, -27), cc.p(-58, 25), cc.p(-58, 13), cc.p(-58, 0), cc.p(-58, -13),
            cc.p(-58, -27)
        ];
        for (var i = 0; i < 26; i++) {
            var bulbImg = (i % 2) ? "#bigLottery_pic_lightBulb01.png" : "#bigLottery_pic_lightBulb02.png";
            var bulbSprite = bulbArray[i] = new cc.Sprite(bulbImg);
            bulbSprite.setPosition(bulbPosArray[i]);
            this.addChild(bulbSprite);
        }

        // 燈泡閃爍動畫，讓燈泡下移一個位置
        this.runAction(cc.repeatForever(cc.sequence(
            cc.delayTime(0.3),
            cc.callFunc(() => {
                var bulbArrayLength = bulbArray.length;
                bulbArray.forEach((bulb, index) => {
                    bulb.setPosition(bulbPosArray[(index + 1) % bulbArrayLength]);
                });
            }),
            cc.delayTime(0.3),
            cc.callFunc(() => {
                bulbArray.forEach((bulb, index) => {
                    bulb.setPosition(bulbPosArray[index]);
                });
            })
        )));

        // 先刷新一次
        this._refreshView();

        GS.addListener("NotifyBigLotteryIconInfoDone", this.notifyBigLotteryIconInfoDone.bind(this), this);
    },

    /**
     * 刷新畫面
     */
    _refreshView: function () {
        // 先停掉倒數
        var timeLabel = this._timeLabel;
        timeLabel.clearTimer();

        var bigLotteryData = DataModal.bigLotteryData;
        var drawLeftTime = bigLotteryData.getDrawTime();
        if (drawLeftTime > 0) {
            // 刷新標題圖(重置中圖不一樣)
            var titleImg = "bigLottery_word_openRewardCountdown.png";
            if (bigLotteryData.isResetting()) {
                titleImg = "bigLottery_word_openCountdown.png";
            }
            this._titleSprite.setSpriteFrame(titleImg);

            // 設定倒數
            timeLabel.countdownSeconds(drawLeftTime, () => {
                // 隱藏自己
                this.setVisible(false);
            });

            // 顯示自己
            this.setVisible(true);
        } else {
            // 隱藏自己
            this.setVisible(false);
        }
    },

    /**
     * 通知
     */

    // 通知收到icon資料
    notifyBigLotteryIconInfoDone: function () {
        this._refreshView();
    }
});