/**
 * 5.3.7 優惠券背包 - 大廳icon
 * Created by Jimmy.Wen 2022/3/8
 */
var BonusBackpackLobbyNode = LobbyIconNode.extend({
    ctor: function () {
        this._super();

        this.key = "BonusBackpackLobbyNode";

        this.setVisible(false);

        // 主畫面
        var mainNode = this._mainNode = new cc.Node();
        this.addChild(mainNode);

        // 監聽
        GS.addListener("NotifyCouponAssembleDone", this.notifyCouponAssembleDone.bind(this), this);
        GS.addListener("NotifyBonusBackpackRedPointDone", this.notifyBonusBackpackRedPointDone.bind(this), this);
    },

    onEnter: function () {
        this._super();

        // 刷新畫面
        this._refreshView();
    },

    /**
     * 判斷小紅點規則
     */
    _checkRedPoint: function () {
        // 取得優惠券資料
        var couponList = DataModal.purchaseCouponData.couponAssemble;

        // 計算各種類別的數量
        var list = [0, 0, 0, 0, 0];
        var canGatReward = 0;
        couponList.forEach(cur => {
            if (cur.couponType - 1 >= 0) {
                list[cur.couponType - 1]++;
                canGatReward += cur.isCanGetReward;
            }
        });

        // 將新的優惠券數量轉成字串，舊的數量轉回list
        var newCouponListCount = "[" + list.toString() + "]";
        var oldCouponListCount = JSON.parse(GS.localStorage.getItem("bonusBackpackCouponListCount" + DataModal.profileData.account, "[0,0,0,0,0]"));

        // 可領獎就顯示小紅點
        if (canGatReward > 0) {
            GS.localStorage.setItem("bonusBackpackShowRedPoint" + DataModal.profileData.account, "1");
        } else {
            // 數量比對，只要有一種數量變多就顯示小紅點
            for (var i = 0; i < list.length; i++) {
                if (list[i] > oldCouponListCount[i]) {
                    // this._isRedPoint = true;
                    GS.localStorage.setItem("bonusBackpackShowRedPoint" + DataModal.profileData.account, "1");
                    break;
                }
            }
        }

        GS.localStorage.setItem("bonusBackpackCouponListCount" + DataModal.profileData.account, newCouponListCount);
    },

    /**
     * 更新畫面
     */
    _refreshView: function () {
        this.setVisible(true);

        // 先清掉東西
        this._badgeNode = undefined;
        var mainNode = this._mainNode;
        mainNode.removeAllChildren();

        // 判斷小紅點
        this._checkRedPoint();

        // 創一個按鈕加進去
        var button = ButtonUtility.createSimpleImageButton("lobby_icon_bonusBackpack.png");
        button.bg.setScale(1.1);
        button.bg.setPositionY(-4);
        button.addTouchUpInsideAction(this._iconClicked, this);
        mainNode.addChild(button);

        // 小紅點
        var badgeNode = this._badgeNode = new BadgeNode();
        badgeNode.setPosition(17, 9);
        badgeNode.useDefaultStyle();
        badgeNode.setVisible(GS.localStorage.getItem("bonusBackpackShowRedPoint" + DataModal.profileData.account, "0") === "1");
        button.addChildToContentNode(badgeNode);
    },

    /**
     * 按鈕事件
     */
    _iconClicked: function () {
        // 跳Dialog
        var dialog = new PurchasePackDialog({
            packSkin: PurchaseStructuresData.PackSkin.BONUS_BACKPACK,
            packName: "BonusBackpack"
        }, this);
        DialogManager.addLobbyDialog(dialog);

        // 消掉小紅點
        this._badgeNode.setVisible(false);
        GS.localStorage.setItem("bonusBackpackShowRedPoint" + DataModal.profileData.account, "0");

        // 埋點
        DataProcess.sendString('track_coupon_assemble 1');
    },

    /**
     * 通知事件
     */
    // 通知收到按鈕狀態
    notifyCouponAssembleDone: function () {
        this._refreshView();
    },

    // 從儲值中心或RP商店點到 要刷新小紅點狀態
    notifyBonusBackpackRedPointDone: function () {
        this._refreshView();
    }
});