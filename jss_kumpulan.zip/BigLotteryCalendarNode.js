/**
 * [9T] 幸運彩票日曆node
 * Domino移植設定 印尼有自己客製畫面
 */

var BigLotteryCalendarNode = cc.Node.extend({
    ctor: function (param) {
        this._super();

        var midPos = cc.p(47, 55);

        // 背景
        var bgSize = cc.size(84, 74);
        var bgSprite = new ccui.Scale9Sprite("bigLottery_bg_purpleboard2.png");
        bgSprite.setPreferredSize(bgSize);
        bgSprite.setPosition(midPos);
        this.addChild(bgSprite);

        // 日期下方線
        var lineSprite = new cc.Sprite("#bigLottery_pic_line.png");
        lineSprite.setScaleX(3);
        lineSprite.setPosition(midPos.x, midPos.y + 17);
        this.addChild(lineSprite);

        // 標題
        var titleLabel = new cc.LabelTTF(param.dateStr, JSFontName, 12);
        titleLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        titleLabel.enableStroke(cc.color(98, 8, 13), 2);
        titleLabel.setPosition(midPos.x, midPos.y + 26);
        this.addChild(titleLabel);

        // 裝內文的node
        var autoLayoutNode = new GSAutoLayoutNode();
        autoLayoutNode.setType(GSAutoLayout.TYPE.VERTICAL);
        autoLayoutNode.setPosition(midPos.x, midPos.y);
        this.addChild(autoLayoutNode);

        param.typeArray.forEach(cur => {
            var label = this._getBonusLabel(cur);
            autoLayoutNode.addChild(label);
        });

        // 判斷是不是過期了
        if (param.isExpired) {
            // 蓋章的node
            var stampNode = new cc.Node();
            stampNode.setPosition(midPos.x, autoLayoutNode.getPositionY());
            this.addChild(stampNode);

            // 印章背景
            var bgSprite = new cc.Sprite("#bigLottery_bg_shadow_black.png");
            bgSprite.setScale(6);
            stampNode.addChild(bgSprite);

            // 印章
            var stampSprite = new cc.Sprite("#bigLottery_pic_ended.png");
            stampNode.addChild(stampSprite);

            // 縮小一點
            stampNode.setScale(0.8);
        }
    },

    /**
     * 取得加碼的文字
     * @param bonusType
     */
    _getBonusLabel: function (bonusType) {
        var bigLotteryStr = LocalizedString.BigLottery;
        var bonusString = "";
        var fontColor = JSColor.WHITE;

        switch (bonusType) {
            case BigLotteryData.LotteryBonusType.ENVELOPE:
                bonusString = "#!FFFF00!#" + bigLotteryStr("大紅包");
                fontColor = JSColor.YELLOW;
                break;
            case BigLotteryData.LotteryBonusType.EXTRA_PERIOD:
                bonusString = bigLotteryStr("加開一期");
                break;
            case BigLotteryData.LotteryBonusType.EXTRA_MONEY:
                bonusString = bigLotteryStr("頭獎加碼");
                break;
            case BigLotteryData.LotteryBonusType.LUCKY_NUMBER:
                bonusString = bigLotteryStr("幸運數字");
                break;
        }
        return new GSRichTextNode(bonusString, JSFontName, 8);
    }
});
