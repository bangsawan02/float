/**
 * 21點的數字Led
 */
var BlackjackLedNode = cc.Node.extend({
    ctor: function () {
        this._super();

        this.setCascadeOpacityEnabled(true);

        this.nowMoney = 0;
        this._totalMoney = 0;
        this._updateTime = 0.3;         // 更新數字要多久

        // 背景
        var bgSprite = new ccui.Scale9Sprite("bj_bg_money.png");
        bgSprite.setPreferredSize(cc.size(144, 26));
        this.addChild(bgSprite);

        // 數字 從右邊開始放到左邊 每3個後會有1個逗號
        this._ledNumberArray = [];
        this._ledDotArray = [];
        var posX = 64;
        for (var i = 0; i < 11; i++) {
            if (i % 3 === 0 && i !== 0) {
                // 要加逗號
                var dotSprite = new cc.Sprite("#vegas_led10.png");
                dotSprite.setPosition(posX + 2.5, -8);
                this.addChild(dotSprite);

                this._ledDotArray.push(dotSprite);

                posX -= 6;
            }

            var ledSprite = new cc.Sprite("#vegas_led0.png");
            ledSprite.setPosition(posX, 0);
            this.addChild(ledSprite);

            this._ledNumberArray.push(ledSprite);

            posX -= 11;
        }

        // 免費文字Node
        {
            var freeLabelNode = this._freeLabelNode = new cc.Node();
            freeLabelNode.setPosition(0, 22);
            freeLabelNode.setVisible(false);
            this.addChild(freeLabelNode);

            var blackBgSp = new ccui.Scale9Sprite("lobby_bg_list_04.png");
            blackBgSp.setPreferredSize(cc.size(50, 16));
            freeLabelNode.addChild(blackBgSp);

            var freeLabel = new cc.LabelTTF(LocalizedString.Vegas("Free"), JSFontBoldName, 12);
            freeLabel.setFontFillColor(cc.color(230, 200, 20));
            freeLabelNode.addChild(freeLabel);
        }
    },

    /**
     * 設定金錢 可以讓他有動畫
     * @param money
     * @param isAnimation 是否要有動畫
     */
    setMoney: function (money, isAnimation) {
        var len = arguments.length;
        if (len < 2)
            isAnimation = true;

        this._totalMoney = money || 0;
        this._floorNumber = this.nowMoney;

        if (isAnimation && this._floorNumber !== this._totalMoney) {
            this._usedTime = 0;

            this.unschedule(this._scheduleUpdateMoney);
            this.schedule(this._scheduleUpdateMoney);
        } else {
            this._scheduleUpdateMoney(999999);
        }
    },

    // 真正更新金錢的地方
    _updateMoney: function (money) {
        var moneyString = (money || "0").toString();
        var moneyStringLen = moneyString.length;
        for (var i = 0; i < 11; i++) {
            var ledSprite = this._ledNumberArray[i];
            var nowPos = moneyStringLen - i - 1;
            var nowMoneyChar = (nowPos < 0 ? "0" : moneyString[nowPos]);

            ledSprite.setSpriteFrame("vegas_led" + nowMoneyChar + ".png");
        }
    },

    //運算
    _scheduleUpdateMoney: function (dt) {
        this._usedTime += dt;
        if (this._usedTime < this._updateTime)
            this.nowMoney = Math.floor(this._floorNumber + (this._totalMoney - this._floorNumber) * (this._usedTime / this._updateTime));
        else {
            this.unschedule(this.scheduleUpdateLabel);
            this.nowMoney = this._totalMoney;
        }

        this._updateMoney(this.nowMoney);
    },

    /**
     * 設定是否使用免費券 畫面要修改
     * @param useFreeTicket 是否使用免費券
     */
    setUseFreeTicket: function (useFreeTicket) {
        var info = DataModal.vegasData.blackjackBetInfo;
        var freeBetMoney = (info && info.betArray) ? info.betArray[0] : 1000000;

        // 是否要出現免費文字
        this._freeLabelNode.setVisible(useFreeTicket);

        // 更新金額
        this.setMoney(freeBetMoney);
    },

    /**
     * 加倍動畫 傳壓注的金額
     */
    showDoubleEffect: function (betChips) {
        // 加倍框動畫
        var frameSprite = new ccui.Scale9Sprite("bj_double_line0.png");
        frameSprite.setPreferredSize(cc.size(144, 26));
        frameSprite.setOpacity(0);
        this.addChild(frameSprite, 1);

        var self = this;
        frameSprite.runAction(cc.sequence(
            cc.fadeIn(0.2),
            cc.callFunc(function () {
                // 更新LED數字
                self.setMoney(betChips * 2);
            }),
            cc.delayTime(0.5),
            cc.fadeOut(0.2),
            cc.removeSelf()
        ));

        // 加倍字動畫
        var wordSprite = new cc.Sprite("#bj_word_double.png");
        wordSprite.setPosition(0, 25);
        wordSprite.setScale(0);
        this.addChild(wordSprite, 1);

        wordSprite.runAction(cc.sequence(
            cc.scaleTo(0.2, 1).easing(cc.easeInOut(2)),
            cc.delayTime(1.5),
            cc.removeSelf()
        ));
    },
});