/**
 *
 * 使用方式:
 * var keys     = ["Event1", "Event12"]     // 事件名稱
 * var values   = {"Value1", "Value2"};     // 事件內容
 *
 * GSAnalyticsAdapter.logEventByFirebase(values);                   //Firebase:事件統一gamesofa_group
 * GSAnalyticsAdapter.logEventByFirebase(event, keys, values);      //Firebase:自定義事件
 * GSAnalyticsAdapter.logEventByAppsFlyer(event, keys, values);     //AppsFlyer:自定義事件
 * GSAnalyticsAdapter.logEventByBoth(event, keys, values);          //希望之後可以兩邊一起丟
 */
var GSAnalyticsAdapter = {

    FIREBASE_CLASS_NAME: "com.gamesofa.GSFirebaseAnalytics",
    FIREBASE_CLASS_NAME_iOS: "GSFirebaseAnalytics",
    RECORD_NAME: "GSAppsFlyer_",
    record: {},                                                     // 記錄暫存資料
    enableDebug: false,                                             // 是否打開debug

    h5_init_async: async function (firebaseConfig) {
        if (!cc.sys.isNative && firebaseConfig) {
            const {initializeApp} = await import("https://www.gstatic.com/firebasejs/11.5.0/firebase-app.js");
            const {
                getAnalytics,
                setUserProperties,
                setUserId,
                logEvent
            } = await import("https://www.gstatic.com/firebasejs/11.5.0/firebase-analytics.js");

            try {
                // 初始化 Firebase
                this._firebaseApp = initializeApp(firebaseConfig);
                this._analytics = getAnalytics(this._firebaseApp);

                // 主要的function
                this._firebase = {
                    setUserProperties: setUserProperties,
                    setUserId: setUserId,
                    logEvent: logEvent,
                };

                // 抓GA的Client ID
                gtag('get', firebaseConfig.measurementId, 'client_id', (clientId) => {
                    if (clientId) {
                        // 記下client ID
                        this._firebaseClientId = clientId;
                        cc.log("H5 GA Client ID:", clientId);
                    } else {

                    }
                });

                cc.log("Firebase & GA4 初始化成功！");
            } catch (error) {
                cc.error("Firebase 初始化失敗", error);
            }
        }
    },

    start: function () {
        if (cc.sys.isNative) {
            if (cc.sys.os === cc.sys.OS_ANDROID) {
                jsb.reflection.callStaticMethod(this.FIREBASE_CLASS_NAME, "start", "()V");
            } else {
                // iOS 初始化於 AppController.mm
            }
        }
    },

    /**
     * Firebase, initiateOnDeviceConversionMeasurementWithEmailAddress
     * https://support.google.com/google-ads/answer/12119136
     */
    initOnDeviceConversionMeasurementWithEmail: function (email) {
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            // AN無此功能不做事
        } else if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(this.FIREBASE_CLASS_NAME_iOS, "initOnDeviceConversionMeasurementWithEmail:", email);
        }
    },

    /**
     * Firebase, set Screen Name
     * https://firebase.google.com/docs/analytics/screenviews
     */
    setCurrentScreen: function (screenName) {
        if (cc.sys.isNative) {
            if (cc.sys.os === cc.sys.OS_ANDROID) {
                jsb.reflection.callStaticMethod(this.FIREBASE_CLASS_NAME, "setCurrentScreen", "(Ljava/lang/String;)V", screenName);
            } else if (cc.sys.os === cc.sys.OS_IOS) {
                jsb.reflection.callStaticMethod(this.FIREBASE_CLASS_NAME_iOS, "setCurrentScreen:", screenName);
            }
        }

        if (this.enableDebug)
            cc.log("GSAnalyticsAdapter screenName:" + screenName);
    },

    /**
     * Firebase, set User Property
     * https://firebase.google.com/docs/analytics/user-properties?platform=android
     */
    setUserProperty: function (key, value) {
        if (cc.sys.isNative) {
            if (cc.sys.os === cc.sys.OS_ANDROID) {
                jsb.reflection.callStaticMethod(this.FIREBASE_CLASS_NAME, "setUserProperty", "(Ljava/lang/String;Ljava/lang/String;)V", key, value);
            } else if (cc.sys.os === cc.sys.OS_IOS) {
                jsb.reflection.callStaticMethod(this.FIREBASE_CLASS_NAME_iOS, "setUserProperty:withValue:", key, value);
            }
        } else if (this._firebase) {
            this._firebase.setUserProperties(this._analytics, {key: value});
        }

        if (this.enableDebug)
            cc.log("GSAnalyticsAdapter setUserProperty key:" + key + " ,value:" + value);
    },

    /**
     * Firebase setUserID
     * https://firebase.google.com/docs/analytics/userid?hl=zh-tw
     */
    setFirebaseUserID: function (userID) {
        if (cc.sys.isNative) {

        } else if (this._firebase) {
            this._firebase.setUserId(this._analytics, userID);
        }
    },

    /**
     * 因為預設事件(gamesofa_group)、欄位是固定的(Event,Action,Label,Value)，直接寫死就好
     *
     */
    logEventByFirebase: function (values) {
        if (values.length === 4) {
            var json = {"Event": values[0], "Action": values[1], "Label": values[2], "Value": values[3]};
            if (cc.sys.isNative) {
                if (cc.sys.os === cc.sys.OS_ANDROID) {
                    jsb.reflection.callStaticMethod(this.FIREBASE_CLASS_NAME, "logEvent", "(Ljava/lang/String;Ljava/lang/String;)V", "gamesofa_group", JSON.stringify(json));
                } else if (cc.sys.os === cc.sys.OS_IOS) {
                    jsb.reflection.callStaticMethod(this.FIREBASE_CLASS_NAME_iOS, "logEvent:withJson:", "gamesofa_group", JSON.stringify(json));
                }
            } else if (this._firebase) {
                // 先不開
                // this._firebase.logEvent(this._analytics, "gamesofa_group", json);
            }
        }

        if (this.enableDebug)
            cc.log("GSAnalyticsAdapter gamesofa_group values:" + values);
    },

    /**
     * 自定義事件、欄位
     */
    logEventByFirebaseAll: function (event, keys, values) {
        var json = {};
        for (var i = 0, len1 = keys.length, len2 = values.length; (i < len1) && (len1 === len2); i++) {
            json[keys[i]] = values[i];
        }

        if (cc.sys.isNative) {
            if (cc.sys.os === cc.sys.OS_ANDROID) {
                jsb.reflection.callStaticMethod(this.FIREBASE_CLASS_NAME, "logEvent", "(Ljava/lang/String;Ljava/lang/String;)V", event, JSON.stringify(json));
            } else if (cc.sys.os === cc.sys.OS_IOS) {
                jsb.reflection.callStaticMethod(this.FIREBASE_CLASS_NAME_iOS, "logEvent:withJson:", event, JSON.stringify(json));
            }
        } else if (this._logEvent) {
            // 先不開
            // this._firebase.logEvent(this._analytics, event, json);
        }

        if (this.enableDebug)
            cc.log("GSAnalyticsAdapter event: " + event + ", param: " + JSON.stringify(json));
    },

    /**
     * GSAppsFlyer
     */
    logEventByAppsFlyer: function (event, keys, values) {
        if (cc.sys.isNative) {
            keys = keys || [];
            values = values || [];
            var newEventName = GSAnalyticsAdapter.getNewEventName(event);
            GSAppsFlyer.logEvent(newEventName, keys, values);
        }

        if (this.enableDebug)
            cc.log("GSAnalyticsAdapter event:" + GSAnalyticsAdapter.getNewEventName(event) + " ,keys:" + keys + " ,values:" + values);
    },

    logEventByAppsFlyerWithCounter: function (event) {
        if (cc.sys.isNative) {
            var key = GSAnalyticsAdapter.getNewEventName(event);
            var recordKey = this.RECORD_NAME + key;
            var count = parseInt(GS.localStorage.getItem(recordKey, 0, true));
            count++;
            count = count.toString();
            GS.localStorage.setItem(recordKey, count, true);
            GSAnalyticsAdapter.logEventByAppsFlyer(event, ["times"], [count]);
        }

        if (this.enableDebug)
            cc.log("GSAnalyticsAdapter logEventByAppsFlyerWithCounter event:" + event);
    },

    /**
     * 追蹤purchase event
     */
    logEventPurchaseByAppsFlyer: function (jsonString) {
        if (cc.sys.isNative)
            GSAppsFlyer.logEventPurchase(jsonString);

        if (this.enableDebug)
            cc.log("GSAnalyticsAdapter logEventPurchaseByAppsFlyer jsonString:" + jsonString);
    },

    /**
     * Firebase & GSAppsFlyer
     */
    logEventByBoth: function (event, keys, values) {
        this.logEventByFirebase(keys, values);
        this.logEventByAppsFlyer(event, keys, values);
    },

    /**
     * 依遊戲改變事件名稱
     */
    getNewEventName: function (event) {
        var newEventName = event;
        switch (GS.nowGame) {
            case GSEnum.Game.MJ_16:
                newEventName = "16mj_" + event;
                break;
            case GSEnum.Game.MJ_13:
                newEventName = "13mj_" + event;
                break;
            case GSEnum.Game.BIGTWO:
                newEventName = "big2_" + event;
                break;
            case GSEnum.Game.BIGTWOD:
                newEventName = "big2D_" + event;
                break;
            case GSEnum.Game.SEVENS:
                newEventName = "7s_" + event;
                break;
            case GSEnum.Game.POKER13:
                newEventName = "13poker_" + event;
                break;
            case GSEnum.Game.LANDLORD:
                newEventName = "landlord_" + event;
                break;
            case GSEnum.Game.TEXAS:
                if (GS.isContainer)
                    newEventName = "9T_" + event;
                else
                    newEventName = event;
                break;
            default:
                break;
        }
        return newEventName;
    },

    /**
     * 抓取Firebase GA的Client ID
     */
    getFirebaseGAClientID: function () {
        if (cc.sys.isNative)
            return "";
        else
            return this._firebaseClientId || "";
    },
};