/**
 * v5.6.6 轉輪大狂歡 - 創轉輪的node
 * created by Richie.
 *
 *       原本                 交換調整後
 *   2(橘) → 1(紫)          1(紫) ← 2(橘)
 *      ↖    ↙       =>       ↘     ↗
 *       0(綠)                  0(綠)
 * 只有資料被對調 外面index依照原本順序 要特別注意!!
 *
 * v5.6.6 移植 by tony.cheng
 */
var CarnivalWheelPackWheelItemNode = CircularViewItemNode.extend({
    ctor: function (data, type) {
        this._super();
        // 為了畫面擺放順序是順時針 把原先1跟2的資料交換
        // Texas_CircularView 目前只能逆時針擺放
        let index;
        switch (type) {
            case CarnivalWheelPackWheelNode.Level.SECOND:
                index = 2;
                break;
            case CarnivalWheelPackWheelNode.Level.THIRD:
                index = 1;
                break;
            default:
                index = type;
                break;
        }

        // 確認目前是否有已經轉過的輪子結果
        let nowStep = data.step;
        let step = index + 1;
        let target = (nowStep > step) ? data.targetRecord[index] : data.wheelTarget;
        let scale = nowStep === step ? 0.8 : 0.6;

        let wheelParam = {
            wheelStep: step,                    // 第幾階段的轉輪
            nowStep: nowStep,                   // 當前進行階段
            wheelTarget: target,                // 要轉到哪裡
            wheelList: data.wheelList[index],   // 轉輪內容
            payMoney: data.payMoney,            // 儲值金額
        };

        // 輪盤
        let wheelCarnival = new CarnivalWheelPackWheelNode(wheelParam);
        wheelCarnival.setScale(scale);
        if (nowStep !== step) {
            wheelCarnival.setColor(JSColor.GRAY);
        }

        this.addChild(wheelCarnival);

        // 讓玩家可以自己按
        this._wheel = wheelCarnival;
    },

    getWheel: function () {
        return this._wheel;
    }
});