var Cangkulan_GameUtility = {};

/*
 位置順序圖

       2
 1            3
     0(玩家)
 */

(function () {
    // 玩家位置 (先產生好 之後要加上JSScreenBonus 這樣可以減省掉每次都要產生多次的cc.p)
    var GAME_PLAYER_POSITION = [
        cc.p(107, 38),
        cc.p(54, 156),
        cc.p(256, 260),
        cc.p(458, 156),
    ];

    // 發牌到玩家的位置 (先產生好 之後要加上JSScreenBonus 這樣可以減省掉每次都要產生多次的cc.p)
    var GAME_DEAL_CARD_POSITION = [
        cc.p(138, 51),
        cc.p(93, 126),
        cc.p(200, 230),
        cc.p(402, 126),
    ];

    // 莊家圖片的位置 (先產生好 之後要加上JSScreenBonus 這樣可以減省掉每次都要產生多次的cc.p)
    var GAME_DEAL_IMAGE_POSITION = [
        cc.p(83, 55),
        cc.p(99, 146),
        cc.p(256, 205),
        cc.p(413, 146),
    ];

    /**
     * 回傳玩家大頭貼的位置 <br/>
     * @param {sitNum} 畫面上的位置 <br/>
     */
    Cangkulan_GameUtility.getPlayerPosition = function (sitNum) {
        // -1是荷官
        if (parseInt(sitNum) === -1) {
            return cc.p(JSScreenMidPos.x, 238 + JSScreenBonusHalfHeight);
        }

        // 其他位置
        var originPos = GAME_PLAYER_POSITION[sitNum];
        var bonusHeight = 0;
        switch (sitNum) {
            case 0:
                bonusHeight = 0;
                break;
            case 2:
                bonusHeight = JSScreenBonusHeight;
                break;
            default:
                bonusHeight = JSScreenBonusHalfHeight;
                break;
        }
        return cc.p(originPos.x + JSScreenBonusHalfWidth, originPos.y + bonusHeight);
    };

    /**
     * 回傳玩家發牌的位置 <br/>
     * @param {sitNum} 畫面上的位置 <br/>
     */
    Cangkulan_GameUtility.getDealCardPosition = function (sitNum) {
        var originPos = GAME_DEAL_CARD_POSITION[sitNum];
        var bonusHeight = sitNum === 0
            ? 0
            : sitNum === 2 ? JSScreenBonusHeight : JSScreenBonusHalfHeight;
        return cc.p(originPos.x + JSScreenBonusHalfWidth, originPos.y + bonusHeight);
    };

    /**
     * 回傳這一局的Dealer的位置(黑色底圖上面有一個"D") <br/>
     * @param {sitNum} 畫面上的位置
     */
    Cangkulan_GameUtility.getDealerPosition = function (sitNum) {
        var originPos = GAME_DEAL_IMAGE_POSITION[sitNum];
        var bonusHeight = sitNum === 0
            ? 0
            : sitNum === 2 ? JSScreenBonusHeight : JSScreenBonusHalfHeight;
        return cc.p(originPos.x + JSScreenBonusHalfWidth, originPos.y + bonusHeight);
    };

    /**
     * 回傳多少錢籌碼應該要是什麼顏色 <br/>
     * @param {money} 多少錢
     */
    Cangkulan_GameUtility.getChipImage = function (money) {
        var image;
        if (money < 1000)
            image = "#game_pic_chips01.png";
        else if (money < 10000)
            image = "#game_pic_chips02.png";
        else if (money < 100000)
            image = "#game_pic_chips03.png";
        else if (money < 1000000)
            image = "#game_pic_chips04.png";
        else if (money < 10000000)
            image = "#game_pic_chips05.png";
        else
            image = "#game_pic_chips06.png";

        return image;
    };

    /**
     * 判斷兩張點數是否一模一樣
     */
    Cangkulan_GameUtility.isSameNumber = function (number1, number2) {
        return number1[0] === number2[0] && number1[1] === number2[1] ||
            number1[0] === number2[1] && number1[1] === number2[0];
    };

})();
