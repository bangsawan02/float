/**
 * v5.5.2 分身模組 - 關閉/領獎 Dialog
 * created by Jim.chen
 */
var CloneModelRewardDialog = BaseDialogLayer.extend({
    ctor: function (msgArray) {
        // 先做繼承的東西
        this._super();

        this.key = "CloneModelRewardDialog";
        this.isLockBackKey = true;
        this.dialogBgColor = cc.color(0, 0, 0, 240);

        this._msgArray = msgArray;              // 獎勵陣列

        this.loadFileArray = [
            "cloneModel/cloneModel.plist", "cloneModel/cloneModel.png",
            SelectGameManager.getNowGameFile("cloneModel.plist", "cloneModel/"), SelectGameManager.getNowGameFile("cloneModel.png", "cloneModel/")
        ];
    },

    onExit: function () {
        // 移除圖檔
        if (this._loadFileDone) {
            for (let i = 0; i < this.loadFileArray.length; i += 2)
                cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[i]);
        }

        this._super();
    },

    loadFileDone: function () {
        this._super();

        // 加圖檔
        for (let i = 0; i < this.loadFileArray.length; i += 2)
            cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[i], this.loadFileArray[i + 1]);

        var aniLayer = this._animationLayer;

        // 背景光
        var blueSp = new cc.Sprite("#lobby_pic_light_blue.png");
        blueSp.setFlippedY(true);
        blueSp.setScale(0.8, 5);
        blueSp.setPosition(JSScreenMidPos.x, 230 + JSScreenBonusHalfHeight);
        aniLayer.addChild(blueSp);

        // 一些光點
        [
            {pos: cc.p(144, 105)},
            {pos: cc.p(362, 196)},
        ].forEach((cur) => {
            var bulbSp = new cc.Sprite("#cloneModel_pic_spot.png");
            bulbSp.setPosition(cur.pos.x + JSScreenBonusHalfWidth, cur.pos.y + JSScreenBonusHalfHeight);
            aniLayer.addChild(bulbSp);
        });

        // 背景
        for (var i = 0; i < 2; i++) {
            var bgSp = new ccui.Scale9Sprite("cloneModel_bg_window_1.png");
            bgSp.setPreferredSize(cc.size(131, 179));
            bgSp.setAnchorPoint(i, 0.5);
            bgSp.setFlippedX(!i)
            bgSp.setPosition(JSScreenMidPos.x - 0.5 + i, JSScreenMidPos.y);
            aniLayer.addChild(bgSp);
        }

        // 創獎勵內容
        var msgArray = this._msgArray;
        if (JSCodeUtility.isArray(this._msgArray) && msgArray.length > 0) {
            if (msgArray.length === 1) {
                // 單一獎勵
                var rewardLabel = new cc.LabelTTF(JSStringUtility.format(LocalizedString.Purchase("累積獎勵\n%s"), msgArray[0]), JSFontBoldName, 12, cc.size(0, 0), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
                rewardLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y);
                aniLayer.addChild(rewardLabel);
            } else {
                // 多獎項，創可滑動區域
                var brownBgSp = new ccui.Scale9Sprite("cloneModel_bg_window_5.png", cc.rect(5, 6, 22, 50));
                brownBgSp.setPreferredSize(cc.size(180, 62));
                brownBgSp.setPosition(JSScreenMidPos.x, 140 + JSScreenBonusHalfHeight);
                aniLayer.addChild(brownBgSp);

                // 加ScrollView
                var scrollViewSize = this._scrollViewSize = cc.size(165, 48);
                var mainLayer = this._mainLayer = new cc.Layer();
                var scrollView = this._scrollview = new cc.ScrollView(scrollViewSize, mainLayer);
                scrollView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
                scrollView.setPosition(175 + JSScreenBonusHalfWidth, 116 + JSScreenBonusHalfHeight);
                aniLayer.addChild(scrollView);

                // 文字排版的node
                var layoutNode = new GSAutoLayoutNode();
                layoutNode.setType(GSAutoLayout.TYPE.VERTICAL);
                layoutNode.setAnchorPoint(0, 0);
                mainLayer.addChild(layoutNode);

                // 創文字
                var totalHeight = 0;
                msgArray.forEach(cur => {
                    // 內文
                    var messageLabel = new GSRichTextNode(cur, JSFontName, 9, cc.size(scrollViewSize.width, 0));
                    messageLabel.setHAlignmentToCenter(true);
                    layoutNode.addChild(messageLabel);

                    // 算高度
                    totalHeight += messageLabel.getContentSize().height;
                });

                // 設置scrollView大小
                scrollView.setContentSize(scrollViewSize.width, totalHeight);
                // 是否要滑動
                scrollView.setTouchEnabled(totalHeight >= scrollViewSize.height);
                // 跑到最上面
                scrollView.setContentOffset(scrollView.minContainerOffset());
            }
        }

        // 標題
        var titleSp = new cc.Sprite("#cloneModel_word_Lucky_Chip.png");
        titleSp.setPosition(JSScreenMidPos.x, 204 + JSScreenBonusHalfHeight);
        aniLayer.addChild(titleSp);

        // 確認按鈕
        var okButton = new Texas_Button(Texas_Button.Style.YELLOW, cc.size(92, 39), LocalizedString.Common("確認"), JSColor.BLACK, 14);
        okButton.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 62);
        okButton.addTouchUpInsideAction(this._closeDialogAnimation, this);
        aniLayer.addChild(okButton);
    },
});