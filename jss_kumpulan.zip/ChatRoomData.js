/**
 * 聊天的資料
 *
 * 有好友/公會/優惠券通知
 */
var ChatRoomData = cc.Class.extend({
    ctor: function () {

        this.clean();

        // 註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            // 好友聊天
            "mixFriend_say_list": this.cmd_mixFriend_say_list,
            "mixFriend_say_history": this.cmd_mixFriend_say_history,
            "mixFriend_say": this.cmd_mixFriend_say,
            "mixFriend_say_delete": this.cmd_mixFriend_say_delete,

            // 公會聊天
            "guild_say_history": this.cmd_guild_say_history,
            "guild_say": this.cmd_guild_say,

            // 優惠通知
            "chatroom_coupon": this.cmd_chatroom_coupon,
            "chatroom_coupon_reset": this.cmd_chatroom_coupon_reset,
        });
    },

    clean: function () {
        // 好友聊天列表
        this.friendChatRoomList = [];

        // 好友聊天記錄
        this.friendChatParam = {};

        // 正在聊天對象的UID & userID & nickname
        this.friendChatUID = "";
        this.friendChatUesrID = "";
        this.friendChatNickname = "";

        // 聊天浮動icon的小紅點
        this.friendChatIconRedPoint = false;

        // 需不需要去重要聊天室的清單
        this.isNewOtherMsg = true;

        // 送出訊息的編號
        this._sendMsgNum = 0;

        // 公會聊天的東西
        this.guildChatRedPoint = false;
        this.minimumGuildSerialNum = 0;
        this.guildChatHistory = [];
        this.isCanLoadGuildHistory = true;

        // 優惠卷
        // 副系統道具優惠券
        this._couponList = [];
        // 聊天室顯示的優惠券(副系統道具優惠券 + 一般儲值中心使用的優惠券)
        this.discountList = [];
        this.couponImgURL = GS.httpScheme + "//g.mwsrv.com/19_60/store/iapp/download/multi/HD/";
    },

    /**
     * 清掉聊天頁面的設定 (玩家在聊天室內點返回)
     */
    cleanChatUser: function () {
        this.friendChatUID = "";
        this.friendChatUesrID = "";
        this.friendChatNickname = "";
    },

    // 單獨清掉公會紀錄(退出公會)
    cleanGuildChatHistory: function () {
        this.guildChatRedPoint = false;
        this.minimumGuildSerialNum = 0;
        this.guildChatHistory = [];
        this.isCanLoadGuildHistory = true;
    },

    /**
     * 送聊天室優惠券cmd
     */
    startGetChatRoomDiscountInfo: function () {
        DataProcess.sendString("chatroom_coupon");
    },

    /**
     * 刷新聊天室優惠券
     * 副系統道具優惠券會從cmd chatroom_coupon取得
     * 一般優惠券(商城使用)會從 cmd coupon_assemble
     * 上面兩個cmd收到都會來刷新這邊的清單
     */
    refreshDiscountList: function () {
        this.discountList = [];

        // 一般優惠券(包裝一下讓他可以跟chatroom_coupon格式一致)
        var couponAssembleList = DataModal.purchaseCouponData.couponAssemble;
        if (JSCodeUtility.isArray(couponAssembleList) && couponAssembleList.length > 0) {
            var couponList = couponAssembleList.filter(cur => {
                // 已經儲值過但未領取獎勵的優惠券要排除掉
                if (!cur.isCanGetReward) {
                    // 優惠券的icon寫死用德撲幣的圖
                    cur.wid = 5054;
                    // 因為pm說文案不會變server沒有多一個新key所以由client判斷是不是數字
                    // 如果這邊pm有常改文案還是要請server給文案比較方便...
                    if (!isNaN(parseFloat(cur.bonus)) && isFinite(cur.bonus))
                        // 數字 優惠加贈 +XXX%
                        cur.message = LocalizedString.PurchaseCoupon("優惠加贈") + " +" + cur.bonus + "%";
                    else
                        // 文字 優惠加贈 XXXX
                        cur.message = LocalizedString.PurchaseCoupon("優惠加贈") + " " + cur.bonus;

                    // 引導路徑 優惠券統一走儲值中心
                    cur.bannerType = LobbyBannerMode.Purchase;

                    return cur;
                }
            });

            // 1 埋點 獲得優惠訊息不重覆人數(pm說獲得就算)
            DataProcess.sendString("track_chat_room_coupon 1");
        } else {
            couponList = [];
        }

        // 副系統道具or優惠券
        this.discountList = couponList.concat(this._couponList);

        // 依照獲得時間先排序(時間大(新)->時間小(舊))
        this.discountList.sort((a, b) => b.getTime - a.getTime);

        // 刷新聊天室優惠券UI
        GS.dispatchCustomEvent("NotifyChatRoomDiscountDone");
    },

    /**
     * 開啟聊天頁面時要先拿一次聊天記錄＆設定該聊天頁面的資料
     * @param uid       聊天對象的uid
     * @param userID    聊天對象的userID
     * @param nickname  聊天對象的nickname
     */
    checkHaveChatList: function (UID, userID, nickname) {
        this.friendChatUID = UID;
        this.friendChatUesrID = userID;
        this.friendChatNickname = nickname;
        if (!this.friendChatParam[UID]) {
            // 第一次拿該好友的聊天記錄
            // 初始化聊天記錄
            var chatParam = this.friendChatParam[UID] = {};
            chatParam.chatList = [];

            //聊天清單的長度
            chatParam.chatListLen = 0;

            // 正在聊天的對象最舊的訊息編號(預設-1沒有歷史編號)
            chatParam.minHistoryNum = -1;
            chatParam.isCanLoadHistory = false;

            this.sendFriendChatListCmd(1, false);
        }
        // 通知server進入聊天室了
        this.sendHaveReadCmd(1);
    },

    /**
     * 確認聊天icon紅點有沒有消失
     */
    checkChatIconRedPoint: function () {
        if (this.friendChatRoomList) {
            this.friendChatIconRedPoint = this.friendChatRoomList.find(cur => {
                return cur.replace === true;
            });
        }
        GS.dispatchCustomEvent("NotifyFriendChatRoomListDone");
    },

    /**
     * 確認優惠券紅點
     */
    getDiscountRedPoint: function () {
        // 把優惠券都記在本地
        var localStorageKey = "ChatRoomDiscount_" + DataModal.profileData.account;
        var getDiscountList = JSON.parse(GS.localStorage.getItem(localStorageKey, "[]", true));

        if (getDiscountList.length === 0) {
            // 沒有舊的優惠券 只要有收到新的就亮紅點
            return this.discountList.length > 0;
        } else {
            this.discountList.forEach(curDiscount => {
                if (curDiscount.id) {
                    // 優惠券 獲得的時候亮一次
                    if (getDiscountList.findIndex(cur => cur.id === curDiscount.id) === -1)
                        return true;
                } else {
                    // 道具 每天都需要亮一次 (多判斷時間)
                    if (getDiscountList.findIndex(cur => cur.fid === curDiscount.fid && cur.time !== curDiscount.time) === -1)
                        return true;
                }
            });

            return false;
        }
    },

    /**
     * 設定優惠券小紅點
     */
    setDiscountRedPoint: function () {
        // 把優惠券都記在本地
        var setDiscountList = this.discountList.map(cur => {
            var obj = {};
            if (cur.id) {
                // 優惠券 獲得的時候亮一次
                obj.id = cur.id;
            } else {
                // 道具fid 每天都需要亮一次
                obj.fid = cur.fid;
                obj.time = JSCodeUtility.getNowDateString("%Y%02m%02d");
            }

            return obj;
        });

        var localStorageKey = "ChatRoomDiscount_" + DataModal.profileData.account;
        GS.localStorage.setItem(localStorageKey, JSON.stringify(setDiscountList), true);
    },

    /**
     * 更新聊天室清單的小紅點
     * @param uid
     * @param isShow 要不要show紅點
     */
    updateChatRoomListRedPoint: function (UID, isShow) {
        var index = this.friendChatRoomList.map(cur => {
            return cur.UID;
        }).indexOf(UID);

        if (index >= 0) {
            this.friendChatRoomList[index].redPoint = isShow;
            GS.dispatchCustomEvent("NotifyUpdateFriendChatRoomList", index);
        } else {
            // 不在聊天清單中 重送cmd
            this.isNewOtherMsg = true;
        }
    },

    /**
     * 送出聊天室清單
     */
    sendFriendChatRoomListCmd: function (isSendString) {
        // 確認需不需要重要清單
        if (this.isNewOtherMsg || isSendString)
            DataProcess.sendString("mixFriend_say_list");

        this.isNewOtherMsg = false;
    },

    /**
     * 送出要取得的好友聊天記錄
     * @param num: 最後記錄到哪個num
     * @param isBefore: true: 從num往前25筆  false: 從num往後25筆
     */
    sendFriendChatListCmd: function (num, isBefore) {
        var obj = {
            uid: this.friendChatUID,
            userid: this.friendChatUesrID
        };

        if (isBefore)
            obj.beforeNum = num;
        else
            obj.afterNum = num;
        DataProcess.sendString("mixFriend_say_history " + JSON.stringify(obj));
    },

    /**
     * 送聊天訊息給server
     * @param type 1:文字訊息 2:貼圖
     * @param msg  訊息
     */
    sendFriendChatMessageCmd: function (type, msg) {
        this._sendMsgNum++;

        var height = this.getMessageHeight(type, msg);

        var chatParam = this.friendChatParam[this.friendChatUID];
        var waitParam = {
            type: type,
            message: msg,
            serialNum: -1,
            time: 0,
            msgHeight: height,
            cellHeight: height + 5,
            isMe: true,
            sendMsgNum: this._sendMsgNum
        };
        // 先把送出的訊息丟到清單中
        chatParam.chatList.push(waitParam);
        chatParam.chatListLen++;

        var sendParam = {
            type: type,
            uid: this.friendChatUID,
            userid: this.friendChatUesrID,
            msg: encodeURIComponent(msg),
            sendMsgNum: this._sendMsgNum
        };
        DataProcess.sendString("mixFriend_say " + JSON.stringify(sendParam));

        // 把訊息insert在最後面
        GS.dispatchCustomEvent("NotifyUpdateFriendChatList", chatParam.chatListLen - 1);

        // AppsFlyer 互動道具、表情、對話功能 (累加)
        GameAppsFlyerTracker.trackByGameName("interacttool");
    },

    /**
     * 送已讀的cmd給server
     * @param inRoom 0:離開聊天頁面 1:進入聊天頁面
     */
    sendHaveReadCmd: function (inRoom) {
        if (!this.friendChatUID)
            return;

        var obj = {
            uid: this.friendChatUID,
            inRoom: inRoom
        };
        DataProcess.sendString("mixFriend_say_isRoom " + JSON.stringify(obj));
    },

    /**
     * 取回包含中文的長度 用來算幾個中文字
     * @param str
     * @returns {number}
     * @private
     */
    _getStrLen: function (str) {
        return str.replace(/[^\x00-\xff]/g, "xx").length;
    },

    /**
     * 取得訊息的高
     * @param type : 訊息總類
     * @param msg  : 訊息
     */
    getMessageHeight: function (type, msg) {
        // 文字單行最大數量(英文）
        var maxENLineCount = 24;
        // 文字單行最大數量(中文)
        var maxCHLineCount = 15;

        // 單行文字高度
        var height = 30;

        switch (type) {
            case ChatRoomData.MessageType.Label:
                // 文字

                // 文字長度
                var msgLen = msg.length;
                // 文字長度（包含中文)
                var mixlen = this._getStrLen(msg);

                // 中文個數
                var chNum = mixlen - msgLen;
                // 英文個數
                var enNum = msgLen - chNum;

                var line = 0;
                // 文字有中文字
                if (chNum > 0) {
                    // 中文最多15個字一行
                    var chLine = Math.floor(chNum / maxCHLineCount);
                    // 英文最多25個字一行
                    var enLine = Math.floor(enNum / maxENLineCount);

                    if (chLine === 0 && enLine === 0) {
                        // 中英混合最大的單行數量
                        var change = Math.ceil(enNum / 2);
                        var sum = chNum + change;
                        line = (sum > 15) ? 1 : 0;
                    } else
                        line = chLine + enLine;

                } else
                    line = Math.floor(msgLen / maxENLineCount);

                height += (line * 13);
                break;
            case ChatRoomData.MessageType.Emoticons:
                // 貼圖
                height = 59;
                break;
        }

        return height;
    },

    // 送出公會歷史聊天
    getGuildChatHistory: function () {
        // 代表目前沒有歷史訊息
        if (this.minimumGuildSerialNum === 0) {
            let serial = {"serialNum": 0};
            DataProcess.sendString("guild_say_history " + JSON.stringify(serial));
        }
    },

    // 設定一個行寬，取得行高
    getWordSizeByLimitWidth: function (msg, limitWidth) {
        var wordSize = {};
        // 初始計算行寬為0
        var lineWidth = 0;

        // 初始行數至少有一行
        var totalLine = 1;

        // 判斷一串文字 有沒有被空白隔開的單詞
        var splitMsgArray = msg.split(" ");
        splitMsgArray.forEach(cur => {
            var calcLabel = new cc.LabelTTF(cur, JSFontName, 12);
            var calcWidth = calcLabel.width;

            // 這個單字 + 上一個單詞 + 一個空白為4px 不超過120就不用換行
            if (Math.floor(lineWidth + calcWidth + 4) <= (limitWidth - 5)) {
                // 當前加上 這次的單詞寬度 + 一個空白為4px
                lineWidth += (calcWidth + 4);
                // 比較目前最大行寬
                wordSize.msgWidth = (wordSize.msgWidth > lineWidth) ? wordSize.msgWidth : lineWidth;
            } else {
                // 假如換行之後 這個單詞自己就超過120 代表需要複數行才能容納
                if (Math.floor(calcWidth) >= (limitWidth - 5)) {
                    // 直接設定為最大行寬120
                    wordSize.msgWidth = limitWidth;

                    // 換算這個單詞需要幾行並加上去 因為系統有時候判斷換行但在視覺上有一點超過 用110計算避免少一行的空間
                    totalLine += Math.round(calcWidth / (limitWidth - 5));
                    // 假如沒有空白是ㄧ整串字 算出來的行數要扣掉初始值1
                    if (splitMsgArray.length === 1)
                        totalLine--;
                    // 最新ㄧ行 佔用了多少寬度
                    lineWidth = Math.ceil(calcWidth % limitWidth);
                } else {
                    // 超過最大行寬 加一行數
                    totalLine++;
                    // 記下當前行寬
                    lineWidth = calcWidth;
                    // 比較目前最大行寬
                    wordSize.msgWidth = (wordSize.msgWidth > lineWidth) ? wordSize.msgWidth : lineWidth;
                }
            }
        });

        // 訊息高度 = 行高12 x 行數
        wordSize.msgHeight = 12 * totalLine;

        return wordSize;
    },

    // 公會聊天室規格 回傳obj = {msgHeight: 訊息高度, msgWidth: 訊息寬度, cellHeight: 整個cell高度}
    getGuildChatCellFormat: function (type, msg, isShowDate, isOldest) {
        // 聊天室的寬度為 173
        var formatParam = {};
        formatParam.msgHeight = 0;
        formatParam.msgWidth = 0;
        formatParam.cellHeight = 0;

        switch (type) {
            case ChatRoomData.MessageType.Emoticons: {
                // cell高度預設75
                formatParam.cellHeight = 75;

                // 假如有顯示 日期(上一則訊息日期跟這則不一樣) 或 最上方需要顯示提示(只有當前最舊的訊息需要) 要增加cell高度
                if (isShowDate && isOldest)
                    formatParam.cellHeight += 25;
                if (isShowDate ^ isOldest)
                    formatParam.cellHeight += 18;

                break;
            }
            case ChatRoomData.MessageType.System:
            case ChatRoomData.MessageType.System_Special: {
                // 系統訊息預設165
                var wordSize = this.getWordSizeByLimitWidth(msg, 155);
                formatParam.msgWidth = 160;
                formatParam.msgHeight = wordSize.msgHeight;

                // cell高度 = 訊息高度 + 10
                formatParam.cellHeight = formatParam.msgHeight + 10;

                // 假如有顯示 日期(上一則訊息日期跟這則不一樣) 或 最上方需要顯示提示(只有當前最舊的訊息需要) 要增加cell高度
                if (isShowDate)
                    formatParam.cellHeight += 20;
                if (isOldest)
                    formatParam.cellHeight += 14;

                break;
            }

            case ChatRoomData.MessageType.Label: {
                // 一般訊息預設最寬120
                var wordSize = this.getWordSizeByLimitWidth(msg, 117);
                formatParam.msgWidth = wordSize.msgWidth;
                formatParam.msgHeight = wordSize.msgHeight;

                // 最後設定訊息寬度最小值12 最大值120 (為了防止 判斷換行會有誤差 訊息太短使圖片看起來很醜)
                formatParam.msgWidth = (formatParam.msgWidth > 114) ? 120 : formatParam.msgWidth;
                formatParam.msgWidth = (formatParam.msgWidth <= 12) ? 12 : formatParam.msgWidth;

                // cell高度 = 訊息高度 + 暱稱跟間距20
                formatParam.cellHeight = formatParam.msgHeight + 25;

                // cell 高度至少要60 不然大頭貼會被遮住
                formatParam.cellHeight = (formatParam.cellHeight <= 60) ? 60 : formatParam.cellHeight;

                // 假如有顯示 日期(上一則訊息日期跟這則不一樣) 或 最上方需要顯示提示(只有當前最舊的訊息需要) 要增加cell高度
                if (isShowDate)
                    formatParam.cellHeight += 14;
                if (isOldest)
                    formatParam.cellHeight += 14;

                break;
            }

        }
        return formatParam;
    },

    /**
     * 取得時間
     * @param time server給的時間
     * 回傳
     * timeObj = {
     *    time: xx:xx
     *    date: month * 100 + day
     * }
     */
    getTime: function (time) {
        // 毫秒*1000
        var dateObj = (time === 0) ? new Date() : new Date(time * 1000);

        var month = dateObj.getMonth() + 1;
        var day = dateObj.getDate();

        return {
            time: JSStringUtility.format("%02d:%02d", dateObj.getHours(), dateObj.getMinutes()),
            date: month * 100 + day
        };
    },

    /**
     * 好友聊天列表
     * [{
     *      "notRead":"1",
     *      "pic":"http://d.mwsrv.com/texas9/images/default_pic/photo_f-1.png",
     *      "uid":"12771832",
     *      "nickname":"ariestest",
     *      "userid":"a96184155@an"
     *  },
     *  {
     *      "pic":"http://d.mwsrv.com/texas9/images/default_pic/photo_m-4.png",
     *      "uid":"12923919",
     *      "userid":"c29584511@an",
     *      "nickname":"c29584511"
     * }]
     */
    cmd_mixFriend_say_list: function (key, value) {
        var jsonValue = JSON.parse(value);

        this.friendChatRoomList = [];

        var redPoint = false;

        jsonValue.forEach(cur => {
            var userId = JSCodeUtility.getStringValue(cur["userid"]);

            var friendInfo = {};

            // nickname
            friendInfo.nickname = JSCodeUtility.getStringValue(cur["nickname"]);

            // userID
            friendInfo.userID = userId;

            // uid
            friendInfo.UID = JSCodeUtility.getStringValue(cur["uid"]);

            // 大頭貼
            friendInfo.photo = JSCodeUtility.getStringValue(cur["pic"]);

            // 小紅點
            friendInfo.redPoint = JSCodeUtility.getIntValue(cur["notRead"]) === 1;

            if (!redPoint && friendInfo.redPoint)
                redPoint = true;

            this.friendChatRoomList.push(friendInfo);
        });

        // 浮動icon的小紅點
        this.friendChatIconRedPoint = redPoint;

        GS.dispatchCustomEvent("NotifyFriendChatRoomListDone");
    },

    /**
     * 聊天訊息
     *{
     *   "serialNum":"9260",    # 訊息編號
     *   "type":"1",            # 訊息種類 1:文字 2:貼圖
     *   "time":"1583569441",   # 訊息時間
     *   "sendMsgNum":"1",      # 自己送出的訊息編號 (自己送出的訊息才會有這個資料)
     *   "message":"哈囉哈囉",
     *   "code":"1",            # 是否成功 (自己送出的訊息才會有這個資料)
     *   "sender":"13733936"    # 訊息送出者
     *   "friend":"13733000"    # 自己送出的訊息要給誰(自己送出的訊息才會有這個資)
     *}
     */
    cmd_mixFriend_say: function (key, value) {
        var jsonValue = JSON.parse(value);

        var param = {};

        // 是不是自己送出的訊息
        var isMe = JSCodeUtility.getIntValue(jsonValue["code"]) === 1;
        param.isMe = isMe;

        // 只有自己送出的訊息會收到這個資料 該筆訊息屬於哪個好友
        var friend = JSCodeUtility.getStringValue(jsonValue["friend"]);

        // 訊息送出者
        var senderUID = JSCodeUtility.getStringValue(jsonValue["sender"]);

        if (!isMe) {
            if (!this.friendChatIconRedPoint) {
                // 其他玩家有送訊息 打開icon的紅點
                this.friendChatIconRedPoint = true;
                GS.dispatchCustomEvent("NotifyUpdateChatRoomIcon");
            }

            // 不是正在聊天的玩家
            if (this.friendChatUID !== senderUID)
                this.updateChatRoomListRedPoint(senderUID, true);

            // 沒有拿過該玩家的紀錄(等玩家點開聊天室再一起確認一次)
            if (!this.friendChatParam[senderUID])
                return;
        }

        // 訊息的type
        var type = JSCodeUtility.getIntValue(jsonValue["type"]);
        param.type = type;

        // 訊息
        param.message = JSCodeUtility.getStringValue(jsonValue["message"]);

        // 訊息的編號
        param.serialNum = JSCodeUtility.getIntValue(jsonValue["serialNum"]);

        // 訊息的時間
        var time = param.utime = JSCodeUtility.getIntValue(jsonValue["time"]);
        var timeObj = this.getTime(time);

        // 訊息的日期
        param.date = timeObj.date;

        // 訊息的時間 xx:xx
        param.time = timeObj.time;

        // 訊息尺寸
        var msgHeight = this.getMessageHeight(type, param.message);
        param.msgHeight = msgHeight;

        // cell的高度
        param.cellHeight = msgHeight + 5;

        // 需要被更新的聊天清單
        var updateUID = (isMe) ? friend : senderUID;

        // 更新聊天訊息
        var chatParam = this.friendChatParam[updateUID];
        var chatList = chatParam.chatList;

        // 是自己送出的訊息從清單中把等待的訊息移除
        var updateIndex = -1;
        if (chatParam.chatListLen > 0) {
            // 聊天中最後一個index
            var lastIndex = chatParam.chatListLen - 1;
            // 聊天清單中最後一筆的編號
            var lastChatSerialNum = chatList[lastIndex].serialNum;

            if (isMe) {
                var sendMsgNum = JSCodeUtility.getIntValue(jsonValue["sendMsgNum"]);
                // 因為新的訊息會放到最後這邊用倒敘找比較快
                for (var i = lastIndex; i >= 0; i--) {
                    if (sendMsgNum === chatList[i].sendMsgNum) {
                        chatList.splice(i, 1);
                        updateIndex = i;
                        chatParam.chatListLen--;
                        break;
                    }
                }
            }
        }

        // 是不是新的日期 新的日期要加上日期顯示
        if (chatParam.chatListLen === 0 || chatList[chatParam.chatListLen - 1].date !== param.date) {
            // 要show日期
            param.isShowDate = true;

            // 加上日期高度
            param.cellHeight = param.msgHeight + ChatRoomData.DATE_HEIGHT;

            // 開新的聊天室要去重要浮動icon的聊天列表
            this.isNewOtherMsg = true;
        }

        // 塞入訊息
        chatList.push(param);
        chatParam.chatListLen++;

        if (lastChatSerialNum > param.serialNum) {
            // 訊息需要從中間插入需要排序排序
            // 把沒有等到回應的訊息放到最後
            chatList.sort((a, b) => {
                return (a.serialNum === -1 || b.serialNum === -1) ? b.serialNum - a.serialNum : a.serialNum - b.serialNum;
            });

            // 做reload訊息
            updateIndex = -1;
        } else {
            // 按順序插入
            if (updateIndex === -1) {
                // 其他人送來的訊息
                // 直接新增
                updateIndex = lastIndex + 1;
            } else {
                // 自己送出的訊息
                // 不是最後一筆 需reload 訊息
                if (updateIndex !== lastIndex)
                    updateIndex = -1;
            }
        }


        // 當天送出的第一筆訊息是自己的有加上日期的高度(自己的訊息送出時已經設定了cell的高度須更新cell的高度)
        // updateCell無法更新cell高度 需做reloadData
        if (param.isShowDate && isMe)
            updateIndex = -1;

        // 更新正在聊天中玩家的訊息
        if (senderUID === this.friendChatUID || isMe)
            GS.dispatchCustomEvent("NotifyUpdateFriendChatList", updateIndex);
    },

    /**
     * 好友聊天記錄
     *
     * mixFriend_say_history
     * {
     *   "historyList":
     *   [{
     *      "type":"1",
     *      "message":"aaaaa",
     *      "serialNum":"48",
     *      "sender":"13733936",
     *      "time":"1582529069"
     *     },
     *     {
     *      "message":"\bdddd",
     *      "type":"1",
     *      "sender":"13733936",
     *      "serialNum":"97",
     *      "time":"1582532692"
     *     }],
     *     "user":"༼•͟ ͜ •༽",
     *     "Fuid":"14437398",
     *     "friend":"q55551648",
     *     "Fuserid":"q55551648@an"
     * }
     */
    cmd_mixFriend_say_history: function (key, value) {
        var jsonValue = JSON.parse(value);

        // 哪個玩家的聊天記錄
        var friendUID = JSCodeUtility.getIntValue(jsonValue["Fuid"]);

        var chatParam = this.friendChatParam[friendUID];
        var chatList = chatParam.chatList;

        // 拿舊的聊天記錄 重算cell的高度 把之前起點的日期扣回去
        if (chatList.length > 0) {
            chatList[0].cellHeight -= ChatRoomData.TIP_HEIGHT;
        }

        // 該玩家最舊的訊息編號
        var minHistoryNum = JSCodeUtility.getIntValue(jsonValue["minNum"]);
        if (minHistoryNum > 0)
            chatParam.minHistoryNum = minHistoryNum;

        // 歷史清單
        var jValue = jsonValue["historyList"] || [];
        jValue.forEach(cur => {
            var historyParam = {};

            // 訊息的type
            var type = JSCodeUtility.getIntValue(cur["type"]);
            historyParam.type = type;

            // 是不是自己的訊息
            var UID = JSCodeUtility.getIntValue(cur["sender"]);
            historyParam.isMe = friendUID !== UID;

            // 訊息
            historyParam.message = JSCodeUtility.getStringValue(cur["message"]);

            // 訊息的編號
            historyParam.serialNum = JSCodeUtility.getIntValue(cur["serialNum"]);

            // 訊息的時間 (server給的時間)
            var time = historyParam.utime = JSCodeUtility.getIntValue(cur["time"]);
            var timeObj = this.getTime(time);

            // 訊息的日期
            historyParam.date = timeObj.date;

            // 訊息的時間 xx:xx
            historyParam.time = timeObj.time;

            // 要不要顯示日期
            historyParam.isShowDate = false;

            // 訊息尺寸
            var msgSize = this.getMessageHeight(type, historyParam.message);
            historyParam.msgHeight = msgSize;

            // cell的高度
            historyParam.cellHeight = msgSize + 5;

            chatList.push(historyParam);
        });

        // 排序訊息
        chatList.sort((a, b) => {
            return a.serialNum - b.serialNum;
        });

        var chatListLen = chatParam.chatListLen = chatList.length;
        if (chatListLen > 0) {
            var chat = chatList[0];
            // 是否還有歷史紀錄可以load
            chatParam.isCanLoadHistory = chatParam.minHistoryNum > 0 && chatParam.minHistoryNum < chat.serialNum;

            // 第一個cell要顯示往下滑的提示要加大
            if (chatParam.isCanLoadHistory)
                chat.cellHeight += ChatRoomData.TIP_HEIGHT;

            // 塞入顯示date
            var startDate = chat.date;
            chatList.forEach(cur => {
                // 重新更新日期 之前有日期加大的要扣回去
                if (cur.isShowDate) {
                    cur.cellHeight -= ChatRoomData.DATE_HEIGHT;
                    cur.isShowDate = false;
                }

                if (startDate !== cur.date) {
                    // 下一個日期
                    cur.isShowDate = true;
                    // 加上日期的高度
                    cur.cellHeight += ChatRoomData.DATE_HEIGHT;
                    startDate = cur.date;
                }
            });

            // 最舊的資料塞入日期
            chat.isShowDate = true;
            chat.cellHeight += ChatRoomData.DATE_HEIGHT;
        }

        GS.dispatchCustomEvent("NotifyUpdateFriendChatList", -1);
    },

    // C->S cmd_mixFriend_say_delete {"uid":["18350639","22896376"]} #uid為被刪除者
    // S->C cmd_mixFriend_say_delete {"code":0} 0:失敗 1:成功
    // 刪除對話框
    cmd_mixFriend_say_delete: function (key, value) {

        GSLoading.removeLoadingView();

        var jsonValue = JSON.parse(value);

        var code = JSCodeUtility.getIntValue(jsonValue["code"]);
        var hintStr = (code === 1) ? "對話框刪除成功!" : "對話框刪除失敗，請稍後再試!";

        // 跳提示視窗
        DialogManager.addDialog(new Dialog({
            bgSize: cc.size(320, 200),
            content: LocalizedString.Friend(hintStr),
            btnImages: ["lobby_btn_01.png"],
            buttons: ["OK"],
            closeButton: 0,
        }), false);

        if (code === 1) {
            // 刪除成功/更新列表
            DataProcess.sendString("mixFriend_say_list");
        }
    },

    // 進入遊戲收取過去至今所有的的公會聊天紀錄
    cmd_guild_say_history: function (key, value) {
        var jsonValue = JSON.parse(value) || [];
        var historySize = 0;

        if (!Array.isArray(jsonValue))
            return;

        if (this.minimumGuildSerialNum === 0) {
            this.guildChatRedPoint = true;
            GS.dispatchCustomEvent("NotifyGuildChatRoomDone");
        }

        // 假如沒有歷史訊息了
        if (jsonValue.length === 0) {
            // 原本有訊息
            if (this.guildChatHistory[0]){
                // 要把往下滑獲取歷史訊息的提示關掉 要把多餘的高度扣回來
                this.guildChatHistory[0].isOldest = false;

                // 記下有東西要刷新
                historySize = -1;

                // 記下沒有資料了
                this.isCanLoadGuildHistory = false;
            }
        } else {
            jsonValue.forEach(cur => {
                var param = {};
                // MessageType 文字 貼圖 系統字
                param.type = JSCodeUtility.getIntValue(cur["type"]);
                // 暱稱
                param.nickName = JSCodeUtility.getStringValue(cur["nickName"]);
                // 玩家ID
                param.userID = JSCodeUtility.getStringValue(cur["userid"]);
                // 時間
                param.time = JSCodeUtility.getStringValue(cur["time"]);
                // 日期
                param.date = JSCodeUtility.getStringValue(cur["date"]);
                // 大頭貼
                param.pic = JSCodeUtility.getStringValue(cur["pic"]);
                // 訊息編號
                param.serialNum = JSCodeUtility.getIntValue(cur["serialNum"]);
                // 訊息
                param.message = JSCodeUtility.getStringValue(cur["message"]);

                historySize++;

                // 目前有歷史訊息 且 (當前訊息的日期 跟 上一條訊息的日期不同)
                if ((this.guildChatHistory.length > 0) && (param.date !== this.guildChatHistory[0].date))
                    this.guildChatHistory[0].isShowDate = true;

                // 假如是這次載入的最後一條 代表他是最舊的訊息
                if (historySize === jsonValue.length) {
                    // 設定是最舊的訊息
                    param.isOldest = true;
                    param.isShowDate = true;
                    // 之前最早的訊息編號要換新
                    this.minimumGuildSerialNum = param.serialNum;
                    if (this.guildChatHistory[historySize - 1])
                        this.guildChatHistory[historySize - 1].isOldest = false;
                }

                // 依序塞進最舊的
                this.guildChatHistory.splice(0, 0, param);
                this.isCanLoadGuildHistory = true;
            });
        }

        // 重整一次全部cell的尺寸大小
        this.guildChatHistory.forEach(cur => {
            var format = this.getGuildChatCellFormat(cur.type, cur.message, cur.isShowDate, cur.isOldest);
            // 整個訊息高度
            cur.cellHeight = format.cellHeight;
            // 對話泡泡高度
            cur.msgHeight = format.msgHeight;
            // 對話泡泡寬度
            cur.msgWidth = format.msgWidth;
        });

        GS.dispatchCustomEvent("NotifyUpdateGuildChatList", historySize);
    },

    // 公會聊天 單個訊息
    cmd_guild_say: function (key, value) {
        var jsonValue = JSON.parse(value) || [];

        // 假如server傳錯(不是array 或 array裡面沒東西) 就直接return
        if (!Array.isArray(jsonValue) || !jsonValue[0])
            return;

        var tmp = jsonValue[0];
        var param = {};
        // MessageType 文字 貼圖 系統字
        param.type = JSCodeUtility.getIntValue(tmp["type"]);
        // 暱稱
        param.nickName = JSCodeUtility.getStringValue(tmp["nickName"]);
        // 玩家ID
        param.userID = JSCodeUtility.getStringValue(tmp["userid"]);
        // 時間
        param.time = JSCodeUtility.getStringValue(tmp["time"]);
        // 日期
        param.date = JSCodeUtility.getStringValue(tmp["date"]);
        // 大頭貼
        param.pic = JSCodeUtility.getStringValue(tmp["pic"]);
        // 訊息編號
        param.serialNum = JSCodeUtility.getIntValue(tmp["serialNum"]);
        // 訊息
        param.message = JSCodeUtility.getStringValue(tmp["message"]);

        // 如果還沒有收到任何歷史資料 就記錄第一筆流水號 以防收到歷史資料後更新會重複顯示
        var historySize = this.guildChatHistory.length;
        if (historySize <= 0)
            this.minimumGuildSerialNum = param.serialNum;
        else {
            // 日期不同代表 這是當天的第一則訊息
            if (param.date !== this.guildChatHistory[historySize - 1].date)
                param.isShowDate = true;
        }

        // 如果是系統訊息 要另外看notRead (pm: 系統訊息的紅點提示是3個小時跳一次)
        if (param.type === ChatRoomData.MessageType.System || param.type === ChatRoomData.MessageType.System_Special)
            this.guildChatRedPoint = JSCodeUtility.getIntValue(tmp["notRead"]);
        else {
            // 其他玩家有送訊息 打開紅點提示
            if (DataModal.profileData.account !== param.userID)
                this.guildChatRedPoint = true;
        }

        var format = this.getGuildChatCellFormat(param.type, param.message, param.isShowDate);
        // 整個訊息高度
        param.cellHeight = format.cellHeight;
        // 對話泡泡高度
        param.msgHeight = format.msgHeight;
        // 對話泡泡寬度
        param.msgWidth = format.msgWidth;

        this.guildChatHistory.push(param);

        GS.dispatchCustomEvent("NotifyGuildChatRoomDone");
        GS.dispatchCustomEvent("NotifyUpdateGuildChatList", -1);
    },

    /**
     * 聊天室優惠通知頁面
     * c->s chatroom_coupon
     * s->c chatroom_coupon
     {
        "list":[
            {
                "time_left":"586536",
                "fid":"3818",
                "banner_type":186,
                "pic":"123",
                "notice":"123"
            },
            {...}
        ],
        "success":"1"
     }
     */
    cmd_chatroom_coupon: function (key, value) {
        var jsonValue = JSON.parse(value);

        this._couponList = [];

        if (JSCodeUtility.getBooleanValue(jsonValue["success"])) {
            this.couponImgURL = JSCodeUtility.getStringValue(jsonValue["img_url"]);

            this._couponList = (jsonValue["list"] || []).map(cur => {
                // 引導
                var bannerType = JSCodeUtility.getIntValue(cur["banner_type"]);

                // 送埋點(pm說獲得就算不用點開UI)
                switch (bannerType) {
                    case LobbyBannerMode.VegasCompete:
                        // 3 獲得爭霸賽加速器訊息不重覆人數
                        DataProcess.sendString("track_chat_room_coupon 3");
                        break;

                    case LobbyBannerMode.VegasRacing:
                        // 5 獲得極速競飆加速器訊息不重覆人數
                        DataProcess.sendString("track_chat_room_coupon 5");
                        break;
                }

                return {
                    // 圖片icon
                    wid: JSCodeUtility.getIntValue(cur["pic"]),
                    // 訊息
                    message: JSCodeUtility.getStringValue(cur["notice"]),
                    // 獲得時間
                    getTime: JSCodeUtility.getIntValue(cur["stime"]),
                    // 活動ID
                    fid: JSCodeUtility.getIntValue(cur["fid"]),
                    // 倒數時間
                    remainTime: JSCodeUtility.getIntValue(cur["time_left"]),
                    // 引導
                    bannerType: bannerType,

                    socketTime: JSCodeUtility.getNowTime(),
                };
            });
        }

        // 刷新清單
        this.refreshDiscountList();
    },

    /**
     * 聊天室優惠券通server通知刷新
     * server通知要刷新chatroom_coupon
     * S->C cmd_chatroom_coupon_reset
     */
    cmd_chatroom_coupon_reset: function () {
        // server通知要刷新 chatroom_coupon (副系統活動開啟時)
        this.startGetChatRoomDiscountInfo();
    }
});

// 訊息種類
ChatRoomData.MessageType = {
    Label: 1,           // 文字
    Emoticons: 2,       // 貼圖
    System: 3,          // 系統字
    System_Special: 5   // 特殊系統字
};

// 聊天內容文字提示的高度
ChatRoomData.TIP_HEIGHT = 15;
// 聊天內容日期的高度
ChatRoomData.DATE_HEIGHT = 13;