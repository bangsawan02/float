/**
 * Cangkulan 遊戲中左邊的積分系統 東西都放在Lobby的GameRank資料夾裡
 */

var Cangkulan_GameRankGameLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        var gameRankNode = this._gameRankNode = new GameRankGameNode();
        gameRankNode.setPosition(22 + JSScreenSafeWidth, 64);
        gameRankNode.setVisible(false);
        this.addChild(gameRankNode);
    },

    /**
     * 入桌階級顯示 用來第一次要不要出現Icon
     */
    cmd_gameRank_class: function (value) {
        this._gameRankNode.showViewByParam(value);
    },

    /**
     * 更新個人的階級
     */
    cmd_gameRank_update: function (value) {
        // {
        //        "score":"102",    #目前分數
        //        "ranking":"1",    #目前排名
        //        "class":"40",     #目前階級
        //        "addScore":"6",   #加幾分(輸了是負數)
        //        "classRise":"0",  #階級是否升階
        //        "classLower":"0"  #階級是否降階
        //        "rankRise":"0",   #排名是否上升
        //        "rankLower":"0",  #排名是否下降
        // }
        if (!this._gameRankNode.isVisible())
            return;

        var jsonValue = JSON.parse(value);

        // 目前排名
        var rankNumber = JSCodeUtility.getIntValue(jsonValue["ranking"]);

        // 目前階級
        var levelClass = JSCodeUtility.getIntValue(jsonValue["class"]);

        // 階級是否升階
        var classRise = JSCodeUtility.getIntValue(jsonValue["classRise"]);

        // 階級是否降階
        var classLower = JSCodeUtility.getIntValue(jsonValue["classLower"]);

        // 排名是否上升
        var rankRise = JSCodeUtility.getIntValue(jsonValue["rankRise"]);

        // 排名是否下降
        var rankLower = JSCodeUtility.getIntValue(jsonValue["rankLower"]);

        var param = {
            haveBooster: JSCodeUtility.getIntValue(jsonValue["haveBooster"]) === 1, // 此次有加速器
            haveProtect: JSCodeUtility.getIntValue(jsonValue["haveProtect"]) === 1, // 此次有保護令
            addScore: JSCodeUtility.getIntValue(jsonValue["addScore"]),
            score: JSCodeUtility.getIntValue(jsonValue["score"]),
            nextScore: JSCodeUtility.getIntValue(jsonValue["nextClassScore"]),
            levelClass: JSCodeUtility.getIntValue(jsonValue["class"])
        };

        // 重組一下 1上升 0不變 -1下降
        var isClassRise = classRise ? 1 : (classLower ? -1 : 0);
        var isRankRise = rankRise ? 1 : (rankLower ? -1 : 0);

        // 組所需要的動畫
        var gameRankNode = this._gameRankNode;
        if (isClassRise || isRankRise) {
            var promiseArray = [];

            // 階級有上升
            if (isClassRise)
                promiseArray.push(gameRankNode.updateClassAsync(levelClass, isClassRise === 1, param));

            // 排名有上升
            if (isRankRise)
                promiseArray.push(gameRankNode.updateRankAsync(rankNumber, isRankRise === 1, true, param));
            else {
                // 升降階不會有isRankRise 只改變排名 不跑動畫
                promiseArray.push(gameRankNode.updateRankAsync(rankNumber, false, false, param));
            }

            Promise.all(promiseArray)
                .then(res => {
                    // 跑完動畫 要閃一個新的階級到人物上
                    if (isClassRise) {
                        var newIconNode = new GameRankIconNode(levelClass);
                        newIconNode.setPosition(gameRankNode.getPosition());
                        newIconNode.setScale(0.4);
                        this.addChild(newIconNode);

                        // 跑到人上方
                        var aniTime = 0.5;
                        newIconNode.runAction(cc.sequence(
                            cc.spawn(
                                cc.scaleTo(aniTime, 0.7),
                                cc.moveTo(aniTime, Cangkulan_GameUtility.getPlayerPosition(0))
                            ),
                            cc.callFunc(function () {
                                GS.dispatchCustomEvent("NotifyUpdateGameRankClass", levelClass);
                            }, this),
                            cc.removeSelf()
                        ));
                    }
                });
        } else {
            gameRankNode.runProgress(param);
        }
    },

    /**
     * 入桌確認積分加速器的狀態
     */
    cmd_gameRank_booster_info: function (value) {
        var jsonValue = JSON.parse(value);
        var remaining = JSCodeUtility.getIntValue(jsonValue["remaining"]);
        var socketTime = new Date().getTime() / 1000;
        this._gameRankNode.runBooster(remaining, socketTime);
    }
});