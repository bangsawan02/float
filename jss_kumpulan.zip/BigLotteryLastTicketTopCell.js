/**
 * 9T 幸運彩票 - 上期彩券 Top Cell
 * Domino移植設定 用彩球顯示前期頭獎號碼
 */
var BigLotteryLastTicketTopCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        var cellWidth = BigLotteryLastTicketTopCell.WIDTH;
        var cellHeight = BigLotteryLastTicketTopCell.HEIGHT;
        var midPosX = cellWidth / 2;
        var midPosY = cellHeight / 2;

        var lastPeriodParam = DataModal.bigLotteryData.getLastPeriodTicket();
        var lastNumList = lastPeriodParam.numList;

        // 有前期頭獎號碼
        if (lastNumList) {

            // 頭獎的node
            var winnerNode = new cc.Node();
            this.addChild(winnerNode);

            // 獎球的數量
            var ballNumber = 5;

            // 獎球置中
            var startPosX = midPosX + (ballNumber - 1) / 2 * -45;
            this._winnerNumNodeList = [];
            for (var i = 0; i < ballNumber; i++) {
                // 背景
                var numBgSprite = new cc.Sprite("#bigLottery_pic_ball.png");
                numBgSprite.setPosition(startPosX + 1, midPosY - 6);
                winnerNode.addChild(numBgSprite);

                // 數字
                var numNode = this._winnerNumNodeList[i] = new GSSpriteNumberNode({
                    number: lastNumList[i],
                    numStr: "#bigLottery_word_ticket_",
                    spW: 10,
                });
                numNode.setPosition(startPosX, midPosY - 5);
                winnerNode.addChild(numNode);

                startPosX += 45;
            }

            // 主要的東西
            {
                var mainNode = this._mainNode = new cc.Node();
                this.addChild(mainNode);

                // 裝文字的node
                var labelNode = this._labelNode = new GSAutoLayoutNode();
                labelNode.setPosition(midPosX - 52, midPosY + 11);
                mainNode.addChild(labelNode);

                // 前期頭獎美術字
                var lastTitleSp = new cc.Sprite("#bigLottery_word_lastNumber.png");
                lastTitleSp.setPosition(midPosX, midPosY + 27);
                mainNode.addChild(lastTitleSp);

                // 中間線
                var lineSprite = new ccui.Scale9Sprite("bigLottery_pic_line.png");
                lineSprite.setPreferredSize(cc.size(400, 4));
                lineSprite.setPosition(midPosX, midPosY - 31);
                mainNode.addChild(lineSprite);

                // 您上期購買彩票紀錄如下(文字)
                var lastRecordSp = new cc.Sprite("#bigLottery_word_lastRecord.png");
                lastRecordSp.setPosition(midPosX, midPosY - 44);
                mainNode.addChild(lastRecordSp);
            }
        }
    }
});

// Cell寬
BigLotteryLastTicketTopCell.WIDTH = 418;

// Cell高
BigLotteryLastTicketTopCell.HEIGHT = 100;
