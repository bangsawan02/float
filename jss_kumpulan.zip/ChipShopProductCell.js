/**
 * v5.4.5 商城 - 大廳德撲幣商城Cell
 * created by lichieh on 2022/11/1
 */
var ChipShopProductCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        var midY = 59;

        this._productBtns = [];

        for (var i = 0; i < 3; i++) {
            var productBtn = this._productBtns[i] = new ShopProductButton();
            productBtn.setPosition(60 + i * 110, midY);
            this.addChild(productBtn);
        }
    },

    refreshCell: function (param) {
        if (!param) {
            this.setVisible(false);
            return;
        }

        this.setVisible(true);
        this._productBtns.forEach((cur, i) => {
            if (param[i]) {
                cur.refreshBtn(param[i], ShopLayer.TAB_TYPE.CHIP_SHOP);
                cur.setVisible(true);
            } else {
                cur.setVisible(false);
            }
        });
    },
});

ChipShopProductCell.HEIGHT = 120;