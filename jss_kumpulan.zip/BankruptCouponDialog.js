/**
 * ID破產儲值禮包(移植 BankruptCouponDialog)
 */

var BankruptCouponDialog = BaseDialogLayer.extend({
    ctor: function () {
        this._super();

        this.key = "BankruptCouponDialog";

        // 需要讀取的素材
        this.loadFileArray = ["lobby/lobby_coupons.plist", "lobby/lobby_coupons.png"];
    },

    onExit: function () {
        if (this._loadFileDone)
            cc.spriteFrameCache.removeSpriteFramesFromFile("lobby/lobby_coupons.plist");

        this._super();
    },

    // 讀取素材完畢
    loadFileDone: function () {
        this._super();

        // 先讀圖片Plist
        cc.spriteFrameCache.addSpriteFrames("lobby/lobby_coupons.plist", "lobby/lobby_coupons.png");

        // 拿資料
        var param = this._param = DataModal.purchaseCouponData.bankruptCouponParam;

        var aniLayer = this._animationLayer;

        // 背景
        var bgSize = cc.size(380, 220);
        var background = new ccui.Scale9Sprite("lobby_bg_gold_black.png");
        background.setPreferredSize(bgSize);
        background.setPosition(JSScreenMidPos);
        aniLayer.addChild(background);

        // 紫光
        var purpleLight = new cc.Sprite("#bankrupt_bg_purple.png");
        purpleLight.setScale(6, 3);
        purpleLight.setPosition(JSScreenMidPos);
        aniLayer.addChild(purpleLight);

        // 中間緞帶
        var bgRibbon = new ccui.Scale9Sprite("bankrupt_pic_ribbon_01.png");
        bgRibbon.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 5);
        aniLayer.addChild(bgRibbon);

        // 可獲得的德撲幣
        var chipsNode = new GSNumberNode(param.newChipsWillGet, "congratulation_alert_number", cc.size(30, 38), cc.size(10, 0), false, true, 0, "%s");
        chipsNode.setSuffixMark("congratulation_alert_word_chips.png", cc.size(130, 38));
        chipsNode.setDocOffsetY(-17);
        chipsNode.setAnchorPoint(cc.p(0.5, 0));
        chipsNode.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 5);
        chipsNode.setScale(0.4);
        aniLayer.addChild(chipsNode);

        // 原來可獲得的德撲幣
        var originalChips = new cc.LabelTTF(JSCodeUtility.getCurrencyString(param.oldChipsWillGet), JSFontName, 18);
        originalChips.setFontFillColor(cc.color(255, 200, 255));
        originalChips.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 10);
        aniLayer.addChild(originalChips);

        // 刪除線
        var lineWidth = originalChips.getContentSize().width;
        var deleteLine = new cc.LayerColor(cc.color(255, 200, 255, 255), lineWidth, 2);
        deleteLine.setPosition(JSScreenMidPos.x - lineWidth / 2, JSScreenMidPos.y - 11);
        aniLayer.addChild(deleteLine);

        // 金幣堆
        var moneyStack = new cc.Sprite("#bankrupt_pic_money_03.png");
        moneyStack.setPosition(JSScreenMidPos.x - 20, JSScreenMidPos.y - 70);
        aniLayer.addChild(moneyStack);

        // 左邊紫星星
        var starPos = cc.p(JSScreenMidPos.x - 130, JSScreenMidPos.y + 75);
        var starLight = new cc.Sprite("#bg_simple_alert.png");
        starLight.setScale(1.25);
        starLight.setPosition(starPos);
        aniLayer.addChild(starLight);

        var starSprite = new cc.Sprite("#bankrupt_pic_star_promote.png");
        starSprite.setPosition(starPos);
        aniLayer.addChild(starSprite);

        var starWord = new cc.Sprite("#bankrupt_title_promote.png");
        starWord.setPosition(starPos);
        aniLayer.addChild(starWord);

        // 禮包數量位置
        var remainNumberPos = cc.p(JSScreenMidPos.x + 75, JSScreenMidPos.y + 70);
        // 右邊 剩餘禮包數
        var bgNumber = new ccui.Scale9Sprite("bankrupt_bg_yellow_white.png");
        bgNumber.setPreferredSize(cc.size(100, 54));
        bgNumber.setPosition(remainNumberPos);
        aniLayer.addChild(bgNumber);

        // 兩條黑線
        var blackLinePosX = [remainNumberPos.x - 15, remainNumberPos.x + 13];
        blackLinePosX.forEach(cur => {
            var numberLine = new cc.Sprite("#bankrupt_pic_line_01.png");
            numberLine.setAnchorPoint(0, 0);
            numberLine.setScale(0.7);
            numberLine.setPosition(cur, remainNumberPos.y - 16);
            aniLayer.addChild(numberLine);
        });

        // 禮包數字
        var remainTime = param.countdownTime - JSCodeUtility.getNowTime();
        var numberNode = new GSNumberNode(0, "number_05", cc.size(28, 38), cc.size(0, 0), false, true, 0, "%d");
        numberNode.setPosition(remainNumberPos.x + 42, remainNumberPos.y);
        numberNode.setAnchorPoint(cc.p(1, 0.5));
        numberNode.setNumber(Math.ceil(remainTime / 5));
        aniLayer.addChild(numberNode);

        // 文字圖 剩餘
        var title = new cc.Sprite("#bankrupt_title_remain.png");
        title.setPosition(JSScreenMidPos.x - 17, remainNumberPos.y);
        aniLayer.addChild(title);

        // 左右閃爍光點
        var starPosList = [
            cc.p(JSScreenMidPos.x + bgSize.width / 2 - 30, JSScreenMidPos.y + 25),
            cc.p(JSScreenMidPos.x - bgSize.width / 2 + 35, JSScreenMidPos.y + 35)
        ];
        starPosList.forEach((cur, index) => {
            var star = new cc.Sprite("#bankrupt_pic_spot.png");
            star.setPosition(cur);
            star.setScale(1 + 0.2 * index);
            aniLayer.addChild(star);
        });

        // 左中綠色圈齒輪
        var gearPos = cc.p(JSScreenMidPos.x - 148, JSScreenMidPos.y + 2);
        var greenGear = new cc.Sprite("#bankrupt_pic_sticker.png");
        greenGear.setPosition(gearPos);
        aniLayer.addChild(greenGear);

        // 折扣%數
        var discountNode = new GSNumberNode(param.discount, "number_04", cc.size(20, 38), cc.size(0, 0), false, true, 0, "%d");
        discountNode.setPrefixMark("number_04_+.png", cc.size(22, 38));
        discountNode.setSuffixMark("number_04_%.png", cc.size(30, 38));
        discountNode.setPosition(gearPos);
        discountNode.setRotation(-25);
        discountNode.setScale(0.7);
        aniLayer.addChild(discountNode);

        // 時間Label
        var timeLabel = new GSTimeLabel("", JSFontName, 15, cc.TEXT_ALIGNMENT_LEFT);
        timeLabel.setFormat("%mm:%ss");
        timeLabel.setFontFillColor(cc.color(255, 255, 255));
        timeLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 40);
        aniLayer.addChild(timeLabel);

        // 倒數計時
        timeLabel.countdownSeconds(remainTime,
            () => {
                GS.dispatchCustomEvent("NotifyBankruptCouponFinish");
            },
            (leftTime) => {
                var quota = Math.ceil(leftTime / 5);
                numberNode.setToNumber(quota);
            });

        var timeLabelSize = timeLabel.getContentSize();
        var iconTimer = new cc.Sprite("#pic_icon_time.png");
        iconTimer.setAnchorPoint(1, 0.5);
        iconTimer.setScale(0.7);
        iconTimer.setPosition(JSScreenMidPos.x - timeLabelSize.width / 2, JSScreenMidPos.y - 40);
        aniLayer.addChild(iconTimer);

        // 飛行金幣
        var goldPosition = [
            cc.p(JSScreenMidPos.x - 145, JSScreenMidPos.y - 100),
            cc.p(JSScreenMidPos.x + 140, JSScreenMidPos.y - 100),
            cc.p(JSScreenMidPos.x + 105, JSScreenMidPos.y - 70),
            cc.p(JSScreenMidPos.x + 150, JSScreenMidPos.y - 65),
            cc.p(JSScreenMidPos.x - 160, JSScreenMidPos.y - 65)
        ];
        var goldRotation = [-70, 60, 50, 30, -45];
        var goldScale = [0.8, 0.95, 0.85, 1.15, 0.95];
        goldPosition.forEach((cur, index) => {
            var spriteName = (index < 3) ? "#bankrupt_pic_money_01.png" : "#bankrupt_pic_money_02.png";
            var goldSp = new cc.Sprite(spriteName);
            goldSp.setPosition(cur);
            goldSp.setRotation(goldRotation[index]);
            goldSp.setScale(goldScale[index]);
            if (index === 2)
                goldSp.setFlippedX(true);
            aniLayer.addChild(goldSp, 3);
        });

        // 儲值按鈕
        var btnSize = cc.size(120, 35);
        var str = JSCodeUtility.getCurrencyString(param.payMoney) + " IDR";

        var buyBtn = ButtonUtility.createSimpleButton("bt_tournament_01.png", btnSize, str, JSColor.BLACK, 15);
        buyBtn.addTouchUpInsideAction(this._clickPurchaseButton, this);
        buyBtn.setPosition(JSScreenMidPos.x, 70 + JSScreenBonusHalfHeight);
        aniLayer.addChild(buyBtn);

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
        closeBtn.setPosition(442 + JSScreenBonusHalfWidth, 252 + JSScreenBonusHalfHeight);
        aniLayer.addChild(closeBtn);

        // 監聽
        GS.addListener("NotifyBankruptCouponFinish", this._closeDialogAnimation.bind(this), this);
        GS.addListener("NotifyPurchaseSuccess", this._closeDialogAnimation.bind(this), this);
    },

    keyBackPressed: function () {
        this._closeBtnClicked();
    },

    // 按下購買
    _clickPurchaseButton: function () {
        // 判斷是否開第三方 超過一個要開管道多選dialog
        var param = this._param;
        var productList = param.productIDList;
        // 只有一個 送儲值
        if (productList.length === 1)
            DataModal.purchaseData.sendPurchase(productList[0]);

        // 一個以上開選擇dialog
        if (productList.length > 1)
            DialogManager.addDialog(new ProviderChooseDialog(param), false);

        // 埋點
        DataProcess.sendString(JSStringUtility.format("track_bankrupt_payment_click %s", param.payMoney));
    },

    // 按下離開
    _closeBtnClicked: function () {
        // 跳出挽回的dialog
        DialogManager.addDialog(new BankruptCouponLeaveDialog(), false);
    }
});