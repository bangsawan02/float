/**
 * v5.6.5 農場賓果 機台圖示旁 icon
 */
var FarmBingoSlotIconNode = cc.Sprite.extend({
    ctor: function (gameType) {
        this._gameType = gameType;
        this._super("#lobby_icon_farm_pass.png");
        this.setVisible(false);

        this.refreshView();

        GS.addListener("NotifyFarmBingoIconDone", this.refreshView.bind(this), this);
    },

    refreshView: function () {
        this.setVisible(false);

        let data = DataModal.farmBingoData;
        let iconParam = data.iconParam;

        if (iconParam && data.canThisSlotAccumulate(this._gameType)) {
            let remainTime = JSCodeUtility.getRemainTime(iconParam.remainTime, iconParam.socketTime);
            if (remainTime > 0) {
                this.setVisible(true);
                this.runAction(cc.sequence(
                    cc.delayTime(remainTime),
                    cc.hide()
                ));
            }
        }
    },
});