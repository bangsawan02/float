/**
 * 成就頁面
 */

var AchieveLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 用來放頁面內容
        this._pageArray = [];

        // 背景
        var bgSprite = new cc.Sprite(SelectGameManager.getNowGameFile("lobby_background.jpg", true));
        bgSprite.setPosition(JSScreenMidPos);
        bgSprite.setColor(cc.color(100, 100, 100));
        this.addChild(bgSprite, -1000);

        // 上方文字底 / 按鈕
        var achieveString = LocalizedString.Achieve;
        var titleNode = new TitleBackgroundNode(LocalizedString.Lobby("成就"));
        titleNode.setTitleToLeft();
        titleNode.addTabButton([achieveString("活動"), achieveString("偉大"), achieveString("一般")], this._tabClicked, this);
        titleNode.setPosition(JSScreenMidPos.x, JSVisibleSize.height - TITLE_BG_HEIGHT / 2);
        this.addChild(titleNode, 10);

        // 加小紅點
        var tabItems = titleNode.getTabItems();
        this._badgeNode = [];
        for (var i = 0, len = tabItems.length; i < len; i++) {
            var badgeNode = this._badgeNode[i] = new BadgeNode();
            badgeNode.setPosition(58, 24);
            tabItems[i].addChild(badgeNode);
        }

        // 預設哪一頁
        titleNode.setTabClickedIndex(2);

        // 更新大廳成就的小紅點提示
        this._refreshBadge();

        GS.addListener("NotifyPatchAchievementRewardDone", this.notifyPatchAchievementRewardDone.bind(this), this);
        GS.addListener("NotifyFetchAchievementTabInfoDone", this.notifyFetchAchievementTabInfoDone.bind(this), this);
    },

    onExit: function () {
        // 把原來成就的資料清除
        DataModal.achieveData.clean();

        this._super();
    },

    /**
     * 功能
     */
    // 更新小紅點
    _refreshBadge: function () {
        // achieveNumArray = [每日, 一般, 偉大, 活動]  => server傳的順序
        // this._badgeNode = [活動, 偉大, 一般]        => 畫面上的順序
        var achieveNum = DataModal.achieveData.achieveNumArray;
        for (var i = 0, len = this._badgeNode.length; i < len; i++) {
            this._badgeNode[i].setNumber(achieveNum[3 - i]);
        }
    },

    /**
     * 按鈕
     */
    // 按到Tab
    _tabClicked: function (index) {
        var pageArray = this._pageArray;

        // 先把所有頁面關掉
        pageArray.forEach(page => page && page.setVisible(false));

        var page = pageArray[index];
        if (!page) {
            page = this._pageArray[index] = new AchieveDetailLayer(index);
            this.addChild(page);
        }

        // 讓哪一個畫面出現
        page.setVisible(true);
    },


    /**
     * 通知
     */
    // 取得成就獎勵 / 失敗
    notifyPatchAchievementRewardDone: function (event) {
        var param = event.getUserData();
        if (param) {
            DialogManager.addDialog(new RewardDialog({content: param}));
        } else {
            var commonString = LocalizedString.Common;
            var obj = {
                content: commonString("領取失敗，請稍候再試"),
                buttons: [commonString("確認")]
            };
            DialogManager.addDialog(new Dialog(obj));
        }
    },

    // 收到cmd通知更新小紅點
    notifyFetchAchievementTabInfoDone: function () {
        this._refreshBadge();
    }
});