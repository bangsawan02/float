/**
 * Cangkulan的牌
 */
var Cangkulan_CardNode = PokerCardNode.extend({
    ctor: function (number, type) {
        this._super(number, type);

        var contentWidth = 54;
        var contentHeight = 72;
        this._cardRect = cc.rect(0, 0, contentWidth, contentHeight);
    },

    /**
     * 設定牌為灰階狀態
     * @param isGray
     */
    setGray: function (isGray) {
        this.setColor(isGray ? JSColor.GRAY : JSColor.WHITE);
    },

    /**
     * 取得花色編號
     * @returns {*}
     */
    getSuit: function () {
        return Cangkulan_CardSuit[this.cardNumber[0]];
    },

    /**
     * 比大小使用 依造花色大小排序
     * @returns {number}
     */
    getCounterBySuit: function () {
        var cardCount = 0;
        if (this.cardNumber.length >= 2) {
            switch (this.cardNumber[0]) {
                case '1':
                    //黑桃
                    cardCount = 80;
                    break;
                case '2':
                    //紅心
                    cardCount = 60;
                    break;
                case '3':
                    //紅磚
                    cardCount = 20;
                    break;
                case '4':
                    //梅花
                    cardCount = 40;
                    break;
            }

            switch (this.cardNumber[1]) {
                case '1':
                    cardCount += 14;
                    break;
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9': {
                    cardCount += Number.parseInt(this.cardNumber[1]);
                    break;
                }
                case 'T': {
                    cardCount += 10;
                    break;
                }
                case 'J': {
                    cardCount += 11;
                    break;
                }
                case 'Q': {
                    cardCount += 12;
                    break;
                }
                case 'K': {
                    cardCount += 13;
                    break;
                }
            }
        }
        return cardCount;
    },

    /**
     * 取出可以Touch到的範圍
     */
    getCardBoundingBox: function () {
        return cc.rectApplyAffineTransform(this._cardRect, this.getNodeToParentAffineTransform());
    }
});