/**
 * v5.6.5 農場賓果 - 共用 Dialog
 */
var FarmBingoCommonDialog = BaseDialogLayer.extend({
    ctor: function (param) {
        this._super();

        this.key = "FarmBingoCommonDialog";

        this._param = param;
        this.isLockBackKey = !!param.isLockBackKey;
        this._buttons = [];
        this._callbackReturnValue = undefined;

        this._fontColor = cc.color(84, 61, 26);

        // 背景
        var bgSprite = new ccui.Scale9Sprite("farm_bingo_bg_frame_dialog-1.png");
        bgSprite.setPreferredSize(cc.size(234, 152));
        bgSprite.setPosition(JSScreenMidPos);
        this._animationLayer.addChild(bgSprite);

        // 背景2
        var bgSprite2 = this._bgSprite2 = new ccui.Scale9Sprite("farm_bingo_bg_frame_dialog-2.png");
        bgSprite2.setPreferredSize(cc.size(200, 92));
        bgSprite2.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 16);
        this._animationLayer.addChild(bgSprite2);

        switch (param.type) {
            case FarmBingoCommonDialog.DialogType.REWARD:
            case FarmBingoCommonDialog.DialogType.OPEN_AVAILABLE:
                // 創領獎畫面
                this._createRewardView();
                break;
            case FarmBingoCommonDialog.DialogType.RP_NOT_ENOUGH:
                this._createNoRpView();
                break;
            case FarmBingoCommonDialog.DialogType.POT_LIMIT:
                this._createPotLimitView();
                break;
            case FarmBingoCommonDialog.DialogType.RP_BUY_POT:
                this._createRpBuyPotView();
                break;
            case FarmBingoCommonDialog.DialogType.GIVE_UP_PURCHASE:
                this._createGiveUpPurchaseView();
                break;
            case FarmBingoCommonDialog.DialogType.COMMON:
                this._createCommonView();
                break;
        }

        if (param.isCloseButtonShow) {
            // 關閉按鈕
            var closeBtn = ButtonUtility.createSimpleImageButton("lobby_btn_circle_04.png", null, "#lobby_btn_pic_window_x.png");
            closeBtn.addTouchUpInsideAction(this._closeDialogClicked, this);
            closeBtn.setPosition(JSScreenMidPos.x + 112, JSScreenMidPos.y + 74);
            this._animationLayer.addChild(closeBtn);
        }

        if (param.callback) {
            this._callback = param.callback;
        }
    },

    _createRewardView: function () {
        var animeLayer = this._animationLayer;
        var param = this._param;
        var type = param.type;

        var titleString = type === FarmBingoCommonDialog.DialogType.REWARD ? "恭喜獲得" : "先幫您領取可領的金蘋果";

        // 標題
        var titleLabel = new cc.LabelTTF(LocalizedString.FarmBingo(titleString), JSFontName, 12);
        titleLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 55);
        titleLabel.setColor(cc.color(120, 91, 49));
        animeLayer.addChild(titleLabel);

        // 獎勵列表背景
        this._bgSprite2.setPreferredSize(cc.size(200, 75));
        this._bgSprite2.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 7);

        // 獎勵內文 auto layout
        var rewardAutoLayout = new GSAutoLayoutNode();
        rewardAutoLayout.setPosition(this._bgSprite2.getPosition());
        rewardAutoLayout.setType(GSAutoLayout.TYPE.VERTICAL);
        animeLayer.addChild(rewardAutoLayout);

        // 獎勵內文
        (param.rewardArray || []).forEach((element) => {
            var msgLabel = new cc.LabelTTF(element, JSFontName, 12);
            msgLabel.setFontFillColor(this._fontColor);
            rewardAutoLayout.addChild(msgLabel);
        });

        // OK 按鈕
        var okButton = new Texas_Button(Texas_Button.Style.GREEN, cc.size(93, 30), "OK", JSColor.WHITE, 15);
        okButton.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 52);
        okButton.addTouchUpInsideAction(this._closeDialogClicked, this);
        animeLayer.addChild(okButton);
    },

    _createNoRpView: function () {
        // 埋點：購買獎勵罐 RP 不足 dialog 4407、達上限 RP 不足 4416
        let isParentPotLimit = this._param.parentType === FarmBingoCommonDialog.DialogType.POT_LIMIT;
        DataModal.farmBingoData.sendTrackingData(isParentPotLimit ? 4416 : 4407);

        var animeLayer = this._animationLayer;

        // 不足文字
        var label = new cc.LabelTTF(JSStringUtility.format(LocalizedString.FarmBingo("%s不足\n馬上儲值獲得獎勵!"), ProfileData.getIsKoinLuxy() ? "KL" : "RP"), JSFontName, 12, null, cc.TEXT_ALIGNMENT_CENTER);
        label.setColor(this._fontColor);
        label.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 18);
        animeLayer.addChild(label);

        // 放棄按鈕
        var giveUpButton = new Texas_Button(Texas_Button.Style.BLUE, cc.size(93, 33), LocalizedString.FarmBingo("放棄"));
        giveUpButton.addTouchUpInsideAction(this._closeDialogClicked, this);
        giveUpButton.setPosition(JSScreenMidPos.x - 51, JSScreenMidPos.y - 50);
        animeLayer.addChild(giveUpButton);

        // 馬上獲得按鈕
        var getNowButton = new Texas_Button(Texas_Button.Style.GREEN, cc.size(93, 33), LocalizedString.FarmBingo("馬上獲得"));
        getNowButton.addTouchUpInsideAction(() => {
            if (isParentPotLimit) {
                // 埋點：達上限 4417
                DataModal.farmBingoData.sendTrackingData(4417);
            } else {
                UserAnalyticsTrackUtils.sendTrack("農場賓果 >=8.4 點馬上獲得", DataModal.farmBingoData.group);
            }

            this._closeDialogClicked();

            var bingoData = DataModal.farmBingoData.bingoParam;

            // 導儲值
            let productIDList = bingoData.recharge.productIDList;
            if (productIDList.length === 1) {
                DataModal.purchaseData.sendPurchase(productIDList[0]);
            } else {
                DialogManager.addDialog(new ProviderChooseDialog(bingoData.recharge), false);
            }
        }, this);
        getNowButton.setPosition(JSScreenMidPos.x + 51, JSScreenMidPos.y - 50);
        animeLayer.addChild(getNowButton);
    },

    _createPotLimitView: function () {
        // 埋點：跳罐子已達上限 dialog 4410
        DataModal.farmBingoData.sendTrackingData(4410);

        var animeLayer = this._animationLayer;
        var param = this._param;

        // 標題
        var titleLabel = new cc.LabelTTF(LocalizedString.FarmBingo("金頻果數量已達上限!"), JSFontName, 10, null, cc.TEXT_ALIGNMENT_CENTER);
        titleLabel.setColor(this._fontColor);
        titleLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 45);
        animeLayer.addChild(titleLabel);

        // 罐子
        var potSprite = new cc.Sprite("#farm_bingo_pic_apple_1.png");
        potSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 17);
        animeLayer.addChild(potSprite);

        // 內文
        var label = new cc.LabelTTF(JSStringUtility.format(LocalizedString.FarmBingo("要使用%s直接領取獎勵嗎?"), ProfileData.getIsKoinLuxy() ? "KL" : "RP"), JSFontName, 10, null, cc.TEXT_ALIGNMENT_CENTER);
        label.setColor(this._fontColor);
        label.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 10);
        animeLayer.addChild(label);

        // 購買按鈕
        var buyButton = new Texas_Button(Texas_Button.Style.GREEN, cc.size(105, 33), JSCodeUtility.getCurrencyString(param.cost || 0));
        buyButton.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 53);
        buyButton.addTouchUpInsideAction(() => {
            // 埋點：點擊 RP 購買按鈕 4411
            DataModal.farmBingoData.sendTrackingData(4411);

            // 購買
            var koinNum = DataModal.koinLuxyData.myKoin;

            if (koinNum >= this._param.cost) {
                // RP 足夠可購買
                this._closeDialogAnimation();

                // 回傳購買
                this._callback(true);
            } else {
                // 跳 RP 不足 dialog
                var dialog = new FarmBingoCommonDialog({
                    type: FarmBingoCommonDialog.DialogType.RP_NOT_ENOUGH,
                    parentType: FarmBingoCommonDialog.DialogType.POT_LIMIT
                });
                dialog.startDialogAnimation();
                this._animationLayer.addChild(dialog, 9999);
            }
        }, this);
        buyButton.getTitleLabel().setPosition(12, 0);
        animeLayer.addChild(buyButton);

        // RP icon
        var rpSprite = new cc.Sprite(ProfileData.getKoinLuxyRes("#lobby_icon_koinLuxy"));
        rpSprite.setPosition(-26, 0);
        rpSprite.setScale(0.6);
        buyButton.addChildToContentNode(rpSprite);
    },

    _createRpBuyPotView: function () {
        var animeLayer = this._animationLayer;
        var param = this._param;

        // Column auto layout
        var colAutoLayout = new GSAutoLayoutNode();
        colAutoLayout.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 14);
        colAutoLayout.setType(GSAutoLayout.TYPE.VERTICAL);
        animeLayer.addChild(colAutoLayout);

        // Auto layout node
        var rowAutoLayout = new GSAutoLayoutNode();
        rowAutoLayout.setSpace(3);
        colAutoLayout.addChild(rowAutoLayout);

        // 說明文字
        var confirmLabel = new cc.LabelTTF(LocalizedString.FarmBingo("確定要用"), JSFontName, 12);
        confirmLabel.setColor(this._fontColor);
        rowAutoLayout.addChild(confirmLabel);

        // RP icon
        var rpSprite = new cc.Sprite(ProfileData.getKoinLuxyRes("#lobby_icon_koinLuxy"));
        rpSprite.setScale(0.6);
        rowAutoLayout.addChild(rpSprite);

        // Cost
        var costLabel = new cc.LabelTTF(JSCodeUtility.getCurrencyString(param.cost || 0), JSFontName, 12);
        costLabel.setColor(this._fontColor);
        rowAutoLayout.addChild(costLabel);

        // 說明文字
        var redeemLabel = new cc.LabelTTF(LocalizedString.FarmBingo("獲得獎勵嗎?"), JSFontName, 12);
        redeemLabel.setColor(this._fontColor);
        colAutoLayout.addChild(redeemLabel);

        // OK 按鈕
        var okButton = new Texas_Button(Texas_Button.Style.ORANGE, cc.size(93, 35), "OK", JSColor.WHITE, 15);
        okButton.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 52);
        okButton.addTouchUpInsideAction(() => {
            this._callback && this._callback(true);
            this._closeDialogAnimation();
        }, this);
        animeLayer.addChild(okButton);
    },

    _createGiveUpPurchaseView: function () {
        // 埋點：跳放棄提示 dialog、達上限跳 4413
        let isParentRPBuyPot = this._param.parentType === FarmBingoCommonDialog.DialogType.RP_BUY_POT;
        DataModal.farmBingoData.sendTrackingData(isParentRPBuyPot ? 4404 : 4413);

        var animeLayer = this._animationLayer;

        // 放棄兌換文字
        var label = new cc.LabelTTF(LocalizedString.FarmBingo("確定要放棄兌換獎勵嗎?"), JSFontName, 12, null, cc.TEXT_ALIGNMENT_CENTER);
        label.setColor(this._fontColor);
        label.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 18);
        animeLayer.addChild(label);

        // 放棄按鈕
        var giveUpButton = new Texas_Button(Texas_Button.Style.BLUE, cc.size(93, 33), LocalizedString.FarmBingo("放棄（兌獎按鈕）"));
        giveUpButton.addTouchUpInsideAction(() => {
            // 回傳放棄
            this._callbackReturnValue = true;
            this._closeDialogClicked();

            // 埋點：放棄購買 4405、達上限放棄 4414
            DataModal.farmBingoData.sendTrackingData(isParentRPBuyPot ? 4405 : 4414);
        }, this);
        giveUpButton.setPosition(JSScreenMidPos.x - 51, JSScreenMidPos.y - 50);
        animeLayer.addChild(giveUpButton);

        // 把握機會按鈕
        var getNowButton = new Texas_Button(Texas_Button.Style.GREEN, cc.size(93, 33), LocalizedString.FarmBingo("把握機會"));
        getNowButton.addTouchUpInsideAction(() => {
            this._closeDialogClicked();

            // 埋點：把握機會 3223、達上限把握機會 4415
            DataModal.farmBingoData.sendTrackingData(isParentRPBuyPot ? 4406 : 4415);
        }, this);
        getNowButton.setPosition(JSScreenMidPos.x + 51, JSScreenMidPos.y - 50);
        animeLayer.addChild(getNowButton);
    },

    _createCommonView: function () {
        var aniLayer = this._animationLayer;

        // 內文
        var contentLabel = new cc.LabelTTF(this._param.content, JSFontName, 12);
        contentLabel.setFontFillColor(cc.color(84, 61, 26));
        contentLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        contentLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 16);
        aniLayer.addChild(contentLabel);

        // 確認按鈕
        var okBtn = new Texas_Button(Texas_Button.Style.GREEN, cc.size(93, 33), "OK");
        okBtn.addTouchUpInsideAction(() => {
            this._closeDialogClicked();

            // 埋點：tracking number
            this._param.trackType && DataModal.farmBingoData.sendTrackingData(this._param.trackType);
        }, this);
        okBtn.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 50);
        aniLayer.addChild(okBtn);
    },

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        if (this.isLockBackKey) {
            return;
        }
        switch (this._param.type) {
            case FarmBingoCommonDialog.DialogType.GIVE_UP_PURCHASE:
                // 點擊返回按鈕代表放棄購買
                this._callbackReturnValue = true;
                break;
        }
        this._closeDialogClicked();
    },

    /**
     * 按鈕
     */
    // 關掉畫面
    _closeDialogClicked: function () {
        // 關閉前
        switch (this._param.type) {
            case FarmBingoCommonDialog.DialogType.POT_LIMIT:
                // 罐子超出數量 dialog 關閉前詢問
                var dialog = new FarmBingoCommonDialog({
                    type: FarmBingoCommonDialog.DialogType.GIVE_UP_PURCHASE,
                    parentType: this._param.type,
                    callback: (isGiveUp) => {
                        if (isGiveUp === true) {
                            if (this._callback)
                                this._callback(this._callbackReturnValue);

                            this._closeDialogAnimation();
                        }
                    }
                });
                dialog.startDialogAnimation();
                this._animationLayer.addChild(dialog, 9999);
                return;
        }

        if (this._callback)
            this._callback(this._callbackReturnValue);

        this._closeDialogAnimation();
    },
});

FarmBingoCommonDialog.DialogType = GSEnumHelper({
    REWARD: -1,             // 恭喜獲得
    RP_NOT_ENOUGH: -1,      // RP 不足
    POT_LIMIT: -1,          // 罐子達上限
    OPEN_AVAILABLE: -1,     // 打開可領獎罐子
    RP_BUY_POT: -1,         // 購買罐子
    GIVE_UP_PURCHASE: -1,   // 放棄購買
    COMMON: -1,             // 共用
});