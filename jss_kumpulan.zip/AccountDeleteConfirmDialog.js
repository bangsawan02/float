/**
 * 刪除帳號確認dialog
 */

var AccountDeleteConfirmDialog = BaseDialogLayer.extend({
    ctor: function () {
        this._super();

        // 先設定此Dialog的Key 之後容易砍
        this.key = "AccountDeleteConfirmDialog";

        var aniLayer = this._animationLayer;
        var loginString = LocalizedString.Login;

        // 背景底
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(cc.size(377, 224));
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite, -1);

        var lightSprite = new cc.Sprite("#lobby_pic_pink_light.png");
        lightSprite.setScale(100, 50);
        lightSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(lightSprite, -1);

        // 看板娘
        var avatarNode = null;
        if (GS.useSpineAvatar) {
            var spineArray = [
                SelectGameManager.getNowGameFile("avatar_domino_half.json"),
                SelectGameManager.getNowGameFile("avatar_domino_half.atlas"),
                SelectGameManager.getNowGameFile("avatar_domino_half.png")
            ];
            avatarNode = new cc.Node();
            avatarNode.setScale(GS.isLuxyPoker ? 0.85 : 0.7);
            avatarNode.setPosition(150 + JSScreenBonusHalfWidth, (GS.isLuxyPoker ? 130 : 30) + JSScreenBonusHalfHeight);
            aniLayer.addChild(avatarNode);
            var addSpineAvatar = function () {
                var avatar = new sp.SkeletonAnimation(spineArray[0], spineArray[1], 0.25);
                avatar.setAnimation(0, 'animation', true);
                avatarNode.addChild(avatar);
            };
            if (!cc.sys.isNative) {
                // H5要先去讀
                cc.loader.load(spineArray, function (a, b) {
                    addSpineAvatar();
                });
            } else {
                // 原生不用讀
                addSpineAvatar();
            }
        } else {
            // 5.5.8改看板娘有額外調整(之後如果要改回原版看板娘要再調整回去)
            avatarNode = new cc.Sprite(SelectGameManager.getNowGameFile("common_avatar.png"));
            avatarNode.setScale(GS.isLuxyPoker ? -0.45 : 0.55, GS.isLuxyPoker ? 0.45 : 0.55);
            avatarNode.setAnchorPoint(JSAnchorPoint.M_BOTTOM);
            avatarNode.setPosition((GS.isLuxyPoker ? 160 : 148) + JSScreenBonusHalfWidth, (GS.isLuxyPoker ? 37 : 40) + JSScreenBonusHalfHeight);
            aniLayer.addChild(avatarNode, 1);
        }

        // 標題
        var titleMidPosX = 320 + JSScreenBonusHalfWidth;
        var titleMessage = new GSRichTextNode(JSColor.colorToRichColor(JSColor.YELLOW) + loginString("刪除帳號"), JSFontName, 19);
        titleMessage.setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        titleMessage.setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        titleMessage.setPosition(titleMidPosX, 218 + JSScreenBonusHalfHeight);
        aniLayer.addChild(titleMessage);

        // 分隔線
        var lineSprite = new cc.Sprite("#lobby_division_line.png");
        lineSprite.setScaleX(25);
        lineSprite.setPosition(titleMidPosX, 196 + JSScreenBonusHalfHeight);
        aniLayer.addChild(lineSprite);

        // 內文
        var messageLabel = new GSRichTextNode(loginString("親愛的玩家您好,\n帳號永久刪除後資產將全數回收無法恢復\n請確認完畢後點擊「確定刪除」\n---------\n若有問題，歡迎使用回報系統聯繫客服\nGamesofa客服中心敬上"), JSFontName, 9, cc.size(200, 0));
        messageLabel.setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
        messageLabel.setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        messageLabel.setPosition(titleMidPosX, 140 + JSScreenBonusHalfHeight);
        aniLayer.addChild(messageLabel);

        // 按鈕
        var btnAutoLayout = new GSAutoLayoutNode();
        btnAutoLayout.setSpace(20);
        btnAutoLayout.setPosition(titleMidPosX, 68 + JSScreenBonusHalfHeight);
        aniLayer.addChild(btnAutoLayout, 1);

        // 按鈕 (確定刪除先設定成不可按的顯示狀態)
        var btnArray = ["取消", "確定刪除"];
        var btnImages = ["lobby_btn_01.png", "lobby_btn_04.png"];
        var btnCallback = [this._closeClicked, this._deleteClicked];
        var btnSize = cc.size(85, 30);
        btnArray.forEach((cur, index) => {
            var bgImg = btnImages[index];
            var btnBaseStr = loginString(cur);
            var btnItem = ButtonUtility.createArrayScale9Nodes([bgImg], btnSize, btnBaseStr, 13, JSColor.BLACK)[0];
            var button = new GSControlButton(btnItem, btnSize);
            button.addTouchUpInsideAction(btnCallback[index], this);
            button.setChangeColorWhenDisabled(false);
            btnAutoLayout.addChild(button);

            // 確定刪除要倒數完後才能按
            if (index === 1) {
                // 先鎖定
                button.setEnabled(false);

                // 設定倒數秒數
                var remainTime = 10;
                btnItem.label.setString(btnBaseStr + "(" + remainTime + ")");

                // 處理倒數
                this.runAction(cc.sequence(
                    cc.delayTime(1),
                    cc.callFunc(() => {
                        --remainTime;

                        var btnStr;
                        if (remainTime === 0) {
                            // 倒數結束
                            button.setEnabled(true);

                            // 調整成可以按下的按鈕樣式
                            btnItem.bg.setSpriteFrame(btnImages[0]);
                            btnItem.bg.setPreferredSize(btnSize);

                            btnStr = btnBaseStr;
                        } else {
                            btnStr = btnBaseStr + "(" + remainTime + ")";
                        }
                        btnItem.label.setString(btnStr);
                    })
                ).repeat(remainTime));
            }
        });
    },

    onEnter: function () {
        this._super();

        // 註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            "delete_account": this.cmd_delete_account,
        });
    },

    onExit: function () {
        // 砍掉SocketKey
        DataProcess.removeSocketKeyDispatch(this);

        this._super();
    },

    /**
     * 按鈕
     */
    // 按到確定刪除
    _deleteClicked: function () {
        // 卡loading TODO: 要改成新loading
        GSLoading.addLoadingView();

        // 送刪除帳號cmd
        DataProcess.sendString("delete_account");
    },

    // 按到關閉
    _closeClicked: function () {
        // 直接關掉dialog
        this._closeDialogAnimation();
    },

    /**
     * Socket
     */
    // 刪除帳號的回覆
    cmd_delete_account: function (key, value) {
        var jsonValue = JSON.parse(value || "{}");

        var error = JSCodeUtility.getIntValue(jsonValue["error"], -1);

        GSLoading.removeLoadingView();

        if (error) {
            // 刪除帳號失敗 跳錯誤訊息
            var dialogParam = {
                content: JSCodeUtility.getStringValue(jsonValue["msg"]) || LocalizedString.Common("系統忙碌中，請稍後再試"),
                buttons: [LocalizedString.Common("確定")]
            };

            var dialog = new AvatarDialog(dialogParam);
            this.addChild(dialog, 100);

            dialog.startDialogAnimation();
        } else {
            // 刪除帳號成功 開始處理刪帳號流程
            var loginData = DataModal.loginData;

            cc.warn("已刪除帳號：" + DataModal.profileData.account);

            // 有另外紀錄帳號資訊的要在這邊先清除
            switch (loginData.loginType) {
                case LoginType.Gamesofa:
                    // 清掉GS帳號
                    loginData.updateAccountAndPassword("", "");
                    break;

                case LoginType.Trail:
                    // 清掉訪客帳號
                    GS.localStorage.setItem("TrialLoginAccount", "");
                    break;
            }

            // 如果有轉正過 把已轉正的紀錄清掉 因為被刪除的可能是已轉正的訪客帳號
            var trialToAccount = GS.localStorage.getItem("ttred");
            if (trialToAccount) {
                GS.localStorage.setItem("ttred", "");
                GS.localStorage.setItem("TrialLoginAccount", "");
            }

            // 走登出流程踢回登入頁
            loginData.logout(true);
        }
    }
});