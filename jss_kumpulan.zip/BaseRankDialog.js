/**
 * 排行榜 Dialog
 * created by andrew.chang
 */
var BaseRankDialog = BaseDialogLayer.extend({
    ctor: function (type, rewardBaseUrl) {
        this._super();

        // 是哪個副系統的排行榜
        this._type = type;

        // 獎勵的網址
        this._rewardBaseUrl = rewardBaseUrl;

        // 放排名資料
        this._rankArray = [];

        // 要顯示的Cell數量
        this._totalCellCount = 0;

        var aniLayer = this._animationLayer;

        // 裝排行榜內容物的node
        var contentNode = this._contentNode = new cc.Node();
        aniLayer.addChild(contentNode, 2);

        // loading畫面
        var loadingLayer = this._mainLoadingLayer = new LoadingLayer(JSVisibleSize.width, JSVisibleSize.height);
        aniLayer.addChild(loadingLayer, 2);

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.setPosition(JSScreenMidPos.x + 176, JSScreenMidPos.y + 111);
        closeBtn.addTouchUpInsideAction(this._closeDialogAnimation, this);
        aniLayer.addChild(closeBtn, 2);

        // 重要資料的node
        var timerNode = this._timerNode = new GSTimerNode();
        aniLayer.addChild(timerNode);

        // 監聽
        GS.addListener("NotifyBaseRankShowMessage", this.notifyBaseRankShowMessage.bind(this), this);
    },

    /**
     * 創排行榜的Cell(有需要可自行override)
     * @isInTableView 是不是加在table view的cell
     */
    _createRankCell: function (isInTableView) {
        return new BaseRankCell(this._type, isInTableView);
    },

    /**
     * 創上方前三名玩家的畫面(有需要可自行override)
     */
    _createTopPlayerUI: function (rankArray) {
        // 加前三名的排行榜
        var playerPosX = [JSScreenMidPos.x, JSScreenMidPos.x - 93, JSScreenMidPos.x + 93];
        for (var i = 0; i < 3; i++) {
            var param = rankArray[i];
            var playerNode = new BaseRankTopPlayerNode(this._type, i + 1);
            playerNode.refreshView(param);
            playerNode.setOpacity(param ? 255 : 150);
            playerNode.setPosition(playerPosX[i], 208 + JSScreenBonusHalfHeight);
            this._contentNode.addChild(playerNode);
        }
    },

    /**
     * 創排行榜的畫面(有需要可自行override)
     */
    _createRankTableUI: function () {
        // tableView
        var tableViewSize = cc.size(BaseRankDialog.TABLE_WIDTH, 98);
        var mainLayer = new cc.Layer();
        var tableView = new cc.TableView(this, tableViewSize, mainLayer);
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setTouchEnabled(this._totalCellCount > 3);
        tableView.setPosition(89 + JSScreenBonusHalfWidth, 48 + JSScreenBonusHalfHeight);
        this._contentNode.addChild(tableView);

        // 更新TableView
        tableView.reloadData(true);
    },

    /**
     * 創自己排名的畫面(有需要可自行override)
     */
    _createSelfRankUI: function (selfRankParam) {
        var selfCell = this._createRankCell(false);
        selfCell.refreshView(selfRankParam);
        selfCell.setPosition(JSScreenMidPos.x - BaseRankDialog.TABLE_WIDTH / 2, 30 + JSScreenBonusHalfHeight - BaseRankCell.HEIGHT / 2);
        this._contentNode.addChild(selfCell);
    },

    /**
     * 檢查活動是否結束(有需要可自行override)
     */
    _isEventEnd: function () {
        // 這邊用來給需要的副系統override
        // 去檢查活動有沒有開 or 異常
        return false;
    },

    /**
     * 刷新排行榜畫面
     */
    _refreshRankView: function () {
        // 給繼承override用
        cc.error("你忘了override _refreshRankView");
    },

    /**
     * 刷新畫面
     */
    _refreshView: function () {
        // 先拿掉loading
        this._mainLoadingLayer.setVisible(false);

        // 先檢查活動是否結束
        if (this._isEventEnd())
            return;

        // 有泡泡框先砍掉
        if (this._messageNode) {
            this._messageNode.close();
            this._messageNode = undefined;
        }

        // 刷新排行榜畫面
        this._refreshRankView();
    },

    /**
     * TableView delegate
     */
    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        if (cell == null) {
            cell = this._createRankCell(true);
            cell.setAnchorPoint(cc.p(0, 0));
        }

        // 下面資料從第四名開始拿
        cell.refreshView(this._rankArray[idx + 3]);
        return cell;
    },

    numberOfCellsInTableView: function (table) {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function (table, idx) {
        return cc.size(BaseRankDialog.TABLE_WIDTH, BaseRankCell.HEIGHT);
    },

    // 寶箱按鈕點擊
    _chestBtnClicked: function (sender, controlEvent) {
        if (controlEvent === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || controlEvent === cc.CONTROL_EVENT_TOUCH_DOWN) {
            var pos = sender.pos;

            var rewardParam = sender.rewards;
            if (!rewardParam)
                return;

            // 裝獎勵的容器
            var contentNode = new GSAutoLayoutNode();
            contentNode.setType(GSAutoLayout.TYPE.VERTICAL_LEFT);

            rewardParam.forEach(cur => {
                // 排版用的node
                var autoLayoutNode = new GSAutoLayoutNode();

                // 獎勵圖
                var imageName = cur.wid + ".png";
                var imageUrl = this._rewardBaseUrl + imageName;
                var savePath = JSWriteablePath + "shop/" + imageName;
                var rewardSprite = new GSDownloadSprite("", imageUrl, savePath);
                rewardSprite.setTargetSize(cc.size(20, 20));
                autoLayoutNode.addChild(rewardSprite);

                // 加一個間距
                autoLayoutNode.addEmptyNode(cc.size(10, 10));

                // 獎勵文字
                var countLabel = new cc.LabelTTF(cur.content, JSFontName, 9, cc.size(0, 0), cc.TEXT_ALIGNMENT_LEFT, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
                countLabel.setFontFillColor(JSColor.BLACK);
                countLabel.setAnchorPoint(0, 0.5);
                autoLayoutNode.addChild(countLabel);

                // 最後再加進去，才會有autoLayoutNode的contentSize
                contentNode.addChild(autoLayoutNode);
            });

            var isDown = sender.isUp ? false : rewardParam.length > 3;
            if (!this._messageNode) {
                var messageNode = this._messageNode = new BaseMessageNode({
                    mainNode: contentNode,
                    style: BaseMessageNode.Style.WHITE_SHADOW,
                    direct: isDown ? BaseMessageNode.Direct.UP : BaseMessageNode.Direct.DOWN,
                    arrowType: BaseMessageNode.ArrowType.STRAIGHT,
                    isFlip: false,
                    autoFixed: true,
                });
                messageNode.show();
                this.addChild(messageNode, 10);
            }
            this._messageNode.setPosition(pos.x, pos.y + (isDown ? -10 : 10));
        } else {
            // 有泡泡框先砍掉
            if (this._messageNode) {
                this._messageNode.close();
                this._messageNode = undefined;
            }
        }
    },

    // 跳個別獎勵泡泡框
    notifyBaseRankShowMessage: function (event) {
        if (event && event.getUserData()) {
            var param = event.getUserData();
            param.pos = this.convertToNodeSpace(param.pos);
            this._chestBtnClicked(param, param.controlEvent);
        }
    },
});

/**
 * 類型
 */
BaseRankDialog.Type = GSEnumHelper({
    TOKEN_SUBSYSTEM: -1,    // 代幣副系統
    STONE_GAMBLING: -1,     // 賭石大師
});

// TableView寬度
BaseRankDialog.TABLE_WIDTH = 334;