(function () {
    if (cc.sys.isNative)
        return;

    var checkHosts = ['office.mwsrv.com', 'localhost', '127.0', '192.168.'];
    var hostName = window.location.hostname;
    var findIt = checkHosts.some(function (host) { return hostName.indexOf(host) == 0; });

    if (findIt) {
        var log = getParameterByName('log');
        if (log) {
            log = decodeURIComponent(log);
            var errorUrl = 'http://' + log + '/error/';
            var wsUrl = 'http://' + log + '/ws/';

            var session = Date.now().toString()
            window.showSession = function () { console.log(session); };

            var revision = window.location.href.match(/\/(\d+)\//);
            revision = (revision && revision[1]) || 0;

            // 處理 error 先判斷TrackJS是否有開啟
            var trackJSObj = window._trackJs;
            var trackJSEnabled = false;
            if (trackJSObj && trackJSObj.enabled)
                trackJSEnabled = true;
            var customOnError = function (msg, url, line, column, error) {
                axios.post(errorUrl, {
                    msg: msg,
                    url: url,
                    line: line,
                    column: column,
                    stack: error ? error.stack : "",
                    ts: Date.now(),
                    session: session,
                    revision: revision
                });
                return false; // return true 會把後續的東西都停掉
            };

            if (!trackJSEnabled) {
                window.onerror = customOnError;
            } else {
                // TrackJS打開 要override掉他的error
                trackJs.configure({
                    onError: function (payload, error) {
                        customOnError(error.message, error.file, error.line, error.column, error);
                        return true;
                    }
                });
            }

            // 處理 ws
            var ignore = ['_ping', '_PONG', '_pong', 'online_num'];
            var OrigWebSocket = window.WebSocket;
            var callWebSocket = null;
            try {
                //iPad這邊會掛掉 用Try Catch包起來
                callWebSocket = OrigWebSocket.apply.bind(OrigWebSocket);
            } catch (e) {
                return;
            }
            var wsAddListener = OrigWebSocket.prototype.addEventListener;
            wsAddListener = wsAddListener.call.bind(wsAddListener);
            window.WebSocket = function WebSocket(url, protocols) {
                var ws;
                if (!(this instanceof WebSocket)) {
                    // Called without 'new' (browsers will throw an error).
                    ws = callWebSocket(this, arguments);
                } else if (arguments.length === 1) {
                    ws = new OrigWebSocket(url);
                } else if (arguments.length >= 2) {
                    ws = new OrigWebSocket(url, protocols);
                } else { // No arguments (browsers will throw an error)
                    ws = new OrigWebSocket();
                }
                ws.hijack = url.indexOf('gamesofa') > -1;
                wsAddListener(ws, 'message', function (event) {
                    if (ws.hijack && ignore.every(x => event.data.indexOf(x) != 0)) {
                        wsPost(event.data, 'receive');
                    }
                });
                return ws;
            }.bind();
            window.WebSocket.prototype = OrigWebSocket.prototype;
            window.WebSocket.prototype.constructor = window.WebSocket;

            var wsSend = OrigWebSocket.prototype.send;
            wsSend = wsSend.apply.bind(wsSend);
            OrigWebSocket.prototype.send = function (data) {
                if (this.hijack && ignore.every(x => data.indexOf(x) != 0)) {
                    wsPost(data, 'send');
                }
                return wsSend(this, arguments);
            };
        }

        function wsPost(data, type) {
            axios.post(wsUrl, {
                type: type,
                log: data,
                ts: Date.now(),
                session: session,
                revision: revision
            })
        }

        function getParameterByName(name, url) {
            if (!url) url = window.location.href;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        }
    }
})();