/**
 * 5.3.7 優惠券背包 - 票券cell
 * Created by Jimmy.Wen 2022/3/8
 */
var BonusBackpackCouponCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        // 優惠券容器
        var couponNodeArray = this.couponNodeArray = [];

        // 優惠券圖片
        for (var i = 0; i < 2; i++) {
            var couponSprite = new ccui.Scale9Sprite("bonusBackpack_pic_coupon.png");
            couponSprite.setCapInsets(cc.rect(13, 0, 5, 40));
            couponSprite.setPreferredSize(cc.size(163 - 61 * i, 45.5));
            !!i && couponSprite.setScaleX(-1);
            couponSprite.setPosition(7 + 266.5 * i, 4);
            couponSprite.setAnchorPoint(0, 0);
            couponNodeArray.push(couponSprite);
            this.addChild(couponNodeArray[i]);
        }

        // 左上「已使用」標籤
        var tagNode = this._tag = new cc.Node();
        var labelBgSprite = new cc.Sprite("#bonusBackpack_pic_label.png");
        labelBgSprite.setPosition(2.5, 2.5);
        tagNode.addChild(labelBgSprite);
        var labelSprite = new cc.Sprite("#bonusBackpack_word_using.png");
        labelSprite.setPosition(0, 4.5);
        tagNode.addChild(labelSprite);
        tagNode.setPosition(26, 36);
        this.addChild(tagNode);

        // 右側看獎勵/領獎按鈕
        {
            // 先創Sprite 等refresh再換圖
            var btnSprite = this._btnSprite = new cc.Sprite();
            var rewardButton = this._rewardButton = new GSControlButton(btnSprite, cc.size(60, 60));
            rewardButton.imgSprite = btnSprite;
            rewardButton.setChangeColorWhenDisabled(false);
            rewardButton.setCascadeOpacityEnabled(true);
            rewardButton.addTargetWithActionForControlEvents(this, this._getReward,
                cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
                cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
                cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
            rewardButton.setPosition(303, 25);

            // 領獎倒數計時文字
            var rewardTimeLabel = this._rewardTimeLabel = new GSTimeLabel("", JSFontName, 8);
            rewardTimeLabel.setFontFillColor(JSColor.BLACK);
            rewardTimeLabel.setMultiFormat("%hhH:%mmM", "%hhH:%mmM", "%mmM:%ssS");
            rewardTimeLabel.setPosition(28, 25);
            rewardButton.addChildToContentNode(rewardTimeLabel);

            // 可領獎的底下假按鈕
            var rewardButtonSprite = this._rewardButtonSprite = new ccui.Scale9Sprite("lobby_btn_01.png");
            rewardButtonSprite.setContentSize(cc.size(48, 14));
            rewardButtonSprite.setPosition(28, 10);
            rewardButton.addChildToContentNode(rewardButtonSprite);

            var rewardButtonLabel = new cc.LabelTTF(LocalizedString.Purchase("領取"), JSFontName, 9);
            rewardButtonLabel.setFontFillColor(JSColor.BLACK);
            rewardButtonLabel.setPosition(24, 7);
            rewardButtonSprite.addChild(rewardButtonLabel);

            this.addChild(rewardButton);
        }

        // 左側數字+% 文字圖
        var numberNode = this._numberNode = new GSNumberNode(200, "num_05", cc.size(26, 38), cc.size(4, 0), false, true, 0, "%d");
        numberNode.setSuffixMark("num_05_%.png", cc.size(36, 38));
        numberNode.setScale(0.65);
        numberNode.setPosition(95, 32);
        this.addChild(numberNode);

        // 左側 買一送一
        var buy1get1freeLabel = this._buy1get1freeLabel = new cc.LabelTTF(LocalizedString.Purchase("買一送一"), JSFontName, 16);
        buy1get1freeLabel.setPosition(105, 32);
        this.addChild(buy1get1freeLabel);

        // 下方優惠描述文字
        var descriptionText = this._descriptionText = new cc.LabelTTF("", JSFontName, 9);
        descriptionText.setPosition(93, 16);
        this.addChild(descriptionText);

        // 右方時鐘圖案
        var clockSprite = this.clockSprite = new cc.Sprite("#pic_icon_time.png");
        clockSprite.setPosition(182, 28);
        clockSprite.setScale(0.8);
        this.addChild(clockSprite);

        // 右方倒數計時文字
        var couponTimeLabel = this._couponTimeLabel = new GSTimeLabel("", JSFontName, 11);
        couponTimeLabel.setPosition(191, clockSprite.getPositionY());
        couponTimeLabel.setAnchorPoint(0, 0.5);
        couponTimeLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        couponTimeLabel.setMultiFormat("%dd Hari %hh Jm", "%hh Jm %mm Mnt", "%mm Mnt %ss Dtk");
        this.addChild(couponTimeLabel);
    },

    refreshCell: function (param) {
        // 取得資料
        this._param = param;

        // 左上已使用標籤顯示
        this._tag.setVisible(param.isUsing);

        // 取得計時器時間
        var leftTime = JSCodeUtility.getRemainTime(param.remainTime, param.socketTime);
        // 清除計時器倒數
        this._couponTimeLabel.clearTimer();
        this._rewardTimeLabel.clearTimer();

        // 非iap優惠券 不用顯示禮物盒
        this._btnSprite.setVisible(param.couponType === PurchaseCouponAssembleType.LIMIT_IAP);

        // 刷新領獎按鈕可點擊狀態
        if (this._rewardButton.rewardFlag)
            this._rewardButton.rewardFlag = undefined;

        // 依照是否可以領獎決定畫面內容
        if (param.isCanGetReward) {
            // 右方禮物盒按鈕圖片
            this._btnSprite.setSpriteFrame("bonusBackpack_btn_reward_02.png");
            this._rewardTimeLabel.setVisible(true);
            this._rewardButtonSprite.setVisible(true);

            // 可領獎倒數的計時器
            if (leftTime > 0) {
                this._rewardTimeLabel.countdownSeconds(leftTime, () => {
                    // 倒數完去刷新清單
                    GS.dispatchCustomEvent("NotifyUpdateCouponAssemble");
                });
            }

            // 優惠券顯示設定
            this.clockSprite.setVisible(false);
            this._couponTimeLabel.setString(LocalizedString.Purchase("已使用"));
            this._couponTimeLabel.setPositionX(193);
        } else {
            this._btnSprite.setSpriteFrame("bonusBackpack_btn_reward_01.png");
            this._rewardTimeLabel.setVisible(false);
            this._rewardButtonSprite.setVisible(false);

            // 優惠券的計時器
            if (leftTime > 0) {
                this._couponTimeLabel.countdownSeconds(leftTime, () => {
                    // 倒數完去刷新清單
                    GS.dispatchCustomEvent("NotifyUpdateCouponAssemble");
                });
            }

            // 禮物盒、優惠券顯示設定
            this._rewardTimeLabel.setVisible(false);
            this.clockSprite.setVisible(true);
            this._couponTimeLabel.setPositionX(191);
        }

        // 優惠券變色
        for (let i = 0; i < 2; i++) {
            this.couponNodeArray[i].setSpriteFrame(param.isCanGetReward ? "bonusBackpack_pic_coupon_gray.png" : "bonusBackpack_pic_coupon.png");
            this.couponNodeArray[i].setCapInsets(cc.rect(13, 0, 5, 40));
            this.couponNodeArray[i].setPreferredSize(cc.size(163 - 61 * i, 45.5));
        }

        // 根據優惠內容決定顯示數字圖或文字
        if (param.couponType === PurchaseCouponAssembleType.BUY_ONE_GET_ONE_FREE) {
            // 買一送一
            this._buy1get1freeLabel.setVisible(true);
            this._numberNode.setVisible(false);
        } else {
            // 其它
            this._buy1get1freeLabel.setVisible(false);
            this._numberNode.setVisible(true);
            this._numberNode.setNumber(parseInt(param.bonus));
        }

        // 更新優惠描述內容
        this._descriptionText.setString(param.description);

        // 沒有描述文字的話把數字往下一點點
        this._numberNode.setPositionY(param.description === "" ? 27 : 32);

        // 更新獎勵內容文字
        var rewardMsgText = "";
        for (var i = 0; i < param.rewardList.length; i++) {
            rewardMsgText += param.rewardList[i].toString();
            if (i !== param.rewardList.length - 1)
                rewardMsgText += "\n";
        }
        this._rewardMsgText = rewardMsgText;

        // 紀錄iap_id、plan編號
        this._iapId = param.iapId;
        this._plan = param.plan;
    },

    _getReward: function (sender, event) {
        var isTouched = (event === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || event === cc.CONTROL_EVENT_TOUCH_DOWN);

        if (event === cc.CONTROL_EVENT_TOUCH_DOWN || event === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE) {
            //已經產生泡泡框 或是不是iap優惠券 直接離開判定
            if (this._rewardMsgNode || this._param.couponType !== PurchaseCouponAssembleType.LIMIT_IAP)
                return;

            if (!this._param.isCanGetReward) {
                // 獎勵的文字
                var msgText = new cc.LabelTTF(this._rewardMsgText, JSFontName, 10);
                msgText.setFontFillColor(cc.color.BLACK);

                // 避免太多行爆框，太高時自動縮小文字
                while (msgText.getContentSize().height > 48)
                    msgText.setFontSize(msgText.getFontSize() - 0.5);

                // 加入泡泡框
                var param = {
                    mainNode: msgText,
                    style: BaseMessageNode.Style.WHITE_SHADOW,
                    direct: BaseMessageNode.Direct.RIGHT,
                    arrowType: BaseMessageNode.ArrowType.STRAIGHT,
                    arrowPadding: 0
                };
                var rewardMsgNode = this._rewardMsgNode = new BaseMessageNode(param);
                rewardMsgNode.setPosition(cc.pAdd(sender.getPosition(), cc.p(-3, 2)));
                rewardMsgNode.show();

                this.addChild(rewardMsgNode, 2);
            }
        } else if (event === cc.CONTROL_EVENT_TOUCH_UP_INSIDE) {
            // 點在寶箱裡面 檢查是不是要送領獎
            if (!sender.rewardFlag && this._param.isCanGetReward) {
                sender.rewardFlag = true;   // 防止玩家連點寶箱
                var jsonObject = {
                    iap_id: this._iapId,
                    plan: this._plan
                };
                DataProcess.sendString("iap_recharge_reward " + JSON.stringify(jsonObject));

                // 領獎等回應時壓loading
                GS.dispatchCustomEvent("NotifyBonusBackpackLoadingStart");
            }

            // 清掉泡泡框
            this._rewardMsgNode && this._rewardMsgNode.close();
            this._rewardMsgNode = null;
        } else if (!isTouched) {
            // 清掉泡泡框
            this._rewardMsgNode && this._rewardMsgNode.close();
            this._rewardMsgNode = null;
        }
    }
});

// Cell寬度
BonusBackpackCouponCell.WIDTH = 336;

// Cell高度
BonusBackpackCouponCell.HEIGHT = 54;