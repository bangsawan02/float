/**
 * 骰寶的紀錄 Label的zOrder統一在1 圖片在0 common的圖片在2
 */

var DiceBoRecordLayer = cc.Layer.extend({
    COLOR_BLUE: cc.color(23, 222, 255),
    COLOR_RED: cc.color(255, 69, 69),
    COLOR_BROWN: cc.color(206, 189, 182),
    COLOR_GREEN: cc.color(76, 255, 26),

    ctor: function () {
        this._super();

        var diceBoString = LocalizedString.DiceBo;

        this._isShow = false;

        // 先創一個空的Node來裝 用來做動畫用
        var aniNode = this._aniNode = new cc.Node();
        aniNode.setCascadeOpacityEnabled(true);
        aniNode.setPosition(JSVisibleSize.width, JSScreenBonusHeight);
        aniNode.setVisible(false);
        this.addChild(aniNode);

        // 20手頁面跟標題
        var bgSprite = new ccui.Scale9Sprite("db_bg_record.png");
        bgSprite.setPreferredSize(cc.size(226, 234));
        bgSprite.setAnchorPoint(0, 0);
        bgSprite.setPosition(252, 22);
        aniNode.addChild(bgSprite);

        var titleLabel = new cc.LabelTTF(diceBoString("最近20手開大小機率"), JSFontName, 8);
        titleLabel.setPosition(367, 238);
        aniNode.addChild(titleLabel, 1);

        var lineSprite = new cc.Sprite("#users_line.png");
        lineSprite.setPosition(367, 133);
        lineSprite.setRotation(90);
        lineSprite.setScaleX(5.5);
        aniNode.addChild(lineSprite, 2);

        var titles = [diceBoString("開骰"), diceBoString("點數"), diceBoString("大小")];
        var titlesPosX = [295, 329, 351];
        for (var x = 0; x < 2; x++) {
            for (var i = 0; i < 3; i++) {
                titleLabel = new cc.LabelTTF(titles[i], JSFontName, 8);
                titleLabel.setPosition(titlesPosX[i] + (100 * x), 225);
                titleLabel.setFontFillColor(this.COLOR_BROWN);
                aniNode.addChild(titleLabel, 1);
            }
        }

        // 百手的紀錄
        var hundredBg = new ccui.Scale9Sprite("db_bg_record.png");
        hundredBg.setPreferredSize(cc.size(200, 234));
        hundredBg.setAnchorPoint(0, 0);
        hundredBg.setPosition(62, 22);
        aniNode.addChild(hundredBg);

        var titleLabel = new cc.LabelTTF(diceBoString("前100手開獎次數"), JSFontName, 8);
        titleLabel.setPosition(162, 238);
        aniNode.addChild(titleLabel, 1);

        var wordLabel = new cc.LabelTTF(diceBoString("大"), JSFontName, 15);
        wordLabel.setPosition(204, 220);
        wordLabel.setFontFillColor(this.COLOR_BLUE);
        aniNode.addChild(wordLabel, 1);

        wordLabel = new cc.LabelTTF(diceBoString("小"), JSFontName, 15);
        wordLabel.setPosition(120, 220);
        wordLabel.setFontFillColor(this.COLOR_RED);
        aniNode.addChild(wordLabel, 1);

        var lineSprite = new cc.Sprite("#users_line.png");
        lineSprite.setPosition(162, 183);
        lineSprite.setScaleX(5);
        aniNode.addChild(lineSprite, 2);

        lineSprite = new cc.Sprite("#users_line.png");
        lineSprite.setPosition(179, 108);
        lineSprite.setRotation(90);
        lineSprite.setScaleX(4);
        aniNode.addChild(lineSprite, 2);

        // 前百記錄的骰子
        for (var i = 0; i < 6; i++) {
            for (var j = 0; j < 3; j++) {
                var diceSprite = new cc.Sprite(JSStringUtility.format("#db_dice_0%d.png", i + 1));
                diceSprite.setPosition(90 + (15 * j), 170 - (25 * i));
                diceSprite.setScale(0.875);
                aniNode.addChild(diceSprite);
            }

            var diceSprite = new cc.Sprite(JSStringUtility.format("#db_dice_0%d.png", i + 1));
            diceSprite.setPosition(192, 170 - (25 * i));
            diceSprite.setScale(0.875);
            aniNode.addChild(diceSprite);

            // 下方的線
            if (i < 5) {
                var lineSprite = new cc.Sprite("#users_line.png");
                lineSprite.setPosition(130, 157 - (25 * i));
                lineSprite.setScaleX(2.8);
                aniNode.addChild(lineSprite, 2);

                lineSprite = new cc.Sprite("#users_line.png");
                lineSprite.setPosition(215, 157 - (25 * i));
                lineSprite.setScaleX(2);
                aniNode.addChild(lineSprite, 2);
            }
        }

        // 動態創的畫面
        var recordListNode = this._recordListNode = new cc.Node();
        recordListNode.setCascadeOpacityEnabled(true);
        aniNode.addChild(recordListNode, 2);

        // 先重整一下畫面
        this._refreshRecordList();

        // 加Touch 先創好畫面可以點到的區塊
        this._touchBoundingBox = cc.rect(22, 22 + JSScreenBonusHalfHeight, 410, 234);
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this.onTouchBegan.bind(this)
        }, this);
    },

    /**
     * 更新記錄
     */
    _refreshRecordList: function () {
        var recordListNode = this._recordListNode;
        var diceBoString = LocalizedString.DiceBo;

        // 先把之前的記錄清掉
        recordListNode.removeAllChildren();

        // 處理資料
        var diceRecordArray = DataModal.vegasData.diceBoRecordArray;

        var totalRound = diceRecordArray.length;    // 總場次
        var bigRound = 0;                           // 開大的次數
        var smallRound = 0;                         // 開小的次數
        var tripleCount = [0, 0, 0, 0, 0, 0];       // 1~6豹子的次數
        var diceNumCount = [0, 0, 0, 0, 0, 0];      // 1~6數字的次數
        for (var i = 0; i < totalRound; i++) {
            var diceNum = diceRecordArray[totalRound - i - 1];      // 從最新的開始拿
            var diceNumTotal = 0;           // 記錄數字總合
            var isTriple = false;           // 是否為豹子

            if (diceNum[0] === diceNum[1] && diceNum[1] === diceNum[2]) {
                isTriple = true;
                tripleCount[diceNum[0] - 1]++;
            }

            // 數字總合
            for (var x = 0; x < 3; x++) {
                diceNumTotal += diceNum[x];
                diceNumCount[diceNum[x] - 1]++;
            }

            // 判斷是大還是小 扣掉豹子
            if (!isTriple)
                diceNumTotal > 10 ? bigRound++ : smallRound++;

            // 排畫面
            if (i < 20) {
                var rowIndex = Math.floor(i / 10);      // 第幾列
                var column = i % 10;                    // 第幾行
                var rowOffsetX = 100 * rowIndex;        // X位移
                var columnOffsetY = 19 * column;        // Y位移

                // 排骰子
                for (var x = 0; x < 3; x++) {
                    var diceSprite = new cc.Sprite(JSStringUtility.format("#db_dice_0%d.png", diceNum[x]));
                    diceSprite.setPosition(279 + (15 * x) + rowOffsetX, 212 - columnOffsetY);
                    diceSprite.setScale(0.875);
                    recordListNode.addChild(diceSprite);
                }

                // 骰數字
                var wordColor, wordText;
                if (isTriple) {
                    wordColor = this.COLOR_GREEN;
                    wordText = diceBoString("豹");
                } else if (diceNumTotal > 10) {
                    wordColor = this.COLOR_BLUE;
                    wordText = diceBoString("大");
                } else {
                    wordColor = this.COLOR_RED;
                    wordText = diceBoString("小");
                }

                var resultLabel = new cc.LabelTTF(diceNumTotal.toString(), JSFontName, 9);
                resultLabel.setPosition(329 + rowOffsetX, 212 - columnOffsetY);
                resultLabel.setFontFillColor(wordColor);
                recordListNode.addChild(resultLabel, 1);

                // 秀大小或豹子
                resultLabel = new cc.LabelTTF(wordText, JSFontName, 9);
                resultLabel.setPosition(351 + rowOffsetX, 212 - columnOffsetY);
                resultLabel.setFontFillColor(wordColor);
                recordListNode.addChild(resultLabel, 1);

                // 底線
                var lineSprite = new cc.Sprite("#users_line.png");
                lineSprite.setPosition(314 + rowOffsetX, 202 - columnOffsetY);
                lineSprite.setScaleX(2.8);
                recordListNode.addChild(lineSprite, 2);
            }
        }

        // 百手記錄的數字
        var bigText = new GSRichTextNode(JSStringUtility.format("#!FFFF00!#%d#!FFFFFF!#/%d", bigRound, totalRound), JSFontName, 15);
        bigText.setPosition(204, 200);
        recordListNode.addChild(bigText, 2);

        var smallText = new GSRichTextNode(JSStringUtility.format("#!FFFF00!#%d#!FFFFFF!#/%d", smallRound, totalRound), JSFontName, 15);
        smallText.setPosition(120, 200);
        recordListNode.addChild(smallText, 2);

        for (var i = 0; i < 6; i++) {
            var tripleText = new GSRichTextNode(JSStringUtility.format("#!FFFF00!#%d#!FFFFFF!#/%d", tripleCount[i], totalRound), JSFontName, 15);
            tripleText.setPosition(151, 170 - (25 * i));
            recordListNode.addChild(tripleText, 2);

            var numberText = new GSRichTextNode(JSStringUtility.format("#!FFFF00!#%d#!FFFFFF!#/%d", diceNumCount[i], totalRound * 3), JSFontName, 15);
            numberText.setPosition(223, 170 - (25 * i));
            recordListNode.addChild(numberText, 2);
        }
    },

    /**
     * 是否要出現
     * @param isShow
     * @param closeCallback 關掉後的通知
     */
    show: function (isShow, closeCallback) {
        if (!JSCodeUtility.checkIsdefined(isShow))
            isShow = true;

        if (this._isShow === isShow)
            return;

        this._isShow = isShow;

        var aniNode = this._aniNode;
        aniNode.stopAllActions();
        if (isShow) {
            // 在出現的時後再重整畫面就好
            this._refreshRecordList();

            this._closeCallback = closeCallback;

            // 動畫
            aniNode.setVisible(true);
            aniNode.runAction(cc.moveTo(0.2, cc.p(JSScreenBonusWidth, JSScreenBonusHeight)).easing(cc.easeBackOut()));
        } else {
            aniNode.runAction(cc.sequence(
                cc.moveTo(0.2, cc.p(JSVisibleSize.width, JSScreenBonusHeight)).easing(cc.easeBackIn()),
                cc.hide(),
                cc.callFunc(function () {
                    this._closeCallback && this._closeCallback();
                    this._closeCallback = null;
                }, this)
            ));
        }

    },

    /**
     * Touch
     */
    onTouchBegan: function (touch, event) {
        var aniNode = this._aniNode;

        var isVisible = aniNode.isVisible();
        if (!isVisible)
            return false;

        var target = event.getCurrentTarget();
        if (!target.isVisible())
            return false;
        for (var c = target.parent; c != null; c = c.parent) {
            if (!c.isVisible())
                return false;
        }

        var touchPos = aniNode.convertToNodeSpace(touch.getLocation());

        if (!cc.rectContainsPoint(this._touchBoundingBox, touchPos)) {
            // 點到外面 要縮畫面
            this.show(false);
        }
        return true;
    }
});