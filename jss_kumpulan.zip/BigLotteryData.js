/**
 * 9T 幸運彩票(從中文德撲移植)
 */
var BigLotteryData = cc.Class.extend({
    ctor: function () {
        // 初始化
        this.clean();

        // 註冊SocketKey
        DataProcess.addSocketKeyDispatch(this, {
            // 12.0 合併進彩券行
            "big_lottery_info_buy": this.cmd_big_lottery_info_buy,
            "big_lottery_my_ticket": this.cmd_big_lottery_my_ticket,
            "big_lottery_history": this.cmd_big_lottery_history,
            "big_lottery_auto_choose": this.cmd_big_lottery_auto_choose,
            "big_lottery_choose": this.cmd_big_lottery_choose,
        });
    },

    /**
     * 砍掉Data
     */
    destroyData: function () {
        DataProcess.removeSocketKeyDispatch(this);
    },

    /**
     * 清除資料
     */
    clean: function () {
        // 狀態
        this.status = BigLotteryData.Status.CLOSE;

        // 小紅點
        this.redDotStatus = BigLotteryData.RedDotStatus.NONE;

        // 是否有大紅包
        this.haveRedEnvelope = false;

        // 是否有加碼頭獎
        this.haveExtraMoney = false;

        // 儲值可得彩票
        this.purchaseTicketNum = 0;

        // 儲值進度條資料
        this.progressParam = undefined;

        // 儲值方案資料
        this.productArray = undefined;

        // 我的彩券資料
        this.myTicketParam = undefined;

        // 歷史紀錄資料
        this.historyParam = undefined;

        // 清掉小紅點相關判斷的資料
        this._isFirstInit = undefined;

        this._localStorePeriod = undefined;

        this._lastPeriod = undefined;

        this.purchaseSuccess = false;

        // 進度條的可領數目
        this.hasProgressReward = 0;

        // 預設開啟頁面
        this.openPage = 0;

        // 圖片Host
        this.productHost = "";
    },

    /**
     * 取得開獎剩餘時間
     */
    getDrawTime: function () {
        var nowTime = JSCodeUtility.getNowTime();

        return Math.max(this.drawLeftTime - (nowTime - this.socketTime), 0);
    },

    /**
     * 取得自己選號剩餘時間
     */
    getSelectTime: function () {
        var nowTime = JSCodeUtility.getNowTime();

        return Math.max(this.selectedTime - (nowTime - this.socketTime), 0);
    },

    /**
     * 抓上期彩券資料
     */
    getLastPeriodTicket: function () {
        if (this.historyParam && this.historyParam.historyList && this.historyParam.historyList.length)
            return this.historyParam.historyList[0];
    },

    // 判斷是不是重置中(重置或開獎完畢)
    isResetting: function () {
        var status = this.status;
        return status === BigLotteryData.Status.RESETTING || status === BigLotteryData.Status.DRAW_FINISH;
    },

    /**
     * 抓獎勵名稱(頭獎到普獎)
     */
    _getTitleName: function (index) {
        var titleName = "";

        switch (index) {
            case 1:
                titleName = "Hadiah Utama";
                break;

            case 2:
                titleName = "Hadiah Kedua";
                break;

            case 3:
                titleName = "Hadiah Ketiga";
                break;

            case 4:
                titleName = "Hadiah Keempat";
                break;

            case 5:
                titleName = "Hadiah Kelima";
                break;

            case 6:
                titleName = "Hadiah Hiburan";
                break;
        }

        return titleName;
    },

    /**
     *  解析中獎名單
     */
    _parseWinList: function (list, getPhotoUrl) {
        var param = [];

        list.forEach(cur => {
            // 標題
            var titleParam = {
                isTitle: true,                                                      // 是不是標題
                period: JSCodeUtility.getStringValue(cur["period"]),                // 期數
                prize: JSCodeUtility.getIntValue(cur["each_reward_money"])          // 獎金
            };

            param.push(titleParam);

            // 玩家
            var playerList = (cur["people_list"] || []);

            var tempArray = [];

            // 2個放一起
            for (var i = 0; i < playerList.length; ++i) {
                if (i % 2 === 0) {
                    tempArray = [];
                    param.push({
                        players: tempArray
                    });
                }

                tempArray.push({
                    picUrl: getPhotoUrl(playerList[i]["pic"]),                                  // 大頭照
                    nickname: JSCodeUtility.getDecodeStringValue(playerList[i]["nickname"]),    // 暱稱
                    userID: JSCodeUtility.getStringValue(playerList[i]["userid"])               // id
                });
            }
        });
        return param;
    },

    // 給外部處理
    processIconInfo: function (jsonValue) {
        // 防呆
        if (!jsonValue)
            return;

        // 抓帳號
        var account = DataModal.profileData.account;

        this.redDotStatus = BigLotteryData.RedDotStatus.NONE;

        // 狀態
        var status = JSCodeUtility.getIntValue(jsonValue["type"], BigLotteryData.Status.CLOSE);
        if (status !== BigLotteryData.Status.CLOSE) {
            // 收到時間
            this.socketTime = JSCodeUtility.getNowTime();

            // 資料更新時間
            this.refreshTime = JSCodeUtility.getIntValue(jsonValue["left_time"]);

            // 開獎剩餘時間
            this.drawLeftTime = JSCodeUtility.getIntValue(jsonValue["draw_left_time"]);

            // 自行選號時間
            this.selectedTime = JSCodeUtility.getIntValue(jsonValue["optional_left_time"]);

            // 期數
            this.period = JSCodeUtility.getStringValue(jsonValue["period"]);

            // 預設開啟頁面
            this.openPage = JSCodeUtility.getIntValue(jsonValue["open_page"]);

            // 小紅點
            if (JSCodeUtility.getIntValue(jsonValue["red_point"]))
                this.redDotStatus = BigLotteryData.RedDotStatus.PROGRESS;

            // 狀態改變
            if (status !== this.status) {
                // 記下狀態
                this.status = status;

                if (status === BigLotteryData.Status.NORMAL) {
                    // 需要刷新 歷史紀錄
                    this.needRefreshHistoryPage = true;
                } else {
                    // 要我的彩券
                    DataProcess.sendString("big_lottery_my_ticket");
                }

                // 判斷小紅點
                {
                    if (this._isFirstInit === undefined) {
                        // 有值表示抓過了就不再抓值了
                        // 抓紀錄
                        this._isFirstInit = GS.localStorage.getItem(UserDefaultKey.BigLotteryFirstIn + account, "1", true);
                    }

                    if (this._isFirstInit === "1") {
                        this.redDotStatus = BigLotteryData.RedDotStatus.FIRST_IN;

                        this._isFirstInit = "0";

                        // 紀錄
                        GS.localStorage.setItem(UserDefaultKey.BigLotteryFirstIn + account, "0", true);
                    }
                }

                // 判斷期數
                {
                    // 因為重置之後才會是新期數, 所以才會需要用上次的重置期數判斷
                    if (status === BigLotteryData.Status.RESETTING) {
                        var key = JSStringUtility.format("Texas_ResettingPeriod_%s", account);
                        if (!this._lastPeriod) {
                            this._lastPeriod = GS.localStorage.getItem(key, "");
                        }

                        if (this._lastPeriod !== this.period) {
                            this.redDotStatus = BigLotteryData.RedDotStatus.DRAW;

                            // 記錄下來
                            this._lastPeriod = this.period;
                            GS.localStorage.setItem(key, this._lastPeriod);
                        }
                    }
                }

                // 如果狀態改變成不能選號
                if (status === BigLotteryData.Status.CANNOT_SELECT) {
                    // 通知關閉選號dialog
                    GS.dispatchCustomEvent("NotifyBigLotterySelectDialogClose");
                }
            }

            // 判斷第一進入不同期數
            {
                var key = JSStringUtility.format("BigLottery_Period_%s", account);
                if (!this._localStorePeriod) {
                    this._localStorePeriod = GS.localStorage.getItem(key, "");
                }

                // 該期第一次進入
                if (this._localStorePeriod !== this.period) {
                    // 調整紀錄
                    this._localStorePeriod = this.period;

                    // 存起來
                    GS.localStorage.setItem(key, this._localStorePeriod);
                }
            }

        } else {
            // 關閉
            // 為了要在下次活動開啟時有小紅點
            // 這裡把小紅點打開
            // 狀況有變,第一次進遊戲也會變
            if (status !== this.status) {
                this.status = status;

                // 記下來
                GS.localStorage.setItem(UserDefaultKey.BigLotteryFirstIn + DataModal.profileData.account, "1", true);
            }
        }
    },

    /**
     * ===============
     * Socket Callback
     * ===============
     */

    // 印尼大樂彩使用 (將主頁面和購買方案整合)
    cmd_big_lottery_info_buy: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value || "{}");

        var infoValue = jsonValue["info"] || {};

        // 主頁面資料
        var infoParam = {};

        // 頭獎獎金
        infoParam.prize = JSCodeUtility.getIntValue(infoValue["first_prize"]);

        // 輪播秒數(預設3秒)
        infoParam.pollSec = JSCodeUtility.getIntValue(infoValue["marquee_poll"], 3);

        // 跑馬燈文字
        infoParam.marqueeArray = (infoValue["marquee"] || []).map(cur => {
            return JSCodeUtility.getStringValue(cur);
        });

        // 加碼資料
        var bonusValue = infoValue["fiesta_bonus"];
        if (bonusValue) {
            // 大紅包
            infoParam.envelope = JSCodeUtility.getIntValue(bonusValue["big_red_envelope"]);

            // 記下有沒有大紅包
            this.haveRedEnvelope = infoParam.envelope > 0;

            // 頭獎加碼
            infoParam.extraPrice = JSCodeUtility.getIntValue(bonusValue["first_prize_plus"]);

            // 記下有沒有頭獎加碼
            this.haveExtraMoney = infoParam.extraPrice > 0;

            // 幸運數字獎金
            infoParam.luckyNumber = JSCodeUtility.getIntValue(bonusValue["lucky_number_reward"]);

            // 行事曆
            infoParam.scheduleArray = (bonusValue["notify_scheduled"] || []).map(cur => {
                return {
                    dateStr: JSCodeUtility.getStringValue(cur["dateTime"]),                         // 日期
                    typeArray: (cur["type"] || []).map(type => JSCodeUtility.getIntValue(type)),    // 加碼類型
                    isExpired: JSCodeUtility.getIntValue(cur["expired"])                            // 是不是過期了
                };
            });
        } else {
            this.haveRedEnvelope = false;

            this.haveExtraMoney = false;
        }

        // 購買方案資料
        var buyValue = jsonValue["buy"] || {};

        // 圖片Host
        this.productHost = buyValue["productHost"] || "";

        // 儲值方案資料(包含按鈕顯示資訊)
        this.productArray = (buyValue["bill_list"] || []).map((cur, index) => {
            let productValue = cur["productList"] || [];
            let productList = productValue.map((cur) => {
                return {
                    productID: JSCodeUtility.getStringValue(cur["productid"]),  // productID
                    pot_rate: JSCodeUtility.getIntValue(cur["pot_rate"]),
                    fund_rate: JSCodeUtility.getIntValue(cur["fund_rate"]),
                    ticketNum: JSCodeUtility.getIntValue(cur["ticketCnt"]),     // 可獲得彩票數量
                    pic: JSCodeUtility.getStringValue(cur["pic"])
                };
            });

            var providerParam = {
                titleString: JSCodeUtility.getStringValue(cur["productDesc"]),  // 第三方視窗標題
                productIDList: productValue.map((cur) => {
                    return JSCodeUtility.getStringValue(cur["productid"])
                }),
                providerPicList: productValue.map((cur) => {
                    return JSCodeUtility.getStringValue(cur["pic"])
                }),
                imageUrl: this.productHost
            };

            return {
                index: index,                                               // 索引
                title: JSCodeUtility.getStringValue(cur["title"]),          // 標題
                content: JSCodeUtility.getStringValue(cur["msg"]),          // 內文
                isHot: JSCodeUtility.getIntValue(cur["isHot"]) === 1,       // 是否限購
                price: JSCodeUtility.getStringValue(cur["btn"]),            // 儲值金額
                imgType: JSCodeUtility.getIntValue(cur["png"]),             // 彩票圖檔
                productList: productList,                                   // 儲值方資訊
                providerParam: providerParam                                // 第三方儲值視窗param
            };
        });


        // 進度條可領數目
        this.hasProgressReward = 0;

        // 儲值進度 TODO 5.2.4 目前沒用到
        var progressValue = jsonValue["extra_bonus"];
        if (progressValue) {
            var progressParam = this.progressParam = {};

            // 總張數
            progressParam.totalTicket = JSCodeUtility.getIntValue(progressValue["total_cnt"]);

            // 任務
            var missionValue = progressValue["reward_list"];
            if (Array.isArray(missionValue)) {
                var needRedDot = false;

                progressParam.missionList = missionValue.map((mission, index) => {
                    var missionParam = {};

                    // 索引(server是從1開始，所以+1)
                    missionParam.index = index + 1;

                    // 所需的票
                    missionParam.ticket = JSCodeUtility.getIntValue(mission["reach_goal"]);

                    // 是否已領過
                    var alreadyReceive = JSCodeUtility.getIntValue(mission["is_get"]) === 1;
                    if (alreadyReceive) {
                        // 已領過設為已領過
                        missionParam.status = BigLotteryData.RewardStatus.ALREADY_RECEIVE;
                    } else if (progressParam.totalTicket >= missionParam.ticket) {
                        // 還沒領過但可以領獎
                        missionParam.status = BigLotteryData.RewardStatus.CAN_RECEIVE;
                        needRedDot = true;
                        ++this.hasProgressReward;
                    } else {
                        // 不能領獎
                        missionParam.status = BigLotteryData.RewardStatus.CANNOT_RECEIVE;
                    }

                    // 獎勵
                    missionParam.rewards = (mission["reward"] || []).map(cur => JSCodeUtility.getStringValue(cur["name"]));

                    return missionParam;
                });

                // 找出任務所需要的最大數量去算進度
                var maxTicket = progressParam.missionList.reduce((prev = 0, cur) => {
                    return prev > cur.ticket ? prev : cur.ticket;
                });
            }
        }

        // 通知UI
        GS.dispatchCustomEvent("NotifyBigLotteryInfoBuyDone", infoParam);
    },

    // 我的彩券頁面資料
    cmd_big_lottery_my_ticket: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value || "{}");

        var myTicketParam = this.myTicketParam = {
            totalTicketNum: 0,          // 總彩票數量
            notSelectTicketNum: 0,      // 未選號彩票數量
            autoSelectTicketNum: 0,     // 自動選號數量
            currentTicketCount: 0,      // 目前是第幾張
            drawNumList: [],            // 頭獎數字
            marqueeList: [],            // 跑馬燈訊息
            ticketList: []              // 我的彩票
        };

        // 頭獎數字
        var drawValue = jsonValue["draw_numbers"];
        if (Array.isArray(drawValue) && drawValue.length > 0) {
            myTicketParam.drawNumList = drawValue.map(cur => JSCodeUtility.getIntValue(cur));
        }

        // 跑馬燈訊息
        var marqueeValue = jsonValue["marquee"];
        if (Array.isArray(marqueeValue) && marqueeValue.length > 0) {
            myTicketParam.marqueeList = marqueeValue.map(cur => JSCodeUtility.getStringValue(cur));
        }

        // 彩券
        var ticketListValue = jsonValue["my_numbers_list"];
        if (Array.isArray(ticketListValue) && ticketListValue.length > 0) {

            myTicketParam.totalTicketNum = ticketListValue.length;  // 總數量

            ticketListValue.forEach(ticket => {
                var numberValue = ticket["numbers"];
                if (Array.isArray(numberValue) && numberValue.length > 0) {
                    var ticketParam = {
                        period: this.period,                                            // 期數
                        rewardType: JSCodeUtility.getIntValue(ticket["reward_type"]),   // 獎勵類型
                        selectType: JSCodeUtility.getIntValue(ticket["choose_type"]),   // 選號方式
                        numList: numberValue.map(cur => JSCodeUtility.getIntValue(cur)) // 號碼
                    };

                    // 是不能買彩券時電腦自選的
                    if (ticketParam.selectType === BigLotteryData.LotterySelectType.CANNOT_BUY_AUTO_SELECT)
                        myTicketParam.autoSelectTicketNum++;

                    myTicketParam.ticketList.push(ticketParam);
                } else {
                    // 沒有號碼代表未選號，未選號數量加一
                    myTicketParam.notSelectTicketNum++;
                }
            });

            // 如果有沒自選的票,當前玩家填到第幾章就可以從1開始
            if (myTicketParam.notSelectTicketNum)
                myTicketParam.currentTicketCount = 1;
        }

        // 通知UI
        GS.dispatchCustomEvent("NotifyBigLotteryMyTicketInfoDone");

        // 是儲值後的刷新
        if (this.purchaseSuccess) {
            // 通知UI
            GS.dispatchCustomEvent("NotifyPurchaseSuccessWithNewData");

            // 調整flag
            this.purchaseSuccess = false;
        }
    },

    // 歷史紀錄頁面資料
    cmd_big_lottery_history: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value || "{}");

        this.needRefreshHistoryPage = false;

        var lastPeriod = "";    // 用來記錄上一期數
        var historyParam = this.historyParam = {};

        // 歷史紀錄
        historyParam.historyList = (jsonValue["history_log"] || []).map(history => {
            return {
                hasWinner: JSCodeUtility.getIntValue(history["has_first_prize"]),               // 有沒有人得頭獎
                period: JSCodeUtility.getStringValue(history["period"]),                        // 期數
                numList: (history["numbers"] || []).map(cur => JSCodeUtility.getIntValue(cur))  // 中獎號碼
            };
        });

        // 上期期號就是歷史紀錄最新那筆資料的期號
        if (historyParam.historyList.length > 0) {
            lastPeriod = historyParam.historyList[0].period;
        }

        // 前期我的彩券
        historyParam.lastTicketList = (jsonValue["pre_numbers_list"] || []).map(ticket => {
            return {
                rewardType: JSCodeUtility.getIntValue(ticket["reward_type"], BigLotteryData.LotteryRewardType.NO_WIN),
                period: lastPeriod,
                numList: (ticket["numbers"] || []).map(cur => JSCodeUtility.getIntValue(cur))
            };
        });

        // 排行榜大頭貼的base url 格式 {"d":"//d.mwsrv.com/texas9/images/","id-rvp":"//id-rvp.mwsrv.com/users.photo/"}
        var baseUrlJson = jsonValue["photo_base_url"];

        // 把玩家頭像路徑跟baseUrl組合起來
        // picJson格式:
        //     ["d","default_pic/photo_m-4.png"]    // 第一個參數代表base url的索引
        //     ["ori","https://graph.facebook.com/410205269861703/picture?type=normal&height=130&width=130"] // 索引是ori代表他是完整網址
        var getPhotoUrl = function getPhotoUrl(picJson) {
            picJson = picJson || [];
            if (picJson.length < 2) return "";

            var urlType = picJson[0];
            var urlStr = JSCodeUtility.getStringValue(picJson[1]);

            // 索引是ori代表他是完整網址 直接回傳
            if (urlType === "ori") return urlStr;

            return GS.httpScheme + JSCodeUtility.getStringValue(baseUrlJson[urlType]) + "/" + urlStr;
        };

        // 大紅包資訊
        {
            // 大紅包中獎號碼
            historyParam.envelopeHistoryList = (jsonValue["red_history_log"] || []).map(cur => {
                return {
                    winnerCount: JSCodeUtility.getIntValue(cur["red_win_count"]),               // 有多少人中頭獎
                    period: JSCodeUtility.getStringValue(cur["red_period"]),                    // 期數
                    numList: (cur["red_numbers"] || []).map(innercur => JSCodeUtility.getIntValue(innercur)), // 中獎號碼
                };
            });

            // 大紅包中獎人數
            historyParam.envelopeCount = JSCodeUtility.getIntValue(jsonValue["red_win_count"]);

            // 大紅包歷史紀錄
            historyParam.envelopeHistoryArray = (jsonValue["red_winner_list"] || []).map(cur => {
                return {
                    period: JSCodeUtility.getStringValue(cur["period"]),                    // 期數
                    prize: JSCodeUtility.getIntValue(cur["each_reward_money"]),             // 獎金
                    userArray: (cur["people_list"] || []).map(user => {                     // 得獎名單
                        return {
                            picUrl: getPhotoUrl(user["pic"]),                               // 大頭照
                            nickname: JSCodeUtility.getDecodeStringValue(user["nickname"]), // 暱稱
                            userID: JSCodeUtility.getStringValue(user["userid"]),           // id
                        };
                    }),
                };
            });

        }

        // 得獎者
        var winnerListValue = jsonValue["winner_list"];
        if (winnerListValue) {
            historyParam.winnerList = [];

            // 共有六個獎項
            for (var i = 1; i <= 6; i++) {
                // 先塞標題
                historyParam.winnerList.push({
                    isTitle: true,
                    title: this._getTitleName(i),
                    fontColor: (i === 1) ? JSColor.YELLOW : JSColor.WHITE
                });

                var winnerValue = winnerListValue[i];
                if (Array.isArray(winnerValue) && winnerValue.length) {
                    winnerValue.forEach((cur, index) => {
                        var rankParam = {
                            isTitle: false,
                            nickName: JSCodeUtility.getDecodeStringValue(cur["nickname"]),
                            userID: JSCodeUtility.getStringValue(cur["userid"]),
                            rewardType: JSCodeUtility.getIntValue(cur["which_prize"], i),
                            photoUrl: getPhotoUrl(cur["pic"]),
                            fontColor: (i === 1) ? JSColor.YELLOW : JSColor.WHITE,
                            isLast: (index === winnerValue.length - 1)
                        };

                        historyParam.winnerList.push(rankParam);
                    });
                } else {
                    // 沒人中獎，塞一個本期槓龜
                    historyParam.winnerList.push({
                        nickName: LocalizedString.BigLottery("本期無人中獎"),
                        fontColor: (i === 1) ? JSColor.YELLOW : JSColor.WHITE,
                        isLast: true
                    });
                }
            }
        }

        // 獎勵資料
        var rewardValue = jsonValue["reward_list"];
        if (rewardValue) {
            historyParam.rewardList = [];

            // 共有六個獎項
            for (var i = 1; i <= 6; i++) {
                var chestValue = rewardValue[i];
                if (Array.isArray(chestValue) && chestValue.length) {
                    var chestParam = chestValue.map(cur => {
                        return {
                            name: JSCodeUtility.getStringValue(cur["name"]),
                            wid: JSCodeUtility.getStringValue(cur["wid"])
                        };
                    });

                    historyParam.rewardList.push(chestParam);
                }
            }
        }

        // 記住上一期期號
        historyParam.lastPeriod = lastPeriod;

        // 幸運數字資訊
        {
            // 幸運數字 歷史紀錄
            historyParam.luckyHistoryList = (jsonValue["lucky_history_log"] || []).map(cur => {
                return {
                    winnerCount: JSCodeUtility.getIntValue(cur["lucky_win_count"]),     // 有多少人中獎
                    period: JSCodeUtility.getStringValue(cur["lucky_period"]),          // 期數
                    number: JSCodeUtility.getIntValue(cur["lucky_numbers"])             // 中獎號碼
                };
            });

            // 幸運數字 中獎名單
            historyParam.luckyHistoryArray = this._parseWinList(jsonValue["lucky_winner_list"] || [], getPhotoUrl);
        }

        // 大紅包資訊
        {
            // 大紅包 歷史紀錄
            historyParam.envelopeHistoryList = (jsonValue["red_history_log"] || []).map(cur => {
                return {
                    winnerCount: JSCodeUtility.getIntValue(cur["red_win_count"]),               // 有多少人中頭獎
                    period: JSCodeUtility.getStringValue(cur["red_period"]),                    // 期數
                    numList: (cur["red_numbers"] || []).map(innerCur => JSCodeUtility.getIntValue(innerCur)) // 中獎號碼
                };
            });

            // 大紅包中獎人數
            historyParam.envelopeCount = JSCodeUtility.getIntValue(jsonValue["red_win_count"]);

            // 大紅包 中獎名單
            historyParam.envelopeHistoryArray = this._parseWinList(jsonValue["red_winner_list"] || [], getPhotoUrl);
        }
        // 通知UI
        GS.dispatchCustomEvent("NotifyBigLotteryHistoryInfoDone");
    },

    // 選號結果cmd
    cmd_big_lottery_choose: function (key, value) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            return;

        var jsonValue = JSON.parse(value || "{}");

        // 是否成功
        var param = {
            isSuccess: JSCodeUtility.getIntValue(jsonValue["success"]) === 1
        };
        if (param.isSuccess) {
            var myTicketParam = this.myTicketParam;
            if (myTicketParam) {
                // 還不會更新資料
                // 剩餘彩票要減少，當前選到要增加
                --myTicketParam.notSelectTicketNum;
                ++myTicketParam.currentTicketCount;
            }
        }

        // 通知UI
        GS.dispatchCustomEvent("NotifyBigLotterySelectResult", param);
    },

    // 自動選號結果cmd
    cmd_big_lottery_auto_choose: function (key, value) {
        var jsonValue = JSON.parse(value || "{}");

        // 是否成功
        var param = {isSuccess: JSCodeUtility.getIntValue(jsonValue["success"]) === 1};
        if (param.isSuccess) {
            // 自動選號的張數
            param.ticketNum = JSCodeUtility.getIntValue(jsonValue["res_cnt"]);
        }

        // 通知UI
        GS.dispatchCustomEvent("NotifyBigLotteryAutoSelectResult", param);
    },
});

/**
 * 狀態
 */
BigLotteryData.Status = {
    CLOSE: -1,                // 關閉
    NORMAL: 0,                // 活動開始
    CANNOT_BUY: 1,            // 不准買票，但是可以選號
    CANNOT_SELECT: 2,         // 不能選號，但是電腦會幫你選
    RESETTING: 3,             // 重置中
    AUTO_SELECT_FINISH: 4,    // 電腦選號完畢
    DRAW_FINISH: 5            // 開獎完畢(已經抽出號碼)
};

/**
 * 獎勵狀態
 */
BigLotteryData.RewardStatus = {
    CAN_RECEIVE: 0,     // 可領獎
    CANNOT_RECEIVE: 1,  // 不能領獎
    ALREADY_RECEIVE: 2  // 已領獎
};

/**
 * 獎勵類型
 */
BigLotteryData.LotteryRewardType = {
    NO_WIN: -1,         // 未中獎
    NO_DRAW: 0,         // 未開獎
    FIRST_PRICE: 1,     // 頭獎
    SECOND_PRICE: 2,    // 貳獎
    THIRD_PRICE: 3,     // 參獎
    FOURTH_PRICE: 4,    // 肆獎
    FIFTH_PRICE: 5,     // 伍獎
    NORMAL_PRICE: 6,    // 普獎
    RED_ENVELOPE: 88,   // 大紅包
    LUCKY_NUMBER: 77,   // 幸運數字
    UNSELECTED: 99      // 未選號
};

/**
 * 選號方式
 */
BigLotteryData.LotterySelectType = {
    NOT_SELECT: 0,              // 未選號
    MANUAL_SELECT: 1,           // 手動選號
    AUTO_SELECT: 2,             // 電腦選號
    CANNOT_BUY_AUTO_SELECT: 3,  // 不能買彩券時電腦自選
    MANUAL_INPUT: 4             // 手動塞入
};

/**
 * 加碼類型
 */
BigLotteryData.LotteryBonusType = {
    ENVELOPE: 1,        // 大紅包
    EXTRA_PERIOD: 2,    // 加開一期
    EXTRA_MONEY: 3,     // 頭獎加碼
    LUCKY_NUMBER: 4     // 幸運數字
};

/**
 * 取得活動名稱
 */
BigLotteryData.getBonusEventNameByType = function (type) {
    var bigLotteryStr = LocalizedString.BigLottery;
    switch (type) {
        case BigLotteryData.LotteryBonusType.ENVELOPE:
            return bigLotteryStr("大紅包");
        case BigLotteryData.LotteryBonusType.EXTRA_PERIOD:
            return bigLotteryStr("加開一期");
        case BigLotteryData.LotteryBonusType.EXTRA_MONEY:
            return bigLotteryStr("頭獎加碼");
        case BigLotteryData.LotteryBonusType.LUCKY_NUMBER:
            return bigLotteryStr("幸運數字");
        default:
            return "";
    }
};

/**
 * 判斷小紅點的依據
 */
BigLotteryData.RedDotStatus = {
    NONE: -1,       //
    FIRST_IN: 0,    // 第一次進入
    PROGRESS: 1,    // 進度可領獎
    DRAW: 2         // 開獎
};