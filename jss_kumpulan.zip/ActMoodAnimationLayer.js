/**
 * 互動道具動畫頁面
 */

var ActMoodAnimationLayer = cc.Layer.extend({
    ctor: function () {
        this._super();
    },

    /**
     * 送互動道具
     * @param serial    序號
     * @param fromPos   從哪一個位置
     * @param toPos     到哪一個位置
     * @param nickName  暱稱
     */
    _startSendActMoods: function (serial, fromPos, toPos, nickName) {
        var url = MoodItemGAFBaseUrl + serial + ".zip";
        var entryFile = JSStringUtility.format("%s/%s.gaf", serial, serial);
        var saveFileName = JSWriteablePath + "actMoods/" + serial + ".zip";
        gaf.createAndDownloadWithBundle(url, saveFileName, entryFile, this, (gafAsset) => {
            if (!gafAsset)
                return;

            // 已經砍掉了不做事
            if (this.__isDestroyed)
                return;

            var gameData = DataModal.gameData;

            var reallyFromPos = (fromPos === -1 ? -1 : gameData.getDirectionByServerDirection(fromPos));
            var reallyToPos = (toPos === -1 ? -1 : gameData.getDirectionByServerDirection(toPos));

            // 額外的Scale
            var bonusScale = 0;
            var fromPosition = cc.p(0, 0);
            var toPosition = cc.p(0, 0);
            var needFlipX = false;
            switch (GS.nowGame) {
                case GSEnum.Game.Texas:
                    // Texas
                    bonusScale = 0.3;    // 德撲的互動道具比較大
                    fromPosition = Texas_GameUtility.getPlayerPosition(reallyFromPos);      // 誰丟
                    toPosition = Texas_GameUtility.getPlayerPosition(reallyToPos);          // 誰被丟

                    // 是否要翻轉 1:不需要 -1:需要 右邊(idx=8)要翻轉 不然有些互動道具會看不到
                    needFlipX = reallyToPos === 8 ? -1 : 1;
                    break;

                case GSEnum.Game.Domino:
                    // Domino
                    fromPosition = Domino_GameUtility.getPlayerPosition(reallyFromPos);     // 誰丟
                    toPosition = Domino_GameUtility.getPlayerPosition(reallyToPos);         // 誰被丟

                    // 是否要翻轉 1:不需要 -1:需要 右邊(idx > 3)要翻轉 不然有些互動道具會看不到
                    needFlipX = reallyToPos > 3 ? -1 : 1;
                    break;

                case GSEnum.Game.Gaple:
                case GSEnum.Game.GapleChat:
                case GSEnum.Game.GaplePlus:
                case GSEnum.Game.GapleFriend:
                case GSEnum.Game.GapleVideo:
                    // Gaple Gaple加倍
                    fromPosition = Gaple_GameUtility.getPlayerPosition(reallyFromPos);      // 誰丟
                    toPosition = Gaple_GameUtility.getPlayerPosition(reallyToPos);          // 誰被丟

                    // 是否要翻轉 1:不需要 -1:需要 右邊(idx > 3)要翻轉 不然有些互動道具會看不到
                    needFlipX = reallyToPos > 2 ? -1 : 1;
                    break;

                case GSEnum.Game.Cangkulan:
                case GSEnum.Game.Remi:
                    // Remi Cangkulan
                    fromPosition = Remi_GameUtility.getPlayerPosition(reallyFromPos);      // 誰丟
                    toPosition = Remi_GameUtility.getPlayerPosition(reallyToPos);          // 誰被丟

                    // 是否要翻轉 1:不需要 -1:需要 右邊(idx > 3)要翻轉 不然有些互動道具會看不到
                    needFlipX = reallyToPos > 2 ? -1 : 1;
                    break;

                case GSEnum.Game.CapsaSusun:
                    // CapsaSusun
                    fromPosition = CapsaSusun_GameUtility.getPlayerPosition(reallyFromPos);      // 誰丟
                    toPosition = CapsaSusun_GameUtility.getPlayerPosition(reallyToPos);          // 誰被丟

                    // 是否要翻轉 1:不需要 -1:需要 右邊(idx > 3)要翻轉 不然有些互動道具會看不到
                    needFlipX = reallyToPos > 2 ? -1 : 1;
                    break;

                case GSEnum.Game.TebakQQ:
                    // TebakQQ
                    fromPosition = TebakQQ_GameUtility.getPlayerPosition(fromPos);      // 誰丟
                    toPosition = TebakQQ_GameUtility.getPlayerPosition(toPos);          // 誰被丟

                    // 是否要翻轉 1:不需要 -1:需要 右邊(idx > 3)要翻轉 不然有些互動道具會看不到
                    needFlipX = reallyToPos > 2 ? -1 : 1;
                    break;
            }

            var gafObject = gafAsset.createObjectAndRun(true);
            gafObject.setPosition(fromPosition);
            gafObject.pauseAnimation();
            this.addChild(gafObject);

            // 跑移動動畫
            var scaleNormal = 0.5 + bonusScale;
            var scaleBig = 0.65 + bonusScale;
            gafObject.setScale(needFlipX * scaleNormal, scaleNormal);

            var moveAction = cc.spawn(
                cc.moveTo(0.8, toPosition).easing(cc.easeQuadraticActionOut()),
                cc.sequence(
                    cc.scaleTo(0.3, needFlipX * scaleBig, scaleBig).easing(cc.easeQuadraticActionOut()),
                    cc.scaleTo(0.5, needFlipX * scaleNormal, scaleNormal).easing(cc.easeQuadraticActionOut())
                )
            );
            gafObject.runAction(cc.sequence(
                cc.delayTime(0.2),
                moveAction,
                cc.callFunc(function () {
                    gafObject.resumeAnimation();
                })
            ));

            // 設定撥完動畫後的事
            gafObject.addEventListener(gaf.EVENT_SEQUENCE_END, function () {
                // 停止動畫 (要delay一下)
                gafObject.runAction(cc.sequence(
                    cc.delayTime(0.01),
                    cc.removeSelf()
                ));
            });
        });

        // 紀錄ㄧ生只有一次的表情提示訊息
        var hasShowHint = parseInt(GS.localStorage.getItem("hadShowActMoodsHint", ""));
        if (!hasShowHint) {
            // 假如有暱稱 且表情是丟向自己 代表荷官要說話提示
            var name = (nickName) ? nickName : fromPos === -1 ? "" : DataModal.gameData.playerDataArray[fromPos].nickname;
            if (name && (DataModal.gameData.getIsSelfByServerSitNum(toPos))) {
                switch (GS.nowGame) {
                    case GSEnum.Game.Texas:
                    case GSEnum.Game.Domino:
                        // Texas 跟 Domino 有荷官
                        // 荷官右邊的訊息
                        var message = JSStringUtility.format(LocalizedString.Game("%s對您使用互動道具\n，您可以點擊他的頭像選擇\n互動道具使用唷!"), name);
                        var messageLabel = new cc.LabelTTF(message, JSFontBoldName, 12);
                        messageLabel.setFontFillColor(JSColor.BLACK);
                        var param = {
                            mainNode: messageLabel,
                            style: BaseMessageNode.Style.GOLD,
                            direct: BaseMessageNode.Direct.LEFT,
                            arrowType: BaseMessageNode.ArrowType.SLANT,
                            isFlip: false,
                            arrowPadding: -10
                        };
                        var msgNode = new BaseMessageNode(param);
                        msgNode.setPosition(JSScreenMidPos.x + 16, 260 + JSScreenBonusHalfHeight);
                        msgNode.show(2, true);
                        this.addChild(msgNode);
                        // 顯示過了 下次不用顯示
                        GS.localStorage.setItem("hadShowActMoodsHint", "1");
                        break;

                    case GSEnum.Game.Gaple:
                    case GSEnum.Game.GapleChat:
                    case GSEnum.Game.GaplePlus:
                    case GSEnum.Game.GapleFriend:
                    case GSEnum.Game.GapleVideo:
                    case GSEnum.Game.Remi:
                    case GSEnum.Game.Cangkulan:
                    case GSEnum.Game.CapsaSusun:
                    default:
                        break;
                }
            }
        }
    },

    /**
     * 送禮包
     * @param serial    序號
     * @param fromPos   從哪一個位置
     * @param toPos     到哪一個位置
     */
    _startSendGiftPackage: function (serial, fromPos, toPos, nickName) {

        //圖片
        var url = ShopItemBaseUrl + serial + ".png";
        var saveFileName = JSStringUtility.format("%sshop/%d.png", JSWriteablePath, serial);
        var imageSprite = new GSDownloadSprite("", url, saveFileName, function () {
            var gameData = DataModal.gameData;

            var reallyFromPos = (fromPos === -1 ? -1 : gameData.getDirectionByServerDirection(fromPos));
            var reallyToPos = (toPos === -1 ? -1 : gameData.getDirectionByServerDirection(toPos));

            // 額外的Scale
            var bonusScale = 0;
            switch (GS.nowGame) {
                case GSEnum.Game.Texas:
                    // Texas
                    bonusScale = 0.3;    // 德撲的互動道具比較大
                    var fromPosition = Texas_GameUtility.getPlayerPosition(reallyFromPos);      // 誰丟
                    var toPosition = Texas_GameUtility.getPlayerPosition(reallyToPos);          // 誰被丟

                    // 是否要翻轉 1:不需要 -1:需要 右邊(idx=8)要翻轉 不然有些互動道具會看不到
                    var needFlipX = reallyToPos === 8 ? -1 : 1;
                    break;

                case GSEnum.Game.Domino:
                    // Domino
                    var fromPosition = Domino_GameUtility.getPlayerPosition(reallyFromPos);     // 誰丟
                    var toPosition = Domino_GameUtility.getPlayerPosition(reallyToPos);         // 誰被丟

                    // 是否要翻轉 1:不需要 -1:需要 右邊(idx > 3)要翻轉 不然有些互動道具會看不到
                    var needFlipX = reallyToPos > 3 ? -1 : 1;
                    break;

                case GSEnum.Game.Gaple:
                case GSEnum.Game.GapleChat:
                case GSEnum.Game.GaplePlus:
                case GSEnum.Game.GapleFriend:
                case GSEnum.Game.GapleVideo:
                    // Gaple Gaple加倍
                    var fromPosition = Gaple_GameUtility.getPlayerPosition(reallyFromPos);      // 誰丟
                    var toPosition = Gaple_GameUtility.getPlayerPosition(reallyToPos);          // 誰被丟

                    // 是否要翻轉 1:不需要 -1:需要 右邊(idx > 3)要翻轉 不然有些互動道具會看不到
                    var needFlipX = reallyToPos > 2 ? -1 : 1;
                    break;

                case GSEnum.Game.Cangkulan:
                case GSEnum.Game.Remi:
                    // Remi Cangkulan
                    var fromPosition = Remi_GameUtility.getPlayerPosition(reallyFromPos);      // 誰丟
                    var toPosition = Remi_GameUtility.getPlayerPosition(reallyToPos);          // 誰被丟

                    // 是否要翻轉 1:不需要 -1:需要 右邊(idx > 3)要翻轉 不然有些互動道具會看不到
                    var needFlipX = reallyToPos > 2 ? -1 : 1;
                    break;

                case GSEnum.Game.CapsaSusun:
                    // CapsaSusun
                    var fromPosition = CapsaSusun_GameUtility.getPlayerPosition(reallyFromPos);      // 誰丟
                    var toPosition = CapsaSusun_GameUtility.getPlayerPosition(reallyToPos);          // 誰被丟

                    // 是否要翻轉 1:不需要 -1:需要 右邊(idx > 3)要翻轉 不然有些互動道具會看不到
                    var needFlipX = reallyToPos > 2 ? -1 : 1;
                    break;

                case GSEnum.Game.TebakQQ:
                    // TebakQQ
                    fromPosition = TebakQQ_GameUtility.getPlayerPosition(fromPos);      // 誰丟
                    toPosition = TebakQQ_GameUtility.getPlayerPosition(toPos);          // 誰被丟

                    // 是否要翻轉 1:不需要 -1:需要 右邊(idx > 3)要翻轉 不然有些互動道具會看不到
                    needFlipX = reallyToPos > 2 ? -1 : 1;
                    break;
            }

            this.setPosition(fromPosition);

            // 跑移動動畫
            var scaleNormal = 0.5 + bonusScale;
            var scaleBig = 0.65 + bonusScale;
            this.setScale(needFlipX * scaleNormal, scaleNormal);

            var moveAction = cc.spawn(
                cc.moveTo(0.8, toPosition).easing(cc.easeQuadraticActionOut()),
                cc.sequence(
                    cc.scaleTo(0.3, needFlipX * scaleBig, scaleBig).easing(cc.easeQuadraticActionOut()),
                    cc.scaleTo(0.5, needFlipX * scaleNormal, scaleNormal).easing(cc.easeQuadraticActionOut())
                )
            );

            this.runAction(cc.sequence(
                cc.delayTime(0.2),
                moveAction,
                cc.delayTime(0.01),
                cc.removeSelf()
            ));
        });
        imageSprite.setTargetSize(cc.size(50, 50));
        this.addChild(imageSprite);


        // 紀錄ㄧ生只有一次的表情提示訊息
        // 假如有暱稱 且表情是丟向自己 代表荷官要說話提示
        var name = (nickName) ? nickName : fromPos === -1 ? "" : DataModal.gameData.playerDataArray[fromPos].nickname;
        if (name && (DataModal.gameData.getIsSelfByServerSitNum(toPos))) {
            switch (GS.nowGame) {
                case GSEnum.Game.Texas:
                case GSEnum.Game.Domino:
                    // Texas 跟 Domino 有荷官
                    // 荷官右邊的訊息
                    var message = JSStringUtility.format(LocalizedString.Game("%s對您使用互動道具\n，您可以點擊他的頭像選擇\n互動道具使用唷!"), name);
                    var messageLabel = new cc.LabelTTF(message, JSFontBoldName, 12);
                    messageLabel.setFontFillColor(JSColor.BLACK);
                    var param = {
                        mainNode: messageLabel,
                        style: BaseMessageNode.Style.GOLD,
                        direct: BaseMessageNode.Direct.LEFT,
                        arrowType: BaseMessageNode.ArrowType.SLANT,
                        isFlip: false,
                        arrowPadding: -10
                    };
                    var msgNode = new BaseMessageNode(param);
                    msgNode.setPosition(JSScreenMidPos.x + 16, 260 + JSScreenBonusHalfHeight);
                    msgNode.show(2, true);
                    this.addChild(msgNode);
                    break;

                case GSEnum.Game.Gaple:
                case GSEnum.Game.GapleChat:
                case GSEnum.Game.GaplePlus:
                case GSEnum.Game.GapleFriend:
                case GSEnum.Game.GapleVideo:
                case GSEnum.Game.Remi:
                case GSEnum.Game.Cangkulan:
                case GSEnum.Game.CapsaSusun:
                default:
                    // Gaple Remi沒有荷官
                    break;
            }
        }
    },


    /**
     * 收到要送互動道具
     */
    cmd_act_moods: function (value) {
        // act_moods ["2","18008","-1", nickName]  -1是荷官
        var jsonValue = JSON.parse(value);
        var fromPos = JSCodeUtility.getIntValue(jsonValue[0]);
        var toPos = JSCodeUtility.getIntValue(jsonValue[2]);
        var serial = JSCodeUtility.getStringValue(jsonValue[1]);
        var nickName = JSCodeUtility.getStringValue(jsonValue[3]);

        this._startSendActMoods(serial, fromPos, toPos, nickName);
    },

    cmd_gift_package: function (value) {
        // gift_package 0 ["0"] 19004 Paket%20Mood%20A
        var fromPos = parseInt(value[0]);
        var toPos = JSON.parse(value[1]);
        var serial = JSCodeUtility.getStringValue(value[2]);
        var nickName = JSCodeUtility.getStringValue(decodeURIComponent(value[3]));

        toPos.forEach(cur => {
            this._startSendGiftPackage(serial, fromPos, cur, nickName);
        });
    }
});