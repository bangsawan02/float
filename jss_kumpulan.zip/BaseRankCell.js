/**
 * 排行榜cell
 * created by andrew.chang
 */

var BaseRankCell = cc.TableViewCell.extend({
    ctor: function (type = BaseRankDialog.Type.TOKEN_SUBSYSTEM, isInTableView) {
        this._super();

        this._type = type;
        this._isInTableView = isInTableView;

        var midPosX = BaseRankDialog.TABLE_WIDTH / 2;
        var midPosY = BaseRankCell.HEIGHT / 2;

        var setting = this._getCellSetting();

        // 背景
        if (setting.bgImg) {
            var bgSprite = this._bgSprite = new ccui.Scale9Sprite(setting.bgImg);
            bgSprite.setPosition(midPosX, midPosY);
            this.addChild(bgSprite);
        }

        // 名次
        var rankLabel = this._rankLabel = new cc.LabelTTF("0", JSFontName, 12);
        rankLabel.setFontFillColor(!isInTableView ? setting.selfStringColor : setting.stringColor);
        setting.strokeColor && rankLabel.enableStroke(setting.strokeColor, 2);
        rankLabel.setPosition(31, midPosY);
        this.addChild(rankLabel);

        // 前三名皇冠
        var crownSprite = this._crownSprite = new cc.Sprite("#crown_01.png");
        crownSprite.setVisible(false);
        crownSprite.setPosition(31, midPosY);
        this.addChild(crownSprite);

        // 大頭照 裁切的node
        var stencilSprite = new cc.Sprite("#lobby_photo_clip.png");
        var clipNode = new cc.ClippingNode(stencilSprite);
        clipNode.setCascadeColorEnabled(true);
        clipNode.setAlphaThreshold(0.5);
        this.addChild(clipNode);

        // 大頭照
        var photoSprite = this._photoSprite = new PhotoSprite("", 56, 56);
        photoSprite.setDefaultSprite(JSCodeUtility.getRandomInt(0, 1) ? "photo_male.png" : "photo_female.png");
        clipNode.setScale(0.35);
        clipNode.setPosition(61, midPosY);
        clipNode.addChild(photoSprite);

        // 暱稱
        var nicknameLabel = this._nicknameLabel = new cc.LabelTTF("", JSFontName, 11);
        nicknameLabel.setAnchorPoint(cc.p(0, 0.5));
        nicknameLabel.setFontFillColor(!isInTableView ? setting.selfStringColor : setting.stringColor);
        setting.strokeColor && nicknameLabel.enableStroke(setting.strokeColor, 2);
        nicknameLabel.setPosition(76, midPosY);
        this.addChild(nicknameLabel);

        // 物品
        var itemSprite = this._createItemSprite();
        itemSprite.setPosition(202, midPosY);
        this.addChild(itemSprite);

        // 物品數量
        var itemLabel = this._itemLabel = new cc.LabelTTF("", JSFontName, 10);
        itemLabel.setAnchorPoint(cc.p(0, 0.5));
        itemLabel.setFontFillColor(!isInTableView ? setting.selfStringColor : setting.stringColor);
        setting.strokeColor && itemLabel.enableStroke(setting.strokeColor, 2);
        itemLabel.setPosition(216, midPosY);
        this.addChild(itemLabel);

        // 寶箱圖案
        var chestSprite = this._chestSprite = new cc.Sprite("#lobby_pic_chest_04.png");

        // 寶箱按鈕
        var chestBtn = this._chestBtn = new GSControlButton(chestSprite);
        chestBtn.setScale(0.75);
        chestBtn.setPosition(297, midPosY);
        chestBtn.addTargetWithActionForControlEvents(this, this._chestBtnClicked,
            cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
            cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
            cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
        this.addChild(chestBtn);

        // 需要分隔線
        if (setting.divisionLineImg) {
            var lineSprite = new ccui.Scale9Sprite(setting.divisionLineImg);
            lineSprite.setPreferredSize(cc.size(BaseRankDialog.TABLE_WIDTH - 1, 2));
            lineSprite.setPosition(midPosX, 0);
            this.addChild(lineSprite);
        }
    },

    /**
     * 刷新畫面
     * @param param
     */
    refreshView: function (param) {
        // 前三名
        var rank = parseInt(param.rank);
        if (rank > 0 && rank < 4) {
            // 顯示皇冠
            this._crownSprite.setVisible(true);
            this._crownSprite.setSpriteFrame(JSStringUtility.format("crown_%02d.png", rank));

            // 隱藏文字
            this._rankLabel.setVisible(false);
        } else {
            // 隱藏皇冠
            this._crownSprite.setVisible(false);

            // 顯示排名
            this._rankLabel.setVisible(true);
            this._rankLabel.setString(param.rank);
        }

        // 刷新背景
        this._refreshBgSprite(param.isSelf);

        // 暱稱
        this._nicknameLabel.setString(JSStringUtility.cutStringReplaceByEllipsis(param.nickname, 11, 110));

        // 大頭貼
        this._photoSprite.setPhotoUrlString(param.photoURL);

        // 刷新物品數量
        var string = param.score > 9999999 ? TexasUtility.getSimpleMoneyString(param.score, 1) : JSCodeUtility.getCurrencyString(param.score);
        this._itemLabel.setString(string);

        // 寶箱的資料
        let showChestBtn = param.rewardArray.length;
        this._chestBtn.setVisible(showChestBtn);
        this._chestBtn.rewards = param.rewardArray;

        // 刷新寶箱圖片
        if (showChestBtn) {
            // 4~10名寶箱圖
            var chestImg = (rank >= 4 && rank <= 10) ? "lobby_pic_chest_04.png" : "lobby_pic_chest_05.png";

            // 前三名有自己的寶箱
            if (rank < 4)
                chestImg = JSStringUtility.format("lobby_pic_chest_%02d.png", rank);

            this._chestSprite.setSpriteFrame(chestImg);
        }
    },

    /**
     * 刷新背景圖
     * @param isSelf 是不是自己
     */
    _refreshBgSprite: function (isSelf) {
        switch (this._type) {
            case BaseRankDialog.Type.TOKEN_SUBSYSTEM:
                // 刷新背景
                if (!this._isInTableView) {
                    this._bgSprite.setSpriteFrame("tokenSubsystem_bg_Peringkat_04.png");
                    this._bgSprite.setPreferredSize(cc.size(326, 24));
                } else {
                    let bgImg = isSelf ? "tokenSubsystem_bg_Peringkat_06.png" : "tokenSubsystem_bg_Peringkat_05.png";
                    this._bgSprite.setSpriteFrame(bgImg);
                    this._bgSprite.setPreferredSize(cc.size(326, 28));
                }
                break;
            case BaseRankDialog.Type.STONE_GAMBLING:
                // 在 Table 裡的自己要有 紅底
                if (this._isInTableView && isSelf) {
                    this._bgSprite.setVisible(true);
                    this._bgSprite.setPreferredSize(cc.size(BaseRankDialog.TABLE_WIDTH, BaseRankCell.HEIGHT - 2));
                } else
                    this._bgSprite.setVisible(false);
                break;
        }
    },

    /**
     * 創物品的sprite
     */
    _createItemSprite: function () {
        switch (this._type) {
            case BaseRankDialog.Type.TOKEN_SUBSYSTEM:
                var itemSprite = new cc.Sprite("#tokenSubsystem_pic_coconut.png");
                itemSprite.setScale(0.5);
                return itemSprite;
            case BaseRankDialog.Type.STONE_GAMBLING:
                var itemSprite = new cc.Sprite("#stoneGambling_pic_crown.png");
                itemSprite.setScale(0.3);
                return itemSprite;
        }
    },

    /**
     * 取得設定
     */
    _getCellSetting: function () {
        let setting = {};

        switch (this._type) {
            case BaseRankDialog.Type.TOKEN_SUBSYSTEM:
                // 背景圖
                setting.bgImg = "tokenSubsystem_bg_Peringkat_04.png";

                // 文字顏色
                setting.strokeColor = JSColor.BLACK;
                setting.stringColor = JSColor.WHITE;
                setting.selfStringColor = JSColor.YELLOW;

                // 分隔線
                setting.divisionLineImg = undefined;
                break;
            case BaseRankDialog.Type.STONE_GAMBLING:
                // 背景圖
                setting.bgImg = "stoneGambling_line_pink.png";

                // 文字顏色
                setting.stringColor = JSColor.WHITE;
                setting.selfStringColor = JSColor.WHITE;

                if (this._isInTableView) {
                    // 分隔線
                    setting.divisionLineImg = "stoneGambling_line_list.png";
                }
                break;
        }

        return setting;
    },

    /**
     * 點擊寶箱
     */
    _chestBtnClicked: function (sender, controlEvent) {
        // 跳獎勵泡泡框
        var obj = {
            controlEvent: controlEvent,
            isUp: this._isSelf,
            pos: this.convertToWorldSpace(sender.getPosition()),
            rewards: sender.rewards
        };
        GS.dispatchCustomEvent("NotifyBaseRankShowMessage", obj);
    },
});

// Cell高度
BaseRankCell.HEIGHT = 28;