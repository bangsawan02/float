/**
 * 首購卡
 */

var CouponAdvanceDialog = BaseDialogLayer.extend({
    ctor: function (param) {
        this._super();

        this.key = "CouponAdvanceDialog";

        this._shiningSize = null;           // 閃光動畫的範圍大小
        this._shiningPos = null;            // 閃光動畫的起始點
        this._param = param;

        switch (param.status) {
            case "A":     // 晶鑽卡A
                this._createDiamondA();
                break;
            case "B":     // 晶鑽卡B
                this._createDiamondB();
                break;
        }
    },

    /**
     * 創晶鑽卡A的畫面
     */
    _createDiamondA: function () {
        var aniNode = this._animationNode;
        var rewardString = LocalizedString.Reward;
        var param = this._param;

        // 背景先設黑色的
        this.dialogBgColor = JSColor.BLACK;

        // 背景光 要裁掉一半
        var stencil = new cc.LayerColor(cc.color(255, 255, 255, 255), 400, 200);
        stencil.setPosition(-200, 0);
        var clipNode = new cc.ClippingNode(stencil);
        clipNode.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 68);
        aniNode.addChild(clipNode);

        var bgSprite = new cc.Sprite("#three_choose_one_back_light.png");
        bgSprite.setScale(4.5);
        clipNode.addChild(bgSprite);

        // 藍光底
        var bgLightSprite = new cc.Sprite("#three_choose_one_green_light.png");
        bgLightSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 90);
        aniNode.addChild(bgLightSprite);

        // 標題
        var titleSprite = new cc.Sprite("#three_choose_one_title.png");
        titleSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 85);
        aniNode.addChild(titleSprite);

        // 標題下方文字
        var subTitleLabel = new cc.LabelTTF(rewardString("選擇並點擊您的幸運禮盒"), JSFontBoldName, 14);
        subTitleLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 60);
        aniNode.addChild(subTitleLabel, 1);

        // 標題的閃光動畫
        this._shiningSize = titleSprite.getContentSize();
        this._shiningSize.width += 10;
        this._shiningSize.height += 5;
        this._shiningPos = titleSprite.getPosition();
        this.schedule(this._shiningAnimation, 0.3);

        // 箭頭
        var arrowNode = new NavigateNode(NavigateNode.Direction.BOTTOM);
        arrowNode.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 25);
        arrowNode.setScale(0.8);
        arrowNode.run();
        aniNode.addChild(arrowNode, 3);

        // 禮物盒
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        aniNode.addChild(menu, 2);

        var self = this;
        var menuItems = [];
        var rewardList = param.rewardList;
        var totalLength = rewardList.length;

        // 禮物盒按下去的Func
        var getRewardFunc = function (sender) {
            // 把全部按鈕關掉
            menu.setEnabled(false);

            // 因為三選一是固定指定的 所以要把順序重新排序一下 讓點到的按鈕保證是Server指定的
            var selectIndex = menuItems.indexOf(sender);
            for (var i = 0; i < rewardList.length; i++) {
                var rewardParam = rewardList[i];
                if (rewardParam.isSpecify) {
                    // 找到指定的 跟按鈕的index互換
                    var tmpRewardParam = rewardList[selectIndex];
                    rewardList[selectIndex] = rewardParam;
                    rewardList[i] = tmpRewardParam;
                    break;
                }
            }

            // 按鈕的動畫
            menuItems.forEach(function (cur, index) {
                cur.stopAllActions();
                cur.setRotation(0);
                cur.setPositionY(JSScreenMidPos.y - 90);

                // 沒中獎禮盒要縮小70% 透明度60%
                var rewardParam = rewardList[index];
                var isRewardBox = cur === sender;
                cur.runAction(cc.sequence(
                    cc.spawn(
                        cc.scaleTo(0.25, isRewardBox ? 1.1 : 0.7).easing(cc.easeBackIn()),
                        isRewardBox ? cc.moveBy(0.25, cc.p(0, -10)) : cc.fadeTo(0.25, 150)
                    ),
                    cc.callFunc(function () {
                        // 換圖片
                        cur.setEnabled(false);

                        // 訊息部份
                        var contentNode = new cc.Node();
                        var menuPos = cur.getPosition();
                        if (isRewardBox) {
                            // 有中獎
                            var remainTime = rewardParam.remainTime;
                            var message = remainTime ? rewardString("買一送一") : rewardParam.reward;
                            var messageLabel = new cc.LabelTTF(message, JSFontBoldName, 12);
                            messageLabel.setFontFillColor(remainTime ? JSColor.YELLOW : JSColor.BLACK);
                            contentNode.addChild(messageLabel);

                            // 算大小
                            var labelSize = messageLabel.getContentSize();
                            labelSize.width += 6;           // 給他多一點寬度顯示
                            contentNode.setContentSize(labelSize);

                            if (remainTime) {
                                // 旁邊要加彩帶
                                for (var i = 0; i < 2; i++) {
                                    var starSprite = new cc.Sprite("#decorative_star.png");
                                    starSprite.setAnchorPoint(i === 0 ? 0 : 1, 0.5);
                                    starSprite.setPosition((i === 0 ? -1 : 1) * (labelSize.width - 8), 0);
                                    starSprite.setFlippedX(i === 1);
                                    contentNode.addChild(starSprite);
                                }
                            }
                        } else {
                            var messageLabel = new cc.LabelTTF(rewardParam.reward, JSFontBoldName, 12);
                            messageLabel.setFontFillColor(JSColor.BLACK);
                            contentNode.addChild(messageLabel);

                            // 算大小
                            var labelSize = messageLabel.getContentSize();
                            labelSize.width += 6;           // 給他多一點寬度顯示
                            contentNode.setContentSize(labelSize);
                        }

                        // 出現對話泡泡匡
                        var messageNode = new BaseMessageNode({
                            mainNode: contentNode,
                            style: (remainTime && isRewardBox) ? 7 : 0,
                            direct: 0,
                            arrowType: 1,
                            arrowPadding: 0,
                            isFlip: false
                        });
                        messageNode.setPosition(menuPos.x, menuPos.y + 80);
                        messageNode.show(0);
                        aniNode.addChild(messageNode, 4);

                    }, self)
                ));
            });

            // 告訴server顯示獎勵了
            DataProcess.sendString("show_coupon_advance_open");

            // 停止箭頭
            arrowNode.stop();
            arrowNode.setVisible(false);

            // 背景光旋轉
            bgSprite.runAction(cc.repeatForever(cc.rotateBy(1, 180)));

            // 換標題 恭喜您獲得最強好康
            titleSprite.setSpriteFrame("three_choose_one_reward_title.png");

            // 關掉SubTitle
            subTitleLabel.setVisible(false);

            // 關掉閃光
            self.unschedule(self._shiningAnimation);

            // 加按鈕關掉的按鈕 (要創新的Menu 因為舊的Menu被關掉了)
            var newMenu = new cc.Menu();
            newMenu.setPosition(0, 0);
            aniNode.addChild(newMenu, 2);
            var exitNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_circle_04.png", null, "#lobby_btn_pic_window_x.png");
            var exitMenuItem = new cc.MenuItemSprite(exitNodes[0], exitNodes[1], self._closeClicked, self);
            exitMenuItem.setPosition(JSVisibleSize.width - 20, JSVisibleSize.height - 20);
            newMenu.addChild(exitMenuItem);

            // 馬上使用的按鈕
            var btnSize = cc.size(102, 30);
            var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", btnSize, rewardString("馬上使用"), 12, JSColor.BLACK);
            var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], self._goPurchaseClicked, self);
            menuItem.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 100);
            newMenu.addChild(menuItem);

            // 晶鑽卡A關掉後要跳提示買一送一個東西
            GS.dispatchCustomEvent("NotifyShowPurchasePromote");
        };

        // 創禮物盒的地方
        var creatRewardFunc = function (index) {
            var itemNodes = ButtonUtility.createBtnSpriteArray("#three_choose_one_gift_01.png", "#three_choose_one_gift_01.png", "#three_choose_one_gift_02.png");
            itemNodes[2].setOpacity(255);

            var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], getRewardFunc, self);

            // 最大寬度
            var totalWidth = JSVisibleSize.width - itemNodes[0].getContentSize().width;
            var eachWidth = totalWidth / totalLength;
            menuItem.setAnchorPoint(0.5, 0);
            menuItem.setPosition(JSScreenMidPos.x - totalWidth / 2 + eachWidth * (index + 1) - eachWidth / 2, JSScreenMidPos.y - 90);
            menuItems.push(menuItem);
            menu.addChild(menuItem);

            // 動畫
            var rotateAction = cc.sequence(
                cc.spawn(cc.scaleTo(0.6, 1, 1.05), cc.rotateTo(0.6, -5, -5)),
                cc.spawn(cc.scaleTo(0.4, 1, 0.95), cc.rotateTo(0.4, 0, 0)),
                cc.spawn(cc.scaleTo(0.6, 1, 1.05), cc.rotateTo(0.6, 5, 5)),
                cc.spawn(cc.scaleTo(0.4, 1, 0.95), cc.rotateTo(0.4, 0, 0))
            );
            var jumpAction = cc.jumpBy(2, cc.p(0, 0), 10, 2);
            var allAction = cc.spawn(
                rotateAction,
                jumpAction
            );
            menuItem.runAction(allAction);

            // 陰影
            var shadowSprite = new cc.Sprite("#bg_shadow.png");
            shadowSprite.setScale(1.2, 1);
            shadowSprite.setPosition(menuItem.getPositionX(), menuItem.getPositionY() + 20);
            aniNode.addChild(shadowSprite);
        };

        // 每個禮物都跑一次
        for (var i = 0; i < totalLength; i++) {
            creatRewardFunc(i);
        }
    },

    /**
     * 創晶鑽卡B的畫面
     */
    _createDiamondB: function () {
        var aniNode = this._animationNode;
        var rewardString = LocalizedString.Reward;

        // 背景主畫面
        var bgSprite = new cc.Sprite("banner/lobby_purchase_banner.png");
        bgSprite.setPosition(JSScreenMidPos);
        aniNode.addChild(bgSprite);

        // 下方的金錢圖片
        for (var i = 0; i < 2; i++) {
            var chipSprite = new cc.Sprite("#lobby_reward_chips2.png");
            chipSprite.setFlippedX(i === 1);
            chipSprite.setPosition(JSScreenMidPos.x + (i === 0 ? -159 : 159), 87 + JSScreenBonusHalfHeight);
            aniNode.addChild(chipSprite);
        }

        // 煙火動畫
        var firework1 = new cc.Sprite("#lobby_pic_fireworks_01.png");
        firework1.setPosition(384 + JSScreenBonusHalfWidth, 240 + JSScreenBonusHalfHeight);
        firework1.setScale(0.2);
        firework1.setOpacity(0);
        firework1.runAction(cc.repeatForever(cc.sequence(
            cc.spawn(cc.scaleTo(1.2, 1), cc.fadeIn(1.2)),
            cc.scaleTo(0.6, 1.2),
            cc.spawn(cc.scaleTo(0.6, 1.3), cc.fadeOut(0.6)),
            cc.spawn(cc.scaleTo(0.01, 0.2), cc.fadeTo(0.01, 0)),
            cc.delayTime(JSCodeUtility.getRandomFloat(1, 2))
        )));
        aniNode.addChild(firework1);

        var firework2 = new cc.Sprite("#lobby_pic_fireworks_02.png");
        firework2.setPosition(58 + JSScreenBonusHalfWidth, 234 + JSScreenBonusHalfHeight);
        firework2.setScale(0.2);
        firework2.setOpacity(0);
        firework2.runAction(cc.repeatForever(cc.sequence(
            cc.delayTime(0.5),
            cc.spawn(cc.scaleTo(1.2, 1), cc.fadeIn(1.2)),
            cc.scaleTo(0.6, 1.2),
            cc.spawn(cc.scaleTo(0.6, 1.3), cc.fadeOut(0.6)),
            cc.spawn(cc.scaleTo(0.01, 0.2), cc.fadeTo(0.01, 0)),
            cc.delayTime(JSCodeUtility.getRandomFloat(0.5, 1.5))
        )));
        aniNode.addChild(firework2);

        // 閃光動畫
        var purplePos = [
            cc.p(20 + JSScreenBonusHalfWidth, 204 + JSScreenBonusHalfHeight),
            cc.p(46 + JSScreenBonusHalfWidth, 189 + JSScreenBonusHalfHeight),
            cc.p(108 + JSScreenBonusHalfWidth, 258 + JSScreenBonusHalfHeight),
            cc.p(280 + JSScreenBonusHalfWidth, 262 + JSScreenBonusHalfHeight),
            cc.p(407 + JSScreenBonusHalfWidth, 201 + JSScreenBonusHalfHeight),
        ];
        for (var i = 0; i < purplePos.length; i++) {
            var purpleSprite = new cc.Sprite("#lobby_pic_purplelight.png");
            purpleSprite.setPosition(purplePos[i]);
            purpleSprite.setScale(JSCodeUtility.getRandomFloat(1, 3));
            aniNode.addChild(purpleSprite);

            var randomTime = JSCodeUtility.getRandomFloat(0.8, 1.2);
            purpleSprite.runAction(cc.repeatForever(cc.sequence(
                cc.spawn(cc.scaleBy(randomTime, 1), cc.fadeTo(randomTime, 100)),
                cc.spawn(cc.scaleBy(randomTime, -1), cc.fadeTo(randomTime, 255))
            )));
        }

        // 文字
        var self = this;
        var couponObject = DataModal.profileData.coupon;
        var getTimeString = function () {
            var nowTime = new Date().getTime() / 1000;
            var surplusTime = couponObject.surplus - (nowTime - couponObject.systemTime);
            if (surplusTime < 0) {
                // 要關掉
                self._closeClicked();

                // 重新去要儲值的內容
                DataModal.purchaseData.sendGetPurchaseListCMD();

                return "";
            } else {
                // 還有時間
                var hour = surplusTime / 3600;
                var min = surplusTime % 3600 / 60;
                var sec = surplusTime % 60;
                return JSStringUtility.format(rewardString("剩餘時間：%d時%02d分%02d秒"), hour, min, sec);
            }
        };

        var richText = new GSRichTextNode(getTimeString(), JSFontBoldName, 10);
        richText.setPosition(JSScreenMidPos.x, 92 + JSScreenBonusHalfHeight);
        aniNode.addChild(richText, 1);
        richText.schedule(function () {
            // 倒數
            richText.setText(getTimeString(), JSFontBoldName, 10);
        }, 1);

        // 關閉按鈕
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        aniNode.addChild(menu);

        var exitNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_circle_04.png", null, "#lobby_btn_pic_window_x.png");
        var exitMenuItem = new cc.MenuItemSprite(exitNodes[0], exitNodes[1], self._closeClicked, self);
        exitMenuItem.setPosition(412 + JSScreenBonusHalfWidth, 247 + JSScreenBonusHalfHeight);
        menu.addChild(exitMenuItem);

        // 儲值按鈕
        var btnSize = cc.size(120, 30);
        var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", btnSize, rewardString("馬上使用"), 12, JSColor.BLACK);
        var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], self._goPurchaseClicked, self);
        menuItem.setPosition(JSScreenMidPos.x, 65 + JSScreenBonusHalfHeight);
        menu.addChild(menuItem);
    },

    /**
     * 出現閃光動畫
     */
    _shiningAnimation: function () {
        var randX = JSCodeUtility.getRandomInt(-this._shiningSize.width / 2, this._shiningSize.width / 2);
        var randY = JSCodeUtility.getRandomInt(-this._shiningSize.height / 2, this._shiningSize.height / 2);

        var shiningSprite = new cc.Sprite(JSCodeUtility.getRandomInt(0, 1) ? "#shining_03.png" : "#shining_02.png");
        shiningSprite.setPosition(this._shiningPos.x + randX, this._shiningPos.y + randY);
        shiningSprite.setScale(0);
        shiningSprite.setRotation(JSCodeUtility.getRandomInt(0, 360));
        this._animationNode.addChild(shiningSprite);

        shiningSprite.runAction(cc.sequence(
            cc.scaleTo(0.5, 1),
            cc.fadeOut(1),
            cc.removeSelf()
        ));
    },

    /**
     * 按鈕
     */
    // 關掉畫面
    _closeClicked: function () {
        this._closeDialogAnimation();
    },

    // 去儲值頁的按鈕
    _goPurchaseClicked: function () {
        // 去儲值頁面
        PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase, "");

        // 關掉畫面
        this._closeDialogAnimation();
    },
});