var Domino_RoomCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        this.setCascadeColorEnabled(true);
        this.setCascadeOpacityEnabled(true);

        var cellHeight = Domino_RoomLayer.TABLE_CONTENT_HEIGHT;
        var cellMidPosY = cellHeight / 2;

        var gameRankObject = DataModal.regionsData.domino.gameRankObject;
        var haveGameRank = !!gameRankObject;

        var haveKoinLuxy = DataModal.regionsData.domino.isShowKoinLuxy;

        // 有分有積分的畫面 就是(房名 底注 積分 小攜入/大攜入)
        // 沒有積分的畫面 桌列資訊(房名 底注 小攜入/大攜入)
        var posX = 0;

        var index = 0;

        // 房間名
        var tabWidth = Domino_RoomLayer.TAB_WIDTH[index];
        var label = this._nameLabel = new cc.LabelTTF("", JSFontBoldName, 13);
        label.setPosition(posX + tabWidth / 2, cellMidPosY);
        this.addChild(label);
        posX += tabWidth + 2;

        // 底注
        tabWidth = Domino_RoomLayer.TAB_WIDTH[++index];
        label = this._anteLabel = new cc.LabelTTF("", JSFontBoldName, 13);
        label.setPosition(posX + tabWidth / 2, cellMidPosY);
        this.addChild(label);
        posX += tabWidth + 2;

        // 是否有積分畫面
        if (haveGameRank) {
            tabWidth = Domino_RoomLayer.TAB_WIDTH[++index];

            // Icon
            var rankIconNode = new GameRankIconNode(gameRankObject.class);
            rankIconNode.setScale(0.4);
            rankIconNode.setPosition(posX + tabWidth / 2 - 14, cellMidPosY);
            this.addChild(rankIconNode);

            label = this._scoreLabel = new cc.LabelTTF("", JSFontBoldName, 13);
            label.setAnchorPoint(0, 0.5);
            label.setFontFillColor(JSColor.YELLOW);
            label.setPosition(posX + tabWidth / 2 + 8, cellMidPosY);
            this.addChild(label);
            posX += tabWidth + 2;
        }

        // 是否有Koin Luxy
        if (haveKoinLuxy) {
            tabWidth = Domino_RoomLayer.TAB_WIDTH[++index];

            // Icon
            var koinLuxyIcon = this._KLIconSp = new cc.Sprite(ProfileData.getKoinLuxyRes("#koinLuxy_pic_currency_01"));
            koinLuxyIcon.setScale(0.6);
            koinLuxyIcon.setPosition(posX + tabWidth / 2 - 16, cellMidPosY);
            this.addChild(koinLuxyIcon);

            // 加倍時段x2符號
            var KLDoubleSp = this._KLDoubleSp = new cc.Sprite("#koinLuxy_pic_double_01.png");
            KLDoubleSp.setPosition(cc.pAdd(koinLuxyIcon.getPosition(), cc.p(7, -5)));
            KLDoubleSp.setScale(0.9);
            this.addChild(KLDoubleSp);

            label = this._KLLabel = new cc.LabelTTF("", JSFontBoldName, 13);
            label.setAnchorPoint(0, 0.5);
            label.setFontFillColor(JSColor.YELLOW);
            label.setPosition(posX + tabWidth / 2, cellMidPosY);
            this.addChild(label);
            posX += tabWidth + 2;
        }

        // 小攜入/大攜入
        tabWidth = Domino_RoomLayer.TAB_WIDTH[++index];
        label = this._bringLabel = new cc.LabelTTF("", JSFontBoldName, 13);
        label.setPosition(posX + tabWidth / 2, cellMidPosY);
        this.addChild(label);
        posX += tabWidth + 2;

        // 鎖頭 之後給座標
        var lockSprite = this._lockSprite = new cc.Sprite("#lobby_pic_lock.png");
        lockSprite.setAnchorPoint(0, 0.5);
        lockSprite.setScale(0.5);
        lockSprite.setPosition(0, cellMidPosY);
        this.addChild(lockSprite);

        //推薦的金框
        var frameNode = this._frameNode = new cc.Node();
        this.addChild(frameNode, 1);

        var goldFrame = new ccui.Scale9Sprite("lobby_recommend.png");
        goldFrame.setPreferredSize(cc.size(356 + JSScreenBonusWidth - (JSScreenSafeWidth * 2), 44));
        goldFrame.setPosition(goldFrame.getContentSize().width / 2, cellMidPosY + 1);
        frameNode.addChild(goldFrame);

        //金框上的彩帶
        var ribbon = new cc.Sprite("#btn_ribbon.png");
        ribbon.setAnchorPoint(0, 1);
        ribbon.setScale(0.95);
        ribbon.setPosition(-8, goldFrame.getContentSize().height + 7);
        goldFrame.addChild(ribbon);

        //彩帶文字
        var ribbonWord = new cc.LabelTTF("Populer", JSFontName, 8);
        ribbonWord.setRotation(-45);
        ribbonWord.setPosition(ribbon.getContentSize().width / 2 - 3, ribbon.getContentSize().height / 2 + 4);
        ribbonWord.setFontFillColor(JSColor.BLACK);
        ribbon.addChild(ribbonWord);
    },

    //更新Cell
    refreshCell: function (idx, region) {
        // 房名
        this._nameLabel.setString(region.roomName);

        // 底注
        this._anteLabel.setString(TexasUtility.getSimpleMoneyString(region.ante));

        // 積分
        this._scoreLabel && this._scoreLabel.setString("+" + region.winScore.toString());

        // koinLuxy
        var isKLDouble = DataModal.koinLuxyData.isKLDouble;

        this._KLDoubleSp && this._KLDoubleSp.setVisible(isKLDouble);
        if (this._KLLabel) {
            var koinValue = region.koinLuxy;
            this._KLLabel.setString("+" + (isKLDouble ? koinValue * 2 : koinValue));                        // server保留原數值 加倍在這邊計算
            this._KLLabel.setFontFillColor(isKLDouble ? JSColor.WHITE : JSColor.YELLOW);
            isKLDouble ? this._KLLabel.enableStroke(cc.color(153, 0, 0), 2) : this._KLLabel.disableStroke();
        }

        // 小攜入/大攜入
        this._bringLabel.setString(TexasUtility.getSimpleMoneyString(region.minBringIn) + "/" + TexasUtility.getSimpleMoneyString(region.maxBringIn));

        // 推薦
        this._frameNode.setVisible(region.isRecommend);

        // 是否能進桌
        var canSit = !region.cannotSit || region.cannotSit.result === 0;
        this._lockSprite.setVisible(!canSit);
        if (!canSit) {
            this._lockSprite.setPositionX(this._nameLabel.getPositionX() + this._nameLabel.getContentSize().width / 2 + 2);
        }
    },

    //點到他 高亮
    setIsHighlight: function (isSelect) {
        this.setOpacity(isSelect ? 150 : 255);
    }
});