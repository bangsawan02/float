var MAX_RECONNECT_TIMES = 3;                        // 斷線重連 最多重新連線幾次
var NO_NET_RECONNECT_DELAY = 5;                     // 斷線重連時後 沒有網路要Delay多久去連線
var USE_TLS_SOCKET = 1;                             // Native下 是否改用TLS v1.2 的連線方式 (有要改也要去GSSocket.h修改)
var RECONNECT_INTERVAL = 0.5;                       // 斷線重連有網路的狀態下，嘗試連線次數大於1時，重連時要增加的時間隔間

var DataProcess = cc.Class.extend({
    _socketKeyDispatchMapArray: null,

    ctor: function () {
        this._socket = null;                        // 連接的Socket
        this._proxyKey = "";                        // ProxyKey
        this._httpRequestArray = [];                // http連線的物件
        this._proxyArray = [];                      // 收到的Proxy位置

        this._socketKeyDispatchMapArray = [];       // SocketKey Dispatch
        this._socketLogCallbackArray = [];          // Log的callback

        this._gamePauseCmdArray = [];                   // 遊戲暫停收到的cmd
        this._gamePauseForceDispatchCMD = new Set();    // 遊戲暫停後還需要強制分發的CMD
        this._isGamePause = false;                      // 現在遊戲是否暫停

        // 斷線重連的東西
        this._wsURL = "";                           // 連上哪一台WebSocket
        this._enableRC = false;                     // 是否打開斷線重連
        this._rcTimeoutTime = 0;                    // 斷線重連多久沒連上算Timeout
        this._rcTimes = 0;                          // 目前重連的次數
        this._rcSequence = 0;                       // 現在Socket封包的序號
        this._rcKey = "";                           // 斷線重連回去的Key
        this._usingReconnect = false;               // 連上的Socket是否使用斷線重連
        this._needResendCMD = false;                // 斷線重連後是否要補送CMD
        this._resendSeq = 0;                        // 送出指令的seq
        this._resendCMDBuffer = [];                 // 送出指令的Buffer

        // 是否使用https 是的話要改走wss
        this._useHttps = (GS.httpScheme.indexOf("https") > -1);

        // 加斷線重連處理的SocketKey
        var socketKeyMap = new SocketKeyMap(this, {
            "!setRC": this.cmd_setRC,
            "!setSEQ": this.cmd_setSEQ,
            "!RCOK": this.cmd_RCOK,
            "!RCNG": this.cmd_RCNG,
            "!debug": this.cmd_debug,
            "_PingPongLag": this.cmd_PingPongLag,
            "_PingPongTimeout": this.cmd_PingPongTimeout,
            "_": this.cmd_pingPongSeq,
        });
        this._socketKeyDispatchMapArray.push(socketKeyMap);

        // 切換分頁之類的 遊戲會暫停
        GS.addListener(cc.sys.isNative ? "NotifyGameEnterBackground" : cc.game.EVENT_HIDE, () => {
            this.setGamePause(true);

            // H5切換分頁要防止斷線
            if (!cc.sys.isNative && this._socket)
                this._socket.clearAllInterval();
        }, -1);

        // 回來頁面需要做什麼
        GS.addListener(cc.sys.isNative ? "NotifyGameEnterForeground" : cc.game.EVENT_SHOW, () => {
            this.setGamePause(false);

            // H5切換分頁要防止斷線
            if (!cc.sys.isNative && this._socket)
                this._socket.addAllInterval();
        }, -1);

        // 收到送cmd給server通知 (給java層呼叫用)
        GS.addListener("NotifySendSocketString", (event) => {
            var socketString = event.getUserData();
            socketString && DataProcess.sendString(socketString);
        }, -1);

        // 收到送cmd給自己通知 (給java層呼叫用)
        GS.addListener("NotifyReceiveSocketString", (event) => {
            var socketString = event.getUserData();
            socketString && DataProcess.sendCustomStringToSelf(socketString);
        }, -1);
    },

    // 清掉http request連線
    _cancelHttpConnect: function () {
        // 先取消之前的連線
        this._httpRequestArray.forEach((cur) => {
            // 先把callback清掉
            cur.onreadystatechange = null;

            // 先不要abort掉 有機會閃退, native下xhr會自動砍掉 所以應該沒差
            // cur.abort();
        });

        // 清空
        this._httpRequestArray = [];
    },

    // 開始去抓Host
    startConnect: function () {
        // 砍掉socket & http
        this.disconnect();

        // 清掉是斷線重連的狀態
        this._isStartReconnect = false;

        if (cc.sys.isNative && !GSDeviceInfo.checkInternetConnection()) {
            // 沒網路 晚一點通知 怕寫法是在LoadingView之前就登入
            setTimeout(() => {
                this._notifyUIDisconnect();
            }, 100);
            return;
        }

        // 一個走http 一個走https
        for (var i = 0; i < 1; i++) {
            var randNum = JSCodeUtility.getRandomInt(1, 100000);
            var url = JSStringUtility.format("%sbundleid=%s&enableRC&struct&rand=%d&container=%d%s%s",
                GS.hostURL,
                GS.bundleID,
                randNum,
                GS.containerID,
                (USE_TCP_SOCKET ? "" : "&ws=1"),
                (USE_TLS_SOCKET ? "&tls=1.2" : "")              // 是否使用tls連線
            );

            if (i === 1) {
                // 改成https
                url = url.replace("http://", "https://");
            }

            let xhr = new XMLHttpRequest();
            var self = this;
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4) {
                    if (self._httpRequestArray.length == 0)      //代表這不需要了
                        return;

                    if (xhr.status >= 200 && xhr.status < 400) {
                        var response = xhr.responseText;
                        self._log(response);

                        // 先清掉之前http request連線
                        self._cancelHttpConnect();

                        // 轉成JSON
                        try {
                            var jsonValue = JSON.parse(response);
                        } catch (e) {
                            // 失敗 就不處理
                            return;
                        }

                        self._proxyKey = JSCodeUtility.getStringValue(jsonValue['PKey']);
                        self._enableRC = (JSCodeUtility.getIntValue(jsonValue['enable_proxy_reconnect']) === 1);
                        self._rcTimes = 0;

                        if (USE_TCP_SOCKET) {
                            // 原生的走 TCP Socket
                            var hostArray = JSCodeUtility.getStringValue(jsonValue["PHostX"]).split(",");

                            var portArray = [];
                            var port1 = JSCodeUtility.getStringValue(jsonValue["PPort"]);
                            port1 && portArray.push(port1);
                            var port1 = JSCodeUtility.getStringValue(jsonValue["PPort2"]);
                            port1 && portArray.push(port1);

                            // 組成Object
                            hostArray.forEach(function (host) {
                                portArray.forEach(function (port) {
                                    self._proxyArray.push({host: host, port: port, isTCP: true});
                                });
                            });
                        } else {
                            var wsHost = JSCodeUtility.getStringValue(jsonValue["WSPHost"]);
                            var wsPort = JSCodeUtility.getStringValue(jsonValue["WSPPort"]);
                            var wssHost = JSCodeUtility.getStringValue(jsonValue["WSSPHost"]);
                            var wssPort = JSCodeUtility.getStringValue(jsonValue["WSSPPort"]);

                            // 組成Array
                            self._proxyArray = [];

                            // 轉成WSS跟WS
                            if (cc.sys.isNative) {
                                // 原生
                                // wssHost && self._proxyArray.push({host: wssHost, port: wssPort, isWSS: true});
                                wsHost && self._proxyArray.push({host: wsHost, port: wsPort, isWSS: false});
                            } else {
                                // H5
                                if (self._useHttps) {
                                    self._proxyArray.push({host: wssHost, port: wssPort, isWSS: true});
                                } else {
                                    wssHost && self._proxyArray.push({host: wssHost, port: wssPort, isWSS: true});
                                    wsHost && self._proxyArray.push({host: wsHost, port: wsPort, isWSS: false});
                                }
                            }
                        }

                        self._startConnectSocket();

                        //通知UI
                        GS.dispatchCustomEvent("NotifyLoginStatus", LoginLoadingStatus.SOCKET_CONNECT);

                    } else if (self._httpRequestArray.length === 1) {
                        // 全部失敗 通知UI
                        self._log("抓取Proxy IP Port失敗 Http Request URL=" + url + " Code=" + xhr.status.toString() + " response=" + xhr.responseText);
                        self._notifyUIDisconnect();
                    } else {
                        // 砍掉此http request 還有其他的
                        JSCodeUtility.removeArrayObject(self._httpRequestArray, xhr);
                    }
                }
            };

            // 連線失敗的callBack
            xhr.onerror = () => {
                // 砍掉此http request 還有其他的
                if (this._httpRequestArray.indexOf(xhr) > -1) {
                    JSCodeUtility.removeArrayObject(this._httpRequestArray, xhr);

                    if (!this._httpRequestArray.length) {
                        //全部失敗 通知UI
                        this._log("抓取Proxy IP Port失敗 Http Request URL=" + url + " Code=" + xhr.status.toString() + " response=" + xhr.responseText);
                        this._notifyUIDisconnect();
                    }
                }
            };

            xhr.open("GET", url, true);
            xhr.send();

            this._httpRequestArray.push(xhr);

            self._log("連到" + url);
        }

        // 通知UI
        GS.dispatchCustomEvent("NotifyLoginStatus", LoginLoadingStatus.GO_GET_PROXY);
    },

    // 開始連Socket
    _startConnectSocket: function (wsURL) {
        // 先把Socket清掉
        this.disconnect();

        if (wsURL) {
            // 代表是斷線重連來的
            this._wsURL = wsURL;
            this._usingReconnect = true;
            this._socket = new GSSocket(this._wsURL, this);
            this._log("重連 Socket連到:" + this._wsURL);
        } else if (this._proxyArray.length) {
            var proxyObj = this._proxyArray[0];
            this._usingReconnect = false;
            if (proxyObj.isTCP) {
                // 是走TCP Socket
                this._wsURL = proxyObj.host + ":" + proxyObj.port;
            } else {
                this._wsURL = (proxyObj.isWSS ? "wss://" : "ws://") + proxyObj.host + ":" + proxyObj.port;
            }
            this._socket = new GSSocket(this._wsURL, this);
            this._log("Socket連到:" + this._wsURL);

            // 砍掉第一個
            this._proxyArray.splice(0, 1);
        } else {
            // 沒東西了 通知斷線
            this._notifyUIDisconnect();
        }
    },

    // 送字串
    sendString: function (sendString) {
        if (!sendString)
            return;

        // 用來處理把送出指令的記下來 假如斷線重連需要補送的話可以送出
        var ignoreBuffer = sendString[0] === "_" || sendString[0] === "!";
        if (!ignoreBuffer) {
            this._resendSeq++;

            // 加到Buffer裡
            this._resendCMDBuffer.push(sendString);
            if (this._resendCMDBuffer.length > 40) {
                // 超過的話砍掉它
                this._resendCMDBuffer.shift();
            }
        }

        if (this._socket) {
            if (this._socket.getState() !== 1) {
                // 代表不能傳
                cc.log('%c' + 'WebSocket State 錯誤 [' + sendString + '] 沒有送出', 'background: #EEE; color: #F00');
                return;
            }

            if (!this._socket.isSendProxyNeed) {
                // 代表還沒有送完Proxy所需的東西 先檔掉
                cc.warn('Socket 尚未完成Proxy所需的指令 [' + sendString + '] 沒有送出');
                return;
            }

            this._socket.send(sendString);

            this._dispatchLog({
                flag: 1,
                content: sendString
            });
        } else {
            cc.log("Socket尚未連接送出: " + sendString);
        }
    },

    // 抓取現在是否有連線
    getIsConnected: function () {
        var isConnected = false;
        if (this._socket)
            isConnected = this._socket.getState() === 1;
        return isConnected;
    },

    // 自行斷線
    disconnect: function (needReconnect, needLogToServer) {
        // 也把Http request清掉
        this._cancelHttpConnect();

        // 把Socket清掉
        if (this._socket) {
            var oldSocket = this._socket;
            if (!needReconnect)
                this._socket = null;
            oldSocket.disconnect();
        }

        // 是否要送斷線Log給Server
        needLogToServer && this._sendDisconnectLog();
    },

    // 通知UI斷線
    _notifyUIDisconnect: function (isReconnect) {
        // 清掉HTTP
        this._cancelHttpConnect();

        // 假如是斷線重連的話 要送Log給Server
        isReconnect && this._sendDisconnectLog();

        // 通知UI
        GS.dispatchCustomEvent("NotifySocketResult", isReconnect ? "ReconnectFail" : "disconnect");
    },

    /**
     * 設定現在是否要暫停接收CMD
     * @param isSelfPause   是否是自己暫停的 是的話不送CMD
     */
    setGamePause: function (isPause, isSelfPause) {
        cc.log(isPause ? "Socket停止派送" : "Socket重新開始派送");

        this._isGamePause = isPause;

        if (!isPause) {
            // 把之前停止遊戲暫存的Socket Cmd分發下去
            this._gamePauseCmdArray.forEach(cur => {
                this.onReceive(cur.socket, cur.data, cur.needAddRC);
            });
            this._gamePauseCmdArray = [];
        }

        // isBackGround，1 => 玩家把app切到背景，0 => 玩家呼喚app回來前景
        if (!isSelfPause)
            this.sendString("isBackGround " + (isPause ? "1" : "0"));
    },

    /**
     * 新增暫停分發時也要強制分發的CMD
     */
    addGamePauseForceDispatchCMD: function (cmdKey) {
        this._gamePauseForceDispatchCMD.add(cmdKey);
    },

    /**
     * 移除暫停分發時也要強制分發的CMD
     */
    removeGamePauseForceDispatchCMD: function (cmdKey) {
        this._gamePauseForceDispatchCMD.delete(cmdKey);
    },

    /**
     * 清光暫停分發時也要強制分發的CMD
     */
    clearGamePauseForceDispatchCMD: function () {
        this._gamePauseForceDispatchCMD.clear();
    },

    /**
     * 清掉暫停收到的CMD
     */
    clearGamePauseCmd: function () {
        this._gamePauseCmdArray.length = 0;
    },

    /**
     * 設定斷線重連後是否要補送CMD
     */
    setReconnectResendCMD: function (enable) {
        if (!this._needResendCMD && enable) {
            // 假如之前是關掉 現在開啟的話 要把buffer清掉
            this._resendCMDBuffer.length = 0;
        }
        this._needResendCMD = enable;
    },

    /**
     * log專用的東西
     */
    // 註冊Callback
    addSocketLogCallback: function (callback, context) {
        this._socketLogCallbackArray.push({
            context: context,
            callback: callback
        });
    },

    // 砍掉Callback
    removeSocketLogCallback: function (context) {
        for (var i = 0, len = this._socketLogCallbackArray.length; i < len; i++) {
            if (this._socketLogCallbackArray[i].context === context) {
                // 砍掉他
                this._socketLogCallbackArray.splice(i, 1);
                break;
            }
        }
    },

    // 發送給有註冊的Callback
    _dispatchLog: function (param) {
        this._socketLogCallbackArray.forEach(function (cur) {
            cur.callback.call(cur.context, param);
        });
    },

    /**
     * 傳斷線Log給Server
     */
    _sendDisconnectLog: function () {
        if (!this._isStartReconnect)
            return;

        var url = JSStringUtility.format("%s/_disconnect_log/?nativeBundleID=%s&bundleID=%s&client_ver=%s&userid=%s",
            GS.domain,
            GS.nativeBundleID || "",
            GS.bundleID,
            GS.gameVersion,
            DataModal.profileData.account || ""
        );
        axios.get(url);

        // 也清掉Flag
        this._isStartReconnect = false;
    },

    /**
     * log用的地方 也會送給其他人記下來
     */
    _log: function () {
        cc.log.apply(this, arguments);
        this._dispatchLog({
            flag: 0,
            content: arguments[0]
        });
    },

    /**
     * 把收到的String分送給其他Object
     */
    _dispatchSocketData: function (data, needAddRC) {
        var key = data;
        var value = "";
        var spaceIndex = key.indexOf(" ");
        if (spaceIndex > 0) {
            // 要切空格
            key = data.slice(0, spaceIndex);
            value = data.slice(spaceIndex + 1);
        }

        // 假如是遊戲暫停的話 要判斷是否是強制分發的cmd 才往下做
        if (this._isGamePause && !this._gamePauseForceDispatchCMD.has(key))
            return;

        //判斷斷線重連的Seq是否要增加
        if (needAddRC && key.length) {
            var char = key.charAt(0);
            if (char != "!" && char != "_")
                this._rcSequence++;
        }

        // 給SDK Log起來
        if (cc.sys.isNative && (data.indexOf("_pong") !== 0) && (data.indexOf("_ ") !== 0)) {
            // 記下log
            GSFirebaseCrashlytics.log(data);

            // Firebase 紀錄最後收到的cmd
            GSFirebaseCrashlytics.setString("Lastly_Server_Command", data);
        }

        // 分發給其他人
        for (var i = 0; i < this._socketKeyDispatchMapArray.length; i++) {
            var socketKeyMap = this._socketKeyDispatchMapArray[i];
            socketKeyMap.onReceiveSocket(key, value);
        }
    },

    /**
     * 排程來送Client Seq指令給Server的地方
     */
    _scheduleSendClientSeq: function (isStop) {
        // 判斷是否有創出來update的東西
        if (!this._tempScheduleObj) {
            var socketThis = this;
            this._tempScheduleObj = {
                _totalTime: 0,

                sendFunc: function () {
                    socketThis.sendString("_cseq " + socketThis._resendSeq.toString());
                },

                update: function (dt) {
                    if (dt > 1) {
                        // 大於1大部份用在快轉 就不理它
                        return;
                    }
                    this._totalTime += dt;

                    // 每多少秒送出
                    if (this._totalTime > 10) {
                        this.sendFunc();
                        this._totalTime %= 10;
                    }
                }
            };
        }

        if (isStop) {
            // 斷線或是強制要停止 (要用unscheduleUpdateForTarget 這樣假如快轉的話 dt 才不會是固定的, 然後這個才有在JSB綁定)
            cc.director.getScheduler().unscheduleUpdateForTarget(this._tempScheduleObj);
        } else {
            // 連上後 每隔幾秒通知Server現在client cmd的seq
            cc.director.getScheduler().scheduleUpdateForTarget(this._tempScheduleObj, 0, false);

            // 第一次先送一次
            this._tempScheduleObj.sendFunc();
        }
    },

    /**
     * 斷線重連的東西
     */
    // 開始斷線重連
    _startReconnect: function () {
        // 判斷是否超過太多次斷線重連次數
        if (this._rcTimes > MAX_RECONNECT_TIMES)
            return false;

        if (this._rcKey.length) {
            // 要開始斷線重連 先把舊的斷掉
            this.disconnect();

            var reconnectFunc = (val) => {
                this._rcTimes++;

                var haveInternet = (cc.sys.isNative ? GSDeviceInfo.checkInternetConnection() : true);
                if (val || haveInternet) {
                    // 直接連
                    this._startConnectSocket(this._wsURL);
                } else {
                    // 沒有網路 通知UI
                    this._notifyUIDisconnect(true);
                }
            };

            // 記下來重連 用來判斷斷線後是否要送Log給Server
            this._isStartReconnect = true;

            // 先判斷是否有網路 沒網路要Delay幾秒後重連
            var haveInternet = (cc.sys.isNative ? GSDeviceInfo.checkInternetConnection() : true);
            if (haveInternet) {
                // 有網路，如果重連二次以上，每多一次增加0.5秒的間隔
                setTimeout(() => reconnectFunc(true), RECONNECT_INTERVAL * Math.max(0, this._rcTimes) * 1000);
            } else {
                // 幾秒後斷線重連
                setTimeout(reconnectFunc, NO_NET_RECONNECT_DELAY * 1000);
            }

            return true;
        } else
            return false;
    },


    // 設定斷線重連的Key跟時間
    cmd_setRC: function (key, value) {
        var valueArray = value.split(" ");
        if (valueArray && valueArray.length) {
            this._rcKey = valueArray[0];
            this._rcTimeoutTime = JSCodeUtility.getIntValue(valueArray[1]);

        } else {
            this._rcKey = "";
        }

        // 代表連上proxy了 要清掉ProxyArray
        this._proxyArray = [];
    },

    // 斷線重連Socket封包的序號
    cmd_setSEQ: function (key, value) {
        this._rcSequence = JSCodeUtility.getIntValue(value);
    },

    // 斷線重連上了 要把Timer關掉 通知
    cmd_RCOK: function (key, value) {
        this._rcTimes = 0;

        // 斷線重連補送的東西
        var valueArray = value.split(" ");
        var seq = JSCodeUtility.getIntValue(valueArray[0]);
        if (seq && this._needResendCMD) {
            // 需補送Socket CMD
            var bufferLen = this._resendCMDBuffer.length;
            var startSeq = bufferLen - (this._resendSeq - seq);
            // 假如小於0 代表我的buffer長度不夠大 就放棄吧
            if (startSeq < 0)
                startSeq = 0;
            for (var i = startSeq; i < bufferLen; i++) {
                // 補送CMD
                var sendString = this._resendCMDBuffer[i];
                this._socket.resend(sendString);

                // 給LogView記下來
                this._dispatchLog({
                    flag: 11,
                    content: sendString
                });
            }
        }

        // 開始Schedule 送Client Seq
        this._scheduleSendClientSeq();

        // 通知UI
        GS.dispatchCustomEvent("NotifySocketResult", "ReconnectDone");
    },

    // 斷線重連不上 直接踢掉
    cmd_RCNG: function (key, value) {
        // 把Socket關掉
        this.disconnect(false);

        // 通知UI
        this._notifyUIDisconnect();
    },

    // 收到debug用的key
    cmd_debug: function (key, value) {
        var url = "http://id.vgs.tw/admin/dlogsearch.pl/" + value;
        cc.sys.isNative && GSFirebaseCrashlytics.setString("debug", url);
        cc.log("ProxyLog " + url);

        // 把他記下來
        if (!DataProcess.ConnectSessionLogKeyURLs)
            DataProcess.ConnectSessionLogKeyURLs = [];
        if (DataProcess.ConnectSessionLogKeyURLs.indexOf(url) < 0)
            DataProcess.ConnectSessionLogKeyURLs.push(url);
    },

    // 收到PingPong Lag 超過1秒沒回應就會收到
    cmd_PingPongLag: function () {
        GS.dispatchCustomEvent("NotifySocketLag");
    },

    // 收到PingPong Timout 超過9秒沒回應就會收到
    cmd_PingPongTimeout: function () {
        GS.dispatchCustomEvent("NotifySocketTimeout");

        // 強制斷線重連
        this.disconnect(true);
    },

    // 假如走Binary PingPong改成_ 後面會帶seq回來
    cmd_pingPongSeq: function (key, value) {
        var seq = JSCodeUtility.getIntValue(value);
        if (seq)
            this._rcSequence = seq;
    },

    /**
     * Socket delegate
     */
    // Socket Delegate 連上Socket
    onConnect: function (socket) {
        if (this._socket != socket)
            return;

        cc.log("連上Socket");

        // 記下來 假如收到第一個cmd 把proxy array清掉
        this._socketOnConnect = true;

        // 設定已經送完Proxy要用的東西
        this._socket.isSendProxyNeed = true;

        if (this._rcKey.length && this._usingReconnect) {
            // 需送斷線重連的資訊
            var cmdKey = USE_TCP_SOCKET
                ? SOCKET_USE_BINARY ? "!!RCC " : "!RCi "
                : "!RC ";
            var sendStr = cmdKey + this._rcKey + " " + this._rcSequence.toString();
            // 這個要特別走自己的 因為假如是走Binary 第一個cmd不壓縮
            this._socket.send(sendStr, true);
            
            // 記下log
            this._dispatchLog({
                flag: 1,
                content: sendStr
            });
        } else {
            // 假如是Native 因為是改走TCP 要送出斷行改用\n 後面亂數是in2要求要加的
            if (USE_TCP_SOCKET && !SOCKET_USE_BINARY)
                this.sendString("!i-delimiter " + JSCodeUtility.getRandomInt(0, 999999999).toString());

            // 這個要特別走自己的 因為假如是走Binary 第一個cmd不壓縮
            var sendProxyString = (SOCKET_USE_BINARY ? "!!proxyC " : "!proxy ") + this._proxyKey;
            this._socket.send(sendProxyString, true);

            // 記下log
            this._dispatchLog({
                flag: 1,
                content: sendProxyString
            });

            if (this._enableRC) {
                // 可以支援斷線重連 ProxyArray要等收到setRC在清掉
                this.sendString("!enableRC");
            }

            // 清空重送的東西
            this._resendCMDBuffer.length = 0;
            this._resendSeq = 0;

            // 開始Schedule送Client Seq
            this._scheduleSendClientSeq();

            // 通知UI
            GS.dispatchCustomEvent("NotifyLoginStatus", LoginLoadingStatus.SOCKET_DONE);
        }
    },

    // Socket收到東西
    onReceive: function (socket, data, needAddRC, ignoreGamePause) {
        if (this._socket != socket)
            return;

        if (this._socketOnConnect) {
            // ProxyArray清掉
            this._socketOnConnect = false;
            this._proxyArray = [];
        }

        // 把http改成https
        data = GS.transferURL(data);

        if (!ignoreGamePause && this._isGamePause) {
            // 遊戲暫停了 Socket處理先不分發
            this._gamePauseCmdArray.push({
                socket: socket,
                data: data,
                needAddRC: needAddRC
            });

            // 丟給分發判斷是否是暫停需要強制給的cmd
            this._dispatchSocketData(data, needAddRC);

            return;
        }

        // 要先派送Log 不然有時後順序會怪怪的
        this._dispatchLog({
            flag: needAddRC ? 2 : 3,
            content: data
        });

        // 派送收到的東西給需要的人
        this._dispatchSocketData(data, needAddRC);
    },

    // Socket斷線
    onDisconnect: function (socket, err) {
        // 停止送Seq
        this._scheduleSendClientSeq(true);

        if (this._socket != socket)
            return;

        cc.log("斷線了 %s", err);

        // 清掉自己的Socket
        this._socket = null;

        if (this._proxyArray.length) {
            // 代表還有得連
            this._startConnectSocket();
        } else {
            // 沒任何Proxy可用 試斷線重連
            if (this._startReconnect()) {
                // 可以斷線重連 通知UI
                GS.dispatchCustomEvent("NotifySocketResult", "StartReconnect");
            } else {
                // 不可以斷線重連
                this._notifyUIDisconnect();
            }
        }
    },
});

// statics
// 加SocketKey
DataProcess.addSocketKeyDispatch = function (context, keyMap) {
    // 先判斷原本有沒有此context 有的話直接加上去
    var baseArray = DataModal.dataProcess._socketKeyDispatchMapArray;
    var oldObject = baseArray.find(cur => cur.getContext() === context);
    if (oldObject) {
        // 已經有舊的 組起來
        oldObject.addNewCallbackMap(keyMap);
    } else {
        // 沒有舊的 要創新的
        var socketKeyMap = new SocketKeyMap(context, keyMap);
        baseArray.push(socketKeyMap);
    }
};

// 移除SocketKey
DataProcess.removeSocketKeyDispatch = function (context) {
    var socketKeyDispatchMapArray = DataModal.dataProcess._socketKeyDispatchMapArray;
    for (var i = 0; i < socketKeyDispatchMapArray.length; i++) {
        var socketKeyMap = socketKeyDispatchMapArray[i];
        if (socketKeyMap.getContext() == context) {
            socketKeyDispatchMapArray.splice(i, 1);
            break;
        }
    }
};

// 送字串出去
DataProcess.sendString = function (sendString) {
    DataModal.dataProcess.sendString(sendString);
};

// 送加密的字串出去 假如不能加密 就不送加密的 (因為後台有些error是加密會出錯 改用try catch包起來)
DataProcess.sendEncryptString = function (cmd, content) {
    // Native 如果是走TLS連線 就不需用ENC加密
    if (USE_TCP_SOCKET && USE_TLS_SOCKET) {
        DataProcess.sendString(cmd + " " + content);
        return;
    }

    // 其它的需要
    try {
        DataProcess.sendString("ENC" + cmd + " " + GSCrypto.getAES256EncryptString(content));
    } catch (e) {
        DataProcess.sendString(cmd + " " + content);
    }
};

// 送字串給自己
DataProcess.sendCustomStringToSelf = function (sendString, display) {
    if (!JSCodeUtility.checkIsdefined(display)) {
        display = true;
    }
    display && DataModal.dataProcess._log("Socket 送給自己:" + sendString);
    DataModal.dataProcess.onReceive(DataModal.dataProcess._socket, sendString, false, true);
};

// 斷線
DataProcess.disconnect = function (needReconnect, needLogToServer) {
    DataModal.dataProcess.disconnect(needReconnect, needLogToServer);
};

// 抓取PingPongMS
DataProcess.getPingPongMS = function () {
    var socket = DataModal.dataProcess._socket;
    return socket ? socket.getPingPongMS() : 0;
};

// 設定斷線重連時是否要補送沒送出去的資料
DataProcess.setReconnectResendCMD = function (enable) {
    DataModal.dataProcess.setReconnectResendCMD(enable);
};