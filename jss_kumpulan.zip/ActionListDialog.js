/**
 * 免費幣的Dialog 裡面放一堆怪怪的任務
 */

var ActionListDialog = BaseDialogLayer.extend({
    ctor: function (page, whereType, missionType, isCompete) {
        this._super();

        // 先設定此Dialog的Key 之後容易砍
        this.key = "ActionListDialog";

        this._whereType = whereType;
        this._missionType = missionType;
        this._page = page = (page === 0)     // 預選頁
            ? (whereType === DailyMissionEnum.whereType.Lobby ? ActionListDialog.Page.MISSION_LOBBY : ActionListDialog.Page.MISSION_GAME)
            : page;
        this._pageArray = [];       // 各頁籤的內頁

        var aniLayer = this._animationLayer;

        // 兩側霓虹燈
        for (var i = 0; i < 2; i++) {
            var neonSp = new cc.Sprite("#daliy_mission_pic_light_neon_01.png");
            neonSp.setScale(-2 * i + 1, 1);
            neonSp.setPosition(53 + 407 * i + JSScreenBonusHalfWidth, 198 + JSScreenBonusHalfHeight);
            aniLayer.addChild(neonSp, 1);
        }

        // dialog背景底
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(cc.size(492, 280));
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite);

        // 中間背景
        var bgMidPosX = 295 + JSScreenBonusHalfWidth;

        // 上方光暈
        var bgLightUpSprite = new cc.Sprite("#lobby_pic_light_gold.png");
        bgLightUpSprite.setAnchorPoint(0.5, 0);
        bgLightUpSprite.setPosition(bgMidPosX, 236 + JSScreenBonusHalfHeight);
        aniLayer.addChild(bgLightUpSprite, 1);

        // 下方光暈
        var bgLightDownSprite = this._bgLightDownSprite = new cc.Sprite("#lobby_pic_light_gold.png");
        bgLightDownSprite.setAnchorPoint(0.5, 0);
        bgLightDownSprite.setPosition(bgMidPosX, 15 + JSScreenBonusHalfHeight);
        aniLayer.addChild(bgLightDownSprite, 1);

        // 標題背景和文字
        var titles = ["#lobby_pic_title_bg.png", "#lobby_word_title_reward.png"];
        titles.forEach((cur, i) => {
            var title = new cc.Sprite(cur);
            title.setPosition(JSScreenMidPos.x, 257 + JSScreenBonusHalfHeight);
            aniLayer.addChild(title, 1);
        });

        // 標題背景和文字
        var titleNode = new DailyMissionThemeNode();
        aniLayer.addChild(titleNode);

        // //推播提醒
        // var reminder = new cc.LabelTTF(freeChipString("推播提醒"), JSFontName, 9);
        // reminder.setPosition(52.5 + JSScreenBonusHalfWidth, 44.5 + JSScreenBonusHalfHeight);
        // aniLayer.addChild(reminder, 2);
        //
        // //推播提醒
        // var notifyIdx = parseInt(GS.localStorage.getItem("isOpenDailyMissionNotify") || 0);
        // var switchButton = new SwitchControlButton(this._menuItemToggleClicked, this);
        // switchButton.setPosition(cc.pAdd(reminder.getPosition(), cc.p(0, -14.5)));
        // switchButton.setIsOn(notifyIdx);    // 要抓玩家當前設定
        // aniLayer.addChild(switchButton);

        /****************************************************************************/
        var displayTab = [
            this._whereType === DailyMissionEnum.whereType.Lobby ? ActionListDialog.Page.MISSION_LOBBY : ActionListDialog.Page.MISSION_GAME,
            ActionListDialog.Page.ACTION_LIST,
            ActionListDialog.Page.SCRATCH
        ];

        // Luxy Poker會有限時任務
        if (GS.isLuxyPoker)
            displayTab.splice(1, 0, ActionListDialog.Page.MISSION_LIMIT);

        // 假如是桌列表或遊戲內 要多判斷是不是比賽桌 假如是比賽桌 或 Gaple好友桌  只出現刮刮卡的Tab
        if (isCompete || this._missionType === DailyMissionEnum.roomType.GapleFriend) {
            displayTab = [ActionListDialog.Page.SCRATCH];
        }

        // 娛樂城大廳/Slot只有 每日任務Tab
        if (this._whereType === DailyMissionEnum.whereType.Vip_Lobby || this._whereType === DailyMissionEnum.whereType.Slot) {
            displayTab = [ActionListDialog.Page.MISSION_LOBBY];
        }

        // 左方Tab zOrder要在page上方
        this._tabButtons = displayTab.map(cur => {
            // 要有看的到在加畫面且放在array裡 看不看的到裡面Node會去判斷
            var button = new ActionListTabButton(cur, missionType);
            if (button.isVisible()) {
                button.addTouchUpInsideAction(this._tabClicked, this);
                aniLayer.addChild(button, 5);

                return button;
            }
        });

        // 更新Tab位置
        this._updateTabPosition();

        var defaultButton = undefined;
        // 從Priority指定的順序逐一檢查第一個小紅點的頁籤，作為顯示的預設
        for (let i = 0; i < ActionListDialog.Priority.length; i++) {
            defaultButton = this._tabButtons.find(btn => btn.getBadgeEnabled() && (btn.page === ActionListDialog.Priority[i]));
            // 找到就跳出搜尋
            if (defaultButton)
                break;
        }
        // 都沒有找到則預設顯示每日任務
        if (!defaultButton)
            defaultButton = this._tabButtons[0];

        defaultButton && this._tabClicked(defaultButton);

        /****************************************************************************/

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
        closeBtn.setPosition(493 + JSScreenBonusHalfWidth, 274 + JSScreenBonusHalfHeight);
        aniLayer.addChild(closeBtn, 10);

        // 註冊通知
        GS.addListener("NotifyCloseActionListDialog", this.notifyCloseActionListDialog.bind(this), this);
        GS.addListener("NotifyActionListDone", this.notifyActionListDone.bind(this), this);
        GS.addListener("NotifyUpdateDailyScratch", this.notifyUpdateDailyScratch.bind(this), this);
        GS.addListener("NotifyTimeLimitTaskInfoDone", this.notifyTimeLimitTaskInfoDone.bind(this), this);
    },

    /**
     * 更新Tab位置
     */
    _updateTabPosition: function () {
        var nowPos = cc.p(59 + JSScreenBonusHalfWidth, 220 + JSScreenBonusHalfHeight);
        var paddingY = 35;
        this._tabButtons.forEach(button => {
            // 先更新一次看不看的到
            button.updateVisible();

            if (button.isVisible()) {
                button.setPosition(nowPos);

                // 下一個位置
                nowPos.y -= paddingY;
            }
        });
    },

    /**
     * 按鈕
     */
    // 切換頁籤
    _tabClicked: function (sender) {
        var pageArray = this._pageArray;

        // 把所有Tab設定可以按
        this._tabButtons.forEach(btn => btn && btn.setEnabled(btn !== sender));

        // 先把所有頁面關掉
        pageArray.forEach(page => page && page.setVisible(false));

        var pageEnum = sender.page;
        var page = pageArray[pageEnum];

        if (!page) {
            switch (pageEnum) {
                case ActionListDialog.Page.MISSION_GAME:
                case ActionListDialog.Page.MISSION_LOBBY:
                    // 每日任務
                    page = this._pageArray[pageEnum] = new DailyMissionLayer(this._whereType, this._missionType);
                    break;
                case ActionListDialog.Page.SCRATCH:
                    // 刮刮卡
                    page = this._pageArray[pageEnum] = new DailyScratchLayer();
                    break;
                case ActionListDialog.Page.ACTION_LIST:
                    // 特殊任務
                    page = this._pageArray[pageEnum] = new ActionListLayer();
                    break;
                case ActionListDialog.Page.MISSION_LIMIT:
                    // 限時任務
                    page = this._pageArray[pageEnum] = new LimitMissionLayer();
                    break;
                default:
                    return;
            }
            page.setPosition(JSScreenBonusHalfWidth, JSScreenBonusHalfHeight);
            this._animationLayer.addChild(page, 4);
        }

        // 讓哪一個畫面出現
        page.setVisible(true);

        // 埋點
        if (pageEnum === ActionListDialog.Page.SCRATCH) {
            // 刮刮卡埋點
            DataProcess.sendString("track_scratch_mix 1");

            // 華麗牌桌埋點 171:進入刮刮卡
            DataModal.profileData.isUseGorgeousTheme() && TexasUtility.sendUserAnalyticsTrack(171);
        } else if (pageEnum === ActionListDialog.Page.MISSION_GAME) {
            // 華麗牌桌埋點 170:進入每日任務頁
            DataModal.profileData.isUseGorgeousTheme() && TexasUtility.sendUserAnalyticsTrack(170);
        }

        // 每日/限時任務不要有下邊光 會蓋到字
        var isDaily = (pageEnum === ActionListDialog.Page.MISSION_GAME) || (pageEnum === ActionListDialog.Page.MISSION_LOBBY) || (pageEnum === ActionListDialog.Page.MISSION_LIMIT);
        this._bgLightDownSprite.setVisible(!isDaily);
    },

    // 推播提醒
    _menuItemToggleClicked: function (sender) {
        var isOn = sender.getIsOn();
        GS.localStorage.setItem("isOpenDailyMissionNotify", isOn ? "1" : "0");

        // 設定每日任務推播
        DataModal.dailyMissionData.setDailyMissionNotify();
    },

    // 按到關閉
    _closeBtnClicked: function () {
        this._closeDialogAnimation();
    },

    /**
     * 通知
     */
    notifyCloseActionListDialog: function () {
        this._closeDialogAnimation();
    },

    // action_list更新回來
    notifyActionListDone: function () {
        this._updateTabPosition();
    },

    // 更新刮刮卡
    notifyUpdateDailyScratch: function () {
        this._updateTabPosition();
    },

    // 更新限時任務
    notifyTimeLimitTaskInfoDone: function () {
        this._updateTabPosition();
    }
});

// 打開來的Page
ActionListDialog.Page = {
    MISSION_LOBBY: 0,   // 任務(大廳)
    MISSION_GAME: 1,    // 任務(桌內)
    ACTION_LIST: 2,     // 特殊任務
    SCRATCH: 3,         // 刮刮卡
    ACHIEVEMENT: 4,     // 簽到簿
    TARGET: 5,          // 成就
    EVENT: 6,           // 活動
    MISSION_LIMIT: 7    // 限時任務
};

// v5.4.2: 有紅點時，預設開啟頁籤的優先度，越上面越高，（免費德撲幣(刮刮卡) > 每日任務 > 特殊任務）
ActionListDialog.Priority = [
    ActionListDialog.Page.SCRATCH,
    ActionListDialog.Page.MISSION_LOBBY,
    ActionListDialog.Page.MISSION_GAME,
    ActionListDialog.Page.ACTION_LIST
];