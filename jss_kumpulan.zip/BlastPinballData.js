/**
 * v5.7.0 激爆彈珠台資料
 */
class BlastPinballData extends PurchaseTriggerIntegrationDataTemplate {
    constructor() {
        super();

        this.registerSocket({
            "blast_pinball_icon": this.cmd_blast_pinball_icon.bind(this),
            "blast_pinball_info": this.cmd_blast_pinball_info.bind(this),
            "blast_pinball_play": this.cmd_blast_pinball_play.bind(this),
            "blast_pinball_recharge_done": this.cmd_blast_pinball_recharge_done.bind(this),
        });
    }

    clean() {
        super.clean();
        this.lastReward = undefined;
        this.ballCount = 0;
        this.rewards = undefined;
        this.isFree = undefined;
        this.cleanRechargeData();
    }

    cleanRechargeData() {
        this.rechargeData = {
            error: -1,
            deltaBallCount: 0,
        };
    }

    // 請求 icon
    requestIcon() {
        DataProcess.sendString("blast_pinball_icon");
    }

    // 請求 info
    requestInfo() {
        DataProcess.sendString("blast_pinball_info");
    }

    // 請求發射彈珠
    requestShoot() {
        DataProcess.sendString("blast_pinball_play");
    }

    /**
     * 更新紅點
     * 儲值整合 icon 每 1s 更新一次
     */
    refreshBadge() {
        this.isShowBadge = this.ballCount > 0;
    }

    /**
     * 告訴 server 獎勵已領取
     * C -> S: blast_pinball_reward_done
     */
    sendRewardDone() {
        DataProcess.sendString("blast_pinball_reward_done");
    }

    /**
     * 解析獎勵資料
     * @param {Object} jsonValue
     * @private
     */
    _parseReward(jsonValue) {
        let data = {};
        for (let type in jsonValue) {
            data[JSCodeUtility.getIntValue(type)] = JSCodeUtility.getStringValue(jsonValue[type]);
        }
        return data;
    }

    /**
     * Icon 資料
     * C -> S: blast_pinball_icon
     * S -> C: blast_pinball_icon
     */
    cmd_blast_pinball_icon(key, value) {
        let jsonValue = JSON.parse(value || "{}");
        const error = this.error = JSCodeUtility.getIntValue(jsonValue["error"]);

        if (error === 0) {
            // 分群
            this.group = JSCodeUtility.getIntValue(jsonValue["group"]);

            // 剩餘時間
            this.setRemainTime(jsonValue["time_left"]);

            // 是否為免費彈珠
            this.isFree = JSCodeUtility.getBooleanValue(jsonValue["is_free"]);

            // 球數
            this.ballCount = JSCodeUtility.getIntValue(jsonValue["pinballs"]);

            if (JSCodeUtility.getBooleanValue(jsonValue["pop"])) {
                this.setPopType(PurchaseTriggerIntegrationData.purchaseType.BLAST_PINBALL);
            }
        } else {
            this.clean();
        }

        this._integrationData.updateOpenPurchaseActivityCount();
        this._integrationData.refreshPurchaseActivityRedPoint();
    }

    /**
     * Info 資料
     * C -> S: blast_pinball_info
     * S -> C: blast_pinball_info
     */
    cmd_blast_pinball_info(key, value) {
        let jsonValue = JSON.parse(value || "{}");
        const error = this.error = JSCodeUtility.getIntValue(jsonValue["error"]);

        if (error === 0) {
            // 分群
            this.group = JSCodeUtility.getIntValue(jsonValue["group"]);

            // 彈珠數量
            this.ballCount = JSCodeUtility.getIntValue(jsonValue["pinballs"]);

            // 獎勵內容
            this.rewards = this._parseReward(jsonValue["rewards"]);

            // 是否為免費
            this.isFree = JSCodeUtility.getBooleanValue(jsonValue["is_free"]);

            if (jsonValue["last_reward"]) {
                this.lastReward = {
                    prize: JSCodeUtility.getIntValue(jsonValue["last_reward"]["prize"]),
                    rewardMsg: JSCodeUtility.getStringValue(jsonValue["last_reward"]["reward"]),
                    isFree: JSCodeUtility.getBooleanValue(jsonValue["last_reward"]["is_free"]),
                };
            }
        }

        this._integrationData.updateOpenPurchaseActivityCount();
        this._integrationData.refreshPurchaseActivityRedPoint();

        GS.dispatchCustomEvent("NotifyBlastPinballInfoDone");
    }

    /**
     * 發射彈珠
     * C -> S: blast_pinball_play
     * S -> C: blast_pinball_play
     */
    cmd_blast_pinball_play(key, value) {
        let jsonValue = JSON.parse(value || "{}");
        let param = {};
        param.error = JSCodeUtility.getIntValue(jsonValue["error"]);

        if (param.error === 0) {
            param.prize = JSCodeUtility.getIntValue(jsonValue["prize"]);
            param.rewardMsg = JSCodeUtility.getStringValue(jsonValue["reward_msg"]);
            param.isFree = JSCodeUtility.getBooleanValue(jsonValue["is_free"]);

            GS.dispatchCustomEvent("NotifyBlastPinballPlayDone", param);
        } else {
            // 出錯了
            this.error = param.error;

            this._integrationData.updateOpenPurchaseActivityCount();
            this._integrationData.refreshPurchaseActivityRedPoint();
            GS.dispatchCustomEvent("NotifyBlastPinballInfoDone");
        }
    }

    /**
     * 儲值成功
     * S -> C: blast_pinball_recharge_done
     */
    cmd_blast_pinball_recharge_done(key, value) {
        let jsonValue = JSON.parse(value || "{}");
        let param = this.rechargeData;
        param.error = JSCodeUtility.getIntValue(jsonValue["error"]);

        if (param.error === 0) {
            // 彈珠數量
            param.deltaBallCount += JSCodeUtility.getIntValue(jsonValue["pinballs"]);
        }

        GS.dispatchCustomEvent("NotifyBlastPinballRechargeDone");
    }
}

/**
 * 獎勵類型，對應 server 送來的數字
 */
BlastPinballData.RewardType = {
    GRAND: 1,
    MEGA: 2,
    BIG: 3,
    MINI: 4
};