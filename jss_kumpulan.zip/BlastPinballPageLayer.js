/**
 * v5.7.0 激爆彈珠台 - 參考自中撲
 */
var BlastPinballPageLayer = PurchaseTriggerIntegrationPageLayer.extend({
    ctor: function (dialog) {
        this._super(dialog);

        this.key = "BlastPinballPageLayer";
        this.type = PurchaseTriggerIntegrationData.purchaseType.BLAST_PINBALL;

        // 是否正在自動射彈珠
        this._isAutoShootingFreeBall = false;

        // 是否正在請求資料
        this._isRequestingInfo = false;

        this.loadFileArray = [
            "purchaseTriggerIntegration/blastPinball.plist", "purchaseTriggerIntegration/blastPinball.png"
        ];

        // 資料 reference
        // @type {BlastPinballData}
        this._dataRef = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(this.type);
    },

    onEnter: function () {
        this._super();

        // 埋點：5227 進入激爆彈珠台活動頁
        this._dataRef.sendTracking(5227);
    },

    canExit: function () {
        // 埋點：5228 點擊關閉按鈕
        this._dataRef.sendTracking(5228);

        if (this._isAutoShootingFreeBall) {
            return false;
        }

        let data = this._dataRef;
        if (data.ballCount > 0 && !this._isRequestingInfo) {
            if (data.isFree) {
                // 有球可以繼續玩，跳挽留 dialog 2
                this._showBallLeftDialogAsync().then(() => {
                    // 自動玩，直到免費彈珠用完
                    this._isAutoShootingFreeBall = true;
                    this._shootBall();
                });

                // 不給離開
                return false;
            } else if (!this._didPaidBallLeftDialogShow) {
                // 若已經顯示過付費彈珠提醒 dialog，不再顯示。
                // 下一次點擊關閉按鈕時將可以關閉 dialog
                this._didPaidBallLeftDialogShow = true;
                this._showBallLeftDialogAsync().then(() => {
                    // 幫他抽一球
                    this._shootBall();
                });

                // 不給離開
                return false;
            }
        }

        return true;
    },

    /**
     * 請求資料
     * @private
     */
    _requestInfo: function () {
        if (this.__isDestroyed) {
            return;
        }
        this._isRequestingInfo = true;
        this.setLoadingSprite(true, true);
        this._dataRef.requestInfo();
    },

    loadFileDone: function () {
        this._super();

        // 主背景
        let bgSprite = new ccui.Scale9Sprite("blastPinball_bg_1-" + (GS.isLuxyPoker ? "2" : "1") + ".png");
        bgSprite.setPreferredSize(cc.size(370, 198));
        bgSprite.setPosition(JSScreenMidPos.x + 36, JSScreenMidPos.y - 21);
        this.addChild(bgSprite);

        // 標題 激爆彈珠台
        let titleSprite = new cc.Sprite("#blastPinball_w_title.png");
        titleSprite.setPosition(JSScreenMidPos.x - 60, JSScreenMidPos.y + 88);
        this.addChild(titleSprite);

        // 左方背景
        let leftBg = new ccui.Scale9Sprite("blastPinball_bg_2.png");
        leftBg.setPreferredSize(cc.size(200, 128));
        leftBg.setPosition(JSScreenMidPos.x - 43, JSScreenMidPos.y - 23);
        this.addChild(leftBg);

        // 副標題 挑戰
        let title = this._titleSp = new cc.LabelTTF("", JSFontName, 12);
        title.setFontFillColor(cc.color(247, 252, 212));
        title.enableStroke(cc.color(130, 29, 10), 2);
        title.setPosition(JSScreenMidPos.x - 63, JSScreenMidPos.y + 53);
        this.addChild(title);

        // 9T只有四個獎項
        let rewardPosList = Array(4).fill(0).map((_, i) => cc.p(-111, 17 - i * 27));

        this._rewardNodeList = rewardPosList.map((pos, i) => {
            let node = new BlastPinballPrizeNode(i + 1);
            node.setPosition(cc.pAdd(JSScreenMidPos, pos));
            this.addChild(node);
            return node;
        });

        // 彈珠臺本體
        let machineNode = this._machineNode = new BlastPinballMachineNode(
            this._onShootBtnTouchDown.bind(this),
            this._onShootStart.bind(this),
            this._onShootEnd.bind(this),
            this._purchaseBtnClicked.bind(this)
        );
        machineNode.setPosition(JSScreenMidPos.x + 115, JSScreenMidPos.y + 17);
        this.addChild(machineNode, 1);

        // 咖啡色背景
        let ballCountBg = new ccui.Scale9Sprite("blastPinball_pic_blank2.png");
        ballCountBg.setPreferredSize(cc.size(70, 18));
        ballCountBg.setPosition(JSScreenMidPos.x + 135, JSScreenMidPos.y - 99);
        this.addChild(ballCountBg);

        let ballCountAutoLayout = this._ballCountAutoLayout = new GSAutoLayoutNode();
        ballCountAutoLayout.setPosition(ballCountBg.getPosition());
        ballCountAutoLayout.setSpace(2);
        this.addChild(ballCountAutoLayout);

        let ballCountTextLabel = new cc.LabelTTF(LocalizedString.BlastPinballString("剩餘彈珠"), JSFontBoldName, 10);
        ballCountAutoLayout.addChild(ballCountTextLabel);

        // 剩餘彈珠右方的 數字
        var ballCountLabel = this._ballCountLabel = new cc.LabelTTF('-', JSFontBoldName, 10);
        ballCountLabel.setFontFillColor(JSColor.YELLOW3);
        ballCountAutoLayout.addChild(ballCountLabel);

        // 剩餘彈珠 右方的彈珠
        let ballSprite = this._ballSprite = new cc.Sprite("#blastPinball_pic_pinball1.png");
        ballSprite.setScale(0.75);
        ballCountAutoLayout.addChild(ballSprite);

        // 關閉倒數的時間 XX:XX
        let countdownLabel = this._countdownLabel = new RemainTimeLabel(RemainTimeLabel.Style.WHITE, {
            fontSize: 10,
            bgFileName: "blastPinball_pic_blank2.png",
            prefix: LocalizedString.BlastPinballString("剩餘時間"),
            countdownColor: JSColor.YELLOW,
        });
        countdownLabel.setPosition(JSScreenMidPos.x - 75, JSScreenMidPos.y - 99);
        countdownLabel.setMultiFormat("%ddD%hhH", "%hhH%mmM", "%mmM%ssS");
        this.addChild(countdownLabel);

        // 說明按鈕
        let infoButton = this._infoButton = new Texas_ExplainButton(this._explainBtnStyle);
        infoButton.addTouchUpInsideAction(() => {
            // 埋點：5229 點擊說明按鈕
            this._dataRef.sendTracking(5229);
            this.showInfoDialog();
        }, this);
        infoButton.setPosition(123 + JSScreenBonusHalfWidth, JSVisibleSize.height - JSScreenBonusHalfHeight - 20);
        this.addChild(infoButton, 1);

        // 先跑一次，看看有沒有儲值資料
        this.notifyBlastPinballRechargeDone();

        GS.addListener("NotifyBlastPinballInfoDone", this.notifyBlastPinballInfoDone.bind(this), this);
        GS.addListener("NotifyBlastPinballShowErrorDialog", this.notifyBlastPinballShowErrorDialog.bind(this), this);
        GS.addListener("NotifyBlastPinballPlayDone", this.notifyBlastPinballPlayDone.bind(this), this);
        GS.addListener("NotifyBlastPinballRechargeDone", this.notifyBlastPinballRechargeDone.bind(this), this);
        GS.addListener("NotifySocketResult", this.notifySocketResult.bind(this), this);

        // 請求資料
        this._requestInfo();
    },

    /**
     * 更新禮包畫面
     */
    _refreshView: function () {
        this.stopAllActions();
        this.setLoadingSprite(false, false);
        this._isRequestingInfo = false;

        let data = this._dataRef;

        if (!data.getIsOpen()) {
            return;
        }

        this._countdownLabel.countdownSeconds(data.getRemainTime());

        this._machineNode.refreshView();

        // 更新球數
        this._updateBallCount();

        // 有上一筆獎勵資料，顯示獎勵 dialog
        if (data.lastReward) {
            this._isReconnected = true;
            this._showRewardDialog(data.lastReward).then(() => {
                // Do nothing.
            });
            data.lastReward = undefined;
        }
    },

    /**
     * 設定是否鎖住 dialog 按鈕
     * @param {boolean} isLock
     * @private
     */
    _setLockButtons: function (isLock) {
        // 設定Dialog上的按鈕
        this.setAllBtnEnabled(!isLock);

        // 設定說明按鈕
        this._infoButton.setEnabled(!isLock);
    },

    // 依照模式 更新獎金
    _updatePriceList: function (withoutHideAwardFlag) {
        let param = this._dataRef;

        // 讓獎金更新動畫間隔 0.1 秒
        let actList = [];
        this._rewardNodeList.forEach((node, i) => {
            // 隱藏中獎動畫
            node.stopRewardAnime();

            actList.push(
                cc.delayTime(0.1),
                cc.callFunc(() => {
                    node.playFlippingAnime(param.rewards[i + 1]);
                })
            );
        });

        this.runAction(cc.sequence(actList));

        // 隱藏所有獎格內五角形 spine 動畫
        withoutHideAwardFlag || this.runAction(cc.sequence(cc.delayTime(1), cc.callFunc(() => {
            this._machineNode.hideFlagSpine();
        })));
    },

    // 更新 球數
    _updateBallCount: function () {
        let data = this._dataRef;

        // 更新球的數量
        this._ballCountLabel.setString(data.ballCount);
        this._ballCountAutoLayout.refresh();

        // 更新副標題
        this._titleSp.setString(LocalizedString.BlastPinballString(data.isFree ? "來抽免費獎勵！" : "每球必有獎！"));

        // 換左下球數的球的顏色
        this._ballSprite.setSpriteFrame(JSStringUtility.format("blastPinball_pic_pinball%d.png", data.isFree ? 2 : 1));

        if (this._isAutoShootingFreeBall && !data.isFree) {
            // 只有持有免費彈珠點擊關閉 dialog 時會自動射，當更新時是付費彈珠時，代表已經射完免費彈珠 -> 跳提醒 dialog
            this._showPurchaseRemindingDialog();

            // 關掉自動抽球，避免自動射出付費的球
            this._isAutoShootingFreeBall = false;
        }

        // 沒球了
        if (data.ballCount <= 0) {
            // 埋點：5236 看到獲得彈珠按鈕
            this._dataRef.sendTracking(5236);

            // 球用完要顯示購買按鈕
            this._machineNode.showPurchaseButton();
            this._isAutoShootingFreeBall = false;
        }
        // 還有球可以繼續玩，準備下一顆球
        else {
            this._machineNode.hidePurchaseLayer();
            this._machineNode.prepareNextBall();

            if (data.isFree && this._isAutoShootingFreeBall) {
                // 只有免費的彈珠要幫他射完
                this._shootBall();
            }
        }

        // 更新獎金列表
        this._updatePriceList(true);
    },

    /**
     * 蓄力並射出一顆彈珠
     * @private
     */
    _shootBall: function () {
        let machineNode = this._machineNode;
        machineNode.shotBtnPressed(machineNode.shotButton, cc.CONTROL_EVENT_TOUCH_DOWN);
        machineNode.shotButton.runAction(cc.sequence(
            cc.delayTime(1),
            cc.callFunc(() => {
                machineNode.shotBtnPressed(machineNode.shotButton, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
            })
        ));
    },

    /**
     * 開始蓄力
     * @private
     */
    _onShootBtnTouchDown: function () {
        // 鎖住按鈕
        this._setLockButtons(true);
    },

    /**
     * 開始射出彈珠
     * @private
     */
    _onShootStart: function () {
        this.eventEndDelegate.lock().then((key) => {
            // 卡掉不給儲值觸發整合 dialog 跑活動結束
            this.__eventEndSemaphoreKey = key;
        }).catch(() => { /* Do Nothing */
        });
    },

    /**
     * 彈珠停下
     * @param {boolean} isFailed 是否失敗
     * @param {object?} playData blast_pinball_play 回傳的資料
     * @private
     */
    _onShootEnd: function (isFailed, playData = {}) {
        let machineNode = this._machineNode;

        // 成功 演中獎動畫
        Promise.resolve()
            .then(() => new Promise((resolve, reject) => {
                if (isFailed) {
                    // 發射失敗不特別做其他事
                    return reject();
                }

                // 播放音效(同大樂彩-完成選號)
                MusicUtility.playEffect("Music/Effect/blastPinball.mp3", false);

                let targetType = machineNode.getBallStopType();
                this._rewardNodeList[targetType - 1].playWinningAnime();

                // 機台內的獎格也亮起
                machineNode.playFlagSpine();

                // 演 2 秒就 resolve
                this.runAction(cc.sequence(
                    cc.delayTime(2),
                    cc.callFunc(() => resolve())
                ));
            }))
            .catch(() => Promise.resolve())
            .then(() => {
                // 按鈕復原
                this._setLockButtons(false);

                return playData.rewardMsg ? this._showRewardDialog(playData) : Promise.resolve();
            })
            .then(() => {
                if (isFailed) {
                    machineNode.prepareNextBall();
                } else {
                    // 去要彈珠的新資料
                    this._requestInfo();
                }

                // 釋放 semaphore
                if (this.__eventEndSemaphoreKey) {
                    this.eventEndDelegate.unlock(this.__eventEndSemaphoreKey);
                    this.__eventEndSemaphoreKey = undefined;
                }
            });
    },

    /**
     * 購買按鈕點擊
     * @private
     */
    _purchaseBtnClicked: function (sender) {
        // 埋點：5237 點擊獲得彈珠按鈕
        sender && this._dataRef.sendTracking(5237);

        // 導儲值中心 (已經在儲值中心的話不要再導)
        if (!PushScene.checkNowLayer(PurchaseLayer)) {
            PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
        } else {
            this.closeDialogAnimation();
        }
    },

    /**
     * ========== Dialog ==========
     */

    _showRewardDialog: function (playData) {
        return new Promise((resolve, reject) => {
            let data = this._dataRef;

            // 領獎 Dialog
            let prizeTextMap = {
                [BlastPinballData.RewardType.BIG]: "BIG",
                [BlastPinballData.RewardType.MEGA]: "MEGA",
                [BlastPinballData.RewardType.GRAND]: "GRAND",
                [BlastPinballData.RewardType.MINI]: "MINI",
            };

            // 內文
            let content = playData.rewardMsg;
            let ballCount = data.ballCount - (this._isReconnected ? 0 : 1);

            if (playData.isFree) {
                content += "\n#!faffad!#" + LocalizedString.BlastPinballString("儲值玩彈珠獲得更多獎勵！");
            } else if (ballCount > 0) {
                content += "\n#!faffad!#" + JSStringUtility.format(LocalizedString.BlastPinballString("(你還有%s顆彈珠)"), ballCount);
            }

            // 告訴 server 跳出獎勵 dialog
            this._dataRef.sendRewardDone();
            this.showDialog(new BlastPinballCommonDialog({
                title: LocalizedString.BlastPinballString("恭喜您獲得") + " #!005AD9!#" + prizeTextMap[playData.prize],
                content: content,
                isReconnected: this._isReconnected,
                closeCallback: () => resolve(),
                buttonList: [
                    (dialog) => {
                        let button = new Texas_Button(Texas_Button.Style.GREEN, cc.size(85, 30), LocalizedString.BlastPinballString(this._dataRef.isFree ? "繼續玩" : "確定"));
                        button.addTouchUpInsideAction(() => {
                            dialog.closeDialogAnimation();

                            // 先前顯示過挽留付費彈珠 dialog（挽留 dialog 2）
                            if (this._didPaidBallLeftDialogShow) {
                                // 關掉儲值整合 dialog
                                this.closeDialogAnimation();
                            }
                        }, dialog);
                        return button;
                    }
                ],
            }));
            this._isReconnected = false;
        });
    },

    /**
     * 跳出提醒有付費彈珠 dialog（挽留 dialog 2）
     * @private
     */
    _showBallLeftDialogAsync: function () {
        // 埋點：5245 獲得挽留Dialog 2
        this._dataRef.sendTracking(5245);
        return new Promise((resolve, reject) => {
            this.showDialog(new BlastPinballCommonDialog({
                title: LocalizedString.BlastPinballString("提醒您"),
                content: JSStringUtility.format(LocalizedString.BlastPinballString("還有#!fff433!#%d#!ffffff!#顆未使用的彈珠，\n來玩一手吧！"), this._dataRef.ballCount),
                closeCallback: () => {
                    // 埋點：5246 挽留Dialog 2點擊確定
                    this._dataRef.sendTracking(5246);

                    resolve();
                },
            }));
        });
    },

    /**
     * 顯示提醒儲值 dialog（挽留 dialog 1）
     * @private
     */
    _showPurchaseRemindingDialog: function () {
        // 埋點：5242 獲得挽留Dialog 1
        this._dataRef.sendTracking(5242);

        let dialog = new BlastPinballCommonDialog({
            title: LocalizedString.BlastPinballString("提醒您"),
            content: LocalizedString.BlastPinballString("獲得更多彈珠子，\n有機會中GRAND獎！"),
            buttonList: [
                () => {
                    let btn = new Texas_Button(Texas_Button.Style.BLUE, cc.size(85, 30), LocalizedString.BlastPinballString("先不要"));
                    btn.addTouchUpInsideAction(() => {
                        // 埋點：5243 挽留Dialog 1點擊先不要
                        this._dataRef.sendTracking(5243);
                        this.closeDialogAnimation();
                    }, this);
                    return btn;
                },
                () => {
                    let btn = new Texas_Button(Texas_Button.Style.GREEN, cc.size(85, 30), LocalizedString.BlastPinballString("確定"));
                    btn.addTouchUpInsideAction(() => {
                        // 埋點：5244 挽留Dialog 1點擊確定
                        this._dataRef.sendTracking(5244);

                        // 導儲值中心 (已經在儲值中心的話不要再導)
                        this._purchaseBtnClicked();
                        dialog.closeDialogAnimation();
                        this.closeDialogAnimation();
                    }, this);
                    return btn;
                }
            ],
            isLockBackKey: true,
        });
        this.showDialog(dialog);
    },

    /**
     * 建立說明頁 dialog
     * @returns {*}
     * @private
     */
    _createInfoDialog: function () {
        let param = this._dataRef;
        return new WebViewDialog(TexasUtility.getSimpleInfoURLByKey("blast_pinball", ["group=" + param.group]), "", null, true);
    },

    /**
     * ========== Notification ==========
     */

    /**
     * 處理 彈珠發射 server 是否正常收到
     */
    notifyBlastPinballPlayDone: function (event) {
        if (event && event.getUserData()) {
            let param = event.getUserData();
            if (param.error === 0) {
                // 讓彈珠射出去
                this._machineNode.realShotPinballAnimation(param);
            } else {
                // 跳錯誤 dialog
                this.showErrorDialog();

                // 按鈕復原
                this._setLockButtons(false);

                // 射球失敗
                this._onShootEnd(true);
            }
        }
    },

    /**
     * 儲值成功
     */
    notifyBlastPinballRechargeDone: function () {
        let param = this._dataRef.rechargeData;
        if (param.error === 0) {
            if (this._rechargeDoneDialog) {
                // 已經顯示過 -> 關掉（清掉 callback 避免要資料與誤刪暫存資料）
                this._rechargeDoneDialog.setCloseCallback(undefined);
                this._rechargeDoneDialog.closeDialogAnimation();
                this._rechargeDoneDialog = undefined;
            }

            // 購買成功 dialog
            let dialog = this._rechargeDoneDialog = new BlastPinballCommonDialog({
                title: LocalizedString.BlastPinballString("購買成功！"),
                content: JSStringUtility.format(LocalizedString.BlastPinballString("恭喜獲得#!fff433!#%s#!ffffff!#次遊玩機會\n#!faffad$!10!$!#次數請務必於倒數時間結束前用完"), param.deltaBallCount),
                closeCallback: () => {
                    // 去要付費彈珠的資料
                    this._requestInfo();

                    // 清掉資料
                    this._rechargeDoneDialog = undefined;
                    this._dataRef.cleanRechargeData();
                },
            });
            this.showDialog(dialog);
        }
    },

    // 收到資料更新
    notifyBlastPinballInfoDone: function () {
        this._refreshView();
    },

    // 通知顯示 錯誤 dialog
    notifyBlastPinballShowErrorDialog: function () {
        this.showErrorDialog();
    },

    notifySocketResult: function (e) {
        switch (e.getUserData()) {
            case "ReconnectDone":
                // 斷線重連成功了
                this._isReconnected = true;
                this._requestInfo();
                break;
        }
    },

    /**
     * ========== Debug ==========
     */

    createDebugTestObject: function () {
        return new TestMenuDebugObject("激爆彈珠台", {
            "開關碰撞箱": () => {
                if (this._machineNode.hitBoxLayer) {
                    this._machineNode.hitBoxLayer.removeFromParent();
                    this._machineNode.hitBoxLayer = undefined;
                } else {
                    let debugNode = this._machineNode.hitBoxLayer = new cc.PhysicsDebugNode(this._machineNode._space);
                    debugNode.setPosition(-JSScreenMidPos.x, -JSScreenMidPos.y);
                    this._machineNode.addChild(debugNode, 10);
                }
            },
            "開關落點顯示": () => {
                if (this._machineNode.debugLocationDrawNode) {
                    this._machineNode.debugLocationDrawNode.removeFromParent();
                    this._machineNode.debugLocationDrawNode = undefined;
                    this._machineNode.debugLocationDrawLabel.removeFromParent();
                    this._machineNode.debugLocationDrawLabel = undefined;
                } else {
                    this._machineNode.debugLocationDrawNode = new cc.DrawNode();
                    this._machineNode.addChild(this._machineNode.debugLocationDrawNode, 10);

                    let debugLabel = this._machineNode.debugLocationDrawLabel = new cc.LabelTTF("落點顯示已開啟", JSFontName, 12);
                    debugLabel.setPosition(this._machineNode.convertToNodeSpace(cc.p(JSVisibleSize.width - 10, 10)));
                    debugLabel.setAnchorPoint(1, 0);
                    debugLabel.enableStroke(JSColor.OUTLINE_CONTENT, 2);
                    this._machineNode.addChild(debugLabel, 10);
                }
            },
            "免費有球": () => DataProcess.sendCustomStringToSelf('blast_pinball_info {"group":"1","error":"0","pinballs":"20","rewards":{"1":"34.88mlr","2":"34.77jt","3":"34.66rb","4":"34.55RP"},"is_free":"1"}'),
            "免費無球": () => DataProcess.sendCustomStringToSelf('blast_pinball_info {"group":"1","error":"0","pinballs":"0","rewards":{"1":"34.88mlr","2":"34.77jt","3":"34.66rb","4":"34.55RP"},"is_free":"1"}'),
            "付費有球": () => DataProcess.sendCustomStringToSelf('blast_pinball_info {"group":"1","error":"0","pinballs":"20","rewards":{"1":"34.88mlr","2":"34.77jt","3":"34.66rb","4":"34.55RP"},"is_free":"0"}'),
            "付費無球": () => DataProcess.sendCustomStringToSelf('blast_pinball_info {"group":"1","error":"0","pinballs":"0","rewards":{"1":"34.88mlr","2":"34.77jt","3":"34.66rb","4":"34.55RP"},"is_free":"0"}'),
            "重連 info": () => DataProcess.sendCustomStringToSelf('blast_pinball_info {"group":"1","error":"0","pinballs":"0","rewards":{"1":"34.88mlr","2":"34.77jt","3":"34.66rb","4":"34.55RP"},"is_free":"0","last_reward":{"prize":"2","reward":"34.77jt","is_free":"1"}}'),
            "play 1": () => DataProcess.sendCustomStringToSelf('blast_pinball_play {"prize":"1","left_charged_pinballs":"-1","is_free":"1","count":"2","reward_msg":"2 chips","error":"0"}'),
            "play 2": () => DataProcess.sendCustomStringToSelf('blast_pinball_play {"prize":"2","left_charged_pinballs":"-1","is_free":"1","count":"2","reward_msg":"2 chips","error":"0"}'),
            "play 3": () => DataProcess.sendCustomStringToSelf('blast_pinball_play {"prize":"3","left_charged_pinballs":"-1","is_free":"1","count":"2","reward_msg":"2 chips","error":"0"}'),
            "play 4": () => DataProcess.sendCustomStringToSelf('blast_pinball_play {"prize":"4","left_charged_pinballs":"-1","is_free":"1","count":"2","reward_msg":"2 chips","error":"0"}'),
            "recharge_done": () => DataProcess.sendCustomStringToSelf('blast_pinball_recharge_done {"pinballs":"3"}'),
            "斷線重連領獎": () => {
                this._isReconnected = true;
                this._showRewardDialog({
                    prize: 2,
                    rewardMsg: "2 chips"
                });
            },
            "免費領獎 dialog": () => this._showRewardDialog({
                prize: 2,
                rewardMsg: "2 chips",
                isFree: true,
            }),
            "付費領獎 dialog": () => this._showRewardDialog({
                prize: 2,
                rewardMsg: "2 chips",
                isFree: false,
            }),
            "挽留 dialog 1": () => this._showPurchaseRemindingDialog(),
            "挽留 dialog 2": () => this._showBallLeftDialogAsync(),
            "錯誤 dialog": () => this.showErrorDialog(),
        });
    },
});