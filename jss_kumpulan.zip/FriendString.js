var LocalizedString = LocalizedString || {};

(function () {
    var keyValue = {
        "好友清單": "Daftar Teman",
        "找好友": "Cari Teman",
        "申請列表": "Permintaan\nTeman",
        "確定": "OK",
        "取消": "Batal",

        // 聊天室
        "聊天室": "Ruang Obrolan",
        "找好友聊天": "Cari teman ngobrol",
        "往下拉看更多": "Tarik ke bawah utk lihat lebih",
        "說些什麼吧": "Yuk ngobrol",
        "牌局中不可聊天哦": "Tidak bisa chat saat bermain",
        "確定要將對話框刪除?": "Yakin untuk hapus obrolan ini?",
        "不刪除": "Tidak",
        "刪除": "Hapus",
        "對話框刪除成功!": "Obrolan telah dihapus!",
        "對話框刪除失敗，請稍後再試!": "Obrolan gagal dihapus,\nCoba lagi nanti!",

        // 好友清單
        "目前還沒有好友哦，快去玩遊戲交朋友吧!": "Tidak ada teman,\nyuk main & cari teman",
        "好友清單(%d/%d)": "Daftar Teman(%d/%d)",
        "確定要將此好友刪除？": "Yakin hapus teman ini?",
        "已成功刪除": "Berhasil menghapus",
        "此桌已無法入桌\n是否要與其他人玩?\n實際進入底台大小，可能與看到的不同": "Meja sudah penuh, pindah ke meja lain?\nJumlah bet bisa berbeda dari sebelumnya",
        "您的資產不夠入桌哦\n是否要儲值?": "Jumlah chips Anda belum \ncukup untuk masuk ke meja,\napakah Anda mau melakukan \npembelian?",
        "在線上": "Online",
        "離線1分鐘": "Offline 1\nmenit lalu",
        "離線%d分鐘": "Offline %d\nmenit lalu",
        "離線%d小時": "Offline %d\njam lalu",
        "離線%d天": "Offline %d\nhari lalu",
        "離線": "Offline",
        "請輸入兩個字以上": "Harap ketik 2 huruf atau lebih",
        "查無結果，請重新輸入": "Data tidak tersedia, silahkan coba lagi",

        // 找好友
        "最近一起玩過的人(%d)": "Baru saja main dengan(%d)",
        "輸入ID搜尋好友": "Ketik ID cari teman",
        "已將好友申請送出": "Permintaan teman telah dikirim",
        "已發送申請，等待確認中": "Permintaan telah dikirim, harap menunggu",
        "查無結果，請重新搜尋": "Tidak ada hasil, coba cari lagi",
        "目前沒有一起玩過的人哦\n快去牌桌玩遊戲\n認識新朋友吧": "Belum bermain dengan orang lain\nSegera main & mengenal teman baru",
        "你的好友數已滿\n目前沒有空位再加好友了哦": "Teman sudah penuh\nTidak ada slot utk tambah teman",
        "提醒": "Peringatan",
        "您剛剛已經搜尋過了哦\n稍等再試試看吧": "Sudah pernah mencari,\ncoba beberapa saat lagi",
        "對方好友已滿，目前沒有空位再加好友囉": "Jumlah teman pemain lain sudah penuh,\nsaat ini belum ada tempat kosong untuk tambah teman",

        // 申請好友
        "申請好友": "Permintaan Teman",
        "目前沒有好友申請哦": "Belum ada permintaan teman",

        // 桌內好友邀請
        "好友": "Teman",
        "邀請": "Undang",
        "已邀請": "Sudah diundang",
        "已經": "Sudah",
        "邀請過": "diundang",
        "邀請您一起玩": "Mengundang mu bermain",
        "加入": "Gabung",
        "無法入該注牌桌，\n要不要導到其他注的牌桌呢?": "Belum bisa masuk ke meja bet ini,\napakah Anda mau diarahkan ke\nmeja bet lainya?",

        // 桌內加好友提示
        "想要加你好友": "Ingin menjadi teman Anda",
        "你已拒絕成為好友": "Anda telah menolak untuk\njadi teman",
        "與你已成為好友!": "Telah berhasil menjadi\nteman Anda",
        "拒絕": "Tolak",
        "接受": "Terima",

        // Gaple好友桌邀請訊息
        "邀你一起玩Gaple好友桌": "Anda diundang masuk meja Gaple Teman",

        // 其它
        "系統異常，將為您重新整理": "Sistem bermasalah, akan refresh secara otomatis",
        "選擇一位好友:": "Memilih 1 teman:"

    };

    LocalizedString.Friend = function (str) {
        return USE_i18n ? (keyValue[str] || str) : str;
    };
})();
