/**
 * 玩家決定牌型的等待圖片
 */

var DOMINO_PLAYER_CONFIRM_STATUS = {
    NONE: 0,            // 現在沒在決定任何東西
    WAITING: 1,         // 現在正在等待做決定
    DONE: 2,            // 決定完成
};

var Domino_PlayerConfirmNode = cc.Node.extend({

    ctor: function () {
        this._super();

        this.setCascadeOpacityEnabled(true);
        this.setCascadeColorEnabled(true);

        // 背景
        var bgSprite = new cc.Sprite("#domino_pic_status.png");
        this.addChild(bgSprite);

        // 等待 or 完成的Sprite
        this._actionSprite = new cc.Sprite();
        this.addChild(this._actionSprite);
    },

    /**
     * 設定現在的狀態
     */
    setStatus: function (status) {
        var spriteFrameName = null;
        switch (status) {
            case DOMINO_PLAYER_CONFIRM_STATUS.WAITING:
                // 等待中
                spriteFrameName = "domino_pic_waiting.png";
                break;
            case DOMINO_PLAYER_CONFIRM_STATUS.DONE:
                // 已決定
                spriteFrameName = "game_pic_check.png";
                break;
            default:
                break
        }

        // 更換圖片
        if (spriteFrameName) {
            this._actionSprite.setSpriteFrame(spriteFrameName);
        }

        // 看是否要顯示
        this.setVisible(!!spriteFrameName);
    },
});