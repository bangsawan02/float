var Domino_PlayerChipNode = cc.Node.extend({

    ctor: function (money) {
        this._super();

        this.setCascadeOpacityEnabled(true);
        this.setCascadeColorEnabled(true);

        this.chipMoney = 0;             // 現在的金錢
        this._chipSprite = null;        // 現在的圖片

        money && this.setChipMoney(money);
    },

    /**
     * 設定這個chip的金錢
     */
    setChipMoney: function (money) {
        this.chipMoney = money;

        // 判斷是否有舊的圖
        if (this._chipSprite) {
            this._chipSprite.removeFromParent();
            this._chipSprite = null;
        }

        // 判斷金額大小來決定圖檔
        var imageString = Domino_GameUtility.getChipImage(money);
        this._chipSprite = new cc.Sprite(imageString);
        this.addChild(this._chipSprite);
    },
});