/**
 * 排行榜前三名 Node
 * created by andrew.chang
 */

var BaseRankTopPlayerNode = cc.Node.extend({
    ctor: function (type = BaseRankDialog.Type.TOKEN_SUBSYSTEM, rank) {
        this._super();
        this._type = type;

        // 人物的Node 因為會縮小 放在一起
        var playerNode = new cc.Node();
        playerNode.setCascadeColorEnabled(true);
        playerNode.setCascadeOpacityEnabled(true);
        playerNode.setScale(rank === 1 ? 0.8 : (rank === 2 ? 0.75 : 0.7));
        this.addChild(playerNode);

        // 大頭照按鈕
        var photoBtn = this._photoBtn = new ButtonUtility.createSimpleButton(undefined, cc.size(56, 56));
        photoBtn.addTouchUpInsideAction(this._photoBtnClicked, this);
        photoBtn.setEnabled(false);
        playerNode.addChild(photoBtn);

        // 人物頭像
        var stencilSprite = new cc.Sprite("#lobby_photo_clip.png");
        var clipNode = new cc.ClippingNode(stencilSprite);
        clipNode.setCascadeColorEnabled(true);
        clipNode.setAlphaThreshold(0.5);
        clipNode.setScale(1.16);
        photoBtn.addChildToContentNode(clipNode);

        // 放照片
        var photoSprite = this._photoSprite = new PhotoSprite(undefined, 56, 56, "photo_gray_male.png");
        photoSprite.setColor(JSColor.GRAY);
        clipNode.addChild(photoSprite);

        // 大頭照上的從缺
        var noPhotoLabel = this._noPhotoLabel = new cc.LabelTTF(LocalizedString.VegasMapMissionString("從缺"), JSFontName, 12);
        noPhotoLabel.enableStroke(JSColor.BLACK, 2);
        this.addChild(noPhotoLabel);

        // 排名旁邊的葉子
        var leafImage = JSStringUtility.format("#lobby_rank_laurelleaf_%02d.png", rank);
        for (var i = 0; i < 2; i++) {
            var leafSprite = new cc.Sprite(leafImage);
            leafSprite.setScale(0.7);
            leafSprite.setPositionX(i === 0 ? 32 : -31);
            leafSprite.setFlippedX(i === 1);
            playerNode.addChild(leafSprite);
        }

        // 排名框
        var rankFrameSprite = new cc.Sprite(JSStringUtility.format("#lobby_rank_pic_frame_%02d.png", rank));
        rankFrameSprite.setScale(0.7);
        playerNode.addChild(rankFrameSprite);

        // 名次數字
        var rankSprite = new cc.Sprite("#lobby_rank_0" + rank + ".png");
        rankSprite.setAnchorPoint(0.5, 0);
        rankSprite.setPosition(-35, -20);
        playerNode.addChild(rankSprite);

        // 暱稱背景
        var nicknameBgSprite = new cc.Sprite("#lobby_rank_pic_bg.png");
        nicknameBgSprite.setScale(0.9);
        nicknameBgSprite.setPositionY(-27);
        this.addChild(nicknameBgSprite);

        // 玩家暱稱
        var nicknameLabel = this._nicknameLabel = new cc.LabelTTF("", JSFontName, 12);
        nicknameLabel.setPositionY(-27);
        this.addChild(nicknameLabel);

        // 第一名閃光特效
        if (rank === 1) {
            // 要閃閃發光
            var starPos = [
                cc.p(-3, 36),
                cc.p(32, -15),
                cc.p(35, 8),
                cc.p(-47, 13)
            ];
            for (var i = 0, len = starPos.length; i < len; i++) {
                var thisDelayTime = i * 0.6;
                var finalDelayTime = 3 - thisDelayTime;
                var starSprite = new cc.Sprite("#lobby_pic_star.png");
                starSprite.setPosition(starPos[i]);
                starSprite.setScale(0.6 + JSCodeUtility.getRandomFloat(0, 0.4));
                starSprite.setOpacity(0);
                starSprite.runAction(cc.repeatForever(cc.sequence(
                    cc.delayTime(thisDelayTime),
                    cc.show(),
                    cc.fadeIn(0.5),
                    cc.delayTime(0.5),
                    cc.fadeOut(0.5),
                    cc.hide(),
                    cc.delayTime(finalDelayTime)
                )));
                starSprite.runAction(cc.repeatForever(cc.rotateBy(1, 360)));
                playerNode.addChild(starSprite);
            }
        }

        // 寶箱按鈕
        var chestBtn = this._chestBtn = ButtonUtility.createSimpleImageButton("lobby_pic_chest_light.png", null, JSStringUtility.format("#lobby_pic_chest_%02d.png", rank));
        chestBtn.setVisible(false);
        chestBtn.setScale(0.75);
        chestBtn.setPosition(33, -8);
        chestBtn.addTargetWithActionForControlEvents(this, this._chestBtnClicked,
            cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
            cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
            cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
        this.addChild(chestBtn);

        // 排行排版的node
        var rankLayoutNode = this._rankLayoutNode = new GSAutoLayoutNode();
        rankLayoutNode.setSpace(4);
        rankLayoutNode.setPositionY(-46);
        this.addChild(rankLayoutNode);
    },

    /**
     * 刷新畫面
     * @param param 玩家資訊
     */
    refreshView: function (param) {
        // 先清掉排版的node
        var rankLayoutNode = this._rankLayoutNode;
        rankLayoutNode.removeAllChildren();

        // 判斷有無玩家帳號
        if (param && param.account && param.account.length) {
            // 記下account 開個人資訊頁會用到
            this._account = param.account;

            // 刷新大頭照
            this._photoSprite.setPhotoUrlString(param.photoURL, param.account);
            this._photoSprite.setColor(JSColor.WHITE);

            // 隱藏從缺
            this._noPhotoLabel.setVisible(false);

            // 暱稱
            this._nicknameLabel.setString(JSStringUtility.cutStringReplaceByEllipsis(param.nickname, 8, 50));

            // 將按鈕設為可以點擊
            this._photoBtn.setEnabled(true);

            // 寶箱的按鈕
            if (param.rewardArray && param.rewardArray.length > 0) {
                this._chestBtn.rewards = param.rewardArray;
                this._chestBtn.setVisible(true);
            } else
                this._chestBtn.setVisible(false);

            // 物品
            var itemSprite = this._createItemSprite();
            rankLayoutNode.addChild(itemSprite);

            // 數量
            var string = param.score > 999999999 ? TexasUtility.getSimpleMoneyString(param.score, 1) : JSCodeUtility.getCurrencyString(param.score);
            var label = new cc.LabelTTF(string, JSFontName, 10);
            label.setFontFillColor(this._getScoreLabelFontFillColor());
            rankLayoutNode.addChild(label);
        } else {
            this._account = undefined;

            // 沒有資料的話用預設的大頭照
            this._photoSprite.setDefaultSprite("photo_gray_male.png");
            this._photoSprite.setColor(JSColor.GRAY);

            // 顯示從缺
            this._noPhotoLabel.setVisible(true);

            // 暱稱
            this._nicknameLabel.setVisible(false);

            // 將按鈕設為不可點擊
            this._photoBtn.setEnabled(false);

            // 寶箱消失
            this._chestBtn.setVisible(false);
        }
    },

    _getScoreLabelFontFillColor: function () {
        switch (this._type) {
            case BaseRankDialog.Type.TOKEN_SUBSYSTEM:
                return JSColor.BLACK;
            case BaseRankDialog.Type.STONE_GAMBLING:
                return cc.color(100, 56, 34);
        }
    },

    /**
     * 創物品的sprite
     */
    _createItemSprite: function () {
        switch (this._type) {
            case BaseRankDialog.Type.TOKEN_SUBSYSTEM:
                var itemSprite = new cc.Sprite("#tokenSubsystem_pic_coconut.png");
                itemSprite.setScale(0.5);
                return itemSprite;
            case BaseRankDialog.Type.STONE_GAMBLING:
                var itemSprite = new cc.Sprite("#stoneGambling_pic_crown.png");
                itemSprite.setScale(0.3);
                return itemSprite;
        }
    },

    /**
     * 點擊大頭照
     */
    _photoBtnClicked: function () {
        if (this._account && this._account.length)
            DialogManager.addDialog(new ProfileDialog(this._account), false, true);
    },

    /**
     * 點擊寶箱
     */
    _chestBtnClicked: function (sender, controlEvent) {
        // show獎勵泡泡框
        var obj = {
            controlEvent: controlEvent,
            pos: this.convertToWorldSpace(sender.getPosition()),
            rewards: sender.rewards
        };
        GS.dispatchCustomEvent("NotifyBaseRankShowMessage", obj);
    },
});
