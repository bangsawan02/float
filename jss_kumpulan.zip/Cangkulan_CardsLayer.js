/**
 * Cangkulan 所有放牌的地方都在這 (抽牌區, 棄牌區, 四家手牌, 牌計數器)
 */
var Cangkulan_CardsLayer = cc.Node.extend({
    ctor: function () {
        this._super();

        // 自己的手牌
        var handCardsLayer = this._handCardsLayer = new Cangkulan_HandCardsLayer(this);
        this.addChild(handCardsLayer);

        // 棄牌區
        var foldCardLayer = this._foldCardLayer = new Cangkulan_FoldCardLayer();
        this.addChild(foldCardLayer);

        // 抽牌區
        var drawCardLayer = this._drawCardLayer = new Cangkulan_DrawCardLayer();
        this.addChild(drawCardLayer);

        // 放要發的牌
        var seaCardLayer = this._seaCardLayer = new Cangkulan_SeaCardsLayer();
        this.addChild(seaCardLayer);

        // 記牌器
        var cardCounterLayer = this.cardCounterLayer = new Cangkulan_CardCounterLayer();
        this.addChild(cardCounterLayer, 10);

        // 初始化其他的參數
        this.clean();

        // 監聽
        GS.addListener("NotifyFoldHandCard", this.notifyFoldHandCard.bind(this), this);
        GS.addListener("NotifyShowHandCards", this.notifyShowHandCards.bind(this), this);
        GS.addListener("NotifyShowDrawCards", this.notifyShowDrawCards.bind(this), this);
    },

    clean: function () {
        this.unscheduleAllCallbacks();

        // 清掉自己
        this._selfPlaying = false;

        this._isTurnMe = false;

        this._drawCards = [];
        this._drawTimes = 0;

        // 清掉自家手牌
        this._handCardsLayer.clean();

        // 清掉手牌計數器
        this.cardCounterLayer.clean();

        // 清掉抽牌區
        this._drawCardLayer.clean();

        // 清掉棄牌區
        this._foldCardLayer.clean();

    },

    /**
     * 設定抽牌玩家的位置&抽哪邊的牌
     * @param pos
     * @param type
     */
    setDrawPos: function (drawSit, type, cardCount, drawCard, foldCard) {
        // 抽牌的玩家的座位
        this._drawSit = drawSit;
        // 從 0:抽牌區 1:棄牌區
        this._drawType = type;

        // 抽到的棄牌
        this._foldShowCard = foldCard;

        if (!this._isTurnMe) {
            var cards = [];
            if (this._drawType === Cangkulan_CardType.DRAW) {
                cards[cardCount - 1] = "";
            } else if (this._drawType === Cangkulan_CardType.FOLD) {
                cards.push(drawCard);
            }
            this.runDrawCardAnim(cards);
        } else
            GS.dispatchCustomEvent("NotifyEnableProcessMessage");
    },

    /**
     * 設定是否輪到我
     * @param {Boolean} isTurnMe        是否輪到我
     */
    setIsTurnMe: function (isTurnMe) {
        this._isTurnMe = isTurnMe;
    },

    /**
     * 設定抽牌區的張數
     * @param drawCount
     */
    setDrawCount: function (drawCount) {
        this._drawCardLayer.setDrawCount(drawCount);
    },

    /**
     * 設置棄牌的花色
     */
    setFoldSuit: function (foldCard) {
        this._handCardsLayer.setFoldSuit(foldCard);
    },

    /**
     * 設定 抽牌區 棄牌區隱藏 計牌器隱藏清空
     * @param isFinish
     */
    setFinishAnimationMode: function (isFinish) {
        var isVisible = (!isFinish);
        if (isFinish)
            this.cardCounterLayer.clean(true);
        else
            this.setHandCardVisible(true);

        this._drawCardLayer.setVisible(isVisible);
        this._foldCardLayer.setVisible(isVisible);
    },

    /**
     * 隱藏玩家手牌
     * @param isVisible
     */
    setHandCardVisible: function (isVisible) {
        this._handCardsLayer.setVisible(isVisible);
    },

    /**
     * 開始發牌
     * @param dealerPos     Dealer的位置
     * @param sendPosArray  要發給哪幾家
     * @param handCards     手牌的Array 假如沒有 代表下方是別人
     */
    startSendCardAsync: function (dealerPos, sendPosArray, handCards) {
        return new Promise((resolve, reject) => {
            if (this.__isDestroyed) {
                return reject();
            }

            // 先轉成正確位置
            dealerPos = DataModal.gameData.getDirectionByServerDirection(dealerPos);
            sendPosArray = sendPosArray.map(cur => DataModal.gameData.getDirectionByServerDirection(cur));

            // 先清掉畫面
            this.clean();

            // 洗牌
            this._seaCardLayer.shuffleAsync(sendPosArray.length)
                // 發牌
                .then(() => this._seaCardLayer.startDealAsync(dealerPos, sendPosArray, handCards))
                // 移動到抽牌區
                .then(() => {
                    return new Promise((resolve, reject) => {
                        if (this.__isDestroyed) {
                            return reject();
                        }

                        this._drawCardLayer.runDealEndAnim(resolve);
                        this._handCardsLayer.sortHandCards();
                    });
                })
                // 顯示器牌區
                .then(() => {
                    if (this.__isDestroyed) {
                        return reject();
                    }

                    this._foldCardLayer.showFoldSp();
                    GS.dispatchCustomEvent("NotifyGameDealDone");
                    resolve();
                })
                .catch(e => e && cc.error(e));
        });
    },

    /**
     * 表演抽牌的動畫
     * @param card
     */
    runDrawCardAnim: function (cardsArray) {
        if (this._drawType === Cangkulan_CardType.DRAW) {
            // 從抽牌區飛入手牌

            this._drawCards = cardsArray;
            // 需要抽幾張牌
            var times = this._drawTimes = cardsArray.length;
            if (times > 0) {
                this.runAction(cc.repeat(cc.sequence(
                    cc.callFunc(() => {

                        // 播放抽牌音效
                        MusicUtility.playEffect("Music/Effect/cangkulan_playCard.mp3");

                        this._drawTimes--;
                        // 是不是抽最後一張牌
                        var isFinish = this._drawTimes === 0;

                        if (this._isTurnMe) {
                            // 從抽牌區飛入自己手牌中
                            var drawCard = this._drawCards.shift();
                            if (drawCard) {
                                var obj = {
                                    card: drawCard,
                                    isFold: false,
                                    isDraw: true
                                };
                                // 放入手牌中並找出在手牌的位置
                                var handPos = this._handCardsLayer.getDrawCardPosByHandCard(obj);

                                // 抽牌區表演飛入手牌
                                this._drawCardLayer.runDrawCardAnim(handPos, drawCard, isFinish);
                            }
                        } else
                            // 從抽牌區飛入其他人手牌中
                            this._drawCardLayer.runDrawCardAnim(this._drawSit, null, isFinish);

                    }, this),
                    cc.delayTime(0.35)
                ), times));
            }
        } else if (this._drawType === Cangkulan_CardType.FOLD) {
            // 從棄牌區飛入手牌

            // 播放抽牌音效
            MusicUtility.playEffect("Music/Effect/cangkulan_playCard.mp3");

            var drawCard = cardsArray[0];

            var handPos = null;
            if (this._isTurnMe) {
                // 自己
                var obj = {
                    card: drawCard,
                    isFold: true,
                    isDraw: true
                };
                // 放入手牌中並找出在手牌的位置
                handPos = this._handCardsLayer.getDrawCardPosByHandCard(obj);
            }

            // 其他玩家
            this._foldCardLayer.runFoldFlyCardAnim(this._drawSit, Cangkulan_FoldCardLayer.FLY_TYPE.FOLD_TO_HAND, drawCard, handPos, this._foldShowCard);
        }
    },

    /**
     * 表演棄牌的動畫
     * @param pos
     * @param foldCard
     */
    runFoldCardAnim: function (pos, foldCard, isHaveFoldSuit) {

        // 播放放牌音效
        MusicUtility.playEffect("Music/Effect/cangkulan_playCard.mp3");

        // 該輪第一個棄牌玩家要塞入之後玩家要棄牌的指定花色
        if (!isHaveFoldSuit)
            this.setFoldSuit(foldCard);

        var obj = {
            sit: pos,
            card: foldCard,
            isSelf: this._isTurnMe
        };

        if (this._isTurnMe) {
            // 自己手牌飛入棄牌區 調整一下層級 不然會被蓋在下面
            this._foldCardLayer.setLocalZOrder(1);
            this._handCardsLayer.setLocalZOrder(2);
            this._handCardsLayer.foldCard(foldCard)
                .then(() => {
                    if (this.__isDestroyed)
                        return;

                    this._foldCardLayer.showFoldCard(foldCard);
                    this._foldCardLayer.setLocalZOrder(2);
                    this._handCardsLayer.setLocalZOrder(1);

                    GS.dispatchCustomEvent("NotifyEnableProcessMessage");
                    GS.dispatchCustomEvent("NotifyFoldPlayerHandCard", obj);
                });
        } else {
            // 其他玩家手牌飛入棄牌區
            this._foldCardLayer.runFoldFlyCardAnim(pos, Cangkulan_FoldCardLayer.FLY_TYPE.HAND_TO_FOLD, foldCard);
            GS.dispatchCustomEvent("NotifyFoldPlayerHandCard", obj);
        }
    },

    /**
     * 牌局重現
     * @param jsonObj
     */
    cmd_current_playing: function (jsonObj) {

        this._drawCardLayer.clean();
        this._foldCardLayer.clean();
        this._handCardsLayer.clean();

        this.setFinishAnimationMode(false);

        // 自己手牌部份要先處理 這樣計牌器才是對的
        var handCardString = jsonObj["handCard"] || "";
        if (handCardString.length) {
            // 設定自己有在玩
            this._selfPlaying = true;

            // 是自己
            var handCards = handCardString.match(REGEXP_TWO_NUMBERS);
            this._handCardsLayer.addCardByCards(handCards);

            // 有自己 把自動代打拿掉
            DataProcess.sendString("game_autoplay 0");

            GS.dispatchCustomEvent("NotifyGameDealDone");
        }

        // 棄牌的指定花色
        var roundFold = jsonObj["roundDrop"] || [];
        var foldIndex = roundFold.findIndex((cur) => cur !== "");
        var foldCard = (foldIndex > -1) ? roundFold[foldIndex] : null;
        this.setFoldSuit(foldCard);

        var actionBtn = jsonObj["actionBtn"];
        if (actionBtn)
            this.cmd_action_btn(actionBtn);

        // 抽牌區剩餘的牌
        var drawCount = JSCodeUtility.getIntValue(jsonObj["cardListNum"]);
        if (drawCount > 0) {
            this._drawCardLayer.setDrawCount(drawCount);
            this._drawCardLayer.showDrawCards(Cangkulan_Offset.DRAW, drawCount);
        }

        // 棄牌堆的數量
        var foldCount = JSCodeUtility.getIntValue(jsonObj["topLength"]);
        // 棄牌區目前的牌
        var foldCard = JSCodeUtility.getStringValue(jsonObj["topDrop"]);

        if (foldCard)
            this._foldCardLayer.setCurrentFoldCard(foldCard, foldCount);
        else
            this._foldCardLayer.showFoldSp();
    },


    /**
     * 抽牌狀態
     * @param status
     */
    cmd_action_btn: function (status) {
        // 可棄牌
        this._handCardsLayer.setHandCardStatus(status[0], status[1]);
    },

    /**
     * 通知顯示手牌
     */
    notifyShowHandCards: function (event) {
        if (event && event.getUserData())
            this._handCardsLayer.addCard(event.getUserData());
    },

    /**
     * 通知顯示抽牌區
     */
    notifyShowDrawCards: function () {
        this._drawCardLayer.showDrawCards();
    },

    /**
     * 通知手牌飛入棄牌區
     */
    notifyFoldHandCard: function () {
        var foldCard = this._handCardsLayer.getFoldCard();
        if (foldCard) {
            this._handCardsLayer.setTouch(false);
            DataProcess.sendString("drop " + foldCard);

            // AppsFlyer 埋點
            GameAppsFlyerTracker.trackFirstClickType(GameAppsFlyerTrackerEnum.DEFAULT);

            // Firebase 埋點
            var eventName = GSAnalyticsAdapter.record.game + "遊戲行為";
            GSAnalyticsAdapter.logEventByFirebaseAll(eventName, ["牌桌"], ["Cangkulan出牌"]);
        }
    }
});