/**
 *  好友聊天室
 */

// 聊天室開啟的頁面Enum
var ChatRoomPageType = {
    ROOM_LIST: 1,   // 聊天室清單
    CHAT: 2,        // 聊天頁面
    GUILD: 3,       // 公會頁面
    NOTIFY: 4       // 通知頁面
};

// 從哪邊開啟好友聊天視窗Enum
var ChatRoomFromType = {
    GAME: 1,        // 遊戲內
    LOBBY: 2,       // 大廳
    FRIEND_LIST: 3  // 好友清單
};

// 聊天cell狀態Enum 改變cell樣式
var ChatCellType = {
    NORMAL: 1,      // 一般狀態
    DELETE: 2       // 刪除狀態
};

var ChatRoomLayer = cc.Layer.extend({
    ctor: function (from, page, isGameGaple) {
        this._super();

        // 從哪邊開啟聊天室
        this._fromType = from;

        // 開啟聊天室的頁面
        this.chatRoomType = page;
        this._pageArray = [];

        // 是不是Gaple牌桌
        this._isGameGaple = isGameGaple;

        // 外框漸層的大小
        var layerGradientHeight = 20;
        var width = ChatRoomLayer.WIDTH;
        var height = JSVisibleSize.height;

        // 動畫移動的時間
        this._moveTime = 0.2;
        // 預設是關閉
        this._isOpen = false;
        // 開關動畫是否進行中
        this._isPlaying = false;
        // 設定顯示和關閉座標
        this._showPosition = cc.p(-2 + JSScreenSafeWidth, -3);
        this._closePosition = cc.p(-width - layerGradientHeight, -2);
        // 點擊範圍
        this._boundBox = cc.rect( -2 + JSScreenSafeWidth, 0, width, JSVisibleSize.height);

        // 主要的畫面都加在這裡 因為移動動畫
        var mainNode = this._mainNode = new cc.Node();
        mainNode.setPosition(-width, 0);
        this.addChild(mainNode);

        if (this._isGameGaple) {
            // 內容背景
            var contentBgSprite = new ccui.Scale9Sprite("gaple_pic_frame_01.png");
            contentBgSprite.setPreferredSize(cc.size(204, 200));
            contentBgSprite.setPosition(101, 134);
            mainNode.addChild(contentBgSprite);

            this._boundBox = cc.rect(-2 + JSScreenSafeWidth, 36 + JSScreenBonusHalfHeight, 200, 190);
            this._showPosition = cc.p(-2 + JSScreenSafeWidth, -3 + JSScreenBonusHalfHeight);
            this._closePosition = cc.p(-width - layerGradientHeight, -2 + JSScreenBonusHalfHeight);
            mainNode.setPosition(-width, 0 + JSScreenBonusHalfHeight);
        } else {
            // 背景外框漸層
            var layerGradient = new cc.LayerGradient(cc.color(0, 0, 0, 150), cc.color(0, 0, 0, 0));
            layerGradient.setContentSize(height, layerGradientHeight);
            layerGradient.setAnchorPoint(0, 0);
            layerGradient.setRotation(-90);
            layerGradient.setPosition(width + layerGradientHeight, 3);
            mainNode.addChild(layerGradient);

            // 背景
            this._actualTotalViewSize = cc.size(width + 4, height + 6); // Scale9Sprite放大後會有點偏差
            var bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
            bgSprite.setPreferredSize(this._actualTotalViewSize);
            bgSprite.setAnchorPoint(0, 0);
            mainNode.addChild(bgSprite);

            // 內容背景
            var contentSize = cc.size(width - 6, height - 33);
            var contentBgSprite = new ccui.Scale9Sprite("chat_bg_top.png");
            contentBgSprite.setCapInsets(cc.rect(0, 3, 30, 37));
            contentBgSprite.setPreferredSize(contentSize);
            contentBgSprite.setAnchorPoint(0.5, 1);
            contentBgSprite.setPosition(this._actualTotalViewSize.width / 2, height - 28);
            mainNode.addChild(contentBgSprite);
        }
        
        // 隱藏在畫面左邊＆看不到
        this.setVisible(false);

        // 展開動畫
        this.openChatRoom();

        // 監聽
        GS.addListener("NotifyShowChatRoomLayerByPageType", this.notifyShowChatRoomLayerByPageType.bind(this), this);
        GS.addListener("NotifyCloseChatRoomLayer", this.notifyCloseChatRoomLayer.bind(this), this);

        // 加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this._onTouchBegan.bind(this),
        }, this);
    },

    /**
     * 開啟聊天頁面
     */
    openChatPage: function () {
        this.chatRoomType = ChatRoomPageType.CHAT;
        this.openChatRoom();
    },

    /**
     * 開啟畫面 從側邊滑入
     */
    openChatRoom: function () {
        if (this._isPlaying || this._isOpen)
            return;

        // 設置成打開
        this._isOpen = true;

        // 動畫進行中
        this._isPlaying = true;

        // 打開介面
        this.setVisible(true);

        // 刷新開啟的頁面
        this._refreshView();

        // 開啟的動畫
        this._mainNode.runAction(cc.sequence(
            cc.moveTo(this._moveTime, this._showPosition).easing(cc.easeIn(2)),
            cc.callFunc(function () {
                this._isPlaying = false;
            }, this)
        ));
    },

    /**
     *關閉畫面 從畫面中滑出
     */
    closeChatRoomLayer: function () {
        if (this._isPlaying || !this._isOpen)
            return;

        this._isOpen = false;

        // 動畫進行中
        this._isPlaying = true;

        this._mainNode.stopAllActions();
        this._mainNode.runAction(cc.sequence(
            cc.moveTo(this._moveTime, this._closePosition).easing(cc.easeIn(2)),
            cc.callFunc(function () {
                this.setVisible(false);
                this._isPlaying = false;
                // 確認聊天icon的紅點
                DataModal.chatRoomData.checkChatIconRedPoint();
            }, this)
        ));
    },

    /**
     * 更新頁面
     * @private
     */
    _refreshView: function () {
        var page = this._pageArray;
        page.forEach(cur => {
            cur.setVisible(false);
        });

        var type = this.chatRoomType;

        // 每次都重新判斷看有沒有公會 免得聊天室還在公會 按下退出後沒來得及刷新
        if (!DataModal.guildData.haveGuild && type === ChatRoomPageType.GUILD)
            type = ChatRoomPageType.ROOM_LIST;

        var thisPage = page[type];

        if (thisPage) {
            thisPage.setVisible(true);
            thisPage.refreshView();
        } else {
            switch (type) {
                case ChatRoomPageType.CHAT:
                    // 開啟聊天頁面
                    thisPage = page[type] = new FriendChatLayer(this._isGameGaple);
                    this._mainNode.addChild(thisPage);
                    break;
                case ChatRoomPageType.ROOM_LIST:
                    // 開啟聊天清單頁面
                    thisPage = page[type] = new ChatRoomListLayer(this._fromType, this._isGameGaple);
                    this._mainNode.addChild(thisPage);
                    break;
                case ChatRoomPageType.GUILD:
                    // 開啟公會聊天頁面
                    thisPage = page[type] = new GuildChatLayer(this._isGameGaple);
                    this._mainNode.addChild(thisPage);
                    break;
                case ChatRoomPageType.NOTIFY:
                    // 開啟優惠通知頁面
                    thisPage = page[type] = new DiscountNotifyChatLayer();
                    this._mainNode.addChild(thisPage);
                    break;
                default:
                    break;
            }
        }
    },

    /**
     * touch點擊
     * 點擊非聊天室會關閉視窗
     */
    _onTouchBegan: function (touch, event) {
        var target = event.getCurrentTarget();
        if (!target.isVisible())
            return false;

        for (var c = target.parent; c != null; c = c.parent) {
            if (!c.isVisible())
                return false;
        }

        if (!cc.rectContainsPoint(this._boundBox, this.convertToNodeSpace(touch.getLocation()))) {
            // 不是點到聊天室 關閉視窗
            this.closeChatRoomLayer();

            // 開啟聊天時關閉畫面要送離開聊天室給server
            var chatLayer = this._pageArray[ChatRoomPageType.CHAT];
            if (chatLayer && chatLayer.isVisible())
                DataModal.chatRoomData.sendHaveReadCmd(0);
        }
        return true;
    },

    /**
     * 通知切換頁面
     * type:     ChatRoomPageType
     * UID:      聊天對象的uid
     * userid:   聊天對象的userID
     * nickname: 聊天對象的暱稱
     */
    notifyShowChatRoomLayerByPageType: function (event) {
        if (event && event.getUserData()) {
            var param = event.getUserData();
            var type = this.chatRoomType = param.type;
            // 聊天頁面要先設定聊天好友的UID & userID
            if (type === ChatRoomPageType.CHAT) {
                DataModal.chatRoomData.checkHaveChatList(param.UID, param.userID, param.nickname);
            }
            this._refreshView();
        }

    },

    /**
     * 通知關閉聊天
     */
    notifyCloseChatRoomLayer: function () {
        this.closeChatRoomLayer();
    }
});

// 聊天室的尺寸
ChatRoomLayer.WIDTH = 184;

// Gaple牌桌聊天室的尺寸
ChatRoomLayer.GAPLE_HEIGHT = 200;
ChatRoomLayer.GAPLE_WIDTH = 204;