/**
 * 配件畫面的Node
 */

var AccessoryItemNode = cc.Node.extend({
    ctor: function (num, width, height, callback, isFourceUsePic = false) {
        this._super();

        this.setCascadeColorEnabled(true);
        this.setCascadeOpacityEnabled(true);

        this._width = width || 32;          // 寬
        this._height = height || 32;        // 高
        this._callback = callback;          // 讀取完的callback
        this._isFourceUsePic = isFourceUsePic;       // 設定是否強制使用靜態圖

        this.setItemNumber(num);
    },

    onExit: function () {
        // 防止Native Node被砍掉了圖片還在下載, 下載完的callback回來會爛掉
        this._callback = null;
        // 防止Native Node被砍掉了圖片還在下載
        this._isDestroyed = true;

        this._super();
    },

    //檢查編號是否要用GAF還是用圖片
    _checkNumberNeedUsePic: function (num) {
        // 預設是讀GAF
        var needUseGAF = true;
        if (needUseGAF) {
            // 判斷這些編號是否需要用GAF
            if (num >= 6074 && num <= 7000)             // 比賽券
                needUseGAF = false;
            else if (num >= 8000 && num < 9000)         // 勳章
                needUseGAF = false;
            else if (num >= 18000 && num < 19000)       // 互動道具
                needUseGAF = false;
            else if (num >= 19000 && num < 20000)       // 禮包
                needUseGAF = false;
        }
        return needUseGAF;
    },

    //設定item的號碼
    setItemNumber: function (num) {
        // 先判斷是否可以使用GAF
        var needUseGAF = this._checkNumberNeedUsePic(num);

        // 清掉之前的東西
        this.removeAllChildren();

        // 沒有數字 跳掉
        if (!num)
            return;

        if (needUseGAF && !this._isFourceUsePic) {
            // 用GAF的圖片
            var url = ShopItemGAFBaseUrl + num + ".zip";
            var entryFile = JSStringUtility.format("%d/%d.gaf", num, num);
            var saveFileName = JSStringUtility.format("%sshop/%d.zip", JSWriteablePath, num);
            gaf.createAndDownloadWithBundle(url, saveFileName, entryFile, this, (gafAsset) => {
                if (!gafAsset || this.__isDestroyed)
                    return;

                var gafObject = gafAsset.createObjectAndRun(true);
                gafObject.setScaleX(this._width / 64);
                gafObject.setScaleY(this._height / 64);
                this.addChild(gafObject);

                // 讀完callback回去
                this._callback && this._callback(this);
            });
        } else {
            // 用一般的圖片
            var url = ShopItemBaseUrl + num + ".png";
            var saveFileName = JSStringUtility.format("%sshop/%d.png", JSWriteablePath, num);
            var imageSprite = new GSDownloadSprite("", url, saveFileName, () => {
                if (this._isDestroyed)
                    return;

                this._callback && this._callback(this);
            });
            imageSprite.setTargetSize(cc.size(this._width, this._height));
            this.addChild(imageSprite);
        }
    },
});