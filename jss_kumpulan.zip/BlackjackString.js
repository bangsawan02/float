var LocalizedString = LocalizedString || {};

(function () {
    var keyValue = {
        "五　龍：持牌達五張": "5 naga (memiliki 5 kartu)",
        "７７７：持牌達三張７": "7-7-7 (memiliki triple 7)",
        "同花順：持牌同花６７８": "Straight Flush (6-7-8 sama bunga)",
        "→　1 賠 3": "-> 3:1",
        "→　1 賠 10": "-> 10:1",
        "→　1 賠 15": "-> 15:1",
        "清除": "Clear",
        "發牌": "Bagi Kartu",
        "加倍": "Double",
        "補牌": "Hit",
        "不補牌": "Stand",
        "小注桌": "Kecil",
        "大注桌": "Besar",
        "爆牌": "Bust",
        "輸牌": "Kalah",
        "BLACKJACK": "BLACKJACK",
        "請下注": "Taruh Bet",
        "恢復未完成牌局中": "Game terakhir belum selesai\nsedang memuat kembali",
        "左右滑動可選擇投注額哦!": "Geser ke kanan atau ke kiri untuk pilih bet",
    };

    LocalizedString.Blackjack = function (str) {
        return USE_i18n ? (keyValue[str] || str) : str;
    };
})();
