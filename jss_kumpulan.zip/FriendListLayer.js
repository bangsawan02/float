/**
 * 好友清單
 */
var FriendListLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 好友清單
        this._friendList = [];
        // 搜尋好友結果清單
        this._searchFriendList = [];

        // 還有沒有好友可以load
        this._isCanLoadFriend = false;

        // 能不能滑動
        this._isCanScroll = true;

        // 正在顯示搜尋好友
        this._isShowSearchMode = false;

        this._beforeHeight = 0;

        // 列表
        var tableWidth = this._tableWidth = FriendLayer.WIDTH;
        var tableHeight = JSVisibleSize.height - TITLE_BG_HEIGHT - 26;
        var mainLayer = this._mainLayer = new cc.Layer();
        var tableView = this._tableView = new cc.TableView(this, cc.size(tableWidth, tableHeight), mainLayer);
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setPosition(115 + JSScreenBonusHalfWidth, 0);
        this.addChild(tableView);

        // 擋tableView 上方的touch
        var dummyTouch = new DummyTouchLayer(cc.size(tableWidth, 50));
        dummyTouch.setPosition(115 + JSScreenBonusHalfWidth, tableHeight);
        this.addChild(dummyTouch);

        // 標題 好友數量
        var friendCount = this._friendCount = new cc.LabelTTF("", JSFontBoldName, 12);
        friendCount.setAnchorPoint(0, 0.5);
        friendCount.setPosition(128 + JSScreenBonusHalfWidth, JSVisibleSize.height - TITLE_BG_HEIGHT - 13);
        this.addChild(friendCount);

        // 輸入搜尋的EditBox
        var editBoxSize = cc.size(120, 20);
        var editBoxSprite1 = new ccui.Scale9Sprite("select_03.png");
        var editBoxSprite2 = new ccui.Scale9Sprite("select_03.png");
        editBoxSprite2.setColor(JSColor.GRAY);
        var inputEditBox = this._inputEditBox = new cc.EditBox(editBoxSize, editBoxSprite1, editBoxSprite2);
        inputEditBox.setAnchorPoint(1, 0.5);
        inputEditBox.setPosition(473 + JSScreenBonusHalfWidth, 236.5 + JSScreenBonusHeight);
        inputEditBox.setFontColor(JSColor.BLACK);
        inputEditBox.setFontName(JSFontName);
        inputEditBox.setPlaceHolder(LocalizedString.Friend("輸入ID搜尋好友"));
        inputEditBox.setPlaceholderFontName(JSFontName);
        inputEditBox.setPlaceholderFontSize(9);
        inputEditBox.setReturnType(cc.KEYBOARD_RETURNTYPE_DONE);
        inputEditBox.setInputFlag(cc.EDITBOX_INPUT_FLAG_SENSITIVE);
        inputEditBox.setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE);
        inputEditBox.setDelegate(this);
        inputEditBox.setCascadeOpacityEnabled(true);
        this.addChild(inputEditBox);

        // 搜尋框清除按鈕
        var searchBoxClearBtn = this._searchBoxClearBtn = ButtonUtility.createSimpleImageButton("friend_btn_ x_01.png", undefined);
        searchBoxClearBtn.setVisible(false);
        searchBoxClearBtn.addTouchUpInsideAction(this._searchBoxClearBtnClicked, this);
        searchBoxClearBtn.setPosition(463 + JSScreenBonusHalfWidth, JSVisibleSize.height - TITLE_BG_HEIGHT - 14);
        this.addChild(searchBoxClearBtn);

        // 搜尋按鈕
        var searchBtn = ButtonUtility.createSimpleImageButton("lobby_btn_07.png", cc.size(20, 20), "#lobby_icon_search.png");
        searchBtn.wordImage.setScale(0.75);
        searchBtn.addTouchUpInsideAction(this._searchBtnClicked, this);
        searchBtn.setPosition(485 + JSScreenBonusHalfWidth, JSVisibleSize.height - TITLE_BG_HEIGHT - 14);
        this.addChild(searchBtn);

        // 提示訊息
        var msgLabel = this._msgLabel = new cc.LabelTTF("", JSFontBoldName, 12);
        msgLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        msgLabel.setPosition(315 + JSScreenBonusHalfWidth, 122 + JSScreenBonusHalfHeight);
        this.addChild(msgLabel);

        // 加一個Loading
        var loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(cc.pAdd(tableView.getPosition(), cc.p(tableWidth / 2, tableHeight / 2)));
        loadingSprite.start();
        this.addChild(loadingSprite);

        // 5.6.2先拔掉fb功能
        // // facebook登入要去要fb的好友
        // if (GS.isLuxyPoker && DataModal.loginData.loginType === LoginType.Facebook) {
        //     var fbToken = GSFacebookHelper.getToken();
        //     if (fbToken && fbToken.length)
        //         DataProcess.sendString("get_friend_fb_list " + fbToken);
        // } else {
        //     // 跟server要第一頁的好友列表
        //     DataModal.friendData.sendFriendListCmd(0);
        // }

        // 跟server要第一頁的好友列表
        DataModal.friendData.sendFriendListCmd(0);

        // 監聽
        GS.addListener("NotifyFriendListDone", this.notifyFriendListDone.bind(this), this);
        GS.addListener("NotifyFriendChangeDone", this.notifyFriendChangeDone.bind(this), this);
        GS.addListener("NotifyUpdateFriendListCount", this.notifyUpdateFriendListCount.bind(this), this);
    },

    /**
     * @override
     * 從其他頁籤回來時，頁面要顯示所有好友
     */
    setVisible: function (visible) {
        this._super(visible);

        // 清空搜尋相關內容
        this._inputEditBox && this._inputEditBox.setString("");
        this._searchBoxClearBtn && this._searchBoxClearBtn.setVisible(false);

        // 重置搜尋狀態，顯示所有好友畫面
        if (this._isShowSearchMode && visible) {
            this._refreshView();
        }
    },

    /**
     * 更新畫面
     */
    _refreshView: function () {
        // 把Loading拿掉
        this._loadingSprite.stop();
        this._tableView.setTouchEnabled(true);

        // 原本在搜尋好友狀態，重置搜尋相關內容
        if (this._isShowSearchMode) {
            this._isShowSearchMode = false;
            this._inputEditBox.setString("");
            this._searchBoxClearBtn.setVisible(false);
        }

        var data = DataModal.friendData;

        if (!data)
            return;

        var friendList = this._friendList = data.friendList;

        // 是否還可以在load出好友資料
        this._isCanLoadFriend = data.isCanLoadFriend;

        var friendListLen = this._totalCellCount = friendList.length;

        if (friendListLen > 0) {
            // 有好友要把找好友訊息關閉
            if (this._noFriendNode)
                this._noFriendNode.setVisible(false);
        } else
            // 沒有好友時要show找好友的訊息
            this._showFindFriendMsg();

        this._tableView.reloadData(true);

        // 滑動到之前的位置上
        if (this._beforeHeight > 0) {
            var height = this._beforeHeight - this._tableView.getContainer().height;
            this._tableView.setContentOffset(cc.p(0, height));
        }

        this._isCanScroll = true;
        this._beforeHeight = 0;
    },

    /**
     * 顯示好友搜尋結果
     * @param resultList 好友搜尋結果列表
     */
    _showSearchFriendResult: function (resultList) {
        if (this._inputEditBox.isFocused())
            this._inputEditBox.closeKeyboard();

        // 改為顯示好友搜尋狀態
        this._isShowSearchMode = true;

        var friendList = this._searchFriendList = resultList;
        this._totalCellCount = friendList.length;

        this._tableView.reloadData(true);
    },

    /**
     * show沒有好友的提示
     */
    _showFindFriendMsg: function () {
        if (this._noFriendNode) {
            this._noFriendNode.setVisible(true);
            return;
        }

        var noFriendNode = this._noFriendNode = new cc.Node();
        this.addChild(noFriendNode, 2);

        var mainMenu = new cc.Menu();
        mainMenu.setPosition(0, 0);
        noFriendNode.addChild(mainMenu);

        // msg
        var noFriendLabel = new cc.LabelTTF(LocalizedString.Friend("目前還沒有好友哦，快去玩遊戲交朋友吧!"), JSFontBoldName, 12);
        noFriendLabel.setPosition(307 + JSScreenBonusHalfWidth, 157 + JSScreenBonusHalfHeight);
        noFriendLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        noFriendNode.addChild(noFriendLabel);

        // 找好友
        var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", cc.size(108, 30), LocalizedString.Friend("找好友"), 10, JSColor.BLACK);
        var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._findFriendItemClicked, this);
        menuItem.setPosition(312 + JSScreenBonusHalfWidth, 91 + JSScreenBonusHalfHeight);
        mainMenu.addChild(menuItem);
    },

    /**
     * TableView delegate
     */
    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        if (cell == null) {
            cell = new FriendListCell();
            cell.setAnchorPoint(cc.p(0, 0));
        }
        cell.refreshCell((this._isShowSearchMode) ? this._searchFriendList[idx] : this._friendList[idx]);

        return cell;
    },

    numberOfCellsInTableView: function (table) {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function (table, idx) {
        return cc.size(this._tableWidth, FriendListCell.HEIGHT);
    },

    scrollViewDidScroll: function (view) {
        // 顯示所有好友時，往下滑要load新的好友資料
        if (!this._isShowSearchMode && this._isCanScroll && this._isCanLoadFriend && view.getContentOffset().y > 10) {
            // 卡loading TODO: 要改成新loading
            GSLoading.addLoadingView();

            // 跟server要下一頁的好友列表
            this._tableView.setTouchEnabled(false);
            DataModal.friendData.sendFriendListCmd(DataModal.friendData.friendListPage);
            this._isCanScroll = false;
            this._beforeHeight = this._tableView.getContainer().height;
        }
    },

    /**
     * EditBox Delegate
     */
    editBoxEditingDidBegin: function (sender) {
        // 輸入中 先把清除鈕關掉
        this._searchBoxClearBtn.setVisible(false);

        // 擋一層touch 因為ios開鍵盤比較慢 在開完之前用來擋不能點擊其他按鈕
        if (!this._dummyTouchLayer) {
            var dummyTouchLayer = this._dummyTouchLayer = new DummyTouchLayer(JSVisibleSize);
            this.addChild(dummyTouchLayer, 10);

            // 放個提示給ios模擬器使用者
            if (JSDebugMode && cc.sys.os === cc.sys.OS_IOS) {
                var hintLabel = new cc.LabelTTF("這裡有一層dummyTouch擋著\n使用ios模擬器需要把模擬器小鍵盤打開", JSFontBoldName, 12);
                hintLabel.setFontFillColor(JSColor.RED);
                hintLabel.setPosition(JSScreenMidPos.x, JSVisibleSize.height - 100);
                dummyTouchLayer.addChild(hintLabel);

                var blackLayer = new cc.LayerColor(cc.color(0, 0, 0, 255), hintLabel.getContentSize().width + 6, 40);
                blackLayer.setPosition(JSScreenMidPos.x - hintLabel.getContentSize().width / 2 - 3, JSVisibleSize.height - 120);
                dummyTouchLayer.addChild(blackLayer, -1);
            }
        }
        this._dummyTouchLayer.setVisible(true);
    },

    editBoxEditingDidEnd: function (sender) {
        // 搜尋框有文字，顯示清除鈕
        this._searchBoxClearBtn.setVisible(this._inputEditBox.getString().length > 0);
        this._dummyTouchLayer && this._dummyTouchLayer.setVisible(false);
    },

    editBoxTextChanged: function (sender, text) {
        this._dummyTouchLayer && this._dummyTouchLayer.setVisible(false);
    },

    /**
     * 點擊找好友
     */
    _findFriendItemClicked: function () {
        if (this._inputEditBox.isFocused())
            this._inputEditBox.closeKeyboard();

        GS.dispatchCustomEvent("NotifyShowFindFriendTab");
    },

    /**
     *  點擊搜尋
     */
    _searchBtnClicked: function (sender) {
        if (this._inputEditBox.isFocused())
            this._inputEditBox.closeKeyboard();

        var inputStr = this._inputEditBox.getString();
        // 至少要兩個字元
        if (inputStr.length < 2) {
            // 跳提示-請輸入兩個字以上
            GS.dispatchCustomEvent("NotifyFriendLayerShowHintNode", {msg: LocalizedString.Friend("請輸入兩個字以上")});
        } else {
            // 拿搜尋結果列表
            var searchFriendList = DataModal.friendData.getSearchFriendList(inputStr);
            if (searchFriendList.length > 0) {
                // 有結果，更新頁面
                this._showSearchFriendResult(searchFriendList);
            } else {
                // 沒結果，到主頁面跳提示
                GS.dispatchCustomEvent("NotifyFriendLayerShowHintNode", {msg: LocalizedString.Friend("查無結果，請重新輸入")});
            }
        }

        // 埋點 2:點擊搜尋按鈕
        DataProcess.sendString("track_mixFriend 2");
    },

    /**
     *  點擊清除搜尋框
     */
    _searchBoxClearBtnClicked: function (sender) {
        sender.setVisible(false);

        if (this._inputEditBox.isFocused())
            this._inputEditBox.closeKeyboard();

        // 清空搜尋框
        this._inputEditBox.setString("");

        // 顯示搜尋結果時，改為顯示所有好友
        if (this._isShowSearchMode) {
            this._refreshView();
        }

        // 埋點 3:點擊X按鈕
        DataProcess.sendString("track_mixFriend 3");
    },


    /**
     * 通知刷新介面
     */
    notifyFriendListDone: function () {
        this._refreshView();
        GSLoading.removeLoadingView();
    },

    /**
     * 通知好友清單有變更
     */
    notifyFriendChangeDone: function (event) {
        GSLoading.removeLoadingView();

        if (event) {
            var param = event.getUserData();
            var localStr = LocalizedString.Friend;
            if (param.isSuccess) {
                // 刪除成功
                this._refreshView();

                if (!this._hintMsgNode) {
                    var hintMsgNode = this._hintMsgNode = new FriendHintNode();
                    hintMsgNode.setPosition(JSScreenMidPos);
                    this.addChild(hintMsgNode, 100);
                }
                this._hintMsgNode.showHint(localStr("已成功刪除"));
            } else {
                // 刪除失敗 跳Dialog
                var obj = {
                    key: "FriendChangeFail",
                    msg: localStr("系統異常，將為您重新整理"),
                    button: [localStr("確定")],
                    cb: () => {
                        // 卡loading TODO: 要改成新loading
                        GSLoading.addLoadingView();
                        DataModal.friendData.sendFriendListCmd(0);
                    }
                };
                DialogManager.addDialog(new FrameDialog(obj), false);
            }
        }
    },

    /**
     * 通知更新好友數量
     */
    notifyUpdateFriendListCount: function () {
        var data = DataModal.friendData;
        var str = LocalizedString.Friend("好友清單(%d/%d)");
        var friendLimit = data.friendLimit;
        var friendCount = data.friendCount;
        var topStr = (friendCount > 0) ? JSStringUtility.format(str, friendCount, friendLimit) : "";
        this._friendCount.setString(topStr);

        // 是否還可以在load出好友資料
        this._isCanLoadFriend = data.isCanLoadFriend;
    }
});