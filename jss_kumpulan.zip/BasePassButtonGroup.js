/**
 * 通行證 - 按鈕群
 * config: {
 *     buttonGroupPosition: cc.p(JSScreenMidPos.x, 38 + JSScreenBonusHalfHeight),  // 按鈕群位置
 *     buttonGroupAlignment: BasePassButtonGroup.Alignment.HORIZONTAL,             // 按鈕群對齊方式
 *     claimAllBtnText: "",                                                        // 全部領獎按鈕文字
 *     claimAllBtnStyle: Texas_Button.Style.COMMON_BLUE,                           // 全部領獎按鈕樣式
 *     playNowBtnText: "",                                                         // 馬上玩按鈕文字
 *     playNowBtnStyle: Texas_Button.Style.COMMON_BLUE,                            // 馬上玩按鈕樣式
 *     ticketIconFileName: "",                                                     // 票券圖檔
 *     isBuyLevelEnable: false,                                                    // 是否啟用買等級按鈕
 * }
 *
 * @param {object}  config
 * @param {cc.p}    config.buttonGroupPosition  按鈕群位置
 * @param {string}  config.buttonGroupAlignment 按鈕群對齊方式
 * @param {boolean} config.isOrderButtonGroupReverse  按鈕順序是否反轉
 * @param {string}  config.claimAllBtnText      全部領獎按鈕文字
 * @param {string}  config.claimAllBtnStyle     全部領獎按鈕樣式
 * @param {string}  config.playNowBtnText       馬上玩按鈕文字
 * @param {string}  config.playNowBtnStyle      馬上玩按鈕樣式
 * @param {string}  config.ticketIconFileName   票券圖檔
 * @param {boolean} config.isBuyLevelEnable     是否啟用買等級按鈕
 *
 * @property {BasePassClaimButton}  claimAllButton  全部領獎按鈕
 * @property {Texas_Button}         playNowButton   馬上玩按鈕
 * @property {purchaseButton}       purchaseButton  儲值按鈕
 * @property {Texas_Button}         buyLevelButton  買等級按鈕
 */
var BasePassButtonGroup = cc.Node.extend({
    ctor: function (config) {
        this._super();

        // 按鈕群對齊方式
        this._alignment = config.buttonGroupAlignment || BasePassButtonGroup.Alignment.HORIZONTAL;

        let isHorizontal = this._alignment === BasePassButtonGroup.Alignment.HORIZONTAL;

        // 是否反轉順序（truth table）
        // isHorizontal | isOrderButtonGroupReverse | result | notes
        //         true |          false            | false  | 水平不反轉
        //         true |           true            |  true  | 水平反轉
        //        false |          false            |  true  | 垂直不反轉（垂直預設是反轉的，因此是 !isOrderButtonGroupReverse）
        //        false |           true            | false  | 垂直反轉（垂直預設是反轉的，因此是 !isOrderButtonGroupReverse）
        const isOrderButtonGroupReverse = !!config.isOrderButtonGroupReverse === isHorizontal;

        let autoLayout = this._autoLayout = new GSAutoLayoutNode();
        autoLayout.setType(isHorizontal ? GSAutoLayout.TYPE.HORIZONTAL : GSAutoLayout.TYPE.VERTICAL);
        autoLayout.setDirection(isOrderButtonGroupReverse ? GSAutoLayout.DIRECTION.REVERSE : GSAutoLayout.DIRECTION.NORMAL);
        autoLayout.setSpace(isHorizontal ? 75 : 0);
        this.addChild(autoLayout);

        // 儲值按鈕
        let purchaseButton = this.purchaseButton = new BasePassPurchaseButton(config);
        purchaseButton.setVisible(false);
        autoLayout.addChild(purchaseButton);

        if (config.isBuyLevelEnabled) {
            // 買等級按鈕
            let buyLevelButton = this.buyLevelButton = new Texas_Button(Texas_Button.Style.ORANGE, cc.size(110, 39), LocalizedString.LuxyPass("購買等級"));
            buyLevelButton.setVisible(false);
            autoLayout.addChild(buyLevelButton);
        }

        // 全部領獎按鈕
        let claimButton = this.claimAllButton = new BasePassClaimButton(config);
        claimButton.setVisible(false);
        autoLayout.addChild(claimButton);

        // 馬上玩按鈕
        let playNowText = config.playNowBtnText || LocalizedString.BasePass("馬上玩");
        let playNowBtnStyle = config.playNowBtnStyle ? config.playNowBtnStyle : (config.isUseOldBtnStyle ? Texas_Button.Style.COMMON_BLUE : Texas_Button.Style.BLUE);
        let playNowBtn = this.playNowButton = new Texas_Button(playNowBtnStyle, cc.size(110, 38), playNowText);
        playNowBtn.setChangeColorWhenDisabled(false);
        playNowBtn.setChangeOpacityWhenDisabled(false);
        playNowBtn.setVisible(false);
        autoLayout.addChild(playNowBtn);
    },

    /**
     * 更新畫面
     *
     * @param {object}  purchaseParam - 儲值參數
     * @param {boolean} isCompleted - 是否已完成（若有循環獎勵則永遠 false）
     * @param {boolean} isObtainable - 是否可領取
     * @param {boolean} isHavePass - 是否擁有通行證
     * @param {object | null}  options - 其他參數
     * @param {boolean | null} options.isInCycleReward - 是否在循環獎勵中
     * @param {object | null}  options.buyLevelData - 買等級資料（不讀、不使用資料，僅檢查是否有資料）
     */
    refreshView: function (purchaseParam, isCompleted, isObtainable, isHavePass, options = {}) {
        let isInCycleReward = options.isInCycleReward;
        let buyLevelData = options.buyLevelData;

        this.purchaseButton.refreshView(purchaseParam);
        this.purchaseButton.setVisible(purchaseParam && !isHavePass);

        // 全部解完且領獎完
        this.claimAllButton.setVisible(isObtainable);
        this.playNowButton.setVisible(!isCompleted && !isObtainable);

        // 有資料、不在循環獎勵中且有通行證
        this.buyLevelButton && this.buyLevelButton.setVisible(!!buyLevelData && !isInCycleReward && isHavePass);

        this.refreshLayout();
    },

    /**
     * 更新按鈕排版
     */
    refreshLayout: function () {
        if (this.__isDestroyed)
            return;

        this._autoLayout.refresh();

        // 儲值按鈕可視時需播放動畫
        if (this.purchaseButton.isVisible()) {
            this.purchaseButton.playAnimation();
        } else {
            this.purchaseButton.stopAnimation();
        }
    },

    /**
     * 送埋點
     *
     * @param {object}      param
     * @param {int | int[]} param.claimAllBtnTracking 領獎按鈕埋點
     * @param {int | int[]} param.playNowBtnTracking  馬上玩按鈕埋點
     * @param {int}         param.group               分群
     */
    sendTracking: function (param) {
        // 領獎按鈕埋點
        if (this.claimAllButton.isVisible() && param.claimAllBtnTracking) {
            TexasUtility.sendUserAnalyticsTrack(param.claimAllBtnTracking, param.group);
        }

        // 馬上玩按鈕埋點
        if (this.playNowButton.isVisible() && param.playNowBtnTracking) {
            TexasUtility.sendUserAnalyticsTrack(param.playNowBtnTracking, param.group);
        }
    },
});

BasePassButtonGroup.Alignment = GSEnumHelper({
    HORIZONTAL: -1,
    VERTICAL: -1,
});