/**
 * 攜入籌碼的Dialog
 *  param = {
            min: 攜入下限,
            max: 攜入上限,
            money: 身上的金錢,
            sitPos: 目前坐的位置(不一定會有),
            type: BringMoneyDialog.Type
        };
 */

var BringMoneyDialog = BaseDialogLayer.extend({
    ctor: function (param) {
        this._super();

        this.key = "BringMoneyDialog";

        // init data
        var localString = LocalizedString.Game;
        var aniLayer = this._animationLayer;

        var gameData = DataModal.gameData;
        this._isAutoBringInEachRound = gameData.isAutoBringInEachRound;             // 每局補足設定攜入
        this._isAutoBringInWhenZero = gameData.isAutoBringInWhenZero;               // 籌碼爲0時，自動攜入
        this._min = param.min;                                                      // 攜入下限
        this._max = (param.money > param.max) ? param.max : param.money;            // 攜入上限
        this._bringInTime = param.bringInTime ? param.bringInTime : 0;              // 攜入的倒數時間
        this._money = gameData.autoBringInMoney || Math.ceil((this._max - this._min) * 0.5 + this._min);    // 現在的金錢
        if (this._money > this._max)
            this._money = this._max;
        this._sitPos = param.sitPos;                                                // 目前坐的位置
        this._type = param.type;
        this._toggleMenuItems = [];                                                 // 兩個選項按鈕

        // 計算加減單位為最高位下兩位 改用上限來計算
        var count = TexasUtility.howManyZero(this._max);
        var pp = 1;
        for (var i = 0; i < count; i++) {
            pp = pp * 10;
        }
        this.addUnit = Math.floor(pp / 100);

        // 背景底
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(cc.size(380, 230));
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite);

        // 光暈
        var lightSprite = new cc.Sprite("#lobby_pic_pink_light.png");
        lightSprite.setScale(100);
        lightSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(lightSprite);

        // 黑底
        var graySprite = new ccui.Scale9Sprite("game_pic_window_grey.png");
        graySprite.setPreferredSize(cc.size(310, 76));
        graySprite.setPosition(JSScreenMidPos.x, 151 + JSScreenBonusHalfHeight);
        aniLayer.addChild(graySprite);

        // 線
        var lineSprite = new cc.Sprite("#lobby_pic_function_line.png");
        lineSprite.setPosition(JSScreenMidPos.x, 200 + JSScreenBonusHalfHeight);
        lineSprite.setRotation(90);
        lineSprite.setScaleY(9);
        aniLayer.addChild(lineSprite);

        // Title圖片
        var titleLabel = new cc.Sprite("#game_word_01.png");
        titleLabel.setPosition(JSScreenMidPos.x, 231 + JSScreenBonusHalfHeight);
        aniLayer.addChild(titleLabel);

        // 現在有多少錢
        var money = JSStringUtility.format("%s%s", localString("您目前擁有：$"), JSCodeUtility.getCurrencyString(param.money));
        var moneyLabel = new cc.LabelTTF(money, JSFontBoldName, 10);
        moneyLabel.setPosition(JSScreenMidPos.x, 210 + JSScreenBonusHalfHeight);
        aniLayer.addChild(moneyLabel, 1);

        // Slider
        var nowValue = this._money - this._min;
        var sliderValue = (nowValue === 0 ? 0 : (nowValue / (this._max - this._min)));
        var slider = this._slider = new cc.ControlSlider("#lobby_bar_01.png", "#lobby_bar_02.png", "#game_btn_pic_silverbar.png");
        slider.setMinimumValue(-0.1);
        slider.setMaximumValue(1.1);
        slider.setMinimumAllowedValue(0);
        slider.setMaximumAllowedValue(1);
        slider.setValue(sliderValue);
        slider.setPosition(JSScreenMidPos.x, 169 + JSScreenBonusHalfHeight);
        slider.addTargetWithActionForControlEvents(this, this._sliderValueChanged, cc.CONTROL_EVENT_VALUECHANGED);
        aniLayer.addChild(slider);

        // 最小攜入
        var posX = JSScreenMidPos.x - 124;
        titleLabel = new cc.LabelTTF(localString("最小攜入"), JSFontBoldName, 10);
        titleLabel.setPosition(posX, 143 + JSScreenBonusHalfHeight);
        aniLayer.addChild(titleLabel, 1);

        var minLabel = new cc.LabelTTF(TexasUtility.getSimpleMoneyString(this._min), JSFontBoldName, 10);
        minLabel.setFontFillColor(JSColor.YELLOW2);
        minLabel.setPosition(posX, 130 + JSScreenBonusHalfHeight);
        aniLayer.addChild(minLabel, 1);

        // 最大攜入
        posX = JSScreenMidPos.x + 124;
        titleLabel = new cc.LabelTTF(localString("最大攜入"), JSFontBoldName, 10);
        titleLabel.setPosition(posX, 143 + JSScreenBonusHalfHeight);
        aniLayer.addChild(titleLabel, 1);

        var maxLabel = new cc.LabelTTF(TexasUtility.getSimpleMoneyString(this._max), JSFontBoldName, 10);
        maxLabel.setFontFillColor(JSColor.YELLOW2);
        maxLabel.setPosition(posX, 130 + JSScreenBonusHalfHeight);
        aniLayer.addChild(maxLabel, 1);

        // 現在選到多少錢
        var nowMoneyLabel = this._nowMoneyLabel = new cc.LabelTTF(JSCodeUtility.getCurrencyString(this._money), JSFontBoldName, 20);
        nowMoneyLabel.setFontFillColor(JSColor.YELLOW2);
        nowMoneyLabel.setPosition(JSScreenMidPos.x, 135 + JSScreenBonusHalfHeight);
        aniLayer.addChild(nowMoneyLabel);

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.setPosition(441 + JSScreenBonusHalfWidth, 255 + JSScreenBonusHalfHeight);
        closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
        aniLayer.addChild(closeBtn);

        // Menu
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        aniLayer.addChild(menu);

        // 增加按鈕
        var addNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_03.png", cc.size(24, 24), "#lobby_pic_plus.png");
        var addItem = new cc.MenuItemSprite(addNodes[0], addNodes[1], null, this._menuItemAddBringMoney, this);
        addItem.setPosition(JSScreenMidPos.x + 124, 169 + JSScreenBonusHalfHeight);
        menu.addChild(addItem);

        // 減少按鈕
        var cutNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_03.png", cc.size(24, 24), "#lobby_pic_less.png");
        var cutItem = new cc.MenuItemSprite(cutNodes[0], cutNodes[1], null, this._menuItemSubBringMoney, this);
        cutItem.setPosition(JSScreenMidPos.x - 124, 169 + JSScreenBonusHalfHeight);
        menu.addChild(cutItem);

        // 0:每局補足設定攜入 1:籌碼為0。自動攜入
        var toggleMenu = new cc.Menu();
        aniLayer.addChild(toggleMenu);

        var titleStrings = [localString("每局補足設定攜入"), localString("籌碼爲0時，自動攜入")];
        var menuCallback = [this._menuItemRoundAutoBring, this._menuItemZeroAutoBring];
        var menuSelectIndex = [this._isAutoBringInEachRound ? 1 : 0, this._isAutoBringInWhenZero ? 1 : 0];
        var basePosX = JSScreenMidPos.x - 120;
        var posY = 98 + JSScreenBonusHalfHeight;
        for (var i = 0; i < 2; i++) {
            // 先加checkBox
            var toggleItems = [];
            for (var x = 0; x < 2; x++) {
                var name = (x == 0) ? "#game_pic_check_0.png" : "#game_pic_check_1.png";
                var image1 = new cc.Sprite(name);
                var image2 = new cc.Sprite(name);
                image2.setColor(JSColor.GRAY);
                toggleItems[x] = new cc.MenuItemSprite(image1, image2);
            }
            var menuToggle = this._toggleMenuItems[i] = new cc.MenuItemToggle([toggleItems[0], toggleItems[1]], menuCallback[i], this);
            menuToggle.setPosition(basePosX, posY);
            menuToggle.setSelectedIndex(menuSelectIndex[i]);
            menu.addChild(menuToggle);

            var autoLabel = new cc.LabelTTF(titleStrings[i], JSFontBoldName, 10);
            autoLabel.setAnchorPoint(0, 0.5);
            autoLabel.setPosition(basePosX + 12, posY);
            aniLayer.addChild(autoLabel, 1);

            posY -= 15;
        }

        // 攜入確定按鈕
        var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", cc.size(120, 32), localString("接受"), 14, JSColor.BLACK);
        var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._bringBtnClicked, this);
        menuItem.setPosition(JSScreenMidPos.x, 52 + JSScreenBonusHalfHeight);
        menu.addChild(menuItem);

        // 開始跳Dialog
        this._startDialogAnimation();
    },

    /**
     * 當彈跳做完動畫
     */
    _dialogOpenAnimationDone: function () {
        if (!this._bringInTime)
            return;

        var aniNode = this._animationNode;

        // 有攜入時間 要倒數
        var nowTime = this._bringInTime;
        var timeLabel = new cc.LabelTTF(nowTime.toString(), JSFontBoldName, 16);
        timeLabel.setFontFillColor(JSColor.YELLOW2);
        timeLabel.setPosition(JSScreenMidPos.x - 166, 231 + JSScreenBonusHalfHeight);
        aniNode.addChild(timeLabel, 1);

        var timeWordLabel = new cc.LabelTTF(LocalizedString.Game("秒可以攜入"), JSFontBoldName, 12);
        timeWordLabel.setAnchorPoint(0, 0.5);
        timeWordLabel.setPosition(JSScreenMidPos.x - 154, 231 + JSScreenBonusHalfHeight);
        aniNode.addChild(timeWordLabel, 1);

        // 開始倒數
        var reduceFunc = function () {
            nowTime--;

            // 更新文字
            timeLabel.setString(nowTime.toString());

            if (nowTime <= 0) {
                // 要離開
                this.unschedule(reduceFunc);

                // 當做關掉
                this._closeBtnClicked();
            }
        };
        this.schedule(reduceFunc, 1);

        this._super();
    },

    /**
     * 按鈕
     */
    /**
     * 點擊關閉按鈕
     */
    _closeBtnClicked: function () {
        // 判斷是否要送出站起
        if (this._type === BringMoneyDialog.Type.NEED_CHIPS && DataModal.gameData.getMyPlayerData() != null)
            DataProcess.sendString("stand");

        this._closeDialogAnimation();
    },

    /**
     * 按攜入按鈕
     */
    _bringBtnClicked: function () {
        // 設定Data
        var gameData = DataModal.gameData;
        gameData.autoBringInMoney = this._money;
        gameData.isAutoBringInEachRound = this._isAutoBringInEachRound;
        gameData.isAutoBringInWhenZero = this._isAutoBringInWhenZero;

        // 設定攜入時幫玩家攜入多少錢
        var jsonValue = {
            money: this._money,
            each_round: this._isAutoBringInEachRound ? 1 : 0,
            when_zero: this._isAutoBringInWhenZero ? 1 : 0
        };
        DataProcess.sendString("set_auto_bring_in " + JSON.stringify(jsonValue));

        // 選位坐下
        if (this._type === BringMoneyDialog.Type.SIT)
            DataProcess.sendString("sit " + this._sitPos + " " + this._money);
        else
            DataProcess.sendString("bring_in " + this._money);

        this._closeDialogAnimation();
    },

    /**
     * 按 + 按鈕
     */
    _menuItemAddBringMoney: function () {
        var newMoney = this._money + this.addUnit;
        if (newMoney > this._max) {
            this._slider.setValue(1);
            this._money = this._max;
        } else {
            var value = (newMoney - this._min) / (this._max - this._min);
            if (isNaN(value)) value = 1;
            this._slider.setValue(value);
            this._money = newMoney;
        }
        this._nowMoneyLabel.setString(JSCodeUtility.getCurrencyString(this._money));
    },

    /**
     * 按 - 按鈕
     */
    _menuItemSubBringMoney: function () {
        var newMoney = this._money - this.addUnit;
        if (newMoney < this._min) {
            this._slider.setValue(0);
            this._money = this._min;
        } else {
            var value = (newMoney - this._min) / (this._max - this._min);
            if (isNaN(value)) value = 0;
            this._slider.setValue(value);
            this._money = newMoney;
        }
        this._nowMoneyLabel.setString(JSCodeUtility.getCurrencyString(this._money));
    },

    /**
     * 籌碼不足時，是否自動攜入選擇
     */
    _menuItemRoundAutoBring: function (sender) {
        this._isAutoBringInEachRound = sender.getSelectedIndex() === 1;

        if (this._isAutoBringInEachRound) {
            // 把另一邊的勾勾關掉
            this._toggleMenuItems[1].setSelectedIndex(0);
            this._isAutoBringInWhenZero = false;
        }
    },

    // 每局補足設定攜入
    _menuItemZeroAutoBring: function (sender) {
        this._isAutoBringInWhenZero = sender.getSelectedIndex() === 1;

        if (this._isAutoBringInWhenZero) {
            // 把另一邊的勾勾關掉
            this._toggleMenuItems[0].setSelectedIndex(0);
            this._isAutoBringInEachRound = false;
        }
    },

    /**
     * 滑動金錢的slider
     */
    _sliderValueChanged: function (sender) {
        var sliderValue = sender.getValue();
        if (sliderValue > 0.99)
            sliderValue = 1;
        if (sliderValue === 0) {
            this._money = this._min;
        } else if (sliderValue === 1) {
            this._money = this._max;
        } else {
            this._money = this._min + (this._max - this._min) * sliderValue;
            if (this._money > this._max)
                this._money = this._max;
        }
        this._money = Math.round(this._money);
        this._nowMoneyLabel.setString(JSCodeUtility.getCurrencyString(this._money));
    },
});

BringMoneyDialog.Type = {
    NEED_CHIPS: 0,          // 遊戲玩到破產所需要籌碼的時後
    USER_CLICKED: 1,        // 玩家手動自己去叫出來的
    SIT: 2,                 // 選位的時後
};