/**
 * 9T 幸運彩票頁面
 *
 */

var BigLotteryLayer = cc.Layer.extend({
    ctor: function (pageType = BigLotteryLayer.PageType.NONE) {
        this._super();

        this.key = "BigLotteryLayer";

        this._pageArray = [];
        this._openPageType = pageType;

        // 需要讀取的素材
        var resources = this._resourceArray = ["lobby/bigLottery.plist", "lobby/bigLottery.png"];

        // 判斷是否讀取完畢
        this._loadFileDone = false;

        if (cc.sys.isNative || cc.textureCache.getTextureForKey(resources[1])) {
            this._loadResDone();
        } else {
            // H5要先Loader
            cc.loader.load(resources, this._loadResDone.bind(this));
        }
    },

    // 清掉不用的東西
    onExit: function () {
        if (this._loadFileDone)
            cc.spriteFrameCache.removeSpriteFramesFromFile(this._resourceArray[0]);

        this._super();
    },

    /**
     * 讀取素材完畢
     */
    _loadResDone: function () {
        cc.spriteFrameCache.addSpriteFrames(this._resourceArray[0], this._resourceArray[1]);

        this._loadFileDone = true;

        // 標題後光芒
        var titleLightSprite = new cc.Sprite("#bigLottery_bg_light04.png");
        titleLightSprite.setScale(9, 6);
        titleLightSprite.setPosition(JSScreenMidPos.x, JSVisibleSize.height - 40);
        this.addChild(titleLightSprite);

        // 紅色背景
        var bgSize = cc.size(JSVisibleSize.width + 2, 230 + JSScreenBonusHeight);
        var bgSprite = new ccui.Scale9Sprite("bigLottery_bg_redBg.png");
        bgSprite.setPreferredSize(bgSize);
        bgSprite.setPosition(JSScreenMidPos.x, 114 + JSScreenBonusHalfHeight);
        this.addChild(bgSprite);

        // 金線
        var goldLineSprite = new cc.Sprite("#bigLottery_pic_goldLine.png");
        goldLineSprite.setPosition(JSScreenMidPos.x, JSVisibleSize.height - 59);
        this.addChild(goldLineSprite);

        // 標題圖片
        var titleSprite = new cc.Sprite("#bigLottery_pic_title.png");
        titleSprite.setPosition(JSScreenMidPos.x, JSVisibleSize.height - 35);
        this.addChild(titleSprite);

        // 背景圖騰
        var stencilBgSprite = new ccui.Scale9Sprite("bigLottery_bg_redBg.png");
        stencilBgSprite.setPreferredSize(bgSize);

        // 裝主要東西的node(用來隱藏)
        var mainNode = this._mainNode = new cc.Node();
        this.addChild(mainNode);

        // 紅色透明背景
        var redBgSprite = new cc.Sprite("#bigLottery_bg_light.png");
        redBgSprite.setScale(11, 5);
        redBgSprite.setPosition(JSScreenMidPos.x, 114 + JSScreenBonusHalfHeight);
        mainNode.addChild(redBgSprite);

        // 側邊光
        var sideSprite = new cc.Sprite("#bigLottery_bg_halfLight.png");
        sideSprite.setScale(3, 2);
        sideSprite.setAnchorPoint(0, 0.5);
        sideSprite.setPosition(94 + JSScreenBonusHalfWidth, 114 + JSScreenBonusHalfHeight);
        mainNode.addChild(sideSprite);

        // 說明按鈕要蓋在標題gaf上
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        this.addChild(menu, 4);

        // 彩球機
        var colorBallSp = this._colorBallSp = new cc.Sprite("#bigLottery_pic_colorBall.png");
        colorBallSp.setPosition(47 + JSScreenBonusHalfWidth, 47 + JSScreenBonusHalfHeight);
        mainNode.addChild(colorBallSp);

        // 日曆
        var calendarLayer = this._calendarLayer = new BigLotteryCalendarLayer();
        calendarLayer.setPosition(JSScreenBonusHalfWidth, JSScreenBonusHalfHeight);
        mainNode.addChild(calendarLayer);

        // 說明按鈕
        itemNodes = ButtonUtility.createSingleScale9NodesWithIcon("#lobby_btn_circle_04.png", cc.size(28, 28), "#btn_explain.png");
        var infoBtn = this._infoBtn = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._infoClicked, this);
        infoBtn.setScale(0.8);
        infoBtn.setPosition(JSScreenMidPos.x + 90, JSVisibleSize.height - 46);
        menu.addChild(infoBtn);

        // 其餘按鈕
        menu = new cc.Menu();
        menu.setPosition(0, 0);
        mainNode.addChild(menu);

        // 左上角返回按鈕
        var backNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_07.png", cc.size(27, 27), "#lobby_btn_back.png");
        var backBtn = new cc.MenuItemSprite(backNodes[0], backNodes[1], null, this._backBtnClicked, this);
        backBtn.setPosition(20 + JSScreenSafeWidth, JSVisibleSize.height - 18);
        menu.addChild(backBtn);

        // 創側邊選單
        {
            // 新開獎要不要小紅點
            var needRedPoint = parseInt(GS.localStorage.getItem(UserDefaultKey.BigLotteryFirstInPurchase + DataModal.profileData.account, 0, true)) === 0;

            // 選單按鈕
            var tabItems = this._tabItems = [];
            var tabStringArray = ["幸運彩票", "我的彩票", "開獎紀錄"].map(str => LocalizedString.BigLottery(str));
            for (var i = 0; i < 3; i++) {
                var itemNodes = this._createTabBtn(tabStringArray[i], true);
                var tab = tabItems[i] = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._tabClicked, this);
                tab.setPosition(46 + JSScreenBonusHalfWidth, 200 - i * 43 + JSScreenBonusHalfHeight);
                menu.addChild(tab);

                if (i === 1 && needRedPoint) {
                    var badgeNode = tab.badgeNode = new BadgeNode();
                    badgeNode.useDefaultStyle();
                    badgeNode.playAnim();
                    badgeNode.setPosition(83, 35);
                    tab.addChild(badgeNode);
                }
            }
        }

        // 刷新
        this._refreshView();

        // Domino移植設定 Domino沒有購買頁不用導購買
        // 預選頁面
        if (this._openPageType === BigLotteryLayer.PageType.NONE) {
            // 重置中導去前期結果頁
            if (DataModal.bigLotteryData.isResetting())
                this._openPageType = BigLotteryLayer.PageType.HISTORY_PAGE;
            else
                this._openPageType = BigLotteryLayer.PageType.MAIN_PAGE;
        }

        // 預選畫面
        this._tabClicked(this._tabItems[this._openPageType], true);

        // 通知
        // Domino移植設定 Info_Buy的監聽
        GS.addListener("NotifyBigLotteryInfoBuyDone", this.notifyBigLotteryInfoBuyDone.bind(this), this);
        GS.addListener("NotifyBigLotteryChangePage", this.notifyBigLotteryChangePage.bind(this), this);
        GS.addListener("NotifyBigLotteryProgressReward", this.notifyBigLotteryProgressReward.bind(this), this);
        GS.addListener("NotifyBigLotteryHistoryShowPage", this.notifyBigLotteryHistoryShowPage.bind(this), this);
        GS.addListener("NotifyPurchaseSuccess", this.notifyPurchaseSuccess.bind(this), this);
        GS.addListener("NotifyPurchaseSuccessWithNewData", this.notifyPurchaseSuccessWithNewData.bind(this), this);
    },

    viewDidAppear: function () {
        // 撥放大樂彩音樂
        MusicUtility.playMusic("Music/Background/bigLottery.mp3", true);
    },

    // 關掉畫面結束
    viewWillDisappear: function () {
        // 改播回大廳音樂
        if (GS.isLuxyPoker)
            MusicUtility.playMusic("Music/Background/LuxyPoker/Lobbymix.mp3", true);
        else
            MusicUtility.playMusic("Music/Background/Domino/lobby_bg_music.mp3", true);
    },

    /**
     * 創側邊選單按鈕
     * @param btnString     按鈕文字
     * @param isEnabled     按鈕是否可以點擊
     */
    _createTabBtn: function (btnString, isEnabled) {
        var itemNode = [];
        var btnSize = cc.size(85, 38);

        if (isEnabled) {
            for (var i = 0; i < 3; i++) {
                var btnImg = (i === 2) ? "lobby_btn_01.png" : "lobby_btn_purchase_01.png";

                var node = itemNode[i] = new cc.Node();
                node.setContentSize(btnSize);
                node.setCascadeColorEnabled(true);
                node.setCascadeOpacityEnabled(true);

                var bgSprite = new ccui.Scale9Sprite(btnImg);
                bgSprite.setPreferredSize(btnSize);
                bgSprite.setPosition(btnSize.width / 2, btnSize.height / 2);
                node.addChild(bgSprite);

                // Domino移植設定 文字水平垂直置中
                var btnLabel = new cc.LabelTTF(btnString, JSFontName, 13, btnSize);
                btnLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                btnLabel.setVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                btnLabel.enableStroke(cc.color(90, 65, 0, 255), 2);
                btnLabel.setPosition(bgSprite.getPosition());
                node.addChild(btnLabel);
            }
            itemNode[1].setColor(JSColor.GRAY);
        } else {
            itemNode = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", btnSize, btnString, 14);
            itemNode.forEach(cur => {
                cur.label.enableStroke(cc.color(45, 45, 45, 255), 2);
            });
            itemNode[1].setColor(JSColor.WHITE);
            itemNode[2].setOpacity(255);
        }

        return itemNode;
    },

    /**
     * 顯示開獎紀錄的分頁
     * @param clickIndex    分頁
     */
    _showHistoryPage: function (clickIndex) {
        // 先隱藏主畫面
        this._mainNode.setVisible(false);

        var subPage;
        switch (clickIndex) {
            case BigLotteryLayer.HistoryPageType.LAST_TICKET_PAGE:
                // 前期結果
                subPage = this._subPage = new BigLotteryLastTicketLayer();
                break;
            case BigLotteryLayer.HistoryPageType.WINNER_LIST_PAGE:
                // 中獎名單
                subPage = this._subPage = new BigLotteryWinnerListLayer();
                break;
            case BigLotteryLayer.HistoryPageType.HISTORY_RECORD_PAGE:
                // 歷史紀錄
                subPage = this._subPage = new BigLotteryHistoryRecordLayer();
                break;
        }
        this.addChild(subPage, 4);
    },

    /**
     * 刷新畫面
     */
    _refreshView: function () {
        var mainNode = this._mainNode;

        var bigLotteryData = DataModal.bigLotteryData;

        var status = bigLotteryData.status;
        if (status === BigLotteryData.Status.CLOSE) {
            // 跳dialog通知
            DialogManager.addDialog(new CommonDialog({
                title: "提醒您",
                content: "活動已結束",
                callback: () => {
                    // 推回大廳
                    PushScene.popLayer();
                }
            }), false);
        } else {
            // Domino移植設定 這段註解沒用到為了同步比對一樣也移過來
            // // 是否需要鎖住購買彩票的按鈕
            // var needLockPurchaseBtn = !(status === Texas_BigLotteryData.Status.NORMAL);
            //
            // // 抓出購買彩票的按鈕重創(有兩種狀況)
            // // 1. 需要鎖住按鈕但是按鈕沒有鎖住 (needLockPurchaseBtn = true, isLock = false)
            // // 2. 需要打開按鈕但是按鈕鎖住了 (needLockPurchaseBtn = false, isLock = true)
            // var purchaseBtn = this._tabItems[BigLotteryLayer.PageType.PURCHASE_PAGE];
            // if (needLockPurchaseBtn !== purchaseBtn.isLock) {
            //     // 拿掉舊的按鈕
            //     purchaseBtn.removeFromParent();
            //
            //     var menu = new cc.Menu();
            //     menu.setEnabled(!needLockPurchaseBtn);
            //     menu.setPosition(0, 0);
            //     mainNode.addChild(menu);
            //
            //     var itemNodes = this._createTabBtn("購買彩券", !needLockPurchaseBtn);
            //     var tabBtn = this._tabItems[1] = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._tabClicked, this);
            //     tabBtn.setPosition(46 + JSScreenBonusHalfWidth, 157 + JSScreenBonusHalfHeight);
            //     tabBtn.isLock = needLockPurchaseBtn;
            //     menu.addChild(tabBtn);
            //
            //     // 判斷現在是不是在購買頁
            //     var currentPage = this._currentPage;
            //     if (needLockPurchaseBtn && currentPage && currentPage.pageType === Texas_BigLotteryLayer.PageType.PURCHASE_PAGE) {
            //         // 導到第一頁
            //         this._tabClicked(this._tabItems[0], true);
            //     }
            // }

            // 進入不能選票狀態，如果有選號dialog要拿掉他們
            if (status === BigLotteryData.Status.CANNOT_SELECT) {
                // 選號dialog有三種
                // 1.選號前 2.自動選號 3.電腦選號
                var keys = ["BigLotteryBeforeSelectDialog", "BigLotterySelectDialog", "BigLotteryAutoSelectDialog"];
                var dialogs = keys.map(key => DialogManager.getDialogByKey(key));
                var isDialogExist = dialogs.some(cur => cur !== undefined);
                if (isDialogExist) {
                    // 先清掉dialog
                    dialogs.forEach(cur => cur && cur._closeDialogAnimation());

                    // 跳提醒dialog 提醒玩家他的票被電腦強制選了
                    var param = {
                        titleImg: "#bigLottery_word_reminder.png",
                        bgSize: cc.size(380, 153),
                        content: LocalizedString.BigLottery("選號時間已經過囉～\n系統已自動幫您選號完成"),
                        buttons: ["OK"]
                    };
                    DialogManager.addDialog(new BigLotteryCommonDialog(param), false);
                }
            }
        }
    },

    /**
     * 排程去重要主頁面資料
     */
    _scheduleRefreshMainPage: function () {
        DataProcess.sendString("big_lottery_info_buy");
    },

    /**
     * 按鈕
     */

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        this._backBtnClicked();
    },

    /**
     * 側邊選單按鈕
     */
    _tabClicked: function (sender, autoClicked) {
        // 播放按鈕音效
        if (!autoClicked)
            MusicUtility.playEffect("Music/Effect/e_clickButton.mp3", false);

        // 找出現在按的是哪一個按鈕
        var clickedIndex = 0;
        for (var i = 0, len = this._tabItems.length; i < len; i++) {
            if (sender === this._tabItems[i]) {
                // 記下index
                clickedIndex = i;

                // 鎖住按鈕
                sender.setEnabled(false);
            } else {
                // 打開其他按鈕
                this._tabItems[i].setEnabled(true);
            }
        }

        var mainNode = this._mainNode;
        var pageArray = this._pageArray;

        // 先把所有頁面關掉
        pageArray.forEach(page => page && page.setVisible(false));

        var page = pageArray[clickedIndex];
        if (!page) {
            switch (clickedIndex) {
                case BigLotteryLayer.PageType.MAIN_PAGE:
                    // 幸運彩票
                    page = this._pageArray[clickedIndex] = new BigLotteryMainLayer();
                    break;
                case BigLotteryLayer.PageType.MY_TICKET_PAGE:
                    // 我的彩券
                    page = this._pageArray[clickedIndex] = new BigLotteryMyTicketLayer();
                    break;
                case BigLotteryLayer.PageType.HISTORY_PAGE:
                    // 前期結果
                    page = this._pageArray[clickedIndex] = new BigLotteryHistoryLayer();
                    break;
            }
            mainNode.addChild(page);
        }
        // 讓哪一個畫面出現
        page.setVisible(true);

        // 記下現在是哪一頁
        this._currentPage = page;

        // 清掉排程
        this.unschedule(this._scheduleRefreshMainPage);

        // 主頁面
        if (clickedIndex === BigLotteryLayer.PageType.MAIN_PAGE) {
            // 60秒刷新一次
            this.schedule(this._scheduleRefreshMainPage, 60);

            // 顯示說明按鈕
            this._infoBtn.setVisible(true);
        } else {
            // 隱藏說明按鈕
            this._infoBtn.setVisible(false);
        }

        if (sender.badgeNode) {
            // 拿掉小紅點
            sender.badgeNode.removeFromParent();
            sender.badgeNode = null;

            // 紀錄已跳過
            GS.localStorage.setItem(UserDefaultKey.BigLotteryFirstInPurchase + DataModal.profileData.account, "1", true);
        }
    },

    /**
     * 點擊關閉按鈕
     */
    _backBtnClicked: function () {
        MusicUtility.playEffect("Music/Effect/e_clickButton.mp3", false);
        PushScene.popLayer();
    },

    /**
     * 點擊說明按鈕
     */
    _infoClicked: function () {
        MusicUtility.playEffect("Music/Effect/e_clickButton.mp3", false);

        DialogManager.addDialog(new WebViewDialog(TexasUtility.getSimpleInfoURLByKey("big_lottery")), false);
    },

    /**
     * 通知
     */

    // Domino移植設定(Info跟Buy整合)
    // 通知收到大樂彩資訊
    notifyBigLotteryInfoBuyDone: function (event) {

        if (event && event.getUserData()) {
            var param = event.getUserData();

            // 有行事曆資料 顯示日曆
            if (param.scheduleArray && param.scheduleArray.length > 0) {
                this._calendarLayer.refreshView(param.scheduleArray);
                this._colorBallSp.setVisible(false);
            } else {
                // 顯示彩球機
                this._colorBallSp.setVisible(true);
                this._calendarLayer.setVisible(false);
            }

        }

    },

    // 通知要切頁面
    notifyBigLotteryChangePage: function (event) {
        // 傳進來的是頁數 有可能傳0(main_page) 判斷式會變false 所以直接跟undefined比較
        if (event && event.getUserData() !== undefined) {
            var page = event.getUserData();

            // 不同頁才要切
            if (page !== this._currentPage.pageType) {
                this._tabClicked(this._tabItems[page], true);
            }
        }
    },

    // 通知收到進度領獎
    notifyBigLotteryProgressReward: function (event) {
        if (event && event.getUserData()) {
            var param = event.getUserData();

            // 跳選號成功dialog
            var dialogParam = {
                key: "BigLotteryCommonDialog",
                bgSize: cc.size(460, 153),
                content: param.success ? param.msg : "領獎錯誤，請重新再試",
                buttons: ["OK"],
                callback: () => {
                    // 重要資料
                    DataProcess.sendString("big_lottery_info_buy");
                }
            };
            DialogManager.addDialog(new BigLotteryCommonDialog(dialogParam), false);
        }
    },

    // 通知打開前期結果裡頭的分頁
    notifyBigLotteryHistoryShowPage: function (event) {
        if (event && event.getUserData()) {
            var param = event.getUserData();

            // 要打開頁面
            if (param.isShow) {
                this._showHistoryPage(param.clickedIndex);
            } else {
                // 拿掉所有前期結果子頁面
                this._subPage.removeFromParent();
                this._subPage = null;

                // 顯示主畫面
                this._mainNode.setVisible(true);
            }
        }
    },

    // 通知儲值成功
    notifyPurchaseSuccess: function () {
        // 沒有顯示的時候不處理
        if (!this.isVisibleRecursive())
            return;

        // 設定儲值成功
        DataModal.bigLotteryData.purchaseSuccess = true;
        // 儲值完重新更新彩券資料 server雖然會自動吐但來的時間有時會比這邊快 就可能卡loading
        DataProcess.sendString("big_lottery_my_ticket");

        // 加loading
        GSLoading.addLoadingView();
    },

    // 通知儲值成功後收到新的資料來刷新
    notifyPurchaseSuccessWithNewData: function () {
        // 拿掉loading
        GSLoading.removeLoadingView();

        // 抓資料
        var bigLotteryData = DataModal.bigLotteryData;
        var status = bigLotteryData.status;
        var statusType = BigLotteryData.Status;
        var bigLotteryStr = LocalizedString.BigLottery;

        if (status === statusType.NORMAL || status === statusType.CANNOT_BUY) {
            // 跳出dialog
            var param = {
                key: "BigLotteryBeforeSelectDialog",
                bgSize: cc.size(380, 170),
                content: JSStringUtility.format(bigLotteryStr("儲值成功！獲得%d張彩票\n是否要立刻進行選號？"), bigLotteryData.purchaseTicketNum),
                buttons: ["電腦選號", "自己選號"].map(string => bigLotteryStr(string)),
                closeButton: true,
                closeBtnNotClose: true,
                callback: (index) => {
                    // 點關閉按鈕
                    if (index === -1) {
                        // 跳dialog
                        var param = {
                            key: "BigLotteryCommonDialog",
                            btnImages: ["lobby_btn_01.png", "lobby_btn_06.png"],
                            bgSize: cc.size(380, 170),
                            titleImg: "#bigLottery_word_dontMiss.png",
                            content: bigLotteryStr("您尚未完成選號，\n離開後可再至『我的彩票』\n進行選號"),
                            buttons: ["繼續選號", "先離開"].map(string => bigLotteryStr(string)),
                            callback: (index) => {
                                if (index === 1) {
                                    // 拿掉儲值成功那個dialog
                                    var dialog = DialogManager.getDialogByKey("BigLotteryBeforeSelectDialog");
                                    dialog && dialog._closeDialogAnimation();
                                }
                            }
                        };
                        DialogManager.addDialog(new BigLotteryCommonDialog(param), false);
                    }
                    // 點電腦選號
                    else if (index === 0) {
                        // 跳電腦選號dialog
                        DialogManager.addDialog(new BigLotteryAutoSelectDialog(), false);

                        // 重要資料
                        DataProcess.sendString("big_lottery_my_ticket");
                    }
                    // 點繼續選號
                    else if (index === 1) {
                        // 跳選號dialog
                        DialogManager.addDialog(new BigLotterySelectDialog(), false);
                    }
                }
            };
            DialogManager.addDialog(new BigLotteryCommonDialog(param), false);
        } else {
            // 跳dialog
            // 1. 被系統強制選號
            // 2. 等下期才能選號
            // 兩個只差在內文
            var param = {
                key: "BigLotteryCommonDialog",
                bgSize: cc.size(380, 170),
                content: status === statusType.CANNOT_SELECT ? bigLotteryStr("儲值成功 ! \n當期彩券準備開獎 , \n系統已幫您完成選號") : JSStringUtility.format(bigLotteryStr("您已錯過本期開獎時間\n獲得下期彩券%d張\n(下午1點可進行選號)"), bigLotteryData.purchaseTicketNum),
                buttons: ["OK"],
                callback: () => {
                    // 切到我的彩券頁
                    this._tabClicked(this._tabItems[BigLotteryLayer.PageType.MY_TICKET_PAGE], true);
                }
            };
            DialogManager.addDialog(new BigLotteryCommonDialog(param), false);
        }
    }
});

/**
 * 幸運彩票 頁面類型
 */
BigLotteryLayer.PageType = {
    NONE: -1,           // 沒有
    MAIN_PAGE: 0,       // 幸運彩票
    MY_TICKET_PAGE: 1,  // 我的彩票
    HISTORY_PAGE: 2     // 開獎紀錄
};

/**
 * 幸運彩票 歷史紀錄分頁類型
 */
BigLotteryLayer.HistoryPageType = {
    LAST_TICKET_PAGE: 0,    // 上期彩券
    WINNER_LIST_PAGE: 1,    // 中獎名單
    HISTORY_RECORD_PAGE: 2  // 歷史紀錄
};
