/**
 * 好友加入牌桌的node (目前用於好友清單、找尋好友中）
 */
var FriendJoinNode = cc.Node.extend({
    ctor: function () {
        this._super();

        var bgSize = cc.size(96, 36);
        this.setContentSize(bgSize);

        // 玩法背景
        var joinBgSp = this._joinBgSp = new ccui.Scale9Sprite("lobby_purchase_promote_bg.png");
        joinBgSp.setPreferredSize(bgSize);
        joinBgSp.setAnchorPoint(0, 0);
        joinBgSp.setPosition(0, 0);
        this.addChild(joinBgSp);

        // 玩法標題
        var joinGameSp = this._joinGameSp = new cc.Sprite("#friend_word_poker.png");
        joinGameSp.setPosition(24, 24);
        this.addChild(joinGameSp);

        // 玩法倍數
        var joinBetLabel = this._joinBetLabel = new GSAutoSizeLabel("", JSFontBoldName, 12, cc.size(52, 0), cc.TEXT_ALIGNMENT_CENTER);
        joinBetLabel.resizeToFit(6);
        joinBetLabel.setPosition(4, 11);
        this.addChild(joinBetLabel);

        // 加入牌桌
        var posX = joinBgSp.getPositionX() + joinBgSp.getContentSize().width - 28;
        var joinBtn = this._joinBtn = new ButtonUtility.createSimpleButton("lobby_btn_01.png", cc.size(46, 25), LocalizedString.Friend("加入"), JSColor.BLACK, 8);
        joinBtn.enableTouchCancel(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        joinBtn.addTouchUpInsideAction(this._joinBtnClicked, this);
        joinBtn.setPosition(posX, 18);
        this.addChild(joinBtn);

        // 加入箭頭 把文字往左一點
        var arrowSprite = new cc.Sprite("#bg_arrow2.png");
        arrowSprite.setPosition(18, 0);
        joinBtn.addChildToContentNode(arrowSprite);
        joinBtn.label.setPosition(-3, 0);
    },

    setTouch: function (isTouch) {
        this._joinBtn.setEnabled(isTouch);
    },

    /**
     * 刷新資訊
     * game   : 遊戲名稱
     * bet    : 倍率
     * isJoin : 是否顯示加入按鈕
     */
    refreshInfo: function (join, userID) {
        this._joinParam = join;
        this._userID = userID;

        // 刷新入桌倍率
        this._joinBetLabel.setString(join.feeMsg);
        this._joinGameSp.setScale(1);

        // 刷新遊戲名稱
        switch (join.game) {
            case GSEnum.Game.Texas:
                this._joinGameSp.setSpriteFrame("friend_word_poker.png");
                break;
            case GSEnum.Game.Domino:
                this._joinGameSp.setSpriteFrame("friend_word_QQ.png");
                break;
            case GSEnum.Game.Gaple:
                this._joinGameSp.setSpriteFrame("friend_word_gaple.png");
                break;
            case GSEnum.Game.GapleChat:
                this._joinGameSp.setSpriteFrame("friend_word_gapleChat.png");
                break;
            case GSEnum.Game.GaplePlus:
                this._joinGameSp.setSpriteFrame("friend_word_gaplePlus.png");
                break;
            case GSEnum.Game.GapleVideo:
                this._joinGameSp.setSpriteFrame("friend_word_gapleVideo.png");
                break;
            case GSEnum.Game.Remi:
                this._joinGameSp.setSpriteFrame("friend_word_remi.png");
                break;
            case GSEnum.Game.Cangkulan:
                this._joinGameSp.setSpriteFrame("friend_word_cangkulan.png");
                break;
            case GSEnum.Game.CapsaSusun:
                this._joinGameSp.setSpriteFrame("friend_word_capsaSusun.png");
                break;
        }

        // 刷新join是否顯示
        this._joinBtn.setVisible(join.button);

        // 調整背景尺寸 取最長邊
        var titleWidth = this._joinGameSp.getContentSize().width;
        var labelWidth = this._joinBetLabel.getContentSize().width;
        var betLen = Math.max(titleWidth, labelWidth);
        var betLabelWidth = (join.button) ? 110
            : betLen + 8;

        // 背景尺寸
        var bgSize = cc.size(betLabelWidth, 36);
        this.setContentSize(bgSize);
        this._joinBgSp.setPreferredSize(bgSize);

        // 調整入桌按鈕位置
        this._joinBtn.setPositionX(betLabelWidth - 28);

        // 扣掉按鈕前面空白處的一半
        var halfWidth = (betLabelWidth - 48 * join.button) / 2;
        // 調整bet & 遊戲種類位置
        this._joinGameSp.setPositionX(halfWidth);
        this._joinBetLabel.setPositionX(halfWidth);

        // -8 是因為背景有邊框，稍微扣掉一點
        let joinGameSpMaxWidth = 2 * halfWidth - 8;
        let joinGameSpWidth = this._joinGameSp.getContentSize().width;
        if (joinGameSpWidth > joinGameSpMaxWidth) {
            // 較寬，縮小文字圖
            this._joinGameSp.setScale(joinGameSpMaxWidth / joinGameSpWidth);
        }
    },

    /**
     * 加入牌桌點擊
     */
    _joinBtnClicked: function () {
        if (!this._joinParam || !this._userID)
            return;

        var joinParam = this._joinParam;

        // 送出跟隨好友入桌
        var obj = {
            userid: this._userID,
            room_id: joinParam.roomID,
            game: joinParam.game
        };
        DataModal.friendData.sendJoinCmd(FriendData.joinType.LobbyFriendList, JSON.stringify(obj));

        GSLoading.addLoadingView();
    }
});