var LocalizedString = LocalizedString || {};

(function () {
    var keyValue = {
        "單骰1:1": "Satu dadu 1:1",
        "雙骰1:2.3": "Dua dadu 1:2.3",
        "三骰1:12": "Tiga dadu 1:12",
        "大 :": "Besar: ",
        "小 :": "Kecil: ",
        "最近20手開大小機率": "Catatan 20 hasil terakhir",
        "開骰": "Hasil",
        "點數": "Angka",
        "大小": "hasil",
        "大": "Besar",
        "小": "Kecil",
        "豹": "Triple",
        "骰寶": "Sicbo",
        "本區下注金額上限為": "Bet Tertinggi ",
        "總下注金額上限為": "Total Bet Tertinggi ",
        "重複下注的金額不足": "Chip tidak cukup",
        "超過上限": "Melebih batas",
        "前100手開獎次數": "Jumlah keluar angka dari 100 permainan",
        "Record": "Rekor",
        "Tutorial": "Tutorial",
        "左右滑動可選擇投注額哦!": "Geser ke kanan atau ke kiri untuk pilih bet",
        "Info": "Info",
    };

    LocalizedString.DiceBo = function (str) {
        return USE_i18n ? (keyValue[str] || str) : str;
    };
})();
