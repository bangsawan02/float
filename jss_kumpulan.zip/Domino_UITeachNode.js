/**
 * 桌內新手指引
 */
var Domino_UITeachNode = cc.Node.extend({
    UITEACHNODE_LAST_INDEX_KEY: "UITeachLastIndexKey", //記錄目前步驟的Key

    ctor: function () {
        this._super();

        //每一手只會顯示一個教學(一次結算為一手)
        this._canShow = false;

        // 判斷都顯示過了的話 就不理他
        if (parseInt(GS.localStorage.getItem(this.UITEACHNODE_LAST_INDEX_KEY, 0)) >= 5) {
            return;
        }

        this._canShow = true;

        //每步驟的訊息
        var localString = LocalizedString.Game;
        this.MESSAGES = [
            localString("點擊下注決策按鈕"),
            localString("點擊牌即可換組合"),
            localString("使用表情符號"),
            localString("打開遊戲選單"),
            localString("點擊領取免費Chips")
        ];

        //訊息框指示箭頭的方向
        this.DIRECTOR = [
            BaseMessageNode.Direct.DOWN,
            BaseMessageNode.Direct.LEFT,
            BaseMessageNode.Direct.DOWN,
            BaseMessageNode.Direct.UP,
            BaseMessageNode.Direct.LEFT
        ];

        //指示箭頭的偏移值
        this.OFFSET = [0, 0, 35, 40, 0];

        //訊息框的位置
        this.POSITION = [
            cc.p(JSScreenMidPos.x + 25, 26),
            cc.p(274 + JSScreenBonusHalfWidth, 88 + JSScreenBonusHalfHeight),
            cc.p(20 + JSScreenSafeWidth, 26),
            cc.p(20 + JSScreenSafeWidth, JSVisibleSize.height - 32),
            cc.p(76 + JSScreenSafeWidth, JSVisibleSize.height - 18)
        ];

        //加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: false,
            onTouchBegan: this.onTouchBegan.bind(this)
        }, this);
    },

    /**
     * 彈跳出對應的說明文字
     * @param index 要顯示那一個步驟
     */
    show: function (cmd) {
        if (!this._canShow)
            return;

        // 這邊依照CMD來判斷現在的Index
        var lastIndex = parseInt(GS.localStorage.getItem(this.UITEACHNODE_LAST_INDEX_KEY, -1));
        if (lastIndex >= 5)
            return;

        var index = -1;
        switch (cmd) {
            case "FirstParam":
                // 每的手數開始
                if (lastIndex === 1)
                    index = 2;              // 使用表情符號
                else if (lastIndex === 2)
                    index = 3;              // 打開遊戲選單
                else if (lastIndex === 3 && DataModal.dailyMissionData.getActionListDialogHaveReward()) {
                    index = 4;              // 點擊領取免費Chips
                }
                break;
            case "ThirdParam":
                // 代表到三張 要show可以換牌的提示
                index = 1;
                break;
            case "play":
                // 輪到自己可以決策
                index = 0;
                break;
        }

        // 記錄超過步驟就不能彈了、檔手數以一次結算為一手、需要是目前進行到的步數
        if (index <= lastIndex)
            return;

        //開始彈出提示
        var message = new cc.LabelTTF(this.MESSAGES[index], JSFontBoldName, 10);
        message.setFontFillColor(JSColor.BLACK);

        var param = {
            mainNode: message,
            style: BaseMessageNode.Style.CUSTOM,
            direct: this.DIRECTOR[index],
            arrowType: BaseMessageNode.ArrowType.STRAIGHT,
            isFlip: false,
            arrowPadding: this.OFFSET[index],
            bgName: "domino_bubble_bg.png",
            arrowName: "domino_bubble_arrow.png",
            arrowToBgPadding: 3,
            bgBonusSize: cc.size(8, 8),
        };

        var info = new BaseMessageNode(param);
        info.setPosition(this.POSITION[index]);
        info.setName("info");
        this.addChild(info);

        //顯示3秒後移除自已
        info.show(3, true);

        if (index === 0) {
            // 下面要有金框
            var totalWidth = 452;
            var goldSprite = new ccui.Scale9Sprite("lobby_light_gold.png");
            goldSprite.setPreferredSize(cc.size(totalWidth, 35));
            goldSprite.setPosition(289 + JSScreenBonusHalfWidth, DOMINO_UILAYER_BUTTON_Y);
            this.addChild(goldSprite);

            goldSprite.runAction(cc.sequence(
                cc.fadeIn(0.25),
                cc.delayTime(3),
                cc.fadeOut(0.25),
                cc.removeSelf()
            ));
        }

        // 記錄下一次要顯示的步驟
        GS.localStorage.setItem(this.UITEACHNODE_LAST_INDEX_KEY, index.toString());
    },

    /**
     * Touch
     */
    onTouchBegan: function (touch, event) {
        if (this.getChildByName("info")) {
            var info = this.getChildByName("info");
            info.setName("");
            info.close();
        }
        return false;
    },
});
