/**
 * Domino移植設定 改語言
 * 9T 幸運彩票紅包cell
 */

var BigLotteryRedEnvelopeListCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        // Domino移植設定 客製畫面
        // 期數
        {
            // 裝標題的node
            var titleNode = this._titleNode = new cc.Node();
            titleNode.setPosition(191, 28);
            this.addChild(titleNode);

            // 背景
            var bgSprite = new ccui.Scale9Sprite("bigLottery_bg_redLine02.png");
            bgSprite.setPreferredSize(cc.size(360, 20));
            bgSprite.setPosition(0, 12);
            titleNode.addChild(bgSprite);

            // 標題字
            var titleLabel = this._titleLabel = new cc.LabelTTF(param.period, JSFontName, 14);
            titleLabel.setFontFillColor(JSColor.YELLOW);
            titleLabel.enableStroke(cc.color(190, 30, 0, 255), 2);
            titleLabel.setPosition(0, 12);
            titleNode.addChild(titleLabel);

            // 獎金
            var label = this._priceLabel = new cc.LabelTTF("", JSFontName, 14);
            label.enableStroke(cc.color(190, 30, 0, 255), 2);
            label.setPosition(0, -10);
            titleNode.addChild(label);
        }

        // 是玩家
        {
            // 放玩家的node
            var playerNode = this._playerNode = new cc.Node();
            playerNode.setPosition(191, 19);
            this.addChild(playerNode);

            this._playerArray = [];

            // 造2個
            for (var i = 0; i < 2; ++i) {
                var playerNode = new BigLotteryRedEnvelopePlayerNode();
                playerNode.setPosition(-64 + (i % 2) * 170, 0);
                this._playerNode.addChild(playerNode);
                this._playerArray.push(playerNode);
            }
        }
    },

    /**
     * 刷新cell
     */
    refreshCell: function (param) {
        // 是標題
        if (param.isTitle) {
            this._titleNode.setVisible(true);
            this._playerNode.setVisible(false);

            this._titleLabel.setString(param.period);
            this._priceLabel.setString(JSStringUtility.format(LocalizedString.BigLottery("獎金：%s德撲幣/人"), JSCodeUtility.getCurrencyString(param.prize)));
        } else if (param.players) {
            //是玩家
            this._titleNode.setVisible(false);
            this._playerNode.setVisible(true);

            for (var i = 0; i < 2; ++i) {
                this._playerArray[i].refreshByPlayerParam(param.players[i]);
            }
        }
    },

    // 點到cell 高亮
    setIsHighlight: function (isSelect) {
    }
});

// 提取該cell的大小
BigLotteryRedEnvelopeListCell.getSize = function (param) {
    if (param.isTitle)
        return cc.size(380, 55);
    else
        return cc.size(380, 36);
};