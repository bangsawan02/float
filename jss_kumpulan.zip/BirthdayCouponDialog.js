/**
 * 生日券/慶生卡
 */

var BirthdayCouponDialog = BaseDialogLayer.extend({
    ctor: function () {
        this._super();

        this.key = "BirthdayCouponDialog";

        // 需要讀取的素材
        this.loadFileArray = ["lobby/lobby_coupons.plist", "lobby/lobby_coupons.png"];
    },

    onExit: function () {
        if (this._loadFileDone)
            cc.spriteFrameCache.removeSpriteFramesFromFile("lobby/lobby_coupons.plist");

        this._super();
    },

    /**
     * 讀取素材完畢
     * @override
     */
    loadFileDone: function () {
        this._super();

        // 先讀圖片Plist
        cc.spriteFrameCache.addSpriteFrames("lobby/lobby_coupons.plist", "lobby/lobby_coupons.png");

        var aniLayer = this._animationLayer;

        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        aniLayer.addChild(menu);

        // 背景主畫面 + 儲值按鈕
        var itemNodes = ButtonUtility.createBtnSpriteArray("banner/lobby_purchase_birthday_banner.jpg");
        var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._goPurchaseClicked, this);
        menuItem.setPosition(JSScreenMidPos);
        menu.addChild(menuItem);

        // 關閉按鈕
        var closeBtn = this._closeBtn = new Texas_CloseButton();
        closeBtn.setPosition(441 + JSScreenBonusHalfWidth, 254 + JSScreenBonusHalfHeight);
        closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
        aniLayer.addChild(closeBtn);

        var timeBg = new ccui.Scale9Sprite("birthday_coupon_bg_time.png", cc.rect(30, 0, 20, 10));
        timeBg.setPreferredSize(cc.size(94, 48));//86
        timeBg.setAnchorPoint(cc.p(0, 0.5));
        timeBg.setPosition(45 + JSScreenBonusHalfWidth, 244 + JSScreenBonusHalfHeight);
        aniLayer.addChild(timeBg);

        var timeLabel = new GSTimeLabel("", JSFontBoldName, 10);
        timeLabel.setFontFillColor(JSColor.BROWN);
        timeLabel.setPosition(55, 20);
        timeLabel.setMultiFormat("%dd:%hh:%mm:%ss", "%hh:%mm:%ss");
        timeBg.addChild(timeLabel);

        var couponObject = DataModal.profileData.coupon;
        var nowTime = new Date().getTime() / 1000;
        var surplusTime = couponObject.surplus - (nowTime - couponObject.systemTime);

        // 時間到的callback
        var timesUpFun = () => {
            // 要關掉
            this._closeBtnClicked();

            // 重新去要儲值的內容
            DataModal.purchaseData.sendGetPurchaseListCMD();
        };

        if (surplusTime > 0) {
            timeLabel.countdownSeconds(surplusTime, timesUpFun);
        } else {
            timesUpFun();
        }
    },

    /**
     * 按鈕
     */
    // 關掉畫面
    _closeBtnClicked: function () {
        this._closeDialogAnimation();
    },

    // 去儲值頁的按鈕
    _goPurchaseClicked: function () {
        // 去儲值頁面
        PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase, "");

        // 關掉畫面
        this._closeDialogAnimation();
    },
});