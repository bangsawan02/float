/**
 * 骰寶的桌面的感應按鈕
 */

var DiceBoTableButton = cc.Node.extend({
    ctor: function (size, zoneType, callback, target) {
        this._super();

        this.zoneSize = size;
        this.zoneType = zoneType;

        // 壓注區按鈕
        var zoneBg = new ccui.Scale9Sprite("db_grid.png");
        var button = new cc.ControlButton(zoneBg);
        button.setPreferredSize(size);
        button.setZoomOnTouchDown(false);
        button.addTargetWithActionForControlEvents(this, function () {
            // 這邊轉一層 把自己丟給callback
            callback && callback.call(target, this);
        }, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        button.setAdjustBackgroundImage(false);
        button.setZoomOnTouchDown(false);
        this.addChild(button);

        // 壓注區亮光
        var zoneLightSprite = this._zoneLightSprite = new ccui.Scale9Sprite("db_grid_win.png");
        zoneLightSprite.setPreferredSize(cc.size(size.width + 2, size.height + 2));
        zoneLightSprite.setVisible(false);
        this.addChild(zoneLightSprite);

        // 選取區亮光
        var chooseLightSprite = this._chooseLightSprite = new ccui.Scale9Sprite("db_grid_choose.png");
        chooseLightSprite.setPreferredSize(cc.size(size.width + 3, size.height + 3));
        chooseLightSprite.setVisible(false);
        this.addChild(chooseLightSprite);
    },

    /**
     * 清除畫面
     */
    clean: function () {
        // 把所有東西都關掉
        this.setZoneLightVisible(false);
        this.setChooseLightVisible(false);
    },

    /**
     * 設定壓注區亮光是否能看到
     */
    setZoneLightVisible: function (isVisible) {
        this._zoneLightSprite.setVisible(isVisible);
    },

    /**
     * 設定選取區亮光是否能看到
     */
    setChooseLightVisible: function (isVisible) {
        this._chooseLightSprite.setVisible(isVisible);
    },
});