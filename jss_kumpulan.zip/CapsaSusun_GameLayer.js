/**
 * CapsaSusun 遊戲主畫面
 */
var CapsaSusun_GameLayer = cc.Layer.extend({
    Z_TAG_PROFILE_LAYER: 198300001,

    ctor: function () {
        this._super();

        this._isPlaying = false;                        // 是否正在玩
        this._enableProcessMessage = true;              // 是否可以執行cmd
        this._isReplaceingRoom = false;                 // 是否正在換房間(給stand & updateSeat用)
        this._isReplacedRoom = false;                   // 是否正在換房間(給toGame 顯示訊息用)
        this._showNeedPayDialog = false;                // 是否有出現破產的Dialog 這樣收到stand就不處理
        this._playingPlayers = [];                      // 遊戲現在有哪些活人需要發牌給他的
        this._backgroundListener = null;                // 到背景的監聽
        this._isFinishing = false;                      // 現在是否在結算中
        this._playTime = new Date().getTime();          // Firebase 埋點, 記錄遊戲時間

        this._cleanGameLayerData(true);
        this._resetGameLayerData();

        // 背景(含網速、Dealer)
        this._bgLayer = new CapsaSusun_BackgroundLayer();
        this.addChild(this._bgLayer, -10000);

        // 邀請玩家按鈕Layer
        this._sitsInviteLayer = new SitInviteNodesLayer();
        this.addChild(this._sitsInviteLayer, -1);

        // 玩家們
        this._playersLayer = new CapsaSusun_PlayersLayer();
        this.addChild(this._playersLayer, 1);

        // 牌
        this._cardsLayer = new CapsaSusun_CardsLayer();
        this.addChild(this._cardsLayer, 1);

        // 分數
        var scoreLayer = this._scoreLayer = new CapsaSusun_ScoreLayer();
        this.addChild(scoreLayer, 2);

        // 互動表情選擇人物畫面
        this._actMoodAimLayer = new ActMoodAimLayer();
        this.addChild(this._actMoodAimLayer, 3);

        // 新增聚寶盆icon (5.4.2 跳提示泡泡框 要比玩家層級高)
        var treasureBowlIcon = new TreasureBowlGameIconNode();
        treasureBowlIcon.setScale(0.8);
        treasureBowlIcon.setPosition(JSVisibleSize.width - 25 - JSScreenSafeWidth, JSVisibleSize.height - 59);
        this.addChild(treasureBowlIcon, 3);

        // 遊戲積分
        this._gameRankLayer = new GameRankGameLayer();
        this.addChild(this._gameRankLayer, 3);

        // 互動表情動畫
        this._actMoodAnimationLayer = new ActMoodAnimationLayer();
        this.addChild(this._actMoodAnimationLayer, 3);

        // 對話的泡泡匡
        var gameChatMessageLayer = new GameChatMessageLayer();
        this.addChild(gameChatMessageLayer, 3);

        // 遊戲介面
        this._uiLayer = new CapsaSusun_UILayer();
        this.addChild(this._uiLayer, 3);

        // 左上選單
        this._optionUILayer = new CapsaSusun_UIOptionLayer();
        this.addChild(this._optionUILayer, 3);

        // 遊戲中的提示
        this._gameHintLayer = new CapsaSusun_GameHintLayer();
        this.addChild(this._gameHintLayer, 3);

        // 聊天選單
        this._gameChatLayer = new GameChatLayer();
        this.addChild(this._gameChatLayer, 3);

        // 自動代打
        this._autoPlayLayer = new CapsaSusun_AutoPlayLayer();
        this._autoPlayLayer.setVisible(false);
        this.addChild(this._autoPlayLayer, 3);

        // 比賽推廣提示
        var tournamentPromoteNode = this._tournamentPromoteNode = new TournamentPromoteGameNode();
        this.addChild(tournamentPromoteNode, 10);

        // 聊天浮動按鈕(icon在哪個畫面上)
        var friendChatNode = new ChatRoomIconLayer(ChatRoomIconLayer.POS_TYPE.CAPSASUSUN);
        this.addChild(friendChatNode, 4);

        // 動畫 在最上方
        this._animationLayer = new CapsaSusun_AnimationLayer();
        this.addChild(this._animationLayer, 3);

        // 註冊通知
        GS.addListener("NotifyGameProcessCMD", this.notifyGameProcessCMD.bind(this), this);
        GS.addListener("NotifyEnableProcessMessage", this.notifyEnableProcessMessage.bind(this), this);
        GS.addListener("NotifyGameUIChangePlaceClicked", this.notifyGameUIChangePlaceClicked.bind(this), this);
        GS.addListener("NotifyGameUIBackToLobbyClicked", this.notifyGameUIBackToLobbyClicked.bind(this), this);
        GS.addListener("NotifyStartGame", this.notifyStartGame.bind(this), this);
        GS.addListener("NotifyUpdateCurrentSeatDone", this.notifyUpdateCurrentSeatDone.bind(this), this);
    },

    onEnter: function () {
        this._super();

        DataProcess.sendString("get_camp_mood_list");           // 抓special表情
        DataProcess.sendString("act_moods_backpack");           // 抓互動道具
        DataProcess.sendString("store_mood_backpack");          // 抓商城表情

        // 每日任務
        DataModal.dailyMissionData.startGetInfo(DailyMissionEnum.whereType.Game, GSEnum.Game.CapsaSusun);

        // 確認是否有牌局重現指令
        this.checkmRC();
    },

    onExit: function () {
        // Firebase 埋點, 記錄遊戲時間
        GameFirebaseTracker.trackPlayingTime(this._playTime);

        this._backgroundListener && cc.eventManager.removeListener(this._backgroundListener);

        this._super();
    },

    // 確認是否有牌局重現指令
    checkmRC: function () {
        var mRCString = DataModal.reappearData.mRCString;
        if (mRCString && mRCString.length) {
            // 送給GameData
            DataModal.gameData.processReconnectState("mRC_setState", mRCString);

            // 清掉
            DataModal.reappearData.mRCString = null;

            // 直接跑
            while (this.processMessage() && this._enableProcessMessage) {
            }
        } else {
            // 晚一下子 跑所有指令
            this._processAllCommand();
        }
    },

    // 跑所有指令
    _processAllCommand: function () {
        var action1 = cc.delayTime(0.1);
        var action2 = cc.callFunc(function () {
            while (this.processMessage() && this._enableProcessMessage) {
            }
        }, this);
        this.runAction(cc.sequence(action1, action2));
    },

    // 清除GameLayer的資訊
    // isOnload 是否為初始資料階段
    _cleanGameLayerData: function (isOnload) {
        //清掉其他畫面
        if (!isOnload) {
            this._bgLayer.cleanData();
            this._sitsInviteLayer.cleanData();
        }

        this._showNeedPayDialog = false;                // 是否有出現破產的Dialog 這樣收到stand就不處理
    },

    // 重置GameLayer一起記錄的每一局資訊
    _resetGameLayerData: function () {
        // 各家玩家的牌型，普通牌是大小3的array，特殊牌是大小1的array，null就沒有玩家在玩
        // {"0":[0,1,4], null, "2":[1,5,7], "3":[4]}
        this._cardTypeArray = {};
        // 各家玩家的分數 [[第一墩所有人分數],[第二墩所有人分數],[第三墩所有人分數],[普通比牌總分]]
        this._normalScoreArray = [];
        // [最後更新的總分]
        this._totalScoreArray = [];
        // 特殊牌[0,1,2,3]
        this._specialArray = [];
        // 打槍資訊
        this._strikeParamArray = [
            // {winServerDir: 贏家, loseServerDir: 輸家, winnerTotalScore: 贏家分數, loserTotalScore: 輸家分數},{...}
        ];
        // 全壘打資訊 "homerun": {"shotPos":"1", "targetPos":["被打的"],"total":["全部人的被打後的分數"]}
        this._homeRunInfo = undefined;
        // 中途回來開始比牌時需要的資訊
        this._currentFightInfo = {
            // fightOverTime: 比牌的剩餘時間, socketTime: 收到current_playing的時間, foulhand: [相公牌的人]
        };
    },

    // 檢查需要跳哪種沒錢的Dialog
    // canGoToSmallDesktop 是否能進小桌
    _checkBrokePaymentDialog: function (canGoToSmallDesktop) {
        // 跳儲值
        NoMoneyDialogHelper.showGameDialog(canGoToSmallDesktop);

        // 把預約離桌跟預約換桌的關掉
        DataModal.gameData.leaveGameStatus = CapsaSusun_LeaveGameStatus.CAN_LEAVE;
    },

    // 判斷現在是否要提示等待下一局的提示
    _checkNeedShowPlayHint: function () {
        if (DataModal.gameData.myPos === -1) {
            // 清掉所有畫面 不理他
            this._gameHintLayer.closeWaitPlayerHint();
            this._gameHintLayer.closeNextRoundHint();

            return;
        }

        // 如果只有一位 就顯示等待其他玩家
        if (DataModal.gameData.getPlayerCount() === 1 && DataModal.gameData.leaveGameStatus === CapsaSusun_LeaveGameStatus.CAN_LEAVE && !this._isFinishing) {
            this._gameHintLayer.showWaitPlayerHint();
        } else {
            // 關掉等待其他玩家提示
            this._gameHintLayer.closeWaitPlayerHint();

            // 判斷是否進去桌裡面等帶下一局開始 先觀戰
            var myPos = DataModal.gameData.myPos;
            if (myPos > -1 && this._playingPlayers.length && this._playingPlayers.indexOf(myPos) < 0 && !this._isFinishing) {
                // 在裡面 不過沒在玩 要出現
                this._gameHintLayer.showNextRoundHint();
            } else {
                // 其他狀況不顯示
                this._gameHintLayer.closeNextRoundHint();
            }
        }
    },

    // 處理GameData Message
    processMessage: function () {
        var haveMessage = false;
        var newMessageCommand = DataModal.gameData.popQueuedMessage();

        if (newMessageCommand) {
            haveMessage = true;

            var gameData = DataModal.gameData;
            var socketValue = newMessageCommand.value;

            switch (newMessageCommand.key) {
                case "gsOLEH":
                    // 收到一些設定
                    break;

                case "OLEH":
                    // 重置外觀
                    this._playersLayer.cmd_OLEH();
                    this._uiLayer.cmd_OLEH();
                    this._bgLayer.cmd_OLEH();
                    this._gameHintLayer.clean();
                    this._animationLayer.clean();
                    this._cardsLayer.clean();
                    this._scoreLayer.clean();

                    this._isFinishing = false;

                    this._checkNeedShowPlayHint();

                    // 重置遊戲數據
                    this._resetGameLayerData();

                    break;

                case "dealer":
                    // 決定現在誰是dealer
                    this._bgLayer.cmd_dealer(parseInt(socketValue));
                    break;

                case "roomparam":
                    // 處理進入房間的資訊
                    if (this._isReplacedRoom) {
                        this._isReplacedRoom = false;
                        DialogManager.closeDialogByKey("ReplaceRoomDialog");
                        DialogManager.closeDialogByKey("InviteFriendListDialog");

                        //Reset
                        this._cleanGameLayerData(false);
                    }

                    // 更新背景的名稱
                    this._bgLayer.cmd_roomparam();

                    break;

                case "updateSeat":
                    this._cmd_updateSeat();
                    break;

                case "current_playing":
                    // 牌局重現
                    // current_playing 1 {
                    // ----中途入桌必傳
                    // 	"handCard":"3T1Q181J16342Q4K143J4T2K38", // 自己手牌
                    // 	"playing":["0","2","3"],	// 有玩玩家位置
                    // 	"gotSpecial":"3",
                    // 	"remainTimer":"45",			// 剩餘時間
                    // 	"leaveState":"1",			// 預約離桌狀態
                    // 	"dealer":"0",				// 第一個拿到牌玩家
                    // ----中途入桌必傳
                    // 	"ready":"1", 					// 如果自己ready會傳1，沒有就不會傳
                    // ----入桌在fight後必傳，且在收到current_playing前要先收到各玩家的plready/plspecial
                    // 	"fight":"1",					// fight後傳1，fight前傳0
                    // 	"remainFinishTimer":"XX",		// 離finish還有多久，還沒fight傳0
                    // 	"pltotal":["全部人的最後總分"], 	// pltotal的內容
                    // 	"plscore":["第一墩分數","第二墩", "第三墩"],	// plscore的東西[[50,0,50,-100],[140,0,-40,-100],[50,0,50,-100]]
                    // 	"raw":["第一墩特殊分數","第二墩", "第三墩"],	// plscore的自己的特殊，沒有就[0,0,0]
                    // ----fight後必傳
                    // ----假如沒有的話,可以連key都不傳
                    // 	"foulhand": [0, 2],				// 有哪些位置相公
                    // 	"strike": "原來的字串",			// 要修改，多一次多4秒，以|區別有幾次
                    // 	"homerun": {"shotPos":"1", "targetPos":["被打的"],"total":["全部人的各個總分"]},	// 有就要加6.5秒
                    // ----假如沒有的話,可以連key都不傳
                    // }
                    var array = socketValue.split(" ");
                    var isCurrentPlaying = array[0] === "1";

                    //如果牌局重現回來已經沒牌局 直接關閉牌局重現flag
                    if (!isCurrentPlaying) {
                        gameData.isReconnect = false;
                        gameData.isReappearIng = false;

                        this._isPlaying = false;
                        break;
                    }

                    // 牌局重現
                    this._currentFightInfo = {};
                    if (isCurrentPlaying && array[1]) {
                        var jsonValue = JSON.parse(array[1]);
                        // 設定dealer
                        this._bgLayer.cmd_dealer(jsonValue["dealer"]);

                        // 有哪幾家在玩
                        this._playingPlayers = (jsonValue["playing"] || []).map(cur => parseInt(cur));
                        this._playersLayer.setplayingPlayers(this._playingPlayers);

                        // 是不是在觀戰
                        var isPlaying = this._playingPlayers.indexOf(gameData.myPos) !== -1;
                        if (!isPlaying)
                            this._playersLayer.cmd_current_playing(isPlaying);

                        // 設定場上的牌
                        this._cardsLayer.cmd_current_playing(jsonValue, isPlaying, this._specialArray);

                        // 自己是不是特殊牌
                        this._isSpecial = JSCodeUtility.getIntValue(jsonValue["gotSpecial"]);

                        // 是否已經做好決策
                        var isReady = JSCodeUtility.getIntValue(jsonValue["ready"]);

                        // 還在決策階段
                        if (!isReady && !this._isSpecial && isPlaying)
                            this._cardsLayer.setLocalZOrder(100);

                        // 特殊牌的動畫，自己要先播
                        if (this._isSpecial) {
                            this._cardsLayer.showSpecialFighting([gameData.myPos]);
                            this._animationLayer.showMySelfSpecialAnime(this._isSpecial);
                        }

                        // 是否已經開始比牌
                        var isFight = JSCodeUtility.getIntValue(jsonValue["fight"]);
                        if (isFight) {
                            // 離finish還有多久
                            var leftTime = this._currentFightInfo.fightOverTime = JSCodeUtility.getIntValue(jsonValue["remainFinishTimer"]);
                            // 紀錄收到的時間，中途入桌的玩家會可能updateSeat還沒收到有自己的資訊，等收到轉位再開演，會扣掉經過的時間避免delay下場
                            this._currentFightInfo.socketTime = new Date().getTime() / 1000;
                            // 相公
                            var foulhandArray = this._currentFightInfo.foulhand = (jsonValue["foulhand"] || []).map(cur => parseInt(cur));

                            // 各家普通比牌分數
                            var eachStackScoreArray = (jsonValue["plscore"] || []);
                            this._normalScoreArray = eachStackScoreArray.map(cur => {
                                var tmpArray = [];
                                cur.forEach(score => {
                                    if (score === "")
                                        tmpArray.push(0);
                                    else
                                        tmpArray.push(parseInt(score));
                                });
                                return tmpArray;
                            });
                            // 全體普通比牌完的總分
                            var totalScoreData = [0, 0, 0, 0];
                            eachStackScoreArray.forEach(stackScore => {
                                stackScore.forEach((curScore, idx) => {
                                    if (parseInt(curScore))
                                        totalScoreData[idx] += parseInt(curScore);
                                });
                            });
                            this._normalScoreArray.push(totalScoreData);
                            // 自己的普通比牌的特殊大牌加分
                            this._mySpScore = (jsonValue["raw"] || [0, 0, 0]).map(cur => parseInt(cur));
                            // 最終大總分
                            this._totalScoreArray = (jsonValue["pltotal"] || [0, 0, 0, 0]).map(cur => parseInt(cur));

                            // strike 打槍
                            this._strikeParamArray = [];
                            var strike = JSCodeUtility.getStringValue(jsonValue["strike"]);
                            if (strike) {
                                strike.split("|").forEach(info => {
                                    var strikeArray = info.split(",");
                                    // 每一次打槍資訊
                                    var strikeParam = {
                                        winServerDir: parseInt(strikeArray[0]),
                                        loseServerDir: parseInt(strikeArray[1]),
                                        winnerTotalScore: parseInt(strikeArray[2]),
                                        loserTotalScore: parseInt(strikeArray[3])
                                    };
                                    // 把打槍資訊存起來
                                    this._strikeParamArray.push(strikeParam);
                                });
                            }

                            // 全壘打
                            this._homeRunInfo = undefined;
                            var jValue = jsonValue["homerun"] || {};
                            if (jValue) {
                                var loseArray = (jValue["targetPos"] || []).map(cur => parseInt(cur));
                                if (loseArray.length) {
                                    var totalScore = (jValue["total"] || []).map(cur => parseInt(cur));
                                    this._homeRunInfo = {
                                        winServerDir: JSCodeUtility.getIntValue(jValue["shotPos"]),
                                        loseServerDirArray: loseArray,
                                        totalScoreArray: totalScore
                                    };
                                }
                            }

                            // 開始比牌
                            this._current_fighting(leftTime, foulhandArray);
                        }

                        // 離桌狀態
                        var status = JSCodeUtility.getIntValue(jsonValue["leaveState"]);
                        gameData.leaveGameStatus = (status >= 0 && status <= 3) ? status : CapsaSusun_LeaveGameStatus.CAN_LEAVE;

                        // 把表情打開
                        this._uiLayer.setEmoticonVisible(true);

                        this._isPlaying = true;
                    } else
                        this._isPlaying = false;
                    break;

                case "updateChips":
                    this._playersLayer.cmd_updateChips();
                    break;

                case "updateInfo":
                    // 更新配件資訊
                    this._playersLayer.cmd_updateInfo(socketValue);
                    break;

                case "playing":
                    // 把現在遊戲中哪些活人記下來
                    this._playingPlayers = (JSON.parse(newMessageCommand.value) || []).map(cur => parseInt(cur));
                    this._playersLayer.setplayingPlayers(this._playingPlayers);
                    break;

                case "ServerReady":
                    var array = socketValue.split(" ");

                    // 防呆 開始倒數的時候 把換桌視窗關掉
                    if (this._isReplacedRoom) {
                        this._isReplacedRoom = false;
                        DialogManager.closeDialogByKey("ReplaceRoomDialog");
                    }

                    // 準備要開始遊戲了
                    this._gameHintLayer.showGameReadyHint(parseInt(array[0]) || 3);

                    // 關閉比賽推廣
                    this._tournamentPromoteNode.closeGapleKOPromoteHint();

                    // 關掉等待其他玩家提示
                    this._gameHintLayer.closeWaitPlayerHint();
                    break;

                case "startGame":
                    // 開始遊戲
                    this._gameHintLayer.closeGameReadyHint();

                    // 關閉結算模式 顯示手牌抽牌區
                    // this._cardsLayer.setFinishAnimationMode(false);

                    // 把表情打開
                    this._uiLayer.setEmoticonVisible(true);
                    break;

                case "Param":
                    // 發牌 Param [0,1] XXXXXXXXX
                    var array = socketValue.split(" ");
                    var posArray = JSON.parse(array[0]);
                    var handCards = JSCodeUtility.getStringValue(array[1]).match(REGEXP_TWO_NUMBERS);

                    if (!gameData.isReappearing) {
                        // 表演洗牌發牌
                        this._enableProcessMessage = false;
                        this._cardsLayer.dealCardAnim(this._bgLayer.getDealerPosition(), posArray, handCards);
                    }

                    // 放入手牌
                    handCards && this._cardsLayer.addHandCard(handCards);

                    //AppsFlyer
                    if (GameAppsFlyerTracker.isNeedTrackFirstClick()) {
                        GameAppsFlyerTracker.startTime = new Date().getTime();
                    }

                    break;

                case "special":
                    // 有無特殊牌型
                    var array = socketValue.split(" ");
                    this._isSpecial = parseInt(array[0]);
                    this._isSpecial && this._cardsLayer.cmd_special();
                    break;

                case "decision_time":
                    // 決策剩餘秒數
                    var array = socketValue.split(" ");
                    var countTime = parseInt(array[0]);

                    // 不是特殊牌型 進入決策頁面
                    if (!this._isSpecial) {
                        this._cardsLayer.setLocalZOrder(100);

                        // 進入決策要把Dialog關掉
                        DialogManager.cleanAllDialog();
                        DialogManager.pauseShowDialog();

                        // 關掉聊天視窗
                        GS.dispatchCustomEvent("NotifyCloseChatRoomLayer");

                        this._cardsLayer.setHandCardVisible(true);
                    }

                    this._cardsLayer.showChangeCardAnim(this._isSpecial);

                    // 計時
                    this._cardsLayer.startClock(countTime);
                    break;

                case "plready":
                case "plspecial":
                    // 決策準備好
                    // plready:一般牌 plspecial:使用特殊牌 其他內容資訊都一樣
                    // plready 0 22,12,1K,46,16,49,29,17,35,37,3T,3K,31 1|2|5
                    // 位置 手牌(每張牌用逗號隔開) 牌型(每墩用直線隔開)
                    var valueArray = socketValue.split(" ");
                    if (valueArray.length === 0)
                        break;

                    // 哪個玩家
                    var serverDir = parseInt(valueArray[0]);

                    // 牌型
                    var cardType = valueArray[2].split("|").map(cur => parseInt(cur));
                    this._cardTypeArray[serverDir] = cardType;

                    // 手上的牌
                    var cardArray = valueArray[1].split(",");
                    // 是不是特殊牌
                    var isSpecial = (newMessageCommand.key === "plspecial");
                    this._cardsLayer.cmd_plready(serverDir, cardArray, isSpecial);

                    // 紀錄場上有特殊牌的玩家
                    if (isSpecial)
                        this._specialArray.push(serverDir);
                    else {
                        // 解掉上面 進入決策要把Dialog關掉
                        DialogManager.resumeShowDialog();
                    }
                    // 判斷自己 收到決策完畢
                    var isSelf = serverDir === DataModal.gameData.myPos;
                    if (isSelf) {
                        // 關閉決策畫面 進入等待比牌頁面
                        this._cardsLayer.setLocalZOrder(1);
                        this._cardsLayer.setHandCardVisible(false);

                        // 自己的特殊牌動畫要先播放
                        if (this._isSpecial) {
                            this._cardsLayer.showSpecialFighting([serverDir]);
                            this._animationLayer.showMySelfSpecialAnime(cardType[0]);
                        }
                    }

                    break;

                case "plscore":
                    // 比牌分數
                    // plscore pos [pos0分數,pos1分數,pos2分數,pos3分數],[pos0分數,pos1分數,pos2分數,pos3分數],[pos0分數,pos1分數,pos2分數,pos3分數] 0,0,0
                    // #顯示分數 位置沒人會是 ''
                    // 自己位置 第一墩所有人分數,第二墩所有人分數,第三墩所有人分數 特殊加分(只有自己有)
                    var valueArray = socketValue.split(" ");
                    if (valueArray.length === 0)
                        break;

                    // 所有人的一般分數
                    var eachStackScoreArray = JSON.parse(valueArray[1]);
                    this._normalScoreArray = eachStackScoreArray.map(cur => {
                        var tmpArray = [];
                        cur.forEach(score => {
                            if (score === "")
                                tmpArray.push(0);
                            else
                                tmpArray.push(parseInt(score));
                        });
                        return tmpArray;
                    });

                    // 計算一般分數總分
                    var totalScoreData = [0, 0, 0, 0];
                    eachStackScoreArray.forEach(stackScore => {
                        stackScore.forEach((curScore, idx) => {
                            if (parseInt(curScore))
                                totalScoreData[idx] += parseInt(curScore);
                        });
                    });
                    this._normalScoreArray.push(totalScoreData);

                    // 自己的特殊加分
                    if (valueArray[2])
                        this._mySpScore = valueArray[2].split(",");
                    else
                        this._mySpScore = [0, 0, 0];

                    break;

                case "pltotal":
                    // 總分 : 玩家位置0,1,2,3
                    // pltotal ["1","-1","",""]
                    var totalScore = JSON.parse(socketValue);

                    this._totalScoreArray = totalScore;

                    break;

                case "foulHand":
                    // 出牌錯誤
                    // foulHand 0 2 => 這樣就代表位子0 2是相公
                    // foulHand -1 => 這樣就是沒有相公
                    var valueArray = socketValue.split(",");
                    if (valueArray.length === 0 || valueArray[0] === -1)
                        break;

                    var foulHandArray = valueArray;
                    this._isFinishing = true;
                    this._enableProcessMessage = false;
                    this._cardsLayer.setLocalZOrder(1);
                    this._playersLayer.setLocalZOrder(2);
                    this._playersLayer.showFoulhandAsync(foulHandArray)
                        .then(() => {
                            this._playersLayer.setLocalZOrder(1);
                            this._enableProcessMessage = true;
                            // 做完動畫了 重新抓cmd
                            this.notifyEnableProcessMessage();
                        });

                    break;

                case "strike":
                    // 打槍
                    // win家打lose家，，最多共六次 winner_score: 贏家此次打槍加墩後的總分 loser_score: 輸家扣墩後的總分
                    // strike win,lose,winner_score,loser_score|…
                    // e.g. strike 0,1,12,-2 第0家打第1家，第0家的總分變為12，第1家變為-2
                    var valueArray = socketValue.split(" ");
                    if (valueArray.length === 0)
                        break;

                    this._strikeParamArray = [];
                    valueArray[0].split("|").forEach(info => {
                        var strikeArray = info.split(",");
                        // 每一次打槍資訊
                        var strikeParam = {
                            winServerDir: strikeArray[0],
                            loseServerDir: strikeArray[1],
                            winnerTotalScore: parseInt(strikeArray[2]),
                            loserTotalScore: parseInt(strikeArray[3])
                        };
                        // 把打槍資訊存起來
                        this._strikeParamArray.push(strikeParam);
                    });

                    break;

                case "homerun":
                    // 全壘打
                    // homerun 1 [0,2] [-100, 200, -100, 0]
                    // homerun 打者 [被打的] [各個總分]
                    var valueArray = socketValue.split(" ");
                    if (valueArray.length === 0)
                        break;

                    // 把全壘打資訊存起來
                    var homeRunInfo = {
                        winServerDir: valueArray[0],
                        loseServerDirArray: JSON.parse(valueArray[1]),
                        totalScoreArray: JSON.parse(valueArray[2])
                    };

                    this._homeRunInfo = homeRunInfo;
                    break;

                case "fight":
                    // 開始比牌
                    this._isFinishing = true;

                    // 停止計時
                    this._cardsLayer.stopClock();
                    this._enableProcessMessage = false;
                    // 調整牌的層級跟 設定關掉決策
                    this._cardsLayer.setLocalZOrder(1);
                    this._cardsLayer.showFightCardLayer();

                    // 開始比牌
                    this._processingStartAnim();

                    break;

                case "finish":
                    // 結算 結算狀態 贏家座位 [手牌] [牌型] [分數] [錢]
                    // 結算 finish ["-11500000","10350000","0","0"]
                    var moneyArray = JSON.parse(socketValue);   // 全部人的錢
                    var winArray = [];
                    var loseArray = [];
                    moneyArray.forEach((curMoney, idx) => {
                        if (curMoney > 0)
                            winArray.push(idx);
                        else if (curMoney < 0)
                            loseArray.push(idx);

                    });
                    // 記下來現在正在結算
                    this._isFinishing = true;
                    this._enableProcessMessage = false;

                    if (this._playingPlayers.indexOf(DataModal.gameData.myPos) > -1) {
                        // 更新聚寶盆 透過網址
                        DataModal.treasureBowlData.treasureBowlParam && DataModal.treasureBowlData.updateDataBy(1, false);

                        // 跳新玩家牌桌內功能提示
                        DataModal.newbieData.showGameTableFunctionHint();
                    }

                    // 開始噴錢動畫
                    this._animationLayer.showCoinAsync(loseArray, winArray, moneyArray)
                        .then(() => {
                            this._isFinishing = false;
                            this._enableProcessMessage = true;
                            this._cardsLayer.clean();     // 清掉牌
                            this._animationLayer.clean(); // 清動畫
                            this._scoreLayer.clean();     // 清掉分數
                            // 做完動畫了 重新抓cmd
                            this.notifyEnableProcessMessage();
                        });

                    // AppsFlyer 玩家在牌局中贏牌就算1次(累加)
                    winArray.forEach((curWin, idx) => {
                        if (curWin === DataModal.gameData.myPos) {
                            GameAppsFlyerTracker.trackByGameName("win");
                        }
                    });

                    // 追蹤生涯玩x手
                    if (this._playingPlayers.indexOf(DataModal.gameData.myPos) > -1) {
                        GameAppsFlyerTracker.trackPlayingTimes();
                    }

                    // Firebase 追蹤
                    var eventName = GSAnalyticsAdapter.record.game + "Capsa Susun牌桌玩法";
                    var eventKey = "桌列表";
                    var eventValue = undefined;
                    if (DataModal.gameData.anteValue <= 4000000)
                        eventValue = "Capsa Susun低底台局數";
                    else if (DataModal.gameData.anteValue <= 8000000)
                        eventValue = "Capsa Susun中底台局數";
                    else
                        eventValue = "Capsa Susun高底台局數";

                    GSAnalyticsAdapter.logEventByFirebaseAll(eventName, [eventKey], [eventValue]);

                    break;

                case "stand":
                    // TODO
                    break;

                case "showPlayerClass":
                    // 積分系統 入桌階級顯示
                    //   {
                    //        "pos":"5",   #位置
                    //        "dealerSay":"Selamat datang Aries Mo para pemain hebat di meja profesional", #荷官恭迎
                    //        "userClass":{"score":"0","class":"0","ranking":"1"} #此玩家階級資料
                    //   }
                    var jsonValue = JSON.parse(newMessageCommand.value);
                    var serverPos = JSCodeUtility.getIntValue(jsonValue["pos"]);
                    var isMe = DataModal.gameData.myPos === serverPos;

                    var classValue = jsonValue["userClass"];
                    if (classValue) {
                        // 如果是自己的話更新左下角積分系統
                        if (isMe && classValue["showProtecIcon"]) {
                            var userClass = {
                                isShowProtectIcon: JSCodeUtility.getIntValue(classValue["showProtecIcon"])
                            };
                            this._gameRankLayer.cmd_showPlayerClass(userClass);
                        }

                        if (classValue["class"]) {
                            // 給PlayersLayer做進來的動畫
                            this._playersLayer.cmd_showPlayerClass(jsonValue);
                        }
                    }

                    break;

                case "gameRank_protect_info":
                    // 用來跳桌內上方的保護令提示
                    this._gameHintLayer.cmd_gameRank_protect_info(socketValue);
                    break;

                case "gameRank_protect_remain":
                    // 更新個人的階級
                    this._gameRankLayer.cmd_gameRank_protect_remain(socketValue);
                    break;

                case "gameRank_update":
                    // 積分系統 自己的分數變動
                    this._gameRankLayer && this._gameRankLayer.cmd_gameRank_update(socketValue);
                    break;

                case "gameRank_class":
                    // 拿個人積分資訊 要更新左下角Icon
                    var jsonValue = JSON.parse(socketValue);
                    var param = {
                        class: JSCodeUtility.getIntValue(jsonValue["class"]),
                        score: JSCodeUtility.getIntValue(jsonValue["score"]),
                        nextScore: JSCodeUtility.getIntValue(jsonValue["nextClassScore"]),
                        ranking: JSCodeUtility.getIntValue(jsonValue["ranking"])
                    };
                    this._gameRankLayer.cmd_gameRank_class(param);
                    break;

                case "gameRank_booster_info":
                    // 積分系統 加速器的狀態
                    this._gameRankLayer && this._gameRankLayer.cmd_gameRank_booster_info(socketValue);
                    break;

                case "koin_luxy_room_status":
                    // koinluxy更動
                    this._uiLayer.cmd_koin_luxy_room_status(socketValue);
                    break;

                case "play":
                    // 輪到誰
                    this._cmd_play(socketValue);
                    break;

                case "toLobby":
                    // 離桌
                    // 可以離桌 只會有單純的 toLobby
                    if (!newMessageCommand.value) {
                        // 強制GameLayer不要收東西了
                        this._enableProcessMessage = false;

                        GSLoading.addLoadingView();
                    } else {

                        // 離桌失敗 toLobby 0
                        var value = JSCodeUtility.getIntValue(newMessageCommand.value);
                        // 失敗拿掉Loading
                        if (value === 0)
                            GSLoading.removeLoadingView();
                    }
                    break;

                case "update_getexp":
                    // 獲得多少EXP
                    this._playersLayer.cmd_update_getexp(socketValue);
                    break;

                case "update_upgrade":
                    // 有沒有升級
                    this._playersLayer.cmd_update_upgrade(socketValue);
                    break;

                case "update_gameRankUpdate":
                    // 積分更動
                    this._playersLayer.cmd_update_gameRankUpdate(socketValue);
                    break;

                case "stopGame":
                    this._isPlaying = false;
                    this._isFinishing = false;
                    this._bgLayer.cleanData();

                    // 清掉東西
                    this._gameHintLayer.clean();
                    this._animationLayer.clean();
                    this._cardsLayer.clean();

                    // 關掉表情
                    this._uiLayer.setEmoticonVisible(false);

                    // 判斷是否要跳出等待下一局的提示
                    this._checkNeedShowPlayHint();

                    // 刮刮卡暫停
                    DataModal.scratchCardData.stopCountDown();
                    break;

                case "need_pay":
                    // need_pay pos 能不能進小桌
                    // 玩家破產了
                    // 這邊不用判段myPos了 因為GameData那邊判斷過了
                    this._showNeedPayDialog = true;

                    // 是否能進小桌
                    var array = socketValue.split(" ");
                    var canGoToSmallDesktop = parseInt(array[1]) === 1;

                    // 檢查需要跳哪種沒錢的Dialog
                    this._checkBrokePaymentDialog(canGoToSmallDesktop);

                    break;

                case "sitFail":
                    // 入座失敗
                    var jsonValue = JSON.parse(socketValue);
                    var gameString = LocalizedString.Game;
                    var dialogObj = {
                        title: gameString("貼心提醒"),
                        buttons: [gameString("返回大廳")],
                        callback: function (index) {
                            // 回大廳
                            GS.dispatchCustomEvent("NotifyGameUIBackToLobbyClicked");
                        }
                    };

                    var code = JSCodeUtility.getIntValue(jsonValue["code"]);
                    if (code === 1) {
                        // 吃Server給的參數
                        dialogObj.content = decodeURIComponent(JSCodeUtility.getStringValue(jsonValue["msg"]));
                        DialogManager.addDialog(new AvatarDialog(dialogObj));
                    } else {
                        // code = 0 or 舊格式(沒有code), 不吃server參數, 直接顯示訊息
                        DialogManager.addDialog(new AvatarDialog(DialogHelper("GameNoMoney_SitFail")));
                    }
                    break;

                case "broken_reward":
                    // 玩家破產補幣
                    DialogManager.addDialog(new GameBrokenRewardDialog(socketValue));

                    break;

                case "little_tips":
                    // 跳訊息Dialog
                    var param = {
                        key: "LittleTipDialog",
                        msg: socketValue,
                        button: [LocalizedString.Common("確認")]
                    };
                    DialogManager.addDialog(new FrameDialog(param));
                    break;

                /**
                 * 表情
                 */
                case "mood":
                case "amood":
                    this._playersLayer.cmd_mood(socketValue);
                    break;
                case "vmood":
                    this._playersLayer.cmd_vmood(socketValue);
                    break;

                case "store_mood":
                    this._playersLayer.cmd_store_mood(socketValue);
                    break;

                case "act_moods":
                    // 互動表情
                    this._actMoodAnimationLayer.cmd_act_moods(socketValue);
                    break;

                case "gift_accessory":
                    // 送禮物
                    this._playersLayer.cmd_gift_accessory(socketValue);
                    break;

                // 送禮包
                case "gift_package":
                    var array = socketValue.split(" ");
                    this._actMoodAnimationLayer.cmd_gift_package(array);
                    break;

                // 提示
                case "show_intro":
                    this._gameHintLayer.showCapsaSusunIntro(socketValue);
                    break;

                /**
                 * 牌局重現
                 */
                case "mRC_setState":
                    var jsonValue = JSON.parse(socketValue);

                    // 把遊戲資料的Array先Copy一份 然後清掉
                    var oldCmdArray = gameData.cmdQueueArray.slice(0);
                    gameData.cmdQueueArray = [];

                    // 把音效關掉
                    MusicUtility.setReconnectStopEffect(true);

                    // 把牌局重現flag打開 有些東西不執行
                    gameData.isReappearIng = true;

                    // 把preinfo 遊戲一開始產生的資訊抓出來
                    var preinfo = jsonValue["preinfo"];

                    // 主CMD
                    var isParam = false;
                    var cmd = preinfo["cmd"];
                    var cmdLen = cmd ? cmd.length : 0;
                    var canProcess = cmdLen > 0;
                    for (var i = 0; i < cmdLen; i++) {
                        var cmdString = JSCodeUtility.getStringValue(cmd[i]);
                        DataProcess.sendCustomStringToSelf(cmdString);
                    }

                    //快轉到現在的狀況
                    for (var i = 0; i < 10; i++) {
                        cc.director.getActionManager().update(100);
                        cc.director.getScheduler().update(100, false);
                    }

                    //判斷是否要往下做
                    if (!canProcess) {
                        //把音效打開
                        MusicUtility.setReconnectStopEffect(false);

                        //失敗 要斷線踢掉
                        DataProcess.disconnect();

                        //踢回登入頁面
                        cc.director.runScene(new LoginScene());

                        //跳Alert
                        var commonString = LocalizedString.Common;
                        AlertDialog.showAlert(commonString("連線錯誤"), commonString("網路不穩,建議您確認連線是否正常。\n若仍在牌局中，馬上登入即可回到牌局。"));
                        break;
                    }

                    // 已經pass的時鐘時間
                    var countdown = JSCodeUtility.getIntValue(jsonValue["countdown"]);
                    if (countdown < gameData.diouwait) {
                        //因為後面會delay1秒再通知時鐘 所以這裡先加
                        countdown++;
                    }

                    // 判斷是否要進結算畫面
                    var haveFinal = false;
                    var final = jsonValue["final"];
                    if (final) {
                        var cmd = final["cmd"];
                        var cmdLen = cmd ? cmd.length : 0;
                        haveFinal = cmdLen > 0;
                        //結算的CMD
                        for (var i = 0; i < cmdLen; i++) {
                            var cmdString = JSCodeUtility.getStringValue(cmd[i]);
                            DataProcess.sendCustomStringToSelf(cmdString);
                        }
                    }

                    if (!haveFinal) {
                        //g0代表遊戲 沒大小結的
                        var g0 = jsonValue["g0"];
                        if (g0) {
                            var cmd = g0["cmd"];
                            var cmdLen = cmd ? cmd.length : 0;
                            for (var i = 0; i < cmdLen; i++) {
                                var cmdString = JSCodeUtility.getStringValue(cmd[i]);
                                DataProcess.sendCustomStringToSelf(cmdString);
                            }
                        }
                    } else {
                        // 要把手牌都清掉
                        this._cardsLayer.clean();
                        this._playersLayer.cleanAllHandCard();
                    }

                    //再次快轉
                    for (var i = 0; i < 10; i++) {
                        cc.director.getActionManager().update(100);
                        cc.director.getScheduler().update(100, false);
                    }

                    //把音效打開
                    MusicUtility.setReconnectStopEffect(false);

                    // 把GameData設之後setInfo不要理會 不然會錯亂
                    gameData.isReconnect = true;

                    // 把牌局重現關掉
                    gameData.isReappearIng = false;

                    // 把自動代打關掉
                    this._autoPlayLayer.close();
                    DataProcess.sendString("game_autoplay 0");

                    //晚一下子通知時鐘斷線回來了 因為剛快轉過 整個會有問題
                    setTimeout(function () {
                        GS.dispatchCustomEvent("NotifyReconnectDone", countdown);
                    }, 1000);

                    //最後在把cmd array塞回去
                    gameData.cmdQueueArray = gameData.cmdQueueArray.concat(oldCmdArray);

                    break;

                default:
                    this._enableProcessMessage = true;
                    this.processMessage();
                    break;
            }
        }
        return haveMessage;
    },

    /**
     * 更新位置資訊
     * @private
     */
    _cmd_updateSeat: function () {
        // 拿掉第一次進來的LoadingView
        if (this._isFirstComeToTheDestop) {
            GSLoading.removeLoadingView();
            this._isFirstComeToTheDestop = false;
        }

        // 更新是否有坐下的畫面
        var haveMe = DataModal.gameData.haveMe;
        this._playersLayer.updateSeat(haveMe);
        if (haveMe) {
            // 有我了 代表換完房間了
            this._isReplaceingRoom = false;
            this._sitsInviteLayer.update(true);
        } else {
            if (this._isReplaceingRoom) {
                this._sitsInviteLayer.setAllSitsVisible(false);
            } else {
                this._sitsInviteLayer.update(false);
            }
        }

        // 給互動道具選擇畫面更新
        this._actMoodAimLayer.cmd_updateSeat();

        // 去判斷要出現什麼提示
        this._checkNeedShowPlayHint();
    },

    /**
     * 輪到誰
     * play pos is_self
     */
    _cmd_play: function (value) {
        var valueArray = value.split(" ");
        var serverSitNum = JSCodeUtility.getIntValue(valueArray[0]);
        var isMeFlag = JSCodeUtility.getIntValue(valueArray[1]);
        var delay = DataModal.gameData.diouwait || 10;

        // 設定手牌是不是輪到自己
        this._cardsLayer.setIsTurnMe(!!isMeFlag);

        // 輪到自己
        if (isMeFlag) {
            // 撥放音效
            this.runAction(cc.sequence(
                cc.delayTime(0.5),
                cc.callFunc(function () {
                    MusicUtility.playEffect("Music/Effect/e_youturn.mp3");
                })
            ));

            // 判斷是否要震動
            if (DataModal.settingData.remi.vibrateWhenTurnSelf && cc.sys.isNative) {
                cc.Device.vibrate(0.2);
            }

            // 輪到自己要把Dialog關掉先
            DialogManager.cleanAllDialog();

            // 關掉聊天視窗
            GS.dispatchCustomEvent("NotifyCloseChatRoomLayer");
        }
    },

    /**
     * 開始結算比牌的動畫
     */
    // 進行開場動畫
    _processingStartAnim: function (passTime = 0) {
        if (passTime > 0.5) {
            // 時間已經過了的話就跳過
            var newPassTime = passTime - 2.5;
            if (newPassTime) {
                this._processingNormalFight(newPassTime);
            } else {
                this.runAction(cc.sequence(
                    cc.delayTime(2.5 - passTime),
                    cc.callFunc(() => {
                        this._processingNormalFight();
                    })
                ));
            }
        } else {
            // 演開場動畫
            this._animationLayer.showStartFight();
            // 動畫結束
            this.runAction(cc.sequence(
                cc.delayTime(2.5 - passTime),
                cc.callFunc(() => {
                    this._processingNormalFight();
                })
            ));
        }
    },

    // 進行一般比牌
    _processingNormalFight: function (passTime = 0) {
        var posArray = [];
        this._playingPlayers.forEach(cur => {
            if (this._specialArray.indexOf(cur) === -1)
                posArray.push(cur);
        });

        if (!posArray.length) {
            // 沒有普通牌就直接跳過(其實應該直接跳到演特殊牌的，但照順序跑比較不會亂掉)
            this._processingStrike(0);
        } else {
            if (passTime) {
                // 時間已經過了的話就跳過直接開牌跟顯示分數
                var newPassTime = passTime - 2.25;
                this._cardsLayer.showAllCardSkipAnimation(posArray);
                this._scoreLayer.showNormalFightAllScore(posArray, this._normalScoreArray, this._mySpScore, this._isSpecial, true);
                if (newPassTime) {
                    this._processingStrike(0, newPassTime);
                } else {
                    // 動畫結束
                    this.runAction(cc.sequence(
                        cc.delayTime(2.25 - newPassTime),
                        cc.callFunc(() => {
                            this._processingStrike(0);
                        })
                    ));
                }
            } else {
                // 開始演普通比牌的動畫
                this._cardsLayer.showNormalCardFighting(posArray);
                this._animationLayer.showNormalFighting(posArray, this._cardTypeArray, this._normalScoreArray);
                this._scoreLayer.showNormalFightAllScore(posArray, this._normalScoreArray, this._mySpScore, this._isSpecial);

                // 動畫結束
                this.runAction(cc.sequence(
                    cc.delayTime(2.25),
                    cc.callFunc(() => {
                        this._processingStrike(0);
                    })
                ));
            }
        }
    },

    // 進行打槍
    _processingStrike: function (idx, passTime = 0) {
        var strikeParamArray = this._strikeParamArray;
        if (idx >= strikeParamArray.length) {
            // 沒資訊直接跳過
            this._processingHomerun(passTime);
        } else {
            var strikeParam = strikeParamArray[idx];
            var winDir = DataModal.gameData.getDirectionByServerDirection(strikeParam.winServerDir);
            var loseDir = DataModal.gameData.getDirectionByServerDirection(strikeParam.loseServerDir);
            if (passTime) {
                // 時間已經過了的話就跳過只更新總分顯示
                this._scoreLayer.updateTotalScoreByDirection(winDir, strikeParam.winnerTotalScore);
                this._scoreLayer.updateTotalScoreByDirection(loseDir, strikeParam.loserTotalScore);

                // 扣掉這次應該有的動畫4秒
                var newPassTime = passTime - 4;
                if (newPassTime)
                    this._processingStrike(idx + 1, newPassTime);
                else {
                    this.runAction(cc.sequence(
                        cc.delayTime(passTime),
                        cc.callFunc(() => this._processingStrike(idx + 1))
                    ));
                }
            } else {
                // 打槍動畫
                this._animationLayer.showStrikeAnim(winDir, loseDir);

                this.runAction(cc.sequence(
                    cc.delayTime(3),
                    cc.callFunc(() => {
                        // 更新總分顯示
                        this._scoreLayer.updateTotalScoreByDirection(winDir, strikeParam.winnerTotalScore);
                        this._scoreLayer.updateTotalScoreByDirection(loseDir, strikeParam.loserTotalScore);
                    }),
                    cc.delayTime(1),
                    cc.callFunc(() => {
                        this._processingStrike(idx + 1);
                    })
                ));
            }
        }
    },

    // 進行全壘打
    _processingHomerun: function (passTime = 0) {
        if (!this._homeRunInfo) {
            // 沒資訊直接跳過 進特殊比牌
            this._processingSpecialFight(passTime);
        } else {
            if (passTime > 2.5) {
                // 時間已經過了的話就跳過
                var newPassTime = passTime - 6.5;
                this._scoreLayer.updateHomeRunScore(this._homeRunInfo);
                if (newPassTime)
                    this._processingSpecialFight(newPassTime);
                else {
                    this.runAction(cc.sequence(
                        cc.delayTime(passTime),
                        cc.callFunc(() => this._processingSpecialFight())
                    ));
                }
            } else {
                var newPassTime = 2.5 - passTime;
                var canAnime = (passTime > 0);
                this._animationLayer.showHomeRunAnimation(this._homeRunInfo, canAnime);
                // 動畫結束
                this.runAction(cc.sequence(
                    cc.delayTime(1.5 + newPassTime),
                    cc.callFunc(() => this._scoreLayer.updateHomeRunScore(this._homeRunInfo)),
                    cc.delayTime(2.5),
                    cc.callFunc(() => {
                        this._processingSpecialFight();
                    })
                ));
            }
        }
    },

    // 進行特殊比牌
    _processingSpecialFight: function (passTime = 0) {
        if (!this._specialArray.length) {
            this._updateFinishScore();
        } else {
            if (passTime) {
                this._scoreLayer.showSpecialScore(this._specialArray, this._totalScoreArray);
                // 動畫結束
                this.runAction(cc.sequence(
                    cc.delayTime(passTime),
                    cc.callFunc(() => {
                        this._updateFinishScore();
                    })
                ));
            } else {
                this._cardsLayer.showSpecialFighting(this._specialArray);
                this._animationLayer.showSpecialFighting(this._specialArray, this._cardTypeArray);

                // 動畫結束
                this.runAction(cc.sequence(
                    cc.delayTime(1.5),
                    cc.callFunc(() => {
                        this._scoreLayer.showSpecialScore(this._specialArray, this._totalScoreArray);
                    }),
                    cc.delayTime(0.5),
                    cc.callFunc(() => {
                        this._updateFinishScore();
                    })
                ));
            }
        }
    },

    // 結算 總分
    _updateFinishScore: function () {
        // 不管怎樣都顯示牌 跟 總分
        this._cardsLayer.showAllCardSkipAnimation(this._playingPlayers);
        this._scoreLayer.updateAllPlayersScore(this._playingPlayers, this._totalScoreArray);
        this.runAction(cc.sequence(
            cc.delayTime(1.5),
            cc.callFunc(() => {
                this._isFinishing = false;
                this._enableProcessMessage = true;
                // 做完動畫了 重新抓cmd
                this.notifyEnableProcessMessage();
            })
        ));
    },

    // 斷線重連已經在比牌中 就開始算時間
    _current_fighting: function (leftTime, foulhand) {
        if (foulhand)
            this._playersLayer.showFoulhandByServerPos(foulhand, false);

        // "start": 2.5,	// 必須
        // "normal": 2.25,
        // "strike": 4*n,	// 多一次多4秒，以|區別有幾次
        // "homerun": 6.5,
        // "special": 2.5,
        var animTotalTime = 2.5;

        // 普通比牌
        var hasNormal = this._playingPlayers !== this._specialArray;
        if (hasNormal)
            animTotalTime = 2.25;

        // 打槍動畫
        var strikeLength = this._strikeParamArray.length;
        var strikeTime = 0;
        if (strikeLength)
            strikeTime = 4 * strikeLength;
        animTotalTime += strikeTime;

        // 全壘打動畫
        if (this._homeRunInfo)
            animTotalTime += 6.5;

        // 特殊比牌
        if (this._specialArray.length)
            animTotalTime += 2.5;

        // 計算經過時間
        var passTime = animTotalTime - leftTime;
        // 開始執行結算動畫
        this._processingStartAnim(passTime);
    },

    /**
     * 通知 開始處理Socket CMD
     */
    notifyGameProcessCMD: function (event) {
        if (this._enableProcessMessage)
            this.processMessage();
    },

    /**
     * 開啟處理Socket CMD
     */
    notifyEnableProcessMessage: function (event) {
        this._enableProcessMessage = true;
        while (this.processMessage() && this._enableProcessMessage) {
        }
    },

    /**
     * 按"更換房間"按鈕
     */
    notifyGameUIChangePlaceClicked: function (event) {
        // Dialog提示
        var dialog = new SimpleDialog(LocalizedString.Game("更換牌桌中 請稍候..."));
        dialog.key = "ReplaceRoomDialog";
        DialogManager.addDialog(dialog);

        //設定參數
        this._isReplaceingRoom = true;
        this._isReplacedRoom = true;

        var eventObject = event.getUserData();
        var isToSmallTable = false;
        if (eventObject) {
            isToSmallTable = eventObject.isToSmallTable;
        }

        // 送出 (統一送quickJoinP就好)
        if (isToSmallTable)
            DataProcess.sendString("quickJoinP");
        else
            DataProcess.sendString("quickJoinP " + DataModal.gameData.anteValue);

        // 刮刮卡暫停
        DataModal.scratchCardData.stopCountDown();
    },

    /**
     * 按下左上UI返回大廳按鈕回Lobby
     */
    notifyGameUIBackToLobbyClicked: function (event) {
        DataProcess.sendString("toLobby");

        // 加Loading檔掉
        GSLoading.addLoadingView();
    },

    // 收到開始遊戲的CMD
    notifyStartGame: function () {
        // 清空東西
        this._cleanGameLayerData(false);
        this._resetGameLayerData();

        // 清掉畫面
        this._playersLayer.cleanData();

        // 重置外觀
        this._optionUILayer.clean();
        this._playersLayer.cmd_OLEH();
        this._uiLayer.cmd_OLEH();
        this._bgLayer.cmd_OLEH();
        this._gameHintLayer.clean();
        this._animationLayer.clean();
        this._cardsLayer.clean();
        this._optionUILayer.clean();

        this._isFinishing = false;

        // 清掉Dialog
        DialogManager.cleanAllDialog();

        // 設定可以讀取Socket
        this._enableProcessMessage = true;
    },

    // 可以開始重現牌局了
    notifyUpdateCurrentSeatDone: function () {
        this._cardsLayer.current_playing_fighting(this._specialArray);
        var leftTime = this._currentFightInfo.fightOverTime;
        var socketTime = this._currentFightInfo.socketTime;
        var nowTime = new Date().getTime() / 1000;
        var newLeftTime = leftTime - (nowTime - socketTime);
        var foulhand = this._currentFightInfo.foulhand;
        if (newLeftTime) {
            this._current_fighting(newLeftTime, foulhand);
        } else {
            this._current_fighting(0.5, foulhand);
        }
    }
});