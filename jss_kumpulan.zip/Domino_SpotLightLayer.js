var Domino_SpotLightLayer = cc.Layer.extend({

    ctor: function () {
        this._super();

        this._lightServerSitNum = 0;
        this._isStoped = false;

        var spot = this._spotLightSprite = new cc.Sprite("#game_pic_focus.png");
        spot.setScale(3);
        spot.setAnchorPoint(cc.p(1, 0.5));
        spot.setPosition(JSScreenMidPos);
        spot.setVisible(false);
        this.addChild(spot);

        //事件
        GS.addListener("NotifyGameTurnPositionFinish", this.notifyGameTurnPositionFinish.bind(this), this);
    },

    cleanData: function () {
        this.stop();
    },

    stop: function () {
        this._isStoped = true;
        this._spotLightSprite.setVisible(false);
        this._spotLightSprite.stopAllActions();
    },

    //sitNum是畫面上的位置
    play: function (serverSitNum) {
        this._isStoped = false;
        this._lightServerSitNum = serverSitNum;
        var rotation = 0;
        var scale = 0;
        var sitNum = DataModal.gameData.getDirectionByServerDirection(serverSitNum);
        switch (sitNum) {
            case 0:
                rotation = 300;
                scale = 1.5;
                break;
            case 1:
                rotation = 340;
                scale = 2.4;
                break;
            case 2:
                rotation = 5;
                scale = 3;
                break;
            case 3:
                rotation = 45;
                scale = 1.8;
                break;
            case 4:
                rotation = 135;
                scale = 1.8;
                break;
            case 5:
                rotation = 175;
                scale = 3;
                break;
            case 6:
                rotation = 195;
                scale = 2.4;
                break;
            default:
                rotation = 0;
                scale = 0;
                break;
        }
        this._spotLightSprite.setVisible(true);
        this._spotLightSprite.stopAllActions();
        this._spotLightSprite.runAction(cc.spawn(
            cc.fadeIn(0.2),
            cc.rotateTo(0.2, rotation),
            cc.scaleTo(0.2, scale))
        );
    },

    /**
     * 換位置時自已轉到畫面上0的位置結束時觸發,修改SpotLight的位置
     * @private
     */
    notifyGameTurnPositionFinish: function () {
        if (this._isStoped)
            return;
        this.play(this._lightServerSitNum);
    }
});