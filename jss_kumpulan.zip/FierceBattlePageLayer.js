/**
 * 5.4.0 副系統 - 激戰任務分頁Layer 玩法切換會刷新這裏
 * created by Jim.Chen
 */

var FierceBattlePageLayer = cc.Layer.extend({
    ctor: function (pageParam) {
        this._super();
        this._pageParam = pageParam;        // 該時段排行資料
        this._pressedBtn = undefined;       // 紀錄被按下的scrollBtn 用來關閉顯示的 RankLayer

        var mainNode = this._mainNode = new cc.Node();
        this.addChild(mainNode);

        // 時段選單
        {
            var periodScrollView = new cc.ScrollView(cc.size(85, 180));
            periodScrollView.setPosition(85 + JSScreenBonusHalfWidth, 29 + JSScreenBonusHalfHeight);
            periodScrollView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
            mainNode.addChild(periodScrollView);

            // 擋touch 要避開推播按鈕
            var topDummyTouchLayer = new DummyTouchLayer(cc.size(85, JSVisibleSize.height - 235 - JSScreenBonusHalfHeight), false);
            topDummyTouchLayer.setPosition(85 + JSScreenBonusHalfWidth, 235 + JSScreenBonusHalfHeight);
            mainNode.addChild(topDummyTouchLayer);

            topDummyTouchLayer = new DummyTouchLayer(cc.size(30, 30), false);
            topDummyTouchLayer.setPosition(85 + JSScreenBonusHalfWidth, 210 + JSScreenBonusHalfHeight);
            mainNode.addChild(topDummyTouchLayer);

            topDummyTouchLayer = new DummyTouchLayer(cc.size(30, 30), false);
            topDummyTouchLayer.setPosition(137 + JSScreenBonusHalfWidth, 210 + JSScreenBonusHalfHeight);
            mainNode.addChild(topDummyTouchLayer);

            var bottomDummyTouchLayer = new DummyTouchLayer(cc.size(85, 29 + JSScreenBonusHalfHeight), false);
            bottomDummyTouchLayer.setPosition(85 + JSScreenBonusHalfWidth, 0);
            mainNode.addChild(bottomDummyTouchLayer);
        }

        // 判斷是否可以移動
        var periodPageList = pageParam.eventList;
        var periodPageListLen = periodPageList.length;
        periodScrollView.setTouchEnabled(periodPageListLen > 5);

        // 加換頁按鈕
        var gapHeight = 1;                      // 按鈕間隙
        var totalContentSizeHeight = gapHeight; // 按鈕總高
        var btnSize = cc.size(80, 34);          // 按鈕尺寸

        // 逐一建立scrollView按鈕
        var buttonArray = [];
        this._periodButtons = [];
        var periodScrollViewContainer = periodScrollView.getContainer();
        for (var i = 0; i < periodPageListLen; i++) {
            var periodButton = this._periodButtons[i] = new FierceBattlePeriodButton(btnSize, periodPageList[i]);
            periodButton.addTouchUpInsideAction(this._periodBtnClicked, this);
            periodButton.setAnchorPoint(0, 0);
            periodScrollViewContainer.addChild(periodButton);
            buttonArray.push(periodButton);
            totalContentSizeHeight += (btnSize.height + gapHeight);
        }

        // 設定ScrollView的大小
        periodScrollView.setContentSize(cc.size(85, totalContentSizeHeight));
        //設定offset到最高點
        periodScrollView.setContentOffset(cc.p(0, periodScrollView.getViewSize().height - periodScrollView.getContentSize().height));

        // 重新對位
        buttonArray.forEach(cur => {
            totalContentSizeHeight -= (btnSize.height + gapHeight);
            cur.setPositionY(totalContentSizeHeight);
        });

        // 預設點哪一個活動 預設為第一個
        this._tapIndex = (pageParam.defaultOpenPeriodIndex) ? pageParam.defaultOpenPeriodIndex : 0;
        this._periodButtons[this._tapIndex] && this._periodBtnClicked(this._periodButtons[this._tapIndex]);
    },

    /**
     * 分頁 sender 為 FierceBattlePeriodButton
     * 用sender.page 存個別的 FierceBattleRankLayer
     */
    _periodBtnClicked: function (sender) {
        // 把與目前按鈕對應的pageLayer關掉 確保切換頁籤時也能清乾淨
        this._pressedBtn && this._pressedBtn.page.setVisible(false);
        this._pressedBtn = sender;

        // 逐一更新按鈕狀態
        var btnLen = this._periodButtons.length;
        for (var i = 0; i < btnLen; i++) {
            var btn = this._periodButtons[i];
            var findIt = sender === btn;

            // 選到的按鈕設成不能按
            btn.setEnabled(!findIt);
            // 把Page關掉
            btn.page && btn.page.setVisible(findIt);
        }

        // 顯示畫面
        if (!sender.page) {
            var mainNode = this._mainNode;
            var page = sender.page = new FierceBattleRankLayer(this._pageParam.gameType, sender.pageParam);
            mainNode.addChild(page);
        }
    }
});