/**
 * 小紅點 可以傳要用哪一個圖片
 */

var BadgeNode = cc.Node.extend({
    ctor: function (imageName) {
        this._super();

        imageName = imageName || "lobby_prompt_bg.png";

        this.setCascadeColorEnabled(true);
        this.setCascadeOpacityEnabled(true);

        // 創一個空的 之後做動畫靠他
        var moveNode = this._moveNode = new cc.Node();
        moveNode.setCascadeColorEnabled(true);
        moveNode.setCascadeOpacityEnabled(true);
        this.addChild(moveNode);

        var bgSprite = this._bgSprite = new ccui.Scale9Sprite(imageName);
        // 變寬時的設定(寬度奇數取中間一個pixel 偶數取中間2個pixel)
        bgSprite.setCapInsets(cc.rect(Math.floor((bgSprite.width - 1) / 2), 0, 2 - bgSprite.width % 2, bgSprite.height));
        moveNode.addChild(bgSprite);
        // 圖片原始大小
        this._bgSpriteContentSize = this._bgSprite.getContentSize();

        var textLabel = this._textLabel = new cc.LabelTTF("", JSFontBoldName, 10);
        cc.sys.isNative && textLabel.setPositionY(-0.25);    // 原生調整下面一點
        moveNode.addChild(textLabel);

        this.setVisible(false);
    },

    // 給String
    setString: function (str) {
        if (str && str.length > 0) {
            this.setVisible(true);

            var textLabel = this._textLabel;
            textLabel.setString(str);

            var bgSize = this._bgSpriteContentSize;
            var textWidth = textLabel.getContentSize().width;

            // 自動調整背景圖大小，如果文字超過背景原始大小就把背景拉寬
            // 為了讓bonusWidth符合視覺的需求，-6是依照肉眼去調整的
            // Domino移植設定 調整寫法
            var bonusWidth = bgSize.width - 6;
            this._bgSprite.setPreferredSize(cc.size(Math.max(bgSize.width, textWidth + bonusWidth), bgSize.height));
        } else {
            this.setVisible(false);
        }
    },

    // 給數字
    setNumber: function (num) {
        if (num > 0)
            this.setString(num.toString());
        else
            this.setVisible(false);
    },

    // 加上額外圖檔
    setAdditionalSpriteBySpriteName: function (spName) {
        var moveNode = this._moveNode;

        var additionalSprite = new cc.Sprite(spName);
        moveNode.addChild(additionalSprite);

        if (spName && spName.length > 0)
            this.setVisible(true);
        else
            this.setVisible(false);
    },

    /**
     * 使用預設樣式
     */
    useDefaultStyle: function () {
        let moveNode = this._moveNode;

        let additionalSprite = new cc.Sprite("#lobby_prompt_ExclamationMark.png");
        moveNode.addChild(additionalSprite);
    },

    /**
     * 動畫
     */
    // 撥放動畫
    playAnim: function () {
        this.stopAllActions();
        this._moveNode.setPosition(0, 0);

        var action1 = cc.jumpBy(0.5, cc.p(0, 0), 5, 1);
        var action2 = cc.delayTime(1);
        this.runAction(cc.repeatForever(cc.sequence(action1, action2)));
    },

    // 停止動畫
    stopAnim: function () {
        this.stopAllActions();
        this._moveNode.setPosition(0, 0);
    }
});