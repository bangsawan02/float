/**
 * 依據時間跑動大數字的工具
 * <br>
 * 用法:
 * 因為他不是node, 所以會需要在使用到的node手動去做update
 * </br>
 * ```js
 * let bigNumberRunner = new GSBigNumberRunner();
 *
 * this.schedule((dt) => {
 *     bigNumberRunner.update(dt);
 *     // 使用 bigNumberRunner.getNowNumber() 取得目前數字字串
 *     // ...
 *     })
 * ```
 * created by terry.chuang 2025/7/2
 */
var GSBigNumberRunner = cc.Class.extend({
    ctor: function () {
        // 大數運算時，數字皆以字串儲存
        this._targetNumber = "0";
        this._nowNumber = "0";
        this._startNumber = "0";
        this._numberDiff = "0";
        // 時間相關
        this._duration = 0;
        this._usedTime = 0;

        // 回調函式
        this._numberChangeCallback = undefined;
        this._numberUpdateDoneCallback = undefined;
    },

    /**
     * 設定數字變化的回調
     * @param {(string) => void} callback
     */
    setNumberChangeCallback: function (callback) {
        this._numberChangeCallback = callback;
    },

    /**
     * 設定數字更新完成的回調
     * @param {(string) => void} callback
     */
    setNumberUpdateDoneCallback: function (callback) {
        this._numberUpdateDoneCallback = callback;
    },

    /**
     * 設定更新時間, 向下相容
     * @param {number} updateTime
     */
    setUpdateTime: function (updateTime) {
        this.setDuration(updateTime);
    },

    /**
     * 更新數字
     * @param {number} dt 經過秒數
     */
    update: function (dt) {
        if (this._duration <= 0) { return; }
        this._usedTime += dt;
        let isDone = this._usedTime >= this._duration;
        let oldNumber = this._nowNumber;
        if (isDone) {
            // 時間到，直接設定為目標數字
            this.setNowNumber(this._targetNumber);
            // 最後會去處理停止更新
        } else {
            // 計算目前的數字
            let percent = (Math.min(1, this._usedTime / this._duration)).toString();
            let increment = JSCodeUtility.bigNumberMultiply(this._numberDiff, percent);
            this.setNowNumber(JSCodeUtility.bigNumberAdd(this._startNumber, increment));
        }

        if (oldNumber !== this._nowNumber) {
            // 數字變化回調
            this._numberChangeCallback && this._numberChangeCallback(this._nowNumber);
        }
        // 完成回調
        if (isDone) {
            this._numberUpdateDoneCallback && this._numberUpdateDoneCallback(this._nowNumber);
        }
    },

    /**
     * 設定數字更新的目標和持續時間
     * @param {string} toNumber 目標數字
     * @param {number} duration 持續時間(秒)
     */
    setupRunner: function (toNumber, duration) {
        duration = JSCodeUtility.getFloatValue(duration, GSBigNumberRunner.DefaultUpdateTime);
        if (duration > 0) {
            this.setTargetNumber(toNumber);
            this.setDuration(duration);
            this._usedTime = 0;
            this._startNumber = this.getNowNumber();
            this._numberDiff = JSCodeUtility.bigNumberSub(this.getTargetNumber(), this._startNumber);
        } else {
            this.setTargetNumber(toNumber);
            this.setNowNumber(toNumber);
        }
    },

    /**
     * 直接設定目前數字
     * @param {string} nowNumber 當前數字
     */
    setNowNumber: function (nowNumber) {
        this._nowNumber = JSCodeUtility.getStringValue(nowNumber, "0");
    },

    /**
     * 設定目標數字
     * @param {string} targetNumber 目標數字
     */
    setTargetNumber: function (targetNumber) {
        this._targetNumber = JSCodeUtility.getStringValue(targetNumber, "0");
    },

    /**
     * 設定更新的持續時間
     * @param {number} duration 更新持續時間(秒)
     */
    setDuration: function (duration) {
        this._duration = JSCodeUtility.getFloatValue(duration, GSBigNumberRunner.DefaultUpdateTime);
    },

    /**
     * 取得目標數字
     * @returns {string}
     */
    getTargetNumber: function () {
        return this._targetNumber;
    },

    /**
     * 取得目前數字
     * @returns {string}
     */
    getNowNumber: function () {
        return this._nowNumber;
    },

    /**
     * 取得更新持續時間
     * @returns {number}
     */
    getDuration: function () {
        return this._duration;
    }
});
// 設定預設更新時間
GSBigNumberRunner.DefaultUpdateTime = 0.5;