/**
 * CapsaSusun_CardTypeAnimNode 牌型動畫
 * isSpecial是否是特殊牌型，type牌型，isWin分數是否>0，isScale要縮放
 **/
var CapsaSusun_CardTypeAnimNode = cc.Node.extend({
    ctor: function (isSpecial, type, isWin, isScale = true) {
        this._super();

        if (isSpecial) {
            var cardTypeName = CapsaSusun_GameUtility.getAniNameBySpecialCardType(type);
            // 特殊牌型gaf動畫
            var self = this;
            gaf.create("gaf/game/capsaSusun_specialAnim.gaf", this, true, function (gafAsset) {
                gafAsset.setRootTimelineWithName(cardTypeName);
                var gafObject = gafAsset.createObjectAndRun(false);
                self.addChild(gafObject);
            });

            // 等待3秒之後 往上移動
            if (isScale) {
                this.runAction(cc.sequence(
                    cc.delayTime(1),
                    cc.spawn(
                        cc.scaleTo(0.3, 0.8, 0.8),
                        cc.moveBy(0.3, 0, 15)
                    )
                ));
            }
        } else {
            var numType = (isWin) ? 1 : 2;
            var cardTypeName = JSStringUtility.format("#capsaSusun_word_card_type_%02d_%d.png", numType, type);
            var sp = new cc.Sprite(cardTypeName);
            this.addChild(sp);

            // 等動畫結束
            sp.runAction(cc.sequence(
                cc.delayTime(0.1),   // 出牌特效 0.5縮放 + 0.75的顯示時間
                cc.scaleTo(0.25, 1.1, 1.1),
                cc.scaleTo(0.25, 1, 1)
            ));

            // 等待0.75秒之後 自己消失
            this.runAction(cc.sequence(
                cc.delayTime(0.55),
                cc.removeSelf()
            ));
        }
    },
});