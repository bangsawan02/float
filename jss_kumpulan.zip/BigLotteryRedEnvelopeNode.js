/**
 * 9T 幸運彩票 - 紅包中獎名單 Layer
 */

var BigLotteryRedEnvelopeNode = cc.Node.extend({
    ctor: function (param) {
        this._super();

        this._param = param;

        // Domino移植設定 調整位移
        // TableView
        var tableViewSize = cc.size(380, 195 + JSScreenBonusHeight);
        var tableView = this._tableView = new cc.TableView(this, tableViewSize, new cc.Layer());
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setPositionX(JSScreenMidPos.x - 174);
        this.addChild(tableView);

        // 刷新畫面
        this._refreshView();
    },

    /**
     * 刷新畫面
     */
    _refreshView: function () {

    },

    /**
     * TableView delegate
     */

    tableCellTouched: function (table, cell) {
    },

    tableCellHighlight: function (table, cell) {
    },

    tableCellUnhighlight: function (table, cell) {
    },

    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        // 創cell
        if (cell == null)
            cell = new BigLotteryRedEnvelopeListCell();

        // 刷新cell
        cell.refreshCell(this._param[idx]);

        return cell;
    },

    numberOfCellsInTableView: function (table) {
        if (this._param)
            return this._param.length;
        else
            return 0;
    },

    tableCellSizeForIndex: function (table, idx) {
        if (this._param)
            return BigLotteryRedEnvelopeListCell.getSize(this._param[idx]);
        else
            return cc.size(0, 0);
    }
});