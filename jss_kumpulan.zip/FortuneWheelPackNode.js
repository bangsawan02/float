/**
 * 衝動儲值_加碼輪盤 Node
 */

var FortuneWheelPackNode = PurchasePackBaseNode.extend({
    ctor: function (param, closeDialogCallBack) {
        // 先做繼承的東西
        this._super(param, closeDialogCallBack);

        this._fortuneWheelString = LocalizedString.FortuneWheel;

        // 底圖Node
        var backgroundNode = this._backgroundNode = new cc.Node();
        backgroundNode.setPosition(cc.pAdd(JSScreenMidPos, cc.p(72, -10)));
        this.addChild(backgroundNode, 1);

        // 內容Node
        var contentNode = this._contentNode = new cc.Node();
        backgroundNode.addChild(contentNode, 1);

        // 說明Node 因為樣式跟別人不同 層級比別人高
        var infoNode = this._infoNode = new cc.Node();
        infoNode.setPosition(JSScreenMidPos);
        infoNode.setVisible(false);     // 先顯示內容 所以隱藏
        this.addChild(infoNode, 10);

        // 提醒Node
        var remindNode = this._remindNode = new cc.Node();
        remindNode.setPosition(0, 30);
        remindNode.setVisible(false);   // 先顯示內容 所以隱藏
        backgroundNode.addChild(remindNode, 1);

        var midPosX = JSScreenMidPos.x; // X軸中心點

        // -----底圖區-----
        {
            var pinkBgSprite = new cc.Sprite("#lobby_bg_pink01.png");
            pinkBgSprite.setScale(2);
            pinkBgSprite.setAnchorPoint(0.5, 1);
            pinkBgSprite.setPosition(midPosX, JSVisibleSize.height + 3);
            this.addChild(pinkBgSprite);

            pinkBgSprite = new cc.Sprite("#lobby_bg_pink01.png");
            pinkBgSprite.setScale(2);
            pinkBgSprite.setAnchorPoint(0.5, 0);
            pinkBgSprite.setFlippedY(true);
            pinkBgSprite.setPosition(midPosX, -3);
            this.addChild(pinkBgSprite);

            var bgMenu = this._bgMenu = new cc.Menu();
            bgMenu.setPosition(0, 0);
            this.addChild(bgMenu, 10);

            // 右上叉叉按鈕
            this._addCloseButton(cc.p(JSVisibleSize.width - 20 - JSScreenSafeWidth, JSVisibleSize.height - 20), bgMenu);
        }

        // 輪盤
        var fortuneWheel = this._fortuneWheel = new FortuneWheelPackWheelNode(param);
        fortuneWheel.setPosition(midPosX, 123 + JSScreenBonusHalfHeight);
        fortuneWheel.setSpinCallback(() => {
            // 已經砍掉了不做事
            if (this.__isDestroyed)
                return;

            // 輪盤點擊埋點
            this._isLockBackKey = true;
            this._closeBtn.setVisible(false);
            var group = this._param.group;
            DataProcess.sendString("track_new_fortune_wheel 1 " + group);
        });

        fortuneWheel.setSpinFinishCallback(() => {
            // 如果轉盤流程跑完 才放禮包物件(輪盤會縮小壓灰移動到左方)
            fortuneWheel.stopAllActions();
            fortuneWheel.runAction(cc.sequence(
                cc.spawn(
                    cc.scaleBy(0.1, 0.8),
                    cc.moveBy(0.1, -128, 0),
                    cc.tintTo(0.1, 150, 150, 150)
                ),
                cc.callFunc(this._initPack, this)
            ));

            // 把右上角的X移除
            if (this._bgMenu) {
                this._bgMenu.removeFromParent();
                this._bgMenu = undefined;
            }

            // 解開an返回
            this._isLockBackKey = false;
        });

        this.addChild(fortuneWheel);
    },

    /**
     * Android Back Key
     * override
     */
    keyBackPressed: function () {
        if (this._isLockBackKey)
            return;

        this._closeBtnClicked();
    },

    /**
     * 初始化禮包
     * @private
     */
    _initPack: function () {
        this._isShowPack = true;        // 表示在禮包區
        this._exitFlag = false;         // 紀錄要離開的flag

        var param = this._param;
        // 底圖Node
        var backgroundNode = this._backgroundNode;
        // 內容Node
        var contentNode = this._contentNode;
        // 說明Node
        var infoNode = this._infoNode;
        // 提醒Node
        var remindNode = this._remindNode;

        //-----background 底圖區(不會變化的內容)-----
        {
            // 背景
            var bgSprite = this._bgSprite = new ccui.Scale9Sprite("fortune_wheel_bg_02.png");
            bgSprite.setPreferredSize(cc.size(305, 240));
            backgroundNode.addChild(bgSprite);

            // 左邊金幣
            var coinSprite = new cc.Sprite("#fortune_wheel_coin.png");
            coinSprite.setPosition(-122, 120);
            backgroundNode.addChild(coinSprite);

            // 右邊金幣
            coinSprite = new cc.Sprite("#fortune_wheel_coin.png");
            coinSprite.setPosition(122, 120);
            coinSprite.setFlippedX(true);
            backgroundNode.addChild(coinSprite);

            // 標題字 - 好運爆棚
            var titleSprite = new cc.Sprite("#fortune_wheel_word_purchaseTitle.png");
            titleSprite.setPosition(0, 118);
            backgroundNode.addChild(titleSprite);

            // 兩側星光
            for (var i = -1; i < 2; i += 2) {
                var lightSprite = new cc.Sprite("#lobby_pic_star.png");
                lightSprite.setPosition(i * 95, 120);
                lightSprite.setScale(2);
                backgroundNode.addChild(lightSprite);
            }

            // 燈泡動畫
            var lightFrames1 = [
                cc.spriteFrameCache.getSpriteFrame("fortune_wheel_light_01.png"),
                cc.spriteFrameCache.getSpriteFrame("fortune_wheel_light_02.png")
            ];

            // 燈泡動畫2(跟1反過來而已)
            var lightFrames2 = lightFrames1.slice().reverse();

            // 放置燈泡的位置
            var posArray = [];

            // 左排燈
            for (var i = 0; i < 8; i++)
                posArray.push(cc.p(-139, 87 - i * 25));

            // 下排燈
            for (var i = 0; i < 9; i++)
                posArray.push(cc.p(-100 + i * 25, -108));

            // 右排燈
            for (var i = 0; i < 8; i++)
                posArray.push(cc.p(139, -88 + i * 25));

            // 燈泡堆
            posArray.forEach((pos, index) => {
                var light = new cc.Sprite();
                light.setPosition(pos);
                backgroundNode.addChild(light);

                light.runAction(cc.animate(new cc.Animation(index % 2 ? lightFrames1 : lightFrames2, 0.5)).repeatForever());
            });

            // 綠色箭頭
            var arrowSprite = new cc.Sprite("#fortune_wheel_greenarrow.png");
            arrowSprite.setPosition(-145, -85);
            backgroundNode.addChild(arrowSprite);

            // 按鈕
            var backgroundMenu = this._backgroundMenu = new cc.Menu();
            backgroundMenu.setPosition(0, 0);
            backgroundNode.addChild(backgroundMenu, 10);

            // 說明按鈕
            var infoBtnNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_circle_03.png", null, "#lobby_btn_pic_window_?.png");
            var infoBtn = this._infoBtn = new cc.MenuItemSprite(infoBtnNodes[0], infoBtnNodes[1], () => {
                // 淡入:說明Node 淡出:內容Node || 提醒Node
                this._runSmoothlyVisible(PurchasePackBaseNode.ShowType.INFO, infoNode, [contentNode, remindNode]);

                // 說明頁說明按鈕要隱藏
                this._setButtonVisible(infoBtn, false);
            }, this);
            infoBtn.setScale(0.8);
            infoBtn.setPosition(-120, 95);
            backgroundMenu.addChild(infoBtn);

            // 右上叉叉按鈕
            this._addCloseButton(cc.p(150, 140), backgroundMenu, () => {
                // 淡入:提醒Node 淡出:說明Node || 內容Node
                this._runSmoothlyVisible(PurchasePackBaseNode.ShowType.REMIND, remindNode, [infoNode, contentNode]);

                this._closeBtn.setVisible(false);

                // 非說明頁 說明按鈕顯示
                this._setButtonVisible(infoBtn, true);
            });
        }

        // -----content 內容區-----
        {
            // 按鈕
            var contentMenu = new cc.Menu();
            contentMenu.setPosition(0, 0);
            contentNode.addChild(contentMenu, 10);

            // 內容 param.contentInfo.content
            var topContent = new cc.LabelTTF(this._fortuneWheelString("恭喜您獲得"), JSFontBoldName, 14);
            topContent.setFontFillColor(JSColor.YELLOW3);
            topContent.setPosition(0, 80);
            contentNode.addChild(topContent);

            // 內容物
            var contentArray = param.contentInfo.contentArray;

            // 內容底
            var contentBg = new ccui.Scale9Sprite("fortune_wheel_bg_01.png");
            contentBg.setPreferredSize(cc.size(225, 124));
            contentBg.setPosition(0, 0);
            contentNode.addChild(contentBg);

            // 內容物1加錢幣
            var moneySprite = new cc.Sprite("#fortune_wheel_pic_5004.png");
            moneySprite.setScale(0.6);
            moneySprite.setPosition(-70, 26);
            contentNode.addChild(moneySprite);

            // 禮物盒
            var giftSprite = new cc.Sprite("#fortune_wheel_gift.png");
            giftSprite.setPosition(-70, -26);
            contentNode.addChild(giftSprite);

            contentArray.forEach((text, index) => {
                // 內容字 第二個文字內容太多 客製化位移
                var contentLabel = new cc.LabelTTF(text, JSFontName, 12, cc.size(140, 30), cc.TEXT_ALIGNMENT_LEFT, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
                contentLabel.setPosition(40, 26 - 54 * index);
                contentNode.addChild(contentLabel);
            });

            // 儲值按鈕
            var purchaseBtnNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", cc.size(115, 45), param.contentInfo.btn, 16, JSColor.BLACK);
            var purchaseBtn = new cc.MenuItemSprite(purchaseBtnNodes[0], purchaseBtnNodes[1], this._purchaseClicked, this);
            purchaseBtn.setPositionY(-105);
            contentMenu.addChild(purchaseBtn);
        }

        // -----info 說明區-----
        {

            // 背景
            var bgSprite = new ccui.Scale9Sprite("fortune_wheel_bg_02.png");
            bgSprite.setPreferredSize(cc.size(510, 280));
            infoNode.addChild(bgSprite);

            // 紫色底背景
            var infoBg = new ccui.Scale9Sprite("fortune_wheel_bg_01.png");
            infoBg.setPreferredSize(cc.size(460, 220));
            infoNode.addChild(infoBg);

            // 說明文字內容
            var infoMsg = new GSRichTextNode(param.info, JSFontName, 10);
            infoMsg.setPosition(0, -10);
            infoNode.addChild(infoMsg);

            // 放置燈泡的位置
            var posArray = [];

            // 上排燈
            for (var i = 0; i < 18; i++)
                posArray.push(cc.p(-215 + i * 25, 128));

            // 下排燈
            for (var i = 0; i < 18; i++)
                posArray.push(cc.p(-215 + i * 25, -125));

            // 左排燈
            for (var i = 0; i < 9; i++)
                posArray.push(cc.p(-241, 102 - i * 25));

            // 右排燈
            for (var i = 0; i < 10; i++)
                posArray.push(cc.p(241, -102 + i * 25));

            // 圍繞框框的燈泡
            posArray.forEach((pos, index) => {
                var light = new cc.Sprite(index % 2 ? "#fortune_wheel_light_01.png" : "#fortune_wheel_light_02.png");
                light.setPosition(pos);
                infoNode.addChild(light);

            });

            //----按鈕----
            var infoMenu = new cc.Menu();
            infoMenu.setPosition(0, 0);
            infoNode.addChild(infoMenu);

            // 返回按鈕
            var backBtnNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_circle_04.png", null, "#lobby_btn_back.png");
            backBtnNodes.forEach(node => node.word.setScale(0.8));

            // 返回按鈕
            var backBtn = new cc.MenuItemSprite(backBtnNodes[0], backBtnNodes[1], () => {
                // 從說明頁(info)回到內容(content)頁 重置exitFlag
                this._exitFlag = false;
                // 淡入:內容Node 淡出:提醒Node
                this._runSmoothlyVisible(PurchasePackBaseNode.ShowType.CONTENT, contentNode, infoNode);
                // 非說明頁提醒按鈕要顯示
                this._setButtonVisible(infoBtn, true);

                this._closeBtn.setVisible(true);
            }, this);
            backBtn.setPosition(-240, 128);
            infoMenu.addChild(backBtn);
        }

        // -----remind 提醒區-----
        {
            var remindMenu = new cc.Menu();
            remindMenu.setPosition(0, 0);
            remindNode.addChild(remindMenu);

            // 提醒背景
            var remindBg = new ccui.Scale9Sprite("fortune_wheel_bg_01.png");
            remindBg.setPreferredSize(cc.size(210, 124));
            remindBg.setPositionY(-21);
            remindNode.addChild(remindBg);

            // 提醒內容
            var remindMsg = new cc.LabelTTF(param.quitInfo.content, JSFontName, 12);
            remindMsg.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            remindMsg.setPosition(0, 15);
            remindNode.addChild(remindMsg);

            var chipLabel = new cc.LabelTTF(JSCodeUtility.getCurrencyString(param.quitInfo.chips), JSFontName, 20);
            chipLabel.setFontFillColor(JSColor.YELLOW3);
            chipLabel.setPosition(0, -40);
            remindNode.addChild(chipLabel);

            var chipsLabel = new cc.LabelTTF("chips", JSFontName, 14);
            chipsLabel.setFontFillColor(JSColor.YELLOW3);
            chipsLabel.setPosition(0, -55);
            remindNode.addChild(chipsLabel);

            // 提醒區下方籌碼圖
            for (var i = 0; i < 2; i++) {
                var chipSprite = new cc.Sprite("#fortune_wheel_pic_chips.png");
                chipSprite.setScale(-2 * i + 1, 1);
                chipSprite.setPosition(-105 + i * 205, -50);
                remindNode.addChild(chipSprite);
            }

            // 儲值按鈕
            var purchaseBtnNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", cc.size(95, 50), param.quitInfo.rightBtn, 16, JSColor.BLACK);
            var purchaseBtn = new cc.MenuItemSprite(purchaseBtnNodes[0], purchaseBtnNodes[1], this._purchaseClicked, this);
            purchaseBtn.setPosition(40, -135);
            remindMenu.addChild(purchaseBtn);

            // 放棄按鈕
            var giveupBtnNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_04.png", cc.size(75, 40), param.quitInfo.leftBtn, 16, JSColor.BLACK);
            var giveupBtn = new cc.MenuItemSprite(giveupBtnNodes[0], giveupBtnNodes[1], () => {
                // 埋點 放棄禮包
                DataProcess.sendString("giveup_impulse_payment " + param.productID);
                // server埋點 track_impulse_payment A B (A: 每個衝動儲值的編號, B: 0 = 放棄 1 = 儲值)
                DataProcess.sendString("track_impulse_payment 10 0");

                // 把自己關掉
                this.closePurchasePackDialog();
            }, this);
            giveupBtn.setPosition(-50, -135);
            remindMenu.addChild(giveupBtn);
        }

        this._letChildrenCascadeOpacity();
    },

    /**
     * 控制按鈕Visible
     * @param button    要控制的按鈕
     * @param isShow    是否要顯示
     * @private
     */
    _setButtonVisible: function (button, isShow) {
        if (button) {
            if (isShow) {
                button.setVisible(true);
                button.runAction(cc.fadeIn(0.15));
            } else {
                button.runAction(cc.sequence(cc.fadeOut(0.15), cc.hide()));
            }
        }
    },
    /**
     * 按下儲值 第三方出現選擇管道儲值頁面網頁
     * @private
     * @override
     */
    _purchaseClicked: function () {
        this._super();

        var param = this._param;

        if (!param)
            return;

        // 儲值按鈕埋點
        var group = param.group;
        if (param.day === 5)
            DataProcess.sendString("track_new_fortune_wheel 2 " + group);
        else if (param.day === 7)
            DataProcess.sendString("track_new_fortune_wheel 3 " + group);
        else if (param.day === 10)
            DataProcess.sendString("track_new_fortune_wheel 4 " + group);

        // 判斷是否開第三方 超過一個要開管道多選dialog
        var productList = param.productIDList;

        if (productList.length === 1)
            // 只有一個 送儲值
            DataModal.purchaseData.sendPurchase(productList[0]);
        else if (productList.length > 1)
            // 一個以上開選擇dialog
            DialogManager.addDialog(new ProviderChooseDialog(param), false);
    },

    /**
     * 儲值成功, 放要顯示的畫面
     */
    purchaseSuccess: function () {
        this._super();

        this._isLockBackKey = true;

        // 把自己關掉
        var param = this._param;

        // 內容Node
        var contentNode = this._contentNode;

        // 淡入:內容Node 淡出:提醒Node(因為能儲值的地方只有內容&提醒Node所以只需要隱藏提醒Node)
        this._runSmoothlyVisible(PurchasePackBaseNode.ShowType.CONTENT, contentNode, this._remindNode);

        // 移除背景按鈕
        this._backgroundMenu && this._backgroundMenu.removeAllChildren();
        this._infoBtn = undefined;

        // -----content 內容區-----
        {
            contentNode.removeAllChildren();

            // 背景
            var contentBg = new ccui.Scale9Sprite("fortune_wheel_bg_01.png");
            contentBg.setPreferredSize(cc.size(200, 150));
            contentNode.addChild(contentBg);

            // 標題
            var contentLabel = new cc.LabelTTF(this._fortuneWheelString("儲值成功!"), JSFontName, 18);
            contentLabel.setPosition(0, 85);
            contentLabel.setFontFillColor(JSColor.YELLOW);
            contentNode.addChild(contentLabel);

            // 成功訊息
            var successMsg = new GSRichTextNode(param.rewardInfo.content, JSFontName, 16);
            successMsg.setHAlignmentToCenter(true);
            contentNode.addChild(successMsg);

            // 按鈕
            var contentMenu = new cc.Menu();
            contentMenu.setPosition(0, 0);
            contentNode.addChild(contentMenu, 10);

            var confirmBtnNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", cc.size(115, 45), param.rewardInfo.btn, 16, JSColor.BLACK);
            var confirmBtn = new cc.MenuItemSprite(confirmBtnNodes[0], confirmBtnNodes[1], this.closePurchasePackDialog, this);
            confirmBtn.setPosition(0, -105);
            contentMenu.addChild(confirmBtn);
        }
    },

    /**
     * 按下主畫面關閉按鈕
     * @override
     */
    _closeBtnClicked: function () {
        // 動畫中不給按
        if (this._runningSmoothVisible)
            return;

        if (this._isShowPack) {
            if (this._exitFlag) {
                // 在remindNode 又點X 表示真的要離開了
                this.closePurchasePackDialog();
            } else {
                // 第一次按到x 到提醒區(remindNode)
                this._exitFlag = true;
                // 淡入:提醒Node 淡出:說明Node || 內容Node
                this._runSmoothlyVisible(PurchasePackBaseNode.ShowType.REMIND, this._remindNode, [this._infoNode, this._contentNode]);
                // 非說明頁 說明按鈕顯示
                this._setButtonVisible(this._infoBtn, true);
            }
        } else {
            // 跳提示Dialog
            DialogManager.addDialog(new Dialog({
                content: this._fortuneWheelString("別浪費你的好運氣!\n小幫手自動幫您旋轉喔!"),
                buttons: [this._fortuneWheelString("OK")],
                closeButton: false,
                callback: () => {
                    // 已經砍掉了不做事
                    if (this.__isDestroyed)
                        return;

                    // 轉轉輪
                    this._fortuneWheel.spinWheel();
                    this._closeBtn.setVisible(false);
                }
            }), false);
        }
    }
});