/**
 * v5.5.4 Gaple優化 - 牌桌內每日任務的icon
 * create by lichieh on 2023/7/27
 */
var DailyMissionGameButton = GSControlButton.extend({
    ctor: function (isGaple) {
        var btnSize = (isGaple) ? cc.size(26, 26) : cc.size(28, 28);
        this._super(undefined, btnSize);

        this.key = "DailyMissionGameButton";

        this._midPos = cc.p(btnSize.width / 2, btnSize.height / 2);

        var contentNode = this._contentNode;

        if (isGaple) {
            // Gaple牌桌的UI不一樣
            // 背景
            var bgSprite = new ccui.Scale9Sprite("gaple_btn_01_1.png");
            bgSprite.setPreferredSize(btnSize);
            contentNode.addChild(bgSprite);

            // Icon
            contentNode.addChild(new cc.Sprite("#gaple_pic_daily.png"));

            // 小紅點
            var badge = this._badge = new BadgeNode();
            badge.useDefaultStyle();
            badge.setScale(0.7);
            badge.setPosition(11, 9);
            contentNode.addChild(badge);
        } else {
            // 背景
            contentNode.addChild(new cc.Sprite("#lobby_btn_07.png"));
            // Icon
            contentNode.addChild(new cc.Sprite("#lobby_icon_lobbyMission.png"));

            // 小紅點
            var badge = this._badge = new BadgeNode();
            badge.useDefaultStyle();
            badge.setPosition(14, 11);
            contentNode.addChild(badge);
        }

        // 每日任務可領獎的文字
        var freeSprite = this._freeSprite = new cc.Sprite("#lobby_word_reward.png");
        freeSprite.setScale(0.8);
        freeSprite.setPosition(0, -16);
        freeSprite.setOpacity(100);
        freeSprite.runAction(cc.sequence(
            cc.fadeTo(0.6, 255),
            cc.fadeTo(0.6, 100)
        ).repeatForever());
        contentNode.addChild(freeSprite);

        // 刮刮的倒數時間
        var scratchTimeLabel = this._scratchTimeLabel = new cc.LabelTTF("--:--", JSFontBoldName, 9);
        scratchTimeLabel.setPosition(0, -20);
        scratchTimeLabel.enableStroke(JSColor.BLACK, 1);
        contentNode.addChild(scratchTimeLabel);

        // 先更新一次
        this._updateScratch();

        // 每日任務監聽事件
        GS.addListener("NotifyUpdateDailyMission", this.notifyUpdateDailyMission.bind(this), this);
        GS.addListener("NotifyUpdateDailyScratch", this.notifyUpdateDailyScratch.bind(this), this);
        GS.addListener("NotifyGameTableFunctionHint", this.notifyGameTableFunctionHint.bind(this), this);
    },

    /**
     * Override掉 外面控制按鈕的位置
     */
    setVisible: function (value) {
        this._super(value);

        // 通知刷新按鈕的位置
        GS.dispatchCustomEvent("NotifyGameUIRefreshIconContainer");
    },

    /**
     * 更新每日任務的小紅點
     */
    _checkMission: function () {
        // 每日任務有無獎勵
        var haveReward = DataModal.dailyMissionData.getActionListDialogHaveReward(DailyMissionEnum.whereType.Game);  // 每日任務有無獎勵

        // 有無刮刮卡
        var haveScratchCard = DataModal.scratchCardData.cardList.length > 0;

        this._badge.setVisible(haveReward);
        this._freeSprite.setVisible(haveReward);

        // 有獎勵 或 沒有刮刮卡 都不顯示
        this._scratchTimeLabel.setVisible(!haveReward && haveScratchCard);
    },

    /**
     * 更新刮刮卡的顯示
     */
    _updateScratch: function () {
        // 先跑一次每日任務的 判斷是否要顯示紅點
        this._checkMission();

        var scratchTimeLabel = this._scratchTimeLabel;
        scratchTimeLabel.stopAllActions();

        // 判斷是否要倒數
        var scratchData = DataModal.scratchCardData;
        if (scratchData.countdownSec > 0) {
            scratchTimeLabel.runAction(cc.repeatForever(cc.sequence(
                cc.callFunc(function () {
                    if (!DataModal.gameData.haveMe) {
                        // 假如沒有自己
                        scratchTimeLabel.setString("--:--");
                        scratchTimeLabel.stopAllActions();
                        return;
                    }

                    // 先算剩餘時間
                    var nowTime = Math.floor(new Date().getTime() / 1000);
                    var nextTime = scratchData.countdownSec - (nowTime - scratchData.receiveSocketTime);
                    if (nextTime <= 0) {
                        // 等待scratch_ready cmd
                        nextTime = 0;

                        scratchTimeLabel.setString("--:--");
                        scratchTimeLabel.stopAllActions();
                        return;
                    }

                    var min = (nextTime / 60) % 60;
                    var sec = nextTime % 60;
                    scratchTimeLabel.setString(JSStringUtility.format("%02d:%02d", min, sec));
                }, scratchTimeLabel),
                cc.delayTime(0.5)
            )));
        } else {
            // 重置時間
            scratchTimeLabel.setString("--:--");
        }
    },

    /**
     * 加提示泡泡框 時間到關閉
     */
    _showHintMsg: function (msg, time = 2) {
        if (msg && msg.length) {
            if (this._msgNode) {
                this._msgNode = undefined;
            }

            // 泡泡框
            var msgLabel = new GSRichTextNode("#!000000!#" + msg, JSFontName, 12);
            var msgLabelHalfWidth = msgLabel.getContentSize().width / 2;
            var param = {
                mainNode: msgLabel,
                style: BaseMessageNode.Style.WHITE,
                direct: BaseMessageNode.Direct.UP,
                arrowType: BaseMessageNode.ArrowType.STRAIGHT,
                arrowPadding: (msgLabelHalfWidth < 20) ? 0 : msgLabelHalfWidth - 20,
                closeCallback: () => {
                    // 拿掉泡泡框
                    if (this._msgNode) {
                        this._msgNode = undefined;
                    }
                },
                pos: this.convertToWorldSpace(cc.p(this._midPos.x, this._midPos.y - 16)),
                showTime: time
            };

            var msgNode = this._msgNode = new BaseMessageNode(param);
            msgNode.setPosition(this._midPos.x, this._midPos.y - 16);
            msgNode.show(time);
            this.addChild(msgNode, 2);
        }
    },

    /**
     * 通知
     */
    // 更新每日任務
    notifyUpdateDailyMission: function () {
        this._checkMission();
    },

    // 更新刮刮卡
    notifyUpdateDailyScratch: function () {
        this._updateScratch();
    },

    // 牌桌內功能提示
    notifyGameTableFunctionHint: function (event) {
        var hintType = event.getUserData();
        if (hintType === NewbieData.GameTableFunctionHintType.DAILY_MISSION && this.isVisible()) {
            // 泡泡框
            this._showHintMsg(LocalizedString.Game("完成任務拿獎勵!"), 3);

            // 紀錄已經跳過
            DataModal.newbieData.saveGameTableFunctionShowed(hintType);
        }
    }
});
 