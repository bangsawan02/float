/**
 * 足球機台動畫的畫面
 */

var FootballAnimationLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 檔Touch用的東西
        var dummyTouch = this._dummyTouch = new DummyTouchLayer(JSVisibleSize);
        dummyTouch.setVisible(false);
        this.addChild(dummyTouch);

        // 先預讀GAF
        // 單獨射門的動畫 要配何沒抓到球來使用
        gaf.create("vegas/football/ball.gaf", this, true, gafAsset => {
            var gafObject = this._ballGAFObject = gafAsset.createObjectAndRun(false);
            gafObject.setVisible(false);
            gafObject.pauseAnimation();
            gafObject.setPosition(JSScreenMidPos.x, 55);
            this.addChild(gafObject);

            gafObject.setAnimationStartedNextLoopDelegate(() => {
                // 把gaf停止撥放
                gafObject.pauseAnimation();
            });
        });

        // 守門員抓到球的動畫
        gaf.create("vegas/football/get.gaf", this, true, gafAsset => {
            var gafObject = this._loseGAFObject = gafAsset.createObjectAndRun(false);
            gafObject.setVisible(false);
            gafObject.pauseAnimation();
            gafObject.setPosition(JSScreenMidPos.x, 55);
            this.addChild(gafObject);
        });

        // 守門員沒抓到球的動畫
        gaf.create("vegas/football/miss.gaf", this, true, gafAsset => {
            var gafObject = this._winGAFObject = gafAsset.createObjectAndRun(false);
            gafObject.setVisible(false);
            gafObject.pauseAnimation();
            gafObject.setPosition(JSScreenMidPos.x, 55);
            this.addChild(gafObject, 1);
        });
    },

    /**
     * 抓取射球的動畫對應到的編號
     */
    _getShotAnimationParam: function (direction) {
        var seq, isFlipped;
        switch (direction) {
            case FootballLayer.Direction.UP:
                seq = 1;
                isFlipped = false;
                break;
            case FootballLayer.Direction.DOWN_LEFT:
                seq = 3;
                isFlipped = false;
                break;
            case FootballLayer.Direction.DOWN_RIGHT:
                seq = 3;
                isFlipped = true;
                break;
            case FootballLayer.Direction.UP_LEFT:
                seq = 2;
                isFlipped = false;
                break;
            case FootballLayer.Direction.UP_RIGHT:
                seq = 2;
                isFlipped = true;
                break;
        }
        return {
            seq: seq,
            isFlipped: isFlipped,
        }
    },

    /**
     * 把動畫全部藏起來
     */
    _hideGAFAnimation: function () {
        this._loseGAFObject && this._loseGAFObject.setVisible(false);
        this._winGAFObject && this._winGAFObject.setVisible(false);
        this._ballGAFObject && this._ballGAFObject.setVisible(false);
    },

    /**
     * 創金錢的數字
     */
    _createMoneyNode: function (money) {
        // 先計算Sprite總寬度 數字高度固定為50 逗點寬26 其他寬40
        var retNode = new cc.Node();
        retNode.setCascadeOpacityEnabled(true);

        var moneyString = JSCodeUtility.getCurrencyString(money);
        var moneyLen = moneyString.length;
        var moneyPosX = 0;
        for (var i = 0; i < moneyLen; i++) {
            var moneyChar = moneyString[i];
            var isDot = (moneyChar === ",");
            var moneySprite = new cc.Sprite("#vegase_number" + moneyChar + ".png");
            moneySprite.setPosition(moneyPosX, isDot ? -15 : 0);
            moneySprite.setAnchorPoint(0, 0.5);
            retNode.addChild(moneySprite);

            moneyPosX += (isDot ? 16 : 30);
        }

        // 要重新對位
        var offsetX = moneyPosX / 2;
        retNode.getChildren().forEach(function (cur) {
            var originPos = cur.getPosition();
            cur.setPosition(originPos.x - offsetX, originPos.y);
        });


        return retNode;
    },

    /**
     * 撥放射門的動畫
     * @param param Socket回來的東西 可看 cmd_slot22_begin 的設定
     */
    playResultAsync: function (param) {
        return new Promise(resolve => {
            // 把檔Touch打開
            this._dummyTouch.setVisible(true);

            // 判斷輸贏
            if (param.winMoney > 0) {
                // 贏球 會有兩個動畫 人 跟 球 往不同方向飛去
                // 球的動畫
                var ballParam = this._getShotAnimationParam(param.ballDirection);
                var ballObject = this._ballGAFObject;
                ballObject.setVisible(true);
                ballObject.playSequence(JSStringUtility.format("ball_%02d", ballParam.seq));
                ballObject.setScale((ballParam.isFlipped ? -1 : 1) * 1.25, 1.25);
                ballObject.resume();

                // 因為球要蓋在人物上面 等射完後一小段時間會跑到人後面 要動態改zorder
                ballObject.setLocalZOrder(2);
                ballObject.runAction(cc.sequence(
                    cc.delayTime(0.5),
                    cc.callFunc(() => ballObject.setLocalZOrder(0))
                ));

                // 人物動畫 要跟結果不一樣的方向 隨機給他一個
                var peopleParam = this._getShotAnimationParam(param.peopleDirection);
                var gafObject = this._winGAFObject;
                gafObject.setVisible(true);
                gafObject.playSequence(JSStringUtility.format("miss_%02d", peopleParam.seq), true);
                gafObject.setScale((peopleParam.isFlipped ? -1 : 1) * 1.25, 1.25);
                gafObject.resume();

                gafObject.setAnimationStartedNextLoopDelegate(() => {
                    // 把gaf停止撥放 因為他frame會跑到下一個 就會怪怪的 所以把frame先減1
                    gafObject.setFrame(gafObject.getCurrentFrameIndex() - 1);
                    gafObject.pauseAnimation();

                    // 撥放完成了 接著撥放輸贏動畫
                    this._playWinLoseAsync(param, ballParam.seq)
                        .then(() => resolve());
                });
            } else {
                // 輸球 代表被接住
                var gafParam = this._getShotAnimationParam(param.peopleDirection);

                var gafObject = this._loseGAFObject;
                gafObject.setVisible(true);
                gafObject.playSequence(JSStringUtility.format("get_%02d", gafParam.seq), true);
                gafObject.setScale((gafParam.isFlipped ? -1 : 1) * 1.25, 1.25);
                gafObject.start();

                gafObject.setAnimationStartedNextLoopDelegate(() => {
                    // 把gaf停止撥放 因為他frame會跑到下一個 就會怪怪的 所以把frame先減1
                    gafObject.setFrame(gafObject.getCurrentFrameIndex() - 1);
                    gafObject.pauseAnimation();

                    // 撥放完成了 接著撥放輸贏動畫
                    this._playWinLoseAsync(param)
                        .then(() => resolve());
                });
            }
        });
    },

    /**
     * 出現輸贏的動畫
     * @param param Socket回來的東西 可看 cmd_slot22_begin 的設定
     * @param ballSeq
     */
    _playWinLoseAsync: function (param, ballSeq) {
        return new Promise(resolve => {
            // 先更新金錢
            DataModal.profileData.money = param.nowMoney;
            GS.dispatchCustomEvent("NotifyFootballUpdateMoney");

            var aniNode = new cc.Node();
            aniNode.setCascadeOpacityEnabled(true);
            this.addChild(aniNode, 5);

            // 背景黑底
            var bgColor = new cc.LayerColor(cc.color(0, 0, 0, 150), JSVisibleSize.width, JSVisibleSize.height);
            aniNode.addChild(bgColor);

            // 判斷輸贏
            var isWin = param.winMoney > 0;
            if (isWin) {
                // 贏的畫面
                var lightPos = [cc.p(-75, 50), cc.p(-75, 0), cc.p(-75, -50)];
                var lightRotate = [60, 90, 120];
                for (var i = 0; i < 6; i++) {
                    var isRight = i > 2;
                    var ratio = isRight ? -1 : 1;
                    var pos = lightPos[i % 3];
                    var lightSprite = new cc.Sprite("#football_pic_light.png");
                    lightSprite.setPosition((isRight ? 0 : JSVisibleSize.width) + ratio * pos.x, JSScreenMidPos.y + pos.y);
                    lightSprite.setRotation((isRight ? -1 : 1) * lightRotate[i % 3]);
                    lightSprite.setOpacity(100);
                    aniNode.addChild(lightSprite);

                    // 動畫
                    lightSprite.runAction(cc.sequence(
                        cc.fadeTo(0.5, 200),
                        cc.fadeTo(0.5, 100)
                    ).repeatForever());
                }

                // 文字背景
                var bgSprite = new ccui.Scale9Sprite("football_light_bg1.png");
                bgSprite.setPreferredSize(cc.size(JSVisibleSize.width, 100));
                bgSprite.setPosition(JSScreenMidPos);
                aniNode.addChild(bgSprite);

                // 文字 ballSeq 1 2 3 代表著難易度 要顯示不一樣的文字
                var wordSprite = new cc.Sprite(JSStringUtility.format("#football_word_win_0%d.png", ballSeq));
                wordSprite.setPosition(JSScreenMidPos.x, 166 + JSScreenBonusHalfHeight);
                aniNode.addChild(wordSprite);

                // 金錢文字
                var moneyWordNode = this._createMoneyNode(param.winMoney);
                moneyWordNode.setPosition(JSScreenMidPos.x, 116 + JSScreenBonusHalfHeight);
                aniNode.addChild(moneyWordNode);

                // 假如是中大獎 (賠率高的) 要另外的動畫
                if (ballSeq === 2) {
                    aniNode.runAction(cc.sequence(
                        cc.callFunc(() => {
                            // 下彩帶
                            for (var i = 0; i < 2; i++) {
                                var paperSprite = new cc.Sprite(JSStringUtility.format("#football_pic_paper_0%d.png", JSCodeUtility.getRandomInt(1, 2)));
                                paperSprite.setScale(0.8);
                                paperSprite.setRotation(JSCodeUtility.getRandomInt(0, 360));
                                aniNode.addChild(paperSprite);

                                // 位置
                                var width = JSCodeUtility.getRandomInt(0, JSScreenMidPos.x);
                                paperSprite.setPosition(
                                    width + (i === 0 ? 0 : JSScreenMidPos.x),
                                    JSVisibleSize.height + 5
                                );

                                // 動畫 不用砍掉 因為整個動畫秒數不多 來不及砍
                                paperSprite.setOpacity(0);
                                paperSprite.runAction(cc.fadeIn(0.2));

                                // 掉下的動畫
                                var dealtaX1 = i === 0 ? JSCodeUtility.getRandomInt(-50, -10) : JSCodeUtility.getRandomInt(-70, -30);
                                var dealtaX2 = i === 0 ? JSCodeUtility.getRandomInt(60, 100) : JSCodeUtility.getRandomInt(20, 75);
                                paperSprite.runAction(cc.sequence(
                                    cc.moveBy(0.5, cc.p(dealtaX1, -80)),
                                    cc.moveBy(0.6, cc.p(dealtaX2, -60))
                                ).repeatForever());
                            }
                        }),
                        cc.delayTime(0.04)
                    ).repeat(95));
                }

                // 撥放音效
                Vegas_MusicUtility.playEffect("Music/Effect/vegas_bonus_win.mp3");
            } else {
                // 輸的畫面
                var bgSprite = new ccui.Scale9Sprite("football_light_bg2.png");
                bgSprite.setPreferredSize(cc.size(JSVisibleSize.width, 100));
                bgSprite.setPosition(JSScreenMidPos);
                aniNode.addChild(bgSprite);

                // 文字
                for (var i = 0; i < 2; i++) {
                    var wordSprite = new cc.Sprite(JSStringUtility.format("#football_word_lose_0%d.png", i + 1));
                    wordSprite.setPosition(JSScreenMidPos.x, 166 - (i * 50) + JSScreenBonusHalfHeight);
                    aniNode.addChild(wordSprite);
                }
            }

            // 動畫
            aniNode.setOpacity(0);
            aniNode.runAction(cc.sequence(
                cc.fadeIn(0.3),
                cc.delayTime(isWin ? 3 : 0.9),
                cc.fadeOut(0.3),
                cc.callFunc(() => {
                    // 把檔Touch關掉
                    this._dummyTouch.setVisible(false);

                    // 把GAF關掉
                    this._hideGAFAnimation();

                    // resolve掉
                    resolve();
                }),
                cc.removeSelf()
            ));
        });
    },
});