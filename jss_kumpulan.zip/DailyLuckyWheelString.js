var LocalizedString = LocalizedString || {};

(function () {
    var keyValue = {
        "尚未完成任務": "Belum Menyelesaikan Misi",
        "繼續玩牌": "Lanjut bermain",
        "提醒領獎": "Notifikasi Hadiah",
        "請完成任務，才可SPIN唷!": "Selesaikan misi untuk bisa tekan SPIN!",
        "已逾期，即將幫您刷新畫面": "Waktu sudah lewat\nHalaman akan diperbarui",
        "玩牌一手，SPIN拿獎勵": "Main kartu atau gaple sekali langsung bisa SPIN & dapat hadiah!",
        "下次Spin時間：": "Waktu SPIN selanjutnya:",
        "連續完成越多天，加倍獎勵越高": "Makin banyak akumulasi jumlah hari, maka makin banyak juga bonus hadiahnya!",
        "VIP %d 最高X %d倍唷": "VIP %d berkesempatan dapat bonus %dx lipat!",
        "連續完成越多天，加倍獎勵越高。明天記得回來唷♥": "Makin banyak akumulasi jumlah hari, maka makin banyak \njuga bonus hadiahnya! Besok jangan lupa datang lagi ya♥",
        "玩牌一手就可以點spin領獎!": "Main Kartu 1x bisa langsung Spin hadiah!",
        "馬上玩": "Segera Main",
        "跳過": "Lewati"
    };

    LocalizedString.DailyLuckyWheel = function (str) {
        return USE_i18n ? (keyValue[str] || str) : str;
    };
})();
