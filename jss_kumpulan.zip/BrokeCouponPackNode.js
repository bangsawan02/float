/**
 * 破產再儲值 Node
 * param                    禮包資訊
 * closeDialogCallBack      按下關閉或成功畫面的確定要執行的callBack
 */

var BrokeCouponPackNode = PurchasePackBaseNode.extend({
    ctor: function (param, closeDialogCallBack) {
        // 先做繼承的東西
        this._super(param, closeDialogCallBack);

        // 背景
        var bgSprite = new ccui.Scale9Sprite("bg_purple.png");
        bgSprite.setPreferredSize(cc.size(380, 270));
        bgSprite.setPosition(JSScreenMidPos);
        this.addChild(bgSprite);

        // 大標題
        var titleSprite = new cc.Sprite("#broke_coupon_title.png");
        titleSprite.setPosition(JSScreenMidPos.x + 3, JSScreenMidPos.y + 90);
        this.addChild(titleSprite);

        // 左邊的畫面
        {
            // 籌碼
            var chipSprite = new cc.Sprite("#broke_coupon_chips.png");
            chipSprite.setPosition(JSScreenMidPos.x - 80, JSScreenMidPos.y - 10);
            this.addChild(chipSprite);

            // 金額排版的node
            var autoLayoutNode = new GSAutoLayoutNode();
            autoLayoutNode.setSpace(-14);
            autoLayoutNode.setPosition(JSScreenMidPos.x - 80, JSScreenMidPos.y - 55);
            this.addChild(autoLayoutNode);

            // 金額
            ["+", "4", "0", "%", "!"].forEach(cur => {
                var numberSprite = new cc.Sprite(JSStringUtility.format("#broke_coupon_number_%s.png", cur));
                autoLayoutNode.addChild(numberSprite);
            });

            // 時鐘
            var posX = JSScreenMidPos.x - 160;
            var posY = JSScreenMidPos.y - 110;
            var clockSprite = new cc.Sprite("#pic_icon_time.png");
            clockSprite.setAnchorPoint(0, 0.5);
            clockSprite.setPosition(posX, posY);
            this.addChild(clockSprite);

            // 倒數文字
            posX += clockSprite.getContentSize().width + 5;
            var label = new cc.LabelTTF(LocalizedString.PurchaseCoupon("倒數"), JSFontName, 12);
            label.setAnchorPoint(0, 0.5);
            label.setFontFillColor(JSColor.WHITE);
            label.setPosition(posX, posY);
            this.addChild(label);

            // 倒數時間
            posX += label.getContentSize().width + 5;
            var timeLabel = new GSTimeLabel("", JSFontName, 16);
            timeLabel.setFormat("%mm:%ss");
            timeLabel.setAnchorPoint(0, 0.5);
            timeLabel.setFontFillColor(cc.color(255, 100, 200));
            timeLabel.countdownSeconds(JSCodeUtility.getRemainTime(param.remainTime, param.socketTime), () => {
                // 清掉資料
                DataModal.purchaseCouponData.brokeCoupon = undefined;

                // 關掉畫面
                this.closePurchasePackDialog();
            });
            timeLabel.setPosition(posX, posY);
            this.addChild(timeLabel);
        }

        // 右邊的畫面
        {
            // 儲值文字
            var purchaseLabel = new cc.LabelTTF(JSStringUtility.format(LocalizedString.PurchaseCoupon("儲值%s\n獲得"), param.payMoney), JSFontName, 12);
            purchaseLabel.setFontFillColor(JSColor.WHITE);
            purchaseLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            purchaseLabel.setPosition(JSScreenMidPos.x + 80, JSScreenMidPos.y + 20);
            this.addChild(purchaseLabel);

            // 可得幣
            var chipLabel = new cc.LabelTTF(JSStringUtility.format("%s\nCHIPS!", param.chips), JSFontName, 18);
            chipLabel.setFontFillColor(cc.color(255, 255, 0));
            chipLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            chipLabel.setPosition(JSScreenMidPos.x + 85, JSScreenMidPos.y - 27);
            this.addChild(chipLabel);
        }

        // 關閉按鈕
        var closeBtn = ButtonUtility.createSimpleImageButton("lobby_btn_circle_04.png", undefined, "#lobby_btn_pic_window_x.png");
        closeBtn.setPosition(JSScreenMidPos.x + 175, JSScreenMidPos.y + 120);
        closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
        this.addChild(closeBtn);

        // 儲值按鈕
        var purchaseBtn = ButtonUtility.createSimpleButton("lobby_btn_01.png", cc.size(140, 50), LocalizedString.PurchaseCoupon("立刻獲得"), cc.color(78, 0, 6), 14);
        purchaseBtn.setPosition(JSScreenMidPos.x + 85, JSScreenMidPos.y - 90);
        purchaseBtn.addTouchUpInsideAction(this._purchaseClicked, this);
        this.addChild(purchaseBtn);
    },

    /**
     * 按下儲值 第三方出現選擇管道儲值頁面網頁
     * @override
     */
    _purchaseClicked: function () {
        this._super();

        var param = this._param;

        if (!param)
            return;

        // 判斷是否開第三方 超過一個要開管道多選dialog
        var productList = param.productIDList;

        if (productList.length === 1)
            // 只有一個 送儲值
            DataModal.purchaseData.sendPurchase(productList[0]);
        else if (productList.length > 1)
            // 一個以上開選擇dialog
            DialogManager.addDialog(new ProviderChooseDialog(param), false);

        // 儲值按鈕埋點
        DataProcess.sendString("broke_login_payment_click 0");
    },

    /**
     * 儲值成功, 放要顯示的畫面
     * @override
     */
    purchaseSuccess: function () {
        this._super();

        // 關掉畫面
        this.closePurchasePackDialog();
    },

    /**
     * 按下主畫面關閉按鈕
     * @override
     */
    _closeBtnClicked: function () {
        // 要跳 "破產不儲30元，再儲14&7方案"
        if (this._param.showTailor) {
            DialogManager.addDialog(new BrokeCouponTailorDialog(), false);
        }

        // 關掉畫面
        this.closePurchasePackDialog();
    },
});