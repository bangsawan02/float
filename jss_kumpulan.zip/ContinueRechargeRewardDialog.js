/**
 * 5.5.9 移植中撲 連續儲值 - 領獎的dialog
 * created by webber.chen
 */

var ContinueRechargeRewardDialog = BaseDialogLayer.extend({
    ctor: function (type, rewardMessage, callback) {
        this._super();

        this._callback = callback;
        this._dialogType = type;

        var animationLayer = this._animationLayer;

        // 背景
        var bgSprite = new ccui.Scale9Sprite("continue_recharge_bg_frame_01.png");
        bgSprite.setPreferredSize(cc.size(290, 162.5));
        bgSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y);
        animationLayer.addChild(bgSprite);

        // 標題
        var titleString = "";
        switch (type) {
            case ContinueRechargeRewardDialog.Type.free:
            case ContinueRechargeRewardDialog.Type.recharge:
                titleString = LocalizedString.ContinueRecharge("恭喜獲得");
                break;
            case ContinueRechargeRewardDialog.Type.bigPrize:
                titleString = LocalizedString.ContinueRecharge("恭喜獲得超級大獎");
                break;
        }
        var titleLabel = new cc.LabelTTF(LocalizedString.ContinueRecharge(titleString), JSFontName, 15);
        titleLabel.setFontFillColor(cc.color(255, 241, 0));
        titleLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 45);
        animationLayer.addChild(titleLabel);

        // 獎勵內文
        var rewardContentLabel = new cc.LabelTTF(rewardMessage, JSFontName, 12);
        rewardContentLabel.setHorizontalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        rewardContentLabel.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 10);
        animationLayer.addChild(rewardContentLabel);

        // 確認按鈕
        var confirmButton = ButtonUtility.createSimpleButton("lobby_btn_16.png", cc.size(95, 38.75), LocalizedString.ContinueRecharge("確定"), JSColor.WHITE, 12);
        confirmButton.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - 36);
        confirmButton.addTouchUpInsideAction(this._closeDialogAnimation, this);
        confirmButton.label.enableStroke(JSColor.OUTLINE_BLUE, 2);
        animationLayer.addChild(confirmButton);
    },
});

ContinueRechargeRewardDialog.Type = {
    free: 1,        // 免費方案的獲獎dialog
    recharge: 2,    // 儲值方案的獲獎dialog
    bigPrize: 3     // 超級大獎的獲獎dialog
};