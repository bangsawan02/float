/**
 * 用來處理加密 解密的工具
 */
var GSCrypto = {};

(function () {
    var key_256 = 'YQ1BSZ2fdhKf01JfAvVxEhDQr9mJ3R5M'.split('').map(s => s.charCodeAt());
    var randomList = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'.split('');

    /**
     * 抓取Random的字串 給字串所需的長度
     */
    var getRandomString = function (length) {
        var retString = '';
        for (var i = 0; i < length; i++)
            retString += randomList[JSCodeUtility.getRandomInt(0, 61)];

        return retString;
    };

    /**
     * 抓取AES256的加密字串
     * @param {String}  input   輸入的文字
     */
    GSCrypto.getAES256EncryptString = function (input) {
        // 判斷真正的明文 因為json encode完的東西 他最後會有個\n 要拿掉
        if (input.substr(input.length - 1) === '\n')
            input = input.substr(0, input.length - 1);

        // 其他的加密東西
        var salt1 = getRandomString(4);
        var salt2 = getRandomString(4);
        var ivString = getRandomString(16);
        var plainText = JSStringUtility.format('%d,%s%s%s', input.length, salt1, input, salt2);

        // 將文字轉換為位元組
        var textBytes = aesjs.utils.utf8.toBytes(plainText);

        // 補足長度
        textBytes = aesjs.padding.pkcs7.pad(textBytes);

        // 建立 CBC 串鏈
        var aesCbc = new aesjs.ModeOfOperation.cbc(key_256, ivString.split('').map(s => s.charCodeAt()));
        var encryptedBytes = aesCbc.encrypt(textBytes);

        return ivString + btoa(String.fromCharCode.apply(null, encryptedBytes));
    };

    /**
     * 抓取AES256的解密字串
     * @param {String}  input   輸入的文字
     */
    GSCrypto.getAES256DecryptString = function (input) {
        // 抓出IV
        var ivString = input.substr(0, 16);

        // 真正加密的地方
        input = input.substr(16);

        // 將Base64的資料轉回二進位
        var encryptedBytes = atob(input).split('').map(s => s.charCodeAt());

        // 建立 CBC 串鏈
        var aesCbc = new aesjs.ModeOfOperation.cbc(key_256, ivString.split('').map(s => s.charCodeAt()));
        var decryptedBytes = aesCbc.decrypt(encryptedBytes);

        // 將二進位資料轉換回文字
        var decryptedText = aesjs.utils.utf8.fromBytes(decryptedBytes);

        // 在把解密的文字拆開來 len,salt1.input.salt2
        var lenString = decryptedText.split(',')[0];
        var plainString = decryptedText.substr(lenString.length + 1);

        return plainString.substr(4, parseInt(lenString, 10));
    };
})();