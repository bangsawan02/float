/**
 * 通行證 單一獎勵的 node
 *
 * @example
 * Sample config: {
 *     normalRewardNormalNodeSize: cc.size(66, 66),             // 免費獎勵 node 尺寸
 *     normalRewardLuxuryNodeSize: cc.size(76, 76),             // 付費獎勵 node 尺寸
 *     normalRewardSuperNodeSize: cc.size(76, 76),              // 超級付費獎勵 node 尺寸（三通行證系統）
 *     normalRewardNormalBgFileName: "",                        // 免費獎勵背景圖檔
 *     normalRewardLuxuryBgFileName: "",                        // 付費獎勵背景圖檔
 *     normalRewardSuperBgFileName: "",                         // 超級付費獎勵背景圖檔（三通行證系統）
 *     normalRewardGlowFrame: [                                 // 獎勵框發光效果（多層 spine）
 *         {
 *              fileName: "",
 *              isLoop: true,
 *              zOrder: -1
 *         },
 *     //  ...
 *     ],
 *     normalRewardNormalFontColor: cc.color(20, 48, 102),      // 普通獎勵數量標籤顏色
 *     normalRewardLuxuryFontColor: cc.color(75, 15, 15),       // 付費獎勵數量標籤顏色
 *     normalRewardSuperFontColor: cc.color(75, 15, 15),        // 超級付費獎勵數量標籤顏色（三通行證系統）
 *     normalRewardNormalFrameFileName: "",                     // 普通獎勵框
 *     normalRewardLuxuryFrameFileName: "",                     // 付費獎勵框
 *     normalRewardSuperFrameFileName: "",                      // 超級付費獎勵框（三通行證系統）
 *     normalRewardCheckFileName: "",                           // 打勾圖檔
 *     isUseThreePassSystem: false,                             // 是否使用三通行證系統
 * }
 *
 * @param {object} config 設定
 * @param {boolean} isLuxury 是否為豪華獎勵
 * @param {boolean} isButton 是否為按鈕，印尼已經不需要 isButton，等越南也不使用時方可移除
 * @param {BasePassNormalRewardNode.Where} whereType 從哪裡 initialize
 * @param {number} passType 通行證類型 [`BasePassType.FREE`]:免費 [`BasePassType.LUXURY`]:豪華 [`BasePassType.SUPER`]:超級豪華（三通行證系統）
 */
var BasePassNormalRewardNode = GSControlButton.extend({
    ctor: function (config = {}, isLuxury = false, isButton = true, whereType = BasePassNormalRewardNode.Where.TABLE_VIEW, passType = undefined) {
        this._config = config;

        let normalNodeSize = config.normalRewardNormalNodeSize || cc.size(66, 66);
        let luxuryNodeSize = config.normalRewardLuxuryNodeSize || cc.size(66, 76);
        let superNodeSize = config.normalRewardSuperNodeSize || cc.size(66, 76);

        // 確定通行證類型
        if (passType !== undefined) {
            this._passType = passType;
            this._isLuxury = (passType === BasePassType.LUXURY || passType === BasePassType.SUPER);
        } else {
            // 向後相容：根據 isLuxury 參數設定 passType
            this._passType = isLuxury ? BasePassType.LUXURY : BasePassType.FREE;
            this._isLuxury = isLuxury;
        }

        this._isButton = isButton;
        this._whereType = whereType;
        this._isUseThreePassSystem = config.isUseThreePassSystem || false;

        // 根據通行證類型選擇節點大小
        let nodeSize = this._nodeSize;
        if (this._passType === BasePassType.FREE) {
            nodeSize = normalNodeSize;
        } else if (this._passType === BasePassType.LUXURY) {
            nodeSize = luxuryNodeSize;
        } else if (this._passType === BasePassType.SUPER) {
            nodeSize = superNodeSize;
        } else {
            nodeSize = this._isLuxury ? luxuryNodeSize : normalNodeSize;
        }
        this._nodeSize = nodeSize;

        let midPos = this._midPos = cc.p(nodeSize.width / 2, nodeSize.height / 2);

        this._frameSpine = [];

        // 根據通行證類型選擇背景圖檔
        let bgFileName;
        if (this._passType === BasePassType.FREE) {
            bgFileName = config.normalRewardNormalBgFileName || "luxyPass_pic_frame_02.png";
        } else if (this._passType === BasePassType.LUXURY) {
            bgFileName = config.normalRewardLuxuryBgFileName || "luxyPass_pic_frame_01.png";
        } else if (this._passType === BasePassType.SUPER) {
            bgFileName = config.normalRewardSuperBgFileName || config.normalRewardLuxuryBgFileName || "luxyPass_pic_frame_01.png";
        } else {
            // 向後相容
            let frameArray = [
                config.normalRewardLuxuryBgFileName || "luxyPass_pic_frame_01.png",
                config.normalRewardLuxuryBgFileName || "luxyPass_pic_frame_01.png",
                config.normalRewardNormalBgFileName || "luxyPass_pic_frame_02.png",
                config.normalRewardLuxuryBgFileName || "luxyPass_pic_frame_01.png"
            ];
            let index = (isButton << 1) + (this._isLuxury ? 1 : 0);
            bgFileName = frameArray[index];
        }

        let bgSprite = new ccui.Scale9Sprite(bgFileName);
        bgSprite.setPreferredSize(nodeSize);

        this._super(bgSprite, nodeSize);

        this.setChangeColorWhenDisabled(isButton);
        this.setChangeOpacityWhenDisabled(isButton);
        this.setPosition(midPos);
        this.enableTouchCancel(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
        this.setEnabled(isButton);
        isButton && this.addTouchUpInsideAction(this._onClick, this);

        let dummyTouchLayer = this._dummyTouchLayer = new DummyTouchLayer(nodeSize, JSDebugMode);
        dummyTouchLayer.setVisible(false);
        this.addChild(dummyTouchLayer);

        this._createView();
    },

    /**
     * 建立畫面
     */
    _createView: function () {
        this._createRewardFrame();
        this._createCheckSprite();

        this.setContentSize(this._nodeSize);

        this._createItemSprite();
        this._createItemLabel();

        // 豪華才會有鎖頭
        if (this._isLuxury) {
            this._createLock();
        }
    },

    /**
     * 建立獎勵框
     */
    _createRewardFrame: function () {
        (this._config.normalRewardGlowFrame || [
            {
                fileName: "spine/luxyPass/luxyPass_window_small_light2",
                isLoop: true,
                zOrder: -1
            },
            {
                fileName: "spine/luxyPass/luxyPass_window_small_light",
                isLoop: false,
                zOrder: 1
            }
        ]).forEach(settingObject => {
            let spinePlaceholderNode = new cc.Node();
            spinePlaceholderNode.setPosition(this._midPos);
            this.addChild(spinePlaceholderNode, parseInt(settingObject.zOrder, 10));
            this._frameSpine.push(spinePlaceholderNode);

            GSSpine.create(settingObject.fileName, 0.25, (spine) => {
                spine.setAnimation(0, "animation", settingObject.isLoop);
                spinePlaceholderNode.addChild(spine);
            });
        });

        let normalFrameFileName = this._config.normalRewardNormalFrameFileName || "luxyPass_pic_frame_04.png";
        let luxuryFrameFileName = this._config.normalRewardLuxuryFrameFileName || "luxyPass_pic_frame_03.png";
        let superFrameFileName = this._config.normalRewardSuperFrameFileName || luxuryFrameFileName;

        let frameFileName;
        if (this._passType === BasePassType.FREE) {
            frameFileName = normalFrameFileName;
        } else if (this._passType === BasePassType.LUXURY) {
            frameFileName = luxuryFrameFileName;
        } else if (this._passType === BasePassType.SUPER) {
            frameFileName = superFrameFileName;
        } else {
            // 向後相容
            frameFileName = this._isLuxury ? luxuryFrameFileName : normalFrameFileName;
        }

        let sprite = this._rewardFrameSprite = new ccui.Scale9Sprite(frameFileName);
        sprite.setPreferredSize(this._nodeSize);
        sprite.setPosition(this._midPos);
        this.addChild(sprite);
    },

    /**
     * 建立打勾圖
     */
    _createCheckSprite: function () {
        let checkSprite = this._checkSprite = new cc.Sprite("#" + (this._config.normalRewardCheckFileName || "luxyPass_pic_check.png"));
        checkSprite.setVisible(false);
        checkSprite.setScale(0.9);
        checkSprite.setPosition(this._midPos.x, this._midPos.y + 5);
        this.addChild(checkSprite, 1);
    },

    /**
     * 建立物品圖
     */
    _createItemSprite: function () {
        // 物品圖
        let itemSprite = this._itemSprite = new GSDownloadSprite();
        itemSprite.setTargetSize(cc.size(this._nodeSize.width - 20, this._nodeSize.height - 28));
        itemSprite.setPosition(this._midPos.x, this._midPos.y + 8);
        this.addChildToContentNode(itemSprite);
    },

    /**
     * 建立物品數量標籤
     */
    _createItemLabel: function () {
        let normalFontColor = this._config.normalRewardNormalFontColor || cc.color(20, 48, 102);
        let luxuryFontColor = this._config.normalRewardLuxuryFontColor || cc.color(75, 15, 15);
        let superFontColor = this._config.normalRewardSuperFontColor || luxuryFontColor;

        let fontColor;
        if (this._passType === BasePassType.FREE) {
            fontColor = normalFontColor;
        } else if (this._passType === BasePassType.LUXURY) {
            fontColor = luxuryFontColor;
        } else if (this._passType === BasePassType.SUPER) {
            fontColor = superFontColor;
        } else {
            // 向後相容
            fontColor = this._isLuxury ? luxuryFontColor : normalFontColor;
        }

        // 物品數量
        let label = this._itemLabel = new cc.LabelTTF("", JSFontName, 11);
        label.setFontFillColor(fontColor);
        label.setPosition(this._midPos.x, this._midPos.y + 16 - this._nodeSize.height / 2);
        this.addChildToContentNode(label);
    },

    /**
     * 建立鎖頭
     */
    _createLock: function () {
        let lock = this._lock = new BasePassRewardLock(BasePassRewardLock.TYPE.SPINE);
        lock.setPosition(5, this._nodeSize.height - 19);
        lock.setScale(0.72);
        this.addChild(lock);
    },

    /**
     * 設定狀態
     * @param {BasePassRewardStatus} status
     */
    _setStatus: function (status) {
        if (this._currentTokenCount < this._requiredTokenCount)
            status = BasePassRewardStatus.NOT_COMPLETE;

        // 已完成要改狀態變成暗暗的
        let isFinished = status === BasePassRewardStatus.FINISH;
        this.setEnabled(this._isButton && !isFinished);
        this._checkSprite && this._checkSprite.setVisible(isFinished);
        this._rewardStatus = status;

        // 設定閃光要不要出現
        this._setGlowingFrameVisible(status === BasePassRewardStatus.CAN_REWARD);
    },

    /**
     * 取得中點
     * @returns {cc.Point}
     */
    getMidPos: function () {
        return this._midPos;
    },

    /**
     * 指定儲值參數
     * @param {Object} productParam
     */
    setProductParam: function (productParam) {
        this._productParam = productParam;
    },

    /**
     * 從資料更新（舊版方法，保持向後相容）
     * @param {int}                     step                Step
     * @param {int}                     goal                獎勵門檻
     * @param {string}                  imgRootUrl          圖片網址根目錄
     * @param {string}                  imgFileName         圖片檔名
     * @param {int}                     rewardCount         獎勵數量
     * @param {BasePassRewardStatus}    status              獎勵狀態
     * @param {boolean}                 isHavePass          是否有通行證
     * @param {int}                     currentTokenCount   目前的代幣數量
     * @protected
     */
    _refreshByData: function (step, goal, imgRootUrl, imgFileName, rewardCount, status, isHavePass = false, currentTokenCount = 0) {
        this._currentTokenCount = currentTokenCount;
        this._requiredTokenCount = goal;
        this.step = step;

        this._refreshPicture(imgRootUrl, imgFileName);
        this._refreshLabel(rewardCount);
        this._refreshLock(isHavePass);

        // 設定狀態
        this._setStatus(status);
    },

    /**
     * 更新物品圖
     * @param {string} imgRootUrl
     * @param {string} imgFileName
     * @protected
     */
    _refreshPicture: function (imgRootUrl, imgFileName) {
        // 下載圖片
        let savePath = JSWriteablePath + "shop/" + imgFileName + ".png";
        let imgURL = imgRootUrl + imgFileName + ".png";
        this._itemSprite.refreshByImageUrl(imgURL, savePath);
    },

    /**
     * 更新數量
     * @param {int} rewardCount
     * @protected
     */
    _refreshLabel: function (rewardCount) {
        this._itemLabel.setString("x" + TexasUtility.getSimpleMoneyString(rewardCount, 1));
    },

    /**
     * 更新鎖頭
     * @param {boolean} isHavePass 是否已購買通行證
     * @protected
     */
    _refreshLock: function (isHavePass = false) {
        if (this._lock) {
            this._lock.resetSpine();
            this._lock.setVisible(!isHavePass && this._isLuxury);
        }
    },

    /**
     * 閃光動畫要不要出現
     * @param {boolean} isVisible
     */
    _setGlowingFrameVisible: function (isVisible) {
        // 發光的邊框
        this._rewardFrameSprite && this._rewardFrameSprite.setVisible(isVisible);
        this._frameSpine.forEach(spine => spine.setVisible(isVisible));
    },

    /**
     * 播放解鎖動畫
     */
    playUnlockAnimation: function () {
        if (this._lock) {
            this._dummyTouchLayer.setVisible(true);
            this._lock.setAnimation(0, "animation", false);
            this._lock.setCompleteListener(() => {
                this._lock.setCompleteListener(undefined);
                this._dummyTouchLayer.setVisible(false);
            });
        }
    },

    /**
     * 點擊
     * @param sender
     * @private
     */
    _onClick: function (sender) {

    }
});
BasePassNormalRewardNode.Where = GSEnumHelper({
    TABLE_VIEW: -1,
    NOT_CHARGE_GET_REWARD_DIALOG: -1,
});