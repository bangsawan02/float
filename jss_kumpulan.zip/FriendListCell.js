/**
 * 好友列表的Cell
 */

var FriendListCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        var midPosY = FriendListCell.HEIGHT / 2 + 3;

        // 放要變色的東西
        var mainNode = this._mainNode = new cc.Node();
        mainNode.setCascadeColorEnabled(true);
        this.addChild(mainNode);

        // 大頭照
        var photoNode = this._photoSprite = new LobbyCircleProfileNode();
        photoNode.setPosition(30, midPosY);
        photoNode.setScale(0.7);
        mainNode.addChild(photoNode);

        // 暱稱
        var nicknameLabel = this._nicknameLabel = new GSAutoSizeLabel("", JSFontBoldName, 12, cc.size(90, GameRankRankCell.HEIGHT), cc.TEXT_ALIGNMENT_LEFT, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        nicknameLabel.setAnchorPoint(0, 0.5);
        nicknameLabel.setPosition(53, midPosY);
        mainNode.addChild(nicknameLabel);

        // 個人資訊的按鈕(點大頭照&暱稱會跳出個人資訊頁)
        var profileBtn = new GSControlButton("", cc.size(147, FriendListCell.HEIGHT));
        profileBtn.setCascadeOpacityEnabled(true);
        profileBtn.addTargetWithActionForControlEvents(this, this._profileBtnClicked,
            cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
            cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
            cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
        profileBtn.setPosition(0, 0);
        profileBtn.setAnchorPoint(0, 0);
        profileBtn.enableTouchCancel(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        this.addChild(profileBtn);

        // 加入按鈕
        var joinNode = this._joinNode = new FriendJoinNode();
        joinNode.setPosition(147, 8);
        this.addChild(joinNode);

        // 聊天
        var itemNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_circle_04.png", null, "#friend_btn_chat.png");
        itemNodes.forEach(item => {
            item.bg.setScale(1.1);
            item.word.setScale(0.75);
        });
        var chatBtn = new cc.ControlButton(itemNodes[0]);
        chatBtn.setBackgroundSpriteForState(itemNodes[1], cc.CONTROL_STATE_HIGHLIGHTED);
        chatBtn.setAdjustBackgroundImage(false);
        chatBtn.setZoomOnTouchDown(false);
        chatBtn.setSwallowTouches(false);
        chatBtn.setTouchDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        chatBtn.addTargetWithActionForControlEvents(this, this._chatBtnClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        chatBtn.setPosition(276, midPosY);
        this.addChild(chatBtn);

        // 刪除
        itemNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_circle_04.png", null, "#chat_btn_delete.png");
        itemNodes.forEach(item => {
            item.bg.setScale(1.1);
            item.word.setScale(0.75);
        });
        var deleteBtn = new cc.ControlButton(itemNodes[0]);
        deleteBtn.setBackgroundSpriteForState(itemNodes[1], cc.CONTROL_STATE_HIGHLIGHTED);
        deleteBtn.setAdjustBackgroundImage(false);
        deleteBtn.setZoomOnTouchDown(false);
        deleteBtn.setSwallowTouches(false);
        deleteBtn.setTouchDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        deleteBtn.addTargetWithActionForControlEvents(this, this._deleteBtnClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        deleteBtn.setPosition(chatBtn.getPositionX() + 28, midPosY);
        this.addChild(deleteBtn);

        // 最近上線時間
        var lastOnlineLabel = this._lastOnlineLabel = new cc.LabelTTF("Online", JSFontBoldName, 10);
        lastOnlineLabel.setAnchorPoint(1, 0.5);
        lastOnlineLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_RIGHT);
        lastOnlineLabel.setPosition(370, midPosY);
        this.addChild(lastOnlineLabel);

        // 是否在線上的亮燈
        var onlineSp = this._onlineSp = new cc.Sprite("#lobby_prompt_bg4.png");
        onlineSp.setScale(0.5);
        onlineSp.setPosition(375, midPosY);
        this.addChild(onlineSp);

        // cell分隔線
        var lineSp = new ccui.Scale9Sprite("lobby_brown_line.png");
        lineSp.setPreferredSize(cc.size(357, 2));
        lineSp.setPosition(197, 4);
        this.addChild(lineSp);

        // 監聽封鎖其他玩家事件
        GS.addListener("NotifyRefreshIsForbidden", this.notifyRefreshIsForbidden.bind(this), this);
    },

    /**
     * 刷新cell
     * @param param {Object} : DataModal.friendData.friendList
     */
    refreshCell: function (param) {
        if (!param)
            return;

        // 記下userID
        this._userID = param.userID;
        this._nickname = param.nickname;
        this._UID = param.UID;
        this._photo = param.photo;

        // 暱稱
        this._nicknameLabel.setString(JSStringUtility.cutStringReplaceByEllipsis(param.nickname, 12, 136));

        // 刷新大頭貼
        this._photoSprite.setPhotoUrl(param.photo, param.userID);

        // 刷新加入桌的資料
        if (param.join) {
            this._joinNode.setVisible(true);
            this._joinNode.refreshInfo(param.join, param.userID);
        } else {
            this._joinNode.setVisible(false);
        }

        // 刷新最後上線時間
        var onlineRes = (param.isOnline) ? "lobby_prompt_bg3.png" : "lobby_prompt_bg4.png";
        this._onlineSp.setSpriteFrame(onlineRes);
        this._lastOnlineLabel.setString(param.lastOnline);
    },

    /**
     * 聊天點擊
     */
    _chatBtnClicked: function () {
        // 設定聊天室的好友UID & userID
        var obj = {
            type: ChatRoomPageType.CHAT,
            UID: this._UID,
            userID: this._userID,
            nickname: this._nickname
        };
        GS.dispatchCustomEvent("NotifyShowFriendChat", obj);

        // 更新聊天室列表的紅點
        DataModal.chatRoomData.updateChatRoomListRedPoint(this._UID, false);
    },

    /**
     * 刪除點擊
     */
    _deleteBtnClicked: function () {
        // 跳Dialog
        let friendString = LocalizedString.Friend;
        let param = {
            title: friendString("確定要將此好友刪除？"),
            photo: this._photo || "http://d.mwsrv.com/texas9/images/default_pic/photo_m-2.png",
            msg: EllipsisLabel.shortenString(this, this._nickname, JSFontBoldName, 12, 130),
            button: [friendString("取消"), friendString("確定")],
            cb: (sender) => {
                if (sender.getTag() === 1) {
                    if (!this._userID)
                        return;

                    // 卡loading TODO: 要改成新loading
                    GSLoading.addLoadingView();

                    // 刪除好友
                    var obj = {
                        userid: this._userID,
                        type: "5"
                    };
                    DataProcess.sendString("user_invite_friend " + JSON.stringify(obj));
                }
            }
        };
        DialogManager.addDialog(new FriendDialog(param));
    },

    /**
     *  個人資訊頁點擊
     */
    _profileBtnClicked: function (sender, type) {
        var isTouched = (type === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || type === cc.CONTROL_EVENT_TOUCH_DOWN);
        this._mainNode.setColor(isTouched ? JSColor.GRAY : JSColor.WHITE);

        if (type === cc.CONTROL_EVENT_TOUCH_UP_INSIDE) {
            if (!this._userID)
                return;

            DialogManager.addDialog(new ProfileDialog(this._userID));
        }
    },

    notifyRefreshIsForbidden: function (event) {
        if (event.getUserData() === this._userID) {
            this._photoSprite.setPhotoUrl(this._photo, this._userID);
        }
    },
});

// Cell高度
FriendListCell.HEIGHT = 50;