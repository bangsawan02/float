/**
 * 免費幣裡的刮刮卡
 * JSScreenBonusHalfWidth / JSScreenBonusHalfHeight在外面加了
 */

var DailyScratchLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        var bgMidSprite = new ccui.Scale9Sprite("lobby_bg_list_04.png");
        bgMidSprite.setPreferredSize(cc.size(400, 217));
        bgMidSprite.setAnchorPoint(0.5, 0);
        bgMidSprite.setPosition(295, 16);
        this.addChild(bgMidSprite);

        // Title
        var titleSprite = new cc.Sprite("#daily_scratch_word_title.png");
        titleSprite.setPosition(292, 209);
        this.addChild(titleSprite);

        // 問號按鈕
        var explainBtn = new Texas_ExplainButton();
        explainBtn.setPosition(442, 218);
        explainBtn.addTouchUpInsideAction(this._explainBtnClicked, this);
        this.addChild(explainBtn, 1);

        // TableView
        var tableView = this._tableView = new cc.TableView(this, cc.size(285, DailyScratchLayer.TABLE_VIEW_HEIGHT), new cc.Layer());
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
        tableView.setDelegate(this);
        tableView.setPosition(150, 22);
        this.addChild(tableView);

        // 擋tableView 左方的touch
        var dummyTouch = new DummyTouchLayer(cc.size(55, DailyScratchLayer.TABLE_VIEW_HEIGHT));
        dummyTouch.setPosition(95, 22);
        this.addChild(dummyTouch);

        // vip cell
        var vipCell = this._vipCell = new DailyScratchCell(true);
        vipCell.setPosition(356, 22);
        vipCell.setVisible(false);
        this.addChild(vipCell);

        // 讀取動畫
        var loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.start();
        loadingSprite.setPosition(291, 152);
        this.addChild(loadingSprite, 1);

        // 擋touch
        var dummyTouchLayer = this._dummyTouchLayer = new DummyTouchLayer(JSVisibleSize);
        this.addChild(dummyTouchLayer, 1);

        // 先刷新一次
        this._refreshView();

        // 檢查要不要不滑到後面的刮刮卡
        this._checkNeedScrollAnim();

        GS.addListener("NotifyUpdateDailyScratch", this.notifyUpdateDailyScratch.bind(this), this);
        GS.addListener("NotifyDailyScratchSendReward", this.notifyDailyScratchSendReward.bind(this), this);
        GS.addListener("NotifyDailyScratchGetReward", this.notifyDailyScratchGetReward.bind(this), this);
    },

    /**
     * 重整畫面
     */
    _refreshView: function () {
        var scratchCardData = DataModal.scratchCardData;
        var cellCount = this._totalCellCount = scratchCardData.scratchCardCount;

        // 關掉讀取
        this._setLoadingSprite(false);

        // 刷新tableView
        this._tableView.setVisible(cellCount > 0);
        cellCount > 0 && this._tableView.reloadData();

        // 刷新vipCell
        if (scratchCardData.haveVipCard) {
            this._vipCell.setVisible(true);
            this._vipCell.refreshCell(cellCount - 1);
        } else
            this._vipCell.setVisible(false);

        // 檢查是否要跳首次引導動畫
        this._checkNeedIntroAnim();
    },

    /**
     * 檢查是否需要跳首次引導動畫
     */
    _checkNeedIntroAnim: function () {
        var needIntroAnim = parseInt(GS.localStorage.getItem("DailyScratchIntroAnim", 0)) === 0;
        if (needIntroAnim) {
            // 擋touch
            var dummyTouchLayer = new DummyTouchLayer(JSVisibleSize);
            this.addChild(dummyTouchLayer);

            // 手指
            var fingerSprite = new cc.Sprite("#lobby_pic_finger3.png");
            fingerSprite.setPosition(315, 24);
            this.addChild(fingerSprite);

            // 手指動畫
            fingerSprite.runAction(cc.sequence(
                cc.delayTime(.5),                           // 停頓一下
                cc.moveBy(1, cc.p(-100, 0)),     // 移動到指定地點
                cc.delayTime(1),                            // 停頓一下
                cc.removeSelf(),                               // 拿掉自己
                cc.callFunc(function () {
                    dummyTouchLayer.removeFromParent(); // 拿掉擋touch
                })
            ));

            // 設成已看過
            GS.localStorage.setItem("DailyScratchIntroAnim", "1");
        }
    },

    /**
     * 檢查要不要滑到後面
     */
    _checkNeedScrollAnim: function () {
        // 如果解到後面的刮刮卡要滑到後面
        var index = DataModal.scratchCardData.currentIndex;
        if (index >= 2) {
            // 防呆滑超出範圍
            var posX = -index * (DailyScratchCell.WIDTH);
            this._tableView.setContentOffsetInDuration(cc.p(Math.max(posX, this._tableView.minContainerOffset().x), 0), 0.5);
        }
    },

    /**
     * 設定loading && touch
     * @param isVisible 是否要顯示
     */
    _setLoadingSprite: function (isVisible) {
        // loading
        if (isVisible) {
            // 開始loading
            this._loadingSprite.start();

            // 擋touch
            this._dummyTouchLayer.setVisible(true);
        } else {
            // 停止loading
            this._loadingSprite.stop();

            // 拿掉擋touch
            this._dummyTouchLayer.setVisible(false);
        }
    },

    /**
     * 問號按鈕
     */
    _explainBtnClicked: function () {
        var webView = new WebViewDialog(TexasUtility.getSimpleInfoURLByKey("scratchMix"), "");
        webView.key = "dailyScratchInfoWeb";
        DialogManager.addDialog(webView, false);
    },

    /**
     * 通知
     */
    // 通知有更新畫面
    notifyUpdateDailyScratch: function () {
        this._refreshView();
    },

    // 通知送領獎
    notifyDailyScratchSendReward: function (event) {
        if (event && event.getUserData()) {
            // 是哪張刮刮卡
            var index = event.getUserData().index;  // 刮刮卡index
            var type = event.getUserData().type;      // 刮刮卡是不是vip

            // 讀取動畫
            this._setLoadingSprite(true);

            // 送領獎
            var sendJson = {type: type, idx: index};
            DataProcess.sendString("scratch_mix_reward " + JSON.stringify(sendJson));
        }

    },

    // 通知收到領獎
    notifyDailyScratchGetReward: function (event) {
        var param = event.getUserData();
        if (!param)
            return;

        // 領獎失敗
        if (!param.isSuccess) {
            // 跳失敗dialog
            AlertDialog.showAlert("", param.errorMsg);
        } else {
            var tempArray = [];

            for (var i = 0, length = param.reward.length; i < length; i++) {
                // 獎勵的字串
                var rewardString = JSStringUtility.format("#!000000!#%s #!FF0000!#%s", param.reward[i].name, param.reward[i].num);

                // 塞到array
                tempArray.push(rewardString);
            }

            // 獎勵畫面
            var dialog = new RewardDialog({content: tempArray});
            DialogManager.addDialog(dialog, false); //不列入DialogManager控管
        }
        // 重要資料
        DataModal.scratchCardData.startGetInfo();
    },

    /**
     * TableView delegate
     */
    tableCellTouched: function (table, cell) {
    },

    tableCellHighlight: function (table, cell) {
    },

    tableCellUnhighlight: function (table, cell) {
    },

    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        if (cell == null) {
            cell = new DailyScratchCell();
            cell.setAnchorPoint(cc.p(0, 0));
        }
        cell.refreshCell(idx);

        return cell;
    },

    numberOfCellsInTableView: function (table) {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function (table, idx) {
        return cc.size(DailyScratchCell.WIDTH, DailyScratchLayer.TABLE_VIEW_HEIGHT);
    }
});

// 刮刮卡tableview的高度
DailyScratchLayer.TABLE_VIEW_HEIGHT = 160;