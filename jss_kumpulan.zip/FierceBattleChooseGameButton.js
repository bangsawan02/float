/**
 * 5.4.0 副系統 - 激戰任務時段按鈕
 * created by Jim.Chen
 */

var FierceBattleChooseGameButton = GSControlButton.extend({
    ctor: function (btnSize, gameParam) {
        this._super(undefined, btnSize);

        this.pageParam = gameParam;
        var contentNode = this._contentNode;

        // 選到的背景
        var selectedSprite = this._selectBgSp = new ccui.Scale9Sprite("fierceBattle_pic_line_pink.png");
        selectedSprite.setPreferredSize(cc.size(btnSize.width - 2, btnSize.height));
        selectedSprite.setVisible(false);
        contentNode.addChild(selectedSprite);

        // 文字
        var buttonWord = new cc.LabelTTF(gameParam.gameName, JSFontBoldName, 10, btnSize, cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        contentNode.addChild(buttonWord);

        // 該玩法自己的倒數，雖然不顯示，但也順便一起統一時間格式
        if (gameParam.refreshTime > 0) {
            var gameCountdownLabel = new GSTimeLabel("", JSFontBoldName, 8);
            gameCountdownLabel.setFontFillColor(JSColor.YELLOW2);
            gameCountdownLabel.setPositionY(-10);
            gameCountdownLabel.setMultiFormat("%hh:%mm:%ss", "%hh:%mm:%ss", "%hh:%mm:%ss");
            gameCountdownLabel.setVisible(false);
            gameCountdownLabel.countdownSeconds(JSCodeUtility.getRemainTime(gameParam.refreshTime, gameParam.socketTime), () => {
                // 更新資料
                DataModal.fierceBattleData.startGetInfo(gameParam.gameType);
            });
            contentNode.addChild(gameCountdownLabel);
        }

        // 自己的設定
        this.setChangeColorWhenDisabled(false);
        this.setChangeOpacityWhenDisabled(false);
        this.enableTouchCancel(cc.SCROLLVIEW_DIRECTION_VERTICAL);
    },

    setEnabled: function (enabled) {
        this._super(enabled);

        // 要改背景
        this._selectBgSp.setVisible(!enabled);
    },

    /**
     * 按到的時後 要改變顏色
     */
    _buttonClicked: function (sender, type) {
        var isTouched = (type === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || type === cc.CONTROL_EVENT_TOUCH_DOWN);
        this._mainNode.setColor(isTouched ? JSColor.GRAY : JSColor.WHITE);
    },
});