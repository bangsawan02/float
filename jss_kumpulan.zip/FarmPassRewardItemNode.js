/**
 * v5.6.5 農場 Pass - 單一獎勵的node
 */
var FarmPassRewardItemNode = BasePassNormalRewardNode.extend({
    ctor: function (config, isLuxury = false, isButton = true, whereType = BasePassNormalRewardNode.Where.TABLE_VIEW) {
        config.normalRewardNormalBgFileName = "farm_pass_pic_frame_02.png";
        config.normalRewardLuxuryBgFileName = "farm_pass_pic_frame_01.png";
        config.normalRewardNormalFrameFileName = "farm_pass_pic_frame_04.png";
        config.normalRewardNormalFontColor = cc.color(82, 58, 17);
        config.normalRewardLuxuryFontColor = cc.color(34, 74, 19);
        this._super(config, isLuxury, isButton, whereType);
    },

    /**
     * 更新資料
     * @param {object}  stageParam          階段資料
     * @param {int}     currentTokenCount   目前擁有的球數
     */
    refreshByData: function (stageParam, currentTokenCount) {
        let passParam = DataModal.farmBingoData.passData;
        let rewardParam = this._isLuxury ? stageParam.passReward : stageParam.freeReward;

        // 沒資料跳掉
        if (!stageParam || !rewardParam) {
            this.setVisible(false);
            return;
        }

        this.setVisible(true);

        let imgRootUrl = passParam.imgRootUrl;
        let imgFileName = rewardParam.picFileName;
        let rewardCount = rewardParam.count;
        let rewardStatus = rewardParam.status;
        let isHavePass = this._isHavePass = passParam.isPassUnlocked;

        this._refreshByData(stageParam.step, stageParam.goal, imgRootUrl, imgFileName, rewardCount, rewardStatus, isHavePass, currentTokenCount);
    },

    /**
     * 只更新獎勵圖片 (用於未儲值的領獎視窗，即 BasePassGetRewardCell)
     * @param rewardParam
     */
    refreshPicture: function (rewardParam) {
        // 沒資料跳掉
        if (!rewardParam) {
            this.setVisible(false);
            return;
        }

        let reward = rewardParam;
        let imgRootUrl = DataModal.farmBingoData.passData.imgRootUrl;
        let imgFileName = reward.picFileName;
        this._refreshPicture(imgRootUrl, imgFileName);
        this._refreshLabel(reward.count);
        this._refreshLock(false);
        this._setStatus(BasePassRewardStatus.CAN_REWARD);
    },


    /**
     * 按到時做的事。It will be called by BasePassNormalRewardNode.
     * @param sender
     * @private
     */
    _onClick: function (sender) {
        switch (this._whereType) {
            case BasePassNormalRewardNode.Where.NOT_CHARGE_GET_REWARD_DIALOG:
                // 從未儲值獲獎 dialog 點擊，送儲值
                DataModal.purchaseData.goPurchase(this._productParam);
                break;

            default:
                if (this._rewardStatus === BasePassRewardStatus.NOT_COMPLETE) {
                    // 未完成
                    if (!this._isLuxury || this._isHavePass) {
                        // 已解鎖
                        GS.dispatchCustomEvent("NotifyFarmPassShowDialog", {
                            type: BasePassDialogType.GET_TOKEN,
                        });
                    } else {
                        // 尚未解鎖
                        GS.dispatchCustomEvent("NotifyFarmPassShowDialog", {
                            type: BasePassDialogType.BUY_PASS,
                        });
                    }
                } else if (this._rewardStatus === BasePassRewardStatus.CAN_REWARD) {
                    // 可領獎
                    if (!this._isLuxury || this._isHavePass) {
                        // 已解鎖
                        // 加個loading
                        GS.dispatchCustomEvent("NotifyBasePassShowLoading");

                        // 去領獎
                        let cmd = JSStringUtility.format("farm_bingo_pass_reward %d %d", this._isLuxury + 1, this.step);
                        DataProcess.sendString(cmd);
                    } else {
                        // 尚未解鎖
                        GS.dispatchCustomEvent("NotifyFarmPassShowDialog", {
                            type: BasePassDialogType.BUY_PASS,
                        });
                    }
                }
        }
    }
});