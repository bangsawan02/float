/**
 *  個人手牌
 */
var CapsaSusun_HandCardLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this._hintCardTool = new CapsaSusun_HintCardTool();

        // 決策選牌UI
        var hintCardMenuLayer = this._hintCardMenuLayer = new CapsaSusun_HintCardMenuLayer(this);
        this.addChild(hintCardMenuLayer);

        var menu = this._buttonMenu = new cc.Menu();
        menu.setPosition(0, 0);
        this.addChild(menu, 1);
        menu.setVisible(false);

        // 重選按鈕
        itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_10.png", cc.size(100, 32), LocalizedString.Game("重選"), 12, JSColor.WHITE);
        var cancelItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._cancelClicked, this);
        cancelItem.setPosition(201 + JSScreenBonusHalfWidth, 42);
        menu.addChild(cancelItem);

        // 出牌按鈕
        var itemNodes = ButtonUtility.createSingleScale9Nodes("lobby_btn_01.png", cc.size(100, 32), LocalizedString.Game("確認"), 12, JSColor.WHITE);
        var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], this._sendCardClicked, this);
        menuItem.setPosition(310 + JSScreenBonusHalfWidth, 42);
        menu.addChild(menuItem);

        // 放撲克牌的node
        var cardNode = this._cardNode = new cc.Node();
        this.addChild(cardNode);

        // 下方智慧選牌清單
        var hintCardMenuBar = this._hintCardMenuBarLayer = new CapsaSusun_HintCardMenuBarLayer(this.choiceCardByArray.bind(this));
        this.addChild(hintCardMenuBar);

        // 初始化
        this.clean();

        // 加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this.onTouchBegan.bind(this),
            onTouchMoved: this.onTouchMoved.bind(this),
            onTouchEnded: this.onTouchEnded.bind(this),
            onTouchCancelled: this.onTouchCancelled.bind(this)
        }, this);
    },

    clean: function () {
        // 清掉手牌
        this.cleanHandCard();

        this._canTouch = false;                         // 是否可以選取牌
        this._isTurnMe = false;                         // 是否輪到我
        this._isSortingCard = false;                    // 是否正在重新排列
        this._isAlgorithmCardKind = false;              // 是否是快速選牌
        this._isPlayerPlaying = false;                  // 是否有放過牌(沒放過牌要跟server說)

        // 清掉點選相關參數
        this._cleanTouchFlag();

        this._buttonMenu.setVisible(false);

        this._hintCardMenuLayer.clean();

        this._hintCardTool.cleanData();
    },

    /**
     * 清除牌的資訊
     */
    cleanHandCard: function () {
        // 初始化手牌
        this._cardNode.removeAllChildren();

        this._cardArray = [];                    // 初始化放所有的牌

        this._hintCardArray = [[], [], []];      // 初始化放在牌墩的牌

        this._hintCardLenArray = [0, 0, 0];      // 初始化各墩的數量

        // 設定 還沒做過 分析推薦牌組
        this._hintCardTool.isCheckAlgorithmDown = false;

        // 清除選牌資訊
        this._cleanSelectedCardArray();
    },

    /**
     * 清除選牌資訊
     */
    _cleanSelectedCardArray: function () {
        // 初始化選取陣列
        this._selectedCardArray = [];
    },

    /**
     * 是不是正在玩(在比牌送給server 要不要被踢出去)
     */
    setPlaying: function (isPlaying) {
        this._isPlayerPlaying = isPlaying;
    },

    /**
     * 收到換牌開始
     */
    startChangeCard: function () {
        this._canTouch = true;
        this._isTurnMe = true;
    },

    /**
     * 開始比牌
     */
    startFight: function () {
        // 正在玩 不用送給server
        if (!this._isPlayerPlaying)
            return;

        // 玩家沒有在玩 要通知server 下一局會被踢出去
        DataProcess.sendString("afk_player 0");
    },

    /**
     * 加牌 可以帶單一號碼 或 Array
     * @param serverCardStrArray    {string, array} server傳來的字串(牌, 牌組)
     * @param checkAlgorithm        {boolean}       是否要分析推薦牌組
     */
    addHandCard: function (serverCardStrArray, checkAlgorithm = true) {
        if (JSCodeUtility.checkType(serverCardStrArray) !== JSTYPE.ARRAY) {
            serverCardStrArray = [serverCardStrArray];
        }

        var cardArray = this._cardArray;
        var nowCardCount = cardArray.length;    // 取目前已有手牌數

        for (var i = 0, len = serverCardStrArray.length; i < len; i++) {
            var zOrder = nowCardCount + 1;

            // 創撲克牌
            var cardNode = new CapsaSusun_CardNode(serverCardStrArray[i]);
            cardNode.cardIndex = zOrder;
            cardNode.stackNum = -1;
            cardNode.stackIdx = -1;
            cardNode.isUp = false;
            cardNode.setPosition(JSVisibleSize.width / 2, CapsaSusun_HandCardLayer.CARD_Y_POS);
            this._cardNode.addChild(cardNode, zOrder);

            cardArray.push(cardNode);

            nowCardCount++;
        }

        // 整理手牌
        this._sortHandCards();

        // 檢查智慧牌組
        var tool = this._hintCardTool;
        if (checkAlgorithm) {
            tool.checkAllCard(cardArray.map(cur => cur.cardNumber), checkAlgorithm);

            // 依照牌組更新提示區
            this._hintCardMenuBarLayer.checkAllCard(tool);
            this._hintCardMenuLayer.updateAlgorithmBtn(tool.algorithmObjArray);

            tool.isCheckAlgorithmDown = true; // 記下有成功
        }
    },

    /**
     * 把被選取的牌放到指定牌墩
     * @param stackNum   第幾墩
     */
    addSelectedCardToHint: function (stackNum) {
        var selectedCardArray = this._selectedCardArray;

        var cardCount = 0;  // 用來數放到選取陣列中的第幾張牌
        var len = CapsaSusun_CardStackCount[stackNum];
        for (var i = 0; i < len; i++) {
            if (!this._hintCardArray[stackNum][i]) {
                this._addCardToHint(selectedCardArray[cardCount], stackNum, i, i === len - 1);  // 最後一張才去檢查自動補牌
                cardCount++;
            }
        }

        // 更新各墩上面的按鈕
        var stackArray = [0, 0, 0];
        stackArray[stackNum] = 1;
        this._updateStackButton(stackArray, true);

        // 清掉選取的牌
        this._cleanSelectedCardArray();

        // 整理手牌
        this._sortHandCards();
    },

    /**
     * 按照指定推薦牌組擺放到牌墩
     * @param index     第幾組指定牌組
     */
    addAlgorithmCardToHint: function (index) {
        // 先把牌退回
        var cardArray = this._cardArray;
        for (var i = 0; i < CapsaSusun_StackCount; i++) {
            this.removeStackCardFromHint(i, true);
        }

        // 取是第幾組推薦牌組
        var algorithmObj = this._hintCardTool.algorithmObjArray[index];
        var algorithmArray = algorithmObj.algorithmArray;

        // 按照牌墩抓推薦牌組
        var algorithmCardArray = algorithmArray[0];
        for (var i = 0; i < CapsaSusun_StackCount; i++) {
            for (var j = 0, len = CapsaSusun_CardStackCount[i]; j < len; j++) {
                var targetRealNumber = algorithmCardArray[i][j];
                // 找出推薦的撲克牌
                var card = cardArray.find(card => card.cardRealNumber === targetRealNumber);
                this._addCardToHint(card, i, j);
            }
        }

        // 更新牌墩按鈕
        this._updateStackButton([1, 1, 1], true);

        // 整理手牌
        this._sortHandCards();

        this._isAlgorithmCardKind = true;
    },

    /**
     * 把指定牌墩的牌退回手牌
     * @param stackNum   第幾墩
     */
    removeStackCardFromHint: function (stackNum, isAlgorithm) {
        var hintCardArray = this._hintCardArray[stackNum].map(cur => cur);
        hintCardArray.forEach(card => {
            this._removeCardFromHint(card, true);
        });

        // 是快速選牌不更新位置
        if (isAlgorithm)
            return;

        this._updateStackButton();

        // 整理手牌
        this._sortHandCards();
    },

    /**
     * 交換第二墩跟第三墩牌
     */
    changeStackCards: function () {
        var hintCardArray1 = this._hintCardArray[1].slice();
        var hintCardArray2 = this._hintCardArray[2].slice();

        this._isStackCard = true;
        hintCardArray1.forEach((cur, index) => {
            this._addCardToHint(cur, 2, index);
        });

        hintCardArray2.forEach((cur, index) => {
            this._addCardToHint(cur, 1, index);
        });

        this._isStackCard = false;
        this._updateStackButton([0, 1, 1], true);
    },

    /**
     * 點下HintCardMenu的按鈕後 把對應的牌組選起來 ex.點順子 順子牌組裡包含的牌會被選取
     * @param hintCardParam     要升起的牌組
     */
    choiceCardByArray: function (hintCardParam) {
        this._backAllCard();

        if (hintCardParam) {
            var cardArray = this._cardArray;
            hintCardParam.realNumberCardList.forEach(cur => {
                cardArray.forEach(curCard => {
                    if (curCard.cardRealNumber === cur) {
                        this._upCard(curCard);
                    }
                });
            });
        }

        // 更新個墩上的按鈕
        this._updateStackButton();
    },

    /**
     * 整理手牌
     * @param isReset   要reset所有手牌的位置
     */
    _sortHandCards: function (isReset) {
        var cardArray = this._cardArray;
        var cardLength = cardArray.length;

        if (!cardLength)
            return;

        // 開始重新排序
        this._isSortingCard = true;

        // 數字小->大(2->A) 花色 黑桃>愛心>梅花>方塊
        cardArray.sort((cardSpA, cardSpB) => {
            return cardSpA.cardSortNumber - cardSpB.cardSortNumber;
        });

        // 開始處理位置
        var halfLen = Math.floor(cardLength / 2) + ((cardLength % 2 === 0) ? -0.5 : 0);
        var totalWidth = JSVisibleSize.width - (JSScreenSafeWidth * 2);
        var offsetX = (totalWidth - 20) / cardLength;

        offsetX = Math.min(offsetX, 40);

        for (var i = 0; i < cardLength; ++i) {
            var cardNode = cardArray[i];

            if (!cardNode)
                continue;

            cardNode.stopAllActions();

            var posX = (totalWidth / 2) + JSScreenSafeWidth + offsetX * (i - halfLen);
            cardNode.originalPos = cc.p(posX, CapsaSusun_HandCardLayer.CARD_Y_POS);
            cardNode.setScale(1);

            // 更新牌的order和編號
            cardNode.cardIndex = i + 1;
            this._cardNode.reorderChild(cardNode, (i + 1));

            if (isReset)
                this._backCard(cardNode);
            else {

                if (cardNode.isUp)
                    this._upCard(cardNode);
                else
                    this._backCard(cardNode);
            }
        }

        this.runAction(cc.sequence(
            cc.delayTime(0.2),
            cc.callFunc(this._sortCardFinish, this)
        ));

        // 清除選牌資訊
        isReset && this._cleanSelectedCardArray();

        // 重新檢查智慧牌組
        var tool = this._hintCardTool;
        if (tool.isCheckAlgorithmDown) {
            tool.checkAllCard(cardArray.map(cur => cur.cardNumber));
            // 依照牌組更新提示區
            this._hintCardMenuBarLayer.checkAllCard(tool);
            this._hintCardMenuLayer.updateAlgorithmBtn(tool.algorithmObjArray);
        }

    },

    /**
     * 排序墩裡面的牌
     * @param stackNum 哪一墩
     */
    _sortStackCard: function (stackNum) {
        var pos = this._hintCardMenuLayer.getStackPosByStack(stackNum);
        if (!pos)
            return;

        var stackLen = this._hintCardLenArray[stackNum];
        var hintCardArray = this._hintCardArray[stackNum];

        if (stackLen === CapsaSusun_CardStackCount[stackNum]) {
            // 數字大->小(2->A) 花色 黑桃>愛心>梅花>方塊
            hintCardArray.sort((cardSpA, cardSpB) => {
                return cardSpB.cardStackSortNumber - cardSpA.cardStackSortNumber;
            });
        }

        hintCardArray.forEach((cur, index) => {
            // 牌移動 + 縮小
            cur.stackIdx = index;
            cur.stopAllActions();
            cur.runAction(cc.spawn(cc.moveTo(0.1, cc.p(pos.x + index * 41, pos.y)), cc.scaleTo(0.1, 0.77)));
        });
    },

    /**
     * 手牌整理完畢
     */
    _sortCardFinish: function () {
        this._isSortingCard = false;
    },

    /**
     * 檢查剩下的牌 如果剛好剩一墩缺牌 自動幫忙放上去
     */
    _checkAutoAddStackCard: function () {
        var cardLength = this._cardArray.length;
        if (cardLength > 5)
            return;

        // 檢查剩下的牌 如果剛好剩一墩缺牌 自動幫忙放上去
        for (var i = 0; i < CapsaSusun_StackCount; i++) {
            if (cardLength === (CapsaSusun_CardStackCount[i] - this._hintCardLenArray[i])) {
                this._selectedCardArray = [];
                this._cardArray.forEach(card => {
                    // 加入被選中的array
                    if (this._selectedCardArray.indexOf(card) === -1)
                        this._selectedCardArray.push(card);
                });
                // 把牌放到牌墩
                this.addSelectedCardToHint(i);
            }
        }
    },

    /**
     * 更新個牌墩的長度
     */
    _updateStackCardLen: function () {
        this._hintCardArray.forEach((cur, index) => {
            this._hintCardLenArray[index] = cur.length;
        });
    },

    /**
     * 更新牌墩上的按鈕狀態
     * @param stackArray    : 哪些牌墩要顯示動畫
     * @param isPlayAnima   : 要不要顯示牌墩動畫
     */
    _updateStackButton: function (stackArray = [0, 0, 0], isPlayAnima) {
        var choseLen = this._cardArray.filter(cur => cur.isUp).length;

        // 每個牌墩上面牌的數量
        var hintCardLen = this._hintCardLenArray;

        // 是否符合出牌順序
        var hintCardArray = this._hintCardArray.map(curArray => curArray.map(cur => cur.cardRealNumber));
        var checkHintCard = this._hintCardTool.checkHintCardConform(hintCardArray);
        var isConformCardHint = checkHintCard.isConform;
        var cardWeightArray = checkHintCard.weightArray;

        hintCardLen.forEach((cur, index) => {
            if (choseLen > 0 && choseLen <= CapsaSusun_CardStackCount[index] && cur === 0) {
                // 點選了五張牌 可以點擊牌墩上的按鈕 (牌墩上沒牌)
                this._hintCardMenuLayer.updateStatus(index, CapsaSusun_HintCardMenuLayer.STATUS.TOUCH_ON);

                // 關閉牌型動畫
                this._hintCardMenuLayer.playStackAnima(index, false);
            } else {
                if (cur === 0) {
                    // 沒有點選牌 牌墩上沒牌
                    this._hintCardMenuLayer.updateStatus(index, CapsaSusun_HintCardMenuLayer.STATUS.TOUCH_OFF);

                    // 關閉牌型動畫
                    this._hintCardMenuLayer.playStackAnima(index, false);
                } else if (cur === CapsaSusun_CardStackCount[index]) {
                    // 牌墩已滿  確認該出牌是否符合規定
                    var status = (isConformCardHint) ? CapsaSusun_HintCardMenuLayer.STATUS.RIGHT_CARD : CapsaSusun_HintCardMenuLayer.STATUS.ERROR_CARD;
                    this._hintCardMenuLayer.updateStatus(index, status);

                    // 表演牌墩動畫
                    if (isPlayAnima && stackArray[index])
                        this._hintCardMenuLayer.playStackAnima(index, cardWeightArray[index] > CapsaSusun_CardKindWeight);
                } else {
                    // 牌墩上有牌
                    this._hintCardMenuLayer.updateStatus(index, CapsaSusun_HintCardMenuLayer.STATUS.HAVE_CARD);

                    // 關閉牌型動畫
                    this._hintCardMenuLayer.playStackAnima(index, false);
                }

            }
        });

        // 更新右側快速選牌按鈕
        if (this._isAlgorithmCardKind) {
            this._hintCardMenuLayer.updateAlgorithmBtnEnabled();
            this._isAlgorithmCardKind = false;
        }
    },

    /**
     * 把手牌加入上方出牌區
     * @param {Pokers_CardSprite} card
     * @param {int} stackNum
     * @param {int} stackIdx
     * @param {boolean} canAutoComplete
     */
    _addCardToHint: function (card, stackNum, stackIdx, canAutoComplete = false, removeSelect = false) {
        if (!card)
            return;

        var cardArray = this._cardArray;
        var hintCardArray = this._hintCardArray;

        var pos = this._hintCardMenuLayer.getStackPosByStack(stackNum);
        var tempCard, tempStackNum;
        if (pos) {

            tempCard = hintCardArray[stackNum][stackIdx];
            if (tempCard) {
                // 需要交換牌

                if (this._isStackCard) {
                    // 交換牌墩的牌
                    tempStackNum = card.stackNum;
                    var temStackIdx = card.stackIdx;

                    var changeCard = tempCard;

                    if (hintCardArray[tempStackNum])
                        hintCardArray[tempStackNum][temStackIdx] = tempCard;

                    changeCard.stackNum = tempStackNum;
                    changeCard.stackIdx = temStackIdx;
                } else {
                    // 交換手牌

                    var cardArrayIndex = cardArray.findIndex(curCard => curCard === card);
                    if (cardArrayIndex !== -1) {
                        var changeCard = cardArray[cardArrayIndex] = tempCard;
                        changeCard.stackNum = -1;
                        changeCard.stackIdx = -1;
                    }
                }
            } else {
                // 放在空位上

                if (this._isStackCard) {
                    tempStackNum = card.stackNum;

                    // 從牌墩中移過去
                    this._removeCardFromHint(card);
                } else {
                    // 從手牌移過去

                    // 選取中的牌要移掉這張牌
                    if (removeSelect) {
                        var selectIndex = this._selectedCardArray.findIndex(curCard => curCard === card);
                        selectIndex !== -1 && this._selectedCardArray.splice(selectIndex, 1);
                    }

                    // 找到這張牌, 從手牌移除
                    var cardArrayIndex = cardArray.findIndex(curCard => curCard === card);
                    cardArrayIndex !== -1 && cardArray.splice(cardArrayIndex, 1);
                }
            }

            card.stackNum = stackNum;
            card.stackIdx = stackIdx;

            // 有放過牌在牌墩上
            this.setPlaying(true);

            // 塞入該張牌
            hintCardArray[stackNum][stackIdx] = card;
            // 更新牌墩內的長度
            this._updateStackCardLen();

            this._sortStackCard(stackNum);

            if (tempStackNum >= 0) {
                this._sortStackCard(tempStackNum);
            }

            this._buttonMenu.setVisible(cardArray.length === 0);
            this._hintCardMenuBarLayer.setVisible(cardArray.length !== 0);
        }

        // 檢查是否自動把剩下牌放到牌墩
        canAutoComplete && this._checkAutoAddStackCard();
    },

    /**
     * 把出牌區的牌退回手牌
     * @param {Pokers_CardSprite} card
     */
    _removeCardFromHint: function (card, isAddToHand) {
        if (!card)
            return;

        var cardArray = this._cardArray;
        var hintCardArray = this._hintCardArray[card.stackNum];

        // 在牌墩內
        if (hintCardArray) {
            var hintCardArrayIndex = hintCardArray.findIndex(curCard => curCard === card);
            // 找到這張牌, 從牌墩移除
            (hintCardArrayIndex !== -1) && hintCardArray.splice(hintCardArrayIndex, 1);
        }

        // 清除牌墩資料
        card.stackNum = -1;
        card.stackIdx = -1;

        this._buttonMenu.setVisible(cardArray.length === 0);
        this._hintCardMenuBarLayer.setVisible(cardArray.length !== 0);

        this._updateStackCardLen();

        if (isAddToHand) {
            cardArray.push(card);
            card.isUp = false;
        }
    },

    /**
     * 清除touch用Flag
     */
    _cleanTouchFlag: function () {
        this._originPos = undefined;        // 開始點擊的位置
        this._touchCard = undefined;        // 點到的牌
        this._isStackCard = false;          // 點到的牌是牌墩內的牌
    },

    /**
     * 讓所有手牌回原位 (取消選取所有手牌)
     */
    _backAllCard: function () {
        this._cardArray.forEach(cur => this._backCard(cur));
    },

    /**
     * 反向選取手牌(選取/取消選取手牌)
     * @param {Pokers_CardSprite} card
     */
    _upOrDownCard: function (card) {
        if (!card)
            return;

        if (card.isUp)
            this._backCard(card);
        else
            this._upCard(card);
    },

    /**
     * 讓牌跳起來 (選取手牌)
     * @param {Pokers_CardSprite} card
     */
    _upCard: function (card) {
        if (!card)
            return;

        card.stopAllActions();
        card.isUp = true;
        card.setPosition(card.originalPos.x, card.originalPos.y + 10);

        // 加入被選中的array
        if (this._selectedCardArray.indexOf(card) === -1)
            this._selectedCardArray.push(card);
    },

    /**
     * 讓牌移回原位 (取消選取手牌)
     * @param {Pokers_CardSprite} card      牌
     * @param {boolean} setToOriginalPos    設回初始位置
     */
    _backCard: function (card, setToOriginalPos = true) {
        if (!card)
            return;

        // 從選取的陣列移除掉那張牌
        cc.arrayRemoveObject(this._selectedCardArray, card);

        card.stopAllActions();
        card.isUp = false;
        setToOriginalPos && card.setPosition(card.originalPos);     // 設回初始位置
    },

    /**
     * 按鈕相關 =============================================
     */

    /**
     * 按下重選
     */
    _cancelClicked: function () {
        // 退回三個牌墩的牌
        for (var i = 0; i < CapsaSusun_StackCount; i++) {
            this.removeStackCardFromHint(i);
        }
    },

    /**
     * 按下出牌
     */
    _sendCardClicked: function () {
        // if (!this._isTurnMe)
        //     return;
        //
        // 把有選取的牌組成字串  格式 "1T,3T..."
        var cardString = "";
        for (var i = 0; i < CapsaSusun_StackCount; i++) {
            this._hintCardArray[i].forEach((cur, index) => {
                cardString += ((index === 0) ? "" : ",") + cur.cardNumber;
            });
            cardString += (i === CapsaSusun_StackCount - 1) ? "" : ",";
        }
        // 把選取的牌送給server  (C++版本時間到自動送 >> "DeckReady 1 ...", 真合併改成跟其他遊戲一樣)
        DataProcess.sendString("DeckReady 0 " + cardString);

        // Firebase 埋點
        var eventName = GSAnalyticsAdapter.record.game + "遊戲行為";
        GSAnalyticsAdapter.logEventByFirebaseAll(eventName, ["牌桌"], ["Capsa Susun出牌"]);
    },

    onTouchBegan: function (touch, event) {
        var swallow = false;

        if (!this._canTouch || this._isSortingCard) {
            return false;
        }

        var target = event.getCurrentTarget();

        if (!target.isVisible())
            return false;

        for (var c = target.parent; c != null; c = c.parent) {
            if (!c.isVisible())
                return false;
        }

        // 清除touch用Flag
        this._cleanTouchFlag();

        var localPos = this.convertTouchToNodeSpace(touch);

        var cardArray = this._cardArray;

        var stackNum = this._hintCardMenuLayer.getStackPosByContains(touch);
        if (stackNum >= 0 && this._hintCardArray[stackNum].length) {
            // 點到牌墩內的牌

            var hintCardArray = this._hintCardArray[stackNum];

            for (i = hintCardArray.length - 1; i >= 0; --i) { // 從右邊開始
                cardNode = hintCardArray[i];
                if (cardNode && cc.rectContainsPoint(cardNode.getBoundingBox(), localPos)) {

                    this._touchCard = cardNode;
                    this._isStackCard = true;

                    cardNode.setLocalZOrder(20);

                    var cardBoundingBox = cardNode.getBoundingBox();
                    this._touchCardBoundingBox = cc.rect(cardBoundingBox.x, cardBoundingBox.y, cardBoundingBox.width + 5, cardBoundingBox.height + 5);

                    swallow = true;
                    break;
                }
            }
        } else {
            var i, cardNode;
            for (i = cardArray.length - 1; i >= 0; --i) { // 從右邊開始
                cardNode = cardArray[i];
                if (cardNode && cc.rectContainsPoint(cardNode.getBoundingBox(), localPos)) {

                    this._touchCard = cardNode;
                    cardNode.setLocalZOrder(20);

                    this._touchCardBoundingBox = cardNode.getBoundingBox();
                    swallow = true;
                    break;
                }
            }
        }

        // 沒有點到牌
        if (!swallow)
            return swallow;

        // 有找到選取的牌

        this._originPos = cardNode.getPosition();     // 記下該張牌原始的位置
        return swallow;
    },

    onTouchMoved: function (touch) {
        // 不是點到牌, 不用做move的事情
        if (!this._touchCard)
            return;

        var localPos = this.convertTouchToNodeSpace(touch);

        if (localPos.y >= CapsaSusun_HandCardLayer.DRAG_MIN_Y)
            this._touchCard.setScale(0.77);
        else
            this._touchCard.setScale(1);

        this._touchCard.setPosition(localPos);
    },

    onTouchEnded: function (touch) {
        if (!this._touchCard)
            return;

        var localPos = this.convertTouchToNodeSpace(touch);
        var touchCard = this._touchCard;
        var originPos = this._originPos;
        var isNotCardAnima = false;
        var stackArray = [0, 0, 0];

        if (localPos.y <= CapsaSusun_HandCardLayer.DRAG_MIN_Y) {
            if (this._isStackCard) {
                // 牌墩的牌放回手牌中
                var sortStackNum = touchCard.stackNum;
                this._removeCardFromHint(touchCard, true);

                this._sortStackCard(sortStackNum);

                this._buttonMenu.setVisible(false);
                this._hintCardMenuBarLayer.setVisible(true);

                touchCard.setPosition(localPos);

                // 整理下方手牌
                this._sortHandCards();
            } else {
                // 手牌區的牌
                touchCard.setPosition(originPos);
                touchCard.setLocalZOrder(touchCard.cardIndex);

                if (cc.rectContainsPoint(this._touchCardBoundingBox, localPos)) {
                    // 單純點擊事件
                    this._upOrDownCard(touchCard);
                    isNotCardAnima = true;
                }
            }

            // 放回下方手牌中
            touchCard.setScale(1);
        } else {
            // 在三墩的範圍內
            var stackNum = this._hintCardMenuLayer.getStackPosByContains(touch);
            if (stackNum >= 0) {

                // 該墩有幾張牌
                var stackLen = this._hintCardArray[stackNum].length;

                // 是不是在別張牌的上面
                var hintCardArray = this._hintCardArray;
                var changeCard;
                var changeDirection = originPos.x - localPos.x >= 0;
                for (var i = 0; i < stackLen; i++) {
                    // 在某張牌的上面要交換
                    var hintCard = hintCardArray[stackNum][i];
                    if (hintCard && cc.rectContainsPoint(hintCard.getBoundingBox(), localPos)) {
                        changeCard = hintCard;

                        // 確認要交換的牌是該張牌的左邊還是右邊
                        // 換左邊的牌以第一個找到的那張為主
                        // 換右邊的牌以最後一個找到那張為主
                        if (changeDirection)
                            break;
                    }
                }

                if (changeCard === touchCard) {
                    touchCard.setPosition(originPos);
                } else {

                    if (stackNum !== touchCard.stackNum) {
                        stackArray[stackNum] = 1;
                        stackArray[touchCard.stackNum] = 1;
                    } else
                        isNotCardAnima = true;

                    // 該張牌要放在哪個地方
                    var stackIdx = (changeCard) ? changeCard.stackIdx : stackLen;

                    if (stackIdx >= CapsaSusun_CardStackCount[stackNum])
                        // 牌墩已滿 回去原位
                        touchCard.setPosition(originPos);
                    else
                        this._addCardToHint(touchCard, stackNum, stackIdx, true, true);
                }
            } else {
                // 碰到其他地方
                // 回到原位
                touchCard.setPosition(originPos);
            }

            touchCard.setLocalZOrder(1);

            // 整理下方手牌
            this._sortHandCards();
        }

        // 更新上方牌墩的按鈕
        var touchCardPos = touchCard.getPosition();
        this._updateStackButton(stackArray, !isNotCardAnima && !cc.pSameAs(touchCardPos, originPos));

        // 拖曳完成
        this._cleanTouchFlag();
    },

    onTouchCancelled: function () {
        if (!this._canTouch)
            return;

        this._touchCard.setPosition(this._originPos);
        this._touchCard.setScale(1);

        // 清除touch用Flag
        this._cleanTouchFlag();
    }
});

// 牌的Y軸位置
CapsaSusun_HandCardLayer.CARD_Y_POS = 46;

// 拖曳判斷用Y
CapsaSusun_HandCardLayer.DRAG_MIN_Y = 90;