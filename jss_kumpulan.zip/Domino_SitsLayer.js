/**
 * 座位的畫面
 */

var Domino_SitsLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this.setCascadeOpacityEnabled(true);

        this._sitsArray = [];

        this._playerNumber = DataModal.gameData.playerNumber;
        for (var i = 0; i < this._playerNumber; i++) {
            var pos = Domino_GameUtility.getPlayerPosition(i);
            var sitBtn = new Domino_SitsButtonNode(i);
            sitBtn.setPosition(pos);
            sitBtn.playAnim(true);
            sitBtn.setVisible(false);
            this.addChild(sitBtn);

            this._sitsArray.push(sitBtn);
        }
    },

    /**
     * 重置所有資訊
     */
    cleanData: function () {
        this.setAllSitsVisible(false);
    },

    /**
     * 更新狀態
     */
    updateSeat: function () {
        for (var i = 0; i < DataModal.gameData.playerNumber; i++) {
            var sitNum = DataModal.gameData.getDirectionByServerDirection(i);
            var data = DataModal.gameData.playerDataArray[i];
            if (data && !_.isEmpty(data) && !data.getIsExist()) {
                this._sitsArray[sitNum].playAnim(true);
            } else {
                this._sitsArray[sitNum].playAnim(false);
            }
        }
    },

    /**
     * 所有坐位是否可以可視
     * @param {value} 是否可視
     */
    setAllSitsVisible: function (value) {
        this._sitsArray.forEach(function (cur) {
            cur.playAnim(value);
        });
    },
});

var Domino_SitsButtonNode = cc.Node.extend({

    ctor: function (sitNum) {
        this._super();

        this._sitNum = sitNum;

        // 先創主移動的Node 之後透過他移動就好
        var moveNode = this._moveNode = new cc.Node();
        moveNode.setCascadeOpacityEnabled(true);
        this.addChild(moveNode);

        //坐下按鈕
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        moveNode.addChild(menu);

        var itemNode = [];
        for (var i = 0; i < 2; i++) {
            var node = itemNode[i] = new cc.Node();
            node.setCascadeColorEnabled(true);

            var sitSprite = new cc.Sprite("#game_btn_sit.png");
            var buttonSize = sitSprite.getContentSize();
            node.setContentSize(buttonSize);

            sitSprite.setPosition(buttonSize.width / 2, buttonSize.height / 2);
            node.addChild(sitSprite);

            var tableLabel = new cc.LabelTTF(LocalizedString.Game("坐下"), JSFontBoldName, 8);
            tableLabel.setPosition(buttonSize.width / 2, buttonSize.height / 2 - 8);
            tableLabel.setFontFillColor(JSColor.GRAY);
            node.addChild(tableLabel);

            if (i === 1) {
                node.setColor(JSColor.GRAY);
            }
        }
        var menuItem = new cc.MenuItemSprite(itemNode[0], itemNode[1], this._menuClicked, this);
        menu.addChild(menuItem);
    },

    /**
     * 播放上下搖擺動畫
     */
    playAnim: function (isPlay) {
        this.setVisible(isPlay);

        var moveNode = this._moveNode;
        moveNode.stopAllActions();

        if (isPlay) {
            moveNode.setPosition(0, 0);
            var action1 = cc.moveBy(0.25, cc.p(0, 4));
            var action2 = cc.moveTo(0.25, cc.p(0, -4));
            moveNode.runAction(cc.sequence(action1, action2).repeatForever());
        }
    },

    /**
     * 按下坐下
     * @private
     */
    _menuClicked: function () {
        var param = {
            min: DataModal.gameData.minBringIn,
            max: DataModal.gameData.maxBringIn,
            money: DataModal.profileData.money,
            sitPos: DataModal.gameData.getServerDirectionByDirection(this._sitNum),
            type: BringMoneyDialog.Type.SIT
        };

        // 送通知
        GS.dispatchCustomEvent("NotifyGameUISitDownClicked", param);
    }
});