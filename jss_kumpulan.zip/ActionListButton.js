/**
 * ActionList的按鈕
 */

var ActionListButton = cc.ControlButton.extend({
    ctor: function (actionParam) {
        this._super();

        this.actionParam = actionParam;

        // 先把此按鈕的圖片做好
        var btnSize = cc.size(100, 100);

        var node = this._mainNode = new ccui.Scale9Sprite();
        node.setCascadeColorEnabled(true);
        node.setCascadeOpacityEnabled(true);
        node.setContentSize(btnSize);

        // 一般的背景
        var normalSprite = new cc.Sprite(JSStringUtility.format("lobby/ActionList/pic_ActionList_%02d.png", actionParam.picNum));
        normalSprite.setPosition(btnSize.width / 2, btnSize.height / 2);
        node.addChild(normalSprite);

        // 小紅點
        if (actionParam.status === 1) {
            // 可領獎 加個小紅點
            var badge = new BadgeNode();
            badge.useDefaultStyle();
            badge.setPosition(btnSize.width - 6, btnSize.height - 6);
            node.addChild(badge);
        }

        // 如果picNum是0 代表是敬啟期待 讓按鈕不能按
        if (actionParam.picNum === 0) {
            node.setColor(JSColor.GRAY);
            this.setEnabled(false);
        }

        // 自己的設定
        this.setPreferredSize(btnSize);         // 一定要加這行 Native才會是對的
        this.setBackgroundSpriteForState(node, cc.CONTROL_STATE_NORMAL);
        this.addTargetWithActionForControlEvents(this, this._buttonClicked,
            cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
            cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
            cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
        this.setAdjustBackgroundImage(false);
        this.setZoomOnTouchDown(false);
        this.setSwallowTouches(false);
        this.setTouchDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
    },

    /**
     * 按到的時後 要改變顏色
     */
    _buttonClicked: function (sender, type) {
        var isTouched = (type === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || type === cc.CONTROL_EVENT_TOUCH_DOWN);
        this._mainNode.setColor(isTouched ? JSColor.GRAY : JSColor.WHITE);
    },
});