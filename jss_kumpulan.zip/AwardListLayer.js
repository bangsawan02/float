/**
 * 5.5.7大廳信件領獎整合 收件箱 - 領取頁籤
 * 移植自中文德撲 16.2大廳信件領獎整合
 *
 * created by daniel.lin
 */

var AwardListLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 沒有領獎時的顯示Node
        var emptyNode = this._emptyNode = new cc.Node();
        this.addChild(emptyNode);

        // Icon圖
        var iconSprite = new cc.Sprite("#awardAndMail_pic_icon_gift.png");
        iconSprite.setPosition(269 + JSScreenBonusHalfWidth, 159 + JSScreenBonusHalfHeight);
        emptyNode.addChild(iconSprite);

        // 說明文字
        var label = new cc.LabelTTF(LocalizedString.AwardAndMail("您目前沒有獎勵呦!"), JSFontName, 10);
        label.setFontFillColor(GS.isLuxyPoker ? JSColor.WHITE : cc.color(102, 48, 20));
        label.setPosition(269 + JSScreenBonusHalfWidth, 129 + JSScreenBonusHalfHeight);
        emptyNode.addChild(label);

        // TableView
        this._tableWidth = 340;
        var tableView = this._tableView = new cc.TableView(this, cc.size(this._tableWidth, 220 + JSScreenBonusHeight), new cc.Layer());
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setPosition((JSVisibleSize.width - 320) / 2, 40);
        tableView.setDelegate(this);
        this.addChild(tableView);

        // 更新畫面
        this._refreshView();

        // 註冊
        GS.addListener("NotifyAwardAndMailDone", this.notifyAwardAndMailDone.bind(this), this);

        // 埋點 550:進入領取頁籤
        TexasUtility.sendUserAnalyticsTrack(550);

        // 送 有副系統可領獎時，有進入領獎介面 的埋點
        var trackIdArray = [];
        this._awardList.forEach(cur => {
            // 抓埋點
            let fid = this._getTrackIdByFID(cur.fid);

            // 有自己的分群自己單獨送埋點
            if (cur.group) {
                TexasUtility.sendUserAnalyticsTrack(fid, cur.group);
            } else
                trackIdArray.push(fid);
        });
        if (trackIdArray.length)
            TexasUtility.sendUserAnalyticsTrack(trackIdArray);
    },

    // override
    setVisible: function (value) {
        this._super(value);

        if (value) {
            // 埋點 550:進入領取頁籤
            TexasUtility.sendUserAnalyticsTrack(550);
        }
    },

    // 刷新畫面
    _refreshView: function () {
        // 整理一下有沒有已到期的領獎先刪掉
        DataModal.awardAndMailData.purifyAwardArray();

        // 取得"領取"的資料
        var awardList = this._awardList = DataModal.awardAndMailData.awardList;

        // 總數量
        var listCount = this._totalCellCount = awardList ? awardList.length : 0;

        var emptyNode = this._emptyNode;
        var tableView = this._tableView;

        // 切換顯示
        if (listCount === 0) {
            // 沒有領獎
            emptyNode.setVisible(true);
            tableView.setVisible(false);
        } else {
            // 有領獎 顯示tableView並reload
            emptyNode.setVisible(false);
            tableView.setVisible(true);
            tableView.reloadData(true);
        }
    },

    // 取得領獎埋點ID
    _getTrackIdByFID: function (fid) {
        switch (fid) {
            case FidMap.GAMBLER_ROAD:
                // 埋點 2203:牌王之路可領獎
                return 2203;
            case FidMap.TOKEN_SUBSYSTEM:
                // 埋點 2211:代幣副系統可領獎
                return 2211;
            case FidMap.VEGAS_COMPETE:
                // 埋點 2205:VIP爭霸賽可領獎
                return 2205;
            case FidMap.SPEED_RACING:
                // 埋點 2207:極速競飆可領獎
                return 2207;
            case FidMap.VEGAS_MAP_MISSION:
                // 埋點 2209:地圖式任務可領獎
                return 2209;
            case FidMap.LUCKY_LOTTERY:
                // 埋點 3841:新儲值中心抽獎活動可領獎
                return 3841;
            // case FidMap.STONE_GAMBLING:
            //     return XXXX;
        }
    },

    /**
     * TableView delegate
     */
    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        if (cell == null) {
            cell = new AwardCell(() => {
                // 點擊領獎後 要更新這頁的狀態
                this._refreshView();
            });
        }

        var awardList = this._awardList;
        if (!awardList)
            return cell;

        var param = awardList[idx];
        cell.refreshCell(param);

        return cell;
    },

    numberOfCellsInTableView: function (table) {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function (table, idx) {
        return cc.size(this._tableWidth, AwardCell.HEIGHT);
    },

    /**
     * 通知
     */
    notifyAwardAndMailDone: function () {
        this._refreshView();
    }
});