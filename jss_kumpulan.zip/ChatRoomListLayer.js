/**
 *  好友聊天室清單
 *  聊過天的好友列表
 */

var ChatRoomListLayer = cc.Layer.extend({
    ctor: function (type, isGameGaple) {
        this._super();

        this._fromType = type;
        this._cellType = ChatCellType.NORMAL;   // 聊天室狀態 1:正常 2:刪除對話狀態
        this._isGameGaple = isGameGaple;

        if (this._isGameGaple)
            this._initGapleView();
        else
            this._initView();

        this.refreshView();

        // 監聽
        GS.addListener("NotifyFriendChatRoomListDone", this.notifyFriendChatRoomListDone.bind(this), this);
        GS.addListener("NotifyUpdateFriendChatRoomList", this.notifyUpdateFriendChatRoomList.bind(this), this);
    },

    /**
     * init介面UI
     */
    _initView: function () {
        var friendStr = LocalizedString.Friend;

        var width = ChatRoomLayer.WIDTH;

        // 標題
        var titleLabel = new cc.LabelTTF(friendStr("聊天室"), JSFontBoldName, 12);
        titleLabel.setPosition((width + 4) / 2, 275 + JSScreenBonusHeight);
        this.addChild(titleLabel);

        var mainNode = this._mainNode = new cc.Node();
        this.addChild(mainNode, 1);

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.setPosition(width - 15, 275 + JSScreenBonusHeight);
        closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
        mainNode.addChild(closeBtn, 3);

        // Menu
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        mainNode.addChild(menu, 3);

        // 公會聊天區
        var guildChatRoom = this._guildChatRoom = new GuildChatRoomNode(this._cellType, this._isGameGaple);
        guildChatRoom.setPosition(4, 215 + JSScreenBonusHeight);
        mainNode.addChild(guildChatRoom);

        var tableViewHeight = 207;  // 在牌桌時的尺寸(已經扣掉公會聊天區)
        var tableViewPosY = 6;

        // 在lobby有找好友聊天按鈕/刪除聊天室按鈕
        if (PushScene.isLobby) {
            // 左上角刪除小按鈕/返回小按鈕
            var deleteNode = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_circle_04.png", null, "#chat_btn_delete.png");
            deleteNode.forEach(item => {
                item.bg.setScale(1.1);
                item.word.setScale(0.75);
            });
            this._deleteNode = deleteNode[0];
            var deleteItem = new cc.MenuItemSprite(deleteNode[0], deleteNode[1], null, this._deleteItemClicked, this);
            deleteItem.setPosition(20, 275 + JSScreenBonusHeight);
            menu.addChild(deleteItem);

            // 下方找好友/刪除鈕
            this._btnArray = [];
            var btnParam = [
                {
                    title: friendStr("找好友聊天"),
                    callBack: this._addItemClicked,
                    visibleType: ChatCellType.NORMAL
                },
                {
                    title: friendStr("刪除"),
                    callBack: this._deleteChatBtnClicked,
                    visibleType: ChatCellType.DELETE
                }
            ];
            for (var i = 0; i < 2; i++) {
                var itemNodes = ButtonUtility.createArrayScale9Nodes(["lobby_btn_01.png", "lobby_btn_01.png", "lobby_btn_06.png"], cc.size(176, 27), btnParam[i].title, 12, JSColor.BLACK);
                itemNodes[2].setOpacity(255);
                var addItem = this._btnArray[i] = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], btnParam[i].callBack, this);
                addItem.setPosition(width / 2 + 2, 20);
                addItem.setVisible(this._cellType === btnParam[i].visibleType);
                menu.addChild(addItem);
            }

            tableViewHeight = 180;

            // 優惠通知
            var notifyChatRoom = new DiscountNotifyRoomNode();
            notifyChatRoom.setPosition(4, 171 + JSScreenBonusHeight);
            mainNode.addChild(notifyChatRoom);

            tableViewPosY = 30;         // 大廳有加好友按鈕
            tableViewHeight -= 44;      // 有優惠通知 要小一點
        }

        // 上線好友tableView
        this._totalCellCount = 0;
        var tableView = this._tableView = new cc.TableView(this, cc.size(width, tableViewHeight + JSScreenBonusHeight));
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setPosition(0, tableViewPosY);
        this.addChild(tableView);
    },

    /**
     * init Gaple系列專用的UI
     */
    _initGapleView: function () {
        var friendStr = LocalizedString.Friend;

        var width = ChatRoomLayer.GAPLE_WIDTH;
        var posY = ChatRoomLayer.GAPLE_HEIGHT;

        var mainNode = this._mainNode = new cc.Node();
        this.addChild(mainNode, 1);

        // 關閉按鈕
        var closeBtn = ButtonUtility.createSimpleImageButton("gaple_btn_01_2.png", null, "#gaple_pic_x.png");
        closeBtn.setScale(0.77);
        closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
        closeBtn.setPosition(188, 219);
        mainNode.addChild(closeBtn);

        // 公會聊天區
        var guildChatRoom = this._guildChatRoom = new GuildChatRoomNode(this._cellType, true);
        guildChatRoom.setPosition(4, posY - 34);
        mainNode.addChild(guildChatRoom);

        var tableViewHeight = posY - 77;  // 在牌桌時的尺寸(已經扣掉公會聊天區)
        var tableViewPosY = 43;

        // 上線好友tableView
        this._totalCellCount = 0;
        var tableView = this._tableView = new cc.TableView(this, cc.size(width, tableViewHeight));
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setPosition(1, tableViewPosY);
        this.addChild(tableView);
    },

    /**
     * 刷新介面
     */
    refreshView: function (isTableViewReload = true) {
        var data = DataModal.chatRoomData;

        if (!data)
            return;

        // 聊天室清單
        var list = this._list = data.friendChatRoomList.slice().map(friendInfo => {
            if (DataModal.blacklistData.isAccountInList(friendInfo.userID))
                return undefined;
            else
                return friendInfo;
        }).filter(cur => !!cur);

        // 數量
        this._totalCellCount = list.length;

        // 刷新tableview 刪除時不reloadData 否則位置會重置
        this._tableView.reloadData(isTableViewReload);

        // 設定刪除聊天鈕能否點擊
        if (JSCodeUtility.isArray(this._btnArray)) {
            if (this._cellType === ChatCellType.DELETE) {
                this._btnArray[0].setVisible(false);
                this._btnArray[1].setVisible(true);
                this._btnArray[1].setEnabled(list.some((cur) => cur.isDelete));
            } else {
                this._btnArray[0].setVisible(true);
                this._btnArray[1].setVisible(false);
            }
        }
    },

    /**
     * tableview
     */
    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        if (cell == null) {
            cell = new FriendChatRoomListCell(this._cellType, this._isGameGaple);
            cell.setAnchorPoint(0, 0);
        }
        cell.refreshCell(this._list[idx], idx, this._cellType);

        return cell;
    },

    numberOfCellsInTableView: function () {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function () {
        if (this._isGameGaple)
            // Gaple系列牌桌
            return cc.size(ChatRoomLayer.GAPLE_WIDTH, FriendChatRoomListCell.GAPLE_HEIGHT);

        else
            return cc.size(ChatRoomLayer.WIDTH, FriendChatRoomListCell.HEIGHT);
    },

    tableCellTouched: function (table, cell) {
        switch (this._cellType) {
            case ChatCellType.NORMAL:
                // 設定聊天室的好友UID & userID
                var obj = {
                    type: ChatRoomPageType.CHAT,
                    UID: cell.UID,
                    userID: cell.userID,
                    nickname: cell.nickname
                };
                // 前往聊天頁
                GS.dispatchCustomEvent("NotifyShowChatRoomLayerByPageType", obj);

                this._list[cell.idx].redPoint = false;
                break;

            case ChatCellType.DELETE:
                // 改變cell/List isDelete資料
                cell.toggleClicked();
                this._list[cell.idx].isDelete = cell.isDelete();
                this.refreshView(false);
                break;
        }

        cell.setIsHighlight(false);
    },

    tableCellHighlight: function (table, cell) {
        cell.setIsHighlight(true);
    },

    tableCellUnhighlight: function (table, cell) {
        cell.setIsHighlight(false);
    },


    // 取得刪除對話框UID陣列
    _getDeleteChatUidArray: function () {
        var deleteUidArray = [];
        var friendChatList = this._list;
        friendChatList.forEach((cur) => {
            if (cur.isDelete)
                deleteUidArray.push(cur.UID);
        });
        return deleteUidArray;
    },

    /**
     * 點擊找好友聊天 開啟好友清單
     */
    _addItemClicked: function () {
        if (this._fromType === ChatRoomFromType.LOBBY)
            // 打開好友清單
            PushScene.pushLayer(new FriendLayer());

        // 關閉介面
        this._closeBtnClicked();
    },

    // 點擊刪除小按鈕/返回按鈕
    _deleteItemClicked: function () {
        switch (this._cellType) {
            case ChatCellType.NORMAL:
                // 進入刪除畫面
                this._cellType = ChatCellType.DELETE;
                this._deleteNode.word.setSpriteFrame("lobby_btn_back.png");
                break;
            case ChatCellType.DELETE:
                // 回到正常樣式
                this._cellType = ChatCellType.NORMAL;
                this._deleteNode.word.setSpriteFrame("chat_btn_delete.png");
                break;
        }

        this._guildChatRoom.refreshView(this._cellType);
        this.refreshView();
    },

    // 點擊刪除對話按鈕
    _deleteChatBtnClicked: function () {
        // 跳出提示Dialog
        var friendStr = LocalizedString.Friend;

        DialogManager.addDialog(new Dialog({
            bgSize: cc.size(320, 200),
            content: friendStr("確定要將對話框刪除?"),
            btnImages: ["lobby_btn_06.png", "lobby_btn_01.png"],
            buttons: ["不刪除", "確定"].map(string => friendStr(string)),
            closeButton: 0,
            callback: (index) => {
                if (index === 1) {
                    // 卡loading TODO: 要改成新loading
                    GSLoading.addLoadingView();

                    // 取得要刪除的UID->送刪除CMD
                    DataProcess.sendString("mixFriend_say_delete " + JSON.stringify({
                        uid: this._getDeleteChatUidArray()
                    }));
                }
            }
        }), false);
    },

    /**
     * 點擊關閉按鈕
     */
    _closeBtnClicked: function () {
        GS.dispatchCustomEvent("NotifyCloseChatRoomLayer");
    },

    /**
     * 通知刷新聊天室清單
     */
    notifyFriendChatRoomListDone: function () {
        this.refreshView();
    },

    /**
     * 通知刷新單個cell(顯示or不顯示小紅點)
     * @param event cell的index
     */
    notifyUpdateFriendChatRoomList: function (event) {
        if (event) {
            // cell index
            var index = event.getUserData();

            if (index >= 0 && index < this._totalCellCount)
                // 更新單個cell
                this._tableView.updateCellAtIndex(index)
        }
    }
});