var GAFCustomAssetManager = (cc.sys.isNative ? GAFCustomAssetManager : null);

(function () {
    if (cc.sys.isNative)
        return;

    const CHECK_REF_TIME = 10;          // 每幾秒檢查一次是否要Release
    var instance = null;

    GAFCustomAssetManager = cc.Class.extend({
        ctor: function () {
            this._assetMap = {};

            //一直Repeat
            setInterval(_ => {
                var assetMap = this._assetMap;
                for (var key in assetMap) {
                    var assetObj = assetMap[key];

                    if (gaf.gafAssetObject[assetObj.filePath] == 1) {
                        //代表沒人在用了 把他砍掉
                        assetObj.reduceAssetRefCount();

                        delete assetMap[key];
                    }
                }
            }, CHECK_REF_TIME * 1000);
        },

        //一般抓取GAF Asset
        getAsset: function (gafFilePath, delegate, baseNode) {
            var retAsset = this._assetMap[gafFilePath];
            if (!retAsset) {
                //沒有要重創
                retAsset = gaf.Asset.create(gafFilePath, delegate, baseNode);
                this._assetMap[gafFilePath] = retAsset;

                // Ref Count要加1
                retAsset.addAssetRefCount();
            } else if (baseNode) {
                // 假如已經有Asset 要加一個callback管理GAFCustomAsset的REF
                var destroyNode = baseNode.getChildByName("GAFDestroyNode");
                if (!destroyNode) {
                    //要加一次
                    destroyNode = new GAFDestroyNode();
                    baseNode.addChild(destroyNode);
                }

                if (destroyNode.isRunning()) {
                    // 代表已經跑完過onEnter 自己手動加一次ref count
                    retAsset.addAssetRefCount();
                }

                // 加入Node後的callback
                destroyNode.addAssetOnEnterCallback(() => retAsset.addAssetRefCount());
                destroyNode.addAssetDestroyCallback(() => retAsset.reduceAssetRefCount());
            } else {
                cc.assert(0, 'GAFAsset需要Node傳進來用來之後release');
            }

            return retAsset;
        },

        //抓取GAF Zip Asset
        getAssetWithBundle: function (zipFilePath, entryFile, delegate, baseNode) {
            var retAsset = this._assetMap[zipFilePath];
            if (!retAsset) {
                //沒有要重創
                retAsset = gaf.Asset.createWithBundle(zipFilePath, entryFile, delegate, baseNode);
                this._assetMap[zipFilePath] = retAsset;
            } else if (baseNode) {
                // 假如已經有Asset 要加一個callback管理GAFCustomAsset的REF
                var destroyNode = baseNode.getChildByName("GAFDestroyNode");
                if (!destroyNode) {
                    // 要加一次
                    destroyNode = new GAFDestroyNode();
                    baseNode.addChild(destroyNode);
                }

                if (destroyNode.isRunning()) {
                    // 代表已經跑完過onEnter 自己手動加一次ref count
                    retAsset.addAssetRefCount();
                }

                // 加入Node後的callback
                destroyNode.addAssetOnEnterCallback(() => retAsset.addAssetRefCount());
                destroyNode.addAssetDestroyCallback(() => retAsset.reduceAssetRefCount());
            } else {
                cc.assert(0, 'GAFAsset需要Node傳進來用來之後release');
            }

            // Ref Count要加1
            retAsset.addAssetRefCount();

            return retAsset;
        },

        //移除GAF 快取 (當H5 GAFAsset下載失敗需要用)
        removeAsset: function (filePath) {
            var retAsset = this._assetMap[filePath];
            if (retAsset) {
                //要砍掉
                retAsset.reduceAssetRefCount();

                delete this._assetMap[filePath];
            }
        },

        // retain所有GAF Asset
        retainAllAsset: function () {
            for (var key in this._assetMap) {
                this._assetMap[key].addAssetRefCount();
            }
        },

        // release所有GAF Asset
        releaseAllAsset: function () {
            for (var key in this._assetMap) {
                this._assetMap[key].reduceAssetRefCount();
            }
        },
    });

    GAFCustomAssetManager.getInstance = function () {
        if (instance == null) {
            instance = new GAFCustomAssetManager();
        }
        return instance;
    };

    //一般抓取GAF Asset
    GAFCustomAssetManager.createAsset = function (gafFilePath, delegate, baseNode) {
        return GAFCustomAssetManager.getInstance().getAsset(gafFilePath, delegate, baseNode);
    };

    //抓取GAF Zip Asset
    GAFCustomAssetManager.createAssetWithBundle = function (zipFilePath, entryFile, delegate, baseNode) {
        return GAFCustomAssetManager.getInstance().getAssetWithBundle(zipFilePath, entryFile, delegate, baseNode);
    };

    //砍掉GAF Asset
    GAFCustomAssetManager.removeAsset = function (filePath) {
        GAFCustomAssetManager.getInstance().removeAsset(filePath);
    };

    GAFCustomAssetManager.retainAllAsset = function () {
        GAFCustomAssetManager.getInstance().retainAllAsset();
    };

    GAFCustomAssetManager.releaseAllAsset = function () {
        GAFCustomAssetManager.getInstance().releaseAllAsset();
    };

}.call((window || module || {})));