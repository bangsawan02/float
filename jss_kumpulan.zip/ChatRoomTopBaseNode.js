/**
 * v5.4.7 聊天室置頂的Base node (繼承使用)
 * 這邊只有放一些統一個背景跟格式
 * created by lichieh on 2023/1/4
 */
var ChatRoomTopBaseNode = cc.Node.extend({
    /**
     * @param chatRoomTitle  該聊天室的名稱
     * @param iconPic        該聊天室的icon
     */
    ctor: function (chatRoomTitle = "", iconPic) {
        this._super();

        var midPosY = FriendChatRoomListCell.HEIGHT / 2 + 1;

        // icon
        if (iconPic) {
            var giftBoxSp = new cc.Sprite(iconPic);
            giftBoxSp.setPosition(23, midPosY);
            this.addChild(giftBoxSp);
        }

        var btnSize = cc.size(ChatRoomLayer.WIDTH, FriendChatRoomListCell.HEIGHT);
        var chatRoomSp = ButtonUtility.createEmptyNodes(btnSize, chatRoomTitle, 13, JSColor.WHITE, cc.p(10, 0));
        chatRoomSp.forEach(function (cur) {
            // 箭頭
            var arrowSp = new cc.Sprite("#lobby_pic_arrow.png");
            arrowSp.setRotation(180);
            arrowSp.setPosition(168, midPosY);
            cur.addChild(arrowSp);
        });
        // 聊天室的ControlButton
        var button = this._chatRoomBtn = new cc.ControlButton(chatRoomSp[0]);
        button.setBackgroundSpriteForState(chatRoomSp[1], cc.CONTROL_STATE_HIGHLIGHTED);
        button.addTargetWithActionForControlEvents(this, this._clickDiscountNotifyRoomBtn, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
        button.setAdjustBackgroundImage(false);
        button.setZoomOnTouchDown(false);
        button.setSwallowTouches(false);
        button.setTouchDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL);
        button.setPosition(ChatRoomLayer.WIDTH / 2, midPosY);
        this.addChild(button);

        // cell分隔線
        var lineSp = new ccui.Scale9Sprite("lobby_brown_line.png");
        lineSp.setPreferredSize(cc.size(170, 4));
        lineSp.setPosition(92, 2);
        this.addChild(lineSp);

        var badge = this._badge = new BadgeNode();
        badge.useDefaultStyle();
        badge.setPosition(12, 35);
        this.addChild(badge);
    },

    /**
     * 點開該聊天室
     */
    _clickDiscountNotifyRoomBtn: function () {
        var obj = {
            type: ChatRoomPageType.NOTIFY
        };
        GS.dispatchCustomEvent("NotifyShowChatRoomLayerByPageType", obj);
    },
});