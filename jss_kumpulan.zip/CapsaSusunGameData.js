var CapsaSusunGameData = BaseGameData.extend({
    ctor: function () {
        this._super();

        //初始化
        this.gameSerialID = "";                         // 場編
        this.gameRoomTypeName = "";                     // 遊戲房間Type
        this.gameRoomName = "";                         // 遊戲房間名稱
        this.gameType = 0;                              // 遊戲類型
        this.region = 0;                                // 遊戲的region
        this.playerNumber = 4;                          // 4人
        this.diouwait = 10;                             // 輪到一個人的出手時間
        this.anteValue = 0;                             // 目前桌子的底注
        this.haveMe = false;                            // updateSeat中有沒有我
        this.isTeachMode = false;                       // 是否是新手教學模式
        this.myPos = -1;                                // 自已的位置
        this.isMeBet = false;                           // 自己是否有下注
        this.isMeFold = false;                          // 自己是否棄牌
        this.waitChangeTime = 0;                        // 等待換桌的秒數

        this.playerDataArray = [];                      // Player Data Array
        this.serverSitNum = [];                         // 設計一個可以從畫面位置，去找到server位置的Array變數，這樣找比較快
                                                        // ex.this.serverSitNum[0]=4；表示畫面上第0個位置在server上是第4個位置

        this.leaveGameStatus = Remi_LeaveGameStatus.CAN_LEAVE;

        this._playerCount = 0;                          // 現在有幾會玩家 Gaple可以2~4人開始遊戲

        //初始化玩家資料
        for (var i = 0; i < this.playerNumber; i++) {
            this.playerDataArray[i] = new GamePlayerData();
            this.serverSitNum[i] = i;
        }

        //Socket
        this.cmdQueueArray = [];                        //Queue Socket CMD的Array

        // 牌局重現
        this.isReconnect = false;
        this.isReappearIng = false;                     //在牌局重現中 是true的話 有些都西不跑

        //註冊SocketKey
        var receiveSocketCMD = this._receiveSocketCMD;
        DataProcess.addSocketKeyDispatch(this, {
            // 開始遊戲的進入點 這幾個單獨處理
            "gsOLEH_extra": this.cmd_gsOLEH_extra,
            "gsOLEH_for_mobile": this.cmd_gsOLEH_for_mobile,

            "joinRoomAnte": receiveSocketCMD,
            "gsOLEH": receiveSocketCMD,
            "OLEH": receiveSocketCMD,

            "myPos": receiveSocketCMD,
            "updateSeat": receiveSocketCMD,
            "last_cmd": receiveSocketCMD,
            "current_playing": receiveSocketCMD,
            "roomparam": receiveSocketCMD,
            "dealer": receiveSocketCMD,
            "updateChips": receiveSocketCMD,
            "updateInfo": receiveSocketCMD,
            "wait_to_change": receiveSocketCMD,

            // 開始遊戲
            "ServerReady": receiveSocketCMD,
            "startGame": receiveSocketCMD,

            // 站起坐下
            "stand": receiveSocketCMD,

            // 玩遊戲的指令
            "Param": receiveSocketCMD,          // 發牌
            "playing": receiveSocketCMD,
            "play": receiveSocketCMD,
            "game_autoplay": receiveSocketCMD,  // 自動代打
            //一般局的牌相關
            "special": receiveSocketCMD,
            "decision_time": receiveSocketCMD,
            "deckfight": receiveSocketCMD,
            "plspecial": receiveSocketCMD,      // 其他玩家準備好 有特殊牌 先不開牌
            "plready": receiveSocketCMD,        // 其他玩家準備好 一般牌型 可以開牌
            "foulHand": receiveSocketCMD,       // 相公 一開始就自爆
            // 比牌
            "plscore": receiveSocketCMD,        // 分數
            "pltotal": receiveSocketCMD,        // 總分
            "fight": receiveSocketCMD,          // 開始一般比牌
            "strike": receiveSocketCMD,
            "homerun": receiveSocketCMD,
            "fightover": receiveSocketCMD,

            // 離桌
            "toLobby": receiveSocketCMD,

            // 積分系統
            "showPlayerClass": receiveSocketCMD,
            "gameRank_protect_info": receiveSocketCMD,
            "gameRank_protect_remain": receiveSocketCMD,
            "gameRank_class": receiveSocketCMD,
            "gameRank_update": receiveSocketCMD,
            "gameRank_booster_info": receiveSocketCMD,

            // koinLuxy資訊
            "koin_luxy_room_status": receiveSocketCMD,

            // 結算
            "finish": receiveSocketCMD,
            "stopGame": receiveSocketCMD,
            "NextGame": receiveSocketCMD,

            //坐下錯誤
            "sitFail": receiveSocketCMD,

            // 結算後的升級之類的東西
            "update_level": receiveSocketCMD,
            "update_skillrate": receiveSocketCMD,
            "update_getexp": receiveSocketCMD,
            "update_upgrade": receiveSocketCMD,
            "update_gameRankUpdate": receiveSocketCMD,

            // 破產
            "need_pay": receiveSocketCMD,
            "broken_reward": receiveSocketCMD,

            //錯誤訊息
            "little_tips": receiveSocketCMD,

            // 表情
            "mood": receiveSocketCMD,
            "vmood": receiveSocketCMD,
            "amood": receiveSocketCMD,
            "store_mood": receiveSocketCMD,

            // 互動表情
            "act_moods": receiveSocketCMD,

            // 送禮
            "gift_accessory": receiveSocketCMD,

            // 送禮包
            "gift_package": receiveSocketCMD,

            // 顯示提示
            "show_intro": receiveSocketCMD
        });
    },

    /**
     * 砍掉Data
     */
    destroyGameData: function () {
        this.cleanGameData();
        DataProcess.removeSocketKeyDispatch(this);
    },

    /**
     *  清掉遊戲中的資料
     */
    cleanGameData: function () {
        // 目前的SocketCMD清空
        this.clearSocketQueue();

        // 重設參數
        this.isMeBet = false;
        this.isMeFold = false;

        this.leaveGameStatus = Remi_LeaveGameStatus.CAN_LEAVE;

        this._playerCount = 0;
    },

    /**
     * 重設所有玩家資料
     * @param {number} 玩家數量
     */
    resetPlayersData: function () {
        this.serverSitNum.length = 0;
        for (var i = 0; i < this.playerNumber; i++) {
            this.playerDataArray[i].resetGameData();
            this.serverSitNum[i] = i;
        }
    },

    /**
     * 注冊畫面上的Players,單純為了方便找位置，別做其它事
     * @param {layer}
     */
    registerPlayersLayer: function (players) {
        this.players = players;
    },

    /**
     * 用畫面上的位置取得Server玩家的位置
     * @param {index} 畫面上的位置, 自已是0，自已左邊是1，自已右邊3
     */
    getServerDirectionByDirection: function (index) {
        return this.serverSitNum[index];
    },

    /**
     * 找目前Server是做那一個畫面上的位置
     * @param {index} Server的位置
     */
    getDirectionByServerDirection: function (index) {
        return this.players[index] && this.players[index].sitNum;
    },

    /**
     * 取得自已的PlayerData
     */
    getMyPlayerData: function () {
        if (this.myPos != -1) {
            return this.playerDataArray[this.myPos];
        } else {
            return null;
        }
    },

    /**
     * 回傳目前的server的位置是不是自已
     * @param serverSitNum server的位置
     * @returns {Boolean} 是否為自已
     */
    getIsSelfByServerSitNum: function (serverSitNum) {
        return this.playerDataArray[serverSitNum].getIsSelf();
    },

    /**
     * 檢查是否離開遊戲是否要Block
     * @returns {boolean}
     */
    checkLeaveGameNeedBlock: function () {
        //牌桌有我 && 有下注 && 沒棄牌 且超過一個人
        return this.haveMe && this.isMeBet && !this.isMeFold;
    },

    /**
     * 現在有幾位玩家
     */
    getPlayerCount: function () {
        return this._playerCount;
    },

    /**
     * 獨立處理的Socket
     */
    // 房間資訊 要在 gsOLEH_for_mobile 前噴回來
    cmd_gsOLEH_extra: function (key, value) {
        var param = JSON.parse(value);
        this.gameRoomTypeName = JSCodeUtility.getStringValue(param["room_type_name"]);
        this.gameRoomName = JSCodeUtility.getStringValue(param["room_name"]);
        this.region = JSCodeUtility.getIntValue(param["region"]);
    },

    // 遊戲時間 遊戲類型 並取代toGame
    cmd_gsOLEH_for_mobile: function (key, value) {
        var valueArray = value.split(" ");
        if (valueArray.length >= 2) {
            this.gameRoundTime = JSCodeUtility.getIntValue(valueArray[0]);
            this.gameType = JSCodeUtility.getIntValue(valueArray[1]);
        }

        //重設所有玩家資料
        this.resetPlayersData();

        //清上一場cmdQueueArray && Other
        this.cleanGameData();

        //傳!EXTRA
        DataProcess.sendString("!EXTRA");

        DataProcess.sendString("get_broke_payment_json");       // 抓遊戲破產儲值payment

        //通知進遊戲了
        GS.dispatchCustomEvent("NotifyStartGame");
    },

    /**
     * override掉 需要回傳是否要給UI處理 true or false
     */
    _processGameCommand: function (socketParam) {
        // 假如空的也代表停下來
        if (!socketParam)
            return true;

        var retValue = false;
        var value = socketParam.value;

        switch (socketParam.key) {
            case "joinRoomAnte":
                // 進桌前先給我底注
                this.anteValue = JSCodeUtility.getIntValue(value);
                break;

            case "gsOLEH":
                try {
                    var jsonValue = JSON.parse(value);
                    // 場編
                    this.gameSerialID = JSCodeUtility.getStringValue(jsonValue["gid"]);

                    // 出牌時間
                    this.diouwait = JSCodeUtility.getIntValue(jsonValue["diouwait"]);

                    // 結算後進下一輪時間
                } catch (e) {
                }

                break;

            /**
             * [OLEH H94429344908769]
             */
            case "OLEH":
                var valueArray = value.split(" ");
                if (valueArray.length >= 1) {
                    //場編
                    this.gameSerialID = valueArray[0];
                }

                //flag重設
                this.isMeBet = false;
                this.isMeFold = false;
                this.blindStatus = 0;

                // 給UI處理
                retValue = true;

                break;

            /**
             * [myPos -1] 玩家坐下某位置。-1有兩種情況 一種是剛進比賽 另外一種是站起來也會收到-1
             */
            case "myPos":
                var valueArray = value.split(" ");
                if (valueArray.length >= 1) {
                    this.myPos = JSCodeUtility.getIntValue(valueArray[0]);
                }

                // 給UI處理
                retValue = true;
                break;

            /**
             * roomparam 400 20000 20000 設定房間資訊
             */
            case "roomparam":
                // ante min_bring_in max_bring_in seat_fee
                var valueArray = value.split(" ");
                this.anteValue = JSCodeUtility.getIntValue(valueArray[0]);

                // 給UI處理
                retValue = true;
                break;

            /**
             * [updateSeat [{"userid":"","nick":"w52427714",,,,,etc},{},{},{},{},{},{},{},{}]]
             */
            case "updateSeat":
                var jsonParam = JSON.parse(value);
                var len = jsonParam.length;
                this._playerCount = 0;
                this.haveMe = false;
                for (var i = 0; i < len; i++) {
                    var param = jsonParam[i];
                    var playerData = this.playerDataArray[i];
                    if (playerData && param && !_.isEmpty(param)) {
                        this._playerCount++;

                        //帳號
                        playerData.account = JSCodeUtility.getStringValue(param.userid);

                        try {
                            //匿稱
                            playerData.nickname = decodeURIComponent(JSCodeUtility.getStringValue(param.nick));

                            //稱號
                            playerData.titlename = decodeURIComponent(JSCodeUtility.getStringValue(param.title));
                        } catch (e) {
                            playerData.nickname = "";
                            playerData.titlename = "";
                        }

                        //大頭貼網址
                        playerData.photoURL = JSCodeUtility.getStringValue(param.pic);

                        //玩家框框類型
                        playerData.identity = JSCodeUtility.getStringValue(param.identity);

                        //玩家聊天框類型
                        playerData.chatBox = JSCodeUtility.getStringValue(param.chatBox);

                        //等級
                        playerData.level = JSCodeUtility.getIntValue(param.level);

                        //現在金錢
                        playerData.money = JSCodeUtility.getIntValue(param.tmoney);

                        //配戴徽章編號、名稱
                        if (param.medal == "8101" || param.medal == "") {
                            playerData.medal.code = "";
                            playerData.medal.name = "";
                        } else {
                            playerData.medal.code = JSCodeUtility.getStringValue(param["medal"]);
                            playerData.medal.name = JSCodeUtility.getStringValue(param["name_medal"]);
                        }

                        //配戴物品編號、名稱
                        if (param.accessory == "1101" || param.accessory == "") {
                            playerData.accessory.code = "";
                            playerData.accessory.name = "";
                        } else {
                            playerData.accessory.code = JSCodeUtility.getStringValue(param["accessory"]);
                            playerData.accessory.name = JSCodeUtility.getStringValue(param["name_accessory"]);
                        }

                        // 男生、女生
                        playerData.isMale = JSCodeUtility.getStringValue(param.gender) === "m";

                        // 積分系統的階級 若是空的則是沒有階級
                        var userClass = param["userClass"];
                        playerData.userClass = userClass ? JSCodeUtility.getIntValue(param["userClass"]) : null;

                        if (playerData.getIsSelf()) {
                            this.myPos = i;
                            this.haveMe = true;

                            //Update Profile data
                            var profileData = DataModal.profileData;
                            playerData.exp = profileData.exp;
                        }

                    } else {
                        playerData && playerData.resetGameData();
                    }
                }

                // 如果自己是觀戰者 只有離桌選項
                if (!this.haveMe) {
                    this.leaveGameStatus = Remi_LeaveGameStatus.CAN_LEAVE;
                    this.myPos = -1;
                }

                // 給UI處理
                retValue = true;
                break;
            case "wait_to_change":
                // 等待換桌的時間
                this.waitChangeTime = JSCodeUtility.getIntValue(value);
                break;
            case "getPlayerClass":
                // 遊戲內更新階級
                var jsonParam = JSON.parse(value);
                var userClass = jsonParam.userClass;
                if (userClass) {
                    for (var i = 0, len = userClass.length; i < len; i++) {
                        var playerData = this.playerDataArray[i];
                        playerData && (playerData.userClass = JSCodeUtility.getIntValue(userClass[i]));
                    }
                }

                // 給UI處理
                retValue = true;

                break;

            /**
             * Server準備開局
             */
            case "ServerReady":
                // 代表要開局了 不能離開
                this.leaveGameStatus = Remi_LeaveGameStatus.NO_LEAVE;

                // 送通知告知UI換狀態
                GS.dispatchCustomEvent("NotifyRefreshLeaveStatus");

                // 給UI處理
                retValue = true;

                break;

            case "playing":
                // 現在有哪些人玩 來判斷是否在裡面玩 可以離開
                var playingPlayers = JSON.parse(value);
                if (this.myPos >= 0) {
                    this.leaveGameStatus = playingPlayers.indexOf(this.myPos) < 0
                        ? Remi_LeaveGameStatus.CAN_LEAVE
                        : this.leaveGameStatus;
                } else
                    this.leaveGameStatus = Remi_LeaveGameStatus.CAN_LEAVE;

                // 送通知告知UI換狀態
                GS.dispatchCustomEvent("NotifyRefreshLeaveStatus");

                // 給UI處理
                retValue = true;

                break;

            /**
             * stand pos 第pos位置站起來
             */
            case "stand":
                var serverSitNum = parseInt(value);
                var data = this.playerDataArray[serverSitNum];
                if (data && data.getIsSelf()) {
                    this.haveMe = false;

                    //flag重設
                    this.isMeBet = false;
                    this.isMeFold = false;
                }

                // 給UI處理
                retValue = true;
                break;

            case "need_pay":
                var array = value.split(" ");
                var needPayPos = parseInt(array[0] || -2);
                // 是自己破產再做
                retValue = this.myPos === needPayPos;
                break;

            /**
             * [last_cmd [["plcheck"],[],[],[],[],[],[],[],[]]]
             */
            case "last_cmd":
                var jsonParam = JSON.parse(value);
                for (var i = 0, len = jsonParam.length; i < len; i++) {
                    var playerData = this.playerDataArray[i];
                    if (playerData)
                        playerData.last_cmd = jsonParam[i];
                }

                // 給UI處理
                retValue = true;
                break;

            case "updateChips":
                var valueArray = JSON.parse(value);
                for (var i = 0, len = valueArray.length; i < len; i++) {
                    var playerData = this.playerDataArray[i];
                    if (playerData)
                        playerData.tableChips = JSCodeUtility.getIntValue(valueArray[i]);
                }

                // 給UI處理
                retValue = true;

                break;

            case "finish":
                // 結算 結算狀態 [各家輸贏金錢]
                // 結算 finish ["-11500000","10350000","0","0"]
                var winMoneys = JSON.parse(value) || [];
                winMoneys.forEach((money, index) => {
                    if (money)
                        this.playerDataArray[index].money += parseInt(money);
                });

                // 給UI處理
                retValue = true;

                break;

            case "NextGame":
                // 結算完了 要到下一場 把預約離開的設成可離開
                this.leaveGameStatus = Remi_LeaveGameStatus.CAN_LEAVE;

                // 送通知告知UI換狀態
                GS.dispatchCustomEvent("NotifyRefreshLeaveStatus");

                break;

            case "mRC_setState":
                // 牌局重現的指令要放在第一個
                this.cmdQueueArray.splice(0, 0, {
                    key: key,                   //Socket CMD Key
                    value: value                //Socket CMD Value
                });
                break;

            default:
                // 沒寫的統一給UI處理
                retValue = true;
                break;
        }

        return retValue;
    }
});
