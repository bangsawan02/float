var CapsaSusun_GameUtility = {};

/*
 位置順序圖

       2
 1            3
     0(玩家)
 */

(function () {
    // 玩家位置 (先產生好 之後要加上JSScreenBonus 這樣可以減省掉每次都要產生多次的cc.p)
    var GAME_PLAYER_POSITION = [
        cc.p(108, 37),
        cc.p(49, 151),
        cc.p(160, 260),
        cc.p(463, 151),
    ];

    // 莊家圖片的位置 (先產生好 之後要加上JSScreenBonus 這樣可以減省掉每次都要產生多次的cc.p)
    var GAME_DEAL_IMAGE_POSITION = [
        cc.p(83, 55),
        cc.p(99, 146),
        cc.p(256, 205),
        cc.p(413, 146),
    ];

    var CARD_STACK_MIDDLE_POSITION = [
        cc.p(255, 55),
        cc.p(145, 143),
        cc.p(255, 230),
        cc.p(367, 143)
    ];

    /**
     * 回傳玩家大頭貼的位置 <br/>
     * @param {sitNum} 畫面上的位置 <br/>
     */
    CapsaSusun_GameUtility.getPlayerPosition = function (sitNum) {
        // -1是荷官
        if (parseInt(sitNum) === -1) {
            return cc.p(JSScreenMidPos.x, 238 + JSScreenBonusHalfHeight);
        }

        // 其他位置
        var originPos = GAME_PLAYER_POSITION[sitNum];
        var bonusHeight = 0;
        switch (sitNum) {
            case 0:
                bonusHeight = 0;
                break;
            default:
                bonusHeight = JSScreenBonusHalfHeight;
                break;
        }
        return cc.p(originPos.x + JSScreenBonusHalfWidth, originPos.y + bonusHeight);
    };

    /**
     * 回傳這一局的Dealer的位置(黑色底圖上面有一個"D") <br/>
     * @param {sitNum} 畫面上的位置
     */
    CapsaSusun_GameUtility.getDealerPosition = function (sitNum) {
        var originPos = GAME_DEAL_IMAGE_POSITION[sitNum];
        var bonusHeight = sitNum === 0
            ? 0
            : sitNum === 2 ? JSScreenBonusHeight : JSScreenBonusHalfHeight;
        return cc.p(originPos.x + JSScreenBonusHalfWidth, originPos.y + bonusHeight);
    };


    /**
     * 回傳玩家手牌中心的位置 (在第二墩中間牌稍微偏下方)
     * @param {sitNum} 畫面上的位置 <br/>
     */
    CapsaSusun_GameUtility.getCardStacksMidPos = function (sitNum) {
        // 其他位置
        var originPos = CARD_STACK_MIDDLE_POSITION[sitNum];
        return cc.p(originPos.x + JSScreenBonusHalfWidth, originPos.y + JSScreenBonusHalfHeight);
    };

    /**
     * 取牌型文字的美術圖檔名
     * @param type
     * @returns {string}
     */
    CapsaSusun_GameUtility.getAniNameBySpecialCardType = function (type) {
        var aniName = "";
        switch (type) {
            case CapsaSusun_SpecialCardType.None:
                // 預設值
                break;
            case CapsaSusun_SpecialCardType.CDragon:
                // 清龍
                aniName = "act01";
                break;
            case CapsaSusun_SpecialCardType.OneDragon:
                // 一條龍
                aniName = "act02";
                break;
            case CapsaSusun_SpecialCardType.twelveKing:
                // 12王族
                aniName = "act03";
                break;
            case CapsaSusun_SpecialCardType.SixPair:
                // 六對半
                aniName = "act10";
                break;
            case CapsaSusun_SpecialCardType.ThreeStraight:
                // 三順子
                aniName = "act11";
                break;
            case CapsaSusun_SpecialCardType.ThreeFlush:
                // 三同花
                aniName = "act12";
                break;
            case CapsaSusun_SpecialCardType.ThreeRoyalFlush:
                // 三同花順
                aniName = "act04";
                break;
            case CapsaSusun_SpecialCardType.ThreeDivide:
                // 三分天下
                aniName = "act05";
                break;
            case CapsaSusun_SpecialCardType.AllBig:
                // 全大
                aniName = "act06";
                break;
            case CapsaSusun_SpecialCardType.AllSmall:
                // 全小
                aniName = "act07";
                break;
            case CapsaSusun_SpecialCardType.SameColor:
                // 湊一色
                aniName = "act08";
                break;
            case CapsaSusun_SpecialCardType.FourThree:
                // 四套三條
                aniName = "act09";
                break;
            case CapsaSusun_SpecialCardType.HomeRun:
                // 全壘打
                break;
        }

        return aniName;
    };
})();
