/**
 * JSScreenBonusHalfWidth / JSScreenBonusHalfHeight在外面加了
 */
var DailyMissionLayer = cc.Layer.extend({
    ctor: function (whereType, missionType) {
        this._super();

        var freeChipStr = LocalizedString.FreeChip;
        this._whereType = whereType;
        this._missionType = missionType;
        this._totalCellCount = 0;       //總數
        this._boxButtonArray = [];      //寶箱按鈕陣列

        DataModal.dailyMissionData.haveRewardDailyMission = false;

        // 分隔線的光
        var lineLight = new cc.Sprite("#lobby_pic_light_gold.png");
        lineLight.setFlippedY(true);
        lineLight.setPosition(284, 38);
        this.addChild(lineLight);

        // 分隔線
        var lineSprite = new cc.Sprite("#lobby_division_line.png");
        lineSprite.setScaleX(48);
        lineSprite.setPosition(284, 48);
        this.addChild(lineSprite);

        var tableViewSize = cc.size(DailyMissionLayer.TABLE_CONTENT_WIDTH, 144);

        // TableView的黑底
        var blackLayer = new cc.LayerColor(cc.color(0, 0, 0, 255), tableViewSize.width, tableViewSize.height);
        blackLayer.setPosition(95, 92);
        this.addChild(blackLayer, -1);

        // 沒任務的文字
        var emptyLabel = this._emptyLabel = new cc.LabelTTF(freeChipStr("每日任務將於早上06:00重置"), JSFontBoldName, 11);
        emptyLabel.setPosition(95 + tableViewSize.width / 2, 92 + tableViewSize.height / 2);
        emptyLabel.setVisible(false);
        this.addChild(emptyLabel);

        // TableView
        var tableView = this._tableView = new cc.TableView(this, tableViewSize, new cc.Layer());
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setPosition(95, 92);
        this.addChild(tableView);

        // 上下兩邊各加DummyTouch來擋住cell的按鈕
        for (var i = 0; i < 2; i++) {
            var tableCellBtnDummy = new DummyTouchLayer(cc.size(44, 40), false);
            tableCellBtnDummy.setPosition(448, (i === 0 ? 237 : 52));
            this.addChild(tableCellBtnDummy);
        }

        // 活躍區域Node
        var activityNode = this._activityNode = new cc.Node();
        this.addChild(activityNode);

        // 一鍵領取按鈕
        var itemNodes = ButtonUtility.createArrayScale9Nodes(["lobby_btn_03.png", "lobby_btn_03.png", "lobby_btn_06.png"], cc.size(90, 22), freeChipStr("一鍵領取"), 12, [JSColor.WHITE, JSColor.WHITE, JSColor.BLACK]);
        itemNodes[2].setOpacity(255);
        var rewardAllBtn = this._rewardAllBtn = new GSControlButton(itemNodes[0]);
        rewardAllBtn.setBackgroundSpriteForState(itemNodes[2], cc.CONTROL_STATE_DISABLED);
        rewardAllBtn.addTouchUpInsideAction(this._rewardAllBtnClicked, this);
        rewardAllBtn.setPosition(446, 23);
        rewardAllBtn.setEnabled(false);
        this.addChild(rewardAllBtn);

        // 版本累積說明
        var explainLabel = new cc.LabelTTF(LocalizedString.FreeChip("*遊戲版本5.4.3以下恕不累計任務進度"), JSFontBoldName, 8);
        explainLabel.setAnchorPoint(0, 0.5);
        explainLabel.setFontFillColor(cc.color(249, 230, 100));
        explainLabel.setPosition(100, 24);
        this.addChild(explainLabel);

        // 加入讀取
        this._addLoading();

        //註冊通知
        GS.addListener("NotifyDailyMissionLoading", this.notifyDailyMissionLoading.bind(this), this);               //加讀取
        GS.addListener("NotifyUpdateDailyMission", this.notifyUpdateDailyMission.bind(this), this);                 //更新畫面
        GS.addListener("NotifyGotDailyMissionReward", this.notifyGotDailyMissionReward.bind(this), this);           //跳領獎畫面
        GS.addListener("NotifyGotDailyMissionRewardFail", this.notifyGotDailyMissionRewardFail.bind(this), this);   //領獎失敗
        GS.addListener("NotifyDailyMissionRewardClicked", this.notifyDailyMissionRewardClicked.bind(this), this);   //按到領獎
    },

    onEnter: function () {
        this._super();

        // 更新所有資訊 在onEnter後活躍值轉換視窗才能正常跳在ActionListDialog上方
        this._updateAllInfo(true);
    },

    onExit: function () {
        // 在桌列表 有領獎要去重拿桌列表
        if (this._whereType === DailyMissionEnum.whereType.Room && DataModal.dailyMissionData.haveRewardDailyMission)
            GS.dispatchCustomEvent("NotifyRefreshRoomList");

        this._super();
    },

    // 加入讀取
    _addLoading: function () {
        // 加之前先檢查有沒有加過，有的話要拿掉
        this._removeLoading();

        var touchLayerSize = cc.size(400, 250);

        // 檔Touch用
        var loadingLayer = this._loadingLayer = new DummyTouchLayer(touchLayerSize);
        loadingLayer.setPosition(97, 8);
        this.addChild(loadingLayer, 10);

        // 讀取動畫
        var loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.start();
        loadingSprite.setPosition(194, 144);
        loadingLayer.addChild(loadingSprite, 10);
    },

    /**
     * 拿掉loading畫面
     */
    _removeLoading: function () {
        if (this._loadingLayer) {
            this._loadingLayer.removeFromParent();
            this._loadingLayer = undefined;
        }
    },

    /**
     * 更新所有資訊
     */
    _updateAllInfo: function (reset) {
        var freeChipStr = LocalizedString.FreeChip;
        var dailyMissionData = DataModal.dailyMissionData;

        if (!dailyMissionData.getHaveDailyMissionDone())
            return;

        var missionList = this._missionList = DataModal.dailyMissionData.getDailyMissionList();
        var cellCount = this._totalCellCount = missionList && missionList.length || 0;
        var isHaveMission = cellCount > 0;

        // 拿掉讀取
        this._removeLoading();

        this._tableView.setVisible(isHaveMission);
        cellCount > 0 && this._tableView.reloadData(reset);
        this._emptyLabel.setVisible(!isHaveMission);

        // 更新活躍區
        this._activityNode.setVisible(isHaveMission);
        this._refreshActivityNode();

        // 刷新一鍵領獎狀態
        this._rewardAllBtn.setVisible(isHaveMission);
        this._rewardAllBtn.setEnabled(dailyMissionData.getHaveReward());

        // 需要跳活躍值轉換
        if (dailyMissionData.activityConvertParam) {
            var convertParam = dailyMissionData.activityConvertParam;

            var dialog = new CommonDialog({
                title: freeChipStr("活躍值轉換"),
                content: JSStringUtility.format(freeChipStr("您在舊遊戲累積的%d活躍\n已依50%%比例轉換為#!FB0007!#%d#!FFFFFF!#新活躍"), convertParam.oldValue, convertParam.newValue),
                buttons: [LocalizedString.Common("確認")],
                closeButton: 0
            });

            DialogManager.addDialog(dialog, false);

            // 跳完就清空資料
            dailyMissionData.activityConvertParam = undefined;
        }
    },

    /**
     * 更新活躍值區域
     */
    _refreshActivityNode: function () {
        var freeChipStr = LocalizedString.FreeChip;

        // 清空
        var activityNode = this._activityNode;
        activityNode.removeAllChildren();
        this._infoNode = undefined;

        // 背景彩圖
        var bgSp = new ccui.Scale9Sprite("daily_mission_pic_line_activity.png");
        bgSp.setPreferredSize(cc.size(400, 50));
        bgSp.setAnchorPoint(0, 0);
        bgSp.setPosition(95, 40);
        activityNode.addChild(bgSp);

        // 抓資料
        var dailyMissionData = DataModal.dailyMissionData;
        var activityParam = dailyMissionData.activityParam || {};

        // 放寶箱的Node
        var boxBtnNode = this._boxBtnNode = new cc.Node();
        boxBtnNode.setCascadeColorEnabled(true);
        boxBtnNode.setCascadeOpacityEnabled(true);
        activityNode.addChild(boxBtnNode, 1);

        // 放寶箱點下去的資訊Node
        var boxInfoNode = this._boxInfoNode = new cc.Node();
        boxInfoNode.setCascadeColorEnabled(true);
        boxInfoNode.setCascadeOpacityEnabled(true);
        activityNode.addChild(boxInfoNode, 10);

        for (var i = 0; i < 2; i++) {
            // 0:今日 1:週
            var isDaily = i === 0;
            // 抓今日or週資料
            var param = (isDaily) ? activityParam.daily : activityParam.weekly;
            if (!param)
                continue;

            // 活躍值顯示區
            {
                // 旗子
                var flagSp = new ccui.Scale9Sprite("daily_mission_pic_flag_01.png");
                flagSp.setPreferredSize(cc.size(41, 50));
                flagSp.setPosition((isDaily) ? 116 : 358, 66);
                activityNode.addChild(flagSp);

                // 獎牌圖+今日or週
                var autoNode = new GSAutoLayoutNode();
                autoNode.setSpace(1);
                autoNode.setPosition(cc.pAdd(flagSp.getPosition(), cc.p(0, 15)));
                activityNode.addChild(autoNode);

                // 獎牌
                var badgeSp = new cc.Sprite("#daily_mission_pic_activity-badge.png");
                badgeSp.setScale(0.3);
                autoNode.addChild(badgeSp);

                // 今日/週
                var label = new cc.LabelTTF(freeChipStr((isDaily) ? "今日" : "周"), JSFontBoldName, 7);
                autoNode.addChild(label);

                // 活躍字
                label = new cc.LabelTTF(freeChipStr("活躍"), JSFontBoldName, 7);
                label.setPosition(cc.pAdd(autoNode.getPosition(), cc.p(0, -9)));
                activityNode.addChild(label);

                // 背景框
                var bgSp = new ccui.Scale9Sprite("bg_black_01.png");
                bgSp.setPreferredSize(cc.size(34, 15));
                bgSp.setOpacity(153);
                bgSp.setPosition(cc.pAdd(autoNode.getPosition(), cc.p(0, -25)));
                activityNode.addChild(bgSp);

                // 活躍值label
                label = new cc.LabelTTF(JSCodeUtility.getCurrencyString(param.activity), JSFontBoldName, 10);
                label.setPosition(bgSp.getPosition());
                activityNode.addChild(label);
            }

            // 寶箱位移
            var boxOffset = 46;
            // 進度條
            {
                var barSize = (isDaily) ? cc.size(185, 10) : cc.size(90, 10);
                var gapPercent = (boxOffset / barSize.width) * 100;
                var progressBar = new GSProgressTimer("lobby_loading_bar_bg.png", "loading_bar.png", barSize, barSize);
                progressBar.setPosition((isDaily) ? cc.p(235, 68) : cc.p(428, 68));
                progressBar.setPercentage(gapPercent * (param.finishStage + param.gapRatio), false);
                activityNode.addChild(progressBar);
            }

            // 日/週寶箱
            var totalBoxCount = (isDaily) ? 4 : 2;
            for (var j = 0; j < totalBoxCount; j++) {
                var chestParam = param.chestList[j];
                if (!chestParam)
                    return;

                chestParam.isDaily = isDaily;
                var boxPos = cc.p(((isDaily) ? 177 : 418) + boxOffset * j, progressBar.getPositionY() + 3);

                var itemNodes = ButtonUtility.createSingleScale9Nodes(JSStringUtility.format("lobby_daily_box_%02d.png", chestParam.status));
                itemNodes[2].setOpacity(255);
                var boxButton = new cc.ControlButton(itemNodes[0]);
                boxButton.setBackgroundSpriteForState(itemNodes[1], cc.CONTROL_STATE_HIGHLIGHTED);
                boxButton.setBackgroundSpriteForState(itemNodes[2], cc.CONTROL_STATE_DISABLED);
                boxButton.addTargetWithActionForControlEvents(this, this._controlBoxRewardClicked, cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_UP_INSIDE | cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_CANCEL);
                boxButton.setPosition(boxPos);
                boxButton.setScale(0.65);
                boxButton.param = chestParam;
                boxButton.setAdjustBackgroundImage(false);
                boxButton.setZoomOnTouchDown(false);
                this._boxBtnNode.addChild(boxButton, 1);

                switch (chestParam.status) {
                    case DailyMissionEnum.chestRewardStatus.NOT_COMPLETE: // 未完成
                        // boxButton.setEnabled(false);
                        break;
                    case DailyMissionEnum.chestRewardStatus.CAN_GET_REWARD: // 可領獎完成
                        // 加字圖
                        itemNodes.forEach(cur => {
                            var rewardSprite = new cc.Sprite("#lobby_word_reward.png");
                            rewardSprite.setScale(1.5);
                            rewardSprite.setPosition(cur.getContentSize().width / 2, 13);
                            cur.addChild(rewardSprite);
                        });
                        break;
                    case DailyMissionEnum.chestRewardStatus.GET_REWARD_DONE: // 已領過
                        boxButton.setEnabled(false);
                        boxButton.setScale(0.5);
                        break;
                }
                this._boxButtonArray.push(boxButton);

                // 加到達寶箱值的文字
                var boxValueLabel = new cc.LabelTTF(JSStringUtility.format("%d", chestParam.goal), JSFontName, 7);
                boxValueLabel.enableStroke(JSColor.BLACK, 2);
                boxValueLabel.setPosition(cc.pAdd(boxButton.getPosition(), cc.p(0, -18)));
                this._boxBtnNode.addChild(boxValueLabel);
            }

            // 活躍區倒數
            var activityTimeLabel = new GSTimeLabel("", JSFontBoldName, 7);
            activityTimeLabel.setMultiFormat(freeChipStr("(%ddD:%hhH刷新)"), freeChipStr("(%hhH:%mmM刷新)"), freeChipStr("(%mmM:%ssS刷新)"));
            activityTimeLabel.setPosition((i === 0) ? 235 : 429, 45);
            activityTimeLabel.countdownSeconds(JSCodeUtility.getRemainTime(param.remainTime, param.socketTime), () => {
                // 重新要資料
                dailyMissionData.resetAllValue();
                dailyMissionData.startGetInfo(this._whereType);
            });
            activityNode.addChild(activityTimeLabel);
        }

        // 說明按鈕
        var infoBtn = ButtonUtility.createSimpleImageButton("btn_circle_01.png", null, "#lobby_btn_pic_black_?.png");
        infoBtn.addTargetWithActionForControlEvents(this, this._infoBtnClicked, cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_UP_INSIDE | cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_CANCEL);
        infoBtn.setPosition(485, 83);
        activityNode.addChild(infoBtn);
    },

    // 說明按鈕點擊
    _infoBtnClicked: function (sender, event) {
        // 放說明的Node
        var infoNode = this._infoNode;
        if (!infoNode) {
            infoNode = this._infoNode = new cc.Node();
            this._activityNode.addChild(infoNode);
        }

        infoNode.removeAllChildren();

        // 跳說明泡泡框
        if (event === cc.CONTROL_EVENT_TOUCH_DOWN) {
            var label = new cc.LabelTTF(LocalizedString.FreeChip("完成每日任務累積週活躍，\n達成條件可獲得隨機德撲幣"), JSFontName, 10);
            label.setFontFillColor(JSColor.BLACK);

            // 創泡泡框
            var param = {
                mainNode: label,
                style: BaseMessageNode.Style.WHITE,
                direct: BaseMessageNode.Direct.DOWN_RIGHT,
                arrowType: BaseMessageNode.ArrowType.STRAIGHT,
                isFlip: false,
                arrowPadding: 10
            };

            var msgNode = new BaseMessageNode(param);
            msgNode.show();
            infoNode.addChild(msgNode);

            var buttonWorldPos = sender.getParent().convertToWorldSpace(sender.getPosition());
            infoNode.setPosition(cc.pAdd(infoNode.getParent().convertToNodeSpace(buttonWorldPos), cc.p(0, 10)));
            infoNode.setVisible(true);
        } else {
            // 要把說明關掉
            infoNode.setVisible(false);
            infoNode.removeAllChildren();
        }
    },

    /**
     * 寶箱按鈕
     */
    _controlBoxRewardClicked: function (sender, event) {
        var param = sender.param;

        if (event === cc.CONTROL_EVENT_TOUCH_DOWN && param.status === 0) {
            // 要出現說明
            var boxInfoNode = this._boxInfoNode;
            boxInfoNode.removeAllChildren();

            var rewardList = [];
            if (!JSCodeUtility.isArray(param.reward)) {
                rewardList.push(param.reward);
            }

            var textString = "";
            for (var i = 0, len = rewardList.length; i < len; i++) {
                textString += rewardList[i];
            }

            var textLabel = new cc.LabelTTF(textString, JSFontBoldName, 10);
            textLabel.setFontFillColor(JSColor.BLACK);

            // 創泡泡框
            var param = {
                mainNode: textLabel,
                style: BaseMessageNode.Style.WHITE,
                direct: BaseMessageNode.Direct.DOWN_RIGHT,
                arrowType: BaseMessageNode.ArrowType.STRAIGHT,
                isFlip: false,
                arrowPadding: 10
            };

            var msgNode = new BaseMessageNode(param);
            msgNode.show();
            boxInfoNode.addChild(msgNode);

            var buttonWorldPos = sender.getParent().convertToWorldSpace(sender.getPosition());
            boxInfoNode.setPosition(cc.pAdd(boxInfoNode.getParent().convertToNodeSpace(buttonWorldPos), cc.p(0, 10)));
            boxInfoNode.setVisible(true);
        } else {
            if (event === cc.CONTROL_EVENT_TOUCH_UP_INSIDE && param.status === 1) {
                // 卡loading TODO: 要改成新loading
                GSLoading.addLoadingView();

                // 送獎勵
                DataModal.dailyMissionData.haveRewardDailyMission = true;
                DataProcess.sendString(JSStringUtility.format("dailyMission_reward %s_%s", (param.isDaily) ? DailyMissionEnum.rewardType.DAILY_CHEST : DailyMissionEnum.rewardType.WEEKLY_CHEST, param.stage));
            }

            // 要把說明關掉
            this._boxInfoNode.setVisible(false);
            this._boxInfoNode.removeAllChildren();
        }
    },

    // 點擊領取按鈕
    _rewardAllBtnClicked: function () {
        this._rewardAllBtn.setEnabled(false);

        if (!this._isRewardLoading) {
            // 記下現在loading
            this._isRewardLoading = true;

            // 卡loading TODO: 要改成新loading
            GSLoading.addLoadingView();

            // 送領獎
            DataProcess.sendString(JSStringUtility.format("dailyMission_reward %s_0", DailyMissionEnum.rewardType.ALL));
        }
    },

    /**
     * 通知
     */
    // 加上/移除讀取畫面
    notifyDailyMissionLoading: function (event) {
        if (event.getUserData()) {
            this._addLoading();
        } else {
            this._removeLoading();
        }
    },

    // 更新畫面
    notifyUpdateDailyMission: function (event) {
        var resetAllData = false;
        if (event.getUserData()) {
            resetAllData = event.getUserData();
        }

        // 更新所有資訊
        this._updateAllInfo(resetAllData);
    },

    // 跳領獎畫面
    notifyGotDailyMissionReward: function (event) {
        this._isRewardLoading = false;

        if (!event.getUserData())
            return;

        // 播金幣音效
        MusicUtility.playEffect("Music/Effect/reward_coin_fall.mp3");

        // 開始加獎勵的內容
        var missionParam = event.getUserData();
        var rewardArray = missionParam.rewardList;

        var rewardTxt = "";
        // 組合獎勵文字
        rewardArray.forEach((param, idx, array) => {
            rewardTxt += JSColor.colorToRichColor(JSColor.BLACK) + param.rewardTxt;

            // 多獎勵時的換行
            if (array.length > 1 && idx !== array.length - 1)
                rewardTxt += "\n";
        });

        // 獎勵畫面
        var dialog = new RewardDialog({content: rewardTxt, tip: "", needContentScrollView: true});
        DialogManager.addDialog(dialog, false); // 不列入DialogManager控管
    },

    // 領獎失敗
    notifyGotDailyMissionRewardFail: function (event) {
        this._isRewardLoading = false;

        var msg = event && event.getUserData() || LocalizedString.FreeChip("領獎失敗，請稍候再試。");
        AlertDialog.showAlert("", msg);
    },

    // 按到領獎
    notifyDailyMissionRewardClicked: function (event) {
        if (event.getUserData()) {
            var dailyMissionParam = event.getUserData();

            // 卡loading TODO: 要改成新loading
            GSLoading.addLoadingView();

            // 送獎勵
            DataModal.dailyMissionData.haveRewardDailyMission = true;
            DataProcess.sendString(JSStringUtility.format("dailyMission_reward %s_%s", DailyMissionEnum.rewardType.DAILY_MISSION, dailyMissionParam.serialID));
        }
    },

    /**
     * TableView delegate
     */
    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        if (cell == null) {
            cell = new DailyMissionCell(this._whereType);
            cell.setAnchorPoint(cc.p(0, 0));
        }
        cell.refreshCell(this._missionList[idx]);

        return cell;
    },

    numberOfCellsInTableView: function () {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function (table, idx) {
        if (idx >= this._totalCellCount)
            return cc.size(0, 0);
        else
            return cc.size(DailyMissionLayer.TABLE_CONTENT_WIDTH, DailyMissionCell.HEIGHT);
    }
});

DailyMissionLayer.TABLE_CONTENT_WIDTH = 400;    // Table欄位的寬度