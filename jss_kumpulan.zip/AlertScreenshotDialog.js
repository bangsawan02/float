/**
 * 產生截圖畫面的dialog
 */
var AlertScreenshotDialog = BaseDialogLayer.extend({
    ctor: function (texture) {
        this._super();

        // 設定參數
        this.key = "AlertScreenshotDialog";
        var animationLayer = this._animationLayer;

        // 加黑底
        var background = new cc.LayerColor(cc.color(0, 0, 0, 204), JSVisibleSize.width, JSVisibleSize.height);
        animationLayer.addChild(background);

        // 截圖畫面
        var screenshot = new GSShaderSprite(texture);
        screenshot.setFlippedY(true);
        screenshot.setPosition(JSScreenMidPos);
        screenshot.setScale(0.8);
        animationLayer.addChild(screenshot);

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.setPosition(JSVisibleSize.width - 32, JSVisibleSize.height - 32);
        closeBtn.addTouchUpInsideAction(this._closeDialogAnimation, this);
        animationLayer.addChild(closeBtn);

        // 導引到客服按鈕
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        animationLayer.addChild(menu);

        var itemNodes = ButtonUtility.createSingleScale9Nodes("#lobby_icon_help.png");
        var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], itemNodes[2], () => {
            // 關閉截圖畫面
            this._closeDialogAnimation();

            // 導引到客服頁面
            PushLayerHelper.pushLayer("", LobbyBannerMode.SettingHelpReport);

            // 埋點：點擊客服回報
            DataProcess.sendString("track_alert_screenshot 3");
        }, this);
        menuItem.setPosition(JSVisibleSize.width - 32, 32);
        menu.addChild(menuItem);
    }
});