/**
 * 5.5.7大廳信件領獎整合 收件箱 - 領取頁 TableView Cell
 * 移植自中文德撲 16.2大廳信件領獎整合
 *
 * created by daniel.lin
 */

var AwardCell = cc.TableViewCell.extend({
    ctor: function (callback) {
        this._super();

        var awardAndMailStr = LocalizedString.AwardAndMail;

        // 給外部一個callback刷新
        this.callback = callback;

        // 設定個平均高度
        var midPosY = this._midPosY = AwardCell.HEIGHT / 2;

        // 背景圖
        var bgSprite = new cc.Scale9Sprite("awardAndMail_bg_window_02.png");
        bgSprite.setPreferredSize(cc.size(340, 55));
        bgSprite.setPosition(170, midPosY);
        this.addChild(bgSprite);

        // 分類名稱 底圖
        var titleSprite = this._titleSprite = new cc.Scale9Sprite("awardAndMail_bg_line_03.png");
        titleSprite.setPreferredSize(cc.size(130, 18));
        titleSprite.setPosition(37, midPosY + 9);
        titleSprite.setAnchorPoint(cc.p(0, 0.5));
        this.addChild(titleSprite);

        // 分類名稱
        var titleLabel = this._titleLabel = new cc.LabelTTF("", JSFontBoldName, 10);
        titleLabel.setAnchorPoint(0, 0.5);
        titleLabel.setPosition(55, midPosY + 9);
        this.addChild(titleLabel);

        // 獎勵內容
        var subjectLabel = this._subjectLabel = new BouncingNicknameLabel("", JSFontBoldName, 10, cc.size(220, 20), 0.5);
        subjectLabel.getLabel().setFontFillColor(cc.color(102, 48, 20));
        subjectLabel.setPosition(165, midPosY - 12.5);
        subjectLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
        this.addChild(subjectLabel);

        // Icon 底圖
        var circleSprite = new cc.Sprite("#awardAndMail_bg_circle.png");
        circleSprite.setPosition(30, midPosY);
        this.addChild(circleSprite);

        // 領獎按鈕
        var receiveBtn = ButtonUtility.createSimpleButton(GS.isLuxyPoker ? "lobby_btn_01.png" : "lobby_btn_15.png", cc.size(55, 23), awardAndMailStr("領取"), GS.isLuxyPoker ? JSColor.BLACK : JSColor.WHITE, 10);
        receiveBtn.setPosition(305, midPosY + 9);
        !GS.isLuxyPoker && receiveBtn.label.enableStroke(cc.color(24, 140, 0), 2);
        receiveBtn.addTouchUpInsideAction(this._receiveClicked, this);
        this.addChild(receiveBtn);

        // 倒數時間
        var countdownLabel = this._countdownLabel = new GSRichLabelNode("", JSFontName, 10);
        countdownLabel.setMultiFormat("%ddD%hhH", "%hhH%mmM", "%mmM%ssS");
        countdownLabel.setPosition(305, midPosY - 12.5);
        countdownLabel.setFontFillColor(GS.isLuxyPoker ? cc.color(210, 0, 0) : cc.color(204, 41, 41));
        this.addChild(countdownLabel);
    },

    // 點擊領獎
    _receiveClicked: function () {
        if (!this._content)
            return;

        // 送副系統領獎埋點
        if (this._param.group)
            TexasUtility.sendUserAnalyticsTrack(this._getTrackIdByFID(this._param.fid), this._param.group);
        else
            TexasUtility.sendUserAnalyticsTrack(this._getTrackIdByFID(this._param.fid));

        // 跳出Dialog
        DialogManager.addDialog(new AwardAndMailCommonDialog(LocalizedString.AwardAndMail("恭喜您"), this._content, () => {
            // 刪除獎勵並刷新
            this._deleteAwardCell();
        }), false);
    },

    // 刪除獎項並呼叫callback刷新列表
    _deleteAwardCell: function () {
        if (!this._param)
            return;

        // 通知Server領取獎勵
        DataModal.awardAndMailData.updateAwardByParam(this._param);
        this.callback && this.callback();
    },

    // 刷新Cell資料
    refreshCell: function (param) {
        this._param = param;

        // 領獎的Dialog內文
        this._content = param.mailContent;

        // 如果有Icon的話先移除
        if (this._iconSprite) {
            this._iconSprite.removeFromParent();
            this._iconSprite = undefined;
        }

        // Icon Domino移植設定 特定fid改用熱更的圖片
        switch (param.fid) {
            case FidMap.VEGAS_MAP_MISSION:
                // 地圖式任務 走熱更
                this._refreshHotFixIcon(param.fid);
                break;
            default:
                // 其他走下載圖片
                var iconName = JSStringUtility.format("awardAndMail_pic_icon_%s.png", param.fid);
                var imageUrl = JSStringUtility.format("%s/%s/%s", UrlUtils.mailIconUrlRoot, GS.resourcesFolder, iconName);
                var savePath = JSStringUtility.format("%s%s", JSWriteablePath + "AwardAndMail/", iconName);
                var iconSprite = this._iconSprite = new GSDownloadSprite("lobby_icon_gift.png", imageUrl, savePath);
                iconSprite.setPosition(30, this._midPosY);
                this.addChild(iconSprite);
        }

        // Domino移植設定 特定fid調整icon大小
        switch (param.fid) {
            case FidMap.SPEED_RACING:
            case FidMap.VEGAS_TEBAKQQ:
            case FidMap.VEGAS_DRAGON_VS_LEOPARD:
                this._iconSprite && this._iconSprite.setScale(0.9);
                break;
            default:
                this._iconSprite && this._iconSprite.setScale(1);
        }

        // 分類名稱
        this._titleLabel.setString(param.title);

        // 根據名稱長度調整底圖大小
        this._titleSprite.setPreferredSize(cc.size(Math.max(130, this._titleLabel.getContentSize().width + 35), 18));

        // 主旨
        this._subjectLabel.setString(param.subject);

        // 倒數時間
        var remainTime = JSCodeUtility.getRemainTimeByParam(param);
        this._countdownLabel.countdownSeconds(remainTime, () => {
            // 刪除獎勵並刷新
            this._deleteAwardCell();
        });
    },

    // 取得領獎埋點ID
    _getTrackIdByFID: function (fid) {
        switch (fid) {
            case FidMap.GAMBLER_ROAD:
                // 埋點 1497:點擊牌王之路領獎
                return 1497;
            case FidMap.TOKEN_SUBSYSTEM:
                // 埋點 1804:點擊代幣副系統領獎
                return 1804;
            case FidMap.VEGAS_COMPETE:
                // 埋點 1499:點擊VIP爭霸賽領獎
                return 1499;
            case FidMap.SPEED_RACING:
                // 埋點 1501:點擊極速競飆領獎
                return 1501;
            case FidMap.VEGAS_MAP_MISSION:
                // 埋點 1503:點擊地圖式任務領獎
                return 1503;
            case FidMap.LUCKY_LOTTERY:
                // 埋點 3842:點擊新儲值中心抽獎活動領獎
                return 3842;
        }
    },

    /**
     * 熱更圖片
     */
    _refreshHotFixIcon: function (fid) {
        // 設定參數
        var bundleName, bundleType, loadFileArray;
        switch (fid) {
            case FidMap.VEGAS_MAP_MISSION:
                // 地圖式機台任務
                bundleName = "VegasMapMission";
                bundleType = HotfixTool.BundleType.SUBSYSTEM;
                loadFileArray = ["download/subSystem/VegasMapMission/vegasMapMission_download.plist", "download/subSystem/VegasMapMission/vegasMapMission_download.png"];
                break;
            default:
                break;
        }

        // 確保每一次下載，都是指定到目前的cell
        if (this._hotFixHelper) {
            this._hotFixHelper.destroy();
            this._hotFixHelper = undefined;
        }

        if (bundleName && bundleName.length) {
            this._hotFixHelper = new HotFixHelper({
                bundleName: bundleName,
                bundleType: bundleType,
                loadFileArray: loadFileArray,
                onSynchronizeSuccess: this._freshVegasMapMissionIcon.bind(this),
                onSynchronizeFail: null // 下載失敗不需處理，原來就不會看到icon
            });

            // 有下載會去下載
            //    > 下載成功會載入素材後執行onSynchronizeSuccess
            //    > 下載失敗因為畫面原本就看不到，所以不做事
            // 不需下載會接著執行onSynchronizeSuccess
            this._hotFixHelper.start();
        }
    },

    _freshVegasMapMissionIcon: function () {
        // 如果有Icon的話先移除
        if (this._iconSprite) {
            this._iconSprite.removeFromParent();
            this._iconSprite = undefined;
        }
        var iconSprite = this._iconSprite = new cc.Sprite("#vegasMapMission_icon_01.png");
        iconSprite.setPosition(30, this._midPosY);
        this.addChild(iconSprite);
    }
});

AwardCell.HEIGHT = 60;
