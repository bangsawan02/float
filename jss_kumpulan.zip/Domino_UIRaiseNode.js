var Domino_UIRaiseNode = cc.Node.extend({
    ctor: function () {
        this._super();

        this._max = 100;                //最大注
        this._min = 50;                 //最小注
        this._bet = [30, 20, 10];       //[[文字幾倍],[丟多少錢]] (servers 給的文字與數字）
        this._money = 0;

        var bgPos = cc.p(439 + JSScreenBonusHalfWidth, 151);

        this._minSliderPos = cc.p(bgPos.x + 34, 53);
        this._maxSliderPosY = 213;
        this._chipStackOffset = (this._maxSliderPosY - this._minSliderPos.y) / 25;
        this._totalLen = this._maxSliderPosY - this._minSliderPos.y;
        this._sliderOffset = this._totalLen / 25;

        // 背景
        var bg = new ccui.Scale9Sprite("lobby_bg_list_02.png");
        bg.setPreferredSize(cc.size(144, 247));
        bg.setPosition(bgPos);
        this.addChild(bg);

        this._bgBoundBox = bg.getBoundingBox();

        // slider的範圍
        this._sliderBoundBox = cc.rect(447, 50, 50, 180);

        // 存放slider上面的籌碼
        this._sliderChips = [];

        // 黃光底圖
        var yellowBg = new ccui.Scale9Sprite("domino_pic_yellow.png");
        yellowBg.setPreferredSize(cc.size(140, 92));
        yellowBg.setPosition(440 + JSScreenBonusHalfWidth, 76);
        this.addChild(yellowBg);

        // 發光的框
        var frameBg = new ccui.Scale9Sprite("lobby_recommend.png");
        frameBg.setPreferredSize(cc.size(149, 255));
        frameBg.setPosition(bgPos);
        this.addChild(frameBg);

        var betPos = cc.p(bgPos.x, bgPos.y + 100);
        var betNode = this._betNode = new cc.Node();
        this.addChild(betNode);

        var betBgSprite = new ccui.Scale9Sprite("domino_pic_arrow_02.png");
        betBgSprite.setPreferredSize(cc.size(120, 30));
        betBgSprite.setPosition(betPos);
        betNode.addChild(betBgSprite);

        //加注金額
        var betLabel = this._betLabel = new cc.LabelTTF(" ", JSFontBoldName, 14);
        betLabel.setPosition(betPos);
        betNode.addChild(betLabel);

        // 可拉動的硬幣
        var sliderChip = this._sliderChip = new cc.Sprite("#lobby_reward_chip.png");
        sliderChip.setPosition(this._minSliderPos);
        this.addChild(sliderChip, 3);

        this._betBtn = [];
        // 快速下注的按鈕 從下往上 是小到大
        for (var i = 0; i < 4; i++) {
            var betBtn = ButtonUtility.createSimpleButton("lobby_btn_09.png", cc.size(64, 40), " ", JSColor.YELLOW2);
            betBtn.addTouchUpInsideAction(this._betBtnClicked, this);
            betBtn.setPosition(bgPos.x - 34, 70 + i * 46);
            this.addChild(betBtn, 2);

            this._betBtn.push(betBtn);
        }

        var arrowSprites = this._arrowSprites = [];
        for (var i = 0; i < 12; i++) {
            var arrowSp = new cc.Sprite("#domino_pic_red_arrow.png");
            arrowSp.setPosition(this._minSliderPos.x, 74 + i * 13);
            arrowSp.setOpacity(76);
            this.addChild(arrowSp);

            arrowSprites.push(arrowSp);
        }
        // slider 跑光動畫
        this._runSliderAnime();

        var okBtn = ButtonUtility.createSimpleButton("lobby_btn_01.png", cc.size(145, DOMINO_UILAYER_BUTTON_HEIGHT), LocalizedString.Game("確定"), JSColor.BLACK, 16);
        okBtn.addTouchUpInsideAction(this._oKClicked, this);
        okBtn.setPosition(bgPos.x, DOMINO_UILAYER_BUTTON_Y);
        this.addChild(okBtn, 2);

        //加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this._onTouchBegan.bind(this),
            onTouchMoved: this._onTouchMoved.bind(this),
            onTouchEnded: this._onTouchEnded.bind(this)
        }, this);

        //Add Event
        var self = this;
        GS.addListener("NotifyGameUIIsOpenRaise", function (event) {
            if (event.getUserData()) {
                var isOpen = event.getUserData();
                self.setVisible(isOpen);
            }
        }, this);

        //Test
        // this.refresh({max: 1000, min: 50, bet: [["x1 pot", "x2 pot", "x3 pot", "x4 pot"], [100, 200, 300, 400]]});
    },

    /**
     * 設定加注的設定
     * @param param
     */
    refresh: function (param) {
        this._max = param.max;      // 上限
        this._min = param.min;      // 下限
        if (param.bet) {
            this._bet = param.bet;

            // 更改快速下注的文字
            for (var i = 0; i < 4; i++) {
                var message = this._bet[0][i];
                this._betBtn[i].label.setString(message);
            }
        }

        // 把現在的數字重置
        this._money = this._min;
        this._setSlider(this._minSliderPos.y, this._min);

        // 教學模式不鎖按鈕
        if (!DataModal.gameData.isTeachMode) {
            var callMoney = param.callMoney;
            var bringMoney = param.bringMoney;
            var minRaiseMoney = param.minRaiseMoney;

            // 如果加注金額小於別人加注 or 最小盲注 or 自己金額不足加注金額 則按鈕無效轉暗
            for (var i = 0; i < 4; i++) {
                var plus = parseInt(param.bet[1][i]);
                if (plus >= callMoney && plus <= bringMoney && plus >= minRaiseMoney)
                    this._betBtn[i].setEnabled(false);
                else
                    this._betBtn[i].setEnabled(true);
            }
        } else {
            for (var i = 0; i < 4; i++) {
                this._betBtn[i].setEnabled(true);
            }
        }
    },

    /**
     * 設定slider的位置
     * @param posY 高度
     * @param money 強制設定金額
     */
    _setSlider: function (touchY, money) {
        if (touchY > this._maxSliderPosY)
            touchY = this._maxSliderPosY;
        else if (touchY < this._minSliderPos.y)
            touchY = this._minSliderPos.y;

        // 顯示slider上面的籌碼
        var count = Math.floor((touchY - this._minSliderPos.y) / this._chipStackOffset);

        if (count === this._nowCount && !money)
            return;

        this._nowCount = count;

        var sliderChips = this._sliderChips;
        for (var i = 0; i < 25; i++) {
            if (i >= count) {
                sliderChips[i] && sliderChips[i].setVisible(false);
                continue;
            }

            if (!sliderChips[i]) {
                var chip = new cc.Sprite("#lobby_reward_chip.png");
                chip.setPosition(cc.pAdd(this._minSliderPos, cc.p(JSCodeUtility.getRandomInt(-3, 5), this._chipStackOffset * i)));
                this.addChild(chip, 2);
                sliderChips.push(chip);
            }
            sliderChips[i].setVisible(true);
        }

        // 籌碼沒有推滿
        if (count !== 25) {
            this._allInNode && this._allInNode.setVisible(false);
            this._betNode.setVisible(true);

            // 換算長度比例上的金額
            var min = this._min;
            var posY = count * this._sliderOffset;
            money = (money > 0) ? money : (this._max - min) * (posY / this._totalLen) + min;
            var moneyRate = Math.ceil(money / min);
            money = this._money = min * moneyRate;

            // 設定slider可移動籌碼的位置
            this._sliderChip.setPosition(this._minSliderPos.x, this._minSliderPos.y + posY);
            this._betLabel.setString(TexasUtility.getSimpleMoneyString(Math.ceil(money)));

            return;
        }

        // 籌碼推滿 顯示all in
        if (!this._allInNode) {
            var allInNode = this._allInNode = new cc.Node();
            this.addChild(allInNode);

            var pos = this._betLabel.getPosition();

            var betBgSprite = new ccui.Scale9Sprite("domino_pic_arrow_01.png");
            betBgSprite.setPreferredSize(cc.size(120, 30));
            betBgSprite.setPosition(pos);
            allInNode.addChild(betBgSprite);

            // 加注金額圖片 (到Allin的時後要改成圖片)
            var allinSprite = new cc.Sprite("#domino_word_all-in.png");
            allinSprite.setPosition(pos);
            allInNode.addChild(allinSprite);

            var particle = new cc.ParticleSystem("Particle/light01.plist");
            particle.setPositionType(cc.ParticleSystem.TYPE_FREE);
            particle.setScale(0.5);
            particle.setPosition(pos.x, this._minSliderPos.y);
            allInNode.addChild(particle);

            var particle2 = new cc.ParticleSystem("Particle/start01.plist");
            particle2.setPositionType(cc.ParticleSystem.TYPE_FREE);
            particle2.setScale(0.5);
            particle2.setPosition(pos.x, this._minSliderPos.y);
            allInNode.addChild(particle2);
        }
        this._money = this._max;
        this._sliderChip.setPositionY(this._maxSliderPosY);
        this._allInNode.setVisible(true);
        this._betNode.setVisible(false);
    },

    /**
     * slider上的跑光動畫
     */
    _runSliderAnime: function () {
        this._arrowSprites.forEach((cur, idx) => {
            var time = idx * 0.1;
            cur.runAction(cc.sequence(
                cc.delayTime(time),
                cc.fadeTo(0.4, 255),
                cc.fadeTo(0, 76),
                cc.callFunc(() => {
                    if (cur === this._arrowSprites[11])
                        this._runSliderAnime();
                }, this, cur)
            ))
        });
    },

    /**
     * 按到倍數
     */
    _betBtnClicked: function (sender) {
        var money = 0;
        switch (sender) {
            case this._betBtn[0]:
                // x1 pot
                money = this._bet[1][0];
                break;
            case this._betBtn[1]:
                // x2 pot
                money = this._bet[1][1];
                break;
            case this._betBtn[2]:
                // x3 pot
                money = this._bet[1][2];
                break;
            case this._betBtn[3]:
                // x4 pot
                money = this._bet[1][3];
                break;

            default:
                return;
        }
        if (money > this._max) {
            money = this._max;
        } else if (money < this._min) {
            money = this._min;
        }

        var count = 25 * (money - this._min) / (this._max - this._min);
        var posY = count * this._sliderOffset;
        this._setSlider(this._minSliderPos.y + posY, money);
    },

    /**
     * 按到確定
     */
    _oKClicked: function () {
        GS.dispatchCustomEvent("NotifyGameUIRaiseOKClicked", this._money);
    },

    /**
     * Touch
     */
    _onTouchBegan: function (touch, event) {
        this._nowTouch = undefined;
        var target = event.getCurrentTarget();

        if (!target.isVisible())
            return false;

        for (var c = target.parent; c != null; c = c.parent) {
            if (!c.isVisible())
                return false;
        }

        var touchPos = this.convertToNodeSpace(touch.getLocation());
        var sliderChipBoundBox = this._sliderChip.getBoundingBox();
        if (cc.rectContainsPoint(sliderChipBoundBox, touchPos) || cc.rectContainsPoint(this._sliderBoundBox, touchPos))
            this._nowTouch = this._sliderChip;
        else if (!cc.rectContainsPoint(this._bgBoundBox, touchPos))
            this.setVisible(false);

        return true;
    },

    _onTouchMoved: function (touch, event) {
        if (!this._nowTouch)
            return;

        var touchPos = this.convertToNodeSpace(touch.getLocation());
        var posY = touchPos.y;

        // 點到slider的硬幣
        if (this._nowTouch === this._sliderChip) {
            this._setSlider(posY);
        }
    },

    _onTouchEnded: function (touch, event) {
        if (!this._nowTouch)
            return;

        var touchPos = this.convertToNodeSpace(touch.getLocation());
        var posY = touchPos.y;

        // 點到slider的硬幣
        if (this._nowTouch === this._sliderChip) {
            this._setSlider(posY);
        }

        this._nowTouch = undefined;
    }
});
