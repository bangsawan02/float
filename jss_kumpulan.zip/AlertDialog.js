/**
 * 用來取代原生Dialog
 obj = {
        title: "",              // 標題
        content: "",            // 內文
        buttons: ["title"],     // 按鈕的文字
        callback: cb,           // Callback
    }
 *
 */

var AlertDialogArray = [];

var AlertDialog = BaseDialogLayer.extend({
    ctor: function (obj) {
        this._super();
        this.setCascadeOpacityEnabled(true);

        this._callback = obj.callback;
        this.testString = obj.content;

        // 預設按鈕
        if (!obj.buttons || obj.buttons.length === 0)
            obj.buttons = [LocalizedString.Common("確認")];

        var aniLayer = this._animationLayer;

        // 設應
        var imageEmptyOffset = 8;   // 圖片透明的空間
        var upperOffset = 14;       // Title離上方差多遠
        var contentOffsetY = 6;     // Title離Content差多遠
        var buttonOffsetY = 10;     // Button離Content差多遠

        // 視窗寬度
        var dialogWidth = 200;
        var btnHeight = 24;

        var bgSize = cc.size(dialogWidth, imageEmptyOffset * 2 + btnHeight);

        var mainNode = new cc.ClippingNode();
        mainNode.setAlphaThreshold(0.1);
        mainNode.setPosition(JSScreenMidPos);
        aniLayer.addChild(mainNode);

        var posOffsetY = 0;

        // 標題
        if (obj.title && obj.title.length) {
            var titleLabel = new cc.LabelTTF(obj.title, JSFontBoldName, 13, cc.size(dialogWidth - 20, 0), cc.TEXT_ALIGNMENT_CENTER);
            titleLabel.setFontFillColor(JSColor.BLACK);
            titleLabel.setAnchorPoint(0.5, 1);
            mainNode.addChild(titleLabel);

            posOffsetY = titleLabel.getContentSize().height + contentOffsetY;
            bgSize.height += posOffsetY;
        }

        // 內文
        if (obj.content && obj.content.length) {
            // 直接幫他加黑色
            var contentLabel = new GSRichTextNode("#!000000!#" + obj.content, JSFontBoldName, 10, cc.size(dialogWidth - 20, 0));
            contentLabel.setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            contentLabel.setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
            mainNode.addChild(contentLabel);

            bgSize.height += contentLabel.getContentSize().height + buttonOffsetY;
        }

        // 真正的按鈕
        var btnLen = obj.buttons.length;
        var menu = this._menu = new cc.Menu();
        menu.setPosition(0, 0);
        mainNode.addChild(menu);

        this._buttons = [];
        obj.buttons.forEach((cur, index) => {
            var itemNode = [];
            var size = cc.size(btnLen === 2 ? dialogWidth / 2 : dialogWidth, btnHeight);
            for (var i = 0; i < 2; i++) {
                var node = itemNode[i] = new cc.Node();
                node.setCascadeColorEnabled(true);
                node.setCascadeOpacityEnabled(true);
                node.setContentSize(size);

                // 背景
                if (i === 1) {
                    var bgLayer = new cc.LayerColor(cc.color(255, 255, 255, 50), size.width - (btnLen == 2 ? 3 : 6), size.height);
                    if (btnLen === 2) {
                        // 左右放的
                        bgLayer.setPosition(index === 0 ? 3 : 0, 0);
                    } else
                        bgLayer.setPosition(3, 0);
                    node.addChild(bgLayer);
                }

                var label = new cc.LabelTTF(cur, JSFontBoldName, 10);
                label.setFontFillColor(cc.color(10, 90, 255));
                label.setPosition(size.width / 2, size.height / 2);
                node.addChild(label);

                if (i === 1)
                    node.setColor(JSColor.GRAY);
            }
            var menuItem = new cc.MenuItemSprite(itemNode[0], itemNode[1], this._buttonClicked, this);
            menu.addChild(menuItem);
            this._buttons.push(menuItem);
        });

        // 三個按鈕才會垂直排放
        if (btnLen > 2) {
            bgSize.height += btnHeight * (btnLen - 1);
        }

        // 排位置
        var titlePosY = bgSize.height / 2 - upperOffset;
        titleLabel && titleLabel.setPosition(0, titlePosY);
        contentLabel && contentLabel.setPosition(0, titlePosY - posOffsetY - contentLabel.getContentSize().height / 2);


        // 上下放
        var btnBottomY = -bgSize.height / 2 + 15;
        var lineColor = cc.color(0, 0, 0, 180);
        for (var i = 0; i < btnLen; i++) {
            if (btnLen === 2) {
                // 左右放
                this._buttons[i].setPosition(-dialogWidth / 4 + i * dialogWidth / 2, btnBottomY);

                // 線
                if (i === 0) {
                    // 上面的線
                    var line = new cc.LayerColor(lineColor, dialogWidth - 6, 0.5);
                    line.setPosition(-dialogWidth / 2 + 3, btnBottomY + btnHeight / 2 + btnHeight * i);
                    mainNode.addChild(line, -1);
                } else {
                    // 中間的線
                    var line = new cc.LayerColor(lineColor, 0.5, btnHeight);
                    line.setPosition(-1, btnBottomY - btnHeight / 2);
                    mainNode.addChild(line, -1);
                }
            } else {
                // 上下放
                this._buttons[btnLen - 1 - i].setPosition(0, btnBottomY + btnHeight * i);

                // 線
                var line = new cc.LayerColor(lineColor, dialogWidth - 6, 0.5);
                line.setPosition(-dialogWidth / 2 + 3, btnBottomY + btnHeight / 2 + btnHeight * i);
                mainNode.addChild(line, -1);
            }
        }

        //背景
        var bgSprite = new ccui.Scale9Sprite("bg_information1.png");
        bgSprite.setPreferredSize(bgSize);
        bgSprite.setOpacity(240);
        mainNode.addChild(bgSprite, -10);

        //創Clip掉的部份
        var stencilBg = new ccui.Scale9Sprite("bg_information1.png");
        stencilBg.setPreferredSize(bgSize);
        mainNode.setStencil(stencilBg);

        this._startDialogAnimation();

        // 一直跑這個 不然會有圖出不來
        var emptyNode = new cc.Node();
        mainNode.addChild(emptyNode);
        this.schedule(function () {
            emptyNode.setVisible(!emptyNode.isVisible());
        }, 2);

        // 設定關掉後要砍掉Queue的東西
        this.setCloseCallback(() => {
            JSCodeUtility.removeArrayObject(AlertDialogArray, this);

            // 判斷還有沒有下一個Alert
            var len = AlertDialogArray.length;
            if (len) {
                var alert = AlertDialogArray[0];
                alert._startDialogAnimation();
                cc.director.getNotificationNode().addChild(alert);
            }
        });
    },

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        // callback
        this._callback && this._callback(-1);

        // 關掉Dialog
        this._closeDialogAnimation();
    },

    /**
     * 按鈕
     */
    _buttonClicked: function (sender) {
        var index = 0;
        for (var i = 0; i < this._buttons.length; i++) {
            if (this._buttons[i] === sender) {
                index = i;
                break;
            }
        }

        if (this._callback)
            this._callback(index);

        this._closeDialogAnimation();
    },
});


/**
 * 產生出Alert
 * @param title
 * @param content
 * @param buttons
 * @param cb
 */
AlertDialog.showAlert = function (title, content, buttons = [LocalizedString.Common("確認")], cb = undefined) {
    // 設定標題與內容
    title = JSCodeUtility.getStringValue(title);
    content = JSCodeUtility.getStringValue(content);

    // Domino才有，會去從server抓關鍵字，有包含錯誤訊息會有screenshot按鈕，按下後會截圖並去客服
    var keyword = DataModal.settingData.screenshotKeyWordArray || [];
    var titleLowerCase = title.toLowerCase();
    var contentLowerCase = content.toLowerCase();
    var hasKeyword = keyword.some(word => {
        var wordLowerCase = word.toLowerCase();
        return titleLowerCase.indexOf(wordLowerCase) !== -1 || contentLowerCase.indexOf(wordLowerCase) !== -1;
    });
    var isShowScreenshot = hasKeyword && buttons[2] === undefined;
    var redirectCallback = undefined;
    if (isShowScreenshot) {
        buttons[2] = "Screenshot";
        redirectCallback = function (index) {
            if (index === 2) {
                if (cc.sys.isNative) {
                    // 先存在相簿
                    GSCaptureToAlbumWrapper.captureScreen((isSuccess, errorType) => {
                        if (isSuccess) {
                            // 產生截圖畫面
                            var texture = JSCodeUtility.screenCapture(cc.director.getRunningScene(), cc.size(JSVisibleSize.width, JSVisibleSize.height), true, "ShareImage.jpg", cc.IMAGE_FORMAT_JPEG, null);
                            if (texture) {
                                // 去客服的Dialog
                                DialogManager.addDialog(new AlertScreenshotDialog(texture), false);
                            }
                        }
                    });

                    // 埋點：點擊螢幕截圖
                    DataProcess.sendString("track_alert_screenshot 2");
                } else {
                    cc.log("Native才會有功能");
                }
            } else {
                cb && cb(index);
            }
        };
    }


    if (cc.sys.isNative) {
        // 原生走原生的Dialog
        title = title || "";
        content = content || "";
        buttons = buttons || [LocalizedString.Common("確認")];
        var button0 = buttons[0] || "";
        var button1 = buttons[1] || "";
        var button2 = buttons[2] || "";

        if (redirectCallback) {
            GSDeviceInfo.showAlert(title, content, button0, button1, button2, redirectCallback);
        } else {
            GSDeviceInfo.showAlert(title, content, button0, button1, button2, cb);
        }

        if (isShowScreenshot) {
            // 埋點：跳出可截圖的原生Alert
            DataProcess.sendString("track_alert_screenshot 1");
        }

        return;
    }

    // H5自己弄
    var alert = new AlertDialog({
        title: title,
        content: content,
        buttons: buttons,
        callback: redirectCallback ? redirectCallback : cb,
    });

    // 加在最上面
    AlertDialogArray.push(alert);
    if (AlertDialogArray.length === 1)
        cc.director.getNotificationNode().addChild(alert);
    else
        alert._stopDialogAnimation();
};