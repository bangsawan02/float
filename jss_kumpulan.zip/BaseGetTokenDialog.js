/**
 * 我要代幣 Dialog
 * created by andrew.chang
 */

var BaseGetTokenDialog = BaseDialogLayer.extend({
    ctor: function (param, limitToken) {
        this._super();

        this._param = param;            // 資料
        this._limitToken = limitToken;  // 代幣上限
        this._gameBtnArray = [];        // 放玩法的按鈕

        this.loadFileArray = [
            "lobby/select_game.plist", "lobby/select_game.png"
        ];

        /**
         * 繼承的要記得設定以下東西
         */
        // // 設定背景圖檔
        // this._bgImg = "tokenSubsystem_bg_window_01.png";
        // this._bgSize = cc.size(368, 230);
        //
        // // 設定標題相關參數
        // this._titleFontSize = 10;
        // this._titleColor = JSColor.BLACK;
        // this._titleString = JSStringUtility.format(LocalizedString.TokenSubsystem("代幣若達%s時，\n需先消耗才可繼續累積呦"), JSCodeUtility.getCurrencyString(limitToken));
        //
        // // 設定中間資訊框相關參數
        // this._frameSize = cc.size(322, 135);
        // this._frameImg = "tokenSubsystem_bg_window_03.png";
        //
        // // 設定中間的玩法參數
        // var locString = LocalizedString.TokenSubsystem;
        // var tokenThreshold = TexasUtility.getSimpleMoneyString(DataModal.tokenSubsystemData.getTokenThreshold);
        // this._centerTitleFontSize = 12;
        // this._centerStringColor = TokenSubsystemData.BROWN_COLOR;
        // this._centerSettingArray = [
        //     {
        //         title: locString("指定機台"),
        //         content: JSStringUtility.format(locString("投注額>=%s且每%s可獲得1代幣"), tokenThreshold, tokenThreshold),
        //         btnArray: param.slotBtnArray
        //     },
        //     {
        //         title: locString("指定玩法"),
        //         content: locString("每玩1手拿代幣"),
        //         btnArray: param.playBtnArray
        //     }
        // ];
    },

    onExit: function () {
        // 移除圖檔
        if (this._loadFileDone) {
            for (let i = 0; i < this.loadFileArray.length; i += 2)
                cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[i]);
        }

        this._super();
    },

    loadFileDone: function () {
        this._super();

        // 加圖檔
        for (let i = 0; i < this.loadFileArray.length; i += 2)
            cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[i], this.loadFileArray[i + 1]);

        var aniLayer = this._animationLayer;

        // 背景
        var bgSprite = new ccui.Scale9Sprite(this._bgImg);
        bgSprite.setPreferredSize(this._bgSize || cc.size(368, 230));
        bgSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 3);
        aniLayer.addChild(bgSprite);

        // 標題
        var titleLabel = new cc.LabelTTF(this._titleString, JSFontName, this._titleFontSize);
        titleLabel.setFontFillColor(this._titleColor);
        titleLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        titleLabel.setPosition(JSScreenMidPos.x, 233 + JSScreenBonusHalfHeight);
        aniLayer.addChild(titleLabel);

        // 背景框
        var frameSprite = new ccui.Scale9Sprite(this._frameImg);
        frameSprite.setPreferredSize(this._frameSize);
        frameSprite.setPosition(JSScreenMidPos.x, 153 + JSScreenBonusHalfHeight);
        aniLayer.addChild(frameSprite);

        // 分隔線
        var lineSprite = this._createLineSprite();
        lineSprite.setPosition(291 + JSScreenBonusHalfWidth, 154 + JSScreenBonusHalfHeight);
        aniLayer.addChild(lineSprite);

        // 創中間的資料
        this._gameBtnArray = [];
        this._centerSettingArray.forEach((cur, index) => {
            // x軸位置
            let posX = 193 + JSScreenBonusHalfWidth + index * 162;

            // 標題
            let titleLabel = new cc.LabelTTF(cur.title, JSFontName, this._centerTitleFontSize);
            titleLabel.setFontFillColor(this._centerStringColor);
            titleLabel.setPosition(posX, 200 + JSScreenBonusHalfHeight);
            aniLayer.addChild(titleLabel);

            // 內文
            let contentLabel = new cc.LabelTTF(cur.content, JSFontName, 10);
            contentLabel.setFontFillColor(this._centerStringColor);
            contentLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            contentLabel.setPosition(posX, 110 + JSScreenBonusHalfHeight);
            aniLayer.addChild(contentLabel);

            // 排版的node
            var layoutNode = new GSAutoLayoutNode();
            layoutNode.setSpace(4);
            layoutNode.setPosition(posX, 152 + JSScreenBonusHalfHeight);
            aniLayer.addChild(layoutNode);

            // 按鈕
            var btnScale = 0.57;
            cur.btnArray.forEach(btnParam => {
                let gameButton = new LobbySelectGameButton({
                    serverType: btnParam.lobbyType,
                    isBig: false
                });
                gameButton.btnParam = btnParam; // 記下資料
                gameButton.setScale(btnScale);
                gameButton.addTargetWithActionForControlEvents(this, this._gameBtnClicked, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
                layoutNode.addChild(gameButton);

                // 把按鈕存起來
                this._gameBtnArray.push(gameButton);

                // 牌桌玩法要有泡泡框
                if (btnParam.lobbyType > 1000) {
                    var gameName = GSEnum.GameName[btnParam.url];
                    var msgLabel = new cc.LabelTTF(JSStringUtility.format(LocalizedString.Common("限%s"), gameName), JSFontName, 12);
                    msgLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                    msgLabel.setFontFillColor(JSColor.BLACK);

                    // 設定泡泡框
                    var param = {
                        mainNode: msgLabel,
                        style: BaseMessageNode.Style.WHITE_SHADOW,
                        direct: BaseMessageNode.Direct.DOWN,      // 讓泡泡框避開會擋到他的東西
                        arrowType: BaseMessageNode.ArrowType.STRAIGHT,
                        isFlip: false
                    };

                    var infoNode = this._infoNode = new BaseMessageNode(param);
                    infoNode.show();
                    infoNode.setPosition(45, 66);
                    gameButton.addChild(infoNode);
                }
            });
        });

        // 馬上玩按鈕
        var playBtn = this._playBtn = this._createPlayBtn();
        playBtn.addTouchUpInsideAction(this._playBtnClicked, this);
        playBtn.setPosition(JSScreenMidPos.x, 72 + JSScreenBonusHalfHeight);
        aniLayer.addChild(playBtn);

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.setPosition(JSScreenMidPos.x + 169, JSScreenMidPos.y + 103);
        closeBtn.addTouchUpInsideAction(this._closeDialogAnimation, this);
        aniLayer.addChild(closeBtn);
    },

    /**
     * 創分隔線
     */
    _createLineSprite: function () {
        // 給繼承override用
        cc.error("忘了override _createLineSprite");
    },

    /**
     * 創馬上玩按鈕
     */
    _createPlayBtn: function () {
        // 給繼承override用
        cc.error("忘了override _createPlayBtn");

        return new Texas_Button(Texas_Button.Style.COMMON_GREEN, cc.size(95, 32), LocalizedString.Lobby("馬上玩"));
    },

    /**
     * 創一般的dialog
     */
    _createCommonDialog: function (content) {
        // 給繼承override用
        cc.error("忘了override _createCommonDialog");

        return new Dialog({content: content});
    },

    /**
     * 點擊遊戲按鈕
     */
    _gameBtnClicked: function (sender) {
        // 給繼承override用
    },

    /**
     * 點擊馬上玩按鈕
     */
    _playBtnClicked: function (sender) {
        // 給繼承override用
    },

    /**
     * 跳dialog
     */
    _showDialog: function (string) {
        var dialog = this._createCommonDialog(string);
        dialog.startDialogAnimation();
        this._animationLayer.addChild(dialog);
    },
});
