/**
 * 5.4.0 [儲值]轉輪大狂歡 - 大廳的按鈕
 *
 * created by Wen
 */

var CarnivalWheelLobbyNode = LobbyTimeIconNode.extend({
    ctor: function () {
        this._super();

        this.key = "CarnivalWheelLobbyNode";

        // 註冊通知
        GS.addListener("NotifyCarnivalWheelInfoDone", this.notifyCarnivalWheelInfoDone.bind(this), this);
        GS.addListener("NotifyCarnivalWheelPurchaseDone", this.notifyCarnivalWheelPurchaseDone.bind(this), this);
    },

    /**
     * 更新畫面
     */
    _refreshView: function () {
        // 先砍掉所有東西
        var mainNode = this._mainNode;
        mainNode.removeAllChildren();

        // 檢查或活動是否開啟
        var param = DataModal.purchaseStructuresData.packMap[PurchaseStructuresData.PackSkin.CARNIVAL_WHEEL];
        var leftTime = param ? JSCodeUtility.getRemainTime(param.remainTime, param.socketTime) : 0;
        if (!param || !param.isOpen || leftTime <= 0) {
            this.setVisible(false);
            return;
        }

        // 設定看的到
        this.setVisible(true);

        // icon
        var iconSprite = new cc.Sprite("#lobby_icon_carnivalWheel.png");
        mainNode.addChild(iconSprite);

        // 加入倒數時間
        this.createTimeLabelWithBackground(JSCodeUtility.getRemainTimeByParam(param), () => {
            this.setVisible(false);
        });

        // 紅點
        var badgeNode = this._badgeNode = new BadgeNode();
        badgeNode.useDefaultStyle();
        badgeNode.setPosition(cc.p(12, 10));
        badgeNode.setVisible(param.isPop);
        mainNode.addChild(badgeNode);

        // 主動跳dialog
        if (param.isPop) {
            // 跳過就關掉
            param.isPop = false;

            // 跳Dialog
            this._iconClicked();
        }
    },

    /**
     * 按鈕
     */
    _iconClicked: function (sender) {
        var data = DataModal.purchaseStructuresData.packMap[PurchaseStructuresData.PackSkin.CARNIVAL_WHEEL];

        if (sender) {
            // 埋點：4542 主動點擊大廳 icon
            TexasUtility.sendUserAnalyticsTrack(4542, data.group);

            // 隱藏小紅點
            this._badgeNode.setVisible(false);
        }

        // 跳Dialog
        if (!DialogManager.isExist("PurchasePackDialog_CarnivalWheel")) {
            DialogManager.addDialog(new PurchasePackDialog({
                packSkin: PurchaseStructuresData.PackSkin.CARNIVAL_WHEEL,
                packName: "CarnivalWheel"
            }));
        }
    },

    /**
     * 通知
     */
    notifyCarnivalWheelInfoDone: function () {
        this._refreshView();
    },

    /**
     * 通知儲值完畢
     */
    notifyCarnivalWheelPurchaseDone: function () {
        // 清掉資料
        DataModal.purchaseStructuresData.packMap[PurchaseStructuresData.PackSkin.CARNIVAL_WHEEL] = undefined;

        // 刷新畫面
        this._refreshView();

        // 關掉畫面
        DialogManager.closeDialogByKey("PurchasePackDialog_CarnivalWheel");
    },
});