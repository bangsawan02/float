/**
 * Created by chris.chang on 2020/5/29.
 * 這是用來計算移動位置的軸心
 */

var GSAxis = cc.Class.extend({
    ctor: function (acceleration = 0, period = 0) {
        this.init(acceleration, period);
    },

    /**
     * 設定加速度&持續時間 period=-1為永遠
     * @param acceleration
     * @param period
     */
    init: function (acceleration, period) {
        this._acceleration = acceleration;
        this._period = period;
        this._time = 0;
    },

    /**
     * 軸心開始轉
     * @param target{cc.Node}       schedule的載體
     * @param startTime {Number}    軸心開始的時間點
     * @param startSpeed{Number}    起始的速度
     */
    spin: function (target, startTime = 0, startSpeed = 0) {
        if (target) {
            this._time = 0;
            this._target = target;
            this._currentSpeed = startSpeed;
            this._runningAxis = true;

            this._target.schedule(this.update.bind(this), 0, cc.REPEAT_FOREVER, 0, "Axis");

            this.update(startTime);
        }
    },

    /**
     * 停止軸心
     * @param remainTime 多出來的時間要帶到下一個輪軸
     */
    stop: function (remainTime = 0) {
        this._onFinish && this._onFinish();
        this._runningAxis = false;
        this._target && this._target.unschedule("Axis");
        this._onUpdate = undefined;

        this._nextReelAxis && this._nextReelAxis.spin(this._target, remainTime, this._currentSpeed);

        this._target = undefined;
    },

    /**
     * 重置軸心
     */
    reset: function () {
        this._currentSpeed = 0;                         //當下的速度
        this._time = 0;                                 //經過的時間
        this._runningAxis = false;                      //是否還在跑
        this._onUpdate = undefined;                     //更新移動距離的callback function
        this._onFinish = undefined;                     //結束的callback function
        this._nextReelAxis = undefined;                 //當結束時要接續的軸心

        this._target && this._target.unschedule("Axis");
        this._target = undefined;
    },

    /**
     * 設定接收更新距離時呼叫的函式
     * @param onUpdate {Function}
     */
    setOnUpdate: function (onUpdate) {
        this._onUpdate = onUpdate;
    },

    /**
     * 設定結束呼叫的函式
     * @param onFinish {Function}
     */
    setOnFinish: function (onFinish) {
        this._onFinish = onFinish;
    },

    /**
     * 每一次更新時的函式
     * @param dt {Number}
     */
    update: function (dt) {
        this._time += dt;

        let deltaDistance = 0;
        if (this._period === -1 || this._time < this._period) {
            deltaDistance = this._process(dt);
        } else {
            deltaDistance = this._process(this._period - (this._time - dt));
            this._time -= this._period;
            this._runningAxis = false;
        }

        this._onUpdate && this._onUpdate.call(this._target, this, deltaDistance);

        if (!this._runningAxis) {
            this.stop(this._time);
        }
    },

    /**
     * 設定接續的軸心
     * @param nextReelAxis
     */
    next: function (nextReelAxis) {
        if (nextReelAxis instanceof GSAxis) {
            this._nextReelAxis = nextReelAxis;
            this._nextReelAxis.setOnUpdate(this._onUpdate);
        }
    },

    /**
     * 取得當下速度
     * @return {number|*|Number}
     */
    getCurrentSpeed: function () {
        return this._currentSpeed;
    },

    /**
     * 計算位移距離
     * @param dt {number}
     * @return {number}
     * @private
     */
    _process: function (dt) {
        let deltaDistance = this._currentSpeed * dt + 0.5 * this._acceleration * dt * dt;

        this._currentSpeed = this._currentSpeed + this._acceleration * dt;
        return deltaDistance;
    }
});