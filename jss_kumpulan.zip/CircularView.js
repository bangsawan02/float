/**
 * 環狀的循環view
 * warning 這並不會像tableView一樣會循環使用他的cell, 每次reloadDat就是重創所有child
 * notice 如果只需要做顯示半環狀的內容的的view, 請使用tableView
 * 所有cell都會被畫出來, 沒有clipping
 * created by Terry.
 * 移植 by tony.cheng
 */

var CIRCULAR_VIEW_MIN_MOVEMENT = 7.0 / 160.0;
var CIRCULAR_VIEW_DEACCEL_RATE = 0.95;
var CIRCULAR_VIEW_MIN_ROTATION = 0.5;

/**
 * CircularViewItemNode
 * 在circularView裡面都要是他
 */
var CircularViewItemNode = cc.Node.extend({
    ctor: function () {
        this._super();
        this._index = -1;
        this._angle = 0;
    },
    getIndex: function () {
        return this._index;
    },
    setIndex: function (index) {
        this._index = index;
    },
    getAngle: function () {
        return this._angle;
    },
    setAngle: function (angle) {
        this._angle = angle;
    }
});

/**
 * CircularViewDataSource
 * 控制數量, 且自訂化cell的部分
 */
var CircularViewDataSource = cc.Class.extend({
    numberItemInCircularView: function (circularView) {

    },

    itemNodeAtIndex: function (circularView, index) {

    }
});

/**
 * CircularViewDelegate
 * 提供CircularView滑動時的一些控制
 */
var CircularViewDelegate = cc.Class.extend({
    circularViewDidRotate: function (circularView, angle) {

    },

    circularViewDidEndRotate: function (circularView) {

    }
});

/**
 * 環狀的循環view
 * baseViewAngleWidthRatio: 滑動一視窗長度要旋轉多少角度 360 / 5
 * _xAxisLength: 橢圓x軸長
 * _yAxisLength: 橢圓y軸長
 * _startingAngle: item會從幾度開始排列
 * _container: item所在的container
 * _isLockOnItem: 是否要回彈回item上, 預設開啟
 * _touchSize: 整個view的可滑動範圍, 也是視窗長度依據
 * _containerPosition: 設定container在view裡的位置
 * _circularViewDelegate: 要實作參考 `CircularViewDelegate`
 * _dataSource
 * _itemAngleArray: 所有item所在的angle
 * _oldCircleRotationAngle: 舊的旋轉角度
 * _currentRotationAngle: 當前旋轉角度
 * _rotateDuration: 做動畫時的旋轉時長
 * _rotateByDeltaAngle: 做動畫時單位旋轉角度
 * _touches
 * _rotateDistance: 單次滑動的旋轉角度, 減速時會使用
 *
 * 基本上設定startingAngle這個值只會在item設定位置時使用
 * 對於container來說, 正的x軸方向還是0度
 * 只是item設定位置時先加上startingAngle了
 * 所以叫container旋轉90度對item來說(以x軸為零度起點)
 * 就是旋轉90 加上 startingAngle 才是他的最後位置
 *
 * 旋轉示意圖:
 *
 *      *****
 *    *        *
 *  *      _____1 這邊是盤面0度
 *  *           *
 *    *       *
 *      *****
 *
 *      **1**
 *    *   |    *
 *  *     |     * 這邊是盤面90度
 *  *           *
 *    *       *
 *      *****
 *
 *      *****
 *    *        *
 *  *           * 這邊是盤面270度
 *  *     |     *
 *   *    |    *
 *      **1**
 */
var CircularView = cc.Layer.extend({
    _initProperty: function () {
        this.baseViewAngleWidthRatio = 72;
        this._xAxisLength = 0;
        this._yAxisLength = 0;
        this._startingAngle = 0;
        this._container = undefined;
        this._isLockOnItem = true;
        this._touchSize = cc.size(0, 0);
        this._containerPosition = cc.p(0, 0);
        this._circularViewDelegate = undefined;
        this._dataSource = undefined;
        this._itemAngleArray = [];
        this._oldCircleRotationAngle = 0;
        this._currentRotationAngle = 0;
        this._rotateDuration = 0;
        this._rotateByDeltaAngle = 0;
        this._touches = [];
        this._rotateDistance = 0;
        this._isEnableInvertTopHalfRotation = true;
    },
    ctor: function (xAxisLength, yAxisLength, dataSource, startingAngle, touchSize, container) {
        this._super();
        this._initProperty();

        if (touchSize)
            this.initWithParamAndTouchSize(xAxisLength, yAxisLength, dataSource, startingAngle, touchSize, container);
        else
            this.initWithParam(xAxisLength, yAxisLength, dataSource, startingAngle, container);

        this.reloadData(true);
        this.setIsLockOnItem(true);
    },

    initWithParamAndTouchSize: function (xAxisLength, yAxisLength, dataSource, startingAngle, touchSize, container) {
        if (!cc.Layer.prototype.init.call(this))
            return false;

        this._xAxisLength = xAxisLength;
        this._yAxisLength = yAxisLength;

        startingAngle = startingAngle || 0;
        this._startingAngle = startingAngle;

        this.setDataSource(dataSource);

        // 挪到中間
        this._containerPosition.x = touchSize.width / 2;
        this._containerPosition.y = touchSize.height / 2;

        if (!container && !this._container) {
            container = new cc.Node();
        }
        if (container) {
            this.setContainer(container);
        }

        this.setTouchSize(touchSize);

        this.setTouchEnabled(true);

        return true;
    },

    initWithParam: function (xAxisLength, yAxisLength, dataSource, startingAngle, container) {
        if (!cc.Layer.prototype.init.call(this))
            return false;

        this._xAxisLength = xAxisLength;
        this._yAxisLength = yAxisLength;

        startingAngle = startingAngle || 0;
        this._startingAngle = startingAngle;

        this.setDataSource(dataSource);

        var touchSize = this._touchSize = cc.size(xAxisLength * 2, yAxisLength * 2);

        // 挪到中間
        this._containerPosition.x = touchSize.width / 2;
        this._containerPosition.y = touchSize.height / 2;

        if (!container && !this._container) {
            container = new cc.Node();
        }
        if (container) {
            this.setContainer(container);
        }

        this.setTouchSize(touchSize);


        this.setTouchEnabled(true);

        return true;
    },

    /**
     * 用來做旋轉動畫
     * call once per frame
     * @param dt
     * @returns
     */
    _rotatingByAngle: function (dt) {
        // 要是給時間或是旋轉角度太小, 都不轉
        if (this._rotateDuration < cc.FLT_EPSILON || Math.abs(this._rotateByDeltaAngle) < cc.FLT_EPSILON) {
            this.unschedule(this._rotatingByAngle);
            this._rotateDuration = 0;
            this._rotateByDeltaAngle = 0;
            this._rotateStop();
            return;
        }

        // 要是超時就停止
        if (this._rotateDuration - dt < 0) {
            this.unschedule(this._rotatingByAngle);
            this.__setCurrentAngleTo(this._currentRotationAngle + this._rotateByDeltaAngle * this._rotateDuration);
            this._reLocateAllItem();
            this._rotateDuration = 0;
            this._rotateByDeltaAngle = 0;
            this._rotateStop();
            return;
        }

        this._rotateDuration -= dt;
        this.__setCurrentAngleTo(this._currentRotationAngle + this._rotateByDeltaAngle * dt);
        this._reLocateAllItem();
    },

    /**
     * 旋轉停止時
     */
    _rotateStop: function () {
        this._circularViewDelegate && this._circularViewDelegate.circularViewDidEndRotate && this._circularViewDelegate.circularViewDidEndRotate(this);
    },

    /**
     * 回彈動畫
     * 如果有設定_lockOnItem就會呼叫
     */
    __doBounceBackAnimation: function () {
        // 要回彈
        if (this._isLockOnItem) {
            var toAngle = -1, minDiff = 360;
            var angleArray = this._itemAngleArray;
            for (let i = 0; i < angleArray.length; ++i) {
                let tempAngle = this.__regularAngle(this._startingAngle - angleArray[i]);
                let diff;
                // 圓是360度, 要是零度也要可以當作360度看
                if (tempAngle === 0) {
                    diff = Math.min(this._currentRotationAngle, 360 - this._currentRotationAngle);
                    if (diff !== this._currentRotationAngle)
                        tempAngle = 360;
                } else {
                    diff = Math.abs(this._currentRotationAngle - tempAngle);
                }

                if (diff > CIRCULAR_VIEW_MIN_ROTATION && minDiff > diff) {
                    minDiff = diff;
                    toAngle = tempAngle;
                }
            }

            if (toAngle !== -1) {
                this.rotateToAngleWithDuration(0.2, toAngle);
                // cc.log("CircularView: bounce back to: " + toAngle + "currentAngle is : " + this._currentRotationAngle);
            }
        }
    },

    /**
     * 滑動時旋轉減速
     */
    _decelerateRotating: function () {
        if (this._dragging) {
            this.unschedule(this._decelerateRotating);

            if (this._isLockOnItem) {
                // 要回彈
                this.__doBounceBackAnimation();
            }
            return;
        }

        // 旋轉減速
        this._rotateDistance *= CIRCULAR_VIEW_DEACCEL_RATE;
        this.__setCurrentAngleTo(this._currentRotationAngle + this._rotateDistance);
        this._reLocateAllItem();

        if (Math.abs(this._rotateDistance) <= CIRCULAR_VIEW_MIN_ROTATION) {
            this.unschedule(this._decelerateRotating);
            // 要回彈
            if (this._isLockOnItem) {
                // 要回彈
                this.__doBounceBackAnimation();
            } else {
                this._reLocateAllItem();
                this._rotateStop();
            }
        }
    },

    /**
     * 在指定時間內旋轉指定角度
     * @param duration              歷時
     * @param angle                 角度
     */
    rotateByAngleWithDuration: function (duration, angle) {
        this.unschedule(this._decelerateRotating);
        this.unschedule(this._rotatingByAngle);
        this._rotateDuration = duration;

        this._rotateByDeltaAngle = angle / duration;
        this.schedule(this._rotatingByAngle);
    },

    /**
     * 在特定時間內旋轉到特定角度
     * @param duration              歷時
     * @param angle                 角度
     * @param isCounterClockwise    是否是逆時針, undefined 不指定, 會轉去最靠近的
     */
    rotateToAngleWithDuration: function (duration, angle, isCounterClockwise) {
        this.unschedule(this._decelerateRotating);
        this.unschedule(this._rotatingByAngle);

        // 不允許角度小於零或是超過360度
        angle = this.__regularAngle(angle % 360);

        if (duration < cc.FLT_EPSILON) {
            // 如果呼叫這個function同時又不給時間的話, 要直接當作轉完了
            this.setCurrentRotationAngle(angle);
            this._rotateStop();
        } else {
            this._rotateDuration = duration;

            var byAngle = angle - this._currentRotationAngle;
            var absAngle = Math.abs(byAngle);

            // 算經過360度的路線長度, 再去找哪個距離比較近
            if (absAngle > (360 - absAngle)) {
                // 要是進這裡表示越過360的路線比較近, 要是有跨360且要去的角度比較大, 代表要反轉方向
                if (byAngle > 0)
                    byAngle = absAngle - 360;
                else
                    byAngle = 360 - absAngle;
            }

            // 逆時針
            if (isCounterClockwise) {
                // 角度正地表示是逆時針, 所以要是要轉的角度是負的, 要給他多轉一圈, 才會是逆時針轉動
                if (byAngle < 0)
                    byAngle += 360;
            } else if (isCounterClockwise === false) {
                // 反之要到回去一圈
                if (byAngle > 0)
                    byAngle -= 360;
            }

            this._rotateByDeltaAngle = byAngle / duration;
            this.schedule(this._rotatingByAngle);
        }
    },

    /**
     * 在特定時間內旋轉到特定item
     * @param duration              歷時
     * @param index                 item的index
     * @param isCounterClockwise    是否是逆時針, undefined 不指定, 會轉去最靠近的
     */
    rotateToIndexWithDuration: function (duration, index, isCounterClockwise) {
        if (duration > cc.FLT_EPSILON) {
            this.rotateToAngleWithDuration(duration, this.getAngleAtIndex(index), isCounterClockwise);
        } else {
            // 如果呼叫這個function同時又不給時間的話, 要直接當作轉完了
            this.setCurrentRotationAngle(this.getAngleAtIndex(index));
            this._rotateStop();
        }
    },

    /**
     * 依現在角度重新排列item位置
     * @param forceRefresh  要不要強制刷新
     */
    _reLocateAllItem: function (forceRefresh = false) {
        // 角度一樣就不用重設角度了啊
        if (!forceRefresh && Math.abs(this._oldCircleRotationAngle - this._currentRotationAngle) < cc.FLT_EPSILON)
            return;

        var children = this._container.getChildren();

        for (let i = 0; i < children.length; ++i) {
            let tempChild = children[i];
            tempChild.setPosition(this.__getPositionByRotation(this._currentRotationAngle + tempChild.getAngle()));
        }

        this._oldCircleRotationAngle = this._currentRotationAngle;

        this._circularViewDelegate && this._circularViewDelegate.circularViewDidRotate(this, this._currentRotationAngle);

        // if (JSDebugMode) {
        //     cc.log("CircularViewDebugInfo: Current Angle is " + this._currentRotationAngle.toFixed(2));
        //     this._rotateAngleLabel.setString(Math.round(this._currentRotationAngle));
        // }
    },

    /**
     * 依角度取得位置
     * @param rotation
     */
    __getPositionByRotation: function (rotation) {
        rotation = cc.degreesToRadians(rotation);
        return cc.p(this._xAxisLength * Math.cos(rotation), this._yAxisLength * Math.sin(rotation));
    },

    /**
     * 安全設定角度, 限制在0-359
     */
    __setCurrentAngleTo: function (angle) {
        this._currentRotationAngle = this.__regularAngle(angle);
    },

    /**
     * 依水平位移去旋轉角度
     */
    __rotateCircularAngleWitHorizontalMovement: function (originAngle, walkDistance) {
        var scale = walkDistance / this._touchSize.width;
        var ret = originAngle + scale * this.baseViewAngleWidthRatio;

        return this.__regularAngle(ret);
    },

    /**
     * 把角度限制在0-359
     */
    __regularAngle: function (angle) {
        if (angle >= 360)
            angle -= 360;
        else if (angle < 0)
            angle += 360;

        // 浮點數防呆
        if (Math.abs(360 - angle) < cc.FLT_EPSILON)
            angle = 0;

        return angle;
    },

    /**
     * 是否要反轉上半部的轉動
     */
    setIsInvertTopHalfRotation: function (value) {
        this._isEnableInvertTopHalfRotation = value;
    },

    /**
     * 設定container
     */
    setContainer: function (container) {
        if (!container)
            return;

        if (this._container)
            this._container.removeFromParent(true);

        this._container = container;
        this.addChild(container);
        this.setTouchSize(this._touchSize);
    },

    /**
     * 設定可觸碰的範圍
     * @param size                          可觸碰範圍
     * @param isRefreshContainerPosition    是否要刷新container的位置, 把他放到中間
     */
    setTouchSize: function (size, isRefreshContainerPosition = true) {
        this._touchSize = size;
        cc.Node.prototype.setContentSize.call(this, size);

        if (isRefreshContainerPosition) {
            this._containerPosition.x = size.width / 2;
            this._containerPosition.y = size.height / 2;

            this._container.setPosition(this._containerPosition);
        }
    },

    /**
     * 設定現在circularView轉盤的旋轉角度
     */
    setCurrentRotationAngle: function (angle) {
        this.__setCurrentAngleTo(angle);
        this._reLocateAllItem();
    },

    setDelegate: function (delegate) {
        this._circularViewDelegate = delegate;
    },

    setDataSource: function (dataSource) {
        this._dataSource = dataSource;
    },

    setBaseViewAngleWidthRatio: function (angle) {
        this.baseViewAngleWidthRatio = angle;
    },

    getDelegate: function () {
        return this._circularViewDelegate;
    },

    getDataSource: function () {
        return this._dataSource;
    },

    /**
     * 現在盤面旋轉的角度
     */
    getCurrentAngle: function () {
        return this._currentRotationAngle;
    },

    /**
     * 現在盤面旋轉的角度上, 最接近哪個cell
     */
    getCurrentIndex: function () {
        var ret = -1;
        var diff = Number.MAX_VALUE;

        for (let i = 0; i < this._itemAngleArray.length; ++i) {
            let tempDiff = Math.abs(this.getAngleAtIndex(i) - this._currentRotationAngle);
            if (this.getAngleAtIndex(i) === 0) {
                tempDiff = Math.min(tempDiff, 360 - this._currentRotationAngle);
            }
            if (tempDiff < diff) {
                diff = tempDiff;
                ret = i;
            }
        }

        return ret;
    },

    getContainer: function () {
        return this._container;
    },

    /**
     * 取得角度
     */
    getAngleAtIndex: function (index) {
        return this.__regularAngle(this._startingAngle - this._itemAngleArray[index]);
    },

    getTouchesArray: function () {
        return this._touches;
    },
    /**
     * 設定container的位置
     */
    setContainerPosition: function (pos) {
        this._containerPosition.x = pos.x;
        this._containerPosition.y = pos.y;

        this._container.setPosition(pos);
    },

    /**
     * 是否回彈回item上
     */
    setIsLockOnItem: function (value) {
        this._isLockOnItem = value;
    },

    reloadData: function (reset) {
        var locContainer = this._container;
        locContainer.removeAllChildren();

        var tempAngle = this._currentRotationAngle;

        if (reset)
            this._currentRotationAngle = 0;

        var locDataSource = this._dataSource;

        var tempItemCount = this._itemCount;
        this._itemCount = locDataSource.numberItemInCircularView(this);

        var angle = 0;
        var angleArray = this._itemAngleArray;
        angleArray.length = 0;

        for (let i = 0; i < this._itemCount; ++i) {
            angle = this.__regularAngle(this._startingAngle + (360 / this._itemCount) * i);
            var itemNode = locDataSource.itemNodeAtIndex(this, i);
            itemNode.setIndex(i);
            itemNode.setAngle(angle);
            // itemNode.setPosition(this.__getPositionByRotation(angle + this._currentRotationAngle));
            locContainer.addChild(itemNode);
            angleArray.push(angle);
        }

        this._reLocateAllItem(true);

        if (tempAngle !== this._currentRotationAngle || tempItemCount !== this._itemCount) {
            if (this._circularViewDelegate && this._circularViewDelegate.circularViewDidEndRotate)
                this._circularViewDelegate.circularViewDidEndRotate(this);
        }
    },

    setTouchEnabled: function (value) {
        // 要創touch
        if (value === true && this._touchListener === undefined) {
            var listener = cc.EventListener.create({
                event: cc.EventListener.TOUCH_ONE_BY_ONE
            });
            if (this.onTouchBegan)
                listener.onTouchBegan = this.onTouchBegan.bind(this);
            if (this.onTouchMoved)
                listener.onTouchMoved = this.onTouchMoved.bind(this);
            if (this.onTouchEnded)
                listener.onTouchEnded = this.onTouchEnded.bind(this);
            if (this.onTouchCancelled)
                listener.onTouchCancelled = this.onTouchCancelled.bind(this);
            this._touchListener = listener;

            //自己加的,同步c++作法,讓結果與native 同步
            listener.setSwallowTouches(true);
            cc.eventManager.addListener(listener, this);
        }
        // 要拿掉touch
        else if (value === false && this._touchListener !== undefined) {
            if (this._touchListener) {
                cc.eventManager.removeListener(this._touchListener);
                this._touchListener = undefined;
            }
        }
    },

    /**
     * 用來算螢幕上的位移
     */
    convertDistanceFromPointToInch: function (pointDis) {
        if (cc.sys.isNative) {
            var glView = cc.director.getOpenGLView();
            var factor = (glView.getScaleX() + glView.getScaleY()) / 2;
            return pointDis * factor / cc.Device.getDPI();
        } else {
            var eglViewer = cc.view;
            var factor = (eglViewer.getScaleX() + eglViewer.getScaleY()) / 2;
            return (pointDis * factor) / 160;               // CCDevice::getDPI() default value
        }
    },

    onTouchBegan: function (touch, event) {
        if (!this.isVisible())
            return false;

        for (var c = this; c != null; c = c.parent) {
            if (!c.isVisible())
                return false;
        }

        var boundBox = cc.rect(0, 0, this._touchSize.width, this._touchSize.height);

        // 是否在範圍內
        var locPoint = this.convertTouchToNodeSpace(touch);
        var locTouches = this._touches;
        if (locTouches.length > 2 || this._touchMoved || !cc.rectContainsPoint(boundBox, locPoint))
            return false;

        this._invertMoveDistance = locPoint.y > this._touchSize.height / 2;

        locTouches.push(touch);

        if (locTouches.length === 1) { // scrolling
            this._touchPoint = this.convertTouchToNodeSpace(touch);
            this._touchMoved = false;
            this._dragging = true; //dragging started
            this._rotateDistance = 0;
        } else if (locTouches.length === 2) {
            this._touchPoint = cc.pMidpoint(this.convertTouchToNodeSpace(locTouches[0]),
                this.convertTouchToNodeSpace(locTouches[1]));
            this._dragging = false;
        }
        return true;
    },

    onTouchMoved: function (touch, event) {
        if (!this.isVisible())
            return;

        if (this._touches.length === 1 && this._dragging) {
            var newPoint = this.convertTouchToNodeSpace(touch);
            var moveDistance = cc.pSub(newPoint, this._touchPoint);

            if (!this._touchMoved && Math.abs(this.convertDistanceFromPointToInch(moveDistance.x)) < CIRCULAR_VIEW_MIN_MOVEMENT) {
                //CCLOG("Invalid movement, distance = [%f, %f], disInch = %f", moveDistance.x, moveDistance.y);
                return;
            }

            if (!this._touchMoved) {
                moveDistance.x = 0;
            }

            // 處理上半部的旋轉
            if (this._isEnableInvertTopHalfRotation) {
                if (this._invertMoveDistance)
                    moveDistance.x = -moveDistance.x;
            }

            this._touchPoint = newPoint;
            this._touchMoved = true;

            if (this._dragging) {
                var newAngle = this.__rotateCircularAngleWitHorizontalMovement(this._currentRotationAngle, moveDistance.x);
                this._rotateDistance = newAngle - this._currentRotationAngle;
                // this._currentRotationAngle = newAngle;
                this.__setCurrentAngleTo(newAngle);

                this._reLocateAllItem();
            }
        }
    },

    onTouchEnded: function (touch, event) {
        if (!this.isVisible())
            return;

        if (this._touches.length === 1 && this._touchMoved)
            this.schedule(this._decelerateRotating);

        this._touches.length = 0;
        this._dragging = false;
        this._touchMoved = false;
    },

    onTouchCancelled: function (touch, event) {
        if (!this.isVisible())
            return;

        this._touches.length = 0;
        this._dragging = false;
        this._touchMoved = false;
    },
});
