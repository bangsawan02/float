/**
 * 5.5.9 移植中撲 連續儲值 - 大廳icon
 * created by kai.wu
 */

var ContinueRechargeLobbyNode = LobbyTimeIconNode.extend({
    ctor: function () {
        this._super();

        this.key = "ContinueRechargeLobbyNode";

        // 註冊
        GS.addListener("NotifyContinueRechargeIconDone", this.notifyContinueRechargeIconDone.bind(this), this);
        GS.addListener("NotifyContinueRechargeShowRedPoint", this.notifyContinueRechargeShowRedPoint.bind(this), this);
    },

    /**
     * 更新畫面
     */
    _refreshView: function () {
        // 先清掉所有東西
        const mainNode = this._mainNode;
        mainNode.removeAllChildren();
        this._badgeNode = undefined;

        const continueRechargeData = DataModal.continueRechargeData;
        this._remainTime = JSCodeUtility.getRemainTime(continueRechargeData.remainTime, continueRechargeData.socketTime);

        if (!continueRechargeData.isOpen || this._remainTime <= 0) {
            this.setVisible(false);
            return;
        }

        this.setVisible(true);

        // icon
        let iconSprite = new cc.Sprite("#lobby_icon_continueRecharge.png");
        mainNode.addChild(iconSprite);

        // 小紅點
        const badgeNode = this._badgeNode = new BadgeNode();
        badgeNode.setPosition(18, 9);
        badgeNode.useDefaultStyle();
        badgeNode.setVisible(continueRechargeData.isShowRedPoint);
        mainNode.addChild(badgeNode);

        // 加入倒數時間
        this.createTimeLabelWithBackground(this._remainTime, () => {
            // 重要資料
            continueRechargeData.startGetInfo();
        });

        if (continueRechargeData.isPop && !DialogManager.isExist("ContinueRechargeDialog"))
            DialogManager.addLobbyDialog(new ContinueRechargeDialog());
    },

    /**
     * 按鈕
     */
    _iconClicked: function (_) {
        // 埋點：點擊icon
        var param = {type: "3"};
        DataProcess.sendString("track_continue_recharge " + JSON.stringify(param));

        // 隱藏小紅點
        this._badgeNode && this._badgeNode.setVisible(false);

        // 跳Dialog
        DialogManager.addLobbyDialog(new ContinueRechargeDialog());
    },

    /**
     * Notify
     */
    notifyContinueRechargeIconDone: function () {
        this._refreshView();
    },

    notifyContinueRechargeShowRedPoint: function () {
        this._badgeNode && this._badgeNode.setVisible(true);
    },
});