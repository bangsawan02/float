/**
 * 通行證 - 代幣飛行動畫 Node
 */
var BasePassTokenFlyAnimationNode = cc.Node.extend({
    ctor: function (config) {
        this._super();
        this._tokenIconFileName = config.tokenIconFileName || "luxyPass_pic_star.png";
    },

    setSkipped: function (isSkipped) {
        this._isSkipped = isSkipped;
    },

    /**
     * 跑動畫
     * @param {object}      startParam      起點參數
     * @param {object}      endParam        終點參數
     * @param {cc.Point[]}  middlePoints    中間點（Bezier Curve）
     * @returns {Promise<void>}
     */
    playAsync: function (startParam, endParam, middlePoints = []) {
        return new Promise((resolve, reject) => {
            let bezierConfig = Array.from(middlePoints);
            bezierConfig.unshift(startParam.pos);
            bezierConfig.push(endParam.pos);

            let j = 0;
            for (let i = 0; i < 10; i++) {
                let tokenSprite = new cc.Sprite("#" + this._tokenIconFileName);
                tokenSprite.setScale(startParam.scale || 1);
                tokenSprite.setPosition(startParam.pos);
                tokenSprite.setOpacity(0);
                this.addChild(tokenSprite, -i);

                GSSpine.create("spine/luxyPass/luxyPass_star_light", 0.18, (spine) => {
                    spine.setPosition(endParam.pos);
                    spine.setVisible(false);
                    spine.setCompleteListener(() => {
                        spine.removeFromParent();
                    });
                    this.addChild(spine, -i);

                    let moveAction;
                    if (middlePoints.length === 0) {
                        moveAction = cc.moveTo(0.3, endParam.pos);
                    } else {
                        moveAction = cc.bezierTo(0.3, bezierConfig);
                    }

                    tokenSprite.runAction(
                        cc.sequence(
                            cc.delayTime(i * 0.1),
                            cc.fadeIn(0.05),
                            cc.spawn(
                                moveAction.easing(cc.easeSineInOut()),
                                cc.scaleTo(0.3, endParam.scale).easing(cc.easeSineInOut())
                            ),
                            cc.callFunc(() => {
                                if (this._isSkipped) {
                                    this.removeFromParent();
                                    return reject();
                                }

                                spine.setVisible(true);
                                spine.setAnimation(0, "animation", false);

                                if (j === 9) {
                                    spine.setCompleteListener(() => {
                                        this.removeFromParent();
                                        resolve();
                                    });
                                }
                                j++;
                            }),
                            cc.removeSelf()
                        )
                    );
                });
            }
        });
    },
});