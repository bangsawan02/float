/**
 * v8.2 優惠券儲值觸發 優惠券挑戰
 *
 * @author tony.cheng
 */
var CouponChallengePageLayer = PurchaseTriggerIntegrationPageLayer.extend({
    ctor: function (dialog) {
        this._super(dialog);

        this.key = "CouponChallengePageLayer";
        this.type = PurchaseTriggerIntegrationData.purchaseType.COUPON_CHALLENGE;

        this._lockEventEndKey = undefined;

        this._data = DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(this.type);

        this.loadFileArray = [
            "purchaseTriggerIntegration/couponChallenge.plist", "purchaseTriggerIntegration/couponChallenge.png",
            "common/number/num_28.plist", "common/number/num_28.png",
        ];
    },

    onEnter: function () {
        this._super();

        // 紀錄已顯示過每日小紅點
        GS.localStorage.setItem(UserDefaultKey.CouponChallengeDayFirstIn + DataModal.profileData.account, TexasUtility.getNowTimeMillisecondString());
        this._data.refreshBadge();

        this._data.sendTrackingByKey("優惠券儲值觸發 點擊並進入頁籤");
    },

    setVisible: function (visible) {
        this._super(visible);

        if (visible) {
            // 卡母 Dialog 不要時間到就關掉
            if (this._lockEventEndKey === undefined) {
                this.eventEndDelegate.lock().then((key) => {
                    this._lockEventEndKey = key;
                });
            }
        } else {
            // 解鎖
            if (this._lockEventEndKey) {
                this.eventEndDelegate.unlock(this._lockEventEndKey);
                this._lockEventEndKey = undefined;
            }
        }
    },

    loadFileDone: function () {
        this._super();
        const midX = JSScreenBonusHalfWidth + 306;

        // 背景
        [-1, 1].forEach((i) => {
            const bgSp = new cc.Sprite("#couponChallenge_pic_frame_01_1.png");
            bgSp.setPosition(midX + i * 100, JSScreenBonusHalfHeight + 153);
            bgSp.setFlippedX(i === 1);
            this.addChild(bgSp);
        });

        // 標題
        const titleSp = new cc.Sprite("#couponChallenge_w_logo.png");
        titleSp.setPosition(midX, JSScreenBonusHalfHeight + 246);
        this.addChild(titleSp);

        // 副標底
        const subTitleBgSp = new ccui.Scale9Sprite("couponChallenge_pic_frame_01_2.png");
        subTitleBgSp.setContentSize(248, 24);
        subTitleBgSp.setPosition(midX, JSScreenBonusHalfHeight + 203);
        this.addChild(subTitleBgSp);

        // 副標
        const subTitleLabel = new cc.LabelTTF(LocalizedString.CouponChallengeString("使用當前的優惠券來解鎖下一張"), JSFontName, 10);
        subTitleLabel.setPosition(midX, JSScreenBonusHalfHeight + 203);
        subTitleLabel.setFontFillColor(cc.color(255, 216, 143));
        this.addChild(subTitleLabel);

        // 倒數
        const remainTimeLabel = this._remainTimeLable = new RemainTimeLabel(RemainTimeLabel.Style.BLACK);
        remainTimeLabel.setPosition(midX, JSScreenBonusHalfHeight + 224);
        this.addChild(remainTimeLabel);

        // 三個券
        this._couponsNode = [
            CouponChallengeCouponNode.Style.BLUE,
            CouponChallengeCouponNode.Style.PURPLE,
            CouponChallengeCouponNode.Style.GOLD,
        ].map((style, i) => {
            const couponNode = new CouponChallengeCouponNode(style);
            couponNode.setPosition(JSScreenBonusHalfWidth + 184 + 124 * i, JSScreenBonusHalfHeight + 99);
            this.addChild(couponNode);
            return couponNode;
        });

        // 底部字
        const bottomLabel = new cc.LabelTTF(LocalizedString.CouponChallengeString("以上優惠券僅可在儲值中心使用"), JSFontName, 10);
        bottomLabel.setPosition(midX, JSScreenBonusHalfHeight + 63);
        bottomLabel.setFontFillColor(cc.color(255, 216, 143));
        this.addChild(bottomLabel);

        // ok 按鈕
        const okBtn = new Texas_Button(Texas_Button.Style.GREEN, cc.size(105, 35), LocalizedString.CouponChallengeString("OK"));
        okBtn.setPosition(midX, JSScreenBonusHalfHeight + 36);
        okBtn.addTouchUpInsideAction(() => {
            this._data.sendTrackingByKey("優惠券儲值觸發 點擊馬上看按鈕");

            // 把自己關掉
            this.closeDialogAnimation();

            // 推去儲值中心
            PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
        }, this);
        this.addChild(okBtn);

        // 說明按鈕
        let infoButton = this._infoButton = new Texas_ExplainButton(this._explainBtnStyle);
        infoButton.addTouchUpInsideAction(() => {
            this.showInfoDialog();

            this._data.sendTrackingByKey("優惠券儲值觸發 點擊說明頁");
        }, this);
        infoButton.setPosition(121 + JSScreenBonusHalfWidth, JSVisibleSize.height - JSScreenBonusHalfHeight - 20);
        this.addChild(infoButton, 1);

        this._refreshView();

        // 卡母 Dialog 不要關掉
        if (this._lockEventEndKey === undefined) {
            this.eventEndDelegate.lock().then((key) => {
                this._lockEventEndKey = key;
            });
        }

        GS.addListener("NotifyCouponChallengeInfoDone", this.notifyCouponChallengeInfoDone.bind(this), this);
    },

    _refreshView: function () {
        /** @type {CouponChallengeData} **/
        const data = this._data;

        if (data.needRefreshData) {
            // 卡 loading 重要資料
            this.setLoadingSprite(true, true);
            this.setAllBtnEnabled(false);
            data.requestInfo();
            return;
        }

        // 解開 loading
        this.setLoadingSprite(false, false);
        this.setAllBtnEnabled(true);

        // 其餘例外
        if (!data?.getIsOpen()) {
            if (data.error === 5) {
                // error=5: 用完三張要另外處理
                const dialog = this._createCommonDialog({
                    titleStr: LocalizedString.CouponChallengeString("優惠券用完了"),
                    contentArray: [JSStringUtility.format(LocalizedString.CouponChallengeString("活動提前結束"))],
                    btnStrArray: ["OK"],
                    btnStyleArray: [Texas_Button.Style.GREEN],
                    needKeyBack: true,
                    callback: () => {
                        this.closeDialogAnimation();
                    },
                });
                this.showDialog(dialog);
            }
            return;
        }

        // 紀錄現在顯示過第幾張的小紅點
        const nowIndex = data.tickets.findIndex((item) => item.status === CouponChallengeData.TicketStatus.AVAILABLE);
        if (nowIndex >= 0) {
            GS.localStorage.setItem(UserDefaultKey.CouponChallengeLastShowCoupon + DataModal.profileData.account, nowIndex + "");
            data.refreshBadge();
        }

        // 倒數
        this._remainTimeLable.countdownSeconds(data.getRemainTime(), () => {
            const dialog = this._createCommonDialog({
                titleStr: LocalizedString.CouponChallengeString("優惠大挑戰活動已結束"),
                contentArray: [JSStringUtility.format(LocalizedString.CouponChallengeString("活動發送的優惠券已過期\n將從您的背包移除"))],
                btnStrArray: ["OK"],
                btnStyleArray: [Texas_Button.Style.GREEN],
                needKeyBack: true,
                callback: () => {
                    this.closeDialogAnimation();
                },
            });
            this.showDialog(dialog);
        });

        // 重畫三張優惠券
        data.tickets.forEach((item, i) => {
            this._couponsNode[i].refreshView(item);
        });
    },

    canExit: function () {
        this._data.sendTrackingByKey("優惠券儲值觸發 點擊關閉按鈕");
        return true;
    },

    _createInfoDialog: function () {
        return new WebViewDialog(TexasUtility.getSimpleInfoURLByKey("coupon_challenge"));
    },

    notifyCouponChallengeInfoDone: function () {
        this._refreshView();
    },

    getData: function () {
        return DataModal.purchaseTriggerIntegrationData.getPurchaseDataByType(this.type);
    },

    /**
     * @param options 詳見 CommonDialog_V2
     */
    _createCommonDialog: function (options) {
        return new CommonDialog_V2(Object.assign({
            bgImg: "couponChallenge_pic_frame_02_1.png",
            frameImg: "couponChallenge_pic_frame_02_2.png",
            titleColor: cc.color(92, 52, 0),
            contentColor: JSColor.WHITE,
        }, options));
    },

    createDebugTestObject: function () {
        return new TestMenuDebugObject("優惠券挑戰", {
            "已用 可用 未解鎖": () => DataProcess.sendCustomStringToSelf('coupon_challenge_info {"error":0,"pop":1,"cluster":1,"left_time":"12345","zones":[{"zone":1,"bonus":100,"status":2, "limit": 100000},{"zone":2,"bonus":200,"status":1, "limit": 1000000},{"zone":3,"bonus":300,"status":0}]}'),
            "未解鎖 未解鎖 未解鎖": () => DataProcess.sendCustomStringToSelf('coupon_challenge_info {"error":0,"pop":1,"cluster":1,"left_time":"12345","zones":[{"zone":1,"bonus":100,"status":0},{"zone":2,"bonus":200,"status":0},{"zone":3,"bonus":300,"status":0}]}'),
            "已用 已用 已用": () => DataProcess.sendCustomStringToSelf('coupon_challenge_info {"error":0,"pop":1,"cluster":1,"left_time":"12345","zones":[{"zone":1,"bonus":100,"status":2},{"zone":2,"bonus":200,"status":2},{"zone":3,"bonus":300,"status":2}]}'),
            "用完 活動提前結束": () => DataProcess.sendCustomStringToSelf('coupon_challenge_info {"error":5}'),
            "3s": () => DataProcess.sendCustomStringToSelf('coupon_challenge_info {"error":0,"pop":1,"cluster":1,"left_time":"3","zones":[{"zone":1,"bonus":100,"status":0},{"zone":2,"bonus":200,"status":0},{"zone":3,"bonus":300,"status":0}]}'),
            "common dialog": () => {
                const dialog = this._createCommonDialog({
                    titleStr: LocalizedString.CouponChallengeString("優惠大挑戰活動已結束"),
                    contentArray: [JSStringUtility.format(LocalizedString.CouponChallengeString("活動發送的優惠券已過期\n將從您的背包移除"))],
                    btnStrArray: ["OK"],
                    btnStyleArray: [Texas_Button.Style.GREEN],
                });
                this.showDialog(dialog);
            },
            "PropertyViewer": () => PropertyViewerDialog.show(this),
            "PropertyViewer -- Data": () => PropertyViewerDialog.show(this._data),
        });
    },
});
