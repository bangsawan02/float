/**
 * 互動道具選擇人物的畫面
 */

var ActMoodAimLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this._actMoodSerial = null;

        var photoPos = [];
        var dealerPos;
        switch (GS.nowGame) {
            case GSEnum.Game.Texas:
                // Texas
                //荷官位置
                dealerPos = Texas_GameUtility.getPlayerPosition(-1);

                // 總共多少玩家
                var totalPlayer = this._totalPlayer = 9;
                for (var i = 0; i < totalPlayer; i++)
                    photoPos.push(Texas_GameUtility.getPlayerPosition(i));
                break;
            case GSEnum.Game.Domino:
                // Domino
                // 荷官位置
                dealerPos = Domino_GameUtility.getPlayerPosition(-1);

                // 總共多少玩家
                var totalPlayer = this._totalPlayer = 7;
                for (var i = 0; i < totalPlayer; i++)
                    photoPos.push(Domino_GameUtility.getPlayerPosition(i));
                break;
            case GSEnum.Game.Gaple:
            case GSEnum.Game.GapleChat:
            case GSEnum.Game.GaplePlus:
            case GSEnum.Game.GapleFriend:
            case GSEnum.Game.GapleVideo:
                // Gaple
                // 總共多少玩家
                var totalPlayer = this._totalPlayer = 4;
                for (var i = 0; i < totalPlayer; i++)
                    photoPos.push(Gaple_GameUtility.getPlayerPosition(i));
                break;
            case GSEnum.Game.Remi:
                // Remi
                // 總共多少玩家
                var totalPlayer = this._totalPlayer = 4;
                for (var i = 0; i < totalPlayer; i++)
                    photoPos.push(Remi_GameUtility.getPlayerPosition(i));
                break;
            case GSEnum.Game.Cangkulan:
                // Cangkulan
                // 總共多少玩家
                var totalPlayer = this._totalPlayer = 4;
                for (var i = 0; i < totalPlayer; i++)
                    photoPos.push(Cangkulan_GameUtility.getPlayerPosition(i));
                break;

            case GSEnum.Game.CapsaSusun:
                // CapsaSusun
                // 總共多少玩家
                var totalPlayer = this._totalPlayer = 4;
                for (var i = 0; i < totalPlayer; i++)
                    photoPos.push(CapsaSusun_GameUtility.getPlayerPosition(i));
                break;
        }

        // 先把所有玩家畫面產生好
        var aimNodes = this._aimNodes = [];
        for (var i = 0; i < totalPlayer; i++) {
            var aimNode = new ActMoodAimNode(i, this._aimClicked, this);
            aimNode.setPosition(photoPos[i]);
            this.addChild(aimNode);

            aimNodes.push(aimNode);
        }

        // 荷官的按鈕
        if (dealerPos) {
            var aimNode = new ActMoodAimNode(-1, this._aimClicked, this);
            aimNode.setPosition(dealerPos);
            this.addChild(aimNode);
            aimNodes.push(aimNode);
        }

        // 把自己畫面關掉 之後打開透過Notify通知
        this.setVisible(false);

        // 加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this.onTouchBegan.bind(this)
        }, this);

        // 註冊
        GS.addListener("NotifyShowActMoodAim", this.notifyShowActMoodAim.bind(this), this);
    },

    /**
     * 收到updateSeat要更新畫面
     */
    cmd_updateSeat: function () {
        if (!this.isVisible())
            return;

        this._refreshTarget();
    },

    /**
     * 關掉畫面
     */
    _closeAll: function () {
        // 玩家&荷官
        this._aimNodes.forEach(function (cur) {
            cur.close();
        });

        this.setVisible(false);
    },

    /**``
     * 更新目標
     */
    _refreshTarget: function () {
        // 先判斷自己在不在牌桌
        if (!DataModal.gameData.haveMe) {
            this._closeAll();
            return;
        }

        // 一般玩家的
        var aimNodes = this._aimNodes;
        var gameData = DataModal.gameData;
        var playerArray = gameData.playerDataArray;
        for (var i = 0; i < this._totalPlayer; i++) {
            var playerIndex = gameData.getServerDirectionByDirection(i);
            var playerData = playerArray[playerIndex];
            var aimNode = aimNodes[i];
            if (playerData.getIsExist() && !playerData.getIsSelf()) {
                aimNode.show();
            } else {
                aimNode.close();
            }
        }

        // 荷官的 不一定每個遊戲都有
        var dealerNode = aimNodes[this._totalPlayer];
        dealerNode && dealerNode.show();
    },

    /**
     * 按到按鈕
     */
    _aimClicked: function (sender) {
        // 送給Server 荷官是-1
        var realPos = (sender.index === -1) ? -1 : DataModal.gameData.getServerDirectionByDirection(sender.index);
        var sendString = JSStringUtility.format("act_moods %s %d", this._actMoodSerial, realPos);
        DataProcess.sendString(sendString);

        // 把常用項目記下來
        DataModal.moodData.updateNewLastUsedActMoods(this._actMoodSerial);

        // AppsFlyer 互動道具、表情、對話功能 (累加)
        GameAppsFlyerTracker.trackByGameName("interacttool");

        // Firebase 埋點
        var eventName = GSAnalyticsAdapter.record.game + "遊戲行為";
        GSAnalyticsAdapter.logEventByFirebaseAll(eventName, ["牌桌"], ["使用互動道具"]);

        // 關掉自己畫面
        this._closeAll();
    },

    /**
     * 通知
     */
    // 要開啟畫面
    notifyShowActMoodAim: function (event) {
        this.setVisible(true);

        // 記下來編號
        this._actMoodSerial = event.getUserData();

        // 更新畫面
        this._refreshTarget();
    },

    /**
     * Touch
     */
    onTouchBegan: function (touch, event) {
        var target = event.getCurrentTarget();
        if (!target.isVisible())
            return false;
        for (var c = target.parent; c != null; c = c.parent) {
            if (!c.isVisible())
                return false;
        }

        // 沒點到 要關掉畫面
        this._closeAll();

        return false;
    }
});