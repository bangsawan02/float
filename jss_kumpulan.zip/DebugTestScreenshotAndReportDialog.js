/**
 * 5.5.3 【優化】系統資訊增加截圖功能
 * 測試先跳Alert視窗，按下screentshot後會截圖，按客服會在去客服
 *
 * created by Neil
 */
var DebugTestScreenshotAndReportDialog = BaseDialogLayer.extend({
    ctor: function (callback) {
        this._super();

        // 輸入完成後的callback
        this._callback = callback;

        // 加入動畫Layer
        var animLayer = this._animationLayer;

        // 背景
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(cc.size(380, 260));
        bgSprite.setPosition(JSScreenMidPos);
        animLayer.addChild(bgSprite);

        // 收件帳號 與 信件標題
        var titles = ["關鍵字", "標題"];
        var selects = ["這邊是抓server設定ex.\"Sistem sedang sibuk\"or \"error\"", "請輸入標題", "請輸入內容"];
        var defaultText = ["", "", ""];     // 不想打字自已測試時使用
        this.editBoxs = [];
        for (var i = 0; i < 3; i++) {

            if (i < 2) {
                var titleLabel = new cc.LabelTTF(titles[i], JSFontName, 12);
                titleLabel.setAnchorPoint(1, 0.5);
                titleLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_RIGHT);
                titleLabel.setPosition(120 + JSScreenBonusHalfWidth, (i === 0 ? 84 : 55) + JSScreenMidPos.y);
                animLayer.addChild(titleLabel);
            }

            // 編輯區
            var editSize = (i < 2) ? cc.size(300, 22) : cc.size(345, 112);
            var editboxSprite1 = new ccui.Scale9Sprite("select_03.png");
            var editboxSprite2 = new ccui.Scale9Sprite("select_03.png");
            editboxSprite2.setColor(JSColor.GRAY);
            var editBox = this.editBoxs[i] = new cc.EditBox(editSize, editboxSprite1, editboxSprite2);
            editBox.setFontColor(JSColor.BLACK);
            editBox.setFont(JSFontName, 12);
            editBox.setPlaceholderFont(JSFontName, 12);
            editBox.setPlaceHolder(selects[i]);
            editBox.setDelegate(this);
            editBox.setPosition((i < 2) ? cc.p(20 + JSScreenMidPos.x, titleLabel.getPositionY()) : cc.p(JSScreenMidPos.x, JSScreenMidPos.y - 23));
            editBox.setReturnType(cc.KEYBOARD_RETURNTYPE_DONE);
            defaultText.length && editBox.setString(defaultText[i]);
            editBox.setInputMode((i < 2) ? cc.EDITBOX_INPUT_MODE_SINGLELINE : cc.EDITBOX_INPUT_MODE_ANY);
            if (i === 1)
                editBox.setMaxLength(50);
            else
                editBox.setMaxLength(500);
            animLayer.addChild(editBox);

            // 顯示當前關鍵字
            if (i === 0)
                editBox.setString(DataModal.settingData.screenshotKeyWordArray.toString());
        }

        // Menu
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        animLayer.addChild(menu);

        // 取消、送出按鈕
        var title = [LocalizedString.Common("取消"), LocalizedString.Common("送出")];
        var image = ["lobby_btn_03.png", "lobby_btn_01.png"];
        for (var i = 0; i < 2; i++) {
            var nodes = ButtonUtility.createSingleScale9Nodes(image[i], cc.size(100, 30), title[i], 14);
            var item = new cc.MenuItemSprite(nodes[0], nodes[1], null, this._btnClicked, this);
            item.setTag(i);
            item.setPosition(JSScreenMidPos.x + ((i === 0) ? -56 : 56), JSScreenMidPos.y - 102);
            menu.addChild(item);
        }
    },

    // 取消 / 送出
    _btnClicked: function (sender) {
        if (sender.getTag() === 0) {
            this._closeDialogAnimation();
        } else {
            if (DataModal.settingData && this.editBoxs[0].getString().length > 0)
                DataModal.settingData.screenshotKeyWordArray = this.editBoxs[0].getString().split(","); // 重新設定關鍵字
            var title = this.editBoxs[1].getString();
            var content = this.editBoxs[2].getString();
            this._callback && this._callback(title, content);
        }
    },
});