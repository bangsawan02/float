/**
 * Bonus機台 牌桌 下注區圖示Node
 */
var BonusBetPlacementNode = cc.Node.extend({
    /**
     * @param {String}  string  下注區圖示文字
     * @param {Boolean} isBonus 是否為Bonus圖示
     */
    ctor: function (string, isBonus) {
        this._super();
        this._isBonus = isBonus;

        var bgStr;
        if (isBonus) {
            bgStr = "#bonus_placement_bg.png";
        } else {
            bgStr = "#bonus_bet_placement_bg.png";

            // 文字
            var label = this._placementLabel = new cc.LabelTTF(string, JSFontBoldName, 7);
            label.setFontFillColor(cc.color(255, 241, 101));
            label.setOpacity(185);
            this.addChild(label);
        }

        // 下注區背景
        var bgSp = this._backgroundSprite = new cc.Sprite(bgStr);
        this.addChild(bgSp, -1);
    },

    /**
     * 更換下注區圖檔
     * @param {Boolean} isSelect 是否輪到此下注區倍選中
     */
    setIsSelected: function (isSelect) {
        var bgStr;

        if (this._isBonus) {
            bgStr = isSelect ? "bonus_placement_on.png" : "bonus_placement_bg.png";
        } else {
            bgStr = isSelect ? "bonus_bet_placement_on.png" : "bonus_bet_placement_bg.png";
            this._placementLabel.setOpacity(isSelect ? 255 : 185);
        }
        this._backgroundSprite.setSpriteFrame(bgStr);
    }
});