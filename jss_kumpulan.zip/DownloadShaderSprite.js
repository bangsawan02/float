/**
 * 用來下載圖片且存在本機端, 假如本機端有檔案會直接抓取本機端的檔案
 * 加入可以設定Shader的功能
 */

var DownloadShaderSprite = GSDownloadSprite.extend({
    ctor: function (defaultImage, imageUrl, savePath, imageDoneCallback, needForceDownload = false) {
        this._super(defaultImage, imageUrl, savePath, imageDoneCallback, needForceDownload);

        this._shader = undefined;
    },

    setShader: function (shader) {
        if (this._shader !== shader) {
            this._shader = shader;
        }

        this._shader.initSpriteProgramState(this._photoSprite);

        if (this._shader._programState) {
            this._photoSprite.setGLProgramState(this._shader._programState);
        }

        if (this._shader._needUpdateTime)
            this.scheduleUpdate();
        else
            this.unscheduleUpdate();
    },

    update: function (delta) {
        if (this._shader)
            this._shader.updateUniformTime(delta);
    },

    restoreNormalShader: function () {
        if (this._shader) {
            if (this._shader._needUpdateTime) {
                this.unscheduleUpdate();
            }
            this._shader = undefined;
        }
        var shaderState = GSShaders.prototype.getShaderStates(GSSHADER_TYPE.None, false);
        if (shaderState)
            this._photoSprite.setGLProgramState(shaderState);
    }

});
