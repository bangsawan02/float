/**
 * 5.5.7大廳信件領獎整合 9T 信件的主頁面
 * 移植自中文德撲 16.2大廳信件領獎整合
 *
 * v16.2 新增 副系統領獎
 *       修改 官方信件格式
 *
 * modified by daniel
 */

var AwardAndMailDialog = BaseDialogLayer.extend({
    ctor: function (tab) {
        this._super();

        this.key = "AwardAndMailDialog";

        // 預設要打開的頁籤(給引導頁用)
        this._openTab = tab;

        // 有沒有送過Cmd了
        this.isSendedCmd = false;

        // 背景壓黑一點
        this.dialogBgColor = cc.color(0, 0, 0, 200);

        // 根據合併or單一版去讀不同檔案
        this.loadFileArray = [
            SelectGameManager.getNowGameFile("lobby_awardAndMail.plist", "lobby/lobby_awardAndMail/"),
            SelectGameManager.getNowGameFile("lobby_awardAndMail.png", "lobby/lobby_awardAndMail/")
        ];

    },

    onExit: function () {
        // 繼續跳其他Dialog
        DialogManager.resumeShowDialog();

        this._loadFileDone && cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[0]);

        this._super();
    },

    _dialogOpenAnimationDone: function () {
        this._super();

        // 暫停其他Dialog跳出 放這裡停才不會壞
        DialogManager.pauseShowDialog();
    },

    loadFileDone: function () {
        this._super();

        cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[0], this.loadFileArray[1]);

        var aniLayer = this._animationLayer;
        var awardAndMailStr = LocalizedString.AwardAndMail;

        // 背景圖
        var bgSprite = new cc.Scale9Sprite("awardAndMail_bg_window_01.png");
        bgSprite.setPosition(269 + JSScreenBonusHalfWidth, 139 + JSScreenBonusHalfHeight);
        bgSprite.setPreferredSize(cc.size(387, 275 + JSScreenBonusHeight));
        aniLayer.addChild(bgSprite);

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
        closeBtn.setPosition(455 + JSScreenBonusHalfWidth, 267 + JSScreenBonusHeight);
        aniLayer.addChild(closeBtn, 20);

        // 底下的對稱圖
        for (var i = 0; i < 2; ++i) {
            var isRight = i === 0;
            var bottomSprite = new cc.Sprite("#awardAndMail_pic_letter.png");
            bottomSprite.setAnchorPoint(cc.p(isRight ? 0 : 1, 0.5));
            bottomSprite.setFlippedX(isRight);
            bottomSprite.setPosition(((isRight ? -1 : 1) * 0.1) + JSScreenMidPos.x + 13, 15);
            aniLayer.addChild(bottomSprite);
        }

        // 放主要的Node
        var mainNode = this._mainNode = new cc.Node();
        mainNode.setPosition(0, 0);
        aniLayer.addChild(mainNode);

        // 放頁籤頁的Array
        this._pageArray = [];
        // 放頁籤的Array
        var tabArray = this._tabArray = [];
        var menu = new cc.Menu();
        menu.setPosition(56 + JSScreenBonusHalfWidth - 24, 233 + JSScreenBonusHeight);
        aniLayer.addChild(menu);

        // 生成頁籤
        var pageList =
            [   // 順序
                AwardAndMailDialog.Tab.AWARD,
                AwardAndMailDialog.Tab.MAIL
            ];
        if (GS.isLuxyPoker)
            pageList.push(AwardAndMailDialog.Tab.GIFT);

        pageList.forEach((cur, i) => {
            // 圖片
            var sp1Name = "awardAndMail_btn_mail_01.png";
            var sp2Name = "awardAndMail_btn_mail_02.png";
            var size = cc.size(49, 32);
            // 創標籤，合併版用美術文字圖，單一版用系統字
            var itemNode = GS.isLuxyPoker ?
                new ButtonUtility.createArrayScale9Nodes([sp2Name, sp2Name, sp1Name], size, this._getTitleString(cur), 11, JSColor.WHITE, cc.p(2, 0)) :
                new ButtonUtility.createSingleScale9SpriteNodes([sp2Name, sp2Name, sp1Name], size, this._getTitleSpName(cur));
            itemNode[2].setOpacity(255);
            // 把label改成可以換行的
            if (i === 2) {
                // 朋友禮物 文字要換行
                itemNode.forEach(_cur => {
                    var titleLabel = new cc.LabelTTF(awardAndMailStr("朋友禮物"), JSFontBoldName, 10);
                    titleLabel.setPosition(cc.p(2 + size.width / 2, size.height / 2));
                    titleLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
                    _cur.addChild(titleLabel);
                });
            }
            // 按鈕
            var menuItem = new cc.MenuItemSprite(itemNode[0], itemNode[1], itemNode[2], this._tabClicked, this);
            menuItem.tab = cur;
            menuItem.setPosition(0, (i * -36));
            menuItem.setAnchorPoint(0, 0.5);
            menuItem.getNormalImage().setScaleX(0.94);
            menuItem.getSelectedImage().setScaleX(0.94);
            menu.addChild(menuItem);
            tabArray.push(menuItem);
        });

        // loading
        var loadingSpriteLayer = this._loadingSpriteLayer = new GSLoadingSprite();
        loadingSpriteLayer.start();
        loadingSpriteLayer.setPosition(269 + JSScreenBonusHalfWidth, 144 + JSScreenBonusHalfHeight);
        aniLayer.addChild(loadingSpriteLayer, 1);

        // 擋touch
        var dummyTouchLayer = this._dummyTouchLayer = new DummyTouchLayer(JSVisibleSize);
        aniLayer.addChild(dummyTouchLayer, 1);

        // 埋點 547:進入信件整合介面
        TexasUtility.sendUserAnalyticsTrack(547);

        GS.addListener("NotifyAwardAndMailIconDone", this.notifyAwardAndMailIconDone.bind(this), this);
        GS.addListener("NotifyAwardAndMailDone", this.notifyAwardAndMailDone.bind(this), this);
        GS.addListener("NotifyMailReceiveGift", this.notifyMailReceiveGift.bind(this), this);
        GS.addListener("NotifyAwardAndMailLoading", this.notifyAwardAndMailLoading.bind(this), this);

        // 如果等Icon已經回來了 就去打開預設的頁籤
        // 沒有的話 Icon回來會再補送
        if (DataModal.awardAndMailData.isGetIconData) {
            this._openDefaultTab();
        }
    },

    // 刷新小紅點
    _refreshBadge: function () {
        if (!this._tabArray)
            return;

        // 刷新各頁籤
        var tabArray = this._tabArray;
        tabArray.forEach((cur) => {
            // 小紅點
            var count = this._getBadgeCount(cur.tab);
            if (count > 0) {
                if (cur.badgeNode) {
                    cur.badgeNode.setNumber(count);
                } else {
                    var badgeNode = new BadgeNode();
                    badgeNode.setPosition(45, 26);
                    badgeNode.setNumber(count);
                    cur.addChild(badgeNode);
                    cur.badgeNode = badgeNode;
                }
            } else {
                cur.badgeNode && cur.badgeNode.setVisible(false);
            }
        });

        // 刷新大廳icon
        DataModal.awardAndMailData.refreshTotalBadgeCount();
        GS.dispatchCustomEvent("NotifyUpdateMailBadge");
    },

    /**
     * 刷新列表畫面
     * @param tab 頁籤tab (AwardAndMailDialog.Tab)
     */
    _refreshView: function (tab) {
        // 關Loading
        this._setLoadingSprite(false);

        // 小紅點更新
        this._refreshBadge();

        // 放東西的Node
        var mainNode = this._mainNode;

        var pageArray = this._pageArray;
        // 找這頁有沒有被創過了
        var clickPos = pageArray.findIndex(cur => cur.tab === tab);

        var page = pageArray[clickPos];
        if (!page) {
            // 沒創過的話, 創一個
            switch (tab) {
                case AwardAndMailDialog.Tab.AWARD:
                    page = new AwardListLayer();
                    mainNode.addChild(page);
                    break;
                case AwardAndMailDialog.Tab.MAIL:
                    page = new MailListLayer();
                    mainNode.addChild(page);
                    break;
                case AwardAndMailDialog.Tab.GIFT:
                    page = new GiftListLayer();
                    mainNode.addChild(page);
                    break;
            }
            page.tab = tab;
            pageArray.push(page);
        } else {
            // 有的話就打開
            page.setVisible(true);
        }
    },

    // 打開預設頁籤
    _openDefaultTab: function () {
        // 沒有帶預設, 就去Data看開哪個
        var openTab = this._openTab ? this._openTab : DataModal.awardAndMailData.getDefaultTab();
        this._tabClicked(this._tabArray.find(cur => (cur.tab === openTab)), true);

        // _tabClicked 會去要打開的頁籤資料, 這邊就可以標記送過了
        this.isSendedCmd = true;
    },

    // 點擊關閉按鈕
    _closeBtnClicked: function () {
        this._closeDialogAnimation();
    },

    // 開關Loading
    _setLoadingSprite: function (isVisible) {
        if (isVisible)
            this._loadingSpriteLayer.start();
        else
            this._loadingSpriteLayer.stop();

        this._dummyTouchLayer.setVisible(isVisible);
    },

    // 取得頁籤名稱
    _getTitleString: function (type) {
        var awardAndMailStr = LocalizedString.AwardAndMail;
        switch (type) {
            case AwardAndMailDialog.Tab.AWARD:
                return awardAndMailStr("領取(頁籤)");
            case AwardAndMailDialog.Tab.MAIL:
                return awardAndMailStr("信件");
            case AwardAndMailDialog.Tab.GIFT:
                return "";  // 文字「朋友禮物」顯示需要換行，另外處理
        }
    },

    // 取得頁籤文字圖檔案名稱
    _getTitleSpName: function (type) {
        switch (type) {
            case AwardAndMailDialog.Tab.AWARD:
                return "#awardAndMail_word_award.png";
            case AwardAndMailDialog.Tab.MAIL:
                return "#awardAndMail_word_mail.png";
        }
    },

    // 取得頁籤小紅點數量
    _getBadgeCount: function (type) {
        var data = DataModal.awardAndMailData;
        switch (type) {
            case AwardAndMailDialog.Tab.AWARD:
                return data.tabBadgeCountObj.awardBadgeCount;
            case AwardAndMailDialog.Tab.MAIL:
                return data.tabBadgeCountObj.mailBadgeCount;
            case AwardAndMailDialog.Tab.GIFT:
                return data.tabBadgeCountObj.giftBadgeCount;
        }
    },

    // 點擊頁籤按鈕
    _tabClicked: function (sender, isDefaultOpen = false) {
        // 改變頁籤圖片狀態
        for (var i = 0, len = this._tabArray.length; i < len; i++) {
            this._tabArray[i].setEnabled(true);
        }
        sender.setEnabled(false);

        // 將全部頁籤隱藏
        this._pageArray.forEach(cur => {
            cur.setVisible(false);
        });

        // 卡Loading
        this._setLoadingSprite(true);

        var trackID;
        var data = DataModal.awardAndMailData;
        var isFresh = false;
        switch (sender.tab) {
            // 小紅點Icon有更新 兩個List才會被undefined
            case AwardAndMailDialog.Tab.MAIL:
                isFresh = (data.mailList === undefined);
                trackID = 553;
                break;
            case AwardAndMailDialog.Tab.AWARD:
                isFresh = (data.awardList === undefined);
                trackID = 549;
                break;
            case AwardAndMailDialog.Tab.GIFT:
                isFresh = (data.giftList === undefined);
                break;
        }
        // 埋點 548:信件整合-切換任一頁籤; 埋點 553:點擊信件頁籤; 埋點 549:點擊領取頁籤
        // 預設開的不埋點
        if (!isDefaultOpen) {
            TexasUtility.sendUserAnalyticsTrack([548, ...(trackID ? [trackID] : [])]);
        }

        if (isFresh) {
            // 需要更新 去跟serve要資料
            DataModal.awardAndMailData.sendAwardAndMailCmdToSever(sender.tab);
        } else {
            // 沒有更新 用現有資料開
            this._refreshView(sender.tab);
        }
    },

    /**
     * Android Back Key
     */
    keyBackPressed: function () {
        this._closeBtnClicked();
    },

    /**
     * 通知
     */
    // 小紅點刷新
    notifyAwardAndMailIconDone: function () {
        this._refreshBadge();

        // 如果上面沒送的話 代表Icon還沒回來
        // 這裡回來了要補送打開預設的頁籤
        if (!this.isSendedCmd) {
            this._openDefaultTab();
        }
    },

    // 列表刷新
    notifyAwardAndMailDone: function (event) {
        if (event && event.getUserData()) {
            var tab = event.getUserData();
            this._refreshView(tab);
        }
    },

    // 收到禮物信件
    notifyMailReceiveGift: function (event) {
        var awardAndMailStr = LocalizedString.AwardAndMail;

        if (event) {
            var param = event.getUserData();
            if (param.code) {
                // 收取禮物成功
                var giftString = JSStringUtility.format("%s x %s", param.item, JSCodeUtility.getCurrencyString(param.count));
                DialogManager.addDialog(new AwardAndMailCommonDialog(awardAndMailStr("恭喜您"), giftString, undefined, param.account), false);

                // 更新頁面
                DataModal.awardAndMailData.sendAwardAndMailCmdToSever(AwardAndMailDialog.Tab.GIFT);
                this._setLoadingSprite(true);
            } else {
                // 收取禮物失敗
                AlertDialog.showAlert(null, param.message, null);
            }
        }
    },

    // 外部通知壓loading
    notifyAwardAndMailLoading:function (isLoading) {
        this._setLoadingSprite(isLoading);
    }
});

// 有哪些頁籤, 對應AwardAndMailData.Group的Server編號
AwardAndMailDialog.Tab = {
    AWARD: 5,       // 領取
    MAIL: 2,        // 信件
    GIFT: 1         // 禮物盒
};