/**
 * 5.4.0 副系統 - 激戰任務時段按鈕
 * created by Jim.Chen
 */

var FierceBattlePeriodButton = GSControlButton.extend({
    ctor: function (btnSize, pageParam) {
        this._super(undefined, btnSize);

        this.pageParam = pageParam;

        var contentNode = this._contentNode;

        // 一般的背景
        var normalSprite = this._bgSprite1 = new ccui.Scale9Sprite("fierceBattle_btn_02.png");
        normalSprite.setPreferredSize(btnSize);
        contentNode.addChild(normalSprite);

        // 選到的背景
        var selectedSprite = this._bgSprite2 = new ccui.Scale9Sprite("fierceBattle_btn_01.png");
        selectedSprite.setPreferredSize(btnSize);
        selectedSprite.setVisible(false);
        contentNode.addChild(selectedSprite);

        // 文字
        var buttonWord = new cc.LabelTTF(pageParam.periodTxt, JSFontBoldName, 10, btnSize, cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        contentNode.addChild(buttonWord);

        // 自己的設定
        this.setChangeColorWhenDisabled(false);
        this.setChangeOpacityWhenDisabled(false);
        this.enableTouchCancel(cc.SCROLLVIEW_DIRECTION_VERTICAL);
    },

    setEnabled: function (enabled) {
        this._super(enabled);

        // 要改背景
        this._bgSprite1.setVisible(enabled);
        this._bgSprite2.setVisible(!enabled);
    },

    /**
     * 按到的時後 要改變顏色
     */
    _buttonClicked: function (sender, type) {
        var isTouched = (type === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || type === cc.CONTROL_EVENT_TOUCH_DOWN);
        this._mainNode.setColor(isTouched ? JSColor.GRAY : JSColor.WHITE);
    },
});