/**
 * 通行證 - Enum
 */

var BasePassRewardStatus = {
    NOT_COMPLETE: 0,
    CAN_REWARD: 1,
    FINISH: 2,
};

var BasePassDialogType = {
    BUY_PASS: 1,                // 購買 pass
    CYCLE_REWARD: 2,            // 循環獎勵解鎖
    GET_REWARD: 3,              // 獲得獎勵
    NORMAL: 4,                  // 一般訊息
    NOT_RECHARGE_GET_REWARD: 5, // 未儲值的領獎
    GET_TOKEN: 6,               // 獲得代幣
    BUY_SUPER_PASS: 7,          // 購買超級豪華通行證
};

// 埋點：從哪裡解鎖 pass
var BasePassBuyFromWhere = {
    MAIN_DIALOG: 0,
    BUY_PASS_DIALOG: 1,
    NOT_CHARGE_GET_REWARD_DIALOG: 2,
    LEAVE_NOTICE_DIALOG: 3,
    BUY_PASS_DIALOG_CYCLE: 4,
    BUY_SUPER_PASS_DIALOG: 5,   // 購買超級豪華通行證
};

// 通行證類型
var BasePassType = {
    FREE: 0,                    // 免費
    LUXURY: 1,                  // 豪華
    SUPER: 2,                   // 超級豪華
};