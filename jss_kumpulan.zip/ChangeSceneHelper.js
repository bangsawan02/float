/**
 * 用來切換場景使用的小幫手
 */

var ChangeSceneHelper = {
    _loadJSFileDone: {},                // 用來判斷是否讀取JS檔案完成

    // 抓取進入到指定的scene所需的資源包
    getResources: function (scene) {
        var retArray = [];
        switch (scene) {
            case GSEnum.Scene.Login:
                break;
            case GSEnum.Scene.Lobby:
                retArray = [
                    "lobby/lobby_reward.png",
                    "lobby/lobby_reward.plist",
                    "lobby/select_game.png",
                    "lobby/select_game.plist",
                    "lobby/vip.png",
                    "lobby/vip.plist",
                    "common/number/num_04.plist",
                    "common/number/num_04.png",
                    "common/number/num_09.plist",
                    "common/number/num_09.png",
                    "common/number/num_11.plist",
                    "common/number/num_11.png",
                    "vegas/vegas_common.png",
                    "vegas/vegas_common.plist",
                    "vegas/vegasVip/vegasVip.plist",
                    "vegas/vegasVip/vegasVip.png",
                    SelectGameManager.getNowGameFile("vegasVip.plist", "vegas/vegasVip/"),
                    SelectGameManager.getNowGameFile("vegasVip.png", "vegas/vegasVip/")
                ];
                break;
            case GSEnum.Scene.Game: {
                retArray = [
                    "game/game_bg_pattern.png",
                    "game/emoticons.plist",
                    "game/emoticons.png",
                    "common/number/num_09.plist",
                    "common/number/num_09.png",
                    "common/number/num_11.plist",
                    "common/number/num_11.png",
                ];

                // 牌桌遊戲(QQ機台是娛樂城)
                if (GS.nowGame !== GSEnum.Game.TebakQQ) {
                    retArray.push("game/Common/game_common.png");
                    retArray.push("game/Common/game_common.plist");
                }

                // 德撲
                switch (GS.nowGame) {
                    case GSEnum.Game.Domino: {
                        retArray.push("game/Domino/game_bg_windows.png");
                        retArray.push("game/Domino/game_domino.png");
                        retArray.push("game/Domino/game_domino.plist");
                        break;
                    }
                    case GSEnum.Game.Texas: {
                        retArray.push("game/game_texas.png");
                        retArray.push("game/game_texas.plist");
                        retArray.push("vegas/vegas_common.png");
                        retArray.push("vegas/vegas_common.plist");
                        retArray.push("common/gorgeousPokerCard/gorgeousPokerCard.png");
                        retArray.push("common/gorgeousPokerCard/gorgeousPokerCard.plist");
                        retArray.push("common/number/num_white_led2.png");
                        retArray.push("common/number/num_white_led2.plist");
                        retArray.push("rank/gameRank.png");
                        retArray.push("rank/gameRank.plist");
                        break;
                    }
                    case GSEnum.Game.Gaple:
                    case GSEnum.Game.GapleChat:
                    case GSEnum.Game.GapleFriend:
                    case GSEnum.Game.GaplePlus: {
                        retArray.push("background/Domino/game_gaple_background.jpg");
                        retArray.push("game/Domino/game_gaple.png");
                        retArray.push("game/Domino/game_gaple.plist");
                        retArray.push("common/number/gaple_num_multi.png");
                        retArray.push("common/number/gaple_num_multi.plist");

                        // 獎金賽的圖檔(看FID開啟所以可能在桌內開啟 這樣就先預load相關圖檔)
                        retArray.push("common/number/num_24.png");
                        retArray.push("common/number/num_24.plist");
                        retArray.push("tournament/Domino/gapleJPBattle.png");
                        retArray.push("tournament/Domino/gapleJPBattle.plist");

                        if (GS.nowGame === GSEnum.Game.GaplePlus) {
                            retArray.push("common/number/num_11.png");
                            retArray.push("common/number/num_11.plist");
                            retArray.push("background/Domino/game_gaplePlus_background.jpg");
                        } else if (GS.nowGame === GSEnum.Game.GapleFriend) {
                            // gaple好友桌
                            retArray.push("game/Domino/game_gaple_friend.png");
                            retArray.push("game/Domino/game_gaple_friend.plist");
                        }

                        if (DataModal.tournamentData.tournamentType === GSEnum.Tournament.GapleKO) {
                            retArray.push("common/number/num_04.png");
                            retArray.push("common/number/num_04.plist");
                            retArray.push("tournament/Domino/gapleKO.png");
                            retArray.push("tournament/Domino/gapleKO.plist");
                        }
                        break;
                    }
                    case GSEnum.Game.GapleVideo: {
                        retArray.push("background/Domino/game_gapleVideo_background.jpg");
                        retArray.push("game/Domino/game_gapleVideo_table_01.png");
                        retArray.push("game/Domino/game_gaple.png");
                        retArray.push("game/Domino/game_gaple.plist");
                        break;
                    }
                    case GSEnum.Game.Remi: {
                        retArray.push("background/Domino/game_remi_background.jpg");
                        retArray.push("game/Domino/game_remi.png");
                        retArray.push("game/Domino/game_remi.plist");
                        break;
                    }
                    case GSEnum.Game.Cangkulan: {
                        retArray.push("background/Domino/game_cangkulan_background.jpg");
                        retArray.push("game/Domino/game_cangkulan.png");
                        retArray.push("game/Domino/game_cangkulan.plist");
                        break;
                    }
                    case GSEnum.Game.CapsaSusun: {
                        retArray.push("background/Domino/game_capsaSusun_background.jpg");
                        retArray.push("game/Domino/game_capsaSusun.png");
                        retArray.push("game/Domino/game_capsaSusun.plist");
                        break;
                    }
                }
                break;
            }
        }

        return retArray;
    },

    // preload scene
    preloadScene: function (scene) {
        var loadArray = ChangeSceneHelper.getResources(scene);
        if (loadArray.length) {
            cc.loader.load(loadArray, function () {
                cc.log('Scene Tag ' + scene + ' is preloaded');
            });
        }
    },

    /**
     * 預先讀JS File
     * @param {string} filename     帶要讀的檔案名稱 (那個檔案名稱裡面要有一樣的檔名Array)
     * @param {function} callback   讀取完成的callback
     */
    preloadJSFile: function (filename, callback) {
        if (this._loadJSFileDone[filename]) {
            // 讀完了 直接callback
            callback && callback();
        } else {
            // 要讀取
            var allFiles = window[filename];
            cc.loader.loadJs("", allFiles, () => {
                // 設定已讀取過
                this._loadJSFileDone[filename] = true;

                // 把這個變數清掉 可以省一點空間
                window[filename] = undefined;

                // callback回去
                callback && callback();
            });
        }
    },

    /**
     * 去大廳頁面
     * @param param     可以帶給LobbyScene的東西
     * @param callback  讀完的callback
     */
    goLobbyScene: function (param, callback) {
        // 先把Socket暫停分發
        DataModal.dataProcess.setGamePause(true, true);

        // 已回大廳 降下 Vegas 的 flag
        DataModal.vegasData.clearStartToLobbyProcess();

        // 加入Loading
        GSLoading.addLoadingView();

        // 一開始先讀取遊戲內部的JS
        var filename = "LobbyFiles";
        this.preloadJSFile(filename, () => {
            // 切換Scene
            var changeScene = () => {
                var nextScene = new LobbyScene();
                cc.director.runScene(nextScene);

                // 把Socket開始分發 要delay 1 frame 等下一個scene onEnter
                GS.addListenerOnce(cc.Director.EVENT_AFTER_DRAW, () => {
                    DataModal.dataProcess.setGamePause(false, true);

                    // 讀完了 callback回去
                    callback && callback();
                }, nextScene);
            };

            if (cc.sys.isNative) {
                // 原生直接切換
                changeScene();
            } else {
                // H5要讀取東西
                cc.loader.load(ChangeSceneHelper.getResources(GSEnum.Scene.Lobby), function () {
                    // 切換到場景
                    changeScene();
                });
            }
        });
    },

    /**
     * 去遊戲頁面 因為遊戲都分開讀取的 所以要透過這個來處理
     * @param param     可以帶給GameScene的東西
     * @param callback  讀完的callback
     */
    goGameScene: function (param, callback) {
        // 先把Socket暫停分發
        DataModal.dataProcess.setGamePause(true, true);

        // 加入Loading
        GSLoading.addLoadingView();

        // 一開始先讀取遊戲內部的JS
        var filename = SelectGameManager.stringFormatWithGameClass("%s_GameFiles");
        this.preloadJSFile(filename, () => {
            // 切換Scene
            var changeScene = () => {
                var sceneName = SelectGameManager.stringFormatWithGameClass("%s_GameScene");
                var nextScene = new window[sceneName](param);
                cc.director.runScene(nextScene);

                // 把Socket開始分發 要delay 1 frame 等下一個scene onEnter
                GS.addListenerOnce(cc.Director.EVENT_AFTER_DRAW, () => {
                    DataModal.dataProcess.setGamePause(false, true);

                    nextScene.onChangeSceneReady && nextScene.onChangeSceneReady();

                    // 讀完了 callback回去
                    callback && callback();
                }, nextScene);
            };

            if (cc.sys.isNative) {
                // 原生直接切換
                changeScene();
            } else {
                // H5要讀取東西
                cc.loader.load(ChangeSceneHelper.getResources(GSEnum.Scene.Game), function () {
                    changeScene();
                });
            }
        });
    },

    /**
     * 去娛樂城牌局重現的頁面
     * @param param     可以帶給GameScene的東西 裡面需帶slotType
     * @param callback  讀完的callback
     */
    goVegasReconnectScene: function (param, callback) {
        // 先把Socket暫停分發
        DataModal.dataProcess.setGamePause(true, true);

        // 加入Loading
        GSLoading.addLoadingView();

        // 切換Scene
        var changeScene = () => {
            var nextScene = new VegasReconnectScene(param);
            cc.director.runScene(nextScene);

            // 把Socket開始分發 要delay 1 frame 等下一個scene onEnter
            GS.addListenerOnce(cc.Director.EVENT_AFTER_DRAW, () => {
                DataModal.dataProcess.setGamePause(false, true);

                // 讀完了 callback回去
                callback && callback();
            }, nextScene);
        };

        if (cc.sys.isNative) {
            // 原生直接切換
            changeScene();
        } else {
            // H5要讀取東西
            var resourceArray = PushLayerHelper.getVegasResources(param.slotType);
            cc.loader.load(resourceArray, function () {
                // 切換到場景
                changeScene();
            });
        }
    },

    /**
     * 去娛樂城切換到game server的Scene
     * @param param     可以帶給VegasScene:的東西 裡面需帶slotType
     * @param callback  讀完的callback
     */
    goVegasScene: function (param, callback) {
        // 先停掉Socket分發
        DataModal.dataProcess.setGamePause(true, true);

        // 加入Loading
        GSLoading.addLoadingView();

        // 切換Scene
        var changeScene = () => {
            var nextScene = new VegasScene(param);
            cc.director.runScene(nextScene);

            // 把Socket開始分發 要delay 1 frame 等下一個scene onEnter
            GS.addListenerOnce(cc.Director.EVENT_AFTER_DRAW, () => {
                DataModal.dataProcess.setGamePause(false, true);

                // 讀完了 callback回去
                callback && callback();
            }, nextScene);
        };

        if (cc.sys.isNative) {
            // 原生直接切換
            changeScene();
        } else {
            // H5要讀取東西
            var resourceArray = PushLayerHelper.getVegasResources(param.slotType);
            cc.loader.load(resourceArray, function () {
                // 切換到場景
                changeScene();
            });
        }
    }
};