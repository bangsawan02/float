/**
 * 大廳裂變Icon
 */
var FissionIconNode = LobbyTimeIconNode.extend({
    ctor: function () {
        this._super();

        this.key = "FissionIconNode";

        // 註冊通知
        GS.addListener("NotifyShowFissionIcon", this.notifyShowFissionIcon.bind(this), this);
    },

    _refreshView: function () {
        // 抓資料
        var param = DataModal.lobbyInfo.invitationCampaignInfo;

        // 活動沒有開放
        if (!param || !param.isShow) {
            this.setVisible(false);
            return;
        }

        // 記下資料
        this._param = param;

        // 創建icon
        if (!this._btn) {
            // icon
            var iconSprite = new cc.Sprite("#lobby_icon_fission.png");
            iconSprite.setPositionY(-2);
            this._mainNode.addChild(iconSprite);

            // icon
            var iconWordSprite = new cc.Sprite("#lobby_word_fission.png");
            iconWordSprite.setPositionY(-15);
            this._mainNode.addChild(iconWordSprite);
        }

        this.setVisible(true);
    },

    /**
     * 點擊跳出Dialog
     */
    _iconClicked: function () {
        if (!this._param)
            return;

        DialogManager.addDialog(new FissionDialog(this._param), false);
    },

    /**
     * 通知showIcon
     */
    notifyShowFissionIcon: function () {
        this._refreshView();
    }
});