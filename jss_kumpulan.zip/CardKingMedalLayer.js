/**
 * 牌王獎章畫面 Created by terry on 2021/3/29.
 */

var CardKingMedalLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        this._medalArray = [];

        // 放內容的, 等資料好了才秀
        var contentNode = this._contentNode = new cc.Node();
        contentNode.setVisible(false);
        this.addChild(contentNode);

        // 漸層左
        var decorationSprite = new ccui.Scale9Sprite("cardKing_bg_decoration.png");
        decorationSprite.setAnchorPoint(0, 0.5);
        decorationSprite.setCapInsets(cc.rect(4, 0, 21, 270));
        decorationSprite.setPreferredSize(cc.size(116 + JSScreenBonusHalfWidth, 270 + JSScreenBonusHeight));
        decorationSprite.setPositionY(134 + JSScreenBonusHalfHeight);
        contentNode.addChild(decorationSprite);

        // 漸層右
        var decorationSprite = new ccui.Scale9Sprite("cardKing_bg_decoration.png");
        decorationSprite.setScale(-1);
        decorationSprite.setAnchorPoint(0, 0.5);
        decorationSprite.setCapInsets(cc.rect(4, 0, 21, 270));
        decorationSprite.setPreferredSize(cc.size(276 + JSScreenBonusHalfWidth, 270 + JSScreenBonusHeight));
        decorationSprite.setPosition(JSVisibleSize.width, 134 + JSScreenBonusHalfHeight);
        contentNode.addChild(decorationSprite);

        // 背景
        var bgSprite = new ccui.Scale9Sprite("cardKing_bg_purple.png");
        bgSprite.setAnchorPoint(0, 1);
        bgSprite.setPreferredSize(cc.size(JSVisibleSize.width, 100));
        bgSprite.setPositionY(JSVisibleSize.height - TITLE_BG_HEIGHT + 10);
        contentNode.addChild(bgSprite);

        // 標題
        {
            // 標題-年
            var titleYearSprite = new cc.Sprite("#cardKing_word_title_01.png");
            titleYearSprite.setPosition(90 + JSScreenBonusHalfWidth, 234 + JSScreenBonusHalfHeight);
            contentNode.addChild(titleYearSprite, 1);

            // 哪一年
            var yearSprite = this._yearSprite = new GSSpriteNumberNode({
                number: 2021,
                numStr: "#num_20_",
                spW: 12,
            });
            yearSprite.setPosition(190 + JSScreenBonusHalfWidth, 236 + JSScreenBonusHalfHeight);
            contentNode.addChild(yearSprite, 1);

            // 標題-季
            var titleSeasonSprite = new cc.Sprite("#cardKing_word_title_02.png");
            titleSeasonSprite.setPosition(243 + JSScreenBonusHalfWidth, 234 + JSScreenBonusHalfHeight);
            contentNode.addChild(titleSeasonSprite, 1);

            // 哪一季
            var seasonSprite = this._seasonSprite = new GSSpriteNumberNode({
                number: 1,
                numStr: "#num_20_",
                spW: 12,
            });
            seasonSprite.setPosition(278 + JSScreenBonusHalfWidth, 236 + JSScreenBonusHalfHeight);
            contentNode.addChild(seasonSprite, 1);
        }

        // 檯子
        [210, 294].forEach((width, index) => {
            var shelfSprite = new ccui.Scale9Sprite("cardKing_pic_shelf_01.png");
            shelfSprite.setPreferredSize(cc.size(width, 28));
            shelfSprite.setPosition(152 + JSScreenBonusHalfWidth, (!!index ? 38 : 137) + JSScreenBonusHalfHeight);
            contentNode.addChild(shelfSprite);
        });

        // 櫃子的造型
        [73, 238].forEach((posX, index) => {
            var shelfSprite = new cc.Sprite("#cardKing_pic_shelf_02.png");
            !!index && shelfSprite.setFlippedX(true);
            shelfSprite.setPosition(posX + JSScreenBonusHalfWidth, 135 + JSScreenBonusHalfHeight);
            contentNode.addChild(shelfSprite);
        });

        // 獎章的array
        var posArray = [
            cc.p(252 + JSScreenBonusHalfWidth, 72 + JSScreenBonusHalfHeight),
            cc.p(184 + JSScreenBonusHalfWidth, 72 + JSScreenBonusHalfHeight),
            cc.p(116 + JSScreenBonusHalfWidth, 72 + JSScreenBonusHalfHeight),
            cc.p(48 + JSScreenBonusHalfWidth, 72 + JSScreenBonusHalfHeight),
            cc.p(150 + JSScreenBonusHalfWidth, 171 + JSScreenBonusHalfHeight)];

        // 獎章
        this._medalArray = posArray.map((cur, i) => {
            // 徽章從1開始
            var medalNode = this._createMedalNode(i + 1);
            medalNode.setPosition(cur);
            contentNode.addChild(medalNode, 2);
            return medalNode;
        });

        // 上面的倒數背景
        var countdownBgSprite = this._countdownBgSprite = new ccui.Scale9Sprite("bg_shadow_02.png");
        countdownBgSprite.setPosition(150 + JSScreenBonusHalfWidth, 216 + JSScreenBonusHalfHeight);
        contentNode.addChild(countdownBgSprite, 2);

        // 倒數
        var countdownNode = this._countdownNode = new GSTimeLabel("", JSFontName, 12);
        countdownNode.setPosition(150 + JSScreenBonusHalfWidth, 216 + JSScreenBonusHalfHeight);
        contentNode.addChild(countdownNode, 3);

        // 詳細資料
        var detailLayer = this._detailLayer = new CardKingMedalDetailLayer();
        contentNode.addChild(detailLayer, 3);

        // 轉圈圈
        var loadingSp = this._loadingSp = new GSLoadingSprite();
        loadingSp.setPosition(JSScreenMidPos);
        this.addChild(loadingSp, 10);
        loadingSp.start();

        // 時間到要更新資訊
        if (JSCodeUtility.getRemainTime(DataModal.cardKingData.remainTime, DataModal.cardKingData.socketTime) > 0) {
            this._refreshView();
        }

        // 通知
        GS.addListener("NotifyCardKingInfoDone", this.notifyCardKingInfoDone.bind(this), this);
    },

    // 給外面的人取得徽章位置
    getMedalPosByIndex: function (index) {
        if (this._medalArray[index])
            return this._medalArray[index].getPosition();
        return cc.p(0, 0);
    },

    // 更新
    _refreshView: function () {
        this._contentNode.setVisible(true);
        this._loadingSp.stop();

        // 沒有開放
        var data = DataModal.cardKingData;
        if (data.status < CardKingData.Status.OPEN)
            return;

        var cardKingString = LocalizedString.CardKing;

        // 哪一季
        this._seasonSprite.setNumber(data.season);

        // 哪一年
        this._yearSprite.setNumber(data.year);

        // 倒數時間
        var leftTime = JSCodeUtility.getRemainTime(data.remainTime, data.socketTime);
        if (leftTime > 0) {
            // 調整倒數文字
            var prefixStr = data.status === CardKingData.Status.OPEN ? "賽季倒數" : "重置倒數";
            this._countdownNode.setMultiFormat(
                cardKingString(prefixStr) + "：%dd" + cardKingString("天") + " %hh" + cardKingString("時"),
                cardKingString(prefixStr) + "：%hh" + cardKingString("時") + " %mm" + cardKingString("分"),
                cardKingString(prefixStr) + "：%mm" + cardKingString("分") + " %ss" + cardKingString("秒"),
                cardKingString(prefixStr) + "：%mm" + cardKingString("分") + " %ss" + cardKingString("秒")
            );
            this._countdownNode.countdownSeconds(leftTime, undefined, undefined);

            // 調整倒數文字背景
            this._countdownBgSprite.setPreferredSize(cc.size(this._countdownNode.getContentSize().width + 18, 18));
        }

        var preSelect = 0;

        // 更新獎章
        this._medalArray.forEach((cur, i) => {
            // for從0開始, 但是徽章是從1開始的
            var medalDetail = data.medalDetail[i + 1];
            if (medalDetail) {
                cur.button.setEnabled(true);
                if (medalDetail.isCurrentSeasonHave) {
                    cur.button.setOpacity(255);
                    preSelect = i;
                } else {
                    // 沒獲得要暗一些
                    cur.button.setOpacity(150);
                }

                // 幾局
                cur.label.setString(JSStringUtility.format("%s %s", TexasUtility.getSimpleMoneyString(medalDetail.thisSeasonAchieveRoundCount), cardKingString("局")));
            } else {
                cur.button.setEnabled(false);
            }
        });

        // 預選哪個
        this._updateDetailNode(this._medalArray[preSelect].button.level);
    },

    // 創中間小盒子背景
    _createBox: function () {
        var ret = new cc.Node();

        // 背景寬
        var boxWidth = 275 + JSScreenBonusHalfWidth;

        // 藍色背景
        var blueBg = new cc.Scale9Sprite("cardKing_pic_box.png");
        blueBg.setPreferredSize(cc.size(boxWidth, 78));
        ret.addChild(blueBg, 0);

        // x的放大量
        var xScale = 8 * boxWidth / 275;

        // 一個光
        var lightSp = new cc.Sprite("#cardKing_pic_boxBG.png");
        lightSp.setScale(xScale, 4);
        lightSp.setPosition(0, 7);
        ret.addChild(lightSp, 0);

        return ret;
    },

    // 創獎牌按鈕
    _createMedalNode: function (level) {
        var bgSp = new cc.Sprite("#" + TexasUtility.getCardKingMedalName(level));

        var ret = new cc.Node();

        // 獎牌按鈕
        var button = ret.button = new GSControlButton(bgSp);
        button.addTouchUpInsideAction(this._medalBtnClicked, this);
        // 按到可以知道要刷新什麼
        button.level = level;
        ret.addChild(button);

        // 文字背景
        var numberBg = new ccui.Scale9Sprite("cardKing_pic_frame_01.png");
        numberBg.setPreferredSize(cc.size(60, 20));
        numberBg.setPosition(0, -53);
        ret.addChild(numberBg);

        // 文字
        var label = ret.label = new GSAutoSizeLabel("", JSFontName, 12, cc.size(45, 16), cc.TEXT_ALIGNMENT_CENTER, cc.TEXT_ALIGNMENT_CENTER);
        label.setPosition(0, -53);
        ret.addChild(label);

        return ret;
    },

    // 按到獎牌
    _medalBtnClicked: function (sender) {
        // 埋點
        DataProcess.sendString(JSStringUtility.format('track_crown_king {"type":"%d"}', 4 + sender.level));
        this._updateDetailNode(sender.level);
    },

    // 更新右邊資訊
    _updateDetailNode: function (level) {
        this._detailLayer.refreshByLevel(level);
    },

    /**
     * 通知
     */
    notifyCardKingInfoDone: function () {
        this._refreshView();
    }
});