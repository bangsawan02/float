/**
 * v5.5.4 Gaple 系列牌桌優化 - 互動道具和聊天室整合
 * created by Lichieh.
 */
var EmoticonsChatDialog = BaseDialogLayer.extend({
    ctor: function (openPos) {
        this._super();

        this.setCascadeOpacityEnabled(true);

        // 設定Dialog Key
        this.key = "EmoticonsChatDialog";

        this.dialogBgColor = cc.color(255, 255, 255, 0);

        openPos && this.setOpenWorldPosition(openPos);

        // 跳出的視窗
        var aniLayer = this._animationLayer;

        this._pageArray = [];

        // 用於依照遊戲不同儲存不同的圖檔資源及按鈕設定
        var resourceObj = {};
        switch (GS.nowGame) {
            case GSEnum.Game.Gaple:
            case GSEnum.Game.GapleVideo:
            case GSEnum.Game.GaplePlus:
                // 背景底
                resourceObj.bg = {
                    pic: "gaple_pic_frame_01.png",
                    preferredSize: cc.size(210, 210),
                    position: cc.p(106, 133)
                };

                // 黑底
                resourceObj.blackBg = {
                    pic: "gaple_bg_black_02.png"
                };

                // 左側分頁按鈕
                resourceObj.tabButtons = ["#gaple_pic_talk.png", "#gaple_pic_emoticons.png"].map((cur, i) => {
                    return {
                        size: cc.size(28, 86),
                        position: cc.p(23, 85 + i * 87),
                        // 可點擊
                        normal: {
                            bg: {
                                pic: "gaple_bg_black.png",
                                opacity: 76,
                                preferredSize: cc.size(24, 86)
                            },
                            icon: {
                                pic: cur,
                                opacity: 127
                            }
                        },
                        // 不可點擊
                        focused: {
                            bg: {
                                pic: "gaple_btn_01_3.png",
                                preferredSize: cc.size(28, 86),
                            },
                            icon: {
                                position: cc.p(14, 43),
                            }
                        }
                    };
                });

                // 關閉按鈕
                resourceObj.closeBtn = {
                    position: cc.p(196, 224),
                    scale: 0.77,
                    bg: "gaple_btn_01_2.png",
                    icon: "#gaple_pic_x.png"
                };
                break;
            case GSEnum.Game.Texas:
            case GSEnum.Game.Texas19:
                // 背景底
                resourceObj.bg = {
                    pic: "lobby_bg_window.png",
                    preferredSize: cc.size(210, 208),
                    position: cc.p(106, 135)
                };

                // 黑底
                resourceObj.blackBg = {
                    pic: "game_bg_black_05.png"
                };

                // 左側選單按鈕
                resourceObj.tabButtons = ["#game_pic_talk.png", "#game_pic_emoticons.png"].map((cur, i) => {
                    return {
                        size: cc.size(26, 82),
                        position: cc.p(23, 87 + i * 85),
                        // 可點擊
                        normal: {
                            bg: {
                                pic: "game_bt_05_12.png",
                            },
                            icon: {
                                pic: cur,
                                position: cc.p(13, 41),
                                scale: 0.8
                            }
                        },
                        // 不可點擊
                        focused: {
                            bg: {
                                pic: "game_bt_05_3.png",
                                preferredSize: cc.size(26, 82),
                                opacity: 230
                            },
                            icon: {
                                position: cc.p(13, 41),
                                scale: 0.8
                            }
                        }
                    };
                });

                resourceObj.closeBtn = {
                    position: cc.p(200, 227),
                    bg: "lobby_btn_circle_04.png",
                    icon: "#lobby_btn_pic_window_x.png"
                };
                break;
            default:
                this._closeDialogAnimation();
                return;
        }

        // 放東西的node(順便對位)
        var mainNode = this._mainNode = new cc.Node();
        mainNode.setPosition(JSScreenSafeWidth, 0);
        aniLayer.addChild(mainNode);

        // 背景底
        var bgSprite = this._bgSprite = new ccui.Scale9Sprite(resourceObj.bg.pic);
        bgSprite.setPreferredSize(resourceObj.bg.preferredSize);
        bgSprite.setPosition(resourceObj.bg.position);
        mainNode.addChild(bgSprite, -1);

        // 黑底
        var blackBgSprite = new ccui.Scale9Sprite(resourceObj.blackBg.pic);
        blackBgSprite.setPreferredSize(cc.size(163, 172));
        blackBgSprite.setPosition(122, 130);
        mainNode.addChild(blackBgSprite, -1);

        this._tabButtons = resourceObj.tabButtons.map((cur, i) => {
            var tabButton = ButtonUtility.createSimpleImageButton(cur.normal.bg.pic, cur.size, cur.normal.icon.pic);

            // 按鈕本身
            cur.position && tabButton.setPosition(cur.position);

            // 按鈕背景
            cur.normal.bg.preferredSize && tabButton.bg.setPreferredSize(cur.normal.bg.preferredSize);
            cur.normal.bg.opacity && tabButton.bg.setOpacity(cur.normal.bg.opacity);

            // 按鈕圖示
            cur.normal.icon.opacity && tabButton.wordImage.setOpacity(cur.normal.icon.opacity);
            cur.normal.icon.scale && tabButton.wordImage.setScale(cur.normal.icon.scale);

            tabButton.addTouchUpInsideAction(this._tabButtonClicked, this);
            mainNode.addChild(tabButton);

            // Focused 背景
            var focusBgSprite = new ccui.Scale9Sprite(cur.focused.bg.pic);
            focusBgSprite.setPreferredSize(cur.focused.bg.preferredSize);

            // Focused 圖示
            var focusIconSprite = new cc.Sprite(cur.normal.icon.pic);
            focusIconSprite.setPosition(cur.focused.icon.position);
            cur.focused.icon.scale && focusIconSprite.setScale(cur.focused.icon.scale);

            focusBgSprite.addChild(focusIconSprite);
            tabButton.setBackgroundSpriteForState(focusBgSprite, cc.CONTROL_STATE_DISABLED);

            return tabButton;
        });

        // 關閉按鈕
        var closeBtn = ButtonUtility.createSimpleImageButton(resourceObj.closeBtn.bg, null, resourceObj.closeBtn.icon);
        closeBtn.setPosition(resourceObj.closeBtn.position);
        resourceObj.closeBtn.scale && closeBtn.setScale(resourceObj.closeBtn.scale);
        closeBtn.addTouchUpInsideAction(this._closeBtnClicked, this);
        mainNode.addChild(closeBtn);

        this._tabButtonClicked(this._tabButtons[1]);

        // 跳出畫面 這個要在前面 因為之後才會統一加主畫面 要對位
        this._startDialogAnimation();

        // 加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this.onTouchBegan.bind(this)
        }, this);

        // 註冊
        GS.addListener("NotifyCloseEmoticons", this.notifyCloseEmoticons.bind(this), this);
    },

    /**
     *
     * @param sender    頁籤目標
     * @param isClicked 是否為自己點的
     * @private
     */
    _tabButtonClicked: function (sender, isClicked) {
        var clickedPos = 0;

        this._tabButtons.forEach((cur, index) => {
            if (sender === cur) {
                // 記下點到哪個按鈕
                clickedPos = index;

                cur.setEnabled(false);
            } else {
                cur.setEnabled(true);
            }
        });

        // 埋點
        if (sender && isClicked && DataModal.profileData.isUseGorgeousTheme()) {
            switch (clickedPos) {
                case 0:
                    // 埋點：4893 在華麗牌桌點聊天頁籤
                    TexasUtility.sendUserAnalyticsTrack(4893);
                    break;
            }
        }

        // 關掉其他頁面
        var pageArray = this._pageArray;
        pageArray.forEach(cur => cur.setVisible(false));

        var page = pageArray[clickedPos];
        if (!page) {
            switch (clickedPos) {
                case 0:     // 聊天頁
                    page = pageArray[clickedPos] = new EmoticonsChatPageWordsLayer();
                    break;
                case 1:     // 互動道具
                    page = pageArray[clickedPos] = new EmoticonsChatPageEmoticonsLayer();
                    break;
            }
            this._mainNode.addChild(page);
        } else
            page.setVisible(true);
    },

    // 按到關閉
    _closeBtnClicked: function () {
        this._closeDialogAnimation();
        this._openAnimationDone = false;
    },

    /**
     * 通知
     */
    // 要關掉畫面
    notifyCloseEmoticons: function () {
        this._closeDialogAnimation();
    },

    /**
     * Touch
     */
    onTouchBegan: function (touch, event) {
        if (!this._openAnimationDone)
        // 畫面還沒打開完成不處理
            return;

        var target = event.getCurrentTarget();
        if (!target.isVisible())
            return false;
        for (var c = target.parent; c != null; c = c.parent) {
            if (!c.isVisible())
                return false;
        }

        var boundBox = this._bgSprite.getBoundingBox();
        var touchPos = this.convertToNodeSpace(touch.getLocation());

        if (!cc.rectContainsPoint(boundBox, touchPos)) {
            this._closeDialogAnimation();
            this._openAnimationDone = false;
            return false;
        }
        return true;
    }
});
