/**
 * 玩家黑名單 Data
 */
var BlacklistData = cc.Class.extend({
    ctor: function () {
        this._account = "";
        this._data = {};
        this._blacklist = [];

        // 註冊Event 後面node要改帶優先權(數字越小 優先權越高 不得為0)
        GS.addListener("NotifyLoadingDone", this.resetAllValue.bind(this), 1);
    },

    _saveData: function () {
        GS.localStorage.setItem(UserDefaultKey.Blacklist, JSON.stringify(this._data));
    },

    /**
     * 清除資料
     */
    resetAllValue: function () {

        // 抓存在手機端的資料
        var data = JSON.parse(GS.localStorage.getItem(UserDefaultKey.Blacklist, "{}"));
        this._account = DataModal.profileData.account;
        this._data = data;
        if (!data[this._account])
            data[this._account] = [];

        this._blacklist = data[this._account];
    },

    /**
     * 找該帳號有沒有被加到黑名單
     */
    isAccountInList: function (account) {
        return this._blacklist.indexOf(account.toString()) !== -1;
    },

    /**
     * 增加/移除 黑名單帳號
     * @param {String} account 玩家帳號
     * @return {Boolean} 是否被加入黑名單
     */
    changeBlacklistAccount: function (account) {
        var retVal = false;

        var target = account;
        var blacklist = this._blacklist;
        var accountIdx = this._blacklist.indexOf(account);
        if (accountIdx === -1) {
            // 不存在
            blacklist.push(target);
            retVal = true;
        } else {
            // 要移除
            blacklist.splice(accountIdx, 1);
        }

        this._saveData();

        // 通知刷新頭貼
        GS.dispatchCustomEvent("NotifyRefreshIsForbidden", account);

        return retVal;
    }
});