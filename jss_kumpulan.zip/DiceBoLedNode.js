/**
 * 骰寶的數字Led
 */
var DiceBoLedNode = cc.Node.extend({
    ctor: function () {
        this._super();

        this.setCascadeOpacityEnabled(true);

        this.nowMoney = 0;
        this._totalMoney = 0;
        this._updateTime = 0.3;         // 更新數字要多久

        // 背景
        var bgSprite = new ccui.Scale9Sprite("db_bg_money.png");
        bgSprite.setPreferredSize(cc.size(118, 24));
        this.addChild(bgSprite);

        // 數字 從右邊開始放到左邊 每3個後會有1個逗號
        this._ledNumberArray = [];
        this._ledDotArray = [];
        var posX = 50;
        for (var i = 0; i < 10; i++) {
            if (i % 3 == 0 && i != 0) {
                // 要加逗號
                var dotSprite = new cc.Sprite("#vegas_led10.png");
                dotSprite.setPosition(posX + 2.5, -6);
                dotSprite.setScale(0.9);
                this.addChild(dotSprite);

                this._ledDotArray.push(dotSprite);

                posX -= 5;
            }

            var ledSprite = new cc.Sprite("#vegas_led0.png");
            ledSprite.setPosition(posX, 0);
            ledSprite.setScale(0.8);
            this.addChild(ledSprite);

            this._ledNumberArray.push(ledSprite);

            posX -= 9.5;
        }

        // 免費文字
        var freeLabel = this._freeLabel = new cc.LabelTTF(LocalizedString.Vegas("Free"), JSFontBoldName, 12);
        freeLabel.setPosition(-36, 0);
        freeLabel.setFontFillColor(cc.color(230, 200, 20));
        freeLabel.setVisible(false);
        this.addChild(freeLabel);

        GS.addListener("NotifyDiceBoUpdateLED", this._notifyDiceBoUpdateLED.bind(this), this);
    },

    /**
     * 設定金錢 可以讓他有動畫
     * @param money
     * @param isAnimation 是否要有動畫
     */
    setMoney: function (money, isAnimation) {
        var len = arguments.length;
        if (len < 2)
            isAnimation = true;

        if (isAnimation) {
            this._totalMoney = money;
            this._floorNumber = this.nowMoney;
            this._usedTime = 0;

            if (this._floorNumber === this._totalMoney)
                return;

            this.unschedule(this._scheduleUpdateMoney);
            this.schedule(this._scheduleUpdateMoney);
        } else {
            this._totalMoney = money;
            this._floorNumber = this.nowMoney;
            this._scheduleUpdateMoney(999999)
        }
    },

    // 真正更新金錢的地方
    _updateMoney: function (money) {
        var moneyString = (money || "0").toString();
        var moneyStringLen = moneyString.length;
        for (var i = 0; i < 10; i++) {
            var ledSprite = this._ledNumberArray[i];
            var isVisible = i < moneyStringLen;

            // 超過的要把數字設看不到
            if (i % 3 == 0 && i != 0) {
                // 逗號
                var dotSprite = this._ledDotArray[(i / 3) - 1];
                dotSprite.setVisible(isVisible);
            }
            ledSprite.setVisible(isVisible);

            if (!isVisible)
                continue;

            var nowPos = moneyStringLen - i - 1;
            var nowMoneyChar = (nowPos < 0 ? "0" : moneyString[nowPos]);

            ledSprite.setSpriteFrame("vegas_led" + nowMoneyChar + ".png");
        }
    },

    //運算
    _scheduleUpdateMoney: function (dt) {
        this._usedTime += dt;
        if (this._usedTime < this._updateTime)
            this.nowMoney = Math.floor(this._floorNumber + (this._totalMoney - this._floorNumber) * (this._usedTime / this._updateTime));
        else {
            this.unschedule(this.scheduleUpdateLabel);
            this.nowMoney = this._totalMoney;
        }

        this._updateMoney(this.nowMoney);
    },

    /**
     * 設定是否使用免費券 畫面要修改
     * @param useFreeTicket 是否使用免費券
     */
    setUseFreeTicket: function (useFreeTicket) {
        var info = DataModal.vegasData.diceBoBetInfo;
        var freeBetMoney = (info) ? info.betArray[0] : 1000000;
        var freeBetMoneyLen = freeBetMoney.toString().length;
        for (var i = freeBetMoneyLen; i < 10; i++) {
            if (i % 3 == 0 && i != 0) {
                // 逗號
                var dotSprite = this._ledDotArray[(i / 3) - 1];
                dotSprite.setVisible(!useFreeTicket);
            }

            // 數字
            var ledSprite = this._ledNumberArray[i];
            ledSprite.setVisible(!useFreeTicket);
        }

        // 是否要出現免費文字
        this._freeLabel.setVisible(useFreeTicket);

        // 更新金額
        this.setMoney(freeBetMoney);
    },

    /**
     * 通知
     */
    // 更新金額
    _notifyDiceBoUpdateLED: function (event) {
        this.setMoney(event.getUserData());
    },
});