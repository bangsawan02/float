/**
 * 傳Type用 判斷是在一般遊戲裡還是機台中
 */
var AntennaType = {
    NORMAL_GAME: 0,         // 在一般遊戲中
    Vegas: 1,               // 在機台裡
    GAME_LEFT: 2,           // 天線在左上角的
    GAME_RIGHT: 3,          // 天線在右上角
    GAPLE_KO: 4,            // 天線在右上角下移
    MULTI_BJ: 5,            // 天線在左上角一些
    MULTI_DB: 6,            // 天線在左上角右移
    MULTI_HHH: 7,           // 同上
    GAME_RIGHT_DOWN: 8,     // 天線在右下角
    MULTI_DB_NEW: 9,        // 天線在左上角右移
};

var AntennaLayer = cc.Layer.extend({
    ctor: function (type) {
        this._super();

        this.setCascadeOpacityEnabled(true);

        this._type = type || AntennaType.NORMAL_GAME;
        this._infoLock = false;

        // 先抓出基本的位置
        var signalPosX, signalPosY, offsetX;
        switch (type) {
            case AntennaType.Vegas:
                signalPosX = JSVisibleSize.width - JSScreenSafeWidth - 84;
                signalPosY = 3;
                offsetX = 5;
                break;
            case AntennaType.GAME_LEFT:
            case AntennaType.MULTI_BJ:
                offsetX = 4;
                signalPosX = 74 + JSScreenSafeWidth;
                signalPosY = JSVisibleSize.height - 25;
                break;
            case AntennaType.GAPLE_KO:
                offsetX = 3.25;
                signalPosX = JSVisibleSize.width - JSScreenSafeWidth - 20;
                signalPosY = JSVisibleSize.height - 40;
                break;
            case AntennaType.MULTI_DB:
                offsetX = 4;
                signalPosX = 106 + JSScreenSafeWidth;
                signalPosY = JSVisibleSize.height - 25;
                break;
            case AntennaType.MULTI_DB_NEW:
                offsetX = 4;
                signalPosX = 91 + JSScreenSafeWidth;
                signalPosY = JSVisibleSize.height - 29;
                break;
            case AntennaType.MULTI_HHH:
                offsetX = 4;
                signalPosX = 104 + JSScreenSafeWidth;
                signalPosY = JSVisibleSize.height - 25;
                break;
            case AntennaType.GAME_RIGHT_DOWN:
                offsetX = 4;
                signalPosX = JSVisibleSize.width - JSScreenSafeWidth - 12;
                signalPosY = 3;
                break;
            default:
                offsetX = 3.25;
                signalPosX = JSVisibleSize.width - JSScreenSafeWidth - 20;
                signalPosY = JSVisibleSize.height - 15;
                break;
        }

        this._signals = [];
        for (var i = 0; i < 3; i++) {
            var signal = this._signals[i] = new cc.Sprite(JSStringUtility.format("#line_%02d.png", i + 1));
            signal.setAnchorPoint(0.5, 0);
            signal.setPosition(signalPosX + i * offsetX, signalPosY);
            this.addChild(signal);
        }

        // 每多少時間跑一次
        var action1 = cc.callFunc(this._updateSocketPingPong, this);
        var action2 = cc.delayTime(1.0);
        this.runAction(cc.repeatForever(cc.sequence(action1, action2)));

        // 先跑一次
        this._updateConnection(1);

        // 註冊Socket Lag
        GS.addListener("NotifySocketLag", this.notifySocketLag.bind(this), this);
    },

    // 更新Socket Ping Pong MS
    _updateSocketPingPong: function () {
        var ms = DataProcess.getPingPongMS();

        this._updateConnection(ms);
    },

    // 更新圖片
    _updateConnection: function (ms) {
        var colorArray;
        if (ms < 300) {
            // 全綠
            colorArray = [JSColor.GREEN, JSColor.GREEN, JSColor.GREEN];
        } else if (ms < 600) {
            // 二黃
            colorArray = [JSColor.YELLOW, JSColor.YELLOW, JSColor.GRAY];
        } else {
            // 剩一紅燈
            colorArray = [JSColor.RED, JSColor.GRAY, JSColor.GRAY];
        }

        for (var i = 0; i < 3; i++) {
            this._signals[i].setColor(colorArray[i]);
        }
    },
    
    /**
     * 通知
     */
    //通知SocketLag
    notifySocketLag: function () {
        this._updateConnection(1000);
    }
});