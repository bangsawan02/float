var ActionListTabButton = GSControlButton.extend({
    ctor: function (page, missionType) {
        var btnSize = this._btnSize = cc.size(71, 33);
        this._super(undefined, btnSize);

        this.page = page;
        this._missionType = missionType;
        this._changeColorWhenDisabled = false;

        var contentNode = this._contentNode;

        // 底
        var bgSprite = this._bgSprite = new ccui.Scale9Sprite("lobby_btn_tab_02.png");
        bgSprite.setPreferredSize(cc.size(btnSize.height, btnSize.width));
        bgSprite.setRotation(-90);
        contentNode.addChild(bgSprite);

        // Icon
        var iconName, titleName;
        switch (page) {
            case ActionListDialog.Page.MISSION_LOBBY:
            case ActionListDialog.Page.MISSION_GAME:
                // 大廳任務/桌內任務
                iconName = "#lobby_icon_lobbyMission.png";
                titleName = "每日任務(頁籤用)";
                break;
            case ActionListDialog.Page.ACTION_LIST:
                // 特殊任務
                iconName = "#lobby_icon_mission.png";
                titleName = "特殊任務";
                break;
            case ActionListDialog.Page.SCRATCH:
                // 刮刮卡
                iconName = "#lobby_icon_scratch.png";
                titleName = "刮刮卡";
                break;
            case ActionListDialog.Page.ACHIEVEMENT:
                // 簽到簿
                iconName = "#lobby_icon_achievement.png";
                titleName = "簽到簿";
                break;
            case ActionListDialog.Page.TARGET:
                // 成就
                iconName = "#lobby_icon_target.png";
                titleName = "成就";
                break;
            case ActionListDialog.Page.EVENT:
                // 活動
                iconName = "#lobby_icon_event.png";
                titleName = "活動";
                break;
            case ActionListDialog.Page.MISSION_LIMIT:
                // 成就
                iconName = "#lobby_icon_timeMission.png";
                titleName = "限時任務";
                break;
        }

        var iconNode = new cc.Sprite(iconName);
        iconNode.setPosition(-17, 0);
        contentNode.addChild(iconNode);

        // 文字 不能取名 _titleLabel 在H5上是ControlButton的東西
        var titleLabel = this._pageTitleLabel = new cc.LabelTTF(LocalizedString.FreeChip(titleName), JSFontBoldName, 9);
        titleLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        titleLabel.setPosition(13, 0);
        contentNode.addChild(titleLabel, 1);

        // 創小紅點
        var badge = this._badgeNode = new BadgeNode();
        badge.useDefaultStyle();
        badge.setPosition(-30, 11);
        contentNode.addChild(badge);

        // 監聽更新
        var eventNames;
        switch (page) {
            case ActionListDialog.Page.MISSION_GAME:
            case ActionListDialog.Page.MISSION_LOBBY:
                // 每日任務
                eventNames = ["NotifyUpdateDailyMission"];
                break;
            case ActionListDialog.Page.SCRATCH:
                // 刮刮卡
                eventNames = ["NotifyUpdateDailyScratch"];
                break;
            case ActionListDialog.Page.ACTION_LIST:
                eventNames = ["NotifyActionListDone"];
                break;
            case ActionListDialog.Page.MISSION_LIMIT:
                eventNames = ["NotifyTimeLimitTaskInfoDone"];
                break;
        }

        if (eventNames) {
            var updateFunc = this._updateBadge.bind(this);
            eventNames.forEach(eventName => GS.addListener(eventName, updateFunc, this))
        }

        // 先更新一次小紅點
        this._updateBadge();
    },

    /**
     * 不能按的時候 要改變顏色
     */
    setEnabled: function (enable) {
        this._super(enable);

        // 把背景圖片換掉
        var bgSprite = this._bgSprite;
        if (enable) {
            bgSprite.setSpriteFrame("lobby_btn_tab_02.png");
        } else {
            bgSprite.setSpriteFrame("lobby_btn_tab_01.png");
        }
        var btnSize = this._btnSize;
        bgSprite.setPreferredSize(cc.size(btnSize.height, btnSize.width));

        // 把文字設定顏色
        this._pageTitleLabel.setFontFillColor(enable ? JSColor.WHITE : JSColor.YELLOW);
    },

    /**
     * 更新小紅點
     */
    _updateBadge: function () {
        var badgeNode = this._badgeNode;
        switch (this.page) {
            case ActionListDialog.Page.MISSION_LOBBY:
                badgeNode.setVisible(DataModal.dailyMissionData.getHaveReward(DailyMissionEnum.whereType.Lobby, this._missionType));
                break;
            case ActionListDialog.Page.MISSION_GAME:
                // 每日任務
                badgeNode.setVisible(DataModal.dailyMissionData.getHaveReward(PushScene.isGame ? DailyMissionEnum.whereType.Game : DailyMissionEnum.whereType.Room, this._missionType));
                break;
            case ActionListDialog.Page.SCRATCH:
                // 刮刮卡
                badgeNode.setVisible(DataModal.scratchCardData.getHaveReward());
                break;
            case ActionListDialog.Page.ACTION_LIST:
                badgeNode.setVisible(DataModal.lobbyActionData.getHaveReward());
                break;
            case ActionListDialog.Page.MISSION_LIMIT:
                // 限時任務
                badgeNode.setVisible(DataModal.dailyMissionData.timeLimitInfo.canPickUp);
                break;
        }
    },

    getBadgeEnabled: function () {
        switch (this.page) {
            case ActionListDialog.Page.MISSION_LOBBY:
                return DataModal.dailyMissionData.getHaveReward(DailyMissionEnum.whereType.Lobby, this._missionType);
            case ActionListDialog.Page.MISSION_GAME:
                // 每日任務
                return DataModal.dailyMissionData.getHaveReward(PushScene.isGame ? DailyMissionEnum.whereType.Game : DailyMissionEnum.whereType.Room, this._missionType);
            case ActionListDialog.Page.SCRATCH:
                // 刮刮卡
                return DataModal.scratchCardData.getHaveReward();
            case ActionListDialog.Page.ACTION_LIST:
                return DataModal.lobbyActionData.getHaveReward();
            case ActionListDialog.Page.MISSION_LIMIT:
                // 限時任務
                return DataModal.dailyMissionData.timeLimitInfo.canPickUp;
            default:
                return false;
        }
    },

    /**
     * 判斷是否能看的到此按鈕
     */
    updateVisible: function () {
        var isVisible = true;
        switch (this.page) {
            case ActionListDialog.Page.MISSION_LOBBY:
            case ActionListDialog.Page.MISSION_GAME:
                // 每日任務會一直顯示
                break;
            case ActionListDialog.Page.SCRATCH:
                // 刮刮卡
                isVisible = DataModal.scratchCardData.scratchCardCount > 0;
                break;
            case ActionListDialog.Page.ACTION_LIST:
                // 特殊任務
                isVisible = PushScene.isLobby && DataModal.lobbyActionData.actionList.length > 1;
                break;
            case ActionListDialog.Page.MISSION_LIMIT:
                // 限時任務
                isVisible = DataModal.dailyMissionData.timeLimitInfo.isOpen;
                break;
        }

        this.setVisible(isVisible);
    }
});