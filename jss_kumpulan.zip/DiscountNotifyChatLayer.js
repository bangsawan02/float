/**
 * v5.4.7 聊天室優惠券 - 聊天室優惠券頁面
 * created by lichieh on 2023/1/4
 */
var DiscountNotifyChatLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        var width = ChatRoomLayer.WIDTH;

        // 聊天視窗大小
        var chatSize = cc.size(FriendChatLayer.WIDTH, 250 + JSScreenBonusHeight);

        // 標題
        var titleLabel = new GSAutoSizeLabel(LocalizedString.PurchaseCoupon("優惠通知"), JSFontBoldName, 12, cc.size(145, 40), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        titleLabel.setPosition(width / 2 + 17, 275 + JSScreenBonusHeight);
        titleLabel.resizeToFit(5);
        this.addChild(titleLabel);

        // 聊天視窗
        this._totalCellCount = 0;
        var tableView = this._tableView = new cc.TableView(this, cc.size(chatSize.width, chatSize.height));
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setPosition(7, 5);
        this.addChild(tableView);

        // 遊戲中不能聊天
        var tipLabel = this._tipLabel = new cc.LabelTTF(LocalizedString.PurchaseCoupon("目前沒有優惠"), JSFontName, 13);
        tipLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        tipLabel.setPosition(94, 133 + JSScreenBonusHeight);
        this.addChild(tipLabel);

        // Menu
        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        this.addChild(menu, 3);

        // 左上返回按鈕
        var backNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_pic_arrow.png");
        var backItem = new cc.MenuItemSprite(backNodes[0], backNodes[1], null, this._backItemClicked, this);
        backItem.setScaleX(1.3);
        backItem.setPosition(17, 275 + JSScreenBonusHeight);
        menu.addChild(backItem);

        // 加一條線
        var lineSprite = new cc.Sprite("#lobby_white_line.png");
        lineSprite.setScaleY(0.8);
        lineSprite.setPosition(32, 273 + JSScreenBonusHeight);
        this.addChild(lineSprite);

        // 刷新頁面
        this.refreshView();

        GS.addListener("NotifyChatRoomDiscountDone", this.notifyChatRoomDiscountDone.bind(this), this);
    },

    /**
     * 刷新聊天室
     */
    refreshView: function () {
        var discountList = DataModal.chatRoomData.discountList;

        // 優惠券最多顯示10個
        var count = 0;
        this._discountList = discountList.filter(cur => {
            var remainTime = JSCodeUtility.getRemainTime(cur.remainTime, cur.socketTime);
            if (count < 10 && remainTime > 0 && cur.id) {
                // 把日期清空
                cur.getDateString = undefined;
                count++;
                return cur;
            } else if (cur.fid && remainTime > 0) {
                // 把日期清空
                cur.getDateString = undefined;
                count++;
                return cur;
            }
        });

        // 排序獲得的時間(舊->新)
        this._discountList.sort((a, b) => a.getTime - b.getTime);

        // 處理同一天只顯示一次日期
        var lastDiscount;
        this._discountList.forEach(cur => {
            var getTimeDate = new Date(cur.getTime * 1000);
            cur.getTimeYear = getTimeDate.getFullYear();
            cur.getTimemonth = getTimeDate.getMonth() + 1;
            cur.getTimedate = getTimeDate.getDate();

            if (!lastDiscount) {
                // 第一筆資料直接顯示日期
                cur.getDateString = JSStringUtility.format("%02d/%02d", cur.getTimedate, cur.getTimemonth);
                lastDiscount = cur;
            } else {
                // 同一天只要顯示一次日期
                if (lastDiscount.getTimedate === cur.getTimedate && lastDiscount.getTimemonth === cur.getTimemonth
                    && lastDiscount.getTimeYear === cur.getTimeYear) {
                    return;
                }

                // 不同天獲得 要顯示日期(日/月)
                cur.getDateString = JSStringUtility.format("%02d/%02d", cur.getTimedate, cur.getTimemonth);
                lastDiscount = cur;
            }
        });

        // 訊息數量
        this._totalCellCount = this._discountList.length;

        this._tipLabel.setVisible(this._totalCellCount === 0);

        this._tableView.reloadData(true);

        // 滑到最下面 (超過畫面的時候再幫他滑到最新的)
        if (this._tableView.minContainerOffset().y <= 0)
            this._tableView.setContentOffset(this._tableView.maxContainerOffset());
    },

    /**
     * tableview
     */
    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();

        if (cell == null) {
            cell = new DiscountNotifyChatCell();
            cell.setAnchorPoint(0, 0);
        }
        cell.refreshCell(this._discountList[idx]);

        return cell;
    },

    numberOfCellsInTableView: function () {
        return this._totalCellCount;
    },

    tableCellSizeForIndex: function () {
        return cc.size(DiscountNotifyChatLayer.WIDTH, DiscountNotifyChatCell.HEIGHT);
    },

    /**
     * 返回按鈕點擊
     */
    _backItemClicked: function () {
        // 離開聊天畫面時回到清單確認清單的小紅點
        DataModal.chatRoomData.sendFriendChatRoomListCmd();

        var obj = {
            type: ChatRoomPageType.ROOM_LIST
        };
        GS.dispatchCustomEvent("NotifyShowChatRoomLayerByPageType", obj);
    },

    /**
     * 通知更新資料
     */
    notifyChatRoomDiscountDone: function () {
        this.refreshView();
    }
});

DiscountNotifyChatLayer.WIDTH = 173;
