/**
 * Cangkulan 遊戲主畫面
 */

var Cangkulan_GameLayer = cc.Layer.extend({
    Z_TAG_PROFILE_LAYER: 198300001,

    ctor: function () {
        this._super();

        this._isPlaying = false;                        // 是否正在玩
        this._enableProcessMessage = true;              // 是否可以執行cmd
        this._isReplaceingRoom = false;                 // 是否正在換房間(給stand & updateSeat用)
        this._isReplacedRoom = false;                   // 是否正在換房間(給toGame 顯示訊息用)
        this._showNeedPayDialog = false;                // 是否有出現破產的Dialog 這樣收到stand就不處理
        this._playingPlayers = [];                      // 遊戲現在有哪些活人需要發牌給他的
        this._backgroundListener = null;                // 到背景的監聽
        this._isFinishing = false;                      // 現在是否在結算中
        this._isHaveFoldSuit = false;                   // 該輪有沒有棄牌指定的花色
        this._playTime = new Date().getTime();          // Firebase 埋點, 記錄遊戲時間

        // 背景(含網速、Dealer)
        this._bgLayer = new Cangkulan_BackgroundLayer();
        this.addChild(this._bgLayer, -10000);

        // 指示燈
        this._spotLightLayer = new Cangkulan_SpotLightLayer();
        this.addChild(this._spotLightLayer);

        // 邀請玩家按鈕Layer
        this._sitsInviteLayer = new SitInviteNodesLayer();
        this.addChild(this._sitsInviteLayer, -1);

        // 玩家們
        this._playersLayer = new Cangkulan_PlayersLayer();
        this.addChild(this._playersLayer);

        // 牌
        this._cardsLayer = new Cangkulan_CardsLayer();
        this.addChild(this._cardsLayer);

        // 互動表情選擇人物畫面
        this._actMoodAimLayer = new ActMoodAimLayer();
        this.addChild(this._actMoodAimLayer);

        // 遊戲積分
        this._gameRankLayer = new Cangkulan_GameRankGameLayer();
        this.addChild(this._gameRankLayer);

        // 新增聚寶盆icon (5.4.2 跳提示泡泡框 要比玩家層級高)
        var treasureBowlIcon = new TreasureBowlGameIconNode();
        treasureBowlIcon.setScale(0.8);
        treasureBowlIcon.setPosition(JSVisibleSize.width - 25 - JSScreenSafeWidth, JSVisibleSize.height - 78);
        this.addChild(treasureBowlIcon);

        // 互動表情動畫
        this._actMoodAnimationLayer = new ActMoodAnimationLayer();
        this.addChild(this._actMoodAnimationLayer);

        // 對話的泡泡匡
        var gameChatMessageLayer = new GameChatMessageLayer();
        this.addChild(gameChatMessageLayer);

        // 遊戲介面
        this._uiLayer = new Cangkulan_UILayer();
        this.addChild(this._uiLayer);

        // 左上選單
        this._optionUILayer = new Cangkulan_UIOptionLayer();
        this.addChild(this._optionUILayer);

        // 遊戲中的提示
        this._gameHintLayer = new Cangkulan_GameHintLayer();
        this.addChild(this._gameHintLayer);

        // 聊天選單
        this._gameChatLayer = new GameChatLayer();
        this.addChild(this._gameChatLayer);

        // 自動代打
        this._autoPlayLayer = new Cangkulan_AutoPlayLayer();
        this._autoPlayLayer.setVisible(false);
        this.addChild(this._autoPlayLayer);

        // 比賽推廣提示
        var tournamentPromoteNode = this._tournamentPromoteNode = new TournamentPromoteGameNode();
        this.addChild(tournamentPromoteNode, 10);

        // 聊天浮動按鈕(icon在哪個畫面上)
        var friendChatNode = new ChatRoomIconLayer(ChatRoomIconLayer.POS_TYPE.CANGKULAN);
        this.addChild(friendChatNode);

        // 動畫 在最上方
        this._animationLayer = new Cangkulan_AnimationLayer();
        this.addChild(this._animationLayer);

        this._cleanGameLayerData(true);

        //註冊通知
        GS.addListener("NotifyGameProcessCMD", this.notifyGameProcessCMD.bind(this), this);
        GS.addListener("NotifyEnableProcessMessage", this.notifyEnableProcessMessage.bind(this), this);
        GS.addListener("NotifyGameUIChangePlaceClicked", this.notifyGameUIChangePlaceClicked.bind(this), this);
        GS.addListener("NotifyGameUIBackToLobbyClicked", this.notifyGameUIBackToLobbyClicked.bind(this), this);
        GS.addListener("NotifyStartGame", this.notifyStartGame.bind(this), this);
    },

    onEnter: function () {
        this._super();
        
        DataProcess.sendString("get_camp_mood_list");           // 抓special表情
        DataProcess.sendString("act_moods_backpack");           // 抓互動道具
        DataProcess.sendString("store_mood_backpack");          // 抓商城表情

        // 每日任務
        DataModal.dailyMissionData.startGetInfo(DailyMissionEnum.whereType.Game, GSEnum.Game.Cangkulan);

        // 確認是否有牌局重現指令
        this.checkmRC();
    },

    onExit: function () {
        // Firebase 埋點, 記錄遊戲時間
        GameFirebaseTracker.trackPlayingTime(this._playTime);

        this._backgroundListener && cc.eventManager.removeListener(this._backgroundListener);

        this._super();
    },

    /**
     * 確認是否有牌局重現指令
     */
    checkmRC: function () {
        var mRCString = DataModal.reappearData.mRCString;
        if (mRCString && mRCString.length) {
            // 送給GameData
            DataModal.gameData.processReconnectState("mRC_setState", mRCString);

            // 清掉
            DataModal.reappearData.mRCString = null;

            // 直接跑
            while (this.processMessage() && this._enableProcessMessage) {
            }
        } else {
            // 晚一下子 跑所有指令
            this._processAllCommand();
        }
    },

    /**
     * 跑所有指令
     */
    _processAllCommand: function () {
        var action1 = cc.delayTime(0.1);
        var action2 = cc.callFunc(function () {
            while (this.processMessage() && this._enableProcessMessage) {
            }
        }, this);
        this.runAction(cc.sequence(action1, action2));
    },

    /**
     * 清除GameLayer的資訊
     * @param isOnload 是否為初始資料階段
     * @private
     */
    _cleanGameLayerData: function (isOnload) {
        // 清掉其他畫面
        if (!isOnload) {
            this._bgLayer.cleanData();
            this._sitsInviteLayer.cleanData();
        }

        this._spotLightLayer.stop();

        this._showNeedPayDialog = false;                // 是否有出現破產的Dialog 這樣收到stand就不處理
    },

    /**
     * 檢查需要跳哪種沒錢的Dialog
     * @param canGoToSmallDesktop 是否能進小桌
     */
    _checkBrokePaymentDialog: function (canGoToSmallDesktop) {
        // 跳儲值
        NoMoneyDialogHelper.showGameDialog(canGoToSmallDesktop);

        // 把預約離桌跟預約換桌的關掉
        DataModal.gameData.leaveGameStatus = Cangkulan_LeaveGameStatus.CAN_LEAVE;
    },

    /**
     * 判斷現在是否要提示等待下一局的提示
     */
    _checkNeedShowPlayHint: function () {
        if (DataModal.gameData.myPos === -1) {
            // 清掉所有畫面 不理他
            this._gameHintLayer.closeWaitPlayerHint();
            this._gameHintLayer.closeNextRoundHint();

            return;
        }

        // 如果只有一位 就顯示等待其他玩家
        if (DataModal.gameData.getPlayerCount() === 1 && DataModal.gameData.leaveGameStatus === Cangkulan_LeaveGameStatus.CAN_LEAVE && !this._isFinishing) {
            this._gameHintLayer.showWaitPlayerHint();
            this._gameHintLayer.closeNextRoundHint();
        } else {
            // 關掉等待其他玩家提示
            this._gameHintLayer.closeWaitPlayerHint();

            // 判斷是否進去桌裡面等帶下一局開始 先觀戰
            var myPos = DataModal.gameData.myPos;
            if (myPos > -1 && this._playingPlayers.length && this._playingPlayers.indexOf(myPos) < 0 && !this._isFinishing) {
                // 在裡面 不過沒在玩 要出現
                this._gameHintLayer.showNextRoundHint();
                this._playersLayer.setPlayerToGray(myPos, true);
            } else {
                // 其他狀況不顯示
                this._gameHintLayer.closeNextRoundHint();
            }
        }
    },

    /**
     * 處理
     */
    // 處理GameData Message
    processMessage: function () {
        var haveMessage = false;
        var newMessageCommand = DataModal.gameData.popQueuedMessage();

        if (newMessageCommand) {
            haveMessage = true;

            var socketKey = newMessageCommand.key;
            var socketValue = newMessageCommand.value;

            // cc.log("processMessage:" + newMessageCommand.key);
            switch (socketKey) {
                case "gsOLEH":
                    // 收到一些設定
                    break;

                case "OLEH":
                    // 重置外觀
                    this._playersLayer.cmd_OLEH();
                    this._uiLayer.cmd_OLEH();
                    this._bgLayer.cmd_OLEH();
                    this._gameHintLayer.clean();
                    this._animationLayer.clean();
                    this._cardsLayer.clean();

                    this._isFinishing = false;

                    this._checkNeedShowPlayHint();

                    break;

                case "dealer":
                    // 決定現在誰是dealer
                    this._bgLayer.cmd_dealer(parseInt(newMessageCommand.value));
                    break;

                case "roomparam":
                    // 處理進入房間的資訊
                    if (this._isReplacedRoom) {
                        this._isReplacedRoom = false;
                        DialogManager.closeDialogByKey("ReplaceRoomDialog");
                        DialogManager.closeDialogByKey("InviteFriendListDialog");

                        // Reset
                        this._cleanGameLayerData(false);
                    }

                    // 更新背景的名稱
                    this._bgLayer.cmd_roomparam();

                    break;

                case "updateSeat":
                    this._cmd_updateSeat();
                    break;

                case "current_playing":
                    // 牌局重現
                    // current_playing 1 {"dealer":"0","phase":0,"firstCard":"66","playing":["0","1"],"leftCards":["66","56","36"],"rightCards":["66","56","36"],"handLength":['3','4','5','6']}
                    var array = newMessageCommand.value.split(" ");
                    var isCurrentPlaying = array[0] === "1";

                    // 如果牌局重現回來已經沒牌局 直接關閉牌局重現flag
                    if (!isCurrentPlaying) {
                        DataModal.gameData.isReconnect = false;
                        DataModal.gameData.isReappearIng = false;

                        this._isPlaying = false;
                        break;
                    }

                    // 牌局重現
                    if (isCurrentPlaying && array[1]) {
                        var jsonValue = JSON.parse(array[1]);
                        // 設定dealer
                        this._bgLayer.cmd_dealer(jsonValue["dealer"]);

                        // 打開棄牌的文字
                        this._bgLayer.showFoldWard(true);

                        // 設定場上的牌
                        this._cardsLayer.cmd_current_playing(jsonValue);

                        // 玩家的牌
                        this._playersLayer.cmd_current_playing(jsonValue);

                        this._uiLayer.cmd_current_playing(jsonValue);

                        // 有哪幾家在玩
                        this._playingPlayers = (jsonValue["playing"] || []).map(cur => parseInt(cur));

                        // 判斷是否輪到我
                        if (jsonValue.hasOwnProperty("nowPlayer")) {
                            var nowPlayer = JSCodeUtility.getIntValue(jsonValue["nowPlayer"]);
                            this._cardsLayer.setIsTurnMe(nowPlayer === DataModal.gameData.myPos);
                        }

                        // 計牌器
                        var countedCard = jsonValue["recordList"];
                        this._cardsLayer.cardCounterLayer.refreshCardCounterByDataArray(countedCard);

                        var status = JSCodeUtility.getIntValue(jsonValue["leaveState"]);
                        DataModal.gameData.leaveGameStatus = (status >= 0 && status <= 3) ? status : Cangkulan_LeaveGameStatus.CAN_LEAVE;

                        // 把表情打開
                        this._uiLayer.setEmoticonVisible(true);

                        this._isPlaying = true;
                    } else
                        this._isPlaying = false;
                    break;

                case "updateChips":
                    this._playersLayer.cmd_updateChips();
                    break;

                case "updateInfo":
                    // 更新配件資訊
                    this._playersLayer.cmd_updateInfo(newMessageCommand.value);
                    break;

                case "ServerReady":
                    var array = newMessageCommand.value.split(" ");

                    // 防呆 開始倒數的時候 把換桌視窗關掉
                    if (this._isReplacedRoom) {
                        this._isReplacedRoom = false;
                        DialogManager.closeDialogByKey("ReplaceRoomDialog");
                    }

                    // 準備要開始遊戲了
                    this._gameHintLayer.showGameReadyHint(parseInt(array[0]) || 3);

                    // 關閉比賽推廣
                    this._tournamentPromoteNode.closeGapleKOPromoteHint();

                    // 關掉等待其他玩家提示
                    this._gameHintLayer.closeWaitPlayerHint();
                    break;

                case "startGame":
                    // 開始遊戲
                    this._gameHintLayer.closeGameReadyHint();

                    // 關閉結算模式 顯示手牌抽牌區
                    this._cardsLayer.setFinishAnimationMode(false);

                    // 把表情打開
                    this._uiLayer.setEmoticonVisible(true);
                    break;

                case "Param":
                    // 發牌 Param [0,1] XXXXXXXXX
                    var array = newMessageCommand.value.split(" ");
                    var posArray = JSON.parse(array[0]);
                    var handCards = JSCodeUtility.getStringValue(array[1]).match(REGEXP_TWO_NUMBERS);

                    if (DataModal.gameData.isReappearIng) {
                        this._cardsLayer.startSendCardAsync(this._bgLayer.getDealerPosition(), posArray, handCards);
                    } else {
                        this._enableProcessMessage = false;
                        this._cardsLayer.startSendCardAsync(this._bgLayer.getDealerPosition(), posArray, handCards)
                            .then(() => {
                                // 打開背景的器牌文字
                                this._bgLayer.showFoldWard(true);

                                // 發牌完成
                                this._cardsLayer.cardCounterLayer.refreshCardCounterByDataArray(handCards);

                                // 抓完所有訊息
                                this.notifyEnableProcessMessage();
                            })
                            .catch(e => e && cc.error(e));
                    }

                    // AppsFlyer
                    if (GameAppsFlyerTracker.isNeedTrackFirstClick()) {
                        GameAppsFlyerTracker.startTime = new Date().getTime();
                    }

                    break;

                case "showPlayerClass":
                    // 積分系統 入桌階級顯示
                    //   {
                    //        "pos":"5",   #位置
                    //        "dealerSay":"Selamat datang Aries Mo para pemain hebat di meja profesional", #荷官恭迎
                    //        "userClass":{"score":"0","class":"0","ranking":"1"} #此玩家階級資料
                    //   }
                    var jsonValue = JSON.parse(socketValue);
                    var serverPos = JSCodeUtility.getIntValue(jsonValue["pos"]);
                    var isMe = DataModal.gameData.myPos === serverPos;

                    var classValue = jsonValue["userClass"];
                    if (classValue) {
                        // 如果是自己的話更新左下角積分系統
                        if (isMe && classValue["showProtecIcon"]) {
                            var userClass = {
                                isShowProtectIcon: JSCodeUtility.getIntValue(classValue["showProtecIcon"])
                            };
                            this._gameRankLayer.cmd_showPlayerClass(userClass);
                        }

                        if (classValue["class"]) {
                            // 給PlayersLayer做進來的動畫
                            this._playersLayer.cmd_showPlayerClass(jsonValue);
                        }
                    }

                    break;

                case "gameRank_protect_info":
                    // 用來跳桌內上方的保護令提示
                    this._gameHintLayer.cmd_gameRank_protect_info(socketValue);
                    break;

                case "gameRank_protect_remain":
                    // 更新個人的階級
                    this._gameRankLayer.cmd_gameRank_protect_remain(socketValue);
                    break;

                case "gameRank_update":
                    // 積分系統 自己的分數變動
                    this._gameRankLayer && this._gameRankLayer.cmd_gameRank_update(newMessageCommand.value);
                    break;

                case "gameRank_class":
                    // 拿個人積分資訊 要更新左下角Icon
                    var jsonValue = JSON.parse(newMessageCommand.value);
                    var param = {
                        class: JSCodeUtility.getIntValue(jsonValue["class"]),
                        score: JSCodeUtility.getIntValue(jsonValue["score"]),
                        nextScore: JSCodeUtility.getIntValue(jsonValue["nextClassScore"]),
                        ranking: JSCodeUtility.getIntValue(jsonValue["ranking"])
                    };
                    this._gameRankLayer.cmd_gameRank_class(param);
                    break;

                case "gameRank_booster_info":
                    // 積分系統 加速器的狀態
                    this._gameRankLayer && this._gameRankLayer.cmd_gameRank_booster_info(newMessageCommand.value);
                    break;

                case "koin_luxy_room_status":
                    // koinluxy更動
                    this._uiLayer.cmd_koin_luxy_room_status(newMessageCommand.value);
                    break;

                case "playing":
                    // 把現在遊戲中哪些活人記下來
                    this._playingPlayers = (JSON.parse(newMessageCommand.value) || []).map(cur => parseInt(cur));
                    this._playersLayer.setplayingPlayers(this._playingPlayers);
                    break;

                case "play":
                    // 輪到誰
                    this._cmd_play(newMessageCommand.value);
                    break;

                case "plmaxp":
                    // plmaxp X  X:此輪贏家pos  這輪結束 下輪的起始玩家
                    var valueArray = newMessageCommand.value.split(" ");
                    var winPos = JSCodeUtility.getIntValue(valueArray[0]);
                    this._enableProcessMessage = false;
                    this._isHaveFoldSuit = false;
                    // 清空出牌的花色
                    this._cardsLayer.setFoldSuit(null);
                    this._playersLayer.cmd_plmaxp(winPos);
                    break;

                case "cardListNum":
                    // 抽牌區剩餘的張數
                    var valueArray = newMessageCommand.value.split(" ");
                    var drawCount = JSCodeUtility.getIntValue(valueArray[0]);
                    this._cardsLayer.setDrawCount(drawCount);
                    break;

                case "action_btn":
                    // 決策按鈕顯示 action_btn 1/0 1/0 可否出牌 可否抽牌
                    var valueArray = socketValue.split(" ");
                    var array = valueArray.map(cur => JSCodeUtility.getIntValue(cur));
                    this._uiLayer.cmd_action_btn(array);
                    this._cardsLayer.cmd_action_btn(array);
                    break;

                case "draw":
                    // 自己抽到的牌 draw 29
                    this._enableProcessMessage = false;
                    var valueArray = socketValue.split(" ");
                    var drawCards = JSCodeUtility.getStringValue(valueArray[0]).match(REGEXP_TWO_NUMBERS);
                    var cardLayer = this._cardsLayer;
                    cardLayer.runDrawCardAnim(drawCards);

                    // 記牌器加上這些牌
                    drawCards.forEach(cur => {
                        cardLayer.cardCounterLayer.refreshCardCounterBySingleCard(cur, true);
                    });
                    break;

                case "pldraw":
                    // 抽牌 pldraw 0 1/2 5 1A 2A當前玩家pos 牌堆/棄牌區 數量 抽的牌(抽棄牌才有) 棄牌堆顯示的牌(抽棄牌才有 棄牌堆沒牌就不送)
                    this._enableProcessMessage = false;
                    var valueArray = newMessageCommand.value.split(" ");
                    var pos = JSCodeUtility.getIntValue(valueArray[0]);
                    var type = JSCodeUtility.getIntValue(valueArray[1]);
                    var count = JSCodeUtility.getIntValue(valueArray[2]);
                    var drawCard = JSCodeUtility.getStringValue(valueArray[3]);
                    var foldCard = JSCodeUtility.getStringValue(valueArray[4]);

                    // 停止倒數
                    this._playersLayer.playerStopCountDown();

                    // 設置抽到的牌
                    this._cardsLayer.setDrawPos(pos, type, count, drawCard, foldCard);

                    // 假如是從棄牌區抽牌的話 計牌器要把牌亮回來
                    if (type === Cangkulan_CardType.FOLD)
                        this._cardsLayer.cardCounterLayer.refreshCardCounterBySingleCard(drawCard, false);

                    // 自動代打 關閉抽牌按鈕
                    this._uiLayer.refreshDecisionBtn(Cangkulan_UILayer.DecisionStatus.NONE);

                    break;

                case "pldrop":
                    // 棄牌 pldrop 0 1A 當前玩家pos 棄掉的牌
                    this._enableProcessMessage = false;
                    var valueArray = newMessageCommand.value.split(" ");
                    var pos = JSCodeUtility.getIntValue(valueArray[0]);
                    var foldCard = JSCodeUtility.getStringValue(valueArray[1]);

                    // 停止倒數
                    this._playersLayer.playerStopCountDown();

                    // 設置棄牌
                    this._cardsLayer.runFoldCardAnim(pos, foldCard, this._isHaveFoldSuit);
                    this._cardsLayer.cardCounterLayer.refreshCardCounterBySingleCard(foldCard, true);

                    // 沒有花色 塞入該輪要棄牌的花色
                    this._isHaveFoldSuit = true;

                    // 自動代打 關閉棄牌按鈕
                    this._uiLayer.refreshDecisionBtn(Cangkulan_UILayer.DecisionStatus.NONE);

                    break;

                case "game_autoplay":
                    var array = newMessageCommand.value.split(" ");
                    var isAutoPlay = parseInt(array[0]) === 1;
                    if (isAutoPlay) {
                        this._autoPlayLayer.show();
                        // 進入自動玩 要把玩牌提示關掉
                        this._gameHintLayer.closeGameIntro();
                    } else
                        this._autoPlayLayer.close();
                    break;

                case "finish":
                    // 結算 結算狀態 贏家座位 [手牌] [分數] [錢]
                    // 結算 finish 1 ["1K2J3T24444232","1A2A3A1T2T4T4J","",""] ["-45","160","0","0"] ["-11500000","10350000","0","0"]
                    this._enableProcessMessage = false;
                    var array = newMessageCommand.value.split(" ");
                    var winDir = parseInt(array[0]);         // 贏家
                    var money = JSON.parse(array[3]);
                    var winChips = parseInt(money[winDir]);  // 贏多少錢
                    var loseArray = [];
                    JSON.parse(array[3]).forEach(function (cur, idx) {
                        if (cur < 0)
                            loseArray.push(idx);
                    });

                    // 清空棄牌花色
                    this._isHaveFoldSuit = false;

                    // 關掉指示燈
                    this._spotLightLayer.stop();

                    // 記下來現在正在結算
                    this._isFinishing = true;

                    // 打開結算模式 隱藏桌上的抽牌區棄牌區計牌器
                    this._cardsLayer.setFinishAnimationMode(true);
                    this._bgLayer.showFoldWard(false);

                    if (this._playingPlayers.indexOf(DataModal.gameData.myPos) > -1) {
                        // 更新聚寶盆 透過網址
                        DataModal.treasureBowlData.treasureBowlParam && DataModal.treasureBowlData.updateDataBy(1, false);

                        // 跳新玩家牌桌內功能提示
                        DataModal.newbieData.showGameTableFunctionHint();
                    }

                    // 開始結算動畫
                    Promise.resolve()
                        // 比牌動畫
                        .then(() => this._playersLayer.showFinishCardsAsync(array))
                        // 關手牌
                        .then(() => this._cardsLayer.setHandCardVisible(false))
                        // 結算動畫
                        .then(() => this._animationLayer.showFinalAsync(loseArray, winDir, winChips))
                        .then(() => {
                            this._isFinishing = false;
                        });

                    // AppsFlyer 玩家在牌局中贏牌就算1次(累加)
                    if (winDir === DataModal.gameData.myPos) {
                        GameAppsFlyerTracker.trackByGameName("win");
                    }

                    // 追蹤生涯玩x手
                    if (this._playingPlayers.indexOf(DataModal.gameData.myPos) > -1) {
                        GameAppsFlyerTracker.trackPlayingTimes();
                    }

                    // Firebase 追蹤
                    var eventName = GSAnalyticsAdapter.record.game + "Cangkulan牌桌玩法";
                    var eventKey = "桌列表";
                    var eventValue = "Cangkulan局數";
                    GSAnalyticsAdapter.logEventByFirebaseAll(eventName, [eventKey], [eventValue]);

                    break;

                case "toLobby":
                    // 離桌

                    // 可以離桌 只會有單純的 toLobby
                    if (!newMessageCommand.value) {
                        // 強制GameLayer不要收東西了
                        this._enableProcessMessage = false;

                        GSLoading.addLoadingView();
                    } else {

                        // 離桌失敗 toLobby 0
                        var value = JSCodeUtility.getIntValue(newMessageCommand.value);
                        // 失敗拿掉Loading
                        if (value === 0)
                            GSLoading.removeLoadingView();
                    }
                    break;

                case "update_getexp":
                    // 獲得多少EXP
                    this._playersLayer.cmd_update_getexp(newMessageCommand.value);
                    break;

                case "update_upgrade":
                    // 有沒有升級
                    this._playersLayer.cmd_update_upgrade(newMessageCommand.value);
                    break;

                case "update_gameRankUpdate":
                    // 積分更動
                    this._playersLayer.cmd_update_gameRankUpdate(newMessageCommand.value);
                    break;

                case "stopGame":
                    this._isPlaying = false;
                    this._isFinishing = false;
                    this._playersLayer.cmd_stopGame();
                    this._bgLayer.cleanData();
                    this._spotLightLayer.stop();

                    // 清掉東西
                    this._gameHintLayer.clean();
                    this._animationLayer.clean();
                    this._cardsLayer.clean();

                    // 關掉表情
                    this._uiLayer.setEmoticonVisible(false);

                    // 判斷是否要跳出等待下一局的提示
                    this._checkNeedShowPlayHint();

                    // 刮刮卡暫停
                    DataModal.scratchCardData.stopCountDown();
                    break;

                case "need_pay":
                    // need_pay pos 能不能進小桌
                    // 玩家破產了
                    // 這邊不用判段myPos了 因為GameData那邊判斷過了
                    this._showNeedPayDialog = true;

                    // 是否能進小桌
                    var array = newMessageCommand.value.split(" ");
                    var canGoToSmallDesktop = parseInt(array[1]) === 1;

                    // 檢查需要跳哪種沒錢的Dialog
                    this._checkBrokePaymentDialog(canGoToSmallDesktop);

                    // AppsFlyer 因破產而無法入桌或遭踢出牌局
                    GSAppsFlyerWrapper.logEvent("bankrupt_hint");

                    break;

                case "sitFail":
                    // 入座失敗
                    var jsonValue = JSON.parse(newMessageCommand.value);
                    var gameString = LocalizedString.Game;
                    var dialogObj = {
                        title: gameString("貼心提醒"),
                        buttons: [gameString("返回大廳")],
                        callback: function (index) {
                            // 回大廳
                            GS.dispatchCustomEvent("NotifyGameUIBackToLobbyClicked");
                        }
                    };

                    var code = JSCodeUtility.getIntValue(jsonValue["code"]);
                    if (code === 1) {
                        // 吃Server給的參數
                        dialogObj.content = decodeURIComponent(JSCodeUtility.getStringValue(jsonValue["msg"]));
                        DialogManager.addDialog(new AvatarDialog(dialogObj));
                    } else {
                        // code = 0 or 舊格式(沒有code), 不吃server參數, 直接顯示訊息
                        DialogManager.addDialog(new AvatarDialog(DialogHelper("GameNoMoney_SitFail")));
                    }
                    break;

                case "broken_reward":
                    // 玩家破產補幣
                    DialogManager.addDialog(new GameBrokenRewardDialog(newMessageCommand.value));

                    break;

                case "little_tips":
                    // 跳訊息Dialog
                    var param = {
                        key: "LittleTipDialog",
                        msg: newMessageCommand.value,
                        button: [LocalizedString.Common("確認")]
                    };
                    DialogManager.addDialog(new FrameDialog(param));
                    break;

                /**
                 * 表情
                 */
                case "mood":
                case "amood":
                    this._playersLayer.cmd_mood(newMessageCommand.value);
                    break;
                case "vmood":
                    this._playersLayer.cmd_vmood(newMessageCommand.value);
                    break;

                case "store_mood":
                    this._playersLayer.cmd_store_mood(newMessageCommand.value);
                    break;

                case "act_moods":
                    // 互動表情
                    this._actMoodAnimationLayer.cmd_act_moods(newMessageCommand.value);
                    break;

                case "gift_accessory":
                    // 送禮物
                    this._playersLayer.cmd_gift_accessory(newMessageCommand.value);
                    break;

                // 送禮包
                case "gift_package":
                    var array = newMessageCommand.value.split(" ");
                    this._actMoodAnimationLayer.cmd_gift_package(array);
                    break;

                // 提示
                case "show_intro":
                    this._enableProcessMessage = false;
                    this._gameHintLayer.showGameIntro(newMessageCommand.value);
                    break;

                /**
                 * 牌局重現
                 */
                case "mRC_setState":
                    var jsonValue = JSON.parse(newMessageCommand.value);

                    var gameData = DataModal.gameData;

                    // 把遊戲資料的Array先Copy一份 然後清掉
                    var oldCmdArray = gameData.cmdQueueArray.slice(0);
                    gameData.cmdQueueArray = [];

                    // 把音效關掉
                    MusicUtility.setReconnectStopEffect(true);

                    // 把牌局重現flag打開 有些東西不執行
                    gameData.isReappearIng = true;

                    // 把preinfo 遊戲一開始產生的資訊抓出來
                    var preinfo = jsonValue["preinfo"];

                    // 主CMD
                    var isParam = false;
                    var cmd = preinfo["cmd"];
                    var cmdLen = cmd ? cmd.length : 0;
                    var canProcess = cmdLen > 0;
                    for (var i = 0; i < cmdLen; i++) {
                        var cmdString = JSCodeUtility.getStringValue(cmd[i]);
                        DataProcess.sendCustomStringToSelf(cmdString);
                    }

                    // 快轉到現在的狀況
                    for (var i = 0; i < 10; i++) {
                        cc.director.getActionManager().update(100);
                        cc.director.getScheduler().update(100, false);
                    }

                    // 判斷是否要往下做
                    if (!canProcess) {
                        // 把音效打開
                        MusicUtility.setReconnectStopEffect(false);

                        // 失敗 要斷線踢掉
                        DataProcess.disconnect();

                        // 踢回登入頁面
                        cc.director.runScene(new LoginScene());

                        // 跳Alert
                        var commonString = LocalizedString.Common;
                        AlertDialog.showAlert(commonString("連線錯誤"), commonString("網路不穩,建議您確認連線是否正常。\n若仍在牌局中，馬上登入即可回到牌局。"));
                        break;
                    }

                    // 判斷是否要進結算畫面
                    var haveFinal = false;
                    var final = jsonValue["final"];
                    if (final) {
                        var cmd = final["cmd"];
                        var cmdLen = cmd ? cmd.length : 0;
                        haveFinal = cmdLen > 0;
                        // 結算的CMD
                        for (var i = 0; i < cmdLen; i++) {
                            var cmdString = JSCodeUtility.getStringValue(cmd[i]);
                            DataProcess.sendCustomStringToSelf(cmdString);
                        }
                    }

                    if (!haveFinal) {
                        // g0代表遊戲 沒大小結的
                        var g0 = jsonValue["g0"];
                        if (g0) {
                            var cmd = g0["cmd"];
                            var cmdLen = cmd ? cmd.length : 0;
                            for (var i = 0; i < cmdLen; i++) {
                                var cmdString = JSCodeUtility.getStringValue(cmd[i]);
                                DataProcess.sendCustomStringToSelf(cmdString);
                            }
                        }
                    } else {
                        // 要把手牌都清掉
                        this._cardsLayer.clean();
                        this._playersLayer.cleanAllHandCard();
                    }

                    // 再次快轉
                    for (var i = 0; i < 10; i++) {
                        cc.director.getActionManager().update(100);
                        cc.director.getScheduler().update(100, false);
                    }

                    // 把音效打開
                    MusicUtility.setReconnectStopEffect(false);

                    // 把GameData設之後setInfo不要理會 不然會錯亂
                    gameData.isReconnect = true;

                    // 把牌局重現關掉
                    gameData.isReappearIng = false;

                    // 把自動代打關掉
                    this._autoPlayLayer.close();
                    DataProcess.sendString("game_autoplay 0");

                    // 晚一下子通知時鐘斷線回來了 因為剛快轉過 整個會有問題
                    setTimeout(function () {
                        GS.dispatchCustomEvent("NotifyReconnectDone", countdown);
                    }, 1000);

                    // 最後在把cmd array塞回去
                    gameData.cmdQueueArray = gameData.cmdQueueArray.concat(oldCmdArray);

                    break;

                default:
                    this._enableProcessMessage = true;
                    this.processMessage();
                    break;
            }
        }
        return haveMessage;
    },

    /**
     * 更新位置資訊
     * @private
     */
    _cmd_updateSeat: function () {
        // 拿掉第一次進來的LoadingView
        if (this._isFirstComeToTheDestop) {
            GSLoading.removeLoadingView();
            this._isFirstComeToTheDestop = false;
        }

        // 更新是否有坐下的畫面
        var haveMe = DataModal.gameData.haveMe;
        this._playersLayer.updateSeat(haveMe);
        if (haveMe) {
            // 有我了 代表換完房間了
            this._isReplaceingRoom = false;
            this._sitsInviteLayer.update(true);
        } else {
            if (this._isReplaceingRoom) {
                this._sitsInviteLayer.setAllSitsVisible(false);
            } else {
                this._sitsInviteLayer.update(false);
            }
        }

        // 給互動道具選擇畫面更新
        this._actMoodAimLayer.cmd_updateSeat();

        // 去判斷要出現什麼提示
        this._checkNeedShowPlayHint();
    },

    /**
     * 輪到誰
     * play pos is_self
     */
    _cmd_play: function (value) {
        var valueArray = value.split(" ");
        var serverSitNum = JSCodeUtility.getIntValue(valueArray[0]);
        var isMeFlag = JSCodeUtility.getIntValue(valueArray[1]);
        var delay = JSCodeUtility.getIntValue(valueArray[2]);

        // 指引燈
        this._spotLightLayer.play(serverSitNum);

        // 倒數計時
        this._playersLayer.playerCountDown(serverSitNum, delay);

        // 設定手牌是不是輪到自己
        this._cardsLayer.setIsTurnMe(!!isMeFlag);

        // 輪到自己
        if (isMeFlag) {
            // 撥放音效
            this.runAction(cc.sequence(
                cc.delayTime(0.5),
                cc.callFunc(function () {
                    MusicUtility.playEffect("Music/Effect/e_youturn.mp3");
                })
            ));

            // 判斷是否要震動
            if (DataModal.settingData.cangkulan.vibrateWhenTurnSelf && cc.sys.isNative) {
                cc.Device.vibrate(0.2);
            }

            // 輪到自己要把Dialog關掉先
            DialogManager.cleanAllDialog();

            // 關掉聊天視窗
            GS.dispatchCustomEvent("NotifyCloseChatRoomLayer");
        }
    },

    /**
     * 通知 開始處理Socket CMD
     */
    notifyGameProcessCMD: function (event) {
        if (this._enableProcessMessage)
            this.processMessage();
    },

    /**
     * 開啟處理Socket CMD
     */
    notifyEnableProcessMessage: function (event) {
        this._enableProcessMessage = true;
        while (this.processMessage() && this._enableProcessMessage) {
        }
    },

    /**
     * 按"更換房間"按鈕
     */
    notifyGameUIChangePlaceClicked: function (event) {
        // Dialog提示
        var dialog = new SimpleDialog(LocalizedString.Game("更換牌桌中 請稍候..."));
        dialog.key = "ReplaceRoomDialog";
        DialogManager.addDialog(dialog);

        // 設定參數
        this._isReplaceingRoom = true;
        this._isReplacedRoom = true;

        var eventObject = event.getUserData();
        var isToSmallTable = false;
        if (eventObject) {
            isToSmallTable = eventObject.isToSmallTable;
        }

        // 送出 (統一送quickJoinP就好)
        if (isToSmallTable)
            DataProcess.sendString("quickJoinP");
        else
            DataProcess.sendString("quickJoinP " + DataModal.gameData.anteValue);

        // 刮刮卡暫停
        DataModal.scratchCardData.stopCountDown();
    },

    /**
     * 按下左上UI返回大廳按鈕回Lobby
     */
    notifyGameUIBackToLobbyClicked: function (event) {
        DataProcess.sendString("toLobby");

        // 加Loading檔掉
        GSLoading.addLoadingView();
    },

    // 收到開始遊戲的CMD
    notifyStartGame: function () {
        // 清空東西
        this._cleanGameLayerData(false);

        // 清掉畫面
        this._playersLayer.cleanData();

        // 重置外觀
        this._playersLayer.cmd_OLEH();
        this._uiLayer.cmd_OLEH();
        this._bgLayer.cmd_OLEH();
        this._gameHintLayer.clean();
        this._animationLayer.clean();
        this._cardsLayer.clean();
        this._optionUILayer.clean();

        this._isFinishing = false;

        // 清掉Dialog
        DialogManager.cleanAllDialog();

        // 設定可以讀取Socket
        this._enableProcessMessage = true;
    }
});