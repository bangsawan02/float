/**
 * 可自動調整大小的Label
 * stroke的大小"不會"因為變小而變小，所以字體縮小時描邊大小可能會跟字體不成比例
 * 支援自動換行(setLineBreak)，若沒有自動換行的需求，建議優先使用 GSAutoScaleSizeLabel
 */

var GSAutoSizeLabel = cc.LabelTTF.extend({
    ctor: function (label, fontName, fontSize, dimensions, hAlignment, vAlignment, isCutString) {
        dimensions = dimensions || cc.size(0, 0);

        // dimensions 不是零才 resize
        this._needResize = !(dimensions.width === 0 && dimensions.height === 0);

        this._originalDimensions = cc.size(dimensions.width, dimensions.height);
        this._originalFontSize = fontSize;
        this.minFontSize = 8;
        this.textSize = cc.size(0, 0);

        this._labelString = label;
        this._isCutString = isCutString;    // 是否要在縮小後還是超過寬度時裁切
        this._useDimensions2 = false;       // 是否使用第二種 setDimensions 的方法

        // 因為在Native直接把字串傳進去 會直接在C++裡面setString 就不會做到一些事情 改成先傳空字串下去 然後在手動setString
        this._super("", fontName, fontSize, dimensions, hAlignment, vAlignment);

        // 設定不要斷行
        this.setLineBreak(false);

        // 更新文字
        this.setString(label);
    },

    // Override
    setString: function (text) {
        cc.LabelTTF.prototype.setString.call(this, text);
        this._labelString = text;
        this.resizeToFit(this.minFontSize);
    },

    setDimensions: function (dim, height) {
        var width;
        if (height === undefined) {
            width = dim.width;
            height = dim.height;
        } else
            width = dim;

        var dimensions = this._originalDimensions = cc.size(width, height);

        // dimensions 不是零才 resize
        this._needResize = !(dimensions.width === 0 && dimensions.height === 0);

        cc.LabelTTF.prototype.setDimensions.call(this, width, height);

        this.resizeToFit(this.minFontSize);
    },

    // 第二種設定 dimensions 的方法，讓外部可以正常抓到目前的 ContentSize，並讓 對齊 跟 錨點 能正確的交互作用
    setDimensions2: function (dim, height) {
        var width;
        if (height === undefined) {
            width = dim.width;
            height = dim.height;
        } else
            width = dim;

        var dimensions = this._originalDimensions = cc.size(width, height);

        // dimensions 不是零才 resize
        this._needResize = !(dimensions.width === 0 && dimensions.height === 0);
        this._useDimensions2 = true;

        // 清掉原本的設定
        cc.LabelTTF.prototype.setDimensions.call(this, 0, 0);

        this.resizeToFit(this.minFontSize);
    },

    /**
     * 原本的 setFontSize 在 resizeToFit 會被呼叫
     * 導致外部call setFontSize 沒有作用
     * 拉出來給外部一個機會可以更改font大小
     * @param fontSize
     */
    setOriginalFontSize: function (fontSize) {
        this._originalFontSize = fontSize;
    },

    // 重新Resize
    resizeToFit: function (minSize) {
        this._useDimensions2 || cc.LabelTTF.prototype.setDimensions.call(this, 0, 0);
        this.setFontSize(this._originalFontSize);

        this.minFontSize = minSize;

        var textSize = this.getContentSize();
        if (this._needResize && textSize.width > this._originalDimensions.width) {
            // 多減一個 0.02，因為某些機子算出來必須還要再小一點(有些機子空格的 contentSize 會大於 fontSize)，不然 ContentSize > this._originalDimensions 會導致文字自動換行
            var newFontSize = Math.floor(this.getFontSize() * (this._originalDimensions.width / textSize.width)) - 0.02;
            if (newFontSize >= minSize) {
                // 算出來的Size還在範圍內
                this.setFontSize(newFontSize);
            } else {
                // 算出來的Size不能放 就直接用最小的Size
                this.setFontSize(minSize);

                // 如果有設定可以裁切，並且寬度有大於最大寬度，去切他 並且切掉的部分用 "..." 取代
                if (!this._useDimensions2 && this._isCutString) {
                    // 裁切後換字
                    var cutString = JSStringUtility.cutStringReplaceByEllipsis(this._labelString, minSize, this._originalDimensions.width);
                    cc.LabelTTF.prototype.setString.call(this, cutString);
                }
            }

            // 方法二的裁切：如果有設定可以裁切，並且寬度有大於最大寬度，去切他 並且切掉的部分用 "..." 取代 (抓實際 size 以避免這裡的計算誤差)
            if (this._useDimensions2 && this._isCutString && this.getContentSize().width > this._originalDimensions.width) {
                // 裁切後換字
                var cutString = JSStringUtility.cutStringReplaceByEllipsis(this._labelString, minSize, this._originalDimensions.width);
                cc.LabelTTF.prototype.setString.call(this, cutString);
            }

            this.textSize = cc.size(this._originalDimensions.width, this._originalDimensions.height);
        } else {
            this.textSize = cc.size(textSize.width, textSize.height);
        }

        this._useDimensions2 || cc.LabelTTF.prototype.setDimensions.call(this, this._originalDimensions);
    },
});