var DominoGameData = BaseGameData.extend({
    ctor: function () {
        this._super();

        //初始化
        this.players = null;                            // 設定PlayerLayer
        this.gameSerialID = "";                         // 場編
        this.gameRoomTypeName = "";                     // 遊戲房間Type
        this.gameRoomName = "";                         // 遊戲房間名稱
        this.gameType = 0;                              // 遊戲類型
        this.region = 0;                                // 遊戲的region
        this.playerNumber = 7;                          // 7人
        this.gameRoundTime = 10;                        // 輪到一個人的出手時間 休閒桌是10秒
        this.gameBringInTime = 30;                      // 一個人輸光時攜入的時間限制 休閒桌是30秒
        this.anteValue = 0;                             // 目前桌子的底注
        this.minBringIn = 0;                            // 目前桌子最小攜入
        this.maxBringIn = 0;                            // 目前桌子最大攜入
        this.defaultBringIn = 10000;                    // 目前桌子預設攜入
        this.haveMe = false;                            // updateSeat中有沒有我
        this.autoBringInMoney = 0;                      // 自動攜入金額 (0:沒有自動攜入   大於0:自動攜入金額)
        this.firstUpdateSeat = false;                   // 處於收到第二次updateSeat之前的狀態
        this.isTouchUI = false;                         // 玩家是否動過
        this.isTeachMode = false;                       // 是否是新手教學模式
        this.myPos = -1;                                // 自已的位置
        this.isMeBet = false;                           // 自己是否有下注
        this.isMeFold = false;                          // 自己是否棄牌
        this.isAutoBringInEachRound = false;            // 每局補足設定攜入
        this.isAutoBringInWhenZero = true;              // 籌碼爲0時，自動攜入

        this.playerDataArray = [];                      //Player Data Array
        this.serverSitNum = [];                         //設計一個可以從畫面位置，去找到server位置的Array變數，這樣找比較快
                                                        //ex.this.serverSitNum[0]=4；表示畫面上第0個位置在server上是第4個位置
        //初始化玩家資料
        for (var i = 0; i < this.playerNumber; i++) {
            this.playerDataArray[i] = new GamePlayerData();
            this.serverSitNum[i] = i;
        }

        //存入今天是否已登入過(以日來判斷)
        this.isFirstPlayToday = false;

        //註冊SocketKey
        var receiveSocketCMD = this._receiveSocketCMD;
        DataProcess.addSocketKeyDispatch(this, {
            // 開始遊戲的進入點 這幾個單獨處理
            "gsOLEH_extra": this.cmd_gsOLEH_extra,
            "gsOLEH_for_mobile": this.cmd_gsOLEH_for_mobile,
            "joinRoomAnte": this.cmd_joinRoomAnte,

            "gsOLEH": receiveSocketCMD,
            "OLEH": receiveSocketCMD,
            "myPos": receiveSocketCMD,
            "updateSeat": receiveSocketCMD,
            "last_cmd": receiveSocketCMD,
            "current_playing": receiveSocketCMD,
            "roomparam": receiveSocketCMD,
            "dealer": receiveSocketCMD,
            "updateChips": receiveSocketCMD,
            "updateInfo": receiveSocketCMD,

            // 站起坐下
            "stand": receiveSocketCMD,
            "alreadySit": receiveSocketCMD,
            "playerSit": receiveSocketCMD,

            //坐下錯誤
            "sitFail": receiveSocketCMD,

            // 玩遊戲的指令
            "ante": receiveSocketCMD,
            "playing": receiveSocketCMD,
            "FirstParam": receiveSocketCMD,
            "FirstParam3": receiveSocketCMD,
            "ThirdParam": receiveSocketCMD,
            "ForthParam": receiveSocketCMD,
            "BestCard": receiveSocketCMD,
            "play": receiveSocketCMD,
            "raiseList": receiveSocketCMD,
            "pot": receiveSocketCMD,
            "call": receiveSocketCMD,
            "plcall": receiveSocketCMD,
            "fold": receiveSocketCMD,
            "plfold": receiveSocketCMD,
            "check": receiveSocketCMD,
            "plcheck": receiveSocketCMD,
            "raise": receiveSocketCMD,
            "plraise": receiveSocketCMD,
            "waiting_confirm": receiveSocketCMD,
            "confirmed": receiveSocketCMD,

            // 積分系統
            "showPlayerClass": receiveSocketCMD,
            "gameRank_protect_info": receiveSocketCMD,
            "gameRank_protect_remain": receiveSocketCMD,
            "gameRank_class": receiveSocketCMD,
            "gameRank_update": receiveSocketCMD,
            "gameRank_booster_info": receiveSocketCMD,

            // koinLuxy資訊
            "koin_luxy_room_status": receiveSocketCMD,

            // 結算
            "finish1": receiveSocketCMD,
            "winCards": receiveSocketCMD,
            "allPool": receiveSocketCMD,
            "showdown": receiveSocketCMD,
            "noshowdown": receiveSocketCMD,
            "stopGame": receiveSocketCMD,
            "fianlMsg": receiveSocketCMD,
            "NextGame": receiveSocketCMD,

            // 結算後的升級之類的東西
            "update_level": receiveSocketCMD,
            "update_skillrate": receiveSocketCMD,
            "update_getexp": receiveSocketCMD,
            "update_upgrade": receiveSocketCMD,
            "update_gameRankUpdate": receiveSocketCMD,

            // 需要攜入籌碼的東西
            "need_chips": receiveSocketCMD,
            "auto_bring_in_msg": receiveSocketCMD,
            "auto_bring_inFail": receiveSocketCMD,

            // 破產
            "need_pay": receiveSocketCMD,
            "broken_reward": receiveSocketCMD,

            // 表情
            "mood": receiveSocketCMD,
            "vmood": receiveSocketCMD,
            "amood": receiveSocketCMD,
            "store_mood": receiveSocketCMD,

            // 互動表情
            "act_moods": receiveSocketCMD,

            // 送禮
            "gift_accessory": receiveSocketCMD,

            // 送禮包
            "gift_package": receiveSocketCMD,

            //送小費
            "sendTips": this.cmd_sendTips
        });
    },

    /**
     * 砍掉Data
     */
    destroyGameData: function () {
        this.cleanGameData();
        DataProcess.removeSocketKeyDispatch(this);
    },

    /**
     *  清掉遊戲中的資料
     */
    cleanGameData: function () {
        // 目前的SocketCMD清空
        this.clearSocketQueue();

        // 重設參數
        this.isMeBet = false;
        this.isMeFold = false;
        this.isAutoBringInEachRound = false;            // 每局補足設定攜入
        this.isAutoBringInWhenZero = true;              // 籌碼爲0時，自動攜入
        this.autoBringInMoney = 0;                      // 自動攜入金額 (0:沒有自動攜入   大於0:自動攜入金額)
    },

    /**
     * 重設所有玩家資料
     * @param {number} 玩家數量
     */
    resetPlayersData: function () {
        this.serverSitNum.length = 0;
        for (var i = 0; i < this.playerNumber; i++) {
            this.playerDataArray[i].resetGameData();
            this.serverSitNum[i] = i;
        }
    },

    /**
     * 注冊畫面上的Players,單純為了方便找位置，別做其它事
     * @param {layer}
     */
    registerPlayersLayer: function (players) {
        this.players = players;
    },

    /**
     * 用畫面上的位置取得Server玩家的位置
     * @param {index} 畫面上的位置, 自已是0，自已左邊是1，自已右邊8
     */
    getServerDirectionByDirection: function (index) {
        return this.serverSitNum[index];
    },

    /**
     * 找目前Server是做那一個畫面上的位置
     * @param {index} Server的位置
     */
    getDirectionByServerDirection: function (index) {
        return this.players[index] && this.players[index].sitNum;
    },

    /**
     * 取得自已的PlayerData
     */
    getMyPlayerData: function () {
        if (this.myPos != -1) {
            return this.playerDataArray[this.myPos];
        } else {
            return null;
        }
    },

    /**
     * 回傳目前的server的位置是不是自已
     * @param serverSitNum server的位置
     * @returns {Boolean} 是否為自已
     */
    getIsSelfByServerSitNum: function (serverSitNum) {
        return this.playerDataArray[serverSitNum] && this.playerDataArray[serverSitNum].getIsSelf();
    },

    /**
     * 檢查是否離開遊戲是否要Block
     * @returns {boolean}
     */
    checkLeaveGameNeedBlock: function () {
        //牌桌有我 && 有下注 && 沒棄牌 且超過一個人
        return this.haveMe && this.isMeBet && !this.isMeFold;
    },

    /**
     * 獨立處理的Socket
     */
    // 房間資訊 要在 gsOLEH_for_mobile 前噴回來
    cmd_gsOLEH_extra: function (key, value) {
        // 遊戲廳內新增額外資訊 [gsOLEH_extra {"region":"1","room_type_name":"普通局"}] 遊戲廳內新增額外資訊
        var param = JSON.parse(value);
        this.gameRoomTypeName = JSCodeUtility.getStringValue(param["room_type_name"]);
        this.gameRoomName = JSCodeUtility.getStringValue(param["room_name"]);
        this.anteValue = JSCodeUtility.getIntValue(param["fee"]);
        this.region = JSCodeUtility.getStringValue(param["region"]);
    },

    // 遊戲時間 遊戲類型 並取代toGame
    cmd_gsOLEH_for_mobile: function (key, value) {
        var valueArray = value.split(" ");
        if (valueArray.length >= 2) {
            this.gameRoundTime = JSCodeUtility.getIntValue(valueArray[0]);
            this.gameType = JSCodeUtility.getIntValue(valueArray[1]);
        }

        //重設所有玩家資料
        this.resetPlayersData();

        //清上一場cmdQueueArray && Other
        this.cleanGameData();

        //傳!EXTRA
        DataProcess.sendString("!EXTRA");

        //傳送是否自動攜入
        //var autoBring = parseInt(GS.localStorage.getItem("IsAutoBringIn") || 1);
        //DataProcess.sendString(JSStringUtility.format("auto_bring_in %d 0", autoBring));

        DataProcess.sendString("get_broke_payment_json");       // 抓遊戲破產儲值payment

        //通知進遊戲了
        GS.dispatchCustomEvent("NotifyStartGame");
    },

    cmd_joinRoomAnte: function (key, value) {
        // 進桌前先給我底注
        this.anteValue = JSCodeUtility.getIntValue(value);
    },

    /**
     * 送小費
     */
    cmd_sendTips: function (key, value) {
        GS.dispatchCustomEvent("NotifyGameSendTips", value);
    },

    /**
     * override掉 需要回傳是否要給UI處理 true or false
     */
    _processGameCommand: function (socketParam) {
        // 假如空的也代表停下來
        if (!socketParam)
            return true;

        var retValue = false;
        var value = socketParam.value;

        switch (socketParam.key) {
            /**
             * [OLEH H94429344908769]
             */
            case "OLEH":
                var valueArray = value.split(" ");
                if (valueArray.length >= 1) {
                    //場編
                    this.gameSerialID = valueArray[0];
                }

                //flag重設
                this.isMeBet = false;
                this.isMeFold = false;
                this.blindStatus = 0;

                // 給UI處理
                retValue = true;
                break;

            /**
             * [myPos -1] 玩家坐下某位置。-1有兩種情況 一種是剛進比賽 另外一種是站起來也會收到-1
             */
            case "myPos":
                var valueArray = value.split(" ");
                if (valueArray.length >= 1) {
                    this.myPos = JSCodeUtility.getIntValue(valueArray[0]);
                }

                // 給UI處理
                retValue = true;

                break;

            /**
             * roomparam 400 20000 20000 1000 設定房間資訊
             */
            case "roomparam":
                // ante min_bring_in max_bring_in seat_fee
                var valueArray = value.split(" ");
                if (valueArray.length >= 2) {
                    this.anteValue = JSCodeUtility.getIntValue(valueArray[0]);
                    this.minBringIn = JSCodeUtility.getIntValue(valueArray[1]);
                    this.maxBringIn = JSCodeUtility.getIntValue(valueArray[2]);
                }

                // 給UI處理
                retValue = true;

                break;

            /**
             * [updateSeat [{"userid":"","nick":"w52427714",,,,,etc},{},{},{},{},{},{},{},{}]]
             */
            case "updateSeat":
                var jsonParam = JSON.parse(value);
                var len = jsonParam.length;
                this.haveMe = false;
                for (var i = 0; i < len; i++) {
                    var param = jsonParam[i];
                    var playerData = this.playerDataArray[i];
                    if (!playerData)
                        continue;

                    if (param && !_.isEmpty(param)) {

                        //帳號
                        playerData.account = JSCodeUtility.getStringValue(param.userid);

                        try {
                            //匿稱
                            playerData.nickname = decodeURIComponent(JSCodeUtility.getStringValue(param.nick));

                            //稱號
                            playerData.titlename = decodeURIComponent(JSCodeUtility.getStringValue(param.title));
                        } catch (e) {
                            playerData.nickname = "";
                            playerData.titlename = "";
                        }

                        //大頭貼網址
                        playerData.photoURL = JSCodeUtility.getStringValue(param.pic);

                        //玩家框框類型
                        playerData.identity = JSCodeUtility.getStringValue(param.identity);

                        //玩家聊天框類型
                        playerData.chatBox = JSCodeUtility.getStringValue(param.chatBox);

                        //等級
                        playerData.level = JSCodeUtility.getIntValue(param.level);

                        //現在金錢
                        playerData.money = JSCodeUtility.getIntValue(param.tmoney);

                        //現在帶入桌子的籌碼
                        playerData.tableChips = JSCodeUtility.getIntValue(param.chips);

                        //配戴徽章編號、名稱
                        if (param.medal == "8101" || param.medal == "") {
                            playerData.medal.code = "";
                            playerData.medal.name = "";
                        } else {
                            playerData.medal.code = JSCodeUtility.getStringValue(param["medal"]);
                            playerData.medal.name = JSCodeUtility.getStringValue(param["name_medal"]);
                        }

                        //配戴物品編號、名稱
                        if (param.accessory == "1101" || param.accessory == "") {
                            playerData.accessory.code = "";
                            playerData.accessory.name = "";
                        } else {
                            playerData.accessory.code = JSCodeUtility.getStringValue(param["accessory"]);
                            playerData.accessory.name = JSCodeUtility.getStringValue(param["name_accessory"]);
                        }

                        // 男生、女生
                        playerData.isMale = JSCodeUtility.getStringValue(param.gender) === "m";

                        // 積分系統的階級 若是空的則是沒有階級
                        var userClass = param["userClass"];
                        playerData.userClass = userClass ? JSCodeUtility.getIntValue(param["userClass"]) : null;

                        if (playerData.getIsSelf()) {
                            this.haveMe = true;

                            //Update Profile data
                            var profileData = DataModal.profileData;
                            playerData.exp = profileData.exp;
                        }

                    } else {
                        playerData.resetGameData();
                    }
                }

                // 給UI處理
                retValue = true;

                break;

            case "getPlayerClass":
                // 遊戲內更新階級
                var jsonParam = JSON.parse(value);
                var userClass = jsonParam.userClass;
                if (userClass) {
                    for (var i = 0, len = userClass.length; i < len; i++) {
                        var playerData = this.playerDataArray[i];
                        playerData && (playerData.userClass = JSCodeUtility.getIntValue(userClass[i]));
                    }
                }

                // 給UI處理
                retValue = true;

                break;

            /**
             * stand pos 第pos位置站起來
             */
            case "stand":
                var serverSitNum = parseInt(value);
                var data = this.playerDataArray[serverSitNum];
                if (data && data.getIsSelf()) {
                    this.haveMe = false;

                    //flag重設
                    this.isMeBet = false;
                    this.isMeFold = false;
                }

                // 給UI處理
                retValue = true;

                break;

            case "need_pay":
                var array = value.split(" ");
                var needPayPos = parseInt(array[0] || -2);

                // 是自己破產再做
                retValue = this.myPos === needPayPos;

                break;

            /**
             * [last_cmd [["plcheck"],[],[],[],[],[],[],[],[]]]
             */
            case "last_cmd":
                var jsonParam = JSON.parse(value);
                for (var i = 0, len = jsonParam.length; i < len; i++) {
                    var playerData = this.playerDataArray[i];
                    if (playerData)
                        playerData.last_cmd = jsonParam[i];
                }

                // 給UI處理
                retValue = true;

                break;

            case "updateChips":
                var valueArray = JSON.parse(value);
                for (var i = 0, len = valueArray.length; i < len; i++) {
                    if (this.playerDataArray[i])
                        this.playerDataArray[i].tableChips = JSCodeUtility.getIntValue(valueArray[i]);
                }

                // 給UI處理
                retValue = true;
                break;

            case "update_getexp":
                // 更新牌王之路
                // 資格賽或是正式賽再更新
                if (DataModal.gamblerRoadData.type === GamblerRoadData.StatusType.QUALIFYING || DataModal.gamblerRoadData.type === GamblerRoadData.StatusType.RACING)
                    GS.dispatchCustomEvent("NotifyGameUpdateGamblerIcon");

                // 給UI處理
                retValue = true;
                break;

            case "NextGame":
                // 結算完了 要到下一場 把下注的flag清掉
                this.isMeBet = false;
                break;

            default:
                // 沒寫的統一給UI處理
                retValue = true;
                break;
        }

        return retValue;
    }
});
