/**
 *  ChatRoomIconLayer 好友聊天室icon
 *  @ type      icon在哪個畫面上
 */

var ChatRoomIconLayer = cc.Node.extend({
    ctor: function (type) {
        this._super();

        // 點擊初始的位置
        this._beganPos = cc.p(0, 0);

        // 是否點擊到icon
        this._isTouchIcon = false;

        // 預設浮動icon的初始位置
        var iconJson = {
            LOBBY: {vx: 0, vy: 26},
            TEXAS: {vx: 20, vy: 200},
            GAPLE: {vx: 20, vy: 200},
            GAPLEPLUS: {vx: 20, vy: 200},
            DOMINO: {vx: 20, vy: 200},
            REMI: {vx: 20, vy: 200},
            CANGKULAN: {vx: 20, vy: 200},
            CAPSASUSUN: {vx: 20, vy: 200}
        };

        // 取得之前位置的紀錄
        var iconPosJson = this._iconPosJson = JSON.parse(GS.localStorage.getItem("FriendChatIconNodePosition", JSON.stringify(iconJson)));

        var posType = ChatRoomIconLayer.POS_TYPE;
        // 禁止區塊跟位置
        var banSize = cc.size(0, 0);
        var banPos = cc.p(0, 0);
        // 存放上次icon的位置
        var posJson = {};

        // set 要禁止的區域大小跟位置 icon的位置
        switch (type) {
            case posType.LOBBY:
                banPos = cc.p(115, 47);
                banSize = cc.size(JSVisibleSize.width - 115 + JSScreenSafeWidth, 210 + JSScreenBonusHeight);
                posJson = this._posData = (iconPosJson.LOBBY) ? iconPosJson.LOBBY : iconJson.LOBBY;
                break;
            case posType.DOMINO:
                banPos = cc.p(163 + JSScreenBonusHalfWidth, 35 + JSScreenBonusHalfHeight);
                banSize = cc.size(185, 175);
                posJson = this._posData = (iconPosJson.DOMINO) ? iconPosJson.DOMINO : iconJson.DOMINO;
                break;
            case posType.GAPLE:
                banPos = cc.p(43 + JSScreenBonusHalfWidth, 0);
                banSize = cc.size(380, 240 + JSScreenBonusHeight);
                posJson = this._posData = (iconPosJson.GAPLE) ? iconPosJson.GAPLE : iconJson.GAPLE;
                this._isGameGaple = true;
                break;
            case posType.GAPLEPLUS:
                banPos = cc.p(43 + JSScreenBonusHalfWidth, 0);
                banSize = cc.size(380, 240 + JSScreenBonusHeight);
                posJson = this._posData = (iconPosJson.GAPLEPLUS) ? iconPosJson.GAPLEPLUS : iconJson.GAPLEPLUS;
                this._isGameGaple = true;
                break;
            case posType.TEXAS:
                banPos = cc.p(90 + JSScreenBonusHalfWidth, 18 + JSScreenBonusHalfHeight);
                banSize = cc.size(330, 203);
                posJson = this._posData = (iconPosJson.TEXAS) ? iconPosJson.TEXAS : iconJson.TEXAS;
                break;
            case posType.REMI:
                banPos = cc.p(43 + JSScreenBonusHalfWidth, 0);
                banSize = cc.size(380, 240 + JSScreenBonusHeight);
                posJson = this._posData = (iconPosJson.REMI) ? iconPosJson.REMI : iconJson.REMI;
                break;
            case posType.CANGKULAN:
                banPos = cc.p(43 + JSScreenBonusHalfWidth, 0);
                banSize = cc.size(380, 240 + JSScreenBonusHeight);
                posJson = this._posData = (iconPosJson.CANGKULAN) ? iconPosJson.CANGKULAN : iconJson.CANGKULAN;
                break;
            case posType.CAPSASUSUN:
                banPos = cc.p(43 + JSScreenBonusHalfWidth, 0);
                banSize = cc.size(380, 240 + JSScreenBonusHeight);
                posJson = this._posData = (iconPosJson.CAPSASUSUN) ? iconPosJson.CAPSASUSUN : iconJson.CAPSASUSUN;
                break;
        }

        // 浮動icon
        var iconNode = this._iconNode = new cc.Node();
        iconNode.setCascadeColorEnabled(true);
        iconNode.setPosition(posJson.vx, posJson.vy);
        this.addChild(iconNode);

        if (this._isGameGaple) {
            // 背景
            var bg = new cc.Sprite("#gaple_btn_02_1.png");
            iconNode.addChild(bg);

            // icon
            var icon = new cc.Sprite("#gaple_pic_chat.png");
            icon.setScale(0.85);
            iconNode.addChild(icon);
        } else {
            // 背景
            var bg = new cc.Sprite("#lobby_btn_circle_04.png");
            bg.setScale(1.1);
            iconNode.addChild(bg);

            // icon
            var icon = new cc.Sprite("#chat_btn_icon_talk.png");
            icon.setScale(0.75);
            iconNode.addChild(icon);
        }

        // 設定iconNode大小以及背景的位置
        var bgSize = bg.getBoundingBox();
        iconNode.setContentSize(bgSize.width, bgSize.height);
        bg.setPosition(bgSize.width / 2, bgSize.height / 2);
        icon.setPosition(bg.getPosition());

        // 浮動icon上的小紅點
        var redPoint = this._redPoint = new cc.Sprite("#lobby_prompt_bg.png");
        redPoint.setScale(0.5);
        redPoint.setPosition(bgSize.width - 7, bgSize.height - 7);
        redPoint.setVisible(false);
        this._iconNode.addChild(redPoint);

        // 禁止區域
        this._bannedRect = new cc.rect(banPos.x, banPos.y, banSize.width, banSize.height);

        // 一半的自己
        var iconHalf = this._iconHalf = bgSize.width / 2;

        // 螢幕的邊界 移動到邊界不能跑出去
        this._visibleX = JSVisibleSize.width - iconHalf;
        this._visibleY = JSVisibleSize.height - iconHalf;

        // 封鎖的位置(最小)
        this._minPos = cc.p(banPos.x, banPos.y);
        // 封鎖的位置(最大)
        this._maxPos = cc.pAdd(this._minPos, cc.p(banSize.width, banSize.height));

        // 加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this._onTouchBegan.bind(this),
            onTouchMoved: this._onTouchMoved.bind(this),
            onTouchEnded: this._onTouchEnd.bind(this),
            onTouchCancelled: this._onTouchCancelled.bind(this)
        }, this);

        // 確認有沒有小紅點
        DataModal.chatRoomData.sendFriendChatRoomListCmd(true);

        // 要歷史訊息
        DataModal.chatRoomData.getGuildChatHistory();

        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount)
            this.setVisible(false);

        // 註冊
        GS.addListener("NotifySetChatRoomVisible", this.notifySetChatRoomVisible.bind(this), this);
        GS.addListener("NotifyFriendChatRoomListDone", this.notifyUpdateChatIcon.bind(this), this);
        GS.addListener("NotifyGuildChatRoomDone", this.notifyUpdateChatIconRedPoint.bind(this), this);
        GS.addListener("NotifyUpdateChatRoomIcon", this.notifyUpdateChatIconRedPoint.bind(this), this);
        GS.addListener("NotifyChatRoomDiscountDone", this.notifyUpdateChatIconRedPoint.bind(this), this);
    },

    onExit: function () {
        // 把icon最後的位置存起來
        var pos = this._iconNode.getPosition();
        this._posData.vx = pos.x;
        this._posData.vy = pos.y;
        GS.localStorage.setItem("FriendChatIconNodePosition", JSON.stringify(this._iconPosJson));

        this._super();
    },

    /**
     * 更新畫面
     */
    _refreshView: function () {
        // 聊天頁面目前是打開的
        if (this._chatRoomLayer && this._chatRoomLayer.isVisible())
            return;

        // 設定看的到
        this._iconNode.setVisible(true);
        this.notifyUpdateChatIconRedPoint();
    },

    /**
     * 確認icon移動的範圍
     */
    _checkPos: function (pos) {
        // 點擊的位置 不超過螢幕的邊界
        var touchX = (pos.x > this._visibleX) ? this._visibleX : pos.x;
        touchX = (touchX < this._iconHalf) ? this._iconHalf : touchX;
        var touchY = (pos.y > this._visibleY) ? this._visibleY : pos.y;
        touchY = (touchY < this._iconHalf) ? this._iconHalf : touchY;

        // 判斷是否在封鎖範圍中
        if (cc.rectContainsPoint(this._bannedRect, pos)) {
            // 點下去的點到四個邊的距離
            var left = touchX - this._minPos.x;

            var right = (this._maxPos.x > this._visibleX)
                ? this._maxPos.x
                : this._maxPos.x - touchX;

            var top = (this._maxPos.y > this._visibleY)
                ? this._maxPos.y
                : this._maxPos.y - touchY;

            var bottom = (this._minPos.y < this._iconHalf)
                ? this._maxPos.y
                : touchY - this._minPos.y;

            // 找出最靠近的邊
            var minNum = Math.min(left, right, top, bottom);

            // 選擇吸附的邊
            var newPos = cc.p(touchX, touchY);
            switch (minNum) {
                case top:
                    // 吸在上面的邊界
                    newPos = cc.p(touchX, this._maxPos.y);
                    break;
                case bottom:
                    // 吸在下面的邊界
                    newPos = cc.p(touchX, this._minPos.y);
                    break;
                case left:
                    // 吸在左邊的邊界
                    newPos = cc.p(this._minPos.x, touchY);
                    break;
                case right:
                    // 吸在右邊的邊界
                    newPos = cc.p(this._maxPos.x, touchY);
                    break;
            }
            //(iconNode矛點在(0, 0) 最後塞位置要扣掉一半自己讓中心點跟著手點的地方)
            this._iconNode.setPosition(cc.pAdd(newPos, cc.p(-this._iconHalf, -this._iconHalf)));
        } else {
            // 塞入移動的位置 (iconNode矛點在(0, 0) 最後塞位置要扣掉一半自己讓中心點跟著手點的地方)
            this._iconNode.setPosition(touchX - this._iconHalf, touchY - this._iconHalf);
        }
    },

    /**
     * 是否為點擊的範圍內
     * @param touchPos 點擊位置
     * @returns {boolean}
     * @private
     */
    _getIsClicked: function (touchPos) {
        return Math.abs(touchPos.x - this._beganPos.x) < 5 && Math.abs(touchPos.y - this._beganPos.y) < 5
    },

    /**
     * Touch began
     */
    _onTouchBegan: function _onTouchBegan(touch) {
        if (this.__isDestroyed)
            return;

        var touchPos = this.convertToNodeSpace(touch.getLocation());

        if (cc.rectContainsPoint(this._iconNode.getBoundingBox(), touchPos)) {
            // 點到icon
            this._beganPos = touchPos;
            this._isTouchIcon = true;

            // 設定Icon顏色
            this._iconNode.setColor(JSColor.GRAY);

            return true;
        }
        return false;
    },

    /**
     * Touch move
     * 點擊到icon跟隨著移動
     */
    _onTouchMoved: function _onTouchMoved(touch) {
        if (!this._isTouchIcon)
            return;

        var touchPos = this.convertToNodeSpace(touch.getLocation());

        // 單純點擊事件不移動icon
        if (this._getIsClicked(touchPos))
            return;

        // 確認位置
        this._checkPos(touchPos);
    },

    /**
     * Touch end
     */
    _onTouchEnd: function _onTouchEnd(touch) {
        if (!this._isTouchIcon)
            return;

        var touchPos = this.convertToNodeSpace(touch.getLocation());

        // 單純點擊事件
        if (this._getIsClicked(touchPos)) {
            // 點到按鈕
            this._iconClicked();
        } else {
            // 確認位置
            this._checkPos(touchPos);
        }

        this._isTouchIcon = false;

        // 設定Icon顏色
        this._iconNode.setColor(JSColor.WHITE);
    },

    _onTouchCancelled: function _onTouchCancelled(touch, event) {
        this._onTouchEnd(touch, event);
    },

    /**
     * 按下按鈕打開聊天室
     */
    _iconClicked: function () {
        // 確認聊天室清單的資料
        DataModal.chatRoomData.sendFriendChatRoomListCmd();

        // 隱藏浮動icon
        this._iconNode.setVisible(false);

        // 開啟聊天室頁面
        if (this._chatRoomLayer) {
            this._chatRoomLayer.openChatRoom();
            if (this._chatRoomLayer.chatRoomType === ChatRoomPageType.GUILD) {
                DataModal.chatRoomData.guildChatRedPoint = false;
                GS.dispatchCustomEvent("NotifyGuildChatRoomDone");
            }
        } else {
            var from = ChatRoomFromType.LOBBY;
            var page = ChatRoomPageType.ROOM_LIST;
            var chatRoomLayer = this._chatRoomLayer = new ChatRoomLayer(from, page, this._isGameGaple);
            this.addChild(chatRoomLayer, 100);
        }

        if (PushScene.isGame && this._isGameGaple)
            GS.dispatchCustomEvent("NotifyCloseGameUIOptionMenu");
    },

    /**
     * 通知設定聊天室顯示
     */
    notifySetChatRoomVisible: function (event) {
        // 檔黑帳號
        if (DataModal.profileData.isBlackAccount) {
            this.setVisible(false);
            return;
        }

        if (event) {
            var isShow = event.getUserData();
            this.setVisible(isShow);
        }
    },

    /**
     * 通知獲得資訊了
     */
    notifyUpdateChatIcon: function () {
        this._refreshView();
    },

    /**
     * 通知刷新小紅點
     */
    notifyUpdateChatIconRedPoint: function () {
        if (!this._iconNode.isVisible())
            return;

        var data = DataModal.chatRoomData;

        // 小紅點是否打開
        if (PushScene.isLobby)
            // 在大廳時會判斷是否有優惠券
            var isShow = (data.friendChatIconRedPoint || data.guildChatRedPoint || data.getDiscountRedPoint());
        else
            var isShow = (data.friendChatIconRedPoint || data.guildChatRedPoint);

        this._redPoint.setVisible(isShow);
    }
});

// 紀錄浮動icon所在的位置
ChatRoomIconLayer.POS_TYPE = {
    LOBBY: 0,
    TEXAS: 1,
    GAPLE: 2,
    DOMINO: 3,
    REMI: 4,
    CANGKULAN: 5,
    GAPLEPLUS: 6,
    CAPSASUSUN: 7
};