/**
 * 訊息在方框中按鈕在方塊外面的Dialog
 * param = {
 *     key   : 這個Dialog的名稱
 *     bgSize: 背景尺寸 #不設置尺寸會跟的訊息大小調整背景尺寸
 *     msg   : 中間訊息
 *     button: 按鈕
 *     buttonSize: 按鈕尺寸
 *     cb    : 按鈕的cb
 * }
 */
var FrameDialog = BaseDialogLayer.extend({
    ctor: function (param) {
        this._super();

        this.key = param.key;

        this._cb = param.cb;

        var aniNode = this._animationNode;

        // 訊息
        var msgLabel = new cc.LabelTTF(param.msg, JSFontBoldName, 14);
        msgLabel.setPosition(JSScreenMidPos);
        msgLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        aniNode.addChild(msgLabel, 1);

        var contentSize = msgLabel.getContentSize();
        var bgWidth = (contentSize.width < 178) ? 178 : contentSize.width;
        var bgHeight = (contentSize.height < 70) ? 70 : contentSize.height;
        var bgSize = param.bgSize || cc.size(bgWidth + 20, bgHeight + 20);

        // 背景
        var bgSp = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSp.setPreferredSize(bgSize);
        bgSp.setPosition(JSScreenMidPos);
        aniNode.addChild(bgSp, -1);

        var mainMenu = new cc.Menu();
        mainMenu.setPosition(0, 0);
        aniNode.addChild(mainMenu);

        // 下方按鈕
        var btnSize = param.buttonSize || cc.size(76, 30);
        var btnLen = param.button.length;
        var btnRes = (btnLen === 1) ? "lobby_btn_01.png" : "lobby_btn_06.png";
        var btnImages = [btnRes, "lobby_btn_01.png"];
        var posX = (btnLen === 1) ? JSScreenMidPos.x : JSScreenMidPos.x - bgSize.width / 4;
        var posY = JSScreenMidPos.y - bgSize.height / 2 - 18;
        for (var i = 0; i < btnLen; i++) {
            var itemNodes = ButtonUtility.createSingleScale9Nodes(btnImages[i], btnSize, param.button[i], 13, JSColor.BLACK);
            var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._itemClicked, this);
            menuItem.setTag(i);
            menuItem.setPosition(posX + (bgSize.width / 2) * i, posY);
            mainMenu.addChild(menuItem);
        }
    },

    /**
     * 按鈕點擊
     */
    _itemClicked: function (sender) {
        if (this._cb)
            this._cb(sender);

        this._closeDialogAnimation();
    }
});