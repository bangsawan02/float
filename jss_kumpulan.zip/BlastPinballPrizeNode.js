/**
 * v5.7.0 激爆彈珠台獎勵 node
 * 
 * @param {BlastPinballData.RewardType} type 獎勵類型
 * @param {string?} rewardText 獎勵文字
 */
var BlastPinballPrizeNode = cc.Node.extend({
    ctor: function (type) {
        this._super();

        let type2NameMap = { 1: "R", 2: "B", 3: "Y", 4: "G" };

        // 獎項背景
        let bg = new ccui.Scale9Sprite("blastPinball_pic_panel-" + type2NameMap[type] + ".png");
        bg.setPreferredSize(cc.size(50, 22));
        this.addChild(bg);

        // 獎項文字圖
        let wordSprite = new cc.Sprite("#blastPinball_w_award-" + type2NameMap[type] + ".png");
        this.addChild(wordSprite);

        // 獎項數量背景圖
        let numBgSprite = new ccui.Scale9Sprite("blastPinball_pic_blank1.png");
        numBgSprite.setPreferredSize(cc.size(85, 22));
        numBgSprite.setPosition(70, 0);
        this.addChild(numBgSprite);

        GSSpine.create("spine/BlastPinball/ani_flipboard", 0.25, (spine) => {
            // 獎勵翻牌動畫
            this._flipSpine = spine;
            spine.setVisible(false);
            spine.setPosition(numBgSprite.getPosition());
            this.addChild(spine, 1);
        });

        GSSpine.create("spine/BlastPinball/ani_pinaballaward2", 0.25, (spine) => {
            // 獎項發光動畫
            this._rewardSpine = spine;
            spine.setVisible(false);
            this.addChild(spine, 2);
        });

        // 過度用獎金 文字
        let tempLabel = this._tempLabel = new cc.LabelTTF("--", JSFontName, 11);
        tempLabel.setAnchorPoint(0.5, 1);
        tempLabel.setVisible(false);
        tempLabel.setScaleY(0);
        tempLabel.setOpacity(0);
        this.addChild(tempLabel, 5);

        // 基本獎金 文字
        let baseLabel = this._baseLabel = new cc.LabelTTF("--", JSFontName, 11);
        baseLabel.setAnchorPoint(0.5, 0);
        this.addChild(baseLabel, 5);

        baseLabel.setPosition(numBgSprite.getPositionX(), -baseLabel.getContentSize().height / 2);
        tempLabel.setPosition(numBgSprite.getPositionX(), tempLabel.getContentSize().height / 2);
    },

    /**
     * 停止中獎動畫
     */
    stopRewardAnime: function () {
        this._rewardSpine.clearTracks();
        this._rewardSpine.setVisible(false);
    },

    /**
     * 中獎動畫
     */
    playWinningAnime: function () {
        this._rewardSpine.clearTracks();
        this._rewardSpine.setToSetupPose();
        this._rewardSpine.setVisible(true);
        this._rewardSpine.setAnimation(0, 'ani_01', true);
    },

    /**
     * 翻轉動畫
     * @param {string} newRewardText 新的獎勵文字
     */
    playFlippingAnime: function (newRewardText) {
        if (this._baseLabel.getString() !== newRewardText) {
            this._flipSpine.clearTracks();
            this._flipSpine.setToSetupPose();
            this._flipSpine.setVisible(true);
            this._flipSpine.setAnimation(0, 'ani_01', false);

            // 舊獎金動畫
            this._baseLabel.runAction(cc.sequence(
                cc.delayTime(0.04),
                cc.spawn(
                    cc.scaleTo(0.13, 1, 0),
                    cc.fadeOut(0.13)
                ),
                cc.delayTime(0.17),
                cc.callFunc(() => {
                    this._baseLabel.setString(newRewardText);
                    this._baseLabel.setScale(1);
                    this._baseLabel.setOpacity(255);
                }),
                cc.scaleTo(0.13, 1, 0.7),
                cc.scaleTo(0.23, 1)
            ));

            // 新獎金動畫
            this._tempLabel.setString(newRewardText);
            this._tempLabel.runAction(cc.sequence(
                cc.delayTime(0.14),
                cc.show(),
                cc.spawn(
                    cc.scaleTo(0.2, 1),
                    cc.fadeIn(0.2)
                ),
                cc.callFunc(() => {
                    this._tempLabel.setVisible(false);
                    this._tempLabel.setScaleY(0);
                    this._tempLabel.setOpacity(0);
                })
            ));
        }
    },
});