/**
 * Bonus機台 決策按鈕、牌桌左上方下注訊息、牌桌上時鐘node
 */
var BonusUINode = cc.Node.extend({
    ctor: function () {
        this._super();

        this._anteBet = 0;

        var bonusStr = LocalizedString.Bonus;

        // 左上下注限制區 Node
        var tableLimitNode = new cc.Node();
        tableLimitNode.setPosition(98 + JSScreenBonusHalfWidth, 265 + JSScreenBonusHalfHeight);
        this.addChild(tableLimitNode);

        // 左上下注限制區 背景
        var tableLimitSp = new cc.Sprite("#bonus_bet_table_limit.png");
        tableLimitNode.addChild(tableLimitSp);

        // 左上下注限制區 標題
        var titles = [
            {title: "下注限制", fontSize: 9, color: cc.color(111, 189, 255), pos: cc.p(0, 11)},
            {title: "最小", fontSize: 8, color: cc.color(141, 209, 255), pos: cc.p(-16, -2)},
            {title: "最大", fontSize: 8, color: cc.color(141, 209, 255), pos: cc.p(-16, -12)}
        ];
        titles.forEach(cur => {
            var label = new cc.LabelTTF(bonusStr(cur.title), JSFontBoldName, cur.fontSize);
            label.setFontFillColor(cur.color);
            label.setPosition(cur.pos);
            tableLimitNode.addChild(label);
        });

        // 左上下注限制區 金額
        this._tableLimitBetLabels = [
            cc.p(9, -2),
            cc.p(9, -12)
        ].map(cur => {
            var label = new cc.LabelTTF("", JSFontName, 8, cc.size(28, 10), cc.TEXT_ALIGNMENT_RIGHT, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
            label.setFontFillColor(cc.color(255, 214, 11));
            label.setPosition(cur);
            tableLimitNode.addChild(label);
            return label;
        });

        BonusUINode.BTN_SIZE = cc.size(JSVisibleSize.width * 0.49, 30);

        var pos = cc.p(JSScreenMidPos.x, 12.5);
        var btnImages = ["btn_square_up.png", "btn_square_down.png", "btn_square_up.png"];

        // 左下方過牌按鈕
        var nodes = ButtonUtility.createArrayScale9Nodes(btnImages, BonusUINode.BTN_SIZE, " ", 15);
        nodes[2].setOpacity(255);
        nodes[2].label.setOpacity(140);
        this._passMenuItem = new cc.MenuItemSprite(nodes[0], nodes[1], nodes[2], this._passBtnClicked, this);
        this._passMenuItem.setEnabled(false);

        // 右下方下注按鈕
        nodes = ButtonUtility.createArrayScale9Nodes(btnImages, BonusUINode.BTN_SIZE, bonusStr("下注"), 15);
        nodes[2].setOpacity(255);
        nodes[2].label.setOpacity(140);
        this._betMenuItem = new cc.MenuItemSprite(nodes[0], nodes[1], nodes[2], this._betBtnClicked, this);
        this._betMenuItem.setEnabled(false);

        var menu = new cc.Menu(this._passMenuItem, this._betMenuItem);
        menu.alignItemsHorizontallyWithPadding(3);
        menu.setPosition(pos);
        this.addChild(menu);

        // 下方Notify Bar
        var notifyNode = this._notifyNode = new cc.Node();
        notifyNode.setPosition(pos);
        notifyNode.setVisible(false);
        this.addChild(notifyNode);

        var bgSp = new ccui.Scale9Sprite("btn_square_up.png");
        bgSp.setPreferredSize(cc.size(JSVisibleSize.width * 0.98 + 3, 30));
        notifyNode.addChild(bgSp);

        var notifyLabel = this._notifyLabel = new cc.LabelTTF("", JSFontName, 15, cc.size(JSVisibleSize.width * 0.82, 30), cc.TEXT_ALIGNMENT_CENTER, cc.VERTICAL_TEXT_ALIGNMENT_CENTER);
        notifyNode.addChild(notifyLabel);

        // 下注區
        var bonusRaiseLayer = this._bonusRaiseLayer = new BonusRaiseLayer(this._betMenuItem);
        bonusRaiseLayer.setPosition(14 + JSScreenBonusHalfWidth, 10);
        bonusRaiseLayer.hide();
        this.addChild(bonusRaiseLayer);

        // 註冊通知
        GS.addListener("NotifyBonusClockExpire", this.notifyBonusClockExpire.bind(this), this);
        GS.addListener("NotifyBonusRaiseLayerHide", this.notifyBonusRaiseLayerHide.bind(this), this);
    },

    /**
     * 是否啟用加注按鈕
     * @param {Boolean} isEnabled
     */
    _enableBetBtn: function (isEnabled) {
        this._betMenuItem.setEnabled(isEnabled);
    },

    /**
     * 是否啟用過牌按鈕
     * @param {Boolean} isEnabled
     */
    enablePassBtn: function (isEnabled) {
        this._passMenuItem.setEnabled(isEnabled);
    },

    /**
     * 是否啟用決策按鈕
     * @param {Boolean} isEnabled
     */
    enableBet: function (isEnabled) {
        this.enablePassBtn(isEnabled);
        this._enableBetBtn(isEnabled);
    },

    /**
     * 打開下方的顯示文字
     */
    displayNotifyNode: function (text) {
        this._notifyNode.setVisible(true);
        this._notifyLabel.setString(text);
        this.enableBet(false);
    },

    /**
     * 顯示並設定下方的顯示文字
     * @param {Number} playerWin
     * @param type
     * @param cards
     */
    displayWinInfoWithNotifyNode: function (playerWin, type, cards) {
        this._notifyNode.setVisible(true);
        this.enableBet(false);

        var bonusStr = LocalizedString.Bonus;
        var winStr = "";

        if (playerWin === 0) {
            winStr = bonusStr("平手!");
        } else if (playerWin === 1) {
            winStr = DataModal.profileData.nickname + bonusStr(" 以") + BonusSetting.convertHandToText(type, cards, true);
        } else if (playerWin === -1) {
            winStr = bonusStr("莊家") + bonusStr(" 以") + BonusSetting.convertHandToText(type, cards, false);
        }

        this._notifyLabel.setString(winStr);
    },

    /**
     * 開始牌桌上的倒數時鐘
     * @param {Number} time 倒數時間
     */
    startClockCountdown: function (time, nowTime) {
        if (this._bonusClock) {
            this._bonusClock.clearTimer();
        } else {
            this._bonusClock = new BonusClockNode();
            this._bonusClock.setPosition(180 + JSScreenBonusHalfWidth, 265 + JSScreenBonusHalfHeight);
            this.addChild(this._bonusClock);
        }

        this._bonusClock.setTimer(time, nowTime);
        this._bonusClock.startCountdown();
    },

    /**
     * 停止牌桌上的時鐘倒數
     */
    stopClockCountdown: function () {
        this._bonusClock && this._bonusClock.clearTimer();
    },

    /**
     * 設定左上方最高/低注金額
     * @param {Number} lowestBet    最低注金額
     * @param {Number} highestBet    最高注金額
     */
    setBetText: function (lowestBet, highestBet) {
        this._tableLimitBetLabels[0].setString(this._convertMoneyStr(lowestBet));
        this._tableLimitBetLabels[1].setString(this._convertMoneyStr(highestBet));
        // 設定下注Layer區間
        this._bonusRaiseLayer.setPnNumber(highestBet, lowestBet);
    },

    setPnNumber: function (highestBet, lowestBet) {
        this._bonusRaiseLayer.setPnNumber(highestBet, lowestBet);
    },

    setAnteBet: function (anteBet) {
        this._anteBet = anteBet;
    },

    resetRaiseLayer: function () {
        this._bonusRaiseLayer.resetRaiseLayer();
    },

    /**
     * 打開/關閉 RaiseLayer
     * @param   {Boolean} isShow  打開/關閉RaiseLayer
     */
    _showRaiseLayer: function (isShow = false) {
        isShow ? this._bonusRaiseLayer.show() : this._bonusRaiseLayer.hide();
        this._isRaiseOpen = isShow;
    },

    /**
     * 通知隱藏RaiseLayer
     */
    notifyBonusRaiseLayerHide: function () {
        this._isRaiseOpen = false;
        this.changeBetBtnState(false);
    },

    notifyCanBet: function (state) {
        this._gameState = state;
        //  關閉下方的顯示文字
        this._notifyNode.setVisible(false);

        this._updateBtnStatus();

        // 震動
        if (cc.sys.isNative && DataModal.settingData.texas.vibrateWhenTurnSelf)
            cc.Device.vibrate(0.2);
    },

    /**
     * 更新決策按鈕文字
     */
    _updateBtnStatus: function () {
        var bonusStr = LocalizedString.Bonus;

        switch (this._gameState) {
            case BonusStateType.BET_ANTE:
                this._betMenuItem.setEnabled(true);
                this._changeMenuItemLabel(this._betMenuItem, bonusStr("下注"));
                this._passMenuItem.setEnabled(false);
                this._changeMenuItemLabel(this._passMenuItem);
                break;

            case BonusStateType.BET_BONUS:
                this._betMenuItem.setEnabled(true);
                this._changeMenuItemLabel(this._betMenuItem, bonusStr("下注BONUS"));
                this._passMenuItem.setEnabled(true);
                this._changeMenuItemLabel(this._passMenuItem, bonusStr("PASS"));
                break;

            case BonusStateType.FLOP_START:
                this._betMenuItem.setEnabled(true);
                var str = JSStringUtility.format("%s(%s)", bonusStr("下注"), JSCodeUtility.getCurrencyString(this._anteBet * 2));
                this._changeMenuItemLabel(this._betMenuItem, str);
                this._passMenuItem.setEnabled(true);
                this._changeMenuItemLabel(this._passMenuItem, bonusStr("棄牌"));
                break;

            case BonusStateType.TURN_START:
            case BonusStateType.RIVER_START:
                this._betMenuItem.setEnabled(true);
                var str = JSStringUtility.format("%s(%s)", bonusStr("下注"), JSCodeUtility.getCurrencyString(this._anteBet));
                this._changeMenuItemLabel(this._betMenuItem, str);
                this._passMenuItem.setEnabled(true);
                this._changeMenuItemLabel(this._passMenuItem, bonusStr("過牌"));
                break;

            default:
                break;
        }
    },

    /**
     * 下注按鈕Normal背景變換
     * @param {Boolean} isBet 是否為下注模式
     */
    changeBetBtnState: function (isBet = false) {
        isBet && this._updateBtnStatus();
        var normalSp = this._betMenuItem.getNormalImage();
        normalSp.bg && normalSp.bg.setSpriteFrame(isBet ? "btn_square_down.png" : "btn_square_up.png");
        normalSp.bg.setPreferredSize(BonusUINode.BTN_SIZE);
    },

    /**
     * 改變MenuItem內的label文字
     * @param {cc.MenuItem} menuItem    要被改變的menuItem
     * @param {String}      str         要改變的文字
     */
    _changeMenuItemLabel: function (menuItem, str = "") {
        if (menuItem) {
            menuItem.getChildren().forEach(cur => cur.label && cur.label.setString(str));
        }
    },

    /**
     * 轉換金額文字
     * @param {Number} value 金錢數字
     * @return {String} 轉換後的金額文字
     */
    _convertMoneyStr: function (value) {
        return TexasUtility.getSimpleMoneyString(value);
    },

    /**
     * 按鈕點擊事件
     */

    /**
     * 點擊左方過牌按鈕
     */
    _passBtnClicked: function () {
        switch (this._gameState) {
            case BonusStateType.BET_ANTE:
                // 在Ante的時候按下放棄遊戲
                DataProcess.sendString("bonus_flop 0");
                break;

            case BonusStateType.BET_BONUS:
                // 在Bonus的時候按下PASS, 直接跳到下一步
                this._isRaiseOpen && this._showRaiseLayer(false);

                DataProcess.sendString("bonus_bonus 0");
                break;

            case BonusStateType.FLOP_START:
                DataProcess.sendString("bonus_flop 0");
                break;

            case BonusStateType.TURN_START:
                DataProcess.sendString("bonus_turn 0");
                break;

            case BonusStateType.RIVER_START:
                DataProcess.sendString("bonus_river 0");
                break;

            default:
                break;
        }

        // 按了就把按鈕都關起來
        this.enableBet(false);
        GS.dispatchCustomEvent("NotifyStopCountdown");
    },

    /**
     * 點擊右方下注按鈕
     */
    _betBtnClicked: function () {
        switch (this._gameState) {
            case BonusStateType.BET_ANTE:
                // 如果raise沒打開的話就打開, 已經打開的話就下注
                if (!this._isRaiseOpen) {
                    this.changeBetBtnState(true);
                    this._showRaiseLayer(true);
                } else {
                    this.changeBetBtnState(false);
                    this._showRaiseLayer(false);

                    DataProcess.sendString(JSStringUtility.format("bonus_ante %d", this._bonusRaiseLayer.getBetMoney()));

                    // 存下遊戲紀錄
                    // this._savePlayerRecord();

                    // AppsFlyer埋點
                    GSAppsFlyerWrapper.logEvent("casino");

                    // Firebase 埋點
                    var eventName = GSAnalyticsAdapter.record.game + "娛樂城玩法";
                    GSAnalyticsAdapter.logEventByFirebaseAll(eventName, ["大廳"], ["texas holdem bonus下注"]);
                }
                break;

            case BonusStateType.BET_BONUS:
                // 	如果raise沒打開的話就打開, 已經打開的話就下注
                if (!this._isRaiseOpen) {
                    this.changeBetBtnState(true);
                    this._showRaiseLayer(true);
                } else {
                    this.changeBetBtnState(false);

                    this._showRaiseLayer(false);
                    DataProcess.sendString(JSStringUtility.format("bonus_bonus %d", this._bonusRaiseLayer.getBetMoney()));

                    GS.dispatchCustomEvent("NotifyStopCountdown");

                    // AppsFlyer埋點
                    GSAppsFlyerWrapper.logEvent("casino");
                }
                break;

            case BonusStateType.FLOP_START:
                // 移動籌碼並發牌
                DataProcess.sendString("bonus_flop 1");

                GS.dispatchCustomEvent("NotifyStopCountdown");

                // AppsFlyer埋點
                GSAppsFlyerWrapper.logEvent("casino");
                break;

            case BonusStateType.TURN_START:
                // 移動籌碼並發牌
                DataProcess.sendString("bonus_turn 1");

                GS.dispatchCustomEvent("NotifyStopCountdown");

                // AppsFlyer埋點
                GSAppsFlyerWrapper.logEvent("casino");
                break;

            case BonusStateType.RIVER_START:
                // 移動籌碼並發牌
                DataProcess.sendString("bonus_river 1");

                GS.dispatchCustomEvent("NotifyStopCountdown");

                // AppsFlyer埋點
                GSAppsFlyerWrapper.logEvent("casino");
                break;

            default:
                break;
        }
    },

    /**
     * 通知事件
     */

    /**
     * 通知倒數時間到，自動幫他點擊過牌
     */
    notifyBonusClockExpire: function () {
        this._passBtnClicked(null);
    },

    clean: function () {
        this._bonusClock.clearTimer();
        this._anteBet = 0;
        this.displayNotifyNode(LocalizedString.Bonus("等待下局開始"));
    }
});