/**
 * 5.5.9 移植中撲 連續儲值 - 主dialog
 * created by kai.wu
 */

var ContinueRechargeDialog = BaseDialogLayer.extend({
    ctor: function () {
        this._super();

        this.key = "ContinueRechargeDialog";

        // 拿來裝當前以及後續獎勵node的array
        this._rewardNodeArray = [];

        // 讀取
        this.loadFileArray = [
            "continueRecharge/continueRecharge.plist",
            "continueRecharge/continueRecharge.png",
        ];

        TestMenu.delegate(this);
    },

    onEnter: function () {
        this._super();

        // 埋點：進入頁面
        let param = {type: "2"};
        DataProcess.sendString("track_continue_recharge " + JSON.stringify(param));
    },

    onExit: function () {
        this._loadFileDone && cc.spriteFrameCache.removeSpriteFramesFromFile(this.loadFileArray[0]);

        // this.notifyIsStayLobbyMain 上鎖
        DialogManager.resumeShowDialog();

        // 如果可以領獎的話把小紅點打開
        if (this._rewardNodeArray[0] && this._rewardNodeArray[0].price === 0) {
            GS.dispatchCustomEvent("NotifyContinueRechargeShowRedPoint");
        }

        this._super();
    },

    loadFileDone: function () {
        this._super();

        cc.spriteFrameCache.addSpriteFrames(this.loadFileArray[0], this.loadFileArray[1]);

        let animationLayer = this._animationLayer;

        // 背景 + 棚子 node：用於一次調整整體之位置
        let boothNode = new cc.Node();
        boothNode.setPosition(JSScreenMidPos.x - 1, 0);

        // 背景木板：左右對稱（i = 0 ~ 1 右至左，j = 0 ~ 4 下至上）
        for (let i = 0; i < 2; i++) {
            for (let j = 0; j < 10; j++) {
                let bgSprite = new cc.Sprite("#continue_recharge_bg.png");
                bgSprite.setAnchorPoint(i, 0);
                bgSprite.setFlippedX(!i);
                bgSprite.setPosition(i - 0.5, 51.8 * j - 10);
                boothNode.addChild(bgSprite);
            }
        }

        // 背景下方壓暗
        let bgDarkenSprite = new ccui.Scale9Sprite("continue_recharge_bg_shadow.png");
        bgDarkenSprite.setPosition(0, -10);
        bgDarkenSprite.setAnchorPoint(0.5, 0);
        bgDarkenSprite.setPreferredSize(cc.size(512, 40));
        boothNode.addChild(bgDarkenSprite);

        // 棚子：左右對稱
        for (let i = 0; i < 2; i++) {
            let awningSprite = new cc.Sprite("#continue_recharge_pic_awning.png");
            awningSprite.setAnchorPoint(i, 1);
            awningSprite.setFlippedX(!i);
            awningSprite.setPosition(i - 0.5, JSVisibleSize.height);
            boothNode.addChild(awningSprite);
        }
        animationLayer.addChild(boothNode);

        // 標題
        let titleSprite = new cc.Sprite("#continue_recharge_w_logo.png");
        titleSprite.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 119);
        animationLayer.addChild(titleSprite);

        // 關閉按鈕
        var closeButton = new Texas_CloseButton();
        closeButton.addTouchUpInsideAction(this._closeDialogAnimation, this);
        closeButton.setPosition(JSScreenMidPos.x + 240, JSScreenMidPos.y + 124);
        animationLayer.addChild(closeButton, 11);

        // 獎勵的位置 index 0 為目前獎勵其餘是後續獎勵 (之後拿來做獎勵位移動畫)
        this._rewardPosArray = [
            cc.p(JSScreenMidPos.x + 175, JSScreenMidPos.y - 26),
            cc.p(JSScreenMidPos.x + 47, JSScreenMidPos.y + 5),
            cc.p(JSScreenMidPos.x + 47, JSScreenMidPos.y - 88),
            cc.p(JSScreenMidPos.x - 70, JSScreenMidPos.y - 88),
            cc.p(JSScreenMidPos.x - 70, JSScreenMidPos.y + 5),
            cc.p(JSScreenMidPos.x - 189, JSScreenMidPos.y + 5),
            cc.p(JSScreenMidPos.x - 189, JSScreenMidPos.y - 88)
        ];

        // 箭頭的位置, 箭頭位移的位置, 旋轉的角度
        this._arrowArray = [
            {
                arrowPos: cc.p(JSScreenMidPos.x + 106, JSScreenMidPos.y + 8),
                arrowAniPos: cc.p(JSScreenMidPos.x + 107, JSScreenMidPos.y + 8),
                rotation: 90
            },
            {
                arrowPos: cc.p(JSScreenMidPos.x + 47, JSScreenMidPos.y - 37),
                arrowAniPos: cc.p(JSScreenMidPos.x + 47, JSScreenMidPos.y - 36),
                rotation: 0
            },
            {
                arrowPos: cc.p(JSScreenMidPos.x - 11, JSScreenMidPos.y - 80),
                arrowAniPos: cc.p(JSScreenMidPos.x - 10, JSScreenMidPos.y - 80),
                rotation: 90
            },
            {
                arrowPos: cc.p(JSScreenMidPos.x - 70, JSScreenMidPos.y - 37),
                arrowAniPos: cc.p(JSScreenMidPos.x - 70, JSScreenMidPos.y - 38),
                rotation: 180
            },
            {
                arrowPos: cc.p(JSScreenMidPos.x - 129, JSScreenMidPos.y + 8),
                arrowAniPos: cc.p(JSScreenMidPos.x - 128, JSScreenMidPos.y + 8),
                rotation: 90
            },
            {
                arrowPos: cc.p(JSScreenMidPos.x - 188, JSScreenMidPos.y - 37),
                arrowAniPos: cc.p(JSScreenMidPos.x - 188, JSScreenMidPos.y - 36),
                rotation: 0
            },
        ];

        // 桌子
        let tableSprite = new cc.Sprite("#continue_recharge_bg_stage.png");
        tableSprite.setAnchorPoint(0.5, 0);
        tableSprite.setPosition(JSScreenMidPos.x + 176, JSScreenMidPos.y - 143);
        // 桌子、錘子、獎勵層級很高是因為希望有教學模式時可以出現在教學之上
        animationLayer.addChild(tableSprite, 12);

        // 目前獎勵的購買按鈕
        var purchaseButton = this._purchaseButton = ButtonUtility.createSimpleButton("lobby_btn_15.png", cc.size(95, 31.25), "-", JSColor.WHITE, 12);
        purchaseButton.setPosition(JSScreenMidPos.x + 176, JSScreenMidPos.y - 64);
        purchaseButton.setAnchorPoint(0.5, 0);
        purchaseButton.setChangeColorWhenDisabled(false);
        purchaseButton.setVisible(false);
        purchaseButton.addTouchUpInsideAction(this._purchaseClicked, this);
        purchaseButton.label.enableStroke(JSColor.OUTLINE_GREEN, 2);
        animationLayer.addChild(purchaseButton, 14);

        // 是否需要跑強調動畫
        purchaseButton.needToAddEmphaticAnime = false;
        // 有沒有正在跑強調動畫
        purchaseButton.isEmphaticAnimeRunning = false;

        // 購買按鈕下方文字
        let purchaseLabel = this._purchaseLabel = new cc.LabelTTF(LocalizedString.ContinueRecharge("限儲值中心"), JSFontName, 9);
        purchaseLabel.setPosition(JSScreenMidPos.x + 176, JSScreenMidPos.y - 68);
        purchaseLabel.setVisible(false);
        animationLayer.addChild(purchaseLabel, 14);

        // 錘子 node 用於後續動畫呼叫
        let hammerNode = this._hammerNode = new cc.Node();
        hammerNode.setPosition(JSScreenMidPos.x + 241, JSScreenMidPos.y - 99);
        hammerNode.setRotation(-37);
        animationLayer.addChild(hammerNode, 14);

        // 錘子後方的光
        var hammerLightSprite = new cc.Sprite("#continue_recharge_hammer_light.png");
        hammerLightSprite.setPosition(-1, 19.25);
        hammerLightSprite.setVisible(false);
        hammerNode.light = hammerLightSprite;
        hammerNode.addChild(hammerLightSprite);

        // 錘子
        var hammerSprite = new cc.Sprite("#continue_recharge_hammer.png");
        hammerSprite.setPosition(-1, 19.25);
        hammerNode.hammer = hammerSprite;
        hammerNode.addChild(hammerSprite);

        // 用於儲存需要更新的 node
        this._refreshNode = new cc.Node();
        animationLayer.addChild(this._refreshNode, 12);

        // 去要資料
        DataProcess.sendString("continue_recharge_info");

        this.addLoadingLayer();

        GS.addListener("NotifyContinueRechargeInfoDone", this.notifyContinueRechargeInfoDone.bind(this), this);
        GS.addListener("NotifyContinueRechargeRewardDone", this.notifyContinueRechargeRewardDone.bind(this), this);
        GS.addListener("NotifyIsStayLobbyMain", this.notifyIsStayLobbyMain.bind(this), this);
    },

    /**
     * override
     */
    addLoadingLayer: function () {
        var animationLayer = this._animationLayer;

        // 加之前先檢查有沒有加過，有的話要拿掉
        if (this._loadingLayer)
            this.removeLoadingLayer();

        // 加讀取
        var loadingLayer = this._loadingLayer = new DummyTouchLayer(JSVisibleSize);
        animationLayer.addChild(loadingLayer, 13);

        // 讀取sprite
        var loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(JSScreenMidPos);
        loadingSprite.start();
        loadingLayer.addChild(loadingSprite);
    },

    /**
     * Override掉 假如有WebView一起關掉
     */
    setVisible: function (isVisible) {
        this._super(isVisible);

        // 有說明頁也要隱藏
        if (this._infoDialog) {
            this._infoDialog.setVisible(isVisible);
        }
    },

    _refreshView: function (infoData) {
        this.removeLoadingLayer();

        // 更新獎勵內容
        this._refreshNode.removeAllChildren();
        this._rewardNodeArray.length = 0;

        // 新資料
        this._infoData = infoData;

        // 無活動資料 -> 顯示活動已結束 dialog
        if (!infoData.isSuccess) {
            this._showEventEndDialog();
            return;
        }

        // 大獎相關訊息
        var bigPrizeInfo = this._infoData.bigPrizeInfo;

        // 已經蒐集的寶石數量
        var achievedNum = this._achievedNum = bigPrizeInfo.achievedNum;

        // 目標的寶石數量
        var goalNum = this._goalNum = bigPrizeInfo.goalNum;

        // ==================================================
        // 標題下方說明。
        let descriptionNode = new cc.Node();
        descriptionNode.setPosition(JSScreenMidPos.x + 2, JSScreenMidPos.y + 92);
        this._refreshNode.addChild(descriptionNode);

        // 標題下方說明：排文字與圖
        let descriptionAutoLayout = new GSAutoLayoutNode();
        descriptionNode.addChild(descriptionAutoLayout, 1);

        let prefixLabel = new cc.LabelTTF(LocalizedString.ContinueRecharge("收集"), JSFontBoldName, 11);
        prefixLabel.enableStroke(JSColor.BLACK, 2);
        descriptionAutoLayout.addChild(prefixLabel);

        let descriptionDiamondSprite = new cc.Sprite("#continue_recharge_pic_diamond.png");
        descriptionDiamondSprite.setScale(0.5);
        descriptionAutoLayout.addChild(descriptionDiamondSprite);

        let postfixLabel = new cc.LabelTTF(LocalizedString.ContinueRecharge("累積進度，贏取超級大獎"), JSFontBoldName, 11);
        postfixLabel.enableStroke(JSColor.BLACK, 2);
        descriptionAutoLayout.addChild(postfixLabel);

        // 標題下方說明：背景
        let descriptionBg = TexasUtility.createBlackBgNode(cc.size(descriptionAutoLayout.getContentSize().width - 20, 18), 40);
        descriptionBg.setPositionY(-1);
        descriptionBg.setAnchorPoint(0.5, 0);
        descriptionBg.setOpacity(200);
        descriptionNode.addChild(descriptionBg);

        // ==================================================
        // 進度條
        let progressBar = this._progressBar = new GSProgressTimer("continue_recharge_pic_bar_01.png", "continue_recharge_pic_bar_02.png", cc.size(250, 26), cc.size(242, 15), true);
        progressBar.setAnimationTime(0.5);
        progressBar.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 68);
        this._refreshNode.addChild(progressBar);

        // 設定進度條進度
        progressBar.setPercentage((achievedNum * 100) / goalNum, false);

        // 進度條文字
        let progressBarLabel = this._progressBarLabel = new cc.LabelTTF("", JSFontBoldName, 12);
        progressBarLabel.enableStroke(JSColor.BLACK, 2);
        progressBar.addChild(progressBarLabel);

        // 設定進度條文字
        progressBarLabel.setString(JSStringUtility.format("%s / %s", JSCodeUtility.getCurrencyString(achievedNum), JSCodeUtility.getCurrencyString(goalNum)));

        // 進度條前的鑽石(記位置之後拿來做動畫）
        let progressDiamondSprite = new cc.Sprite("#continue_recharge_pic_diamond.png");
        let diamondSpritePos = this._diamondSpritePos = cc.p(JSScreenMidPos.x - 115, JSScreenMidPos.y + 68);
        progressDiamondSprite.setScale(0.7);
        progressDiamondSprite.setPosition(diamondSpritePos);
        this._refreshNode.addChild(progressDiamondSprite);

        // 進度條後方大獎圖
        let bigPrizeButton = this._bigPrizeBtn = ButtonUtility.createSimpleImageButton("continue_recharge_pic_gift.png");
        bigPrizeButton.setPosition(JSScreenMidPos.x + 120, JSScreenMidPos.y + 68);
        bigPrizeButton.addTouchUpInsideAction(this._bigPrizeInfoClicked, this);
        this._refreshNode.addChild(bigPrizeButton);

        // ==================================================
        // 時間倒數
        let countdownLabel = new RemainTimeLabel(RemainTimeLabel.Style.WHITE);
        countdownLabel.enableBg();
        countdownLabel.setVisible(false);
        countdownLabel.setPosition(JSScreenMidPos.x - 196, JSScreenMidPos.y + 124);
        this._refreshNode.addChild(countdownLabel);

        // 設定倒數
        let remainTime = JSCodeUtility.getRemainTime(infoData.timeLeft, infoData.socketTime);
        countdownLabel.setVisible(true);
        countdownLabel.countdownSeconds(remainTime, () => {
            // 如果開著說明頁先關掉
            if (this._infoDialog) {
                this._infoDialog.closeDialogAnimation();
            }
            this._showEventEndDialog();
        });

        // ==================================================
        // 說明按鈕
        var explainBtn = new Texas_ExplainButton();
        explainBtn.setPosition(JSScreenMidPos.x - 240, JSScreenMidPos.y + 124);
        explainBtn.addTouchUpInsideAction(this._explainBtnClicked.bind(this), this);
        this._refreshNode.addChild(explainBtn, 1);

        // 如果不是教學模式且非可領獎 -> 跳泡泡框
        if (!DataModal.continueRechargeData.continueRechargeTeachMode && !infoData.canReward) {
            this._showBigPrizePopup();
        }

        // ==================================================
        // 創獎勵node
        this._createRewardNode(infoData);

        // ==================================================
        // 其他資料處理

        // 設定當前購買按鈕的金額
        var currentRewardPrice = this._rewardNodeArray[0].price;
        if (currentRewardPrice === 0) {
            this._purchaseButton.label.setString(LocalizedString.ContinueRecharge("領獎"));
            // 需要跑強調動畫
            this._purchaseButton.needToAddEmphaticAnime = true;
        } else {
            this._purchaseButton.label.setString(TexasUtility.getCurrencyPriceString(currentRewardPrice));
            // 不需要跑強調動畫
            this._purchaseButton.needToAddEmphaticAnime = false;
            this._purchaseLabel.setVisible(true);
        }
        this._purchaseButton.setVisible(true);

        // 更新儲值按鈕強調動畫
        this._updatePurchaseBtnAnime();

        // 領大獎的防呆:玩家可能在動畫未跑到領大獎的狀況下跳出dialog,所以一進來先幫他判斷有沒有大獎可以領有的話就補發
        if (achievedNum >= goalNum) {
            DataProcess.sendString("continue_recharge_reward");
            this._isGetBigPrize = true;
            this._purchaseButton.setEnabled(false);
            this.addLoadingLayer();
        }

        // 教學的防呆(避免玩家當前的獎勵是儲值方案進行教學
        if (currentRewardPrice !== 0 || this._isGetBigPrize) {
            DataModal.continueRechargeData.continueRechargeTeachMode = false;
        }

        if (DataModal.continueRechargeData.continueRechargeTeachMode) {
            // 鎖住 Android back key.
            this.isLockBackKey = true;
            let teachLayer = this._teachLayer = new ContinueRechargeTeachLayer();
            teachLayer.setFinishCallback(() => {
                this._teachLayer = undefined;

                // 解鎖 Android back key.
                this.isLockBackKey = false;

                DataModal.continueRechargeData.continueRechargeTeachMode = false;
            });
            this._refreshNode.addChild(teachLayer, 11);
        }

        // 如果第一格可以領獎 -> 跑動畫
        if (infoData["canReward"]) {
            this._purchaseButton.setEnabled(false);
            this._playRechargeDoneAnimation(() => {
                this.addLoadingLayer();
                DataProcess.sendString("continue_recharge_free");
            });
        }
    },

    // 領獎dialog按完確定接下來要做什麼事的callback
    _playAnimeAfterRewardDialog: function (dialogType) {
        // 先判斷是不是教學模式
        this._teachLayer && this._teachLayer.createDialogTeachView(4);

        // 當前購買的按鈕消失
        this._purchaseButton.runAction(cc.fadeOut(0.3));
        this._purchaseLabel.runAction(cc.fadeOut(0.3));

        // 如果是領完大獎: 先把進度條設回0避免有進度條倒退的動畫出現 -> 如果領完大獎有剩下進度元素progressBar會跑動畫 -> 跑剩餘獎勵位移的動畫
        if (dialogType === ContinueRechargeRewardDialog.Type.bigPrize) {
            // 進度條歸0後跑剩餘的進度
            this._progressBar.setPercentage(0, false);
            this._progressBar.setPercentage((this._achievedNum * 100) / this._goalNum, true);
            this._progressBarLabel.setString(JSStringUtility.format("%s / %s", JSCodeUtility.getCurrencyString(this._achievedNum), JSCodeUtility.getCurrencyString(this._goalNum)));

            // 跑動畫（如果是補發大獎只跑進度條不跑獎勵位移)
            if (this._isGetBigPrize) {
                this._isGetBigPrize = false;
                this._showBtnAnime();
            } else {
                this._playRewardMovingAnime(dialogType);
            }
        } else if (this._rewardNodeArray[0].tokenNumber) {
            // 如果是一般領獎領完獎之後： 先判斷這個獎勵有沒有進度元素 -> 如果有 -> 跑動畫 -> 鑽石往上飛 -> 跑進度條 -> 檢查可不可以領大獎
            //                                              -> 如果沒有 -> 跑動畫 -> 直接跑剩餘獎勵的位移動畫 -> 購買按鈕出現
            this._diamondFlyAnimeAsync()
                .then(() => this._updateProgressBarAsync())
                .then((percentage) => this._checkBigPrize(percentage));
        } else {
            // 跑動畫
            this._playRewardMovingAnime();
        }
    },

    // 進度條元素(15.9鑽石) 往進度條飛
    _diamondFlyAnimeAsync: function () {
        return new Promise((resolve) => {
            var currentRewardNode = this._rewardNodeArray[0];

            // 當前進度元素飛往進度條上
            currentRewardNode.runAction(cc.sequence(
                cc.callFunc(() => {
                    currentRewardNode._diamondFlyAnime(this.convertToWorldSpace(this._diamondSpritePos));
                }),
                cc.delayTime(1),
                cc.callFunc(function () {
                    resolve();
                })
            ));
        });
    },

    // 變更進度條進度動畫還有上面的文字
    _updateProgressBarAsync: function () {
        return new Promise((resolve) => {
            // 算新的累積進度元素
            this._achievedNum += this._rewardNodeArray[0].tokenNumber;
            var percentage = (this._achievedNum * 100) / this._goalNum;
            this._progressBar.setPercentage(percentage);
            this._progressBar.setFinishProgressCallback(function () {
                resolve(percentage);
            });
            this._progressBarLabel.setString(JSStringUtility.format("%s / %s", JSCodeUtility.getCurrencyString(this._achievedNum), JSCodeUtility.getCurrencyString(this._goalNum)));
        });
    },

    // 百分比超過100 -> 直接幫玩家領超級大獎 , 沒超過100 -> 接著做改變獎勵位置動畫
    _checkBigPrize: function (percentage) {
        if (percentage >= 100) {
            DataProcess.sendString("continue_recharge_reward");
            this.addLoadingLayer();
        } else {
            this._playRewardMovingAnime();
        }
    },

    // 跑移動獎勵的動畫以及儲值按鈕出現的動畫
    _playRewardMovingAnime: function (dialogType) {
        return this._playRewardMovingAnimeAsync(dialogType)
            .then(() => {
                if (this.__isDestroyed)
                    return;
                this._showBtnAnime();
            });
    },

    // 替換當前獎勵以及改變後續獎勵的位置
    _playRewardMovingAnimeAsync: function (dialogType) {
        return new Promise((resolve) => {
            // 加新獎勵Node進來演動畫的array
            var rewardNodeArray = this._rewardNodeArray;
            var rewardPosArray = this._rewardPosArray;
            var newRewardNode = new ContinueRechargeRewardNode(ContinueRechargeRewardNode.Type.FOLLOW_UP_REWARD, this._newRewardInfo);
            var isBigPrize = (dialogType === ContinueRechargeRewardDialog.Type.bigPrize);

            // 新的獎勵先藏起來等位移之後從底下冒出
            newRewardNode.setPosition(rewardPosArray[6].x, -50);
            this._refreshNode.addChild(newRewardNode, 1);
            rewardNodeArray.push(newRewardNode);

            // 砍掉當前獎勵
            var nodeToBeRemove = rewardNodeArray.shift();
            nodeToBeRemove.setLocalZOrder(12);
            nodeToBeRemove.runAction(cc.sequence(cc.delayTime(1.5), cc.removeSelf()));

            // 所有獎勵往前移且當第一個後續獎勵到達目前獎勵的時候會變身成當前獎勵的顏色
            rewardNodeArray.forEach((cur, index) => {
                cur.runAction(cc.sequence(
                    // 大獎之後跑的動畫要停久一點
                    cc.delayTime((isBigPrize ? 0.5 : 0.1) + 0.2 * index),
                    cc.callFunc(function () {
                        cur.setLocalZOrder(13);
                        var isFirst = (index === 0);
                        if (isFirst)
                            cur.removeFollowUpRewardTypeButton();
                    }),
                    cc.moveTo(index ? 0.3 : 0.4, rewardPosArray[index].x, rewardPosArray[index].y),
                    cc.callFunc(() => {
                        var isFirst = (index === 0);
                        var isLast = (index === rewardNodeArray.length - 1);
                        if (isFirst) {
                            cur.currentRewardLighteningAnimation();
                            cur.changeRewardBgSprite();
                        } else
                            cur.setLocalZOrder(1);
                        if (isLast) {
                            resolve();
                        }
                    })
                ));
            });
        });
    },

    /**
     * 更新儲值按鈕動畫
     */
    _updatePurchaseBtnAnime: function () {
        var purchaseButton = this._purchaseButton;

        if (purchaseButton.needToAddEmphaticAnime && !purchaseButton.isEmphaticAnimeRunning) {
            // 有需要且沒有正在跑 -> 打開
            var anime = cc.sequence(
                cc.scaleTo(0.75, 1.1).easing(cc.easeSineInOut()),
                cc.scaleTo(0.75, 1).easing(cc.easeSineInOut())
            ).repeatForever();
            anime.setTag(0);
            purchaseButton.runAction(anime);
            purchaseButton.isEmphaticAnimeRunning = true;
        } else if (!purchaseButton.needToAddEmphaticAnime && purchaseButton.isEmphaticAnimeRunning) {
            // 不需要且正在跑 -> 關掉
            purchaseButton.stopActionByTag(0);
            purchaseButton.isEmphaticAnimeRunning = false;
        }

        // 更新完把需求關閉
        purchaseButton.needToAddEmphaticAnime = false;
    },

    // 購買的按鈕出現
    _showBtnAnime: function () {
        // 購買按鈕換成最新的價格
        var currentPlanPrice = this._rewardNodeArray[0].price;
        if (currentPlanPrice === 0) {
            this._purchaseButton.label.setString(LocalizedString.ContinueRecharge("領獎"));
            this._purchaseButton.needToAddEmphaticAnime = true;
            this._purchaseLabel.setVisible(false);
        } else {
            this._purchaseButton.label.setString(TexasUtility.getCurrencyPriceString(currentPlanPrice));
            this._purchaseButton.needToAddEmphaticAnime = false;
            this._purchaseLabel.setVisible(true);
            this._purchaseLabel.runAction(cc.fadeIn(0.5));
        }

        // 更新儲值按鈕動畫
        this._updatePurchaseBtnAnime();

        this._purchaseButton.runAction(cc.sequence(
            cc.fadeIn(0.5),
            cc.callFunc(() => {
                this._purchaseButton.setEnabled(true);
            })
        ));

        this._teachLayer && this._teachLayer.runAction(cc.sequence(
            cc.delayTime(1),
            cc.callFunc(() => this._teachLayer.createDialogTeachView(5))
        ));
    },

    _createRewardNode: function (infoData) {
        // 所有獎勵的資訊
        var rewardNodeContentArray = infoData.rewardInfoArray;

        // 創獎勵跟箭頭以及目前獎勵上的星星
        for (let i = 0; i < this._rewardPosArray.length; i++) {
            // i = 0 為當前紅框獎勵 其餘為後續紫框獎勵
            var rewardNodeType = i === 0 ? ContinueRechargeRewardNode.Type.CURRENT_REWARD : ContinueRechargeRewardNode.Type.FOLLOW_UP_REWARD;
            var rewardNode = new ContinueRechargeRewardNode(rewardNodeType, rewardNodeContentArray[i]);
            rewardNode.setPosition(this._rewardPosArray[i]);
            this._refreshNode.addChild(rewardNode, i === 0 ? 12 : 1);
            this._rewardNodeArray[i] = rewardNode;

            if (i !== 0) {
                // i = 0 & i = length 時不會創建箭頭
                var arrow = this._arrowArray[i - 1];
                var arrowSprite = new cc.Sprite("#continue_recharge_pic_arrow.png");
                arrowSprite.setPosition(arrow.arrowPos);
                arrowSprite.setRotation(arrow.rotation);
                // 箭頭的飄移動畫
                arrowSprite.runAction(cc.sequence(
                    cc.moveTo(1, arrow.arrowAniPos.x, arrow.arrowAniPos.y),
                    cc.moveTo(1, arrow.arrowPos.x, arrow.arrowPos.y)
                ).repeatForever());
                this._refreshNode.addChild(arrowSprite, 2);
            }
        }
    },

    // 說明頁
    _explainBtnClicked: function () {
        // 埋點：點擊說明按鈕
        var param = {type: "4"};
        DataProcess.sendString("track_continue_recharge " + JSON.stringify(param));

        // 依據收到的 template 回傳以取得對應包裝的說明頁
        var infoDialog = this._infoDialog = new WebViewDialog(TexasUtility.getSimpleInfoURLByKey("continue_recharge", "template=" + this._infoData["template"]));
        infoDialog.setCloseCallback(() => {
            this._infoDialog = undefined;
        });
        this._animationLayer.addChild(infoDialog, 1000);
        infoDialog.startDialogAnimation();
    },

    // 按到桌子上的購買按鈕
    _purchaseClicked: function () {
        if (this._teachLayer) {
            //當前教學的步驟
            var currentStep = this._teachLayer.getCurrentStep();
            if (currentStep === 1) {
                this._teachLayer.createDialogTeachView(2);
                return;
            } else if (currentStep === 5) {
                this._teachLayer.createDialogTeachView(6);
                return;
            } else if (currentStep !== 2) {
                return;
            }
        }

        if (this._bigPrizePopup) {
            // 正在顯示泡泡框 -> 關閉它
            this._bigPrizePopup.close();
        }

        // 看當前是免費還是需要儲值
        if (this._rewardNodeArray[0].price === 0) {
            this.addLoadingLayer();
            this._purchaseButton.setEnabled(false);
            DataProcess.sendString("continue_recharge_free");
        } else {
            // 埋點：點擊購買按鈕
            var param = {type: "5"};
            DataProcess.sendString("track_continue_recharge " + JSON.stringify(param));

            // 導儲值中心
            PushLayerHelper.pushLayer("", LobbyBannerMode.Purchase);
        }
    },

    // 大獎內容按鈕
    _bigPrizeInfoClicked: function (sender) {
        this._showBigPrizePopup();

        // 埋點：點擊禮物盒 icon
        var trackParam = {type: "8"};
        DataProcess.sendString("track_continue_recharge " + JSON.stringify(trackParam));
    },

    // 顯示泡泡框
    _showBigPrizePopup: function () {
        // 正在顯示 -> 不跳
        if (this._bigPrizePopup) {
            return;
        }

        // 大獎相關訊息
        var bigPrizeInfo = this._infoData.bigPrizeInfo;

        var bigPrizeRewardNode = this._bigPrizeRewardNode = new cc.Node();
        bigPrizeRewardNode.setContentSize(cc.size(75, 30));

        var bigPrizeContentAutoLayout = new GSAutoLayoutNode();
        bigPrizeContentAutoLayout.setSpace(40);
        bigPrizeContentAutoLayout.setPosition(2, 5);
        bigPrizeRewardNode.addChild(bigPrizeContentAutoLayout);

        // 獎勵列表
        bigPrizeInfo.rewardList.forEach((cur) => {
            var bigPrizeRewardNode = new cc.Node();
            bigPrizeContentAutoLayout.addChild(bigPrizeRewardNode);

            var imageUrl = TexasUtility.getItemImageUrl(cur.img);
            var savePath = JSWriteablePath + "shop/" + cur.img + ".png";
            var rewardSprite = new GSDownloadSprite("", imageUrl, savePath);
            rewardSprite.setScale(0.2);
            bigPrizeRewardNode.addChild(rewardSprite);

            var label = new cc.LabelTTF(cur.img === "5004" ? cur.name : JSStringUtility.format("x%s", cur.name), JSFontBoldName, 9);
            label.enableStroke(JSColor.BLACK, 1.5);
            label.setPosition(1, -16);
            bigPrizeRewardNode.addChild(label);
        });

        var bigPrizePopupParam = {
            mainNode: this._bigPrizeRewardNode,
            style: BaseMessageNode.Style.WHITE_SHADOW,
            direct: BaseMessageNode.Direct.LEFT,
            arrowType: BaseMessageNode.ArrowType.STRAIGHT,
            arrowPadding: 8,
            bgBonusSize: cc.size(4, 8),
            closeCallback: () => {
                this._bigPrizePopup = undefined;
            }
        };

        // 初始化泡泡框
        var popupLayer = this._bigPrizePopup = new ShowMessageLayer(bigPrizePopupParam);
        this._animationLayer.addChild(popupLayer, 10);
        var offset = cc.p(15, 0);
        popupLayer.showMessageNode(cc.pAdd(this._bigPrizeBtn.getPosition(), offset));
    },

    // 領獎之 dialog
    _showRewardDialog: function (rewardContent) {
        var dialogType = rewardContent.type;
        // 先判斷是不是教學模式是的話要進下一步
        this._teachLayer && this._teachLayer.createDialogTeachView(3);

        this.removeLoadingLayer();

        // 如果是大獎要記下剩餘多少進度元素
        if (dialogType === ContinueRechargeRewardDialog.Type.bigPrize) {
            this._achievedNum = rewardContent.tokens;
        } else {
            // 一般領獎要記新的獎勵資訊
            this._newRewardInfo = rewardContent.newPlan;
        }

        // dialog上面的獎勵內文
        var rewardMessage = rewardContent.rewardMessage;

        // 獲獎的dialog
        var rewardDialog = new ContinueRechargeRewardDialog(dialogType, rewardMessage);
        rewardDialog.setCloseCallback(() => {
            this._playAnimeAfterRewardDialog(dialogType);
        });
        this._animationLayer.addChild(rewardDialog, 1000);
        rewardDialog.startDialogAnimation();
    },

    // 儲值成功之敲打動畫
    _playRechargeDoneAnimation: function (callback) {
        var hammerNode = this._hammerNode;
        var originalPosition = hammerNode.getPosition();
        var purchaseButton = this._purchaseButton;
        var purchaseLabel = this._purchaseLabel;

        // 錘子背後發光
        hammerNode.light.setVisible(true);
        hammerNode.light.runAction(cc.fadeIn(0.2));
        // 提起錘子
        hammerNode.runAction(cc.sequence(
            cc.spawn(
                cc.moveTo(0.3, JSScreenMidPos.x + 235, JSScreenMidPos.y - 41),
                cc.rotateTo(0.3, 23)
            ),
            cc.rotateTo(0.1, -40),
            // 敲中按鈕
            cc.spawn(
                cc.rotateTo(0.1 / 63 * 10, -50),
                cc.callFunc(() => {
                    purchaseButton.runAction(cc.sequence(
                        cc.scaleTo(0.1 / 63 * 10, 0.8),
                        cc.scaleTo(0.1 / 63 * 10, 1)
                    ));
                    purchaseButton.runAction(cc.fadeOut(0.5));
                    purchaseLabel.runAction(cc.fadeOut(0.5));
                })
            ),
            // 反彈
            cc.rotateTo(0.1 / 63 * 20, -30),
            cc.rotateTo(0.1, -33),
            // call callback
            cc.callFunc(() => {
                callback && callback();
            }),
            cc.delayTime(0.5),
            // 收錘子
            cc.spawn(
                cc.rotateTo(0.5, -37),
                cc.moveTo(0.5, originalPosition.x, originalPosition.y),
                cc.callFunc(() => {
                    hammerNode.light.runAction(cc.fadeOut(0.2));
                })
            )
        ));
    },

    _showEventEndDialog: function () {
        // 跳活動結束dialog
        let closeDialog = new CommonDialog({
            content: LocalizedString.ContinueRecharge("活動時間已結束！"),
            callback: () => {
                this._closeDialogAnimation();
            }
        });
        this._animationLayer.addChild(closeDialog, 1000);
        closeDialog.startDialogAnimation();
    },

    /**
     *  Notify
     */

    // 抓到info資料
    notifyContinueRechargeInfoDone: function (event) {
        if (event && event.getUserData()) {
            this._refreshView(event.getUserData());
        }
    },

    // 領獎(免費和儲值的一般領獎還有大獎都共用這個獲獎dialog)
    notifyContinueRechargeRewardDone: function (event) {
        if (!event || !event.getUserData()) {
            return;
        }

        var rewardContent = event.getUserData();
        // 看是免費、儲值、大獎哪個
        var dialogType = rewardContent.type;

        if (!rewardContent.isSuccess) {
            var errorDialog = new CommonDialog({
                content: LocalizedString.ContinueRecharge("領獎失敗，請稍後再試"),
                callback: () => {
                    if (dialogType === ContinueRechargeRewardDialog.Type.bigPrize) {
                        this.removeLoadingLayer();
                        this._playRewardMovingAnime(dialogType);
                    } else {
                        this.removeLoadingLayer();
                        this._showBtnAnime();
                        this._purchaseButton.setEnabled(true);
                    }
                }
            });
            this.addChild(errorDialog, 1000);
            errorDialog.startDialogAnimation();
            return;
        }
        // 直接跳 dialog
        this._showRewardDialog(rewardContent);
    },

    // 回到大廳
    notifyIsStayLobbyMain: function (event) {
        // 回到大廳時更新資料以知道玩家是否儲值成功。
        if (event && JSCodeUtility.getBooleanValue(event.getUserData())) {
            this.addLoadingLayer();
            DataProcess.sendString("continue_recharge_info");
        }
    },

    createDebugTestObject: function () {
        return new TestMenuDebugObject("連續儲值", {
            "info": () => DataProcess.sendCustomStringToSelf('continue_recharge_info {"plans":[{"pid":"","price":"0","rewards":[{"isToken":"1","name":"1"},{"name":"1","isToken":"0","img":"7086"}]},{"rewards":[{"img":"7086","isToken":"0","name":"1"},{"name":"XXX.X mlr","isToken":"0","img":"5002"}],"pid":"","price":"0"},{"pid":"","price":"0","rewards":[{"name":"1","isToken":"1"},{"img":"6058","isToken":"0","name":"1"}]},{"price":"0","pid":"","rewards":[{"isToken":"1","name":"1"},{"name":"1","isToken":"0","img":"6053"}]},{"pid":"","price":"0","rewards":[{"name":"1","isToken":"1"},{"isToken":"0","name":"1","img":"7020"}]},{"pid":"","price":"1000","rewards":[{"isToken":"1","name":"1"},{"img":"6040","isToken":"0","name":"1"}]},{"pid":"","price":"0","rewards":[{"name":"1","isToken":"1"},{"name":"XXX.X mlr","isToken":"0","img":"5002"}]}],"timeLeft":"18702","template":"1","bigPrize":{"rewards":[{"img":"5004","name":"XXX.X mlr"},{"img":"7086","name":"1"}],"achieved":"5000","goal":"10000"},"success":"1"}'),
            "免費獎勵": () => DataProcess.sendCustomStringToSelf('continue_recharge_free {"success":"1","rewardMsg":"這是獎勵","newPlan":{"price":"5","pid":"xxx","rewards":[{"name":"1","isToken":"1"},{"name":"XXX.X mlr","isToken":"0","img":"5002"}]}}'),
        });
    },
});