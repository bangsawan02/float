/**
 * CapsaSusun UI的畫面 設定在UILayerSetting裡面
 */

var CapsaSusun_UILayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 表情 & 對話 按鈕
        var emoticonMenu = this._emoticonMenu = new cc.Menu();
        emoticonMenu.setPosition(0, 0);
        emoticonMenu.setVisible(false);         // 預設先不出現表情與對話
        this.addChild(emoticonMenu);

        // 表情
        var emoticonMenuWidth = 27;
        this._emoticonPos = cc.p(18 + JSScreenSafeWidth, 15);
        var itemNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_07.png", cc.size(emoticonMenuWidth, 27), "#game_pic_emoticons.png");
        var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._emoticonMenuClicked, this);
        menuItem.setPosition(this._emoticonPos);
        emoticonMenu.addChild(menuItem);

        // 聊天按鈕
        var itemNodes = ButtonUtility.createSingleScale9SpriteNodes("lobby_btn_07.png", cc.size(emoticonMenuWidth, 27), "#game_btn_chat.png");
        var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._chatMenuClicked, this);
        menuItem.setPosition(18 + emoticonMenuWidth + 2 + JSScreenSafeWidth, 15);
        emoticonMenu.addChild(menuItem);

        // 桌內koinLuxy (黑帳號 不顯示)
        if (!DataModal.profileData.isBlackAccount) {
            var koinLuxyNode = this._koinLuxyNode = new KoinLuxyGameNode();
            koinLuxyNode.setPosition(2 + JSScreenSafeWidth, 214 + JSScreenBonusHeight);
            this.addChild(koinLuxyNode);
        }

        // 桌內好友提示(加好友/好友上線)
        var friendGameHintLayer = new FriendGameHintLayer();
        this.addChild(friendGameHintLayer);

        // 註冊
        GS.addListener("NotifyGameTableFunctionHint", this.notifyGameTableFunctionHint.bind(this), this);
    },

    cleanData: function () {
        this._status = null;
        // TODO
        // this._sortMenuItem.forEach(cur => {
        //     cur.setEnabled(true);
        //     cur.setVisible(false);
        // });
    },

    /**
     * 按到表情
     */
    _emoticonMenuClicked: function () {
        // 因為遊戲內可能會關掉Dialog 透過代參數讓Manager管理
        DialogManager.addDialog(new EmoticonsDialog(this._emoticonPos), true, true);

        // 撥放音效
        MusicUtility.playEffect("Music/Effect/button_click.mp3");

        // 拿掉泡泡框
        if (this._msgNode) {
            this._msgNode.close();
            this._msgNode = undefined;
        }
    },

    /**
     * 按到聊天對話
     */
    _chatMenuClicked: function () {
        GS.dispatchCustomEvent("NotifyShowGameChat");

        // 撥放音效
        MusicUtility.playEffect("Music/Effect/button_click.mp3");

        // 拿掉泡泡框
        if (this._msgNode) {
            this._msgNode.close();
            this._msgNode = undefined;
        }
    },

    /**
     * 表情按鈕跳提示泡泡框
     */
    _showEmoticonHintMsg: function (msg, time = 2) {
        if (msg && msg.length) {
            if (this._msgNode) {
                this._msgNode = undefined;
            }

            // 泡泡框
            var msgLabel = new GSRichTextNode("#!000000!#" + msg, JSFontName, 12);
            var msgLabelHalfWidth = msgLabel.getContentSize().width / 2;
            var param = {
                mainNode: msgLabel,
                style: BaseMessageNode.Style.WHITE,
                direct: BaseMessageNode.Direct.DOWN,
                arrowType: BaseMessageNode.ArrowType.STRAIGHT,
                arrowPadding: (msgLabelHalfWidth < 15) ? 0 : msgLabelHalfWidth - 15,
                closeCallback: () => {
                    // 拿掉泡泡框
                    if (this._msgNode) {
                        this._msgNode = undefined;
                    }
                }
            };
            var targetPos = this._emoticonPos;
            var msgNode = this._msgNode = new BaseMessageNode(param);
            msgNode.setPosition(targetPos.x, targetPos.y + 16);
            msgNode.show(time);
            this.addChild(msgNode, 2);
        }
    },

    /**
     * 是否要開啟表情&對話按鈕
     */
    setEmoticonVisible: function (isVisible) {
        this._emoticonMenu.setVisible(isVisible && DataModal.gameData.haveMe);
    },

    /**
     * 下一局時，重設外觀
     */
    cmd_OLEH: function () {
        // 把上一局資訊清掉
        this.cleanData();
    },

    /**
     * 更新koinLuxy
     * @param {String} value socke傳回來的值
     */
    cmd_koin_luxy_room_status: function (value) {
        var jsonValue = JSON.parse(value);
        this._koinLuxyNode && this._koinLuxyNode.refreshKoinStatus(jsonValue);
    },

    /**
     * 監聽
     */
    // 牌桌內功能提示
    notifyGameTableFunctionHint: function (event) {
        var hintType = event.getUserData();
        if (hintType === NewbieData.GameTableFunctionHintType.EMOTICON && this._emoticonMenu.isVisible()) {
            // 泡泡框
            this._showEmoticonHintMsg(LocalizedString.Game("與牌友互動一下吧!"), 3);

            // 紀錄已經跳過
            DataModal.newbieData.saveGameTableFunctionShowed(hintType);
        }
    }
});