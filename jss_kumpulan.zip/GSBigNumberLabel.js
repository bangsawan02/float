var GSBigNumberLabel = GSNumberLabel.extend({
    ctor: function (number, fontName, fontSize, dimensions, hAlignment, vAlignment) {
        this._super(JSCodeUtility.getStringValue(number), fontName, fontSize, dimensions, hAlignment, vAlignment);

        this._totalNumber = "0";
        this.nowNumber = "0";
        this._floorNumber = "0";

        // 動畫要變化的數量
        this._deltaNumber = "0";

        // 設定預設值
        number > 0 && this.setToNumber(JSCodeUtility.getStringValue(number), false);
    },

    // 取目前的數字字串(有逗號) 大數做法
    _getCurrencyString: function (number) {
        this.nowNumber = (number.match(/^[1-9]\d*|^0$/) || ["0"])[0];
        return this.isUseCurrencyString ? this.nowNumber.replace(/\d(?=(?:\d{3})+$)/g, c => c + ",") : this.nowNumber;
    },

    // 運算
    scheduleUpdateLabel: function (dt) {
        this._usedTime += dt;
        if (this._usedTime < this.updateTime) {
            // 算更新百分比
            let percent = JSCodeUtility.getStringValue(this._usedTime / this.updateTime);

            // 計算更新後的數字
            this.nowNumber = JSCodeUtility.bigNumberAdd(this._floorNumber, JSCodeUtility.bigNumberMultiply(this._deltaNumber, percent));
        } else {
            this.unschedule(this.scheduleUpdateLabel);
            this.nowNumber = this._totalNumber;
        }

        this.setString(this.reformat(this.nowNumber));

        // 通知數字更新
        this._updateCallback && this._updateCallback(this.nowNumber);
    },

    setToNumber: function (toNumber, isAnimation = true) {
        toNumber = JSCodeUtility.getStringValue(toNumber).match(/^[1-9]\d*|^0$/);
        toNumber = toNumber ? toNumber[0] : "";

        if (toNumber.length === 0) {
            cc.log("Error: GSBigNumberLabel Number is invalid");
            return;
        }

        // 目標數字一樣不用再重設
        if (this._totalNumber === toNumber) {
            // 但有設定格式的話 要重刷新
            this.setString(this.reformat(this.nowNumber));
            return;
        }

        if (isAnimation) {
            this._totalNumber = toNumber;
            this._floorNumber = this.nowNumber;
            this._usedTime = 0;

            if (this._floorNumber === this._totalNumber)
                return;

            this.unschedule(this.scheduleUpdateLabel);
            this.schedule(this.scheduleUpdateLabel);

            this._deltaNumber = JSCodeUtility.bigNumberSub(this._totalNumber, this._floorNumber);
        } else {
            this._totalNumber = toNumber;
            this._floorNumber = this.nowNumber;
            this.scheduleUpdateLabel(this.updateTime);
        }
    }
});