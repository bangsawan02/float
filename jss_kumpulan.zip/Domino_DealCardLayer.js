/**
 * 用來發牌
 */

var Domino_DealCardLayer = cc.Layer.extend({
    ctor: function () {
        this._super();

        // 設定發牌的時間
        this._dealCardTime = 0.3;

        // 設定發牌的queue
        this._dealCardQueue = [];

        // 發牌的起始點
        this._dealCardBeginPos = cc.p(JSScreenMidPos.x, 190 + JSScreenBonusHalfHeight);

        //加入事件
        GS.addListener("NotifyGamePlayerFoldCard", this.notifyGamePlayerFoldCard.bind(this), this);
    },

    cleanData: function () {
        this._dealCardQueue = [];
    },

    /**
     * 發牌到Player上
     * @param sitNum
     * @param cardNumber 是什麼牌
     * @param callback
     */
    dealCardToPlayer: function (serverPos, cardNumber, callback) {
        var sitNum = DataModal.gameData.getDirectionByServerDirection(serverPos);

        // 做成Param放在Queue
        this._dealCardQueue.push({
            sitNum: sitNum,
            serverPos: serverPos,
            cardNumber: cardNumber,
            callback: callback
        });

        // 判斷現在是不是可以直接發牌
        if (this._dealCardQueue.length === 1) {
            // 直接發牌
            this._realDealCard();
        }
    },

    /**
     * 真正發牌的地方 因為有Queue
     */
    _realDealCard: function () {
        if (this._dealCardQueue.length === 0) {
            // 全部抓完 再去抓下一個Socket
            GS.dispatchCustomEvent("NotifyEnableProcessMessage");
            return;
        }

        var param = this._dealCardQueue[0];

        // 創一張牌
        var dealCard = new Domino_CardNode();
        dealCard.setPosition(this._dealCardBeginPos);
        dealCard.setScale(0.55);
        dealCard.setCardIsInBack(true);
        this.addChild(dealCard);

        // 動畫
        var sitNum = param.sitNum;
        var serverPos = param.serverPos;
        var cardNumber = param.cardNumber;
        var callback = param.callback;
        dealCard.runAction(cc.sequence(
            cc.spawn(cc.moveTo(this._dealCardTime, Domino_GameUtility.getDealCardPosition(sitNum)), cc.rotateBy(0.2, JSCodeUtility.getRandomInt(-180, 180))),
            cc.callFunc(function () {
                callback && callback(serverPos, cardNumber);

                // 砍掉現在這張
                this._dealCardQueue.shift();

                // 再去發下一張
                this._realDealCard();
            }, this),
            cc.fadeOut(0.1),
            cc.removeSelf()
        ));

        // 撥放音效
        MusicUtility.playEffect("Music/Effect/flop.mp3");
    },

    /**
     * 通知
     */
    // 棄牌動畫
    notifyGamePlayerFoldCard: function (event) {
        if (!event)
            return;

        // param裡面有serverPos, cardCount數量
        var param = event.getUserData();
        var serverPos = param.serverPos;
        var sitNum = DataModal.gameData.getDirectionByServerDirection(serverPos);
        var cardCount = param.cardCount;
        var basePosition = Domino_GameUtility.getPlayerPosition(sitNum);
        var endPosition = cc.p(JSScreenMidPos.x, 190 + JSScreenBonusHalfHeight);
        var moveTime = 0.45;
        var offsetX = 10;
        basePosition.x -= (cardCount - 1) * offsetX;
        for (var i = 0; i < cardCount; i++) {
            var cardSprite = new cc.Sprite("#game_card_bg_back.png");
            cardSprite.setScale(0.8);
            cardSprite.setPosition(basePosition.x + offsetX * i, basePosition.y);
            this.addChild(cardSprite, 20);

            // 動畫
            cardSprite.runAction(cc.spawn(
                cc.rotateBy(moveTime, 720),
                cc.moveTo(moveTime, endPosition),
                cc.scaleTo(moveTime, 0.5)
            ).easing(cc.easeOut(2)));
            cardSprite.runAction(cc.sequence(
                cc.delayTime(moveTime - 0.1),
                cc.fadeOut(0.15),
                cc.removeSelf()
            ));
        }
    },
});