var DialogManager = {};

(function () {
    var _dialogArray = [];                          // 受控管的dialog陣列
    var _pauseShowDialog = false;                   // 是否要暫停出現Dialog
    var _maxDialogCount = -1;                       // 最多有幾個Dialog同時出現 超過的時後就會不顯示
    var _maxLobbyDialogCount = -1;                  // 最多有幾個Lobby第一頁限定的Dialog同時出現 超過的時後就會不顯示
    var _enabledShowHigherPriorityDialog = true;    // 已經有Dialog時強制顯示高優先權並可以把低的先隱藏
    var showingDialogName = "DialogShowing";        // 放在Scene上Dialog的名稱

    // 抓取Dialog要加在哪邊的Node
    var getParentFunc = function () {
        var nowScene = cc.director.getRunningScene();
        var dialogParent = nowScene.getChildByName("DialogParent");
        if (!dialogParent) {
            dialogParent = new cc.Node();
            dialogParent.setBreakCameraVisit(true);
            nowScene.addChild(dialogParent, 1000, "DialogParent");
        }
        return dialogParent;
    };

    // 創一個抓出來判斷是否LobbyDialog可以顯示的東西
    var getCanShowDialogFunc = (dialogArray) => {
        // 先判斷是否必須在大廳跳 (LayerArray只有1個代表一定為LobbyLayer || GameLayer || LoginLayer)
        var curDialog;
        var index = 0;
        var nowSceneLayerLen = PushScene.getLayerArrayLength();
        do {
            curDialog = dialogArray[index++];
            if (curDialog && curDialog.isLobbyDialog) {
                // 如果是大廳的Dialog
                curDialog.setTempHide(nowSceneLayerLen !== 1);
            }
        } while (curDialog && curDialog.isLobbyDialog && nowSceneLayerLen !== 1);

        return curDialog;
    };

    /**
     * 新增Dialog
     * @param dialog
     * @param management 是否要給DialogManager控管 預設是true
     * @param replaceOldDialog 是否要覆蓋掉原本舊有的Dialog 主要用在遊戲內 可能輪到自己Dialog消失 可是他又特地去按按鈕
     */
    DialogManager.addDialog = function (dialog, management = true, replaceOldDialog = false) {
        // 先判斷數量有沒有達上限 能不能跳
        if (management && _maxDialogCount > 0 && _dialogArray.length >= _maxDialogCount)
            return;

        var parent = getParentFunc();

        // 先判斷是否要拿掉舊有一樣的Key的Dialog
        if (replaceOldDialog && dialog.key.length > 0) {
            // 代表要把舊有的Dialog拿掉
            var dialogArrayLen = _dialogArray.length;
            if (dialogArrayLen) {
                for (var i = dialogArrayLen - 1; i >= 0;) {
                    var thisDialog = _dialogArray[i];
                    if (thisDialog.key === dialog.key) {
                        // 拿掉他
                        _dialogArray.splice(i, 1);
                    }

                    i--;
                }
            }

            // 從DialogParent抓取現在有的Dialog
            var parentChildren = parent.getChildren();
            var parentChildrenLen = parentChildren.length;
            if (parentChildrenLen) {
                for (var i = parentChildrenLen - 1; i >= 0;) {
                    var thisDialog = parentChildren[i];
                    if (thisDialog.key === dialog.key) {
                        // 拿掉他
                        thisDialog.removeFromParent();
                    }

                    i--;
                }
            }
        }

        // 把dialog加到parent
        dialog.setPosition(JSOriginPoint);
        parent.addChild(dialog);

        // 是否要控管慢慢跳
        if (management) {
            // 受控管的dialog先隱藏
            dialog.setVisible(false);
            _dialogArray.push(dialog);

            if (_dialogArray.length === 1) {
                // 現在沒有Dialog，直接跳
                DialogManager.startShowDialog();
            } else {
                // 先中止原本Dialog的彈跳動畫
                dialog._stopDialogAnimation();

                // 判斷是否要重新排序Dialog
                var showing = false;
                var dialogKey = dialog.key;
                var nowSceneLayerLen = PushScene.getLayerArrayLength();
                if (dialogKey.length) {
                    // 判斷進來的Dialog是否有在優先權清單裡
                    var priority = DialogPriority.getPriority(dialog);
                    if (priority > 0) {
                        // 代表要排序 先把Array裡面的排序一次
                        _dialogArray.sort(function (a, b) {
                            var aPriority = DialogPriority.getPriority(a);
                            var bPriority = DialogPriority.getPriority(b);
                            return bPriority - aPriority;
                        });

                        if (_pauseShowDialog) {
                            // 如果_dialogArray 找到相同的dialog key
                            // 但是被pauseDialog了，可能是被卡住了又不斷點擊要顯示東西
                            if (_dialogArray.slice(0, -1).find((cur) => cur.key === dialog.key)) {
                                var dialogKeys = JSON.stringify(_dialogArray.map(function (obj) {
                                    return obj.key;
                                }));
                                // 送log給自己
                                DataProcess.sendCustomStringToSelf("DialogManagerPausedArray " + dialogKeys);
                            }
                            showing = true;
                        } else {
                            if (_enabledShowHigherPriorityDialog) {
                                // 判斷現在顯示的是否要拿掉改顯示這個 (假如是LobbyDialog的話 要只在第一頁才需要判斷)
                                var oldDialog = parent.getChildByName(showingDialogName);
                                if (oldDialog && (!dialog.isLobbyDialog || nowSceneLayerLen === 1)) {
                                    var oldPriority = DialogPriority.getPriority(oldDialog);
                                    if (priority > oldPriority) {
                                        // 要替換掉新的 先設定新的跳出來不需要動畫
                                        // 新跳出來的是不同dialog 所以還是讓他表演動畫 這邊先註解掉
                                        // dialog.openNeedAnimation = false;

                                        // 先把Name改掉 避免舊dialog setTempHide Web被關掉時
                                        // startShowDialog的getName又判斷成舊dialog需要在被顯示
                                        oldDialog.setName("");

                                        // 把舊的拿掉 要設定好先暫時藏起來 有點hack了
                                        oldDialog.setTempHide(true);

                                        // 在加回來
                                        DialogManager.startShowDialog(dialog);

                                        showing = true;
                                    }
                                }
                            }
                        }
                    }
                }

                if (!showing) {
                    // 上面判斷都沒有成立要Show 要改判斷現在Dialog是否都藏起來 先出現新的
                    var allTempHide = true;
                    for (var i = 0; i < _dialogArray.length; i++) {
                        var thisDialog = _dialogArray[i];

                        // 這邊要判斷tempHide是LobbyDialog的話 要判斷現在的頁面數量
                        var isTempHide = thisDialog.isLobbyDialog
                            ? thisDialog.tempHide || nowSceneLayerLen > 1
                            : thisDialog.tempHide;

                        if (!isTempHide && thisDialog !== dialog) {
                            allTempHide = false;
                            break;
                        }
                    }

                    // 這邊要先判斷是否全部的Dialog是isLobbyDialog 假如是 新的Dialog假如不是才可以跳
                    if (allTempHide && (!dialog.isLobbyDialog || nowSceneLayerLen === 1)) {
                        // 代表可以顯示
                        DialogManager.startShowDialog(dialog);
                    } else {
                        // _dialogArray > 1 && 當前沒有在顯示的dialog && 不能加入此dialog -> 讓他自己去找下一個可顯示的dialog
                        /**
                         * note:
                         * replaceOldDialog時 如果拿掉的是當前顯示的dialog 此刻 還有優先權低的dialog時
                         * 因為還沒顯示過 所以不會setTempHide(true) 會使上方的allTempHide = false
                         * 導致DialogManager.addDialog不會call startShowDialog 因而卡住
                         * 故加此行
                         */
                        DialogManager.startShowDialog();
                    }
                }
            }
        } else {
            // 不被控管 直接跳
            dialog._startDialogAnimation();
        }
    };

    /**
     * 只可以在LobbyLayer跳出的Dialog
     */
    DialogManager.addLobbyDialog = function (dialog, replaceOldDialog = false, isCheckLimit = true) {
        // 不是在Lobby的話不能跳Dialog
        if (!PushScene.isLobby)
            return;

        // 先判斷數量有沒有達上限 能不能跳
        if (isCheckLimit) {
            if (_maxLobbyDialogCount > 0 && _dialogArray.reduce((pre, cur) => pre + (cur.isLobbyDialog ? 1 : 0), 0) >= _maxLobbyDialogCount) {
                var curDialogPriority = DialogPriority.getPriority(dialog);
                // 先判斷這個dialog是不是優先權比較高
                if (_dialogArray.some(cur => curDialogPriority > DialogPriority.getPriority(cur))) {
                    // 優先權比較高 砍掉優先權最低的那個dialog
                    var lowestDialog = _dialogArray.pop();
                    lowestDialog.removeFromParent();
                } else {
                    // 優先權比較低 不加入dialog
                    return;
                }
            }
        }

        dialog.isLobbyDialog = true;
        DialogManager.addDialog(dialog, true, replaceOldDialog);
    };

    /**
     * 跳Dialog在Loading之上, 讓有Loading頁的時後還可以顯示Dialog
     * 此邊的Dialog不會被DialogManager控管
     */
    DialogManager.addDialogOnNotificationNode = function (dialog) {
        dialog._startDialogAnimation();
        cc.director.getNotificationNode().addChild(dialog);
    };

    // 拿掉Dialog
    DialogManager.removeDialog = function (dialog, notShow) {
        // 拿掉此Dialog
        var findIt = false;
        for (var i = 0; i < _dialogArray.length; i++) {
            if (_dialogArray[i] === dialog) {
                // 砍掉他
                _dialogArray.splice(i, 1);
                findIt = true;

                // 這邊要強制把他的name設掉 因為removeFromParent會有問題 都是在onExit中
                try {
                    dialog.setName("");
                } catch (e) {

                }

                break;
            }
        }

        // 被關掉的是被控管的Dialog要去判斷是否還有Dialog要跳
        if (findIt) {
            if (_dialogArray.length) {
                !notShow && DialogManager.startShowDialog();
            } else {
                // 通知外部已關閉所有受控管的dialog
                GS.dispatchCustomEvent("NotifyDialogManagerCleared");
            }
        }
    };

    /**
     * 使用key關掉某一個Dialog
     * @param key
     */
    DialogManager.closeDialogByKey = function (key) {
        for (var i = 0; i < _dialogArray.length; i++) {
            if (_dialogArray[i].key === key) {
                _dialogArray[i]._closeDialogAnimation();
            }
        }
    };

    /**
     * 使用key去判斷Dialog是否存在
     * @param key
     * @returns {boolean}
     */
    DialogManager.isExist = function (key) {
        for (var i = 0; i < _dialogArray.length; i++) {
            if (_dialogArray[i].key === key) {
                return true;
            }
        }
        return false;
    };

    /**
     * 使用key去抓Dialog
     * @param key
     */
    DialogManager.getDialogByKey = function (key) {
        return getParentFunc().getChildren().find(dialog => dialog.key === key);
    };

    /**
     * 統一從這判斷是否可以顯示Dialog
     * @param dialog 有帶dialog代表強制要出現這Dialog 不用去判斷其他的
     */
    DialogManager.startShowDialog = function (dialog) {
        // 先判斷是否有WebView
        if (GSWebViewChecker.haveWebViewRef())
            return;

        // 判斷是否有Dialog 跟 暫停跳出
        if (_dialogArray.length > 0 && !_pauseShowDialog) {
            // 判斷是否現在有Dialog在Scene上
            var scene = getParentFunc();
            if (!dialog) {
                // 沒帶Dialog 要去判斷原本有沒有Dialog已經在顯示了
                var allHide = _dialogArray.every(dialog => !dialog.isVisible());
                if (!allHide) {
                    // 有Dialog在顯示 且是被控管的 只能顯示一個 跳掉
                    return;
                }

                // 判斷這畫面上有沒有人之前有顯示過 只是因為優先權或其它原因被暫時看不到
                var parentChildren = scene.getChildren();
                var totalDialogs = [];
                for (var i = 0; i < parentChildren.length; i++) {
                    var child = parentChildren[i];
                    if (child.getName() === showingDialogName) {
                        totalDialogs.push(child);
                    }
                }

                var totalDialogLen = totalDialogs.length;
                if (totalDialogLen) {
                    // 代表有Dialog在 判斷裡面是不是有tempHide的 比較一下優先權後 把他顯示
                    if (totalDialogLen > 1) {
                        totalDialogs.sort(function (a, b) {
                            var aPriority = DialogPriority.getPriority(a);
                            var bPriority = DialogPriority.getPriority(b);
                            return bPriority - aPriority;
                        });
                    }

                    // 顯示該出現的Dialog
                    var needShowDialog = getCanShowDialogFunc(totalDialogs);
                    if (needShowDialog) {
                        // 有該出現的Dialog 把它設定出現 且跳掉
                        needShowDialog.setTempHide(false);
                        needShowDialog.setVisible(true);
                        return;
                    }
                }
            }

            // 上面沒有要顯示的
            try {
                // 看是否有指定跳哪一個 沒有的話去抓出來哪一個Dialog可以出現
                var curDialog = dialog || getCanShowDialogFunc(_dialogArray);

                if (!curDialog)
                    return;

                // 避免需要打開的dialog還在隱藏中
                curDialog.setTempHide(false);

                // 直接跳Dialog
                curDialog.setName(showingDialogName);
                curDialog.setVisible(true);

                if (curDialog.openNeedAnimation) {
                    // 需要動畫, 直接跳
                    curDialog._startDialogAnimation();
                } else {
                    // 不需要動畫, 延遲1frame, 避免notify不會生效
                    curDialog.runAction(cc.callFunc(() => curDialog._startDialogAnimation()));
                }
            } catch (e) {

            }
        }
    };

    /**
     * 清掉所有Dialog 用在切換Scene的時後
     * @param cleanNoManagement 要不要 連未管控的也要清掉
     */
    DialogManager.cleanAllDialog = function (cleanNoManagement = false) {
        // 要copy一份出來清掉 因為裡面dialog remove後 會馬上startDialog
        var tmpArray = _dialogArray.slice();
        _dialogArray = [];
        tmpArray.forEach(function (cur, index) {
            cur.removeFromParent();
        });

        // 未管控也清
        var nowScene = cc.director.getRunningScene();
        var dialogParent = nowScene.getChildByName("DialogParent");
        if (dialogParent && cleanNoManagement) {
            dialogParent.removeAllChildren();
        }
    };

    /**
     * 更新LobbyDialog的顯示與否
     */
    DialogManager.updateLobbyDialogVisible = function () {
        var nowSceneLayerLen = PushScene.getLayerArrayLength();
        if (nowSceneLayerLen > 1) {
            // 不是主頁面了 要把LobbyDialog的畫面關掉
            _dialogArray.forEach(dialog => dialog.isLobbyDialog && dialog.setTempHide(true));
        }

        // 重新去跳出
        DialogManager.startShowDialog();
    };

    /**
     * 用於顯示Dialog中 可以強制先關掉 之後在顯示 (可能用於遊戲中輪到自己要出牌的時後)
     */
    DialogManager.setAllDialogVisible = function (isVisible) {
        // 把現在顯示的Dialog關掉 假如是要顯示的 要判斷是不是LobbyDialog 假如是在第一頁才能顯示
        var nowSceneLayerLen = PushScene.getLayerArrayLength();
        getParentFunc().getChildren().forEach(cur => {
            if (!isVisible || !cur.isLobbyDialog || nowSceneLayerLen === 1)
                cur.setTempHide(!isVisible);
        });
    };

    /**
     * 暫停再出現Dialog 用在假如進去一個頁面 那個頁面不適合跳Dialog了
     */
    DialogManager.pauseShowDialog = function () {
        _pauseShowDialog = true;
    };

    /**
     * 解除 _pauseShowDialog
     */
    DialogManager.unpauseShowDialog = function () {
        _pauseShowDialog = false;
    };

    /**
     * 設定可以再出現Dialog
     */
    DialogManager.resumeShowDialog = function () {
        _pauseShowDialog = false;

        // 去判斷有沒有Dialog要show
        DialogManager.startShowDialog();
    };

    /**
     * 確認現在是否有任何dialog存在
     * @returns {boolean}
     */
    DialogManager.checkIsShowDialog = function () {
        return getParentFunc().getChildren().length > 0;
    };

    /**
     * 確認現在是否有管理的dialog存在
     * @returns {boolean}
     */
    DialogManager.checkHaveManagementDialog = function () {
        return _dialogArray.length > 0;
    };

    /**
     * 確認現存大廳Dialog數量，還能不能跳Dialog
     * @returns {boolean}
     */
    DialogManager.checkCanShowLobbyDialog = function () {
        return !(_maxLobbyDialogCount > 0 && _dialogArray.reduce((pre, cur) => pre + (cur.isLobbyDialog ? 1 : 0), 0) >= _maxLobbyDialogCount);
    };

    /**
     * 取得現在有多少 dialog 存在
     * @returns {number}
     */
    DialogManager.getDialogLength = function () {
        return getParentFunc().getChildren().length;
    };

    /**
     * 取得 現在有多少控管的 dialog 存在
     * @return {number}
     */
    DialogManager.getManagementDialogLength = function () {
        return _dialogArray.length;
    };

    /**
     * 設定現在Dialog最多能出現幾個 -1代表是無限
     */
    DialogManager.setMaxDialogCount = function (count) {
        _maxDialogCount = count;
    };

    /**
     * 設定現在Lobby第一頁跳出的Dialog最多能出現幾個 -1代表是無限
     */
    DialogManager.setMaxLobbyDialogCount = function (count) {
        _maxLobbyDialogCount = count;
    };

    DialogManager.setShowHigherPriorityDialog = function (value) {
        _enabledShowHigherPriorityDialog = value;
    };

    /**
     * 告知現在有WebView 判斷現在有沒有出現的Dialog 有的話把它關掉
     * @param webView   要把現在出現的webView丟進來 來判斷現在出現的Dialog是不是有加WebView
     */
    DialogManager.setNowShowWebView = function (webView) {
        // 判斷這畫面上有沒有人之前有顯示過 只是因為優先權或其它原因被暫時看不到
        var parentChildren = getParentFunc().getChildren();
        var totalDialogs = [];
        for (var i = 0; i < parentChildren.length; i++) {
            var child = parentChildren[i];
            if (child.getName() === showingDialogName) {
                totalDialogs.push(child);
            }
        }

        if (totalDialogs.length) {
            // 東西在出現 要判斷現在的webView是加在Dialog上還是普通頁面上 假如是Dialog上 就不理他
            var isDialogWebView = false;
            for (var c = webView.getParent(); c != null; c = c.getParent()) {
                if (c instanceof BaseDialogLayer) {
                    isDialogWebView = true;
                    break;
                }
            }

            // 不是WebView的Dialog 把它關掉
            if (!isDialogWebView)
                totalDialogs.forEach(dialog => dialog.setTempHide(true));
        }
    };

}.call());
