/**
 * 轉盤的基本Node
 */

var BaseWheelNode = cc.Node.extend({
    initProperties: function () {
        // 指針相關
        this._pin = undefined;          // 指針的Sprite
        this._pinPosOri = -1;
        this._pinPosCur = -1;
        this._isPinMoving = false;
        this._isPinReturn = false;
        this._isPinFirst = false;

        // 轉盤相關
        this._wheelSpeed = 1;           // 起始速度
        this._wheelTargetRotate = 3;    // 基本轉圈數
        this._targetRotation;           // 目標角度

        this._endCallBackSeconds = 1;   // 轉完後幾秒呼叫callBack
    },

    ctor: function () {
        this._super();

        // 初始化屬性
        this.initProperties();

        // 轉盤container, 要轉的東西放這裡
        var wheelContainer = this._wheelContainer = new cc.Node();
        this.addChild(wheelContainer, 1);

        // 初始化轉盤樣式
        this._initWheel();
    },

    /**
     * 初始化轉盤樣式 (給各轉盤override)
     * 在輪盤下方zorder給0
     * 在輪盤上方zorder給1以上
     * @override
     */
    _initWheel: function () {
    },

    /**
     * 按下馬上轉
     * @override
     */
    _spinBtnClicked: function (sender) {
        // 先關閉按鈕
        sender && sender.setEnabled(false);

        // 開始轉的callback
        this._spinCallback && this._spinCallback();

        // 指針初始設定
        if (this._pin) {
            this._pinPosCur = (this._wheelContainer.getRotation() + 15) / 30;
            this._isPinFirst = true;
        }

        // 開始轉
        this.scheduleUpdate();
    },


    /**
     * 轉完了要關動畫
     * @override
     */
    _spinEnd: function () {
        this.unscheduleUpdate();

        // 設定的秒數後呼叫callback
        this.runAction(cc.sequence(
            cc.delayTime(this._endCallBackSeconds),
            cc.callFunc(() => {
                // 呼叫轉盤動畫完成callback
                this._spinFinishCallback && this._spinFinishCallback();
                this._wheelContainer.setRotation(this._wheelContainer.getRotation() % 360);
            }, this)
        ));
    },

    /**
     * 設定開始轉的callback
     * @param callback
     */
    setSpinCallback: function (callback) {
        this._spinCallback = callback;
    },

    /**
     * 設定轉完的callback
     * @param callback
     */
    setSpinFinishCallback: function (callback) {
        this._spinFinishCallback = callback;
    },

    /**
     * update
     * @param delta 每幀run的秒數
     */
    update: function (delta) {
        var targetRotation = this._targetRotation;
        var curRotation = this._wheelContainer.getRotation();   // 最近的rotation

        // 最後一圈開始減速
        if (curRotation > (targetRotation - 360)) {

            // 利用rotation來控制速度(防止最後轉的時候太慢)
            var tmpSpeed = Math.max((targetRotation - curRotation) * delta, 0.07);

            // 設置rotation
            this._wheelContainer.setRotation(curRotation + tmpSpeed);

            // 到達目標角度
            if (Math.abs(this._wheelContainer.getRotation() - targetRotation) < 0.1) {
                this._spinEnd();
            }
        } else {
            // 一開始的加速度 設置速度上限
            this._wheelSpeed = Math.min(this._wheelSpeed * 1.02, 10);

            var rotation = Math.floor(curRotation) + Math.floor(this._wheelSpeed);
            this._wheelContainer.setRotation(rotation);
        }

        // 沒有指針就不往下
        if (!this._pin)
            return;

        // 指針轉動
        if (this._pinPosCur !== -1) {
            this._pinPosCur = (this._wheelContainer.getRotation() + 30) / 60;
            if (!this._isPinFirst) {
                if (Math.floor(this._pinPosCur) !== Math.floor(this._pinPosOri)) {
                    this._isPinMoving = true;
                    this._isPinReturn = false;
                }
            }
            this._isPinFirst = false;
        }
        this._pinPosOri = this._pinPosCur;
        this._movePin();
    },

    /**
     * 移動指針
     */
    _movePin: function () {
        if (this._isPinMoving) {
            var addSpeed = 15;
            var rotation;
            if (this._pin.getRotation() > -67.5 && !this._isPinReturn) {
                if (Math.floor(this._targetRotation / 67.5) === Math.floor(this._wheelContainer.getRotation() / 30)) {
                    this._isPinReturn = true;
                    return;
                }

                rotation = Math.max(this._pin.getRotation() - addSpeed, -67.5);
                if (rotation === -67.5)
                    this._isPinReturn = true;

                this._pin.setRotation(rotation);
            } else {
                rotation = this._pin.getRotation() + addSpeed;
                this._pin.setRotation(rotation);

                if (rotation >= 0) {
                    this._pin.setRotation(0);
                    this._isPinMoving = false;
                    this._isPinReturn = false;
                }
            }
        }
    }
});