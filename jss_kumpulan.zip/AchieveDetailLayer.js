/**
 * 9T 成內容頁面
 */

var AchieveDetailLayer = cc.Layer.extend({
    ctor: function (tabIndex) {
        this._super();

        // 將 tabIndex (0:活動 1:偉大 2:一般 3:每日) => 轉成Server Index (1:每日 2:一般 3:偉大 4:活動)
        this._serverIndex = (2 - tabIndex) + 2;

        // 資料數量
        this._totalCount = 0;

        // 放成就的tableView
        var mainLayer = new cc.Layer();
        var tableView = this._tableView = new cc.TableView(this, cc.size(JSVisibleSize.width - JSScreenBonusWidth, JSVisibleSize.height - TITLE_BG_HEIGHT), mainLayer);
        tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        tableView.setDelegate(this);
        tableView.setPositionX(JSScreenBonusHalfWidth);
        this.addChild(tableView);

        // 加個Loading
        var loadingSprite = this._loadingSprite = new GSLoadingSprite();
        loadingSprite.setPosition(JSScreenMidPos);
        loadingSprite.start();
        this.addChild(loadingSprite);

        // 註冊
        GS.addListener("NotifyFetchAchievementInfo", this._refreshView.bind(this), this);
        GS.addListener("NotifyPatchAchievementRewardDone", this._refreshView.bind(this), this);
    },

    onEnter: function () {
        this._super();

        // 去抓那一個種類的成就
        var param = {
            "tab": this._serverIndex,
            "offset": 0,
            "limit": 0
        };
        DataProcess.sendString("fetch_achievement_info " + JSON.stringify(param));
    },

    /**
     * 功能
     */
    // 更新畫面
    _refreshView: function () {
        // 關掉loading
        this._loadingSprite.stop();

        // 取得數量
        this._totalCount = DataModal.achieveData.achieveArray[this._serverIndex - 1].length;

        // 重整畫面
        this._tableView.reloadData(true);
    },

    /**
     * TableView delegate
     */
    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();
        if (cell == null) {
            cell = new AchieveDetailCell();
            cell.setAnchorPoint(0, 0);
        }
        cell.refreshCell(DataModal.achieveData.achieveArray[this._serverIndex - 1][idx]);
        return cell;
    },

    numberOfCellsInTableView: function (table) {
        return this._totalCount;
    },

    tableCellSizeForIndex: function (table, idx) {
        return cc.size(JSVisibleSize.width, 68);
    },
});