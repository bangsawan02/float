/**
 * 牌王地圖上的單個節點
 */

var CardKingMapRouteNode = cc.Node.extend({
    ctor: function (round, type) {
        this._super();

        // 屬於哪個顏色
        this._colorType = CardKingData.MapRouteColorType.BLUE;

        // 累計幾局
        this.round = round;

        // 這個node的底圖
        this._nodeSp = new cc.Sprite(JSStringUtility.format("#cardKing_pic_mapNode%02d.png", this._colorType));
        this.addChild(this._nodeSp);

        // 局數Node
        var roundSp = this._roundSp = new GSSpriteNumberNode({
            number: 0,
            numStr: "#num_19_",
            spW: 6
        });
        this.addChild(roundSp);

        // 起點按鈕字圖
        var startSp = this._startSp = new cc.Sprite("#cardKing_word_start.png");
        this.addChild(startSp);

        // 玩家頭像的泡泡匡
        var playerNode = this._playerNode = new CardKingMapPlayerNode(type);
        this.addChild(playerNode);
    },

    refresh: function (round, data, level) {
        this.stopAllCurrentAction();
        if (round !== undefined)
            this.round = round;

        var sizeScale = 1;

        // 是起點
        if (round === 0) {
            this._roundSp.setVisible(false);
            this._startSp.setVisible(true);
            sizeScale = 1.2;
        } else {
            this._roundSp.setVisible(true);
            this._startSp.setVisible(false);
            this._roundSp.setNumber(round);
        }

        // 取得顏色
        this._colorType = DataModal.cardKingData.getColorTypeByRound(round);

        this._nodeSp.setSpriteFrame(JSStringUtility.format("cardKing_pic_mapNode%02d.png", this._colorType));

        this._nodeSp.setScale(sizeScale);
        this._roundSp.setNumber(round);

        // 處理泡泡匡
        this._playerNode.refresh(data, level)
    },

    // 讓局數跑一個動畫
    setRoundWithDuration: function (round, duration) {
        if (this.round === 0 && round > 0) {
            this._roundSp.setVisible(true);
            this._startSp.setVisible(false);
            this._roundSp.setNumber(this.round);
            this._nodeSp.setScale(1);
        }

        this._roundSp.setUpdateTime(duration);
        this._roundSp.setAnimationDoneCallback(() => this.round = round);
        this._roundSp.setToNumber(round, true);
    },

    // 設定顏色
    setColorType: function (colorType) {
        if (this._colorType !== colorType) {
            this._colorType = colorType;
            this._nodeSp.setSpriteFrame(JSStringUtility.format("cardKing_pic_mapNode%02d.png", this._colorType));
        }
    },

    getColorType: function () {
        return this._colorType;
    },

    // 設定泡泡箭頭方向
    setBubbleDirection: function (direction) {
        this._playerNode.changeArrowDirection(direction);

        switch (direction) {
            case BaseMessageNode.Direct.DOWN:
                this._playerNode.setPosition(0, 6);
                break;
            case BaseMessageNode.Direct.LEFT:
                this._playerNode.setPosition(7, 0);
                break;
            case BaseMessageNode.Direct.UP:
                this._playerNode.setPosition(0, -6);
                break;
            case BaseMessageNode.Direct.RIGHT:
                this._playerNode.setPosition(-7, 0);
                break;
        }
    },

    // 設定泡泡能不能按(跳這個節點上的其他玩家泡泡匡), 在起點上不能按
    setBubbleEnabled: function (enable) {
        this._playerNode.setButtonEnabled(enable);
    },

    // 設定泡泡匡要不要縮起來
    setBubbleOpen: function (open, doneCallback) {
        this._playerNode.setOpen(open, doneCallback);
    },

    // 設定要不要出現泡泡匡
    setBubbleVisible: function (visible) {
        this._playerNode.checkNeedToShow(visible);
    },

    // 設定泡泡匡是不是最強, 只有自己的節點會用到
    setBubbleIsTop: function (isTop) {
        this._playerNode.setIsTop(isTop);
    },

    // 如果按跳過要中止正在做的一切動作
    stopAllCurrentAction: function () {
        this.stopAllActions();
        this._roundSp.stopUpdateNumber();
    }
});
