/**
 * v5.4.7 聊天室優惠券 - 聊天室列表中上面的node (在公會的下面)
 * 繼承: ChatRoomTopBaseNode
 * created by lichieh on 2023/1/4
 */
var DiscountNotifyRoomNode = ChatRoomTopBaseNode.extend({
    ctor: function () {
        this._super(LocalizedString.PurchaseCoupon("優惠通知"), "#lobby_icon_coupon.png");

        this.notifyChatRoomDiscountDone();

        // 監聽
        GS.addListener("NotifyChatRoomDiscountDone", this.notifyChatRoomDiscountDone.bind(this), this);
    },

    /**
     * 打開聊天室
     * @override
     */
    _clickDiscountNotifyRoomBtn: function () {
        this._super();

        // 關閉紅點
        DataModal.chatRoomData.setDiscountRedPoint();
        this._badge.setVisible(false);

        // 通知外面icon的小紅點刷新
        GS.dispatchCustomEvent("NotifyUpdateChatRoomIcon");
    },

    /**
     * 通知
     */
    // 通知載入優惠卷資訊了(來自其他cmd的通知)
    notifyChatRoomDiscountDone: function () {
        // 確認紅點
        this._badge.setVisible(DataModal.chatRoomData.getDiscountRedPoint());
    }
});