/**
 * 破產儲值挽回dialog
 */

var BankruptCouponLeaveDialog = BaseDialogLayer.extend({
    ctor: function () {
        this._super();
        this.key = "BankruptCouponLeaveDialog";

        // 拿資料
        this._param = DataModal.purchaseCouponData.bankruptCouponParam;

        var aniLayer = this._animationLayer;
        var dialogSize = cc.size(300, 180);

        var background = new ccui.Scale9Sprite("lobby_bg_window.png");
        background.setPreferredSize(dialogSize);
        background.setPosition(JSScreenMidPos);
        aniLayer.addChild(background);

        // 標題
        var couponString = LocalizedString.PurchaseCoupon;
        var title = new cc.LabelTTF(couponString("提醒您"), JSFontBoldName, 18);
        title.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + dialogSize.height / 2 - 22);
        aniLayer.addChild(title);

        // 說明文字
        var timeRichTxt = new GSRichTextNode("", JSFontBoldName, 14);
        timeRichTxt.setHAlignmentToCenter(true);
        timeRichTxt.setPosition(JSScreenMidPos.x, JSScreenMidPos.y + 8);        //加8上去一點看起來會比較自然
        aniLayer.addChild(timeRichTxt);

        // 更新倒數禮包數
        var updateTime = () => {
            var leftTime = this._param.countdownTime - JSCodeUtility.getNowTime();
            if (leftTime < 0) {
                // 先解掉Schedule
                this.unscheduleAllCallbacks();
                // 再通知關閉Dialog
                GS.dispatchCustomEvent("NotifyBankruptCouponFinish");
            } else {
                var quota = JSStringUtility.format("#!FF0000!# %d #!FFFFFF!#", Math.ceil(leftTime / 5));

                var timeString = "#!FFFFFF!#";
                timeString += JSStringUtility.format(couponString("這個優惠只剩下 %s 個"), quota);
                timeRichTxt.setText(timeString, JSFontName, 14);
            }
        };
        this.schedule(updateTime, 1, cc.REPEAT_FOREVER, 0);
        updateTime();

        // 按鈕
        var btnSize = cc.size(100, 28);
        var menu = new cc.Menu;
        menu.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - dialogSize.height / 2 + btnSize.height / 2 + 20);
        aniLayer.addChild(menu);

        // 左邊按鈕
        var thinkBtnSp = ButtonUtility.createArrayScale9Nodes(["btn_style_01_null.png", "btn_style_01_null.png", "btn_style_01_null.png"], btnSize, couponString("再想想"), 12, cc.color(255, 255, 255, 255), cc.p(0, 0));
        var thinkBtn = new cc.MenuItemSprite(thinkBtnSp[0], thinkBtnSp[1], thinkBtnSp[2], this._clickGiveUp, this);
        thinkBtn.setPositionX(-60);
        menu.addChild(thinkBtn);

        // 右邊按鈕
        var buyBtnSp = ButtonUtility.createArrayScale9Nodes(["btn_style_02_on.png", "btn_style_02_on.png", "btn_style_02_on.png"], btnSize, couponString("把握機會"), 12, cc.color(255, 255, 255, 255), cc.p(0, 0));
        var buyBtn = new cc.MenuItemSprite(buyBtnSp[0], buyBtnSp[1], buyBtnSp[2], this._clickBuyButton, this);
        buyBtn.setPositionX(60);
        menu.addChild(buyBtn);

        // 註冊通知
        GS.addListener("NotifyBankruptCouponFinish", this._closeDialogAnimation.bind(this), this);
    },

    // 按下放棄
    _clickGiveUp: function () {
        // 關完再關閉主畫面，畫面才不會有點怪
        this.setCloseCallback(function () {
            GS.dispatchCustomEvent("NotifyBankruptCouponFinish");
        });
        this._closeDialogAnimation();
    },

    // 按下購買
    _clickBuyButton: function () {
        this._closeDialogAnimation();

        // 判斷是否開第三方 超過一個要開管道多選dialog
        var param = this._param;
        var productList = param.productIDList;
        // 只有一個 送儲值
        if (productList.length === 1)
            DataModal.purchaseData.sendPurchase(productList[0]);

        // 一個以上開選擇dialog
        if (productList.length > 1)
            DialogManager.addDialog(new ProviderChooseDialog(param), false);

        // 埋點
        DataProcess.sendString(JSStringUtility.format("track_bankrupt_payment_click %s", param.payMoney));
    }
});
