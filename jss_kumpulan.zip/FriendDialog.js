/**
 * 好友Dialog
 * param = {
 *     photo : 大頭照
 *     msg   : 中間訊息
 *     title : 上方訊息
 *     button: 按鈕
 *     cb    : 按鈕的cb
 * }
 * 使用:
 * 詢問是否刪除該玩家Dialog
 * 詢問此桌椅無法入桌是否要與其他人玩Dialog
 * 顯示已經搜尋過的Dialog
 */
var FriendDialog = BaseDialogLayer.extend({
    ctor: function (param) {
        this._super();

        // 設定參數
        this._cb = param.cb;

        var aniLayer = this._animationLayer;

        // 背景
        var bgSp = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSp.setPreferredSize(cc.size(272, 114));
        bgSp.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSp);

        var mainMenu = new cc.Menu();
        mainMenu.setPosition(0, 0);
        aniLayer.addChild(mainMenu);

        // 下方按鈕
        var btnLen = param.button.length;
        var btnRes = (btnLen === 1) ? "lobby_btn_01.png" : "lobby_btn_06.png";
        var btnImages = [btnRes, "lobby_btn_01.png"];
        var posX = (btnLen === 1) ? JSScreenMidPos.x : 191 + JSScreenBonusHalfWidth;
        for (var i = 0; i < btnLen; i++) {
            var itemNodes = ButtonUtility.createSingleScale9Nodes(btnImages[i], cc.size(76, 30), param.button[i], 14, JSColor.BLACK);
            var menuItem = new cc.MenuItemSprite(itemNodes[0], itemNodes[1], this._itemClicked, this);
            menuItem.setTag(i);
            menuItem.setPosition(posX + 130 * i, 65 + JSScreenBonusHalfHeight);
            mainMenu.addChild(menuItem);
        }

        // 標題
        if (param.title) {
            var titleLabel = new cc.LabelTTF(param.title, JSFontBoldName, 14);
            titleLabel.setPosition(JSScreenMidPos.x, 181 + JSScreenBonusHalfHeight);
            aniLayer.addChild(titleLabel);
        }

        // 訊息
        var msgLabel = new cc.LabelTTF(param.msg, JSFontBoldName, 12);
        msgLabel.setPosition(JSScreenMidPos);
        msgLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        aniLayer.addChild(msgLabel);

        // 大頭貼
        if (param.photo) {
            var photoNode = this._photoSprite = new LobbyCircleProfileNode(param.photo);
            photoNode.setPosition(183 + JSScreenBonusHalfWidth, 134 + JSScreenBonusHalfHeight);
            photoNode.setScale(0.8);
            aniLayer.addChild(photoNode);

            // 調整訊息
            msgLabel.setPosition(276 + JSScreenBonusHalfWidth, 134 + JSScreenBonusHalfHeight);
        }
    },

    /**
     * 按鈕點擊
     */
    _itemClicked: function (sender) {
        if (this._cb)
            this._cb(sender);

        this._closeDialogAnimation();
    }
});