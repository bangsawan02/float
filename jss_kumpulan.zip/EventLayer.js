/**
 * 活動頁面
 */

var EventLayer = cc.Layer.extend({
    ctor: function (eventUrl) {
        this._super();

        // 有指定的Url 要記下來
        this._eventUrl = eventUrl;

        var lobbyStr = LocalizedString.Lobby;

        // 背景
        var bgSprite = new cc.Sprite(SelectGameManager.getNowGameFile("lobby_background.jpg"));
        bgSprite.setPosition(JSScreenMidPos);
        bgSprite.setColor(JSColor.GRAY);
        this.addChild(bgSprite, -1000);

        // 上方文字底
        var titleNode = new TitleBackgroundNode(lobbyStr("活動"));
        titleNode.setPosition(JSScreenMidPos.x, JSVisibleSize.height - TITLE_BG_HEIGHT / 2);
        this.addChild(titleNode);

        // 回列表按鈕
        var btnSize = cc.size(84, 20);
        var backBtn = ButtonUtility.createSimpleButton("btn_style_01_on.png", btnSize, lobbyStr("回列表"), JSColor.WHITE, 13);
        backBtn.setPosition(80 + JSScreenSafeWidth, JSVisibleSize.height - TITLE_BG_HEIGHT / 2 + 4);
        backBtn.addTouchUpInsideAction(this._menuGoHomeClicked, this);
        this.addChild(backBtn);
    },

    viewDidAppear: function () {
        // WebView
        if (!this._webView) {
            var webView = this._webView = new GSWebView();
            webView.setEnableUrlOverride(true);
            webView.setContentSize(JSVisibleSize.width, JSVisibleSize.height - TITLE_BG_HEIGHT);
            webView.setPosition(JSScreenMidPos.x, JSScreenMidPos.y - TITLE_BG_HEIGHT / 2);
            !cc.sys.isNative && webView.setTransparent(true);
            this.addChild(webView);

            // 開啟硬體加速
            webView.setHardwareAccelerated(true);
        }

        // 把WebView打開
        this._webView && this._webView.setVisible(true);

        // 直接跑URL
        this._menuGoHomeClicked();
    },

    viewWillDisappear: function () {
        // 把WebView關掉
        this._webView && this._webView.setVisible(false);
    },

    /**
     * 按鈕
     */
    // 按到回首頁
    _menuGoHomeClicked: function () {
        var url = this._eventUrl;
        if (!url) {
            url = JSStringUtility.format("%s%s&PSKEY=%s",
                GS.transferDomain(DataModal.profileData.eventURL),
                GS.webUrlParam,
                DataModal.loginData.sessionKey);
        }

        // 轉過就清掉
        this._eventUrl = "";

        this._webView.loadURL(encodeURI(url));
        cc.log("EventLayer 連到: " + url);
    }
});