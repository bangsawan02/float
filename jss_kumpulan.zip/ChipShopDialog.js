/**
 * v5.4.5 商城 - 德撲幣商城Dialog(繼承背包BackpackDialog)
 * 目前使用:
 * 桌內商城的Dialog
 * 大廳聊天室貼圖點擊會打開商城Dialog
 *
 * chipShopDialogType : 商城打開的種類(對應 chipShopDialogType)
 * account : 送禮時會使用到
 * shopProductType : 商城指定的分頁(對應 ShopProductType)
 *
 * created by lichieh on 2022/11/2
 */
var ChipShopDialog = BackpackDialog.extend({
    ctor: function (chipShopDialogType, account, shopProductType) {
        var tabTitles = [
            {title: "商城", type: ShopType.PRODUCT},
            {title: "延效", type: ShopType.EXTEND},
            {title: "物品", type: ShopType.BACKPACK},
            {title: "勳章", type: ShopType.MEDAL},
            {title: "其它", type: ShopType.OTHER},
        ];

        // 商城打開的種類(對應 chipShopDialogType)
        this._chipShopDialogType = chipShopDialogType;

        // 商城指定的分頁對應(對應 ShopProductType)
        this._shopProductType = shopProductType;

        // 桌內送禮指定的玩家
        this._account = account;

        // 上面要先設定完 不然商城頁籤無法指定(在BackpackDialog建構子會先呼叫_tabClicked)
        this._super(tabTitles);

        // 加Touch
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this.onTouchBegan.bind(this)
        }, this);
    },

    /**
     * tab點擊
     * @override
     */
    _tabClicked: function (sender) {
        var pageArray = this._pageArray;
        var senderType = sender.type;

        var clickedPos = 0;
        for (var i = 0; i < this._tabButton.length; i++) {
            if (sender == this._tabButton[i]) {
                clickedPos = i;
            }
            this._tabButton[i].setEnabled(true);

            // 把其他頁面關掉
            var page = pageArray[i];
            page && page.setVisible(false);
        }
        sender.setEnabled(false);

        if (!pageArray[clickedPos]) {
            // 創分頁
            // 商城頁面會有指定的分頁
            var shopProductType = (senderType === ShopType.PRODUCT) ? this._shopProductType : undefined;
            var page = pageArray[clickedPos] = new ChipShopPageViewLayer(senderType, shopProductType, this._chipShopDialogType, this._account);
            this._animationNode.addChild(page, 2);
        }
        pageArray[clickedPos].sendSocketCommand();
        pageArray[clickedPos].setVisible(true);
    },


    /**
     * Touch
     */
    onTouchBegan: function (touch, event) {
        var target = event.getCurrentTarget();
        if (!target.isVisible())
            return false;
        for (var c = target.parent; c != null; c = c.parent) {
            if (!c.isVisible())
                return false;
        }

        var boundBox = this._bgSprite.getBoundingBox();
        var touchPos = this._bgSprite.getParent().convertToNodeSpace(touch.getLocation());

        if (cc.rectContainsPoint(boundBox, touchPos))
            return true;
        else {
            // 點到外面 關掉畫面
            this._closeDialogAnimation();
            return true;
        }
    }
});

// 商城類型
ChipShopDialog.Type = {
    LOBBY: 0,           // 大廳的商城
    GAME_SELF: 1,       // 遊戲裡點到自己
    GAME_FRIEND: 2,     // 遊戲裡點到別人
    SINGLE: 3           // 延效物品 與 Bonus單人 都沒有送全桌按鈕
};