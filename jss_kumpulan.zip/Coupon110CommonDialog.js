/**
 * v5.4.5 再儲值小額送10% - 離開時的詢問視窗
 * created by lichieh on 2022/10/25
 */
var Coupon110CommonDialog = BaseDialogLayer.extend({
    ctor: function (param) {
        this._super();

        this.key = "Coupon110CommonDialog";

        var aniLayer = this._animationLayer;

        this._param = param;

        // 背景
        var bgSprite = new ccui.Scale9Sprite("lobby_bg_window.png");
        bgSprite.setPreferredSize(cc.size(320, 174));
        bgSprite.setPosition(JSScreenMidPos);
        aniLayer.addChild(bgSprite);

        // 文字背景
        var blackBgSprite = new ccui.Scale9Sprite("lobby_bar_03.png");
        blackBgSprite.setPreferredSize(cc.size(222, 40));
        blackBgSprite.setPosition(JSScreenMidPos.x, 159 + JSScreenBonusHalfHeight);
        aniLayer.addChild(blackBgSprite);

        // 2堆籌碼
        for (var i = 0; i < 2; i++) {
            var chipSprite = new cc.Sprite("#coupon110_pic_chips.png");
            chipSprite.setScale((-2 * i + 1) * 0.8, 0.8);
            chipSprite.setPosition(420 - 328 * i + JSScreenBonusHalfWidth, 95 + JSScreenBonusHalfHeight);
            aniLayer.addChild(chipSprite);
        }

        // 標題
        var titleLabel = new cc.LabelTTF(LocalizedString.PurchaseCoupon("放棄將失去優惠喔"), JSFontName, 14);
        titleLabel.setPosition(JSScreenMidPos.x, 200 + JSScreenBonusHalfHeight);
        aniLayer.addChild(titleLabel);

        // 獲得德撲幣
        var getChipsLabel = new cc.LabelTTF(param.newChipsWillGet, JSFontName, 24);
        getChipsLabel.setFontFillColor(JSColor.YELLOW2);
        getChipsLabel.setPosition(JSScreenMidPos.x, 160 + JSScreenBonusHalfHeight);
        aniLayer.addChild(getChipsLabel);

        // 德撲幣
        var chipsLabel = new cc.LabelTTF("Chips!", JSFontName, 14);
        chipsLabel.setPosition(JSScreenMidPos.x, 126 + JSScreenBonusHalfHeight);
        aniLayer.addChild(chipsLabel);

        // 放棄按鈕
        var giveUpBtn = ButtonUtility.createSimpleButton("lobby_btn_03.png", cc.size(106, 30), LocalizedString.PurchaseCoupon("放棄"), JSColor.WHITE, 12);
        giveUpBtn.setPosition(194 + JSScreenBonusHalfWidth, 89 + JSScreenBonusHalfHeight);
        giveUpBtn.addTouchUpInsideAction(() => {
            var dialog = DialogManager.getDialogByKey("Coupon110Dialog");
            dialog && dialog.closeDialogAnimation();
        }, this);
        aniLayer.addChild(giveUpBtn);

        // 儲值按鈕
        var purchaseBtn = ButtonUtility.createSimpleButton("lobby_btn_01.png", cc.size(106, 30), JSStringUtility.format("%s %s", TexasUtility.CURRENCY_STRING, param.payMoney), JSColor.BLACK, 12);
        purchaseBtn.setPosition(319 + JSScreenBonusHalfWidth, 89 + JSScreenBonusHalfHeight);
        purchaseBtn.addTouchUpInsideAction(() => {
            // 送儲值方案
            DataModal.purchaseData.sendPurchase(this._param.productID);
            // 點擊埋點
            DataProcess.sendString("small_payment_gift_click");
        }, this);
        aniLayer.addChild(purchaseBtn);

        // 關閉按鈕
        var closeBtn = new Texas_CloseButton();
        closeBtn.addTouchUpInsideAction(this._closeDialogAnimation, this);
        closeBtn.setPosition(484 + JSScreenBonusHalfWidth, 262 + JSScreenBonusHalfHeight);
        aniLayer.addChild(closeBtn);
    }
});