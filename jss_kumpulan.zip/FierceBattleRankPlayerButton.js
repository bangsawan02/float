/**
 * 5.4.0 副系統 - 激戰任務排行前三名頭像按鈕
 * created by Jim.Chen
 */

var FierceBattleRankPlayerButton = cc.ControlButton.extend({
    ctor: function (player, level) {
        this._super();

        this.player = player;

        var fierceStr = LocalizedString.FierceBattle;
        var playerScale = level === 1 ? 1 : (level === 2 ? 0.9 : 0.8);

        // 先把此按鈕的圖片做好
        var btnSize = cc.size(80, 80);
        var midPos = cc.p(btnSize.width / 2, btnSize.height / 2);

        var node = this._mainNode = new ccui.Scale9Sprite();
        node.setCascadeColorEnabled(true);
        node.setCascadeOpacityEnabled(true);
        node.setContentSize(btnSize);

        // 人物的Node 因為會縮小 放在一起
        var playerNode = new cc.Node();
        playerNode.setPosition(midPos);
        playerNode.setCascadeColorEnabled(true);
        playerNode.setCascadeOpacityEnabled(true);
        playerNode.setScale(playerScale);
        node.addChild(playerNode);

        // 人物頭像
        var stencilSprite = new cc.Sprite("#lobby_photo_clip.png");
        var clipNode = new cc.ClippingNode(stencilSprite);
        clipNode.setCascadeColorEnabled(true);
        clipNode.setAlphaThreshold(0.5);
        playerNode.addChild(clipNode);

        if (player) {
            // 放照片
            var photoSprite = new PhotoSprite(player.photoUrl, 56, 56);
            clipNode.addChild(photoSprite);
        } else {
            // 灰色假人底圖
            var photoSprite = new cc.Sprite("#photo_gray_male.png");
            clipNode.addChild(photoSprite);

            // 從缺字樣
            var emptyLabel = new cc.LabelTTF(fierceStr("缺示"), JSFontBoldName, 12);
            emptyLabel.enableStroke(JSColor.BLACK, 2);
            playerNode.addChild(emptyLabel);
        }

        // 放大
        clipNode.setScale(65 / 56);

        // 排名旁邊的葉子  前三名才有
        if (3 >= level && level >= 1) {
            var leafImage = JSStringUtility.format("#lobby_rank_laurelleaf_%02d.png", level);
            for (var i = 0; i < 2; i++) {
                var leafSprite = new cc.Sprite(leafImage);
                leafSprite.setPosition(i === 0 ? 34 : -33, 0);
                leafSprite.setFlippedX(i === 1);
                playerNode.addChild(leafSprite);
            }

            // 排名框
            var rankFrame = new cc.Sprite(JSStringUtility.format("#lobby_rank_circle_%d.png", level));
            playerNode.addChild(rankFrame);

            // 名次數字
            var rankSp = new cc.Sprite("#lobby_rank_0" + level + ".png");
            rankSp.setPosition(-35, -4);
            playerNode.addChild(rankSp);
        }

        if (player && level === 1) {
            // 要閃閃發光
            var starPos = [
                cc.p(-3, 36),
                cc.p(32, -15),
                cc.p(35, 8),
                cc.p(-47, 13)
            ];
            for (var i = 0, len = starPos.length; i < len; i++) {
                var thisDelayTime = i * 0.6;
                var finalDelayTime = 3 - thisDelayTime;
                var starSprite = new cc.Sprite("#lobby_pic_star.png");
                starSprite.setPosition(starPos[i]);
                starSprite.setScale(0.6 + JSCodeUtility.getRandomFloat(0, 0.4));
                starSprite.setOpacity(0);
                starSprite.runAction(cc.repeatForever(cc.sequence(
                    cc.delayTime(thisDelayTime),
                    cc.show(),
                    cc.fadeIn(0.5),
                    cc.delayTime(0.5),
                    cc.fadeOut(0.5),
                    cc.hide(),
                    cc.delayTime(finalDelayTime)
                )));
                starSprite.runAction(cc.repeatForever(cc.rotateBy(1, 360)));
                playerNode.addChild(starSprite);
            }
        }

        // 下方的排名文字
        var rankPosY = level === 0 ? -32 : (level === 1 ? -28 : -25);
        if (3 >= level && level >= 1) {
            var rankBgSprite = new cc.Sprite("#fierceBattle_pic_rank_bg.png");
            rankBgSprite.setPosition(midPos.x, midPos.y + rankPosY);
            node.addChild(rankBgSprite);
        }

        // 顯示名稱
        var nameString = (player) ? JSStringUtility.cutStringReplaceByEllipsis(player.nickname, 12, 70) : "-";
        var nameLabel = new cc.LabelTTF(nameString, JSFontBoldName, 12);
        nameLabel.setPosition(midPos.x, midPos.y + rankPosY);
        node.addChild(nameLabel);

        // 自己的設定
        this.setPreferredSize(btnSize);         // 一定要加這行 Native才會是對的
        this.setBackgroundSpriteForState(node, cc.CONTROL_STATE_NORMAL);
        this.addTargetWithActionForControlEvents(this, this._buttonClicked,
            cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_CANCEL |
            cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_UP_INSIDE |
            cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE);
        this.setAdjustBackgroundImage(false);
        this.setZoomOnTouchDown(false);
        this.setSwallowTouches(false);
        this.setTouchDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);

        // 假如沒有player 設定不能按
        this.setEnabled(!!player);
    },

    /**
     * 按到的時後 要改變顏色
     */
    _buttonClicked: function (sender, type) {
        var isTouched = (type === cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE || type === cc.CONTROL_EVENT_TOUCH_DOWN);
        this._mainNode.setColor(isTouched ? JSColor.GRAY : JSColor.WHITE);
    }
});