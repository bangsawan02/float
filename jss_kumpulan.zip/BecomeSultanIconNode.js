/**
 * v5.4.8 成為蘇丹 - 大廳Icon
 * 儲值方案，儲值完成會獎勵裡會有頭像匡跟物品，需要刷新
 *
 * created by wen
 */

var BecomeSultanIconNode = LobbyTimeIconNode.extend({
    ctor: function () {
        this._super();

        this.key = "BecomeSultanIconNode";

        // 註冊
        GS.addListener("NotifyBecomeSultanInfoDone", this.notifyBecomeSultanInfoDone.bind(this), this);
        GS.addListener("NotifyBecomeSultanRechargeDone", this.notifyBecomeSultanRechargeDone.bind(this), this);
    },

    /**
     * 更新畫面
     */
    _refreshView: function () {
        var param = DataModal.purchaseCouponData.becomeSultanInfo;

        // 先清掉所有東西
        this._badgeNode = undefined;
        var mainNode = this._mainNode;
        mainNode.removeAllChildren();

        var leftTime = param ? JSCodeUtility.getRemainTime(param.leftTime, param.socketTime) : 0;
        if (!param || !leftTime || leftTime <= 0) {
            this.setVisible(false);
            return;
        }

        // 設定看的到
        this.setVisible(true);

        // icon
        var iconSprite = new cc.Sprite("#lobby_icon_becomeSultan.png");
        mainNode.addChild(iconSprite);

        // 加入倒數時間
        this.createTimeLabelWithBackground(leftTime, () => {
            DataProcess.sendString("sultan_king_info 1");

            // 時間到了隱藏自己
            this.setVisible(false);
        });

        // 假如不是這期第一次進入，要加上小紅點
        var account = DataModal.profileData.account;
        var isRedPoint = GS.localStorage.getItem(UserDefaultKey.BecomeSultanRedPoint + account) === "1";
        if (isRedPoint) {
            var badgeNode = this._badgeNode = new BadgeNode();
            badgeNode.setPosition(17, 9);
            badgeNode.useDefaultStyle();
            mainNode.addChild(badgeNode);
        }
    },

    /**
     * 按到的時後 要改變顏色
     */
    _iconClicked: function (sender) {
        if (!DialogManager.isExist("BecomeSultanDialog")) {
            sender.setEnabled(false);
            this.runAction(cc.sequence(
                cc.delayTime(1),
                cc.callFunc(() => {
                    sender.setEnabled(true);
                })
            ));

            // 關掉紅點
            var account = DataModal.profileData.account;
            GS.localStorage.setItem(UserDefaultKey.BecomeSultanRedPoint + account, "0");
            this._badgeNode && this._badgeNode.setVisible(false);

            // 送要新資料
            DataProcess.sendString("sultan_king_info 2");

            // 送server埋點
            var trackParam = {
                click_type: "2",
                group: DataModal.purchaseCouponData.becomeSultanInfo.group
            };
            DataProcess.sendString("track_sultan_king " + JSON.stringify(trackParam));
        }
    },

    /**
     * 通知 收到資訊
     */
    // 更新資訊
    notifyBecomeSultanInfoDone: function () {
        this._refreshView();
    },

    // 儲值成功
    notifyBecomeSultanRechargeDone: function () {
        this.setVisible(false);

        // 清掉所有東西
        this._badgeNode = undefined;
        this._mainNode.removeAllChildren();
    }
});