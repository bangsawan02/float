/**
 * v5.4.5 商城 - 德撲幣商城Dialog的頁面(繼承 BackpackBasePageViewLayer)
 * created by lichieh on 2022/11/2
 */
var ChipShopPageViewLayer = BackpackBasePageViewLayer.extend({
    ctor: function (shopType, shopProductType, chipShopDialogType, account) {
        // 過濾商品用
        this._shopProductType = shopProductType || DataModal.shopData.shopOpenTag || ShopProductType.LOVE;

        this._super(shopType, shopProductType);

        this._account = account;
        this._chipShopDialogType = chipShopDialogType;

        // 裝商城上分類按鈕
        var shopNode = this._shopNode = new cc.Node();
        this.addChild(shopNode);

        // 商城上方的商品分類按鈕
        var shopString = LocalizedString.Shop;
        var tabTitles = [
            {title: shopString("富豪"), type: ShopProductType.RICH},
            {title: shopString("風水"), type: ShopProductType.FENGSHUI},
            {title: shopString("求愛"), type: ShopProductType.LOVE},
            {title: shopString("話題"), type: ShopProductType.TALK},
            {title: shopString("美食"), type: ShopProductType.FOOD},
            {title: shopString("禮包"), type: ShopProductType.GIFT}
        ];

        var menu = new cc.Menu();
        menu.setPosition(0, 0);
        shopNode.addChild(menu);

        this._segmentItems = [];
        var tabLen = tabTitles.length;
        var btnSize = cc.size(57, 22);
        var posX = JSScreenMidPos.x - ((tabLen - 1) / 2 * btnSize.width);
        var defaultBtn;
        for (var i = 0; i < tabLen; i++) {
            var btnImage;
            var flipX = false;
            if (i === 0)
                btnImage = "shop_bt_01.png";
            else if (i === tabLen - 1) {
                btnImage = "shop_bt_03.png";
                flipX = true;
            } else
                btnImage = "shop_bt_02.png";
            var btnImages = [btnImage, btnImage, btnImage];
            var itemNode = ButtonUtility.createArrayScale9Nodes(btnImages, btnSize, tabTitles[i].title, 12, JSColor.WHITE);
            itemNode[0].setOpacity(150);
            itemNode[1].setColor(JSColor.WHITE);
            itemNode[2].setOpacity(255);
            var tabItem = this._segmentItems[i] = new cc.MenuItemSprite(itemNode[0], itemNode[1], itemNode[2], this._filterClicked, this);
            tabItem.type = tabTitles[i].type;
            tabItem.setPosition(posX + btnSize.width * i, 230 + JSScreenBonusHeight / 2);
            menu.addChild(tabItem);

            // 分隔線
            if (i !== (tabLen - 1)) {
                var line = new cc.Sprite("#shop_bt_04.png");
                line.setPosition(tabItem.getPosition().x + btnSize.width / 2, tabItem.getPosition().y);
                shopNode.addChild(line);
            }

            if (tabTitles[i].type === this._shopProductType)
                defaultBtn = this._segmentItems[i];
        }

        // 給按鈕預設值
        if (!defaultBtn)
            defaultBtn = this._segmentItems[0];

        // 預設的index
        this._filterClicked(defaultBtn);

        // 紅點所在位置
        var btnPos = defaultBtn.getPosition();
        var badge = new BadgeNode();
        badge.setPosition(btnPos.x + btnSize.width / 2 - 4, btnPos.y + btnSize.height / 2 - 2);
        badge.useDefaultStyle();
        badge.setScale(0.8);
        shopNode.addChild(badge);
    },

    /**
     * 刷新頁面
     * @override
     */
    _refreshAllPage: function () {
        // 把Loading拿掉
        this._loadingSprite.stop();

        // 以下Page的主畫面
        this._pageView.removeAllPages();

        if (this._shopType === ShopType.PRODUCT) {
            // 商城會依照頁籤(ShopProductType)去抓清單
            this._shopItemArray = DataModal.shopData.getShopProductByType(this._shopProductType);
        } else {
            // 其他面面的清單依照ShopType去抓
            this._shopItemArray = DataModal.shopData.getShopItemArrayByType(this._shopType);
        }

        this._updatePage();
    },

    /**
     * 上方Segment按鈕
     */
    _filterClicked: function (sender) {
        this._segmentItems.forEach(cur => cur.setEnabled(true));
        sender.setEnabled(false);
        this._shopNode.setVisible(this._shopType === ShopType.PRODUCT);
        this._shopProductType = sender.type;
        this._refreshAllPage();
    }
});