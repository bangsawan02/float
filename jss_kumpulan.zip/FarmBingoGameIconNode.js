/**
 * v5.6.0 齋戒副系統 賓果 牌桌內 icon
 */
var FarmBingoGameIconNode = LobbyTimeIconNode.extend({
    ctor: function () {
        this._super();
        this.key = "FarmBingoGameIconNode";

        this._button.setChangeColorWhenDisabled(false);
        this._button.enableTouchCancel(cc.SCROLLVIEW_DIRECTION_VERTICAL);

        this._isInCanGetTokenSlot = false;
        this._isInCanGetTokenPlay = false;

        var mainNode = this._mainNode;

        // 圖案
        var iconSprite = new cc.Sprite("#lobby_icon_farm_pass.png");
        iconSprite.setScale(1.15);
        mainNode.addChild(iconSprite);

        GS.addListener("NotifyFarmBingoIconDone", this.notifyFarmBingoIconDone.bind(this), this);
        GS.addListener("NotifySetLevelDone", this.notifySetLevelDone.bind(this), this);

        // 在Slot內要監聽投注額改變&轉狀態
        if (PushScene.isSlot) {
            GS.addListener("NotifyOnClickSpin", this.notifyOnClickSpin.bind(this), this);
            GS.addListener("NotifySlotOnSpinEnd", this.notifySlotOnSpinEnd.bind(this), this);
        }
    },

    onEnterTransitionDidFinish: function () {
        this._super();

        // 去要資料
        DataModal.farmBingoData.startGetIconInfo();
    },

    _refreshView: function () {
        // 抓資料
        let data = DataModal.farmBingoData;
        let iconParam = data.iconParam;
        if (!data.getEventIsOpen() || !iconParam) {
            this.setVisible(false);
            return;
        }

        // 取得剩餘時間
        let remainTime = JSCodeUtility.getRemainTime(iconParam.remainTime, iconParam.socketTime);

        this.stopActionByTag(0);

        // 有剩餘時間顯示且在可累積台底
        if (remainTime > 0 && (this._isInCanGetTokenPlay || this._isInCanGetTokenSlot)) {
            this.setVisible(true);

            let action = cc.sequence(
                cc.delayTime(remainTime),
                cc.callFunc(() => {
                    // 時間到
                    this.setVisible(false);
                })
            );

            // 倒數
            this.runAction(action);
        } else {
            this.setVisible(false);
        }
    },

    /**
     * 按鈕
     */
    _iconClicked: function () {
        if (JSIsPortrait) {
            // 直式直接顯示提示前往大廳查看
            GS.dispatchCustomEvent("NotifyShowVegasSideOptionRemind", {
                type: VegasSideOptionMessageType.FARM_BINGO,
                msg: "#!000000!#" + LocalizedString.Vegas("請回到大廳查看")
            });
        } else {
            // 跳Dialog
            if (!DialogManager.isExist("FarmBingoDialog"))
                DialogManager.addDialog(new FarmBingoDialog());
        }
    },

    /**
     * 通知
     */
    notifyFarmBingoIconDone: function () {
        var data = DataModal.farmBingoData.iconParam;
        if (data && data.isSuccess) {
            this._isInCanGetTokenSlot = DataModal.farmBingoData.isInCanGetTokenSlot();
            this._isInCanGetTokenPlay = DataModal.farmBingoData.isInCanGetTokenPlay();
            this._refreshView();
        }
    },

    // 更新等級
    notifySetLevelDone: function () {
        // 如果活動沒有開升級後去重要資料
        var data = DataModal.farmBingoData;
        if (!data.getEventIsOpen()) {
            DataModal.farmBingoData.startGetIconInfo();
        }
    },

    // 開始轉就不給按
    notifyOnClickSpin: function () {
        this.setButtonEnabled(false);
    },

    // 停下來就可以按
    notifySlotOnSpinEnd: function () {
        this.setButtonEnabled(true);
    },
});